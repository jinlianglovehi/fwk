






在定制化开发中，客户需求屏保启动时间设置为一律不，如下图  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/8ecca397e1144c28afc887e85e4408a4.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70#pic_center)


而屏保项就是在显示的二级菜单里面  
 显示一级菜单  
 display\_settings.xml中  
 屏保



```
  <Preference
        android:key="screensaver"
        android:title="@string/screensaver\_settings\_title"
        android:fragment="com.android.settings.dream.DreamSettings"
        settings:searchable="false" />

```

二级菜单  
 DreamSettings  
 的xml 是 dream\_fragment\_overview.xml  
 启用时间:



WhenToDreamPicker.java中


@Override  
 protected String getDefaultKey() {  
 return DreamSettings.getKeyFromSetting(mBackend.getWhenToDreamSetting());  
 }


默认值 是通过 DreamBackend.getWhenToDreamSetting()获取  
 接下来看 getWhenToDreamSetting()方法



```
  public @WhenToDream int getWhenToDreamSetting() {
        if (!isEnabled()) {
            return NEVER;
        }
        return isActivatedOnDock() && isActivatedOnSleep() ? EITHER
                : isActivatedOnDock() ? WHILE_DOCKED
                : isActivatedOnSleep() ? WHILE_CHARGING
                : NEVER;
    }

```

从上面看出 isActivatedOnDock 和isActivatedOnSleep 为false 就好



```
public boolean isActivatedOnDock() {
    return getBoolean(Settings.Secure.SCREENSAVER_ACTIVATE_ON_DOCK,
            mDreamsActivatedOnDockByDefault);
}
public boolean isActivatedOnSleep() {
    return getBoolean(Settings.Secure.SCREENSAVER_ACTIVATE_ON_SLEEP,
            mDreamsActivatedOnSleepByDefault);
}

  public DreamBackend(Context context) {
        mContext = context.getApplicationContext();
        mDreamManager = IDreamManager.Stub.asInterface(
                ServiceManager.getService(DreamService.DREAM_SERVICE));
        mComparator = new DreamInfoComparator(getDefaultDream());
        mDreamsEnabledByDefault = mContext.getResources()
                .getBoolean(com.android.internal.R.bool.config_dreamsEnabledByDefault);
        mDreamsActivatedOnSleepByDefault = mContext.getResources()
                .getBoolean(com.android.internal.R.bool.config_dreamsActivatedOnSleepByDefault);
        mDreamsActivatedOnDockByDefault = mContext.getResources()
                .getBoolean(com.android.internal.R.bool.config_dreamsActivatedOnDockByDefault);
    }

```

通过查看config\_dreamsActivatedOnSleepByDefault和config\_dreamsActivatedOnDockByDefault 发现config\_dreamsActivatedOnDockByDefault为true  
 所以改为false即可


具体修改如下:



```
--- a/frameworks/base/core/res/res/values/config.xml
+++ b/frameworks/base/core/res/res/values/config.xml
@@ -2270,7 +2270,7 @@
     <!-- If supported, are dreams enabled? (by default) -->
     <bool name="config\_dreamsEnabledByDefault">true</bool>
     <!-- If supported and enabled, are dreams activated when docked? (by default) -->
-    <bool name="config\_dreamsActivatedOnDockByDefault">true</bool>
+    <bool name="config\_dreamsActivatedOnDockByDefault">false</bool>
     <!-- If supported and enabled, are dreams activated when asleep and charging? (by default) -->
     <bool name="config\_dreamsActivatedOnSleepByDefault">false</bool>

```




