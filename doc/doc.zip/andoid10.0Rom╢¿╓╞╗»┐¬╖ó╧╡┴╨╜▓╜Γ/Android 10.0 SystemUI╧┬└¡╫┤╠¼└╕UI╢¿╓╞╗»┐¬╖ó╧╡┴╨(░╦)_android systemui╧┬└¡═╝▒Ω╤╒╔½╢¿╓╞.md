



**目录**



[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码部分](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E9%83%A8%E5%88%86)


[3.核心代码分析](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1状态栏黑色透明背景的分析](#3.1%E7%8A%B6%E6%80%81%E6%A0%8F%E9%BB%91%E8%89%B2%E9%80%8F%E6%98%8E%E8%83%8C%E6%99%AF%E7%9A%84%E5%88%86%E6%9E%90)


[4.修改下拉状态栏部分背景](#4.%E4%BF%AE%E6%94%B9%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8F%E9%83%A8%E5%88%86%E8%83%8C%E6%99%AF)


[4.1关于QuickQSPanel.java的代码分析](#4.1%E5%85%B3%E4%BA%8EQuickQSPanel.java%E7%9A%84%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)




---



## 1.概述


SystemUI下拉状态栏UI定制第八讲 本篇主要解决QuickQSPanel的下拉状态栏的黑色透明背景的


去除，在下拉状态栏透明度较高的壁纸的情况下可以很清楚的看到黑色透明背景所以这里就要删除这些透明背景


## 2.核心代码部分



```
主要代码如下:
 /frameworks/base/packages/SystemUI/res/layout/status_bar_expanded.xml
/frameworks/base/packages/SystemUI/res/layout/qs_panel.xml
/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickQSPanel.java
```

## 3.核心代码分析


#### 3.1状态栏黑色透明背景的分析


先从下拉状态栏布局分析



```
 /frameworks/base/packages/SystemUI/res/layout/status_bar_expanded.xml
<com.android.systemui.statusbar.phone.NotificationPanelView
xmlns:android="http://schemas.android.com/apk/res/android"
xmlns:systemui="http://schemas.android.com/apk/res-auto"
android:id="@+id/notification_panel"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:background="@android:color/transparent" >

<FrameLayout
android:id="@+id/big_clock_container"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:visibility="gone" />

<include
layout="@layout/keyguard_status_view"
android:visibility="gone" />

<com.android.systemui.statusbar.phone.NotificationsQuickSettingsContainer
android:layout_width="match_parent"
android:layout_height="match_parent"
android:layout_gravity="@integer/notification_panel_layout_gravity"
android:id="@+id/notification_container_parent"
android:clipToPadding="false"
android:clipChildren="false">

<include layout="@layout/dock_info_overlay" />

<FrameLayout
android:id="@+id/qs_frame"
android:layout="@layout/qs_panel"
android:layout_width="@dimen/qs_panel_width"
android:layout_height="match_parent"
android:layout_gravity="@integer/notification_panel_layout_gravity"
android:clipToPadding="false"
android:clipChildren="false"
systemui:viewType="com.android.systemui.plugins.qs.QS" />

<com.android.systemui.statusbar.notification.stack.NotificationStackScrollLayout
android:id="@+id/notification_stack_scroller"
android:layout_marginTop="@dimen/notification_panel_margin_top"
android:layout_width="@dimen/notification_panel_width"
android:layout_height="match_parent"
android:layout_gravity="@integer/notification_panel_layout_gravity"
android:layout_marginBottom="@dimen/close_handle_underlap" />

<include layout="@layout/ambient_indication"
android:id="@+id/ambient_indication_container" />

<ViewStub
android:id="@+id/keyguard_user_switcher"
android:layout="@layout/keyguard_user_switcher"
android:layout_height="match_parent"
android:layout_width="match_parent" />

<include
layout="@layout/keyguard_status_bar"
android:visibility="invisible" />

<Button
android:id="@+id/report_rejected_touch"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:layout_marginTop="@dimen/status_bar_header_height_keyguard"
android:text="@string/report_rejected_touch"
android:visibility="gone" />

</com.android.systemui.statusbar.phone.NotificationsQuickSettingsContainer>

<include
layout="@layout/keyguard_bottom_area"
android:visibility="gone" />

<com.android.systemui.statusbar.AlphaOptimizedView
android:id="@+id/qs_navbar_scrim"
android:layout_height="96dp"
android:layout_width="match_parent"
android:layout_gravity="bottom"
android:visibility="invisible"
android:background="@drawable/qs_navbar_scrim" />

</com.android.systemui.statusbar.phone.NotificationPanelView>

从<FrameLayout
android:id="@+id/qs_frame"
android:layout="@layout/qs_panel"
android:layout_width="@dimen/qs_panel_width"
android:layout_height="match_parent"
android:layout_gravity="@integer/notification_panel_layout_gravity"
android:clipToPadding="false"
android:clipChildren="false"
systemui:viewType="com.android.systemui.plugins.qs.QS" />
可以看出下拉状态布局在qs_panel.xml中

```

接下来分析qs\_panel.xml



```
<com.android.systemui.qs.QSContainerImpl
xmlns:android="http://schemas.android.com/apk/res/android"
android:id="@+id/quick_settings_container"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:clipToPadding="false"
android:clipChildren="false" >

<!-- Main QS background -->
<View
android:id="@+id/quick_settings_background"
android:layout_width="match_parent"
android:layout_height="0dp"
android:elevation="4dp"
android:background="@drawable/qs_background_primary" />

<!-- Black part behind the status bar -->
<View
android:id="@+id/quick_settings_status_bar_background"
android:layout_width="match_parent"
android:layout_height="@*android:dimen/quick_qs_offset_height"
android:clipToPadding="false"
android:clipChildren="false"
android:background="#ff000000" />

<!-- Gradient view behind QS -->
<View
android:id="@+id/quick_settings_gradient_view"
android:layout_width="match_parent"
android:layout_height="126dp"
android:layout_marginTop="@*android:dimen/quick_qs_offset_height"
android:clipToPadding="false"
android:clipChildren="false"
android:background="@drawable/qs_bg_gradient" />


<com.android.systemui.qs.QSPanel
android:id="@+id/quick_settings_panel"
android:layout_marginTop="@*android:dimen/quick_qs_offset_height"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:layout_marginBottom="@dimen/qs_footer_height"
android:elevation="4dp"
android:background="@android:color/transparent"
android:focusable="true"
android:accessibilityTraversalBefore="@android:id/edit"
/>

<include layout="@layout/quick_status_bar_expanded_header" />

<include layout="@layout/qs_footer_impl" />

<include android:id="@+id/qs_detail" layout="@layout/qs_detail" />

<include android:id="@+id/qs_customize" layout="@layout/qs_customize_panel"
android:visibility="gone" />

</com.android.systemui.qs.QSContainerImpl>

从代码分析出


<!-- Black part behind the status bar -->
<View
android:id="@+id/quick_settings_status_bar_background"
android:layout_width="match_parent"
android:layout_height="@*android:dimen/quick_qs_offset_height"
android:clipToPadding="false"
android:clipChildren="false"
android:background="#ff000000" />
就是黑色透明背景




```

3.2解决方案



```
    <View
        android:id="@+id/quick_settings_status_bar_background"
        android:layout_width="match_parent"
        android:layout_height="@*android:dimen/quick_qs_offset_height"
        android:clipToPadding="false"
        android:clipChildren="false"
        android:background="#00000000" />
改为透明背景

```

## 4.修改下拉状态栏部分背景


#### 4.1关于QuickQSPanel.java的代码分析



```
在QuickStatusBarHeader.java 中
private void updateResources() {
Resources resources = mContext.getResources();
updateMinimumHeight();
    // Update height for a few views, especially due to landscape mode restricting space.
    mHeaderTextContainerView.getLayoutParams().height =
            resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
    mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

    mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
            com.android.internal.R.dimen.quick_qs_offset_height);
    mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
    if (mQsDisabled) {
        lp.height = resources.getDimensionPixelSize(
                com.android.internal.R.dimen.quick_qs_offset_height);
    } else {
        lp.height = Math.max(getMinimumHeight(),
                resources.getDimensionPixelSize(
                        com.android.internal.R.dimen.quick_qs_total_height));
    }

    setLayoutParams(lp);

    updateStatusIconAlphaAnimator();
    updateHeaderTextContainerAlphaAnimator();
}
private void updateStatusIconAlphaAnimator() {
    mStatusIconsAlphaAnimator = new TouchAnimator.Builder()
            .addFloat(mQuickQsStatusIcons, "alpha", 1, 0, 0)
            .build();
}
updateResources() 就是关于对布局的设置
通过源码分析updateStatusIconAlphaAnimator() 设置了透明度

```

4.2解决方案



```
private void updateResources() {
Resources resources = mContext.getResources();
updateMinimumHeight();
    // Update height for a few views, especially due to landscape mode restricting space.
    mHeaderTextContainerView.getLayoutParams().height =
            resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
    mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

    mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
            com.android.internal.R.dimen.quick_qs_offset_height);
    mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
    if (mQsDisabled) {
        lp.height = resources.getDimensionPixelSize(
                com.android.internal.R.dimen.quick_qs_offset_height);
    } else {
        lp.height = Math.max(getMinimumHeight(),
                resources.getDimensionPixelSize(
                        com.android.internal.R.dimen.quick_qs_total_height));
    }

    setLayoutParams(lp);

    //updateStatusIconAlphaAnimator();
    updateHeaderTextContainerAlphaAnimator();
}
注释掉updateStatusIconAlphaAnimator()即可

```



