






### 1.概述


在10.0的系统产品开发中，对于Launcher3做各种定制化开发，也是常见的，对于修改图标的形状 修改为圆角图标，对于图标的修改也是要从BubbleTextView.java修改的  
 效果图如下:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/0697be197d194f4ba92f0a2af3ea7540.png#pic_center)


### 2.Launcher3 app hotseat 图标形状为圆角图标的核心类



```
/package/app/Launcher3/src/com/android/launcher3/BubbleTextView.java

```

### 3.Launcher3 app hotseat 图标形状为圆角图标的核心功能分析和实现


在通过读Launcher3的源码发现，在app 的icon 和hotseat folder等都是由BubbleTextView.java  
 构建的，所以对于圆角图标的定制还是需要


看BubbleTextView.java 源码  
 /package/app/Launcher3/src/com/android/launcher3/BubbleTextView.java



```
 public class BubbleTextView extends TextView implements ItemInfoUpdateReceiver, OnResumeCallback {
 public BubbleTextView(Context context, AttributeSet attrs, int defStyle) {
          super(context, attrs, defStyle);
          mActivity = ActivityContext.lookupContext(context);
          mSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
  
          TypedArray a = context.obtainStyledAttributes(attrs,
                  R.styleable.BubbleTextView, defStyle, 0);
          mLayoutHorizontal = a.getBoolean(R.styleable.BubbleTextView_layoutHorizontal, false);
  
          int display = a.getInteger(R.styleable.BubbleTextView_iconDisplay, DISPLAY_WORKSPACE);
          final int defaultIconSize;
          if (display == DISPLAY_WORKSPACE) {
              DeviceProfile grid = mActivity.getWallpaperDeviceProfile();
              setTextSize(TypedValue.COMPLEX_UNIT_PX, grid.iconTextSizePx);
              setCompoundDrawablePadding(grid.iconDrawablePaddingPx);
              defaultIconSize = grid.iconSizePx;
          } else if (display == DISPLAY_ALL_APPS) {
              DeviceProfile grid = mActivity.getDeviceProfile();
              setTextSize(TypedValue.COMPLEX_UNIT_PX, grid.allAppsIconTextSizePx);
              setCompoundDrawablePadding(grid.allAppsIconDrawablePaddingPx);
              defaultIconSize = grid.allAppsIconSizePx;
          } else if (display == DISPLAY_FOLDER) {
              DeviceProfile grid = mActivity.getDeviceProfile();
              setTextSize(TypedValue.COMPLEX_UNIT_PX, grid.folderChildTextSizePx);
              setCompoundDrawablePadding(grid.folderChildDrawablePaddingPx);
              defaultIconSize = grid.folderChildIconSizePx;
          } else {
              defaultIconSize = mActivity.getDeviceProfile().iconSizePx;
          }
          mCenterVertically = a.getBoolean(R.styleable.BubbleTextView_centerVertically, false);
  
          mIconSize = a.getDimensionPixelSize(R.styleable.BubbleTextView_iconSizeOverride,
                  defaultIconSize);
          a.recycle();
  
          mLongPressHelper = new CheckLongPressHelper(this);
          mStylusEventHelper = new StylusEventHelper(new SimpleOnStylusPressListener(this), this);
  
          mDotParams = new DotRenderer.DrawParams();
  
          setEllipsize(TruncateAt.END);
          setAccessibilityDelegate(mActivity.getAccessibilityDelegate());
          setTextAlpha(1f);
      }
     public void applyFromWorkspaceItem(WorkspaceItemInfo info, boolean promiseStateChanged) {
          applyIconAndLabel(info);
          setTag(info);
          if (promiseStateChanged || (info.hasPromiseIconUi())) {
              applyPromiseState(promiseStateChanged);
          }
  
          applyDotState(info, false /* animate */);
      }
  
      public void applyFromApplicationInfo(AppInfo info) {
          applyIconAndLabel(info);
  
          // We don't need to check the info since it's not a WorkspaceItemInfo
          super.setTag(info);
  
          // Verify high res immediately
          verifyHighRes();
  
          if (info instanceof PromiseAppInfo) {
              PromiseAppInfo promiseAppInfo = (PromiseAppInfo) info;
              applyProgressLevel(promiseAppInfo.level);
          }
          applyDotState(info, false /* animate */);
      }
  
      public void applyFromPackageItemInfo(PackageItemInfo info) {
          applyIconAndLabel(info);
          // We don't need to check the info since it's not a WorkspaceItemInfo
          super.setTag(info);
  
          // Verify high res immediately
          verifyHighRes();
      }
  
      private void applyIconAndLabel(ItemInfoWithIcon info) {
          FastBitmapDrawable iconDrawable = DrawableFactory.INSTANCE.get(getContext())
                  .newIcon(getContext(), info);
          mDotParams.color = IconPalette.getMutedColor(info.iconColor, 0.54f);
  
          setIcon(iconDrawable);
          setText(info.title);
          if (info.contentDescription != null) {
              setContentDescription(info.isDisabled()
                      ? getContext().getString(R.string.disabled_app_label, info.contentDescription)
                      : info.contentDescription);
          }
      }

```

在applyFromApplicationInfo(AppInfo info) 中调用applyIconAndLabel(ItemInfoWithIcon info)来实现对app的icon的图标的显示处理在  
 applyIconAndLabel 是对图标做处理显示的  
 所以就从这里解决问题


进入DrawableFactory .newIcon();



```
public FastBitmapDrawable newIcon(Context context, ItemInfoWithIcon info) {
    FastBitmapDrawable drawable = info.usingLowResIcon()
            ? new PlaceHolderIconDrawable(info, getShapePath(), context)
            : new FastBitmapDrawable(info);
    drawable.setIsDisabled(info.isDisabled());
    return drawable;
}

```

发现实际上是有FastBitmapDrawable来处理app图标,构建显示图标，  
 实际的图标处理就是在FastBitmapDrawable中  
 继续跟踪FastBitmapDrawable



```
public FastBitmapDrawable(ItemInfoWithIcon info) {
        this(info.iconBitmap, info.iconColor);
    }

    protected FastBitmapDrawable(Bitmap b, int iconColor) {
        this(b, iconColor, false);
    }

    protected FastBitmapDrawable(Bitmap b, int iconColor, boolean isDisabled) {
        mBitmap = b;
        mIconColor = iconColor;
        setFilterBitmap(true);
        setIsDisabled(isDisabled);
    }

    @Override
    public final void draw(Canvas canvas) {
        if (mScale != 1f) {
            int count = canvas.save();
            Rect bounds = getBounds();
            canvas.scale(mScale, mScale, bounds.exactCenterX(), bounds.exactCenterY());
            drawInternal(canvas, bounds);
            canvas.restoreToCount(count);
        } else {
            drawInternal(canvas, getBounds());
        }
    }

    protected void drawInternal(Canvas canvas, Rect bounds) {
        canvas.drawBitmap(mBitmap, null, bounds, mPaint);
    }

```

通过FastBitmapDrawable构造方法调用draw(Canvas canvas)然后又调用drawInternal(来实现图标的绘制，  
 从以上代码可以看出 具体处理图标的地方是在drawInternal


所以就在这里对图标做圆角处理 具体如下:



```
     protected void drawInternal(Canvas canvas, Rect bounds) {
-        canvas.drawBitmap(mBitmap, null, bounds, mPaint);
+        // 初始化绘制纹理图
+        BitmapShader bitmapShader = new BitmapShader(mBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
+               Paint paint = new Paint();
+               paint.setAntiAlias(true);
+               paint.setDither(true);
+        paint.setShader(bitmapShader);
+               paint.setStrokeWidth(16);
+        // 利用画笔将纹理图绘制到画布上面
+               int mWidth = Math.min(mBitmap.getWidth(), mBitmap.getHeight());
+        canvas.drawRoundRect(new RectF(8, 8, mWidth-8, mWidth-8), 40, 40, paint);
+               //canvas.drawCircle(mWidth / 2, mWidth / 2, mWidth / 2, paint);
+        //canvas.drawBitmap(mBitmap, null, bounds, mPaint);
     }

```

就通过上面的方法实现了对于app图标圆形圆角的绘制





