






### 1.概述


在10.0的系统产品开发中，对于系统SystemUI的定制功能也是特别多的，由于产品是小屏幕所以需要放大导航栏NavigationBar的宽高，用来方便操作导航栏的图标功能。


### 2.修改NavigationBar 图标宽高的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/KeyButtonDrawable.java

```

### 3.修改NavigationBar 图标宽高的核心功能实现和分析


在SystemUI的导航栏中，在系统源码中发现在导航栏图标都是由KeyButtonDrawable负责绘制的  
 所以可以在这里分析实现扩大KeyButtonDrawable.java的图标功能，接下来看下KeyButtonDrawable绘制图标的源码



```
public class KeyButtonDrawable extends Drawable {

    public KeyButtonDrawable(Drawable d, @ColorInt int lightColor, @ColorInt int darkColor,
            boolean horizontalFlip, Color ovalBackgroundColor) {
        this(d, new ShadowDrawableState(lightColor, darkColor,
                d instanceof AnimatedVectorDrawable, horizontalFlip, ovalBackgroundColor));

```

在构造方法传入keybutton参数的构建，如下方，在ShadowDrawableState 的宽高是由度量drawable的宽高然后设置的虚拟按键的图标的



```
	//构建虚拟按键图标
    private KeyButtonDrawable(Drawable d, ShadowDrawableState state) {
        mState = state;
        if (d != null) {
            mState.mBaseHeight = d.getIntrinsicHeight()*2;
            mState.mBaseWidth = d.getIntrinsicWidth()*2;
            //此处 来给图标宽高取值，宽高改为原来宽高的2倍高度
            mState.mChangingConfigurations = d.getChangingConfigurations();
            mState.mChildState = d.getConstantState();
        }
        if (canAnimate()) {
            mAnimatedDrawable = (AnimatedVectorDrawable) mState.mChildState.newDrawable().mutate();
            setDrawableBounds(mAnimatedDrawable);
        }
    }

```

接下来看下绘制图标的相关方法



```
    @Override
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        if (bounds.isEmpty()) {
            return;
        }

        if (mAnimatedDrawable != null) {
            mAnimatedDrawable.draw(canvas);
        } else {
            // If no cache or previous cached bitmap is hardware/software acceleration does not
            // match the current canvas on draw then regenerate
            boolean hwBitmapChanged = mState.mIsHardwareBitmap != canvas.isHardwareAccelerated();
            if (hwBitmapChanged) {
                mState.mIsHardwareBitmap = canvas.isHardwareAccelerated();
            }
            if (mState.mLastDrawnIcon == null || hwBitmapChanged) {
                regenerateBitmapIconCache();
            }
            canvas.save();
            canvas.translate(mState.mTranslationX, mState.mTranslationY);
            canvas.rotate(mState.mRotateDegrees, getIntrinsicWidth() / 2, getIntrinsicHeight() / 2);

            if (mState.mShadowSize > 0) {
                if (mState.mLastDrawnShadow == null || hwBitmapChanged) {
                    regenerateBitmapShadowCache();
                }

                // Translate (with rotation offset) before drawing the shadow
                final float radians = (float) (mState.mRotateDegrees * Math.PI / 180);
                final float shadowOffsetX = (float) (Math.sin(radians) * mState.mShadowOffsetY
                        + Math.cos(radians) * mState.mShadowOffsetX) - mState.mTranslationX;
                final float shadowOffsetY = (float) (Math.cos(radians) * mState.mShadowOffsetY
                        - Math.sin(radians) * mState.mShadowOffsetX) - mState.mTranslationY;
                canvas.drawBitmap(mState.mLastDrawnShadow, shadowOffsetX, shadowOffsetY,
                        mShadowPaint);
            }
            canvas.drawBitmap(mState.mLastDrawnIcon, null, bounds, mIconPaint);
            canvas.restore();
        }
    }

    @Override
    public boolean canApplyTheme() {
        return mState.canApplyTheme();
    }

    @ColorInt int getDrawableBackgroundColor() {
        return mState.mOvalBackgroundColor.toArgb();
    }

    /**
     * Set the alpha of the shadow. As dark intensity increases, drop the alpha of the shadow since
     * dark color and shadow should not be visible at the same time.
     */
    private void updateShadowAlpha() {
        // Update the color from the original color's alpha as the max
        int alpha = Color.alpha(mState.mShadowColor);
        mShadowPaint.setAlpha(
                Math.round(alpha * (mState.mAlpha / 255f) * (1 - mState.mDarkIntensity)));
    }

    /**
     * Prevent shadow clipping by offsetting the drawable bounds by the shadow and its offset
     * @param d the drawable to set the bounds
     */
    private void setDrawableBounds(Drawable d) {
        final int offsetX = mState.mShadowSize + Math.abs(mState.mShadowOffsetX);
        final int offsetY = mState.mShadowSize + Math.abs(mState.mShadowOffsetY);
        d.setBounds(offsetX, offsetY, getIntrinsicWidth() - offsetX,
                getIntrinsicHeight() - offsetY);
    }

    private static class ShadowDrawableState extends ConstantState {
        int mChangingConfigurations;
        int mBaseWidth;
        int mBaseHeight;
        float mRotateDegrees;
        float mTranslationX;
        float mTranslationY;
        int mShadowOffsetX;
        int mShadowOffsetY;
        int mShadowSize;
        int mShadowColor;
        float mDarkIntensity;
        int mAlpha;
        boolean mHorizontalFlip;

        boolean mIsHardwareBitmap;
        Bitmap mLastDrawnIcon;
        Bitmap mLastDrawnShadow;
        ConstantState mChildState;

        final int mLightColor;
        final int mDarkColor;
        final boolean mSupportsAnimation;
        final Color mOvalBackgroundColor;

        public ShadowDrawableState(@ColorInt int lightColor, @ColorInt int darkColor,
                boolean animated, boolean horizontalFlip, Color ovalBackgroundColor) {
            mLightColor = lightColor;
            mDarkColor = darkColor;
            mSupportsAnimation = animated;
            mAlpha = 255;
            mHorizontalFlip = horizontalFlip;
            mOvalBackgroundColor = ovalBackgroundColor;
        }

        @Override
        public Drawable newDrawable() {
            return new KeyButtonDrawable(null, this);
        }

        @Override
        public int getChangingConfigurations() {
            return mChangingConfigurations;
        }

        @Override
        public boolean canApplyTheme() {
            return true;
        }
    }

    public static KeyButtonDrawable create(@NonNull Context ctx, @DrawableRes int icon,
            boolean hasShadow, Color ovalBackgroundColor) {
        final int dualToneDarkTheme = Utils.getThemeAttr(ctx, R.attr.darkIconTheme);
        final int dualToneLightTheme = Utils.getThemeAttr(ctx, R.attr.lightIconTheme);
        Context lightContext = new ContextThemeWrapper(ctx, dualToneLightTheme);
        Context darkContext = new ContextThemeWrapper(ctx, dualToneDarkTheme);
        return KeyButtonDrawable.create(lightContext, darkContext, icon, hasShadow,
                ovalBackgroundColor);
    }

    public static KeyButtonDrawable create(@NonNull Context ctx, @DrawableRes int icon,
            boolean hasShadow) {
        return create(ctx, icon, hasShadow, null /* ovalBackgroundColor */);
    }

    /**
     * Creates a KeyButtonDrawable with a shadow given its icon. For more information, see
     * {@link #create(Context, int, boolean, boolean)}.
     */
    public static KeyButtonDrawable create(Context lightContext, Context darkContext,
            @DrawableRes int iconResId, boolean hasShadow, Color ovalBackgroundColor) {
        return create(lightContext,
            Utils.getColorAttrDefaultColor(lightContext, R.attr.singleToneColor),
            Utils.getColorAttrDefaultColor(darkContext, R.attr.singleToneColor),
            iconResId, hasShadow, ovalBackgroundColor);
    }

    /**
     * Creates a KeyButtonDrawable with a shadow given its icon. For more information, see
     * {@link #create(Context, int, boolean, boolean)}.
     */
    public static KeyButtonDrawable create(Context context, @ColorInt int lightColor,
            @ColorInt int darkColor, @DrawableRes int iconResId, boolean hasShadow,
            Color ovalBackgroundColor) {
        final Resources res = context.getResources();
        boolean isRtl = res.getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        Drawable d = context.getDrawable(iconResId);
        final KeyButtonDrawable drawable = new KeyButtonDrawable(d, lightColor, darkColor,
                isRtl && d.isAutoMirrored(), ovalBackgroundColor);
        if (hasShadow) {
            int offsetX = res.getDimensionPixelSize(R.dimen.nav_key_button_shadow_offset_x);
            int offsetY = res.getDimensionPixelSize(R.dimen.nav_key_button_shadow_offset_y);
            int radius = res.getDimensionPixelSize(R.dimen.nav_key_button_shadow_radius);
            int color = context.getColor(R.color.nav_key_button_shadow_color);
            drawable.setShadowProperties(offsetX, offsetY, radius, color);
        }
        return drawable;
    }
}

```

在draw(Canvas canvas)绘制的图标中，通过调用canvas.drawBitmap(mState.mLastDrawnIcon, null, bounds, mIconPaint);来绘制赋值给mState的图标,完成虚拟按键图标的绘制


在 KeyButtonDrawable 构造方法中，在构建ShadowDrawableState 的图标参数时，通过设置



```
mState.mBaseHeight = d.getIntrinsicHeight()*2;
mState.mBaseWidth = d.getIntrinsicWidth()*2;

```

设置当前图标的宽高，这里扩大两倍即可  
 获取图标的高度，如果修改，就可在此修改





