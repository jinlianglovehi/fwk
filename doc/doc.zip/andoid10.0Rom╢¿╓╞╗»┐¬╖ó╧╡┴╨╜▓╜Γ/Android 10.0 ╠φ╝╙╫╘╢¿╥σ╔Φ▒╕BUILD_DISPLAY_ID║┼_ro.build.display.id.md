






### 1.概述


在10.0的产品系统进行rom定制开发过程中，每个系统软件都有版本号，多个产品的时候，就需要  
 定义自己的版本号来区别每个设备型号，是在开发中经常的工作，那么改如何定制自己的版本号呢  
 首选BUILD\_DISPLAY\_ID会被存在系统属性值中，ro.product.product.id 就是他的属性值  
 而这个值会在  
 echo “ro.build.display.id=$BUILD\_DISPLAY\_ID”  
 而BUILD\_DISPLAY\_ID 会根据Makefile来设置这个值


### 2.添加自定义设备BUILD\_DISPLAY\_ID号的核心类



```
device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk

```

### 3.添加自定义设备BUILD\_DISPLAY\_ID号的核心功能分析和实现


接下来看下ro.product.product.id的定义，首选看下ums512\_2h10\_Base.mk关于对于各个系统属性值的  
 定义，然后看如何处理这个功能修改BUILD\_DISPLAY\_ID的值  
 所以我们可以先在device下对应的mk文件下添加自定义属性值 来设置新的设备名称值



```
diff --git a/device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk b/device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk
index 8c53237..4dcaead 100755 (executable)
--- a/device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk
+++ b/device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk
@@ -373,3 +373,4 @@ PRODUCT_COPY_FILES += \
 # sprd hw module
PRODUCT_PACKAGES += \
	lights.$(TARGET\_BOARD\_PLATFORM) \
	sensors.$(TARGET\_BOARD\_PLATFORM) \
	camera.$(TARGET\_BOARD\_PLATFORM) \
	dpu.$(TARGET\_BOARD\_PLATFORM) \
	gsp.$(TARGET\_BOARD\_PLATFORM) \
	tinymix \
	audio.primary.$(TARGET\_BOARD\_PLATFORM) \
        audio.bluetooth.$(TARGET\_BOARD\_PLATFORM) \
        libaudionpi \
        libaudioparamteser \
        libbundlewrapper2 \
        parameter-framework.policy \
# audio\_hardware\_test \
# power.$(TARGET\_BOARD\_PLATFORM) \
	memtrack.$(TARGET\_BOARD\_PLATFORM)

# dpu enhance module
PRODUCT_PACKAGES += \
	enhance.$(TARGET\_BOARD\_PLATFORM) \
	enhance_test

# dpu PQTune module
PRODUCT_PACKAGES += \
	PQTune.$(TARGET\_BOARD\_PLATFORM)

PRODUCT_PACKAGES += memtrack.$(TARGET\_BOARD\_PLATFORM)


#SANSA|SPRD|NONE
PRODUCT_HOST_PACKAGES += imgheaderinsert \
                         packimage.sh

PRODUCT_PACKAGES += iwnpi \
                    libiwnpi \
		    libwifieut_m3 \
                    FMRadio \
                    #libGLES\_android \
                    gralloc.$(TARGET\_BOARD\_PLATFORM)

#faceid feature
FACEID_FEATURE_SUPPORT := true
FACEID_TEE_FULL_SUPPORT := true

#app stats collect
PRODUCT_PROPERTY_OVERRIDES += persist.sys.pwctl.appstats=1
PRODUCT_PACKAGES += \
        AppStatsService

# add for validationtools disable FM
PRODUCT_PROPERTY_OVERRIDES += \
    ro.vendor.validationtools.fmdisable=1

#Display PQ 3dlut config parameters
PRODUCT_COPY_FILES += \
    $(BOARDDIR)/enhance/3d_lut.xml:vendor/etc/enhance/3d_lut.xml
 #portrait scene
 TARGET_BOARD_PORTRAIT_SCENE_SUPPORT := true
+CUSTOM_VERSION_MODEL := Sunzhi_WIFI

```

通过在ums512\_2h10\_Base.mk中增加CUSTOM\_VERSION\_MODEL := Sunzhi\_WIFI 来通过  
 CUSTOM\_VERSION\_MODEL来增加自定义产品型号的id值来区分产品  
 第二步 在Makefile中自定义BUILD\_DISPLAY\_ID的值



```
diff --git a/build/make/core/Makefile b/build/make/core/Makefile
index c86505b..643e31f 100755 (executable)
--- a/build/make/core/Makefile
+++ b/build/make/core/Makefile
@@ -378,7 +378,11 @@ else
# Set SDK\_GNU\_ERROR to non-empty to fail when a GNU target is built.
#
#SDK\_GNU\_ERROR := true

$(INTERNAL\_SDK\_TARGET): $(deps)
	@echo "Package SDK: $@"
	$(hide) rm -rf $(PRIVATE\_DIR) $@
	$(hide) for f in $(target\_gnu\_MODULES); do \
	  if [ -f $$f ]; then \
	    echo SDK: $(if $(SDK\_GNU\_ERROR),ERROR:,warning:) \
	        including GNU target $$f >&2; \
	    FAIL=$(SDK\_GNU\_ERROR); \
	  fi; \
	done; \
	if [ $$FAIL ]; then exit 1; fi
	$(hide) echo $(notdir $(SDK\_FONT\_DEPS)) | tr " " "\n"  > $(SDK\_FONT\_TEMP)/fontsInSdk.txt
	$(hide) ( \
	    ATREE\_STRIP="$(HOST\_STRIP) -x" \
	    $(HOST\_OUT\_EXECUTABLES)/atree \
	    $(addprefix -f ,$(PRIVATE\_INPUT\_FILES)) \
	        -m $(PRIVATE\_DEP\_FILE) \
	        -I . \
	        -I $(PRODUCT\_OUT) \
	        -I $(HOST\_OUT) \
	        -I $(TARGET\_COMMON\_OUT\_ROOT) \
	        -v "PLATFORM\_NAME=android-$(PLATFORM\_VERSION)" \
	        -v "OUT\_DIR=$(OUT\_DIR)" \
	        -v "HOST\_OUT=$(HOST\_OUT)" \
	        -v "TARGET\_ARCH=$(TARGET\_ARCH)" \
	        -v "TARGET\_CPU\_ABI=$(TARGET\_CPU\_ABI)" \
	        -v "DLL\_EXTENSION=$(HOST\_SHLIB\_SUFFIX)" \
	        -v "FONT\_OUT=$(SDK\_FONT\_TEMP)" \
	        -o $(PRIVATE\_DIR) && \
	    cp -f $(target\_notice\_file\_txt) \
	            $(PRIVATE\_DIR)/system-images/android-$(PLATFORM\_VERSION)/$(TARGET\_CPU\_ABI)/NOTICE.txt && \
	    cp -f $(tools\_notice\_file\_txt) $(PRIVATE\_DIR)/platform-tools/NOTICE.txt && \
	    HOST\_OUT\_EXECUTABLES=$(HOST\_OUT\_EXECUTABLES) HOST\_OS=$(HOST\_OS) \
	        development/build/tools/sdk_clean.sh $(PRIVATE\_DIR) && \
	    chmod -R ug+rwX $(PRIVATE\_DIR) && \
	    cd $(dir $@) && zip -rqX $(notdir $@) $(PRIVATE\_NAME) \
	) || ( rm -rf $(PRIVATE\_DIR) $@ && exit 44 )


# Is a Windows SDK requested? If so, we need some definitions from here
# in order to find the Linux SDK used to create the Windows one.
MAIN_SDK_NAME := $(sdk\_name)
MAIN_SDK_DIR  := $(sdk\_dir)
MAIN_SDK_ZIP  := $(INTERNAL\_SDK\_TARGET)
ifneq ($(filter win\_sdk winsdk-tools,$(MAKECMDGOALS)),)
include $(TOPDIR)development/build/tools/windows_sdk.mk
endif

# -----------------------------------------------------------------
# Findbugs
INTERNAL_FINDBUGS_XML_TARGET := $(PRODUCT\_OUT)/findbugs.xml
INTERNAL_FINDBUGS_HTML_TARGET := $(PRODUCT\_OUT)/findbugs.html
$(INTERNAL\_FINDBUGS\_XML\_TARGET): $(ALL\_FINDBUGS\_FILES)
	@echo UnionBugs: $@
	$(hide) $(FINDBUGS\_DIR)/unionBugs $(ALL\_FINDBUGS\_FILES) \
	> $@
$(INTERNAL\_FINDBUGS\_HTML\_TARGET): $(INTERNAL\_FINDBUGS\_XML\_TARGET)
	@echo ConvertXmlToText: $@
	$(hide) $(FINDBUGS\_DIR)/convertXmlToText -html:fancy.xsl \
	$(INTERNAL\_FINDBUGS\_XML\_TARGET) > $@

# -----------------------------------------------------------------
# Findbugs

# -----------------------------------------------------------------
# These are some additional build tasks that need to be run.
ifneq ($(dont\_bother),true)
include $(sort $(wildcard $(BUILD\_SYSTEM)/tasks/\*.mk))
-include $(sort $(wildcard vendor/\*/build/tasks/\*.mk))
-include $(sort $(wildcard device/\*/build/tasks/\*.mk))
-include $(sort $(wildcard product/\*/build/tasks/\*.mk))
# Also the project-specific tasks
-include $(sort $(wildcard vendor/\*/\*/build/tasks/\*.mk))
-include $(sort $(wildcard device/\*/\*/build/tasks/\*.mk))
-include $(sort $(wildcard product/\*/\*/build/tasks/\*.mk))
# Also add test specifc tasks
include $(sort $(wildcard platform\_testing/build/tasks/\*.mk))
include $(sort $(wildcard test/vts/tools/build/tasks/\*.mk))
endif

include $(BUILD\_SYSTEM)/product-graph.mk

# -----------------------------------------------------------------
# Create SDK repository packages. Must be done after tasks/\* since
# we need the addon rules defined.
ifneq ($(sdk\_repo\_goal),)
include $(TOPDIR)development/build/tools/sdk_repo.mk
endif

   # Non-user builds should show detailed build information
   BUILD_DISPLAY_ID := $(build\_desc)
 endif
-
+# add code start
+ifdef CUSTOM_VERSION_NUMBER
+  BUILD_DISPLAY_ID := $(CUSTOM\_VERSION\_MODEL)_$(shell $(DATE) +%Y%m%d)
+endif
+#add code end

```

在上述代码Makefile中通过CUSTOM\_VERSION\_MODEL来定义新的产品的 BUILD\_DISPLAY\_ID来作为产品的 BUILD\_DISPLAY\_ID  
 BUILD\_DISPLAY\_ID := KaTeX parse error: Expected group after '\_' at position 23: …\_VERSION\_MODEL)\_̲(shell $(DATE) +%Y%m%d)  
 这样就实现了对自己产品的 BUILD\_DISPLAY\_ID的定义  
 然后编译发现设备display Id值已经改变了





