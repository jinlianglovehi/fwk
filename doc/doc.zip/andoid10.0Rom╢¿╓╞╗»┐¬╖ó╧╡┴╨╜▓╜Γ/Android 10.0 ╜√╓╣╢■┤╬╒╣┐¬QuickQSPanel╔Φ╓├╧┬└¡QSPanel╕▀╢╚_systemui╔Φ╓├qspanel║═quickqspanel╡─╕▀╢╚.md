



## 1.前言


  在10.0的系统定制化需求中，在进行systemui的ui定制开发中，有些需要对原生systemui下拉状态栏中的二次展开QSPanel修改成  
 一次展开禁止二次展开，所以就需要修改QuickQSpanel的高度，然后在QuickQsPanel做定制，然后禁止二次展开就可以了


如图:


![](https://img-blog.csdnimg.cn/dc20c05e75514ccfb3b9b84b2957d4ee.png)


 


## 2.禁止二次展开QuickQSPanel设置下拉QSPanel高度的核心类



```
framework\base\packages\SystemUI\res\layout\quick_status_bar_expanded_header.xml
framework\base\packages\SystemUI\res\values\dimens.xml
framework\base\packages\SystemUI\src\com\android\systemui\qs\QuickStatusBarHeader.java
framework\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NotificationPanelView.java
```

## 3.禁止二次展开QuickQSPanel设置下拉QSPanel高度的核心功能分析和实现


SystemUI负责反馈系统及应用状态并与用户保持大量的交互,systemui中主要核心布局控件为以下部分


QSPanel 创建是从 StatusBar#makeStatusBarView 开始的


StatusBar：通知消息提示和状态展现  
 NavigationBar：返回，HOME，Recent  
 KeyGuard：锁屏模块可以看做单独的应用，提供基本的手机个人隐私保护  
 Recents：近期应用管理，以堆叠栈的形式展现。  
 Notification Panel：展示系统或应用通知内容。提供快速系统设置开关。  
 VolumeUI：来用展示或控制音量的变化：媒体音量、铃声音量与闹钟音量  
 截屏界面：长按电源键+音量下键后截屏，用以展示截取的屏幕照片/内容  
 PowerUI：主要处理和Power相关的事件，比如省电模式切换、电池电量变化和开关屏事件等。  
 RingtonePlayer：铃声播放  
 StackDivider：控制管理分屏  
 PipUI：提供对于画中画模式的管理


##  3.1 quick\_status\_bar\_expanded\_header.xml关于下拉状态栏头部布局分析



```
<com.android.systemui.qs.QuickStatusBarHeader
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/header"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_gravity="@integer/notification_panel_layout_gravity"
    android:background="@android:color/transparent"
    android:baselineAligned="false"
    android:clickable="false"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:paddingTop="0dp"
    android:paddingEnd="0dp"
    android:paddingStart="0dp"
    android:elevation="4dp" >

    <!-- The clock -->
    <include layout="@layout/quick_status_bar_header_system_icons" />

    <!-- Status icons within the panel itself (and not in the top-most status bar) -->
    <include layout="@layout/quick_qs_status_icons" />

    <!-- Layout containing tooltips, alarm text, etc. -->
    <include layout="@layout/quick_settings_header_info" />

    <com.android.systemui.qs.QuickQSPanel
        android:id="@+id/quick_qs_panel"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/quick_qs_status_icons"
        android:accessibilityTraversalAfter="@+id/date_time_group"
        android:accessibilityTraversalBefore="@id/expand_indicator"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:focusable="true"
        android:paddingBottom="10dp"
        android:importantForAccessibility="yes" />
....
```

在上述的quick\_status\_bar\_expanded\_header.xml的相关源码中，从中分析得知，在QuickStatusBarHeader  
 这个systemui下拉状态栏头部布局中，这里负责构建管理QuickQSPanel 状态栏图标等等相关布局，所以  
 可以从QuickStatusBarHeader中来设置下拉状态栏的头部布局，接下来看下  
 QuickStatusBarHeader的相关布局分析


## 3.2 QuickStatusBarHeader下拉状态栏头部布局分析



```

 public class QuickStatusBarHeader extends RelativeLayout implements
         View.OnClickListener, NextAlarmController.NextAlarmChangeCallback,
         ZenModeController.Callback {
     private static final String TAG = "QuickStatusBarHeader";
     private static final boolean DEBUG = false;

@Override
      protected void onFinishInflate() {
          super.onFinishInflate();
  
          mHeaderQsPanel = findViewById(R.id.quick_qs_panel);
          mSystemIconsView = findViewById(R.id.quick_status_bar_system_icons);
          mQuickQsStatusIcons = findViewById(R.id.quick_qs_status_icons);
          StatusIconContainer iconContainer = findViewById(R.id.statusIcons);
          iconContainer.setShouldRestrictIcons(false);
          mIconManager = new TintedIconManager(iconContainer);
  
          // Views corresponding to the header info section (e.g. ringer and next alarm).
          mHeaderTextContainerView = findViewById(R.id.header_text_container);
          mStatusSeparator = findViewById(R.id.status_separator);
          mNextAlarmIcon = findViewById(R.id.next_alarm_icon);
          mNextAlarmTextView = findViewById(R.id.next_alarm_text);
          mNextAlarmContainer = findViewById(R.id.alarm_container);
          mNextAlarmContainer.setOnClickListener(this::onClick);
          mRingerModeIcon = findViewById(R.id.ringer_mode_icon);
          mRingerModeTextView = findViewById(R.id.ringer_mode_text);
          mRingerContainer = findViewById(R.id.ringer_container);
          mCarrierGroup = findViewById(R.id.carrier_group);
  
  
          updateResources();
         ....
		}


      private void updateResources() {
          Resources resources = mContext.getResources();
          updateMinimumHeight();
  
          // Update height for a few views, especially due to landscape mode restricting space.
          mHeaderTextContainerView.getLayoutParams().height =
                  resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
          mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());
  
          mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
                  com.android.internal.R.dimen.quick_qs_offset_height);
          mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());
  
          FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
          if (mQsDisabled) {
              lp.height = resources.getDimensionPixelSize(
       -               com.android.internal.R.dimen.quick_qs_offset_height);
     +              com.android.internal.R.dimen.quick_qs_height);
          } else {
              lp.height = Math.max(getMinimumHeight(),
                      resources.getDimensionPixelSize(
        -               com.android.internal.R.dimen.quick_qs_offset_height);
     +              com.android.internal.R.dimen.quick_qs_height);
          }
  
          setLayoutParams(lp);
  
          updateStatusIconAlphaAnimator();
          updateHeaderTextContainerAlphaAnimator();
      }
```

从上述的QuickStatusBarHeader.java中的源码中分析得知，在onFinishInflate()中负责构建  
 下拉状态栏头部布局的相关源码，而在 updateResources();中负责更新相关的布局高度等参数，  
 在 updateResources();中FrameLayout.LayoutParams lp的height就是关于布局的高度，  
 所以可以在这里重新定义下拉状态栏头部的布局高度，这样就可以加高QuickQSPanel 的高度  
 在自定义QuickQSPanel 的时候 可以增加其他布局，  
 具体在framework\base\packages\SystemUI\res\values\dimens.xml中增加quick\_qs\_height的参数为:  
  



```
<resources>
    <!-- Recommended minimum clickable element dimension -->
    <dimen name="min_clickable_item_size">48dp</dimen>
 +   <dimen name="quick_qs_height">256dp</dimen>
    <!-- Amount to offset bottom of notification peek window from top of status bar. -->
    <dimen name="peek_window_y_offset">-12dp</dimen>

    <!-- thickness (height) of the navigation bar on phones that require it -->
    <dimen name="navigation_bar_size">@*android:dimen/navigation_bar_height</dimen>
    <!-- Minimum swipe distance to catch the swipe gestures to invoke assist or switch tasks. -->
    <dimen name="navigation_bar_min_swipe_distance">48dp</dimen>
    <dimen name="navigation_bar_default_edge_height">500dp</dimen>

```

## 3.3 NotificationPanelView.java中禁止展开下拉状态栏QuickQSPanel布局的相关分析


  
 在状态栏从头下拉时，直接走NotificationPanelView的onTouchEvent方法，不走拦截方法，  
 down事件经过PanelView中onTouchEvent时，mExpandedHeight = 0.0，  
 调用onTrackingStarted();  
 再调用setExpandedHeightInternal(newHeight)设置高度，走一遍onLayout方法；  
 此后move事件继续传入，走setExpandedHeightInternal(newHeight)方法。  
 一旦newHeight到达一个值后，调用setExpandedHeightInternal()方法中的setOverExpansion方法，  
 继而调用mNotificationStackScroller.setOverScrolledPixels(overExpansion, true /\* onTop \*/, false /\* animate \*/)方法，  
 从而调用setQsExpansion(mQsMinExpansionHeight + rounded)方法；



```
private void setQsExpansion(float height) {

+     // add core start
+        if (mQs != null) return;
+    //add core end

          height = Math.min(Math.max(height, mQsMinExpansionHeight), mQsMaxExpansionHeight);
          mQsFullyExpanded = height == mQsMaxExpansionHeight && mQsMaxExpansionHeight != 0;
          if (height > mQsMinExpansionHeight && !mQsExpanded && !mStackScrollerOverscrolling) {
              setQsExpanded(true);
          } else if (height <= mQsMinExpansionHeight && mQsExpanded) {
              setQsExpanded(false);
          }
          mQsExpansionHeight = height;
          updateQsExpansion();
          requestScrollerTopPaddingUpdate(false /* animate */);
          updateHeaderKeyguardAlpha();
...
          if (DEBUG) {
              invalidate();
          }
      }
```

通过上述的NotificationPanelView.java中源码中，分析得知在从状态栏头部下拉状态栏的时候，最终是由  
 setQsExpansion(float height)来负责展开QSPanel布局的，所以可以在这里禁止展开QSPanel布局，就需要  
 添加条件mQs != null 这样就可以在状态栏界面禁止下拉状态栏了



