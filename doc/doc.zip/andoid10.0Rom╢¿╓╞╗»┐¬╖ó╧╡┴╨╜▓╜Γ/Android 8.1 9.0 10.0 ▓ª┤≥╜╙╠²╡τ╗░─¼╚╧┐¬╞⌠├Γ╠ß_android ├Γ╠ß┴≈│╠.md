



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.拨打接听电话默认开启免提核心代码](#2.%E6%8B%A8%E6%89%93%E6%8E%A5%E5%90%AC%E7%94%B5%E8%AF%9D%E9%BB%98%E8%AE%A4%E5%BC%80%E5%90%AF%E5%85%8D%E6%8F%90%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.拨打接听电话默认开启免提代码分析](#3.%E6%8B%A8%E6%89%93%E6%8E%A5%E5%90%AC%E7%94%B5%E8%AF%9D%E9%BB%98%E8%AE%A4%E5%BC%80%E5%90%AF%E5%85%8D%E6%8F%90%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1通话native层 主要部分由AudioPolicyManager.cpp 处理](#3.1%E9%80%9A%E8%AF%9Dnative%E5%B1%82%20%E4%B8%BB%E8%A6%81%E9%83%A8%E5%88%86%E7%94%B1AudioPolicyManager.cpp%20%E5%A4%84%E7%90%86)


[3.2接下来看下mEngine->updateDeviceSelectionCache();](#3.2%E6%8E%A5%E4%B8%8B%E6%9D%A5%E7%9C%8B%E4%B8%8BmEngine-%3EupdateDeviceSelectionCache%28%29%3B)


[4.拨打接听电话默认开启免提功能实现](#4.%E6%8B%A8%E6%89%93%E6%8E%A5%E5%90%AC%E7%94%B5%E8%AF%9D%E9%BB%98%E8%AE%A4%E5%BC%80%E5%90%AF%E5%85%8D%E6%8F%90%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)




---



## 1.概述


在原生系统中，接听电话都是默认关闭免提的，由于开发功能性产品的需要，有需求要求接电话开启免提，这要从整个接电话流程分析


## 2.拨打接听电话默认开启免提核心代码



```
主要代码如下:
framework/av/services/audiopolicy/managerdefault/AudioPolicyManager.cpp
framework/av/services/audiopolicy/enginedefault/src/Engine.cpp
```

## 3.拨打接听电话默认开启免提代码分析


#### 3.1通话native层 主要部分由AudioPolicyManager.cpp 处理



```
路径:framework/av/services/audiopolicy/managerdefault/AudioPolicyManager.cpp
处理流程:
AudioSystem::setForceUse--AudioPolicyService::setForceUse（AudioPolicyInterfaceImpl.cpp）--AudioPolicyManager::setForceUse
void AudioPolicyManager::setForceUse(audio_policy_force_use_t usage,
audio_policy_forced_cfg_t config)
{
audio_devices_t prev_device;
audio_devices_t device;
ALOGI("setForceUse() usage %d, config %d, mPhoneState %d", usage, config, mEngine->getPhoneState());
if (config == mEngine->getForceUse(usage)) {
    return;
}
prev_device = getDevicesForStream(AUDIO_STREAM_MUSIC);
if (mEngine->setForceUse(usage, config) != NO_ERROR) {
    ALOGW("setForceUse() could not set force cfg %d for usage %d", config, usage);
    return;
}
device = getDevicesForStream(AUDIO_STREAM_MUSIC);
if (usage == AUDIO_POLICY_FORCE_FOR_COMMUNICATION &&
    config == AUDIO_POLICY_FORCE_BT_SCO &&
    prev_device == AUDIO_DEVICE_OUT_BLUETOOTH_A2DP &&
    device == AUDIO_DEVICE_OUT_BLUETOOTH_SCO_HEADSET &&
    isStreamActive(AUDIO_STREAM_MUSIC, 0)) {
    setStrategyMute(streamToStrategy(AUDIO_STREAM_MUSIC), true, mPrimaryOutput);
    setStrategyMute(streamToStrategy(AUDIO_STREAM_MUSIC), false, mPrimaryOutput,
                    A2DP_TO_SCO_MUSIC_MUTE_TIME_MS,
                    AUDIO_DEVICE_OUT_BLUETOOTH_SCO_HEADSET);
}

#ifdef SPRD_CUSTOM_AUDIO_POLICY
if(AUDIO_POLICY_FORCE_FOR_FM == usage) {
AudioParameter outputCmd = AudioParameter();
if(AUDIO_POLICY_FORCE_SPEAKER == config) {
outputCmd.addInt(String8("set_fm_speaker"),1);
}
else {
outputCmd.addInt(String8("set_fm_speaker"),0);
}
mpClientInterface->setParameters(0, outputCmd.toString());
}
#endif
bool forceVolumeReeval = (usage == AUDIO_POLICY_FORCE_FOR_COMMUNICATION) ||
(usage == AUDIO_POLICY_FORCE_FOR_DOCK) ||
(usage == AUDIO_POLICY_FORCE_FOR_SYSTEM);
// check for device and output changes triggered by new force usage
checkForDeviceAndOutputChanges();

// force client reconnection to reevaluate flag AUDIO_FLAG_AUDIBILITY_ENFORCED
if (usage == AUDIO_POLICY_FORCE_FOR_SYSTEM) {
    mpClientInterface->invalidateStream(AUDIO_STREAM_SYSTEM);
    mpClientInterface->invalidateStream(AUDIO_STREAM_ENFORCED_AUDIBLE);
}

//FIXME: workaround for truncated touch sounds
// to be removed when the problem is handled by system UI
uint32_t delayMs = 0;
uint32_t waitMs = 0;
if (usage == AUDIO_POLICY_FORCE_FOR_COMMUNICATION) {
    delayMs = TOUCH_SOUND_FIXED_DELAY_MS;
}
if (mEngine->getPhoneState() == AUDIO_MODE_IN_CALL && hasPrimaryOutput()) {
    DeviceVector newDevices = getNewOutputDevices(mPrimaryOutput, true /*fromCache*/);
    waitMs = updateCallRouting(newDevices, delayMs);
}
for (size_t i = 0; i < mOutputs.size(); i++) {
    sp<SwAudioOutputDescriptor> outputDesc = mOutputs.valueAt(i);
    DeviceVector newDevices = getNewOutputDevices(outputDesc, true /*fromCache*/);
    if ((mEngine->getPhoneState() != AUDIO_MODE_IN_CALL) || (outputDesc != mPrimaryOutput)) {
        // As done in setDeviceConnectionState, we could also fix default device issue by
        // preventing the force re-routing in case of default dev that distinguishes on address.
        // Let's give back to engine full device choice decision however.
        waitMs = setOutputDevices(outputDesc, newDevices, !newDevices.isEmpty(), delayMs);
    }
    if (forceVolumeReeval && !newDevices.isEmpty()) {
        applyStreamVolumes(outputDesc, newDevices.types(), waitMs, true);
    }
}

for (const auto& activeDesc : mInputs.getActiveInputs()) {
    auto newDevice = getNewInputDevice(activeDesc);
    // Force new input selection if the new device can not be reached via current input
    if (activeDesc->mProfile->getSupportedDevices().contains(newDevice)) {
        setInputDevice(activeDesc->mIoHandle, newDevice);
    } else {
        closeInput(activeDesc->mIoHandle);
    }
}

}
void AudioPolicyManager::checkForDeviceAndOutputChanges(std::function<bool()> onOutputsChecked)
{
// checkA2dpSuspend must run before checkOutputForAllStrategies so that A2DP
// output is suspended before any tracks are moved to it
checkA2dpSuspend();
checkOutputForAllStrategies();
checkSecondaryOutputs();
if (onOutputsChecked != nullptr && onOutputsChecked()) checkA2dpSuspend();
updateDevicesAndOutputs();
if (mHwModules.getModuleFromName(AUDIO_HARDWARE_MODULE_ID_MSD) != 0) {
setMsdPatch();
}
}
void AudioPolicyManager::updateDevicesAndOutputs()
{
mEngine->updateDeviceSelectionCache();
mPreviousOutputs = mOutputs;
}
```

#### 3.2接下来看下mEngine->updateDeviceSelectionCache();



```
路径:framework/av/services/audiopolicy/enginedefault/src/Engine.cpp
void Engine::updateDeviceSelectionCache()
{
for (const auto &iter : getProductStrategies()) {
const auto &strategy = iter.second;
auto devices = getDevicesForProductStrategy(strategy->getId());
mDevicesForStrategies[strategy->getId()] = devices;
strategy->setDeviceTypes(devices.types());
strategy->setDeviceAddress(devices.getFirstValidAddress().c_str());
}
}
DeviceVector Engine::getDevicesForProductStrategy(product_strategy_t strategy, UNUSED_ATTR bool ignoreFM) const
{
DeviceVector availableOutputDevices = getApmObserver()->getAvailableOutputDevices();
DeviceVector availableInputDevices = getApmObserver()->getAvailableInputDevices();
const SwAudioOutputCollection &outputs = getApmObserver()->getOutputs();
auto legacyStrategy = mLegacyStrategyMap.find(strategy) != end(mLegacyStrategyMap) ?
            mLegacyStrategyMap.at(strategy) : STRATEGY_NONE;
audio_devices_t devices = getDeviceForStrategyInt(legacyStrategy,
                                                  availableOutputDevices,
                                                  availableInputDevices, outputs,
                                                  (uint32_t)AUDIO_DEVICE_NONE);
return availableOutputDevices.getDevicesFromTypeMask(devices);

}
audio_devices_t Engine::getDeviceForStrategyInt(legacy_strategy strategy,
DeviceVector availableOutputDevices,
DeviceVector availableInputDevices,
const SwAudioOutputCollection &outputs,
uint32_t outputDeviceTypesToIgnore) const
{
uint32_t device = AUDIO_DEVICE_NONE;
uint32_t availableOutputDevicesType =
availableOutputDevices.types() & ~outputDeviceTypesToIgnore;
switch (strategy) {

case STRATEGY_TRANSMITTED_THROUGH_SPEAKER:
    device = availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER;
    break;

case STRATEGY_SONIFICATION_RESPECTFUL:
    if (isInCall() || outputs.isActiveLocally(toVolumeSource(AUDIO_STREAM_VOICE_CALL))) {
        device = getDeviceForStrategyInt(
                STRATEGY_SONIFICATION, availableOutputDevices, availableInputDevices, outputs,
                outputDeviceTypesToIgnore);
    } else {
        bool media_active_locally =
                outputs.isActiveLocally(toVolumeSource(AUDIO_STREAM_MUSIC),
                                        SONIFICATION_RESPECTFUL_AFTER_MUSIC_DELAY)
                || outputs.isActiveLocally(
                    toVolumeSource(AUDIO_STREAM_ACCESSIBILITY),
                    SONIFICATION_RESPECTFUL_AFTER_MUSIC_DELAY);
        // routing is same as media without the "remote" device
        device = getDeviceForStrategyInt(STRATEGY_MEDIA,
                availableOutputDevices,
                availableInputDevices, outputs,
                AUDIO_DEVICE_OUT_REMOTE_SUBMIX | outputDeviceTypesToIgnore);
        // if no media is playing on the device, check for mandatory use of "safe" speaker
        // when media would have played on speaker, and the safe speaker path is available
        if (!media_active_locally
                && (device & AUDIO_DEVICE_OUT_SPEAKER)
                && (availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER_SAFE)) {
            device |= AUDIO_DEVICE_OUT_SPEAKER_SAFE;
            device &= ~AUDIO_DEVICE_OUT_SPEAKER;
        }
    }
    break;

case STRATEGY_DTMF:
    if (!isInCall()) {
        // when off call, DTMF strategy follows the same rules as MEDIA strategy
        device = getDeviceForStrategyInt(
                STRATEGY_MEDIA, availableOutputDevices, availableInputDevices, outputs,
                outputDeviceTypesToIgnore);
        break;
    }
    // when in call, DTMF and PHONE strategies follow the same rules
    FALLTHROUGH_INTENDED;

case STRATEGY_PHONE:
    // Force use of only devices on primary output if:
    // - in call AND
    //   - cannot route from voice call RX OR
    //   - audio HAL version is < 3.0 and TX device is on the primary HW module
    if (getPhoneState() == AUDIO_MODE_IN_CALL) {
        audio_devices_t txDevice = getDeviceForInputSource(AUDIO_SOURCE_VOICE_COMMUNICATION);
        sp<AudioOutputDescriptor> primaryOutput = outputs.getPrimaryOutput();
        audio_devices_t availPrimaryInputDevices =
             availableInputDevices.getDeviceTypesFromHwModule(primaryOutput->getModuleHandle());

        // TODO: getPrimaryOutput return only devices from first module in
        // audio_policy_configuration.xml, hearing aid is not there, but it's
        // a primary device
        // FIXME: this is not the right way of solving this problem
        audio_devices_t availPrimaryOutputDevices =
            (primaryOutput->supportedDevices().types() | AUDIO_DEVICE_OUT_HEARING_AID) &
            availableOutputDevices.types();

        if (((availableInputDevices.types() &
                AUDIO_DEVICE_IN_TELEPHONY_RX & ~AUDIO_DEVICE_BIT_IN) == 0) ||
                (((txDevice & availPrimaryInputDevices & ~AUDIO_DEVICE_BIT_IN) != 0) &&
                     (primaryOutput->getAudioPort()->getModuleVersionMajor() < 3))) {
            availableOutputDevicesType = availPrimaryOutputDevices;
        }
    }
    // for phone strategy, we first consider the forced use and then the available devices by
    // order of priority
    switch (getForceUse(AUDIO_POLICY_FORCE_FOR_COMMUNICATION)) {
    case AUDIO_POLICY_FORCE_BT_SCO:
        if (!isInCall() || strategy != STRATEGY_DTMF) {
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_SCO_CARKIT;
            if (device) break;
        }
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_SCO_HEADSET;
        if (device) break;
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_SCO;
        if (device) break;
        // if SCO device is requested but no SCO device is available, fall back to default case
        FALLTHROUGH_INTENDED;

    default:    // FORCE_NONE
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_HEARING_AID;
        if (device) break;
        // when not in a phone call, phone strategy should route STREAM_VOICE_CALL to A2DP
        if (!isInCall() &&
                (getForceUse(AUDIO_POLICY_FORCE_FOR_MEDIA) != AUDIO_POLICY_FORCE_NO_BT_A2DP) &&
                 outputs.isA2dpSupported()) {
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES;
            if (device) break;
        }
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_WIRED_HEADPHONE;
        if (device) break;
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_WIRED_HEADSET;
        if (device) break;
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_LINE;
        if (device) break;
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_HEADSET;
        if (device) break;
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_DEVICE;
        if (device) break;
        if (!isInCall()) {
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_ACCESSORY;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_DGTL_DOCK_HEADSET;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_AUX_DIGITAL;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_ANLG_DOCK_HEADSET;
            if (device) break;
        }
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_EARPIECE;
        break;

    case AUDIO_POLICY_FORCE_SPEAKER:
        // when not in a phone call, phone strategy should route STREAM_VOICE_CALL to
        // A2DP speaker when forcing to speaker output
        if (!isInCall() &&
                (getForceUse(AUDIO_POLICY_FORCE_FOR_MEDIA) != AUDIO_POLICY_FORCE_NO_BT_A2DP) &&
                 outputs.isA2dpSupported()) {
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER;
            if (device) break;
        }
        if (!isInCall()) {
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_ACCESSORY;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_DEVICE;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_DGTL_DOCK_HEADSET;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_AUX_DIGITAL;
            if (device) break;
            device = availableOutputDevicesType & AUDIO_DEVICE_OUT_ANLG_DOCK_HEADSET;
            if (device) break;
        }
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER;
        break;
    }
break;

case STRATEGY_SONIFICATION:

    // If incall, just select the STRATEGY_PHONE device
    if (isInCall() ||
            outputs.isActiveLocally(toVolumeSource(AUDIO_STREAM_VOICE_CALL))) {
        device = getDeviceForStrategyInt(
                STRATEGY_PHONE, availableOutputDevices, availableInputDevices, outputs,
                outputDeviceTypesToIgnore);
        break;
    }
    FALLTHROUGH_INTENDED;

case STRATEGY_ENFORCED_AUDIBLE:
    // strategy STRATEGY_ENFORCED_AUDIBLE uses same routing policy as STRATEGY_SONIFICATION
    // except:
    //   - when in call where it doesn't default to STRATEGY_PHONE behavior
    //   - in countries where not enforced in which case it follows STRATEGY_MEDIA

    if ((strategy == STRATEGY_SONIFICATION) ||
            (getForceUse(AUDIO_POLICY_FORCE_FOR_SYSTEM) == AUDIO_POLICY_FORCE_SYSTEM_ENFORCED)) {
        device = availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER;
    }

    // if SCO headset is connected and we are told to use it, play ringtone over
    // speaker and BT SCO
    if ((availableOutputDevicesType & AUDIO_DEVICE_OUT_ALL_SCO) != 0) {
        uint32_t device2 = AUDIO_DEVICE_NONE;
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_SCO_CARKIT;
        if (device2 == AUDIO_DEVICE_NONE) {
            device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_SCO_HEADSET;
        }
        if (device2 == AUDIO_DEVICE_NONE) {
            device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_SCO;
        }
        // Use ONLY Bluetooth SCO output when ringing in vibration mode
        if (!((getForceUse(AUDIO_POLICY_FORCE_FOR_SYSTEM) == AUDIO_POLICY_FORCE_SYSTEM_ENFORCED)
                && (strategy == STRATEGY_ENFORCED_AUDIBLE))) {
            if (getForceUse(AUDIO_POLICY_FORCE_FOR_VIBRATE_RINGING)
                    == AUDIO_POLICY_FORCE_BT_SCO) {
                if (device2 != AUDIO_DEVICE_NONE) {
                    device = device2;
                    break;
                }
            }
        }
        // Use both Bluetooth SCO and phone default output when ringing in normal mode
        if (getForceUse(AUDIO_POLICY_FORCE_FOR_COMMUNICATION) == AUDIO_POLICY_FORCE_BT_SCO) {
            if ((strategy == STRATEGY_SONIFICATION) &&
                    (device & AUDIO_DEVICE_OUT_SPEAKER) &&
                    (availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER_SAFE)) {
                device |= AUDIO_DEVICE_OUT_SPEAKER_SAFE;
                device &= ~AUDIO_DEVICE_OUT_SPEAKER;
            }
            if (device2 != AUDIO_DEVICE_NONE) {
                device |= device2;
                break;
            }
        }
    }
    // The second device used for sonification is the same as the device used by media strategy
    FALLTHROUGH_INTENDED;

case STRATEGY_ACCESSIBILITY:
    if (strategy == STRATEGY_ACCESSIBILITY) {
        // do not route accessibility prompts to a digital output currently configured with a
        // compressed format as they would likely not be mixed and dropped.
        for (size_t i = 0; i < outputs.size(); i++) {
            sp<AudioOutputDescriptor> desc = outputs.valueAt(i);
            audio_devices_t devices = desc->devices().types() &
                (AUDIO_DEVICE_OUT_HDMI | AUDIO_DEVICE_OUT_SPDIF | AUDIO_DEVICE_OUT_HDMI_ARC);
            if (desc->isActive() && !audio_is_linear_pcm(desc->mFormat) &&
                    devices != AUDIO_DEVICE_NONE) {
                availableOutputDevicesType = availableOutputDevices.types() & ~devices;
            }
        }
        availableOutputDevices =
                availableOutputDevices.getDevicesFromTypeMask(availableOutputDevicesType);
        if (outputs.isActive(toVolumeSource(AUDIO_STREAM_RING)) ||
                outputs.isActive(toVolumeSource(AUDIO_STREAM_ALARM))) {
            return getDeviceForStrategyInt(
                STRATEGY_SONIFICATION, availableOutputDevices, availableInputDevices, outputs,
                outputDeviceTypesToIgnore);
        }
        if (isInCall()) {
            return getDeviceForStrategyInt(
                    STRATEGY_PHONE, availableOutputDevices, availableInputDevices, outputs,
                    outputDeviceTypesToIgnore);
        }
    }
    // For other cases, STRATEGY_ACCESSIBILITY behaves like STRATEGY_MEDIA
    FALLTHROUGH_INTENDED;

// FIXME: STRATEGY_REROUTING follow STRATEGY_MEDIA for now
case STRATEGY_REROUTING:
case STRATEGY_MEDIA: {
    uint32_t device2 = AUDIO_DEVICE_NONE;
    if (strategy != STRATEGY_SONIFICATION) {
        // no sonification on remote submix (e.g. WFD)
        if (availableOutputDevices.getDevice(AUDIO_DEVICE_OUT_REMOTE_SUBMIX,
                                             String8("0"), AUDIO_FORMAT_DEFAULT) != 0) {
            device2 = availableOutputDevices.types() & AUDIO_DEVICE_OUT_REMOTE_SUBMIX;
        }
    }
    if (isInCall() && (strategy == STRATEGY_MEDIA)) {
        device = getDeviceForStrategyInt(
                STRATEGY_PHONE, availableOutputDevices, availableInputDevices, outputs,
                outputDeviceTypesToIgnore);
        break;
    }
    // FIXME: Find a better solution to prevent routing to BT hearing aid(b/122931261).
    if ((device2 == AUDIO_DEVICE_NONE) &&
            (getForceUse(AUDIO_POLICY_FORCE_FOR_MEDIA) != AUDIO_POLICY_FORCE_NO_BT_A2DP)) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_HEARING_AID;
    }
    if ((device2 == AUDIO_DEVICE_NONE) &&
            (getForceUse(AUDIO_POLICY_FORCE_FOR_MEDIA) != AUDIO_POLICY_FORCE_NO_BT_A2DP) &&
             outputs.isA2dpSupported()) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP;
        if (device2 == AUDIO_DEVICE_NONE) {
            device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES;
        }
        if (device2 == AUDIO_DEVICE_NONE) {
            device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER;
        }
    }
    if ((device2 == AUDIO_DEVICE_NONE) &&
        (getForceUse(AUDIO_POLICY_FORCE_FOR_MEDIA) == AUDIO_POLICY_FORCE_SPEAKER)) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_WIRED_HEADPHONE;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_LINE;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_WIRED_HEADSET;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_HEADSET;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_ACCESSORY;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_DEVICE;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_DGTL_DOCK_HEADSET;
    }
    if ((device2 == AUDIO_DEVICE_NONE) && (strategy != STRATEGY_SONIFICATION)) {
        // no sonification on aux digital (e.g. HDMI)
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_AUX_DIGITAL;
    }
    if ((device2 == AUDIO_DEVICE_NONE) &&
            (getForceUse(AUDIO_POLICY_FORCE_FOR_DOCK) == AUDIO_POLICY_FORCE_ANALOG_DOCK)) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_ANLG_DOCK_HEADSET;
    }
    if (device2 == AUDIO_DEVICE_NONE) {
        device2 = availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER;
    }
    int device3 = AUDIO_DEVICE_NONE;
    if (strategy == STRATEGY_MEDIA) {
        // ARC, SPDIF and AUX_LINE can co-exist with others.
        device3 = availableOutputDevicesType & AUDIO_DEVICE_OUT_HDMI_ARC;
        device3 |= (availableOutputDevicesType & AUDIO_DEVICE_OUT_SPDIF);
        device3 |= (availableOutputDevicesType & AUDIO_DEVICE_OUT_AUX_LINE);
    }

    device2 |= device3;
    // device is DEVICE_OUT_SPEAKER if we come from case STRATEGY_SONIFICATION or
    // STRATEGY_ENFORCED_AUDIBLE, AUDIO_DEVICE_NONE otherwise
    device |= device2;

    // If hdmi system audio mode is on, remove speaker out of output list.
    if ((strategy == STRATEGY_MEDIA) &&
        (getForceUse(AUDIO_POLICY_FORCE_FOR_HDMI_SYSTEM_AUDIO) ==
            AUDIO_POLICY_FORCE_HDMI_SYSTEM_AUDIO_ENFORCED)) {
        device &= ~AUDIO_DEVICE_OUT_SPEAKER;
    }

    // for STRATEGY_SONIFICATION:
    // if SPEAKER was selected, and SPEAKER_SAFE is available, use SPEAKER_SAFE instead
    if ((strategy == STRATEGY_SONIFICATION) &&
            (device & AUDIO_DEVICE_OUT_SPEAKER) &&
            (availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER_SAFE)) {
        device |= AUDIO_DEVICE_OUT_SPEAKER_SAFE;
        device &= ~AUDIO_DEVICE_OUT_SPEAKER;
    }
    } break;

default:
    ALOGW("getDeviceForStrategy() unknown strategy: %d", strategy);
    break;
}

if (device == AUDIO_DEVICE_NONE) {
    ALOGV("getDeviceForStrategy() no device found for strategy %d", strategy);
    device = getApmObserver()->getDefaultOutputDevice()->type();
    ALOGE_IF(device == AUDIO_DEVICE_NONE,
             "getDeviceForStrategy() no default device defined");
}
ALOGVV("getDeviceForStrategy() strategy %d, device %x", strategy, device);
return device;

}
getDeviceForStrategyInt()处理听筒的输出方式
```

## 4.拨打接听电话默认开启免提功能实现



```
audio_devices_t Engine::getDeviceForStrategyInt(legacy_strategy strategy,
                                                 DeviceVector availableOutputDevices,
                                                  DeviceVector availableInputDevices,
                                                 const SwAudioOutputCollection &outputs,
                                                  uint32_t outputDeviceTypesToIgnore) const
.....
default:    // FORCE_NONE
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_HEARING_AID;
if (device) break;
// when not in a phone call, phone strategy should route STREAM_VOICE_CALL to A2DP
if (!isInCall() &&
(getForceUse(AUDIO_POLICY_FORCE_FOR_MEDIA) != AUDIO_POLICY_FORCE_NO_BT_A2DP) &&
outputs.isA2dpSupported()) {
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES;
if (device) break;
}
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_WIRED_HEADPHONE;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_WIRED_HEADSET;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_LINE;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_HEADSET;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_DEVICE;
if (device) break;
if (!isInCall()) {
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_USB_ACCESSORY;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_DGTL_DOCK_HEADSET;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_AUX_DIGITAL;
if (device) break;
device = availableOutputDevicesType & AUDIO_DEVICE_OUT_ANLG_DOCK_HEADSET;
if (device) break;
}
- device = availableOutputDevicesType & AUDIO_DEVICE_OUT_EARPIECE;
+ device = availableOutputDevicesType & AUDIO_DEVICE_OUT_SPEAKER;
break;
...
}
```




