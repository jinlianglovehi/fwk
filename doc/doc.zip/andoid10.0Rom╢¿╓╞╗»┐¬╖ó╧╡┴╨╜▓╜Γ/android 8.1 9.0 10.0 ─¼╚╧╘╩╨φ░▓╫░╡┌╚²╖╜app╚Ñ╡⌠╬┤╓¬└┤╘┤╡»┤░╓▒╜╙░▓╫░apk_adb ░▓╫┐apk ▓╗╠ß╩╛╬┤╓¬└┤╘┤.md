



## １.概述


在１０.０的产品开发中，8.0以后对于安装第三方app时需要申请 REQUEST\_INSTALL\_PACKAGES权限,那么没有申请权限时就会弹出 安装未知来源的对话框，而在定制化开发中，有需求要求允许安装apk时，去掉未知来源弹窗的功能


## 2.默认允许安装第三方app去掉未知来源弹窗直接安装apk的核心类



```
frameworks/base/packages/PackageInstaller/src/com/android/packageinstaller/PackageInstallerActivity.java
```

## 3.默认允许安装第三方app去掉未知来源弹窗直接安装apk核心功能分析和实现


功能分析:


在安装第三方app时弹窗时，在弹出未知来源时，通过adb shell命令发现弹窗页面就是PackageInstallerActivity.java，需要去掉弹窗，就要对相关源码做分析然后做修改


首先来看 PackageInstallerActivity.java 源码



```
      @Override
      protected void onCreate(Bundle icicle) {
          getWindow().addSystemFlags(SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS);
  
          super.onCreate(null);
  
          if (icicle != null) {
              mAllowUnknownSources = icicle.getBoolean(ALLOW_UNKNOWN_SOURCES_KEY);
          }
  
          mPm = getPackageManager();
          mIpm = AppGlobals.getPackageManager();
          mAppOpsManager = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
          mInstaller = mPm.getPackageInstaller();
          mUserManager = (UserManager) getSystemService(Context.USER_SERVICE);
  
          final Intent intent = getIntent();
  
          mCallingPackage = intent.getStringExtra(EXTRA_CALLING_PACKAGE);
          mSourceInfo = intent.getParcelableExtra(EXTRA_ORIGINAL_SOURCE_INFO);
          mOriginatingUid = intent.getIntExtra(Intent.EXTRA_ORIGINATING_UID,
                  PackageInstaller.SessionParams.UID_UNKNOWN);
          mOriginatingPackage = (mOriginatingUid != PackageInstaller.SessionParams.UID_UNKNOWN)
                  ? getPackageNameForUid(mOriginatingUid) : null;
  
  
          final Uri packageUri;
  
          if (PackageInstaller.ACTION_CONFIRM_INSTALL.equals(intent.getAction())) {
              final int sessionId = intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1);
              final PackageInstaller.SessionInfo info = mInstaller.getSessionInfo(sessionId);
              if (info == null || !info.sealed || info.resolvedBaseCodePath == null) {
                  Log.w(TAG, "Session " + mSessionId + " in funky state; ignoring");
                  finish();
                  return;
              }
  
              mSessionId = sessionId;
              packageUri = Uri.fromFile(new File(info.resolvedBaseCodePath));
              mOriginatingURI = null;
              mReferrerURI = null;
          } else {
              mSessionId = -1;
              packageUri = intent.getData();
              mOriginatingURI = intent.getParcelableExtra(Intent.EXTRA_ORIGINATING_URI);
              mReferrerURI = intent.getParcelableExtra(Intent.EXTRA_REFERRER);
          }
  
          // if there's nothing to do, quietly slip into the ether
          if (packageUri == null) {
              Log.w(TAG, "Unspecified source");
              setPmResult(PackageManager.INSTALL_FAILED_INVALID_URI);
              finish();
              return;
          }
  
          if (DeviceUtils.isWear(this)) {
              showDialogInner(DLG_NOT_SUPPORTED_ON_WEAR);
              return;
          }
  
          boolean wasSetUp = processPackageUri(packageUri);
          if (!wasSetUp) {
              return;
          }
  
          // load dummy layout with OK button disabled until we override this layout in
          // startInstallConfirm
          bindUi();
          checkIfAllowedAndInitiateInstall();
      }
  
private void handleUnknownSources() {
        if (mOriginatingPackage == null) {
            Log.i(TAG, "No source found for package " + mPkgInfo.packageName);
            showDialogInner(DLG_ANONYMOUS_SOURCE);
            return;
        }
        // Shouldn't use static constant directly, see b/65534401.
        final int appOpCode =
                AppOpsManager.permissionToOpCode(Manifest.permission.REQUEST_INSTALL_PACKAGES);
        final int appOpMode = mAppOpsManager.noteOpNoThrow(appOpCode,
                mOriginatingUid, mOriginatingPackage);
        switch (appOpMode) {
            case AppOpsManager.MODE_DEFAULT:
                mAppOpsManager.setMode(appOpCode, mOriginatingUid,
                        mOriginatingPackage, AppOpsManager.MODE_ERRORED);
                // fall through
            case AppOpsManager.MODE_ERRORED:
                showDialogInner(DLG_EXTERNAL_SOURCE_BLOCKED);
                break;
            case AppOpsManager.MODE_ALLOWED:
                initiateInstall();
                break;
            default:
                Log.e(TAG, "Invalid app op mode " + appOpMode
                        + " for OP_REQUEST_INSTALL_PACKAGES found for uid " + mOriginatingUid);
                finish();
                break;
        }
    }
```

在安装第三方app时，首先会调用PackageInstallerActivity.java进行安装，在进入onCreate方法中首先会调用handleUnknownSources()检测是否由权限，而在判断mOriginatingPackage是否为空这个值在onCreate方法是为空的，所以会进入showDialogInner(int id)方法，


接下来看下showDialogInner(int id)；



```
    /**
     * Replace any dialog shown by the dialog with the one for the given {@link #createDialog id}.
     *
     * @param id The dialog type to add
     */
    private void showDialogInner(int id) {
        DialogFragment currentDialog =
                (DialogFragment) getFragmentManager().findFragmentByTag("dialog");
        if (currentDialog != null) {
            currentDialog.dismissAllowingStateLoss();
        }

        DialogFragment newDialog = createDialog(id);
        if (newDialog != null) {
            newDialog.showAllowingStateLoss(getFragmentManager(), "dialog");
        }
    }
```

在showDialogInner(int id)中会继续调用createDialog()进行弹窗


接下来看createDialog();



```
 /**
     * Create a new dialog.
     *
     * @param id The id of the dialog (determines dialog type)
     *
     * @return The dialog
     */
    private DialogFragment createDialog(int id) {
        switch (id) {
            case DLG_PACKAGE_ERROR:
                return SimpleErrorDialog.newInstance(R.string.Parse_error_dlg_text);
            case DLG_OUT_OF_SPACE:
                return OutOfSpaceDialog.newInstance(
                        mPm.getApplicationLabel(mPkgInfo.applicationInfo));
            case DLG_INSTALL_ERROR:
                return InstallErrorDialog.newInstance(
                        mPm.getApplicationLabel(mPkgInfo.applicationInfo));
            case DLG_NOT_SUPPORTED_ON_WEAR:
                return NotSupportedOnWearDialog.newInstance();
            case DLG_INSTALL_APPS_RESTRICTED_FOR_USER:
                return SimpleErrorDialog.newInstance(
                        R.string.install_apps_user_restriction_dlg_text);
            case DLG_UNKNOWN_SOURCES_RESTRICTED_FOR_USER:
                return SimpleErrorDialog.newInstance(
                        R.string.unknown_apps_user_restriction_dlg_text);
            case DLG_EXTERNAL_SOURCE_BLOCKED:
                return ExternalSourcesBlockedDialog.newInstance(mOriginatingPackage);
            case DLG_ANONYMOUS_SOURCE:
                       return AnonymousSourceDialog.newInstance();
			     break;
        }
        return null;
    }
```

从createDialog()这里可以看出 DLG\_ANONYMOUS\_SOURCE的类型时


调用AnonymousSourceDialog的代码产生未知来源弹窗


2.AnonymousSourceDialog 关于未知来源弹窗的分析




```
/**
     * Dialog to show when the source of apk can not be identified
     */
    public static class AnonymousSourceDialog extends DialogFragment {
        static AnonymousSourceDialog newInstance() {
            return new AnonymousSourceDialog();
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            return new AlertDialog.Builder(getActivity())
                    .setMessage(R.string.anonymous_source_warning)
                    .setPositiveButton(R.string.anonymous_source_continue,
                            ((dialog, which) -> {
                            //当点击继续按钮时就行执行下面代码
                                PackageInstallerActivity activity = ((PackageInstallerActivity)
                                        getActivity());

                                //UNISOC 1199312 crash with NullPointerException
                                if(null != activity) {
                                    activity.mAllowUnknownSources = true;
                                   //安装apk
                                   activity.initiateInstall();
                                }
                            }))
                    .setNegativeButton(R.string.cancel, ((dialog, which) -> dialogFinsih()))
                    .create();
        }

        @Override
        public void onCancel(DialogInterface dialog) {
            dialogFinsih();
        }

        //UNISOC 1203078 crash with NullPointerException
        private void dialogFinsih(){
            try {
                getActivity().finish();
            } catch (Exception e) {
                Log.e(TAG, "father activity is destoryed "+ e);
            }
        }
    }
```

经过相关源码的分析发现这里就是未知来源的弹窗，然后点击确定可以继续安装第三方app,所以可以在createDialog()中弹窗的时候不调用AnonymousSourceDialog而是直接安装第三方app就可以了


解决方案如下:



```
--- a/frameworks/base/packages/PackageInstaller/src/com/android/packageinstaller/PackageInstallerActivity.java
+++ b/frameworks/base/packages/PackageInstaller/src/com/android/packageinstaller/PackageInstallerActivity.java
@@ -183,7 +183,10 @@ public class PackageInstallerActivity extends AlertActivity {
             case DLG_EXTERNAL_SOURCE_BLOCKED:
                 return ExternalSourcesBlockedDialog.newInstance(mOriginatingPackage);
             case DLG_ANONYMOUS_SOURCE:
                //当有未知来源apk安装是就会弹出AnonymousSourceDialog对话框
-                return AnonymousSourceDialog.newInstance();
+                mAllowUnknownSources = true;
+                 initiateInstall();
+                            break;
+                //return AnonymousSourceDialog.newInstance();
         }
         return null;
     }

```


