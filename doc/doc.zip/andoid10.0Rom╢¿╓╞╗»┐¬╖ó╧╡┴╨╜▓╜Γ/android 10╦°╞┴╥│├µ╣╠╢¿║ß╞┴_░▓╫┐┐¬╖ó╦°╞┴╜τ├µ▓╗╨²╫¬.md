






### １.概述


在１０.０的系统产品开发中，对于产品需求中，锁屏页面的需求要求在锁屏页面固定横屏，所以就需要从锁屏页面旋转方向入手来设置旋转方向来做固定横屏处理


### ２.锁屏页面固定横屏的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarWindowController.java

```

### ３.锁屏页面固定横屏的核心功能分析和实现


接下来看下在StatusBarWindowController 中分析锁屏页面的屏幕旋转的  
 源码分析



```
  public class StatusBarWindowController implements Callback, Dumpable, ConfigurationListener {
    @Inject
     public StatusBarWindowController(Context context) {
         this(context, context.getSystemService(WindowManager.class), ActivityManager.getService(),
                 DozeParameters.getInstance(context));
     }
 
     @VisibleForTesting
     public StatusBarWindowController(Context context, WindowManager windowManager,
             IActivityManager activityManager, DozeParameters dozeParameters) {
         mContext = context;
          mWindowManager = windowManager;
          mActivityManager = activityManager;
          mKeyguardScreenRotation = shouldEnableKeyguardScreenRotation();
          mDozeParameters = dozeParameters;
          mScreenBrightnessDoze = mDozeParameters.getScreenBrightnessDoze();
          mLpChanged = new WindowManager.LayoutParams();
          ((SysuiStatusBarStateController) Dependency.get(StatusBarStateController.class))
                  .addCallback(mStateListener,
                          SysuiStatusBarStateController.RANK_STATUS_BAR_WINDOW_CONTROLLER);
          Dependency.get(ConfigurationController.class).addCallback(this);
      }
  
      /**
       * Register to receive notifications about status bar window state changes.
       */
      public void registerCallback(StatusBarWindowCallback callback) {
          // Prevent adding duplicate callbacks
          for (int i = 0; i < mCallbacks.size(); i++) {
              if (mCallbacks.get(i).get() == callback) {
                  return;
              }
          }
          mCallbacks.add(new WeakReference<StatusBarWindowCallback>(callback));
      }
  
      private boolean shouldEnableKeyguardScreenRotation() {
          Resources res = mContext.getResources();
          return SystemProperties.getBoolean("lockscreen.rot\_override", false)
                  || res.getBoolean(R.bool.config_enableLockScreenRotation);
      }
  
      /**
       * Adds the status bar view to the window manager.
       *
       * @param statusBarView The view to add.
       * @param barHeight The height of the status bar in collapsed state.
       */
      public void add(ViewGroup statusBarView, int barHeight) {
  
          // Now that the status bar window encompasses the sliding panel and its
          // translucent backdrop, the entire thing is made TRANSLUCENT and is
          // hardware-accelerated.
          mLp = new WindowManager.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT,
                  barHeight,
                  WindowManager.LayoutParams.TYPE_STATUS_BAR,
                  WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                          | WindowManager.LayoutParams.FLAG_TOUCHABLE_WHEN_WAKING
                          | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH
                          | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                          | WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                  PixelFormat.TRANSLUCENT);
          mLp.token = new Binder();
          mLp.gravity = Gravity.TOP;
          mLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
          mLp.setTitle("StatusBar");
          mLp.packageName = mContext.getPackageName();
          mLp.layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
          mStatusBarView = statusBarView;
          mBarHeight = barHeight;
          mWindowManager.addView(mStatusBarView, mLp);
          mLpChanged.copyFrom(mLp);
          onThemeChanged();
      }
  
      private void applyKeyguardFlags(State state) {
          if (state.keyguardShowing) {
              mLpChanged.privateFlags |= WindowManager.LayoutParams.PRIVATE_FLAG_KEYGUARD;
          } else {
              mLpChanged.privateFlags &= ~WindowManager.LayoutParams.PRIVATE_FLAG_KEYGUARD;
          }
  
          final boolean scrimsOccludingWallpaper =
                  state.scrimsVisibility == ScrimController.VISIBILITY_FULLY_OPAQUE;
          final boolean keyguardOrAod = state.keyguardShowing
                  || (state.dozing && mDozeParameters.getAlwaysOn());
          if (keyguardOrAod && !state.backdropShowing && !scrimsOccludingWallpaper) {
              mLpChanged.flags |= WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER;
          } else {
              mLpChanged.flags &= ~WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER;
          }
  
          if (state.dozing) {
              mLpChanged.privateFlags |= LayoutParams.SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS;
          } else {
              mLpChanged.privateFlags &= ~LayoutParams.SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS;
          }
      }

```

在StatusBarWindowController(Context context)的构造方法中通过shouldEnableKeyguardScreenRotation()来判断当前是否旋转，如果固定屏幕这里就可以返回ｆａｓｌｅ  
 而在adjustScreenOrientation(State state)中关于mLpChanged.screenOrientation关于屏幕方向是设置都可以设置为固定横屏，这样就可以保证锁屏页面的固定横屏功能



```
      private void adjustScreenOrientation(State state) {
          if (state.isKeyguardShowingAndNotOccluded() || state.dozing) {
              if (mKeyguardScreenRotation) {
                  mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_USER;
              } else {
                  mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_NOSENSOR;
              }
          } else {
              mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
          }
      }

```

在adjustScreenOrientation(State state)中主要设置根据是否是锁屏页面判断  
 mLpChanged.screenOrientation设置旋转方向，所以在这里设置为固定横屏  
 所以可以修改如下：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarWindowController.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarWindowController.java
@@ -129,8 +129,9 @@ public class StatusBarWindowController implements Callback, Dumpable, Configurat
 
     private boolean shouldEnableKeyguardScreenRotation() {
         Resources res = mContext.getResources();
-        return SystemProperties.getBoolean("lockscreen.rot\_override", false)
-                || res.getBoolean(R.bool.config_enableLockScreenRotation);
+               return false;
+        //return SystemProperties.getBoolean("lockscreen.rot\_override", false)
+        //        || res.getBoolean(R.bool.config_enableLockScreenRotation);
     }
 
public class StatusBarWindowController implements Callback, Dumpable, Configurat
             if (mKeyguardScreenRotation) {
                 mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_USER;
             } else {
-                mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_NOSENSOR;
+                //mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_NOSENSOR;
+                               mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
             }
         } else {
             mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
         }
+        
+               //mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
     }

```

通过上述方法修改在shouldEnableKeyguardScreenRotation()返回ｆａｌｓｅ  
 以及在mLpChanged.screenOrientation设置固定横屏就实现了固定横屏的功能





