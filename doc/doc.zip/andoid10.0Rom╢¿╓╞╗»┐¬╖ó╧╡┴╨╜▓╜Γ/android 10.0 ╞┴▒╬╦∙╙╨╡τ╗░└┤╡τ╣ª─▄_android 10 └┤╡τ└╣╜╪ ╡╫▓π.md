



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.屏蔽所有电话来电功能的核心类](#2.%E5%B1%8F%E8%94%BD%E6%89%80%E6%9C%89%E7%94%B5%E8%AF%9D%E6%9D%A5%E7%94%B5%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.屏蔽所有电话来电功能的核心功能分析和实现](#3.%E5%B1%8F%E8%94%BD%E6%89%80%E6%9C%89%E7%94%B5%E8%AF%9D%E6%9D%A5%E7%94%B5%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0)




---



## 1.概述


在10.0的产品定制化开发中，由于产品是wifi产品，对于系统原生的拨打电话功能需要去掉，所以系统要屏蔽来电功能,需要根据标志位 屏蔽一切来电功能


## 2.屏蔽所有电话来电功能的核心类



```
packages\services\Telecomm\src\com\android\server\telecom\CallsManager.java
packages/services/Telecomm/src/com/android/server/telecom/callfiltering/IncomingCallFilter.java
```

## 3.屏蔽所有电话来电功能的核心功能分析和实现


功能分析:


通过系统的相关源码发现所有的来电去电都是CallManager.java来负责对来电的管理,通过对来电的接口管理来实现对通话流程的管理


所以来看下CallManager.java源码来分析来电流程



```
    /**
   * Singleton.
   *
   * NOTE: by design most APIs are package private, use the relevant adapter/s to allow
   * access from other packages specifically refraining from passing the CallsManager instance
   * beyond the com.android.server.telecom package boundary.
   */
  @VisibleForTesting
  public class CallsManager extends Call.ListenerBase
          implements VideoProviderProxy.Listener, CallFilterResultCallback, CurrentUserProxy {
		   @Override
      public void onSuccessfulOutgoingCall(Call call, int callState) {
          Log.v(this, "onSuccessfulOutgoingCall, %s", call);
  
          setCallState(call, callState, "successful outgoing call");
          if (!mCalls.contains(call)) {
              // Call was not added previously in startOutgoingCall due to it being a potential MMI
              // code, so add it now.
              addCall(call);
          }
  
          // The call's ConnectionService has been updated.
          for (CallsManagerListener listener : mListeners) {
              listener.onConnectionServiceChanged(call, null, call.getConnectionService());
          }
  
          markCallAsDialing(call);
      }
  
      @Override
      public void onFailedOutgoingCall(Call call, DisconnectCause disconnectCause) {
          Log.v(this, "onFailedOutgoingCall, call: %s", call);
  
          markCallAsRemoved(call);
      }

   @Override
    public void onSuccessfulIncomingCall(Call incomingCall) {
        Log.d(this, "onSuccessfulIncomingCall");
        PhoneAccount phoneAccount = mPhoneAccountRegistrar.getPhoneAccountUnchecked(
                incomingCall.getTargetPhoneAccount());
        Bundle extras =
            phoneAccount == null || phoneAccount.getExtras() == null
                ? new Bundle()
                : phoneAccount.getExtras();
        if (incomingCall.hasProperty(Connection.PROPERTY_EMERGENCY_CALLBACK_MODE) ||
                incomingCall.isSelfManaged() ||
                extras.getBoolean(PhoneAccount.EXTRA_SKIP_CALL_FILTERING)) {
            Log.i(this, "Skipping call filtering for %s (ecm=%b, selfMgd=%b, skipExtra=%b)",
                    incomingCall.getId(),
                    incomingCall.hasProperty(Connection.PROPERTY_EMERGENCY_CALLBACK_MODE),
                    incomingCall.isSelfManaged(),
                    extras.getBoolean(PhoneAccount.EXTRA_SKIP_CALL_FILTERING));
            onCallFilteringComplete(incomingCall, new CallFilteringResult(true, false, true, true));
            incomingCall.setIsUsingCallFiltering(false);
            return;
        }

        incomingCall.setIsUsingCallFiltering(true);
        List<IncomingCallFilter.CallFilter> filters = new ArrayList<>();
        filters.add(new DirectToVoicemailCallFilter(mCallerInfoLookupHelper));
        filters.add(new AsyncBlockCheckFilter(mContext, new BlockCheckerAdapter(),
                mCallerInfoLookupHelper, null));
        filters.add(new CallScreeningServiceController(mContext, this, mPhoneAccountRegistrar,
                new ParcelableCallUtils.Converter(), mLock,
                new TelecomServiceImpl.SettingsSecureAdapterImpl(), mCallerInfoLookupHelper,
                new CallScreeningServiceHelper.AppLabelProxy() {
                    @Override
                    public CharSequence getAppLabel(String packageName) {
                        PackageManager pm = mContext.getPackageManager();
                        try {
                            ApplicationInfo info = pm.getApplicationInfo(packageName, 0);
                            return pm.getApplicationLabel(info);
                        } catch (PackageManager.NameNotFoundException nnfe) {
                            Log.w(this, "Could not determine package name.");
                        }

                        return null;
                    }
                }));
        new IncomingCallFilter(mContext, this, incomingCall, mLock,
                mTimeoutsAdapter, filters).performFiltering();
    }
```

通过读CallManager的相关源码发现 当来电时最终都会调用 onSuccessfulIncomingCall（）方法,而在接通电话前,都会通过IncomingCallFilter的performFiltering来进行过滤看是不是黑名单号码,所有可以把标志位加在这里，实现屏蔽所有来电功能


接下来看下IncomingCallFilter的performFiltering关于过滤黑名单的相关方法



```
public class IncomingCallFilter implements CallFilterResultCallback {
  
       public IncomingCallFilter(Context context, CallFilterResultCallback listener, Call call,
             TelecomSystem.SyncRoot lock, Timeouts.Adapter timeoutsAdapter,
             List<CallFilter> filters) {
         mContext = context;
         mListener = listener;
         mCall = call;
         mTelecomLock = lock;
         mFilters = filters;
         mNumPendingFilters = filters.size();
         mTimeoutsAdapter = timeoutsAdapter;
     }
 
     public void performFiltering() {
         Log.addEvent(mCall, LogUtils.Events.FILTERING_INITIATED);
         for (CallFilter filter : mFilters) {
             filter.startFilterLookup(mCall, this);
         }
         // synchronized to prevent a race on mResult and to enter into Telecom.
         mHandler.postDelayed(new Runnable("ICF.pFTO", mTelecomLock) { // performFiltering time-out
             @Override
             public void loggedRun() {
                 if (mIsPending) {
                     Log.i(IncomingCallFilter.this, "Call filtering has timed out.");
                     Log.addEvent(mCall, LogUtils.Events.FILTERING_TIMED_OUT);
                     mListener.onCallFilteringComplete(mCall, mResult);
                     mIsPending = false;
                 }
             }
         }.prepare(), mTimeoutsAdapter.getCallScreeningTimeoutMillis(mContext.getContentResolver()));
     }
 
     public void onCallFilteringComplete(Call call, CallFilteringResult result) {
         synchronized (mTelecomLock) { // synchronizing to prevent race on mResult
             mNumPendingFilters--;
             mResult = result.combine(mResult);
             if (mNumPendingFilters == 0) {
                 // synchronized on mTelecomLock to enter into Telecom.
                 mHandler.post(new Runnable("ICF.oCFC", mTelecomLock) {
                     @Override
                     public void loggedRun() {
                         if (mIsPending) {
                             Log.addEvent(mCall, LogUtils.Events.FILTERING_COMPLETED, mResult);
                             mListener.onCallFilteringComplete(mCall, mResult);
                              mIsPending = false;
                          }
                      }
                  }.prepare());
              }
          }
      }
  
      /**
       * Returns the handler, for testing purposes.
       */
      @VisibleForTesting
      public Handler getHandler() {
          return mHandler;
      }
  }
  
```

在通过上述的performFiltering中发现是在这里，调用来电号码是否需要过滤是否是联系人中的黑名单的号码，决定是否需要拦截来电，所以控制来电功能也可以在这里控制


实现方法如下:



```
a/packages/services/Telecomm/src/com/android/server/telecom/callfiltering/IncomingCallFilter.java
+++ b/packages/services/Telecomm/src/com/android/server/telecom/callfiltering/IncomingCallFilter.java
@@ -27,7 +27,7 @@ import com.android.server.telecom.Call;
 import com.android.server.telecom.LogUtils;
 import com.android.server.telecom.TelecomSystem;
 import com.android.server.telecom.Timeouts;
-
+import android.provider.Settings;
 import java.util.List;
 
 public class IncomingCallFilter implements CallFilterResultCallback {
@@ -67,6 +67,9 @@ public class IncomingCallFilter implements CallFilterResultCallback {
     }
 
     public void performFiltering() {
+        int phonecoming_disable = Settings.Global.getInt(mContext.getContentResolver(), "phonecoming_disable", 0);
+               if(phonecoming_disable==1)return;
         Log.addEvent(mCall, LogUtils.Events.FILTERING_INITIATED);
         for (CallFilter filter : mFilters) {
             filter.startFilterLookup(mCall, this);
```



