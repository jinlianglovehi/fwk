






### 1.概述


在10.0的产品进行平板设备开发中，需要横屏显示，所以需要把屏幕方向旋转90，作为横屏显示，但是这样可能会引起一个问题 就是开机动画显示不全,就是虽然画面是横屏显示了 但是只能显示一部分显示不全


### 2.横屏旋转开机动画显示不全的解决方案的核心类



```
frameworks\native\services\surfaceflinger\DisplayDevice.cpp

```

### 3.横屏旋转开机动画显示不全的解决方案的核心功能分析和实现


功能分析  
 android显示系统的核心是surfaceflinger,它为所有的应用程序提供显示服务显示的翻转和旋转也是由surfaceflinger完成的,所以分析下surfaceflinger的旋转流程  
 surfaceflinger启动后首先进行初始化操作,设置surfaceflinger的相关属性并创建了DisplayDevice对象  
 所以重点看DisplayDevice.cpp的源码  
 路径:frameworks\native\services\surfaceflinger\DisplayDevice.cpp



```
DisplayDevice::DisplayDevice(DisplayDeviceCreationArgs&& args)
      : mFlinger(args.flinger),
        mDisplayToken(args.displayToken),
        mSequenceId(args.sequenceId),
        mDisplayInstallOrientation(args.displayInstallOrientation),
        mCompositionDisplay{mFlinger->getCompositionEngine().createDisplay(
                compositionengine::DisplayCreationArgs{args.isSecure, args.isVirtual,
                                                       args.displayId})},
        mIsVirtual(args.isVirtual),
        mOrientation(),
        mActiveConfig(0),
        mIsPrimary(args.isPrimary) {
    char value[PROPERTY_VALUE_MAX];
    property_get("ro.sprd.superresolution", value, "0");
    mEnabledSR = atoi(value);

    mCompositionDisplay->createRenderSurface(
            compositionengine::RenderSurfaceCreationArgs{ANativeWindow_getWidth(
                                                                 args.nativeWindow.get()),
                                                         ANativeWindow_getHeight(
                                                                 args.nativeWindow.get()),
                                                         args.nativeWindow, args.displaySurface});

    mCompositionDisplay->createDisplayColorProfile(
            compositionengine::DisplayColorProfileCreationArgs{args.hasWideColorGamut,
                                                               std::move(args.hdrCapabilities),
                                                               args.supportedPerFrameMetadata,
                                                               args.hwcColorModes});

    if (!mCompositionDisplay->isValid()) {
        ALOGE("Composition Display did not validate!");
    }

    mCompositionDisplay->getRenderSurface()->initialize();

    setPowerMode(args.initialPowerMode);

    // initialize the display orientation transform.
    setProjection(DisplayState::eOrientationDefault, Rect::INVALID_RECT, Rect::INVALID_RECT);
}

```

在DisplayDevice(DisplayDeviceCreationArgs&& args)的构造方法中，通过  
 setProjection(DisplayState::eOrientationDefault, Rect::INVALID\_RECT, Rect::INVALID\_RECT); 来设置屏幕尺寸


接下来看DisplayDevice的setProjection();



```
void DisplayDevice::setProjection(int orientation,
        const Rect& newViewport, const Rect& newFrame) {
    Rect viewport(newViewport);
    Rect frame(newFrame);

    mOrientation = orientation;

    const Rect& displayBounds = getCompositionDisplay()->getState().bounds;
    int w = displayBounds.width();
    int h = displayBounds.height();

    ui::Transform R;
    DisplayDevice::orientationToTransfrom(orientation, w, h, &R);

    if (mEnabledSR) {
        if (isPrimary() && (frame.getWidth() * frame.getHeight() != w * h) &&
            (frame.getWidth() > frame.getHeight())) {
            w = frame.getHeight();
            h = frame.getWidth();
        }
    }

    if (!frame.isValid()) {
        // the destination frame can be invalid if it has never been set,
        // in that case we assume the whole display frame.
        frame = Rect(w, h);
    }

    if (viewport.isEmpty()) {
        // viewport can be invalid if it has never been set, in that case
        // we assume the whole display size.
        // it's also invalid to have an empty viewport, so we handle that
        // case in the same way.
        viewport = Rect(w, h);
        if (R.getOrientation() & ui::Transform::ROT_90) {
            // viewport is always specified in the logical orientation
            // of the display (ie: post-rotation).
            std::swap(viewport.right, viewport.bottom);
        }
    }

    ui::Transform TL, TP, S;
    float src_width  = viewport.width();
    float src_height = viewport.height();
    float dst_width  = frame.width();
    float dst_height = frame.height();
    if (src_width != dst_width || src_height != dst_height) {
        float sx = dst_width  / src_width;
        float sy = dst_height / src_height;
        S.set(sx, 0, 0, sy);
    }

    float src_x = viewport.left;
    float src_y = viewport.top;
    float dst_x = frame.left;
    float dst_y = frame.top;
    TL.set(-src_x, -src_y);
    TP.set(dst_x, dst_y);

    // need to take care of primary display rotation for globalTransform
    // for case if the panel is not installed aligned with device orientation
    if (isPrimary()) {
        DisplayDevice::orientationToTransfrom(
                (orientation + mDisplayInstallOrientation) % (DisplayState::eOrientation270 + 1),
                w, h, &R);
    }

    // The viewport and frame are both in the logical orientation.
    // Apply the logical translation, scale to physical size, apply the
    // physical translation and finally rotate to the physical orientation.
    ui::Transform globalTransform = R * TP * S * TL;

    const uint8_t type = globalTransform.getType();
    const bool needsFiltering =
            (!globalTransform.preserveRects() || (type >= ui::Transform::SCALE));

    Rect scissor = globalTransform.transform(viewport);
    if (scissor.isEmpty()) {
        scissor = displayBounds;
    }

    if (isPrimary()) {
        sPrimaryDisplayOrientation = displayStateOrientationToTransformOrientation(orientation);
    }

    getCompositionDisplay()->setProjection(globalTransform,
                                           displayStateOrientationToTransformOrientation(
                                                   orientation),
                                           frame, viewport, scissor, needsFiltering);
	if (mEnabledSR) {
    ALOGI_IF((isPrimary()),"SPRD\_SR setProjection(),display\_size(%4dx%4d), v:[%d,%d,%d,%d], f:[%d,%d,%d,%d], s:[%d,%d,%d,%d],"
            "transform:[[%0.3f,%0.3f,%0.3f][%0.3f,%0.3f,%0.3f][%0.3f,%0.3f,%0.3f]]\n",
            w, h,
            viewport.left, viewport.top, viewport.right, viewport.bottom,
            frame.left, frame.top, frame.right, frame.bottom,
            scissor.left, scissor.top, scissor.right, scissor.bottom,
            globalTransform[0][0], globalTransform[1][0], globalTransform[2][0],
            globalTransform[0][1], globalTransform[1][1], globalTransform[2][1],
            globalTransform[0][2], globalTransform[1][2], globalTransform[2][2]);
	}
}

```

在DisplayDevice的setProjection方法的源码中可以看出


在这段核心代码中



```
 if (!frame.isValid()) {
        // the destination frame can be invalid if it has never been set,
        // in that case we assume the whole display frame.
        frame = Rect(w, h);
    }

    if (viewport.isEmpty()) {
        // viewport can be invalid if it has never been set, in that case
        // we assume the whole display size.
        // it's also invalid to have an empty viewport, so we handle that
        // case in the same way.
        viewport = Rect(w, h);
        if (R.getOrientation() & ui::Transform::ROT_90) {
            // viewport is always specified in the logical orientation
            // of the display (ie: post-rotation).
            std::swap(viewport.right, viewport.bottom);
        }
    }

```

根据不同类型设置不同的frame 的宽高，  
 这里就是设置开机动画尺寸的地方 解决方法就是在这里  
 所以修改为：



```
  if (!frame.isValid()) {
        // the destination frame can be invalid if it has never been set,
        // in that case we assume the whole display frame.
        frame = Rect(w, h);
       +    if ((R.getOrientation() & ui::Transform::ROT\_90) || (mFlinger->primaryDisplayOrientation & DisplayState::eOrientationSwapMask)) {

       +          std::swap(frame.right, frame.bottom);

       +    }
    }

    if (viewport.isEmpty()) {
        // viewport can be invalid if it has never been set, in that case
        // we assume the whole display size.
        // it's also invalid to have an empty viewport, so we handle that
        // case in the same way.
        viewport = Rect(w, h);
      -  if (R.getOrientation() & ui::Transform::ROT_90) {
      +    if ((R.getOrientation() & ui::Transform::ROT\_90) || (mFlinger->primaryDisplayOrientation & DisplayState::eOrientationSwapMask)) {

            // viewport is always specified in the logical orientation
            // of the display (ie: post-rotation).
            std::swap(viewport.right, viewport.bottom);
        }
    }

```

在这里根据屏幕方向设置不同的开机动画旋转方向  
 mFlinger->primaryDisplayOrientation表示屏幕旋转





