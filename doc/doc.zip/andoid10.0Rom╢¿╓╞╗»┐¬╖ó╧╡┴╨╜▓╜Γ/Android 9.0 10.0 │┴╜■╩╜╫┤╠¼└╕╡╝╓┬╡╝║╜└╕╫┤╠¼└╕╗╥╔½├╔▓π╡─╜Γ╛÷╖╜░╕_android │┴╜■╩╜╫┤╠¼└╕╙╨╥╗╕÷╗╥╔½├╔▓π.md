






### 1.概述


在10.0的系统产品开发中，在app开发中，沉浸式状态栏也是常有的样式，但是设置沉浸式状态栏后，会导致状态栏和导航栏会有灰色蒙层的问题存在


解决方案:  
 DecorView是整个Window界面的最顶层View，它只有一个子元素为LinearLayout。代表整个Window界面，包含通知栏，标题栏，内容显示栏三块区域。


Android7.0以下，DecorView是PhoneWindow的内部类，而在7.0以上，是一个单独的类，并且有新的属性和方法。新的属性如：mSemiTransparentBarColor，看字面意思应该就是我们要找的，我们对它进行跟踪


### 2.沉浸式状态栏导致导航栏状态栏灰色蒙层的解决方案的核心类



```
framework/base/core/java/com/android/internal/policy/DecorView.java

```

### 3.沉浸式状态栏导致导航栏状态栏灰色蒙层的解决方案的核心功能分析和实现


DecorView，他是android中界面的根布局。其实android的activity界面整个就是一个控件树，DecorView是根节点，DecorView的孩子节点就是一个LinearLayout


接下来查看源码DecorView.java  
 路径：framework/base/core/java/com/android/internal/policy/DecorView.java



```
/** @hide */
  public class DecorView extends FrameLayout implements RootViewSurfaceTaker, WindowCallbacks {
 DecorView(Context context, int featureId, PhoneWindow window,
            WindowManager.LayoutParams params) {
        super(context);
        mFeatureId = featureId;

        mShowInterpolator = AnimationUtils.loadInterpolator(context,
                android.R.interpolator.linear_out_slow_in);
        mHideInterpolator = AnimationUtils.loadInterpolator(context,
                android.R.interpolator.fast_out_linear_in);

        mBarEnterExitDuration = context.getResources().getInteger(
                R.integer.dock_enter_exit_duration);
        mForceWindowDrawsBarBackgrounds = context.getResources().getBoolean(
                R.bool.config_forceWindowDrawsStatusBarBackground)
                && context.getApplicationInfo().targetSdkVersion >= N;
        mSemiTransparentBarColor = context.getResources().getColor(
                R.color.system_bar_background_semi_transparent, null /* theme */);

        updateAvailableWidth();

        setWindow(window);

        updateLogTag(params);

        mResizeShadowSize = context.getResources().getDimensionPixelSize(
                R.dimen.resize_shadow_size);
        initResizingPaints();

        mLegacyNavigationBarBackgroundPaint.setColor(Color.BLACK);
    }
    verride
      public void onDraw(Canvas c) {
          super.onDraw(c);
  
          mBackgroundFallback.draw(this, mContentRoot, c, mWindow.mContentParent,
                  mStatusColorViewState.view, mNavigationColorViewState.view);
      }
  
      @Override
      public boolean dispatchKeyEvent(KeyEvent event) {
          final int keyCode = event.getKeyCode();
          final int action = event.getAction();
          final boolean isDown = action == KeyEvent.ACTION_DOWN;
  
          if (isDown && (event.getRepeatCount() == 0)) {
              // First handle chording of panel key: if a panel key is held
              // but not released, try to execute a shortcut in it.
              if ((mWindow.mPanelChordingKey > 0) && (mWindow.mPanelChordingKey != keyCode)) {
                  boolean handled = dispatchKeyShortcutEvent(event);
                  if (handled) {
                      return true;
                  }
              }
  
              // If a panel is open, perform a shortcut on it without the
              // chorded panel key
              if ((mWindow.mPreparedPanel != null) && mWindow.mPreparedPanel.isOpen) {
 if (mWindow.performPanelShortcut(mWindow.mPreparedPanel, keyCode, event, 0)) {
                      return true;
                  }
              }
          }
  
          if (!mWindow.isDestroyed()) {
              final Window.Callback cb = mWindow.getCallback();
              final boolean handled = cb != null && mFeatureId < 0 ? cb.dispatchKeyEvent(event)
                      : super.dispatchKeyEvent(event);
              if (handled) {
                  return true;
              }
          }
  
          return isDown ? mWindow.onKeyDown(mFeatureId, event.getKeyCode(), event)
                  : mWindow.onKeyUp(mFeatureId, event.getKeyCode(), event);
      }
  
      @Override
      public boolean dispatchKeyShortcutEvent(KeyEvent ev) {
          // If the panel is already prepared, then perform the shortcut using it.
          boolean handled;
          if (mWindow.mPreparedPanel != null) {
              handled = mWindow.performPanelShortcut(mWindow.mPreparedPanel, ev.getKeyCode(), ev,
                      Menu.FLAG_PERFORM_NO_CLOSE);
              if (handled) {
                  if (mWindow.mPreparedPanel != null) {
                      mWindow.mPreparedPanel.isHandled = true;
                  }
                  return true;
              }
          }
  
          // Shortcut not handled by the panel.  Dispatch to the view hierarchy.
          final Window.Callback cb = mWindow.getCallback();
          handled = cb != null && !mWindow.isDestroyed() && mFeatureId < 0
                  ? cb.dispatchKeyShortcutEvent(ev) : super.dispatchKeyShortcutEvent(ev);
          if (handled) {
              return true;
          }
  
          // If the panel is not prepared, then we may be trying to handle a shortcut key
          // combination such as Control+C.  Temporarily prepare the panel then mark it
          // unprepared again when finished to ensure that the panel will again be prepared
          // the next time it is shown for real.
          PhoneWindow.PanelFeatureState st =
                  mWindow.getPanelState(Window.FEATURE_OPTIONS_PANEL, false);
          if (st != null && mWindow.mPreparedPanel == null) {
              mWindow.preparePanel(st, ev);
              handled = mWindow.performPanelShortcut(st, ev.getKeyCode(), ev,
                      Menu.FLAG_PERFORM_NO_CLOSE);
              st.isPrepared = false;
              if (handled) {
                  return true;
              }
          }
          return false;
      }


```

在DecorView的构造方法中，发现  
 mSemiTransparentBarColor 会发现初始值为：system\_bar\_background\_semi\_transparent  
 而这个值就是灰色,就是沉浸式状态栏的灰色蒙层，所以解决灰色蒙层的问题就是从这里解决  
 接下来看这个灰色蒙层是怎么产生的



```
private int calculateStatusBarColor() {
    return calculateBarColor(mWindow.getAttributes().flags, FLAG_TRANSLUCENT_STATUS,
            mSemiTransparentBarColor, mWindow.mStatusBarColor,
            getWindowSystemUiVisibility(), SYSTEM_UI_FLAG_LIGHT_STATUS_BAR,
            mWindow.mEnsureStatusBarContrastWhenTransparent);
}

private int calculateNavigationBarColor() {
    return calculateBarColor(mWindow.getAttributes().flags, FLAG_TRANSLUCENT_NAVIGATION,
            mSemiTransparentBarColor, mWindow.mNavigationBarColor,
            getWindowSystemUiVisibility(), SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR,
            mWindow.mEnsureNavigationBarContrastWhenTransparent
                    && getContext().getResources().getBoolean(R.bool.config_navBarNeedsScrim));
}

```

在SystemUI的状态栏中，app中设置沉浸式状态栏时，  
 而在设置沉浸式时，会对状态栏导航栏的背景颜色做成改变 也就是设置mSemiTransparentBarColor 为背景，修改这个背景就可以实现解决问题


所以修改就在这里



```
 DecorView(Context context, int featureId, PhoneWindow window,
            WindowManager.LayoutParams params) {
        super(context);
        mFeatureId = featureId;

        mShowInterpolator = AnimationUtils.loadInterpolator(context,
                android.R.interpolator.linear_out_slow_in);
        mHideInterpolator = AnimationUtils.loadInterpolator(context,
                android.R.interpolator.fast_out_linear_in);

        mBarEnterExitDuration = context.getResources().getInteger(
                R.integer.dock_enter_exit_duration);
        mForceWindowDrawsBarBackgrounds = context.getResources().getBoolean(
                R.bool.config_forceWindowDrawsStatusBarBackground)
                && context.getApplicationInfo().targetSdkVersion >= N;

        -  mSemiTransparentBarColor = context.getResources().getColor(
                R.color.system_bar_background_semi_transparent, null /* theme */);
        + mSemiTransparentBarColor = context.getResources().getColor(
                R.color.resize_shadow_end_color, null /* theme */);

        updateAvailableWidth();

        setWindow(window);

        updateLogTag(params);

        mResizeShadowSize = context.getResources().getDimensionPixelSize(
                R.dimen.resize_shadow_size);
        initResizingPaints();

        mLegacyNavigationBarBackgroundPaint.setColor(Color.BLACK);
    }

```

mSemiTransparentBarColor 修改为透明色就可以了，这样就解决了灰色蒙层的问题





