






### 1.概述


在10.0的产品定制化开发中，在SystemUI状态栏中，有一些通知类似 消息推送 弹出的 悬浮通知，弹出30秒之后会消失掉 在产品需求中要求屏蔽这类的通过，要想屏蔽掉这些通知，首选知道这些通知是怎么产生的


### 2.SystemUI 屏蔽状态栏消息推送弹出的悬浮通知的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationContentInflater.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/NotificationAlertingManager.java 

```

### 3.SystemUI 屏蔽状态栏消息推送弹出的悬浮通知的核心功能实现和分析


系统通知类型  
 NotificationContentInflater.java 详细的介绍各种通知的类型  
 frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationContentInflater.java


### 3.1NotificationContentInflater 弹窗类型分析



```
public class NotificationContentInflater {
 
     public static final String TAG = "NotifContentInflater";
 
     @Retention(RetentionPolicy.SOURCE)
     @IntDef(flag = true,
             prefix = {"FLAG\_CONTENT\_VIEW\_"},
             value = {
                 FLAG_CONTENT_VIEW_CONTRACTED,
                 FLAG_CONTENT_VIEW_EXPANDED,
                 FLAG_CONTENT_VIEW_HEADS_UP,
                 FLAG_CONTENT_VIEW_AMBIENT,
                 FLAG_CONTENT_VIEW_PUBLIC,
                 FLAG_CONTENT_VIEW_ALL})
     public @interface InflationFlag {}
     /**
      * The default, contracted view.  Seen when the shade is pulled down and in the lock screen
      * if there is no worry about content sensitivity.
      */
     public static final int FLAG_CONTENT_VIEW_CONTRACTED = 1;
 
     /**
      * The expanded view.  Seen when the user expands a notification.
      */
     public static final int FLAG_CONTENT_VIEW_EXPANDED = 1 << 1;
 
     /**
      * The heads up view.  Seen when a high priority notification peeks in from the top.
      */
     public static final int FLAG_CONTENT_VIEW_HEADS_UP = 1 << 2;
 
     /**
      * The ambient view.  Seen when a high priority notification is received and the phone
      * is dozing.
      */
     public static final int FLAG_CONTENT_VIEW_AMBIENT = 1 << 3;
  
      /**
       * The public view.  This is a version of the contracted view that hides sensitive
       * information and is used on the lock screen if we determine that the notification's
       * content should be hidden.
       */
      public static final int FLAG_CONTENT_VIEW_PUBLIC = 1 << 4;
  
      public static final int FLAG_CONTENT_VIEW_ALL = ~0;
  
      /**
       * Content views that must be inflated at all times.
       */
      @InflationFlag
      private static final int REQUIRED_INFLATION_FLAGS =
              FLAG_CONTENT_VIEW_CONTRACTED
              | FLAG_CONTENT_VIEW_EXPANDED;
  
      /**
       * The set of content views to inflate.
       */
      @InflationFlag
      private int mInflationFlags = REQUIRED_INFLATION_FLAGS;
  
      private final ExpandableNotificationRow mRow;
      private boolean mIsLowPriority;
      private boolean mUsesIncreasedHeight;
      private boolean mUsesIncreasedHeadsUpHeight;
      private RemoteViews.OnClickHandler mRemoteViewClickHandler;
      private boolean mIsChildInGroup;
      private InflationCallback mCallback;
      private boolean mRedactAmbient;
      private boolean mInflateSynchronously = false;
      private final ArrayMap<Integer, RemoteViews> mCachedContentViews = new ArrayMap<>();
  
      public NotificationContentInflater(ExpandableNotificationRow row) {
          mRow = row;
      }
  
      public void setIsLowPriority(boolean isLowPriority) {
          mIsLowPriority = isLowPriority;
      }
  
      /**
       * Set whether the notification is a child in a group
       *
       * @return whether the view was re-inflated
       */
      public void setIsChildInGroup(boolean childInGroup) {
          if (childInGroup != mIsChildInGroup) {
              mIsChildInGroup = childInGroup;
              if (mIsLowPriority) {
                  int flags = FLAG_CONTENT_VIEW_CONTRACTED | FLAG_CONTENT_VIEW_EXPANDED;
                  inflateNotificationViews(flags);
              }
          }
      }
  
      public void setUsesIncreasedHeight(boolean usesIncreasedHeight) {
          mUsesIncreasedHeight = usesIncreasedHeight;
      }
  
      public void setUsesIncreasedHeadsUpHeight(boolean usesIncreasedHeight) {
          mUsesIncreasedHeadsUpHeight = usesIncreasedHeight;
      }
  
      public void setRemoteViewClickHandler(RemoteViews.OnClickHandler remoteViewClickHandler) {
          mRemoteViewClickHandler = remoteViewClickHandler;
      }
  
      /**
       * Update whether or not the notification is redacted on the lock screen.  If the notification
       * is now redacted, we should inflate the public contracted view and public ambient view to
       * now show on the lock screen.
       *
       * @param needsRedaction true if the notification should now be redacted on the lock screen
       */
      public void updateNeedsRedaction(boolean needsRedaction) {
          mRedactAmbient = needsRedaction;
          if (mRow.getEntry() == null) {
              return;
          }
          int flags = FLAG_CONTENT_VIEW_AMBIENT;
          if (needsRedaction) {
              flags |= FLAG_CONTENT_VIEW_PUBLIC;
          }
          inflateNotificationViews(flags);
      }
  
      /**
       * Set whether or not a particular content view is needed and whether or not it should be
       * inflated.  These flags will be used when we inflate or reinflate.
       *
       * @param flag the {@link InflationFlag} corresponding to the view that should/should not be
       *             inflated
       * @param shouldInflate true if the view should be inflated, false otherwise
       */
      public void updateInflationFlag(@InflationFlag int flag, boolean shouldInflate) {
          if (shouldInflate) {
              mInflationFlags |= flag;
          } else if ((REQUIRED_INFLATION_FLAGS & flag) == 0) {
              mInflationFlags &= ~flag;
          }
      }

```

通过上述几个常量发现那就是通知的几种类型 而弹窗通知具体是由NotificationAlertingManager来管理NotificationAlertingManager 构造函数中给NotificationEntryManager 加 NotificationEntryListener ，以便在通知视图首次填充(onEntryInflated) 时 感知并弹出悬浮通知。  
 NotificationAlertingManager.java 负责管理弹出悬浮通知  
 路径:frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/NotificationAlertingManager.java


### 3.2 NotificationAlertingManager.java 弹窗通知分析



```
@Inject
public NotificationAlertingManager(
NotificationEntryManager notificationEntryManager,
AmbientPulseManager ambientPulseManager,
NotificationRemoteInputManager remoteInputManager,
VisualStabilityManager visualStabilityManager,
Lazy<ShadeController> shadeController,
NotificationInterruptionStateProvider notificationInterruptionStateProvider,
NotificationListener notificationListener) {
mAmbientPulseManager = ambientPulseManager;
mRemoteInputManager = remoteInputManager;
mVisualStabilityManager = visualStabilityManager;
mShadeController = shadeController;
mNotificationInterruptionStateProvider = notificationInterruptionStateProvider;
mNotificationListener = notificationListener;
notificationEntryManager.addNotificationEntryListener(new NotificationEntryListener() {
@Override
public void onEntryInflated(NotificationEntry entry, int inflatedFlags) {
//showAlertingView(entry, inflatedFlags);
}
@Override
public void onPostEntryUpdated(NotificationEntry entry) {
updateAlertState(entry);
}
@Override
public void onEntryRemoved(
NotificationEntry entry,
NotificationVisibility visibility,
boolean removedByUser) {
stopAlerting(entry.key);
}
});
}

```

通过上述代码发现  
 notificationEntryManager.addNotificationEntryListener(new NotificationEntryListener() 就是监听悬浮通知的 所以在onEntryInflated()  
 注释掉showAlertingView(entry, inflatedFlags); 就可以了





