






### 1.概述


在10.0的产品定制化开发中，产品提出进入launcher后，设置为默认laucher，在退出launcher后，调用设置原生laucher的方法后进入原生launcher，


### 2.两个laucher动态相互切换(退出一个launcher到另外一个launcher桌面 )的核心类



```
frameworks\base\core\java\android\os\ILgyManager.aidl
frameworks\base\services\core\java\com\android\server\lgy\LgyManagerService.java
frameworks/base/core/java/com/android/internal/app/ResolverActivity.java


```

### 3.两个laucher动态相互切换(退出一个launcher到另外一个launcher桌面 )的核心功能分析和实现


解决思路:


1. 在启动laucher后设置为默认launcher  
 2.退出launcher时，设置原生launcher后默认launcher  
 3.调用home键返回到launcher桌面


1.设置默认launcher:



```
setDefaultLauncher("com.hc.musicplayer"); 设置launcher包名


    private List<ResolveInfo> getResolveInfoList() {
        PackageManager pm = mContext.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        return pm.queryIntentActivities(intent, 0);
    }

    private ResolveInfo getCurrentLauncher() {
        PackageManager pm = mContext.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        return pm.resolveActivity(intent, 0);
    }

    private void setDefaultLauncher(String packageName) {
        PackageManager pm = mContext.getPackageManager();
        ResolveInfo currentLauncher = getCurrentLauncher();

        List<ResolveInfo> packageInfos = getResolveInfoList();

        ResolveInfo futureLauncher = null;

        for (ResolveInfo ri : packageInfos) {
            if (!TextUtils.isEmpty(ri.activityInfo.packageName) && !TextUtils.isEmpty(packageName)
                    && TextUtils.equals(ri.activityInfo.packageName, packageName)) {
                futureLauncher = ri;
            }
        }
        if (futureLauncher == null) {
            return;
        }

        pm.clearPackagePreferredActivities(currentLauncher.activityInfo.packageName);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_MAIN);
        intentFilter.addCategory(Intent.CATEGORY_HOME);
        intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
        ComponentName componentName = new ComponentName(futureLauncher.activityInfo.packageName,
                futureLauncher.activityInfo.name);
        ComponentName[] componentNames = new ComponentName[packageInfos.size()];
        int defaultMatch = 0;
        for (int i = 0; i < packageInfos.size(); i++) {
            ResolveInfo resolveInfo = packageInfos.get(i);
            componentNames[i] = new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
            if (defaultMatch < resolveInfo.match) {
                defaultMatch = resolveInfo.match;
            }
        }
        pm.clearPackagePreferredActivities(currentLauncher.activityInfo.packageName);
        pm.addPreferredActivity(intentFilter, defaultMatch, componentNames, componentName);
    }
}

```

通过上述方法调用PM的clearPackagePreferredActivities先是清除当前默认Launcher,然后调用PM的addPreferredActivity设置默认Launcher


2. 退出launcher时 设置Launcher3为默认launcher



```
setDefaultLauncher("com.android.launcher3");

```

3. 发送 home 事件 进入Launcher3 桌面



```
execShell("input keyevent 3");

    public int execShell(String cmd) {
        int result = -1;
        Process pro = null;
        try {
            pro = Runtime.getRuntime().exec(cmd);
            pro.waitFor();
            result = pro.exitValue();
            Log.e(TAG, "result:" + result);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(pro!=null)pro.destroy();
            return result;
        }
    }

```

接下来就在自定义服务来实现默认设置Launcher的功能


首先在ILgyManager.aidl中增加设置默认Launcher的接口  
 增加接口如下:



```
frameworks\base\core\java\android\os\ILgyManager.aidl

package android.os;
/** @hide */

interface ILgyManager
{
setDefaultLauncher(String packageName);
}


```

接下来在LgyManagerService 中增加设置默认Launcher的接口



```
package com.android.server.lgy;

import com.android.server.SystemService;
import android.content.Context;
import android.util.Log;
import java.util.HashMap;
import android.os.ILgyManager;


public final class LgyManagerService extends ILgyManager.Stub{

private static final String TAG = "LgyManagerService";
final Context mContext;
public LgyManagerService(Context context) {
mContext = context;

}
@Override
public  String getValue(){

try{
Log.d("lgy\_bubug", "GetFromJni ");
return "GetFromJni ";
}catch(Exception e){
return " read nothings!!!";
}
}

}

@Override
public void setDefaultLauncher(String packageName){

try{
setDefaultLauncher("com.hc.musicplayer");
}catch(Exception e){
 e.printStackTrace();
}
}

}


```

在setDefaultLauncher(String packageName)调用设置默认Launcher的接口实现设置默认Launcher


3.在ResolverActivity.java开机启动多个Launcher时，设置默认Launcher



```
@UiThread
  public class ResolverActivity extends Activity implements
          ResolverListAdapter.ResolverListCommunicator {
@Override
      protected void onCreate(Bundle savedInstanceState) {
          // Use a specialized prompt when we're handling the 'Home' app startActivity()
          final Intent intent = makeMyIntent();
          final Set<String> categories = intent.getCategories();
          if (Intent.ACTION_MAIN.equals(intent.getAction())
                  && categories != null
                  && categories.size() == 1
                  && categories.contains(Intent.CATEGORY_HOME)) {
              // Note: this field is not set to true in the compatibility version.
              mResolvingHome = true;
          }
  
          setSafeForwardingMode(true);
  
          onCreate(savedInstanceState, intent, null, 0, null, null, true);
      }
  
      /**
       * Compatibility version for other bundled services that use this overload without
       * a default title resource
       */
      @UnsupportedAppUsage
      protected void onCreate(Bundle savedInstanceState, Intent intent,
              CharSequence title, Intent[] initialIntents,
              List<ResolveInfo> rList, boolean supportsAlwaysUseOption) {
          onCreate(savedInstanceState, intent, title, 0, initialIntents, rList,
                  supportsAlwaysUseOption);
      }
  
      protected void onCreate(Bundle savedInstanceState, Intent intent,
              CharSequence title, int defaultTitleRes, Intent[] initialIntents,
              List<ResolveInfo> rList, boolean supportsAlwaysUseOption) {
          setTheme(appliedThemeResId());
          super.onCreate(savedInstanceState);
  
          // Determine whether we should show that intent is forwarded
          // from managed profile to owner or other way around.
          setProfileSwitchMessageId(intent.getContentUserHint());
  
          try {
              mLaunchedFromUid = ActivityTaskManager.getService().getLaunchedFromUid(
                      getActivityToken());
          } catch (RemoteException e) {
              mLaunchedFromUid = -1;
          }
  
          if (mLaunchedFromUid < 0 || UserHandle.isIsolated(mLaunchedFromUid)) {
              // Gulp!
              finish();
              return;
          }
  
          mPm = getPackageManager();
  
          mReferrerPackage = getReferrerPackageName();
 ....
      }


```

可以在ResolverActivity 中的onCreate中调用相关的setDefaultLauncher(String packageName)来设置默认Launcher,从而实现功能





