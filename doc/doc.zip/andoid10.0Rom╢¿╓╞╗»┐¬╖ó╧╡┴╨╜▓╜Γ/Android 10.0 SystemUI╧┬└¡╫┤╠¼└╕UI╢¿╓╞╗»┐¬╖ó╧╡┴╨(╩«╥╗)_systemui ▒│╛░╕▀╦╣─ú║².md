



## 1.概述


系统SystemUI下拉状态栏定制化开发系列第十一讲，本篇主要讲解怎么样把


下拉状态栏UI中的通知栏部分每一条通知背景修改为圆角背景


## 效果图:


![](https://img-blog.csdnimg.cn/bacef648aff146cf8bf220f8d1cdd43f.png)


 


## 2.核心代码



```
主要代码为:
frameworks\base\packages\SystemUI\res\layout\status_bar_notification_section_header.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ActivatableNotificationView.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java
frameworks/base/packages/SystemUI/res/layout/notification_info.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationGuts.java
```

## 3.核心代码功能实现


####    3.1增加圆角背景布局



```
qs_background_primary.xml

<inset xmlns:android="http://schemas.android.com/apk/res/android">
    <shape>
        <solid android:color="#ffffff"/>
        <corners android:radius="20dp" />
    </shape>
</inset>
```

####   3.2 status\_bar\_notification\_section\_header.xml圆角背景的修改


  先分析status\_bar\_notification\_section\_header.xml布局


 



```
<com.android.systemui.statusbar.notification.stack.SectionHeaderView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="@dimen/notification_section_header_height"
    android:focusable="true"
    android:clickable="true"
    >

    <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
        android:id="@+id/backgroundNormal"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
    <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
        android:id="@+id/backgroundDimmed"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

    <LinearLayout
        android:id="@+id/content"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:gravity="center_vertical"
        android:orientation="horizontal"
        >
        <include layout="@layout/status_bar_notification_section_header_contents"/>
    </LinearLayout>

    <com.android.systemui.statusbar.notification.FakeShadowView
        android:id="@+id/fake_shadow"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</com.android.systemui.statusbar.notification.stack.SectionHeaderView>

从代码分析中可以看出
<com.android.systemui.statusbar.notification.row.NotificationBackgroundView
        android:id="@+id/backgroundNormal"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
    <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
        android:id="@+id/backgroundDimmed"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
就是通知的背景修改为:
--- a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml
@@ -21,6 +21,7 @@
     android:layout_height="@dimen/notification_section_header_height"
     android:focusable="true"
     android:clickable="true"
+       android:background="@drawable/qs_background_primary"
     >
 
     <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
@@ -38,6 +39,7 @@
         android:layout_height="match_parent"
         android:gravity="center_vertical"
         android:orientation="horizontal"
+               android:background="@drawable/qs_background_primary"
         >
         <include layout="@layout/status_bar_notification_section_header_contents"/>
     </LinearLayout>
```

#### 3.2ActivatableNotificationView.java中圆角背景的修改



```
public abstract class ActivatableNotificationView extends ExpandableOutlineView {

    private static final int BACKGROUND_ANIMATION_LENGTH_MS = 220;
    private static final int ACTIVATE_ANIMATION_LENGTH = 220;
    private static final long DARK_ANIMATION_LENGTH = StackStateAnimator.ANIMATION_DURATION_WAKEUP;

    /**
     * The amount of width, which is kept in the end when performing a disappear animation (also
     * the amount from which the horizontal appearing begins)
     */
    private static final float HORIZONTAL_COLLAPSED_REST_PARTIAL = 0.05f;

    /**
     * At which point from [0,1] does the horizontal collapse animation end (or start when
     * expanding)? 1.0 meaning that it ends immediately and 0.0 that it is continuously animated.
     */
    private static final float HORIZONTAL_ANIMATION_END = 0.2f;

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mBackgroundNormal = findViewById(R.id.backgroundNormal);
        mFakeShadow = findViewById(R.id.fake_shadow);
        mShadowHidden = mFakeShadow.getVisibility() != VISIBLE;
        mBackgroundDimmed = findViewById(R.id.backgroundDimmed);
        initBackground();
        updateBackground();
        updateBackgroundTint();
        updateOutlineAlpha();
    }

    /**
     * Sets the custom backgrounds on {@link #mBackgroundNormal} and {@link #mBackgroundDimmed}.
     * This method can also be used to reload the backgrounds on both of those views, which can
     * be useful in a configuration change.
     */
    protected void initBackground() {
        mBackgroundNormal.setCustomBackground(R.drawable.notification_material_bg);
        mBackgroundDimmed.setCustomBackground(R.drawable.notification_material_bg_dim);
    }

从代码中可以看到initBackground() 就是设置背景色

所以修改方案为:
     protected void initBackground() {
-        mBackgroundNormal.setCustomBackground(R.drawable.notification_material_bg);
-        mBackgroundDimmed.setCustomBackground(R.drawable.notification_material_bg_dim);
+        mBackgroundNormal.setCustomBackground(R.drawable.qs_background_primary);
+        mBackgroundDimmed.setCustomBackground(R.drawable.qs_background_primary);
     }
```

#### 3.3 NotificationStackScrollLayout.java 圆角布局的修改



```
@@ -624,7 +629,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
     protected void onFinishInflate() {
         super.onFinishInflate();

         inflateEmptyShadeView();
         inflateFooterView();
         mVisualStabilityManager.setVisibilityLocationProvider(this::isInVisibleLocation);
@@ -651,6 +656,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
     }
 
     private void reinflateViews() {

         inflateFooterView();
         inflateEmptyShadeView();
         updateFooter();
@@ -834,11 +840,11 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
         int right = (int) MathUtils.lerp(darkLeft, lockScreenRight, xProgress);
         int top = (int) MathUtils.lerp(darkTop, lockScreenTop, yProgress);
         int bottom = (int) MathUtils.lerp(darkTop, lockScreenBottom, yProgress);
-        mBackgroundAnimationRect.set(
+        /*mBackgroundAnimationRect.set(
                 left,
                 top,
                 right,
-                bottom);
+                bottom);*/
 
         int backgroundTopAnimationOffset = top - lockScreenTop;
         // TODO(kprevas): this may not be necessary any more since we don't display the shelf in AOD
@@ -850,7 +856,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
             }
         }
         if (!mAmbientState.isDark() || anySectionHasVisibleChild) {
-            drawBackgroundRects(canvas, left, right, top, backgroundTopAnimationOffset);
+            //drawBackgroundRects(canvas, left, right, top, backgroundTopAnimationOffset);
         }
 
         updateClipping();
@@ -924,6 +930,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
             if (child.getVisibility() != View.GONE
                     && child instanceof ExpandableNotificationRow) {
                 ExpandableNotificationRow row = (ExpandableNotificationRow) child;
                 if ((row.isPinned() || row.isHeadsUpAnimatingAway()) && row.getTranslation() < 0
                         && row.getProvider().shouldShowGutsOnSnapOpen()) {
                     top = Math.min(top, row.getTranslationY());

 
     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
@@ -4892,7 +4902,15 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
         mEmptyShadeView = emptyShadeView;
         addView(mEmptyShadeView, index);
     }


     /**
      * Updates expanded, dimmed and locked states of notification rows.
      */
     @ShadeViewRefactor(RefactorComponent.STATE_RESOLVER)
     public void onUpdateRowStates() {
         changeViewPosition(mFooterView, -1);
```

## 3.4 NotificationGuts背景为圆角背景


####  3.4.1 xml布局修改



```
首选notification_info.xml的修改
<com.android.systemui.statusbar.notification.row.NotificationInfo
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/notification_guts"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:clickable="true"
    android:clipChildren="false"
    android:clipToPadding="true"
    android:orientation="vertical"
    android:paddingStart="@*android:dimen/notification_content_margin_start"
    android:background="@color/notification_guts_bg_color">

    <!-- Package Info -->
    <RelativeLayout
        android:id="@+id/header"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:clipChildren="false"
        android:clipToPadding="false">
        <ImageView
            android:id="@+id/pkgicon"
            android:layout_width="@dimen/notification_guts_header_height"
            android:layout_height="@dimen/notification_guts_header_height"
            android:layout_centerVertical="true"
            android:layout_alignParentStart="true"
            android:layout_marginEnd="3dp" />
        <TextView
            android:id="@+id/pkgname"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerVertical="true"
            style="@style/TextAppearance.NotificationImportanceHeader"
            android:layout_marginStart="3dp"
            android:layout_marginEnd="2dp"
            android:layout_toEndOf="@id/pkgicon"
            android:singleLine="true" />
        <TextView
            android:id="@+id/pkg_divider"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerVertical="true"
            style="@style/TextAppearance.NotificationImportanceHeader"
            android:layout_marginStart="2dp"
            android:layout_marginEnd="2dp"
            android:layout_toEndOf="@id/pkgname"
            android:text="@*android:string/notification_header_divider_symbol" />
        <TextView
            android:id="@+id/delegate_name"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerVertical="true"
            style="@style/TextAppearance.NotificationImportanceHeader"
            android:layout_marginStart="2dp"
            android:layout_marginEnd="2dp"
            android:ellipsize="end"
            android:text="@string/notification_delegate_header"
            android:layout_toEndOf="@id/pkg_divider"
            android:maxLines="1" />
        <!-- Optional link to app. Only appears if the channel is not disabled and the app
asked for it -->
        <ImageButton
            android:id="@+id/app_settings"
            android:layout_width="@dimen/notification_importance_toggle_size"
            android:layout_height="@dimen/notification_importance_toggle_size"
            android:layout_centerVertical="true"
            android:visibility="gone"
            android:background="@drawable/ripple_drawable"
            android:contentDescription="@string/notification_app_settings"
            android:src="@drawable/ic_info"
            android:layout_toStartOf="@id/info"
            android:tint="@color/notification_guts_link_icon_tint"/>
        <ImageButton
            android:id="@+id/info"
            android:layout_width="@dimen/notification_importance_toggle_size"
            android:layout_height="@dimen/notification_importance_toggle_size"
            android:layout_centerVertical="true"
            android:background="@drawable/ripple_drawable"
            android:contentDescription="@string/notification_more_settings"
            android:src="@drawable/ic_settings"
            android:layout_alignParentEnd="true"
            android:tint="@color/notification_guts_link_icon_tint"/>
    </RelativeLayout>

    <!-- Channel Info Block -->
    <LinearLayout
        android:id="@+id/channel_info"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingEnd="@*android:dimen/notification_content_margin_end"
        android:gravity="center"
        android:orientation="vertical">
        <!-- Channel Name -->
        <TextView
            android:id="@+id/channel_name"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            style="@style/TextAppearance.NotificationImportanceChannel"/>
        <TextView
            android:id="@+id/group_name"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            style="@style/TextAppearance.NotificationImportanceChannelGroup"
            android:ellipsize="end"
            android:maxLines="1"/>
    </LinearLayout>

    <LinearLayout
        android:id="@+id/blocking_helper"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="@dimen/notification_guts_button_spacing"
        android:layout_marginBottom="@dimen/notification_guts_button_spacing"
        android:paddingEnd="@*android:dimen/notification_content_margin_end"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:orientation="vertical">
        <!-- blocking helper text. no need for non-configurable check b/c controls won't be
        activated in that case -->
        <TextView
            android:id="@+id/blocking_helper_text"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="2dp"
            android:text="@string/inline_blocking_helper"
            style="@*android:style/TextAppearance.DeviceDefault.Notification" />
        <RelativeLayout
            android:id="@+id/block_buttons"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="@dimen/notification_guts_button_spacing">
            <TextView
                android:id="@+id/blocking_helper_turn_off_notifications"
                android:text="@string/inline_turn_off_notifications"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_centerVertical="true"
                android:layout_alignParentStart="true"
                android:width="110dp"
                android:paddingEnd="15dp"
                android:breakStrategy="simple"
                style="@style/TextAppearance.NotificationInfo.Button"/>
            <TextView
                android:id="@+id/deliver_silently"
                android:text="@string/inline_deliver_silently_button"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_centerVertical="true"
                android:layout_marginStart="@dimen/notification_guts_button_horizontal_spacing"
                android:paddingEnd="15dp"
                android:width="110dp"
                android:breakStrategy="simple"
                android:layout_toStartOf="@+id/keep_showing"
                style="@style/TextAppearance.NotificationInfo.Button"/>
            <TextView
                android:id="@+id/keep_showing"
                android:text="@string/inline_keep_button"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_centerVertical="true"
                android:layout_marginStart="@dimen/notification_guts_button_horizontal_spacing"
                android:width="110dp"
                android:breakStrategy="simple"
                android:layout_alignParentEnd="true"
                style="@style/TextAppearance.NotificationInfo.Button"/>
        </RelativeLayout>

    </LinearLayout>

    <LinearLayout
        android:id="@+id/inline_controls"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingEnd="@*android:dimen/notification_content_margin_end"
        android:layout_marginTop="@dimen/notification_guts_option_vertical_padding"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:orientation="vertical">

        <!-- Non configurable app/channel text. appears instead of @+id/interruptiveness_settings-->
        <TextView
            android:id="@+id/non_configurable_text"
            android:text="@string/notification_unblockable_desc"
            android:visibility="gone"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            style="@*android:style/TextAppearance.DeviceDefault.Notification" />

        <!-- Non configurable multichannel text. appears instead of @+id/interruptiveness_settings-->
        <TextView
            android:id="@+id/non_configurable_multichannel_text"
            android:text="@string/notification_multichannel_desc"
            android:visibility="gone"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            style="@*android:style/TextAppearance.DeviceDefault.Notification" />

        <LinearLayout
            android:id="@+id/interruptiveness_settings"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="center"
            android:orientation="vertical">

            <com.android.systemui.statusbar.notification.row.ButtonLinearLayout
                android:id="@+id/alert"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:padding="@dimen/notification_importance_button_padding"
                android:clickable="true"
                android:focusable="true"
                android:background="@drawable/notification_guts_priority_button_bg"
                android:orientation="vertical">
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center"
                    >
                    <ImageView
                        android:id="@+id/alert_icon"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:src="@drawable/ic_notifications_alert"
                        android:background="@android:color/transparent"
                        android:tint="@color/notification_guts_priority_contents"
                        android:clickable="false"
                        android:focusable="false"/>
                    <TextView
                        android:id="@+id/alert_label"
                        android:layout_width="0dp"
                        android:layout_height="wrap_content"
                        android:layout_marginStart="@dimen/notification_importance_drawable_padding"
                        android:layout_weight="1"
                        android:ellipsize="end"
                        android:maxLines="1"
                        android:clickable="false"
                        android:focusable="false"
                        android:textAppearance="@style/TextAppearance.NotificationImportanceButton"
                        android:text="@string/notification_alert_title"/>
                </LinearLayout>
                <TextView
                    android:id="@+id/alert_summary"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="@dimen/notification_importance_button_description_top_margin"
                    android:visibility="gone"
                    android:text="@string/notification_channel_summary_default"
                    android:clickable="false"
                    android:focusable="false"
                    android:ellipsize="end"
                    android:maxLines="2"
                    android:textAppearance="@style/TextAppearance.NotificationImportanceDetail"/>
            </com.android.systemui.statusbar.notification.row.ButtonLinearLayout>

            <com.android.systemui.statusbar.notification.row.ButtonLinearLayout
                android:id="@+id/silence"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="@dimen/notification_importance_button_separation"
                android:padding="@dimen/notification_importance_button_padding"
                android:clickable="true"
                android:focusable="true"
                android:background="@drawable/notification_guts_priority_button_bg"
                android:orientation="vertical">
                <LinearLayout
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:orientation="horizontal"
                    android:gravity="center"
                    >
                    <ImageView
                        android:id="@+id/silence_icon"
                        android:src="@drawable/ic_notifications_silence"
                        android:background="@android:color/transparent"
                        android:tint="@color/notification_guts_priority_contents"
                        android:layout_gravity="center"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:clickable="false"
                        android:focusable="false"/>
                    <TextView
                        android:id="@+id/silence_label"
                        android:layout_width="match_parent"
                        android:layout_height="wrap_content"
                        android:ellipsize="end"
                        android:maxLines="1"
                        android:clickable="false"
                        android:focusable="false"
                        android:layout_toEndOf="@id/silence_icon"
                        android:layout_marginStart="@dimen/notification_importance_drawable_padding"
                        android:textAppearance="@style/TextAppearance.NotificationImportanceButton"
                        android:text="@string/notification_silence_title"/>
                </LinearLayout>
                <TextView
                    android:id="@+id/silence_summary"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="@dimen/notification_importance_button_description_top_margin"
                    android:visibility="gone"
                    android:text="@string/notification_channel_summary_low"
                    android:clickable="false"
                    android:focusable="false"
                    android:ellipsize="end"
                    android:maxLines="2"
                    android:textAppearance="@style/TextAppearance.NotificationImportanceDetail"/>
            </com.android.systemui.statusbar.notification.row.ButtonLinearLayout>

        </LinearLayout>

        <RelativeLayout
            android:id="@+id/bottom_buttons"
            android:layout_width="match_parent"
            android:layout_height="60dp"
            android:gravity="center_vertical"
            android:paddingStart="4dp"
            android:paddingEnd="4dp"
            >
            <TextView
                android:id="@+id/turn_off_notifications"
                android:text="@string/inline_turn_off_notifications"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentStart="true"
                android:gravity="start|center_vertical"
                android:minWidth="@dimen/notification_importance_toggle_size"
                android:minHeight="@dimen/notification_importance_toggle_size"
                android:maxWidth="200dp"
                style="@style/TextAppearance.NotificationInfo.Button"/>
            <TextView
                android:id="@+id/done"
                android:text="@string/inline_ok_button"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentEnd="true"
                android:gravity="end|center_vertical"
                android:minWidth="@dimen/notification_importance_toggle_size"
                android:minHeight="@dimen/notification_importance_toggle_size"
                android:maxWidth="125dp"
                style="@style/TextAppearance.NotificationInfo.Button"/>
        </RelativeLayout>

    </LinearLayout>

    <com.android.systemui.statusbar.notification.row.NotificationUndoLayout
        android:id="@+id/confirmation"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:visibility="gone"
        android:orientation="horizontal" >
        <TextView
            android:id="@+id/confirmation_text"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_gravity="start|center_vertical"
            android:layout_marginStart="@*android:dimen/notification_content_margin_start"
            android:layout_marginEnd="@*android:dimen/notification_content_margin_start"
            android:text="@string/notification_channel_disabled"
            style="@style/TextAppearance.NotificationInfo.Confirmation"/>
        <TextView
            android:id="@+id/undo"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:minWidth="@dimen/notification_importance_toggle_size"
            android:minHeight="@dimen/notification_importance_toggle_size"
            android:layout_marginTop="@dimen/notification_guts_button_spacing"
            android:layout_marginBottom="@dimen/notification_guts_button_spacing"
            android:layout_marginStart="@dimen/notification_guts_button_side_margin"
            android:layout_marginEnd="@dimen/notification_guts_button_side_margin"
            android:layout_gravity="end|center_vertical"
            android:text="@string/inline_undo"
            style="@style/TextAppearance.NotificationInfo.Button"/>
    </com.android.systemui.statusbar.notification.row.NotificationUndoLayout>
</com.android.systemui.statusbar.notification.row.NotificationInfo>

com.android.systemui.statusbar.notification.row.NotificationInfo就是背景
所以修改为:
<com.android.systemui.statusbar.notification.row.NotificationInfo
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/notification_guts"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:clickable="true"
    android:clipChildren="false"
    android:clipToPadding="true"
    android:orientation="vertical"
    android:paddingStart="@*android:dimen/notification_content_margin_start"
-    android:background="@color/notification_guts_bg_color">
+    android:background="@drawable/qs_background_primary">
```

#### 3.4.2 View设置背景的修改



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationGuts.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationGuts.java
@@ -173,7 +173,7 @@ public class NotificationGuts extends FrameLayout {
     @Override
     protected void onFinishInflate() {
         super.onFinishInflate();
-        mBackground = mContext.getDrawable(R.drawable.notification_guts_bg);
+        mBackground = mContext.getDrawable(R.drawable.qs_background_primary);
         if (mBackground != null) {
             mBackground.setCallback(this);
         }
```



