



## 1.前言


在10.0的系统产品开发中，系统对于多窗口模式默认会有分屏功能的，但是在某些产品中，需要禁用分屏模式，所以需要在导航栏中  
 禁用长按recent的分屏模式功能，接下来分析下相关分屏模式的实现


## 2.SystemUI禁用长按recent键的分屏功能的核心类



```
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NavigationBarFragment.java
```

## 3.SystemUI禁用长按recent键的分屏功能的核心功能分析和实现


在Android应用程序中,导航栏(NavigationBarView)是一个重要的UI组件,默认位于屏幕底部,并提供了导航功能,让用户通过  
 按键导航功能，实现相关功能，通常用于在应用程序的不同页面之间进行快速切换。它提供了一种直观且易于使用的导航方式，  
 使用户可以轻松访问应用程序的各个模块。  
  底部导航栏的加载流程,是接下来分析的重点。 二,加载流程 创建导航栏视图,并添加到窗口上:  
   系统导航栏的创建是在StatusBar的makeStatusBarView方法中  
 NavigationBarController.java，在创建完StatusBar所对应的视图之后，会调用IWindowManager的hasNavigationBar  
 方法来判断系统是否存在导航栏，如果存在则会调用createNavigationBar方法，该方法会进一步调用  
 NavigationBarFragment的静态方法create来创建导航栏视图，所以接下来关于按键的点击 长按事件都是在  
 NavigationBarFragment中定义的，接下来重点分析下NavigationBarFragment中的相关源码


## 3.1 NavigationBarFragment.java相关源码分析


在SystemUI禁用长按recent键的分屏功能的实现中，在通过上述的分析中得知，  
 按键的点击 长按事件都是在NavigationBarFragment中定义的，接下来就来分析下核心源码



```
   @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            Bundle savedInstanceState) {
        return inflater.inflate(R.layout.navigation_bar, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mNavigationBarView = (NavigationBarView) view;
        final Display display = view.getDisplay();
        // It may not have display when running unit test.
        if (display != null) {
            mDisplayId = display.getDisplayId();
            mIsOnDefaultDisplay = mDisplayId == Display.DEFAULT_DISPLAY;
        }

        mNavigationBarView.setComponents(mStatusBar.getPanel(), mAssistManager);
        mNavigationBarView.setDisabledFlags(mDisabledFlags1);
        mNavigationBarView.setOnVerticalChangedListener(this::onVerticalChanged);
        mNavigationBarView.setOnTouchListener(this::onNavigationTouch);
        if (savedInstanceState != null) {
            mNavigationBarView.getLightTransitionsController().restoreState(savedInstanceState);
        }
        mNavigationBarView.setNavigationIconHints(mNavigationIconHints);
        mNavigationBarView.setWindowVisible(isNavBarWindowVisible());

        prepareNavigationBarView();
        checkNavBarModes();
        notifyNavigationBarScreenOn();

        mOverviewProxyService.addCallback(mOverviewProxyListener);
        updateSystemUiStateFlags(-1);
        android.util.Log.d("dong","onViewCreated:");
        // Currently there is no accelerometer sensor on non-default display.
        if (mIsOnDefaultDisplay) {
            mNavigationBarView.getRotateSuggestionButton().setListener(mRotationButtonListener);

            final RotationButtonController rotationButtonController =
                    mNavigationBarView.getRotationButtonController();
            rotationButtonController.addRotationCallback(mRotationWatcher);

            // Reset user rotation pref to match that of the WindowManager if starting in locked
            // mode. This will automatically happen when switching from auto-rotate to locked mode.
            if (display != null && rotationButtonController.isRotationLocked()) {
                rotationButtonController.setRotationLockedAtAngle(display.getRotation());
            }
        } else {
            mDisabledFlags2 |= StatusBarManager.DISABLE2_ROTATE_SUGGESTIONS;
        }
        setDisabled2Flags(mDisabledFlags2);

        mScreenDecorations = SysUiServiceProvider.getComponent(getContext(),
                ScreenDecorations.class);
        //UNISOC: Modify for bug 1373209
        if (mScreenDecorations != null) {
            getBarTransitions().addDarkIntensityListener(mScreenDecorations);
        }
    }
```

在SystemUI禁用长按recent键的分屏功能的实现中，在通过上述的分析中得知，  
 在NavigationBarFragment.java中的上述源码中，在onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,  
             Bundle savedInstanceState)和onViewCreated(View view, @Nullable Bundle savedInstanceState)  
 中负责构建关于NavigationBarView的布局，而在prepareNavigationBarView()中来绑定导航栏三键的  
 点击和长按事件，接下来分析下prepareNavigationBarView()中的核心按键事件



```
    private void prepareNavigationBarView() {
        mNavigationBarView.reorient();

        ButtonDispatcher recentsButton = mNavigationBarView.getRecentsButton();
        recentsButton.setOnClickListener(this::onRecentsClick);
        recentsButton.setOnTouchListener(this::onRecentsTouch);
        recentsButton.setLongClickable(true);
        recentsButton.setOnLongClickListener(this::onLongPressBackRecents);

        ButtonDispatcher backButton = mNavigationBarView.getBackButton();
        backButton.setLongClickable(true);

        ButtonDispatcher homeButton = mNavigationBarView.getHomeButton();
        homeButton.setOnTouchListener(this::onHomeTouch);
        homeButton.setOnLongClickListener(this::onHomeLongClick);

        ButtonDispatcher accessibilityButton = mNavigationBarView.getAccessibilityButton();
        accessibilityButton.setOnClickListener(this::onAccessibilityClick);
        accessibilityButton.setOnLongClickListener(this::onAccessibilityLongClick);
        updateAccessibilityServicesState(mAccessibilityManager);

        updateScreenPinningGestures();
    }
```

在SystemUI禁用长按recent键的分屏功能的实现中，在通过上述的分析中得知，  
 在NavigationBarFragment.java中的上述源码中，在prepareNavigationBarView()中定义  
 导航按键事件中，在ButtonDispatcher recentsButton就是关于最近任务导航键的长按事件  
 而这个长按事件就是onLongPressBackRecents，而在onLongPressBackRecents中会调用  
 onLongPressNavigationButtons(v, R.id.back, R.id.recent\_apps)这个方法，  
 而它的代码解析中，会最终调用onLongPressRecents()在这个方法中，会最终  
 调用api来传递分屏事件的，



```
    private boolean onLongPressRecents() {

        if (mRecents == null || !ActivityTaskManager.supportsMultiWindow(getContext())
                || (mDivider != null ? !mDivider.getView().getSnapAlgorithm().isSplitScreenFeasible() : true) //UNISOC: Modify for bug 1373209
                || ActivityManager.isLowRamDeviceStatic()
                // If we are connected to the overview service, then disable the recents button
                || mOverviewProxyService.getProxy() != null) {
            return false;
        }

        /* UNISOC: Bug 1074234, 885650, Super power feature @{ */
        if (SprdPowerManagerUtil.isSuperPower()) {
            Log.d(TAG, "mRecentsClickListener SUPPORT_SUPER_POWER_SAVE ignore!");
            return false;
        }
        /* @} */

        return mStatusBar.toggleSplitScreenMode(MetricsEvent.ACTION_WINDOW_DOCK_LONGPRESS,
                MetricsEvent.ACTION_WINDOW_UNDOCK_LONGPRESS);
    }

```

在SystemUI禁用长按recent键的分屏功能的实现中，在通过上述的分析中得知，  
 在NavigationBarFragment.java中的上述源码中，在onLongPressRecents() 中  
 最终通过返回mStatusBar.toggleSplitScreenMode(MetricsEvent.ACTION\_WINDOW\_DOCK\_LONGPRESS,  
                 MetricsEvent.ACTION\_WINDOW\_UNDOCK\_LONGPRESS)  
 来作为是否响应分屏功能，所以可以注释掉这个方法的响应事件，具体修改为



```
    private boolean onLongPressRecents() {
//add core start
if(true)return false;
//add core end
        if (mRecents == null || !ActivityTaskManager.supportsMultiWindow(getContext())
                || (mDivider != null ? !mDivider.getView().getSnapAlgorithm().isSplitScreenFeasible() : true) //UNISOC: Modify for bug 1373209
                || ActivityManager.isLowRamDeviceStatic()
                // If we are connected to the overview service, then disable the recents button
                || mOverviewProxyService.getProxy() != null) {
            return false;
        }

        /* UNISOC: Bug 1074234, 885650, Super power feature @{ */
        if (SprdPowerManagerUtil.isSuperPower()) {
            Log.d(TAG, "mRecentsClickListener SUPPORT_SUPER_POWER_SAVE ignore!");
            return false;
        }
        /* @} */

        return mStatusBar.toggleSplitScreenMode(MetricsEvent.ACTION_WINDOW_DOCK_LONGPRESS,
                MetricsEvent.ACTION_WINDOW_UNDOCK_LONGPRESS);
    }
```

在SystemUI禁用长按recent键的分屏功能的实现中，在通过上述的分析中得知，  
 在NavigationBarFragment.java中的上述源码中，在onLongPressRecents() 中  
 通过增加if(true)return false;然后就消耗掉recent的长按事件，就不会响应分屏功能了



