






### 1.概述


在10.0的系统产品开发中，在定制化开发中，由于去掉了通过按键进入工厂模式，所以需要通过暗码进入工厂测试模式  
 所以就打算通过拨号盘输入暗码进入工厂模式


### 2.电话拨号盘(Dialer app中)通过暗码进入工厂测试模式的核心类



```
packages\apps\Dialer\java\com\android\dialer\dialpadview\DialpadFragment.java
packages/apps/Dialer/java/com/android/dialer/app/DialtactsActivity.java

```

### 3.电话拨号盘(Dialer app中)通过暗码进入工厂测试模式核心功能实现和分析


### 3.1DialtactsActivity.java关于拨号盘功能分析


在电话app Dialer中在拨号盘页面通过adb shell 命令 发现DialtactsActivity.java 就是处理拨号相关的页面的  
 路径为:packages/apps/Dialer/java/com/android/dialer/app/DialtactsActivity.java



```
public class DialtactsActivity extends TransactionSafeActivity
    implements View.OnClickListener,
        DialpadFragment.OnDialpadQueryChangedListener,
        OnListFragmentScrolledListener,
        CallLogFragment.HostInterface,
        CallLogAdapter.OnActionModeStateChangedListener,
        ContactsFragment.OnContactsListScrolledListener,
        DialpadFragment.HostInterface,
        OldSpeedDialFragment.HostInterface,
        OnDragDropListener,
        OnPhoneNumberPickerActionListener,
        PopupMenu.OnMenuItemClickListener,
        ViewPager.OnPageChangeListener,
        ActionBarController.ActivityUi,
        PhoneNumberInteraction.InteractionErrorListener,
        PhoneNumberInteraction.DisambigDialogDismissedListener,
        ActivityCompat.OnRequestPermissionsResultCallback,
        DialpadListener,
        SearchFragmentListener,
        OnContactSelectedListener {

  /** Listener used to send search queries to the phone search fragment. */
  private final TextWatcher phoneSearchQueryTextListener =
      new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
          final String newText = s.toString();
          if (newText.equals(searchQuery)) {
            // If the query hasn't changed (perhaps due to activity being destroyed
 // and restored, or user launching the same DIAL intent twice), then there is
 // no need to do anything here.
 return;
 }

 if (count != 0) {
 PerformanceReport.recordClick(UiAction.Type.TEXT\_CHANGE\_WITH\_INPUT);
 }

 LogUtil.v("DialtactsActivity.onTextChanged", "called with new query: " + newText);
 LogUtil.v("DialtactsActivity.onTextChanged", "previous query: " + searchQuery);
 searchQuery = newText;

 // Show search fragment only when the query string is changed to non-empty text.
 if (!TextUtils.isEmpty(newText)) {
 // Call enterSearchUi only if we are switching search modes, or showing a search
 // fragment for the first time.
 final boolean sameSearchMode =
 (isDialpadShown && inDialpadSearch) || (!isDialpadShown && inRegularSearch);
 if (!sameSearchMode) {
 enterSearchUi(isDialpadShown, searchQuery, true /\* animate \*/);
 }
 }

 if (newSearchFragment != null && newSearchFragment.isVisible()) {
 newSearchFragment.setQuery(searchQuery, getCallInitiationType());
 }
 }

 @Override
 public void afterTextChanged(Editable s) {}
 };

 @Override
 public void onClick(View view) {
 int resId = view.getId();
 if (resId == R.id.floating\_action\_button) {
 if (!isDialpadShown) {
 LogUtil.i(
 "DialtactsActivity.onClick", "floating action button clicked, going to show dialpad");
 PerformanceReport.recordClick(UiAction.Type.OPEN\_DIALPAD);
 inCallDialpadUp = false;
 showDialpadFragment(true);
 PostCall.closePrompt();
 } else {
 LogUtil.i(
 "DialtactsActivity.onClick",
 "floating action button clicked, but dialpad is already showing");
 }
 } else if (resId == R.id.voice\_search\_button) {
 try {
 startActivityForResult(
 new Intent(RecognizerIntent.ACTION\_RECOGNIZE\_SPEECH),
 ActivityRequestCodes.DIALTACTS\_VOICE\_SEARCH);
 } catch (ActivityNotFoundException e) {
 Toast.makeText(
 DialtactsActivity.this, R.string.voice\_search\_not\_available, Toast.LENGTH\_SHORT)
 .show();
 }
 } else if (resId == R.id.dialtacts\_options\_menu\_button) {
 overflowMenu.show();
 } else {
 Assert.fail("Unexpected onClick event from " + view);
 }
 }

 /\*\*
 \* Initiates a fragment transaction to show the dialpad fragment. Animations and other visual
 \* updates are handled by a callback which is invoked after the dialpad fragment is shown.
 \*
 \* @see #onDialpadShown
 \*/
 private void showDialpadFragment(boolean animate) {
 LogUtil.i("DialtactActivity.showDialpadFragment", "animate: %b", animate);
 if (isDialpadShown) {
 LogUtil.i("DialtactsActivity.showDialpadFragment", "dialpad already shown");
 return;
 }
 if (stateSaved) {
 LogUtil.i("DialtactsActivity.showDialpadFragment", "state already saved");
 return;
 }
 isDialpadShown = true;

 listsFragment.setUserVisibleHint(false);

 final FragmentTransaction ft = getFragmentManager().beginTransaction();
 if (dialpadFragment == null) {
 dialpadFragment = new DialpadFragment();
 ft.add(R.id.dialtacts\_container, dialpadFragment, TAG\_DIALPAD\_FRAGMENT);
 } else {
 ft.show(dialpadFragment);
 }

 dialpadFragment.setAnimate(animate);
 Logger.get(this).logScreenView(ScreenEvent.Type.DIALPAD, this);
 ft.commit();

 if (animate) {
 floatingActionButtonController.scaleOut();
 maybeEnterSearchUi();
 } else {
 floatingActionButtonController.scaleOut();
 maybeEnterSearchUi();
 }
 actionBarController.onDialpadUp();

 Assert.isNotNull(listsFragment.getView()).animate().alpha(0).withLayer();

 // adjust the title, so the user will know where we're at when the activity start/resumes.
    setTitle(R.string.launcherDialpadActivityLabel);
  }

  @Override
  public void getLastOutgoingCall(LastOutgoingCallCallback callback) {
    DialerExecutorComponent.get(this)
        .dialerExecutorFactory()
        .createUiTaskBuilder(
            getFragmentManager(), "Query last phone number", Calls::getLastOutgoingCall)
        .onSuccess(output -> callback.lastOutgoingCall(output))
        .build()
        .executeParallel(this);
  }

  /** Callback from child DialpadFragment when the dialpad is shown. */
  @Override
  public void onDialpadShown() {
    LogUtil.enterBlock("DialtactsActivity.onDialpadShown");
    Assert.isNotNull(dialpadFragment);
    if (dialpadFragment.getAnimate()) {
      Assert.isNotNull(dialpadFragment.getView()).startAnimation(slideIn);
    } else {
      dialpadFragment.setYFraction(0);
    }

    updateSearchFragmentPosition();
  }

  /**
   * Initiates animations and other visual updates to hide the dialpad. The fragment is hidden in a
   * callback after the hide animation ends.
   *
   * @see #commitDialpadFragmentHide
   */
  private void hideDialpadFragment(boolean animate, boolean clearDialpad) {
    LogUtil.enterBlock("DialtactsActivity.hideDialpadFragment");
    if (dialpadFragment == null || dialpadFragment.getView() == null) {
      return;
    }
    if (clearDialpad) {
      // Temporarily disable accessibility when we clear the dialpad, since it should be
      // invisible and should not announce anything.
      dialpadFragment
          .getDigitsWidget()
          .setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
      dialpadFragment.clearDialpad();
      dialpadFragment
          .getDigitsWidget()
          .setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_AUTO);
    }
    if (!isDialpadShown) {
      return;
    }
    isDialpadShown = false;
    dialpadFragment.setAnimate(animate);
    listsFragment.setUserVisibleHint(true);
    listsFragment.sendScreenViewForCurrentPosition();

    updateSearchFragmentPosition();

    floatingActionButtonController.align(getFabAlignment(), animate);
    if (animate) {
      dialpadFragment.getView().startAnimation(slideOut);
    } else {
      commitDialpadFragmentHide();
    }

    actionBarController.onDialpadDown();

    // reset the title to normal.
    setTitle(R.string.launcherActivityLabel);
  }

  /** Finishes hiding the dialpad fragment after any animations are completed. */
  private void commitDialpadFragmentHide() {
    if (!stateSaved && dialpadFragment != null && !dialpadFragment.isHidden() && !isDestroyed()) {
      final FragmentTransaction ft = getFragmentManager().beginTransaction();
      ft.hide(dialpadFragment);
      ft.commit();
    }
    floatingActionButtonController.scaleIn();
  }

  private void updateSearchFragmentPosition() {
    if (newSearchFragment != null) {
      int animationDuration = getResources().getInteger(R.integer.dialpad_slide_in_duration);
      int actionbarHeight = getResources().getDimensionPixelSize(R.dimen.action_bar_height_large);
      int shadowHeight = getResources().getDrawable(R.drawable.search_shadow).getIntrinsicHeight();
      int start = isDialpadShown() ? actionbarHeight - shadowHeight : 0;
      int end = isDialpadShown() ? 0 : actionbarHeight - shadowHeight;
      newSearchFragment.animatePosition(start, end, animationDuration);
    }
  }
  private void showDialpadFragment(boolean animate) {
    LogUtil.i("DialtactActivity.showDialpadFragment", "animate: %b", animate);
    if (isDialpadShown) {
      LogUtil.i("DialtactsActivity.showDialpadFragment", "dialpad already shown");
      return;
    }
    if (stateSaved) {
      LogUtil.i("DialtactsActivity.showDialpadFragment", "state already saved");
      return;
    }
    isDialpadShown = true;

    listsFragment.setUserVisibleHint(false);

    final FragmentTransaction ft = getFragmentManager().beginTransaction();
    if (dialpadFragment == null) {
      dialpadFragment = new DialpadFragment();
      ft.add(R.id.dialtacts_container, dialpadFragment, TAG_DIALPAD_FRAGMENT);
    } else {
      ft.show(dialpadFragment);
    }

    dialpadFragment.setAnimate(animate);
    Logger.get(this).logScreenView(ScreenEvent.Type.DIALPAD, this);
    ft.commit();

    if (animate) {
      floatingActionButtonController.scaleOut();
      maybeEnterSearchUi();
    } else {
      floatingActionButtonController.scaleOut();
      maybeEnterSearchUi();
    }
    actionBarController.onDialpadUp();

    Assert.isNotNull(listsFragment.getView()).animate().alpha(0).withLayer();

    // adjust the title, so the user will know where we're at when the activity start/resumes.
    setTitle(R.string.launcherDialpadActivityLabel);
  }

```

在通过上述代码分析发现  
 howDialpadFragment 方法，用来加载显示拨号盘，因此入口就从 showDialpadFragment  
 具体实现在 DialpapFragment 中，看到 DialpapFragment 实现了 TextWatcher，TextWatcher 有 3 个重要方法，分别为：beforeTextChanged，onTextChanged 和 afterTextChanged，重点看 afterTextChanged 方法。  
 DialpapFragment.java 路径为:  
 packages\apps\Dialer\java\com\android\dialer\dialpadview\DialpadFragment.java


### 3.2下面来看DialpadFragment.java的源码



```
public class DialpadFragment extends Fragment
    implements View.OnClickListener,
        View.OnLongClickListener,
        View.OnKeyListener,
        AdapterView.OnItemClickListener,
        TextWatcher,
        PopupMenu.OnMenuItemClickListener,
        DialpadKeyButton.OnPressedListener {

  @Override
  public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    wasEmptyBeforeTextChange = TextUtils.isEmpty(s);
  }

  @Override
  public void onTextChanged(CharSequence input, int start, int before, int changeCount) {
    if (wasEmptyBeforeTextChange != TextUtils.isEmpty(input)) {
      final Activity activity = getActivity();
      if (activity != null) {
        activity.invalidateOptionsMenu();
        updateMenuOverflowButton(wasEmptyBeforeTextChange);
      }
      updateDialpadHint();
    }

    // DTMF Tones do not need to be played here any longer -
    // the DTMF dialer handles that functionality now.
  }

  @Override
  public void afterTextChanged(Editable input) {
    // When DTMF dialpad buttons are being pressed, we delay SpecialCharSequenceMgr sequence,
    // since some of SpecialCharSequenceMgr's behavior is too abrupt for the "touch-down"
    // behavior.
    if (!digitsFilledByIntent
        && SpecialCharSequenceMgr.handleChars(getActivity(), input.toString(), digits)) {
      // A special sequence was entered, clear the digits
      digits.getText().clear();
    }

    if (isDigitsEmpty()) {
      digitsFilledByIntent = false;
      digits.setCursorVisible(false);
    }

    if (dialpadQueryListener != null) {
      dialpadQueryListener.onDialpadQueryChanged(digits.getText().toString());
    }

    updateDeleteButtonEnabledState();
  }

```

在DialpadFragment 类中关于对拨号盘输入的监控  
 所以就在afterTextChanged（）中来监听输入字符然后做处理  
 具体修改如下:



```
@Override
  public void afterTextChanged(Editable input) {
    // When DTMF dialpad buttons are being pressed, we delay SpecialCharSequenceMgr sequence,
    // since some of SpecialCharSequenceMgr's behavior is too abrupt for the "touch-down"
    // behavior.

// add code start
	           Log.d(TAG, "input: " + input);
               if(input!=null && input.toString().length()>0){
                    String input_value = input.toString().replace(",", "");
                       Log.d(TAG, "input: " + input);
                        if (input_value.length() > 8 && input_value.startsWith("#\*#\*") && input_value.endsWith("\*#\*#")) {
                               String secretCode = input_value.substring(4, input_value.length() - 4);
                               Log.d(TAG, "secretCode@@: " + secretCode);
                         // UNISOC: add for bug1255602 & 1267172
                          sendBroadcastBySecretCode(secretCode);
						  return;
                       }
               }
// add code end 

    if (!digitsFilledByIntent
        && SpecialCharSequenceMgr.handleChars(getActivity(), input.toString(), digits)) {
      // A special sequence was entered, clear the digits
      digits.getText().clear();
    }

    if (isDigitsEmpty()) {
      digitsFilledByIntent = false;
      digits.setCursorVisible(false);
    }

    if (dialpadQueryListener != null) {
      dialpadQueryListener.onDialpadQueryChanged(digits.getText().toString());
    }

    updateDeleteButtonEnabledState();
  }
// add code start
    private void sendBroadcastBySecretCode(String secretCode) {
        Log.d(TAG, "secretCode: " + secretCode);
        if (secretCode != null) {
            if (secretCode.equals("83789") || secretCode.equals("654987")) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.setClassName("com.sprd.validationtools", "com.sprd.validationtools.ValidationToolsMainActivity");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getActivity().startActivity(intent);
                              getActivity().finish();
            } else if (secretCode.equals("83781") || secretCode.equals("83782") || secretCode.equals("33284")) {
                Intent intent1 = new Intent(Intent.ACTION_MAIN);
                intent1.setClassName("com.sprd.engineermode", "com.sprd.engineermode.EngineerModeActivity");
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getActivity().startActivity(intent1);
                               getActivity().finish();
            }
        }
     }
// add code end

```

通过在afterTextChanged中判断当前输入什么字符，然后就可以跳转到对应的页面所以就完成了功能  
 添加完验证即可





