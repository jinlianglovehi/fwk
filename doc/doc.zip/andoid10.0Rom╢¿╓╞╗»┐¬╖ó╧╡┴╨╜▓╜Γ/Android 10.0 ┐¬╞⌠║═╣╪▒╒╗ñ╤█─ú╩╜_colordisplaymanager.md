






### 1.概述


在10.0系统的产品定制化中，由于一些定制化开发设备中，需要护眼模式，而护眼模式功能开启和关闭 也需要提供接口供app调用，这就需要在系统api中自定义的服务中，提供开启关闭护眼模式的接口，但产品前提是必须设备支持护眼模式


### 2.开启和关闭护眼模式的核心类



```
frameworks/base/core/java/android/hardware/display/ColorDisplayManager.java

```

### 3.开启和关闭护眼模式的核心功能分析和实现


### 3.1ColorDisplayManager关于护眼模式相关api调用的分析



```
 @SystemApi
 @SystemService(Context.COLOR_DISPLAY_SERVICE)
 public final class ColorDisplayManager {
     /**
      * @hide
      */
     @Retention(RetentionPolicy.SOURCE)
     @IntDef({ AUTO_MODE_DISABLED, AUTO_MODE_CUSTOM_TIME, AUTO_MODE_TWILIGHT })
     public @interface AutoMode {}
 
     /**
      * Auto mode value to prevent Night display from being automatically activated. It can still
       * be activated manually via {@link #setNightDisplayActivated(boolean)}.
       *
       * @see #setNightDisplayAutoMode(int)
       *
       * @hide
       */
      @SystemApi
      public static final int AUTO_MODE_DISABLED = 0;
      /**
       * Auto mode value to automatically activate Night display at a specific start and end time.
       *
       * @see #setNightDisplayAutoMode(int)
       * @see #setNightDisplayCustomStartTime(LocalTime)
       * @see #setNightDisplayCustomEndTime(LocalTime)
       *
       * @hide
       */
      @SystemApi
      public static final int AUTO_MODE_CUSTOM_TIME = 1;
      /**
       * Auto mode value to automatically activate Night display from sunset to sunrise.
       *
       * @see #setNightDisplayAutoMode(int)
       *
       * @hide
       */
      @SystemApi
      public static final int AUTO_MODE_TWILIGHT = 2;
       /**
       * Sets the current auto mode value controlling when Night display will be automatically
       * activated. One of {@link #AUTO\_MODE\_DISABLED}, {@link #AUTO\_MODE\_CUSTOM\_TIME}, or
       * {@link #AUTO\_MODE\_TWILIGHT}.
       *
       * @param autoMode the new auto mode to use
       * @return {@code true} if new auto mode was set successfully
       *
       * @hide
       */
      @SystemApi
      @RequiresPermission(Manifest.permission.CONTROL_DISPLAY_COLOR_TRANSFORMS)
      public boolean setNightDisplayAutoMode(@AutoMode int autoMode) {
          if (autoMode != AUTO_MODE_DISABLED
                  && autoMode != AUTO_MODE_CUSTOM_TIME
                  && autoMode != AUTO_MODE_TWILIGHT) {
              throw new IllegalArgumentException("Invalid autoMode: " + autoMode);
          }
          if (mManager.getNightDisplayAutoMode() != autoMode) {
              getMetricsLogger().write(new LogMaker(
                      MetricsEvent.ACTION_NIGHT_DISPLAY_AUTO_MODE_CHANGED)
                      .setType(MetricsEvent.TYPE_ACTION)
                      .setSubtype(autoMode));
          }
          return mManager.setNightDisplayAutoMode(autoMode);
      }
  
      /**
       * Returns the local time when Night display will be automatically activated when using
       * {@link ColorDisplayManager#AUTO\_MODE\_CUSTOM\_TIME}.
       *
       * @hide
       */
      public @NonNull LocalTime getNightDisplayCustomStartTime() {
          return mManager.getNightDisplayCustomStartTime().getLocalTime();
      }
   /**
       * Sets the local time when Night display will be automatically deactivated when using
       * {@link #AUTO\_MODE\_CUSTOM\_TIME}.
       *
       * @param endTime the local time to automatically deactivate Night display
       * @return {@code true} if the new custom end time was set successfully
       *
       * @hide
       */
      @SystemApi
      @RequiresPermission(Manifest.permission.CONTROL_DISPLAY_COLOR_TRANSFORMS)
      public boolean setNightDisplayCustomEndTime(@NonNull LocalTime endTime) {
          if (endTime == null) {
              throw new IllegalArgumentException("endTime cannot be null");
          }
          getMetricsLogger().write(new LogMaker(
                  MetricsEvent.ACTION_NIGHT_DISPLAY_AUTO_MODE_CUSTOM_TIME_CHANGED)
                  .setType(MetricsEvent.TYPE_ACTION)
                  .setSubtype(1));
          return mManager.setNightDisplayCustomEndTime(new Time(endTime));
      }

```

从ColorDisplayManager的常量中发现  
 public static final int AUTO\_MODE\_DISABLED = 0;  
 public static final int AUTO\_MODE\_CUSTOM\_TIME = 1;  
 这两个模式就是关于护眼模式的常量  
 在setNightDisplayAutoMode(int)就是调用这两种模式进行切换的


实现系统护眼模式用两种方法  
 一种是通过发送广播的方式 一种是通过调用系统api的方式实现护眼模式


第一种 通过设置系统属性night\_display\_activated实现



```
设置开启关闭护眼模式
     public void sysTurnOnEyeComfort(boolean on) throws RemoteException {
        		SystemProperties.set("persist.sys.EyeComfortIsEnable", on ? "true": "false");
        Settings.Secure.putIntForUser(this.mContext.getContentResolver(), "night\_display\_activated", on ? 1 : 0, mContext.getUserId());
        }
如果设备支持这个广播模式 就可以实现

     public boolean isSysEyeComfortTurnedOn() throws RemoteException {
-        boolean defenable="true".equals(SystemProperties.get("persist.sys.EyeComfortIsEnable","false"));
        return defenable;
     }

```

通过上述方法可以得知首选要设置系统属性值，  
 persist.sys.EyeComfortIsEnable的值开启或关闭  
 然后在设置系统数据库中night\_display\_activated的值开启和关闭  
 设置这两个值以后就可以设置开启关闭护眼模式的功能


第二种方法  
 通过ColorDisplayManager.java 设置显示颜色来实现


调用ColorDisplayManager .setNightDisplayAutoMode的方法来实现护眼模式开启关闭功能



```
    public void sysTurnOnEyeComfort(boolean on) throws RemoteException {

+               ColorDisplayManager mManager = mContext.getSystemService(ColorDisplayManager.class);
+        if ("1".equals(Settings.Global.getString(mContext.getContentResolver(),
+                Settings.Global.NIGHT_DISPLAY_FORCED_AUTO_MODE_AVAILABLE))
+                && mManager.getNightDisplayAutoModeRaw() == -1) {
+            mManager.setNightDisplayAutoMode(ColorDisplayManager.AUTO_MODE_CUSTOM_TIME);
+            Log.i("NightDisplayTile", "Enrolled in forced night display auto mode");
         }
+           mManager.setNightDisplayActivated(on);
     }
 
     @Override
     public boolean isSysEyeComfortTurnedOn() throws RemoteException {

+               ColorDisplayManager mManager = mContext.getSystemService(ColorDisplayManager.class);
+               return mManager.isNightDisplayActivated();
     }

```

两种方式看设备支持哪种方式  
 在通过调用setNightDisplayAutoMode的api接口时，首选要权限Manifest.permission.CONTROL\_DISPLAY\_COLOR\_TRANSFORMS  
 然后根据开关设置是否开启护眼模式



```
@RequiresPermission(Manifest.permission.CONTROL_DISPLAY_COLOR_TRANSFORMS)
      public boolean setNightDisplayAutoMode(@AutoMode int autoMode) {
          if (autoMode != AUTO_MODE_DISABLED
                  && autoMode != AUTO_MODE_CUSTOM_TIME
                  && autoMode != AUTO_MODE_TWILIGHT) {
              throw new IllegalArgumentException("Invalid autoMode: " + autoMode);
          }
          if (mManager.getNightDisplayAutoMode() != autoMode) {
              getMetricsLogger().write(new LogMaker(
                      MetricsEvent.ACTION_NIGHT_DISPLAY_AUTO_MODE_CHANGED)
                      .setType(MetricsEvent.TYPE_ACTION)
                      .setSubtype(autoMode));
          }
          return mManager.setNightDisplayAutoMode(autoMode);
      }

```




