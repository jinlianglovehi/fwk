



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[系统SystemUI下拉状态栏UI定制第十讲 本篇主要讲述在下拉状态栏通知栏添加 通知消息的文字内容](#%E7%B3%BB%E7%BB%9FSystemUI%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8FUI%E5%AE%9A%E5%88%B6%E7%AC%AC%E5%8D%81%E8%AE%B2%20%E6%9C%AC%E7%AF%87%E4%B8%BB%E8%A6%81%E8%AE%B2%E8%BF%B0%E5%9C%A8%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8F%E9%80%9A%E7%9F%A5%E6%A0%8F%E6%B7%BB%E5%8A%A0%20%E9%80%9A%E7%9F%A5%E6%B6%88%E6%81%AF%E7%9A%84%E6%96%87%E5%AD%97%E5%86%85%E5%AE%B9)


[2.核心代码](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.核心代码分析和功能实现](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E5%92%8C%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1下拉状态栏中通知栏添加通知消息 文字 通知栏布局就是在NotificationStackScrollLayout.java](#%C2%A03.1%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8F%E4%B8%AD%E9%80%9A%E7%9F%A5%E6%A0%8F%E6%B7%BB%E5%8A%A0%E9%80%9A%E7%9F%A5%E6%B6%88%E6%81%AF%20%E6%96%87%E5%AD%97%20%E9%80%9A%E7%9F%A5%E6%A0%8F%E5%B8%83%E5%B1%80%E5%B0%B1%E6%98%AF%E5%9C%A8NotificationStackScrollLayout.java)


[3.2 根据下拉状态展开或收缩 添加移除通知头](#3.2%20%E6%A0%B9%E6%8D%AE%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E5%B1%95%E5%BC%80%E6%88%96%E6%94%B6%E7%BC%A9%20%E6%B7%BB%E5%8A%A0%E7%A7%BB%E9%99%A4%E9%80%9A%E7%9F%A5%E5%A4%B4)


[3.3 StatusBar.java 中下拉状态栏的时候调用 onStatusExpand()](#3.3%20StatusBar.java%20%E4%B8%AD%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8F%E7%9A%84%E6%97%B6%E5%80%99%E8%B0%83%E7%94%A8%20onStatusExpand%28%29)




---



## 1.概述


#### 系统SystemUI下拉状态栏UI定制第十讲 本篇主要讲述在下拉状态栏通知栏添加 通知消息的文字内容


## 2.核心代码



```
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\notification\stack\NotificationStackScrollLayout.java
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone/StatusBar.java
```

## 3.核心代码分析和功能实现


####  3.1下拉状态栏中通知栏添加通知消息 文字 通知栏布局就是在NotificationStackScrollLayout.java


路径:frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\notification\stack\NotificationStackScrollLayout.java  
 首选自定义通知栏标题



```

package com.android.systemui.statusbar;

import android.annotation.ColorInt;
import android.annotation.StringRes;
import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.android.systemui.R;
import com.android.systemui.statusbar.notification.row.StackScrollerDecorView;
import com.android.systemui.statusbar.notification.stack.ExpandableViewState;

public class NotificationTipView extends StackScrollerDecorView {

    private TextView mEmptyText;
    private @StringRes int mText = R.string.notification_message_text;

    public NotificationTipView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mEmptyText.setText(mText);
    }

    @Override
    protected View findContentView() {
        return findViewById(R.id.notifications_tip);
    }

    @Override
    protected View findSecondaryView() {
        return null;
    }

    public void setTextColor(@ColorInt int color) {
        mEmptyText.setTextColor(color);
    }

    public void setText(@StringRes int text) {
        mText = text;
        mEmptyText.setText(mText);
    }

    public int getTextResource() {
        return mText;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mEmptyText = (TextView) findContentView();
    }

    @Override
    public ExpandableViewState createExpandableViewState() {
        return new EmptyShadeViewState();
    }

    public class EmptyShadeViewState extends ExpandableViewState {
        @Override
        public void applyToView(View view) {
            super.applyToView(view);
            if (view instanceof NotificationTipView) {
                NotificationTipView emptyShadeView = (NotificationTipView) view;
                boolean visible = this.clipTopAmount <= mEmptyText.getPaddingTop() * 0.6f;
                emptyShadeView.setContentVisible(visible && emptyShadeView.isVisible());
            }
        }
    }
}

在onFinishInflate()中添加通知栏通知头布局
    protected void onFinishInflate() {
        super.onFinishInflate();
       //通知头标题布局
        inflateNotificationTipView();
        inflateEmptyShadeView();
        inflateFooterView();
        mVisualStabilityManager.setVisibilityLocationProvider(this::isInVisibleLocation);
        if (mAllowLongPress) {
            setLongPressListener(mNotificationGutsManager::openGuts);
        }
    }

    private void inflateNotificationTipView() {
        NotificationTipView view = (NotificationTipView) LayoutInflater.from(mContext).inflate(
                R.layout.notifications_tip, this, false);
        view.setText(R.string.notification_message_text);
        setNotificationView(view);
    }

    public void setNotificationView(NotificationTipView noticationTipView) {
        if (mNotificationTipView != null) {
            removeView(mNotificationTipView);
        }
		mNotificationTipView = noticationTipView;
        addView(noticationTipView,0);
    }

    public void removeNotificationTipView(){
        if (mNotificationTipView != null) {
            removeView(mNotificationTipView);
			mNotificationTipView = null;
        }
    }

    @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
    public void updateFooterView(boolean visible, boolean showDismissView) {
        if (mFooterView == null) {
            return;
        }
        boolean animate = mIsExpanded && mAnimationsEnabled;
        if(mNotificationTipView!=null)mNotificationTipView.setVisible(visible,false);
        mFooterView.setVisible(visible, animate);
        mFooterView.setSecondaryVisible(showDismissView, animate);
    }

updateFooterView(）中添加标题头在无通知时也随着footview一起隐藏

    public void onExpansionExpand(boolean isShow) {
       if(mNotificationTipView == null&&!isShow){
           inflateNotificationTipView();
           mNotificationTipView.setVisible(true,false);
      }
	}
```

#### 3.2 根据下拉状态展开或收缩 添加移除通知头



```
NotificationPanelView.java中添加
    public void onStatusExpand(){
		mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(mIsExpand)mNotificationStackScroller.onExpansionExpand(mEntryManager.getNotificationData().getActiveNotifications().size() == 0);
            }
        },100);
	}

```

#### mIsExpand 在closeQs() 为false  在onExpandingStarted() 开始下滑为true


#### 3.3 StatusBar.java 中下拉状态栏的时候调用 onStatusExpand()



```
void makeExpandedVisible(boolean force) {
        if (SPEW) Log.d(TAG, "Make expanded visible: expanded visible=" + mExpandedVisible);
        if (!force && (mExpandedVisible || !mCommandQueue.panelsEnabled())) {
            return;
        }

        mExpandedVisible = true;

        // Expand the window to encompass the full screen in anticipation of the drag.
        // This is only possible to do atomically because the status bar is at the top of the screen!
        mStatusBarWindowController.setPanelVisible(true);
      +  mNotificationPanel.onStatusExpand();
        visibilityChanged(true);
        mCommandQueue.recomputeDisableFlags(mDisplayId, !force /* animate */);
        setInteracting(StatusBarManager.WINDOW_STATUS_BAR, true);
    }

void makeExpandedInvisible() {
        if (SPEW) Log.d(TAG, "makeExpandedInvisible: mExpandedVisible=" + mExpandedVisible
                + " mExpandedVisible=" + mExpandedVisible);

        if (!mExpandedVisible || mStatusBarWindow == null) {
            return;
        }

        // Ensure the panel is fully collapsed (just in case; bug 6765842, 7260868)
        mStatusBarView.collapsePanel(/*animate=*/ false, false /* delayed*/,
                1.0f /* speedUpFactor */);
        mNotificationPanel.closeQs();

        mExpandedVisible = false;
        visibilityChanged(false);

        // Shrink the window to the size of the status bar only
        mStatusBarWindowController.setPanelVisible(false);
        mStatusBarWindowController.setForceStatusBarVisible(false);

        // Close any guts that might be visible
        mGutsManager.closeAndSaveGuts(true /* removeLeavebehind */, true /* force */,
                true /* removeControls */, -1 /* x */, -1 /* y */, true /* resetMenu */);

        runPostCollapseRunnables();
        setInteracting(StatusBarManager.WINDOW_STATUS_BAR, false);
        if (!mNotificationActivityStarter.isCollapsingToShowActivityOverLockscreen()) {
            showBouncerIfKeyguard();
        } else if (DEBUG) {
            Log.d(TAG, "Not showing bouncer due to activity showing over lockscreen");
        }
        mCommandQueue.recomputeDisableFlags(
                mDisplayId, mNotificationPanel.hideStatusBarIconsWhenExpanded() /* animate */);

        // Trimming will happen later if Keyguard is showing - doing it here might cause a jank in
        // the bouncer appear animation.
        if (!mStatusBarKeyguardViewManager.isShowing()) {
            WindowManagerGlobal.getInstance().trimMemory(ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN);
        }
    }

```

收缩状态栏的时候 移除通知头 就是在mNotificationPanel.closeQs();中操作  
     public void closeQs() {  
         mIsExpand=false;  
         + mNotificationStackScroller.removeNotificationTipView();  
         cancelQsAnimation();  
         setQsExpansion(mQsMinExpansionHeight);  
     }



