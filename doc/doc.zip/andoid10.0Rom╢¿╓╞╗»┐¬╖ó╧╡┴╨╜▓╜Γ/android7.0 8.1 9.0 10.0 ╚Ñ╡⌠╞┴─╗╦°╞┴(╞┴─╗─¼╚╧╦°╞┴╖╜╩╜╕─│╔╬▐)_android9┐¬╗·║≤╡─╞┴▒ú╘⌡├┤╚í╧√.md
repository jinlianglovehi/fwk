






### 1.概述


在10.0的系统产品开发中，系统在开机后会默认进入锁屏界面，但是产品需求要求去掉锁屏方式，默认无锁屏，就是需要实现去掉屏幕锁屏功能


### 2.去掉屏幕锁屏(屏幕默认锁屏方式改成无)的核心类



```
frameworks/base/packages/SettingsProvider/res/values/defaults.xml
packages/apps/Settings/res/xml/security_settings_picker.xml
packages/apps/Settings/src/com/android/settings/password/ChooseLockGeneric.java

```

### 3.去掉屏幕锁屏(屏幕默认锁屏方式改成无)的核心功能分析和实现


实现去掉锁屏功能分析  
 实现这个功能要分两步 一需要在系统SettingsProvider设置禁用锁屏功能，二需要在系统Settings页面的安全菜单项里面去掉选择锁屏方式的其他功能


### 3.1 SettingsProvider禁用锁屏功能实现


在SettingsProvider中禁用锁屏的系统属性就是def\_lockscreen\_disabled 系统默认是true 就是  
 启用锁屏功能的，所以需要设置为false 就可以了，表示禁用锁屏功能  
 修改如下:



```
--- a/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
+++ b/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
@@ -84,7 +84,7 @@
     <integer name="def\_max\_sound\_trigger\_detection\_service\_ops\_per\_day" translatable="false">1000</integer>
     <integer name="def\_sound\_trigger\_detection\_service\_op\_timeout" translatable="false">15000</integer>
 
-    <bool name="def\_lockscreen\_disabled">false</bool>
+    <bool name="def\_lockscreen\_disabled">true</bool>
     <bool name="def\_device\_provisioned">false</bool>
     <integer name="def\_dock\_audio\_media\_enabled">1</integer>

```

3.2 Settings 去掉其他锁屏方式  
 在选择锁屏方式的页面就是security\_settings\_picker.xml，接下来要注释掉除了无的 其他锁屏方式



```
diff --git a/packages/apps/Settings/res/xml/security_settings_picker.xml b/packages/apps/Settings/res/xml/security_settings_picker.xml
old mode 100644
new mode 100755
index 2e6361aca4..2fc36b184d
--- a/packages/apps/Settings/res/xml/security_settings_picker.xml
+++ b/packages/apps/Settings/res/xml/security_settings_picker.xml
@@ -23,38 +23,38 @@
             android:title="@string/unlock\_set\_unlock\_off\_title"
             android:persistent="false"/>
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_set\_none"
             android:title="@string/unlock\_set\_unlock\_none\_title"
-            android:persistent="false"/>
+            android:persistent="false"/-->
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_set\_pattern"
             android:title="@string/unlock\_set\_unlock\_pattern\_title"
-            android:persistent="false"/>
+            android:persistent="false"/-->
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_set\_pin"
             android:title="@string/unlock\_set\_unlock\_pin\_title"
-            android:persistent="false"/>
+            android:persistent="false"/-->
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_set\_password"
             android:title="@string/unlock\_set\_unlock\_password\_title"
-            android:persistent="false"/>
+            android:persistent="false"/-->
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_set\_managed"
-            android:persistent="false"/>
+            android:persistent="false"/-->
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_skip\_fingerprint"
             android:title="@string/fingerprint\_unlock\_skip\_fingerprint"
-            android:persistent="false"/>
+            android:persistent="false"/-->
 
-    <com.android.settingslib.RestrictedPreference
+    <!--com.android.settingslib.RestrictedPreference
             android:key="unlock\_skip\_face"
             android:title="@string/face\_unlock\_skip\_face"
-            android:persistent="false"/>
+            android:persistent="false"/--> 
 </PreferenceScreen>

```

在security\_settings\_picker.xml只保留 unlock\_set\_unlock\_off\_title这个无锁的选项，其他的都默认去掉，注释掉其他选项即可  
 接下来在ChooseLockGeneric.java中这个设置锁屏方式的页面注释掉其他的锁屏方式的相关代码



```
diff --git a/packages/apps/Settings/src/com/android/settings/password/ChooseLockGeneric.java b/packages/apps/Settings/src/com/android/settings/password/C
hooseLockGeneric.java
old mode 100644
new mode 100755
index e9cc9b770a..4a84def4dc
--- a/packages/apps/Settings/src/com/android/settings/password/ChooseLockGeneric.java
+++ b/packages/apps/Settings/src/com/android/settings/password/ChooseLockGeneric.java
@@ -511,10 +511,10 @@ public class ChooseLockGeneric extends SettingsActivity {
 
             // Used for testing purposes
             findPreference(ScreenLockType.NONE.preferenceKey).setViewId(R.id.lock_none);
-            findPreference(KEY_SKIP_FINGERPRINT).setViewId(R.id.lock_none);
-            findPreference(KEY_SKIP_FACE).setViewId(R.id.lock_none);
-            findPreference(ScreenLockType.PIN.preferenceKey).setViewId(R.id.lock_pin);
-            findPreference(ScreenLockType.PASSWORD.preferenceKey).setViewId(R.id.lock_password);
+            //findPreference(KEY_SKIP_FINGERPRINT).setViewId(R.id.lock_none);
+            //findPreference(KEY_SKIP_FACE).setViewId(R.id.lock_none);
+            //findPreference(ScreenLockType.PIN.preferenceKey).setViewId(R.id.lock_pin);
+            //findPreference(ScreenLockType.PASSWORD.preferenceKey).setViewId(R.id.lock_password);
         }
 
         private String getFooterString() {
@@ -540,24 +540,24 @@ public class ChooseLockGeneric extends SettingsActivity {
 
         private void updatePreferenceText() {
             if (mForFingerprint) {
-                setPreferenceTitle(ScreenLockType.PATTERN,
+                /*setPreferenceTitle(ScreenLockType.PATTERN,
                         R.string.fingerprint_unlock_set_unlock_pattern);
                 setPreferenceTitle(ScreenLockType.PIN, R.string.fingerprint_unlock_set_unlock_pin);
                 setPreferenceTitle(ScreenLockType.PASSWORD,
-                        R.string.fingerprint_unlock_set_unlock_password);
+                        R.string.fingerprint_unlock_set_unlock_password);*/
             } else if (mForFace) {
-                setPreferenceTitle(ScreenLockType.PATTERN,
+                /*setPreferenceTitle(ScreenLockType.PATTERN,
                         R.string.face_unlock_set_unlock_pattern);
                 setPreferenceTitle(ScreenLockType.PIN, R.string.face_unlock_set_unlock_pin);
                 setPreferenceTitle(ScreenLockType.PASSWORD,
-                        R.string.face_unlock_set_unlock_password);
+                        R.string.face_unlock_set_unlock_password);*/
             }
 
             if (mManagedPasswordProvider.isSettingManagedPasswordSupported()) {
-                setPreferenceTitle(ScreenLockType.MANAGED,
-                        mManagedPasswordProvider.getPickerOptionTitle(mForFingerprint));
+                /*setPreferenceTitle(ScreenLockType.MANAGED,
+                        mManagedPasswordProvider.getPickerOptionTitle(mForFingerprint));*/
             } else {
-                removePreference(ScreenLockType.MANAGED.preferenceKey);
+                //removePreference(ScreenLockType.MANAGED.preferenceKey);
             }
 
             if (!(mForFingerprint && mIsSetNewPassword)) {
@@ -679,10 +679,10 @@ public class ChooseLockGeneric extends SettingsActivity {
                 return;
             }
 
-            setPreferenceSummary(ScreenLockType.PATTERN, R.string.secure_lock_encryption_warning);
+            /*setPreferenceSummary(ScreenLockType.PATTERN, R.string.secure_lock_encryption_warning);
             setPreferenceSummary(ScreenLockType.PIN, R.string.secure_lock_encryption_warning);
             setPreferenceSummary(ScreenLockType.PASSWORD, R.string.secure_lock_encryption_warning);
-            setPreferenceSummary(ScreenLockType.MANAGED, R.string.secure_lock_encryption_warning);
+            setPreferenceSummary(ScreenLockType.MANAGED, R.string.secure_lock_encryption_warning);*/
         }
 
         protected Intent getLockManagedPasswordIntent(byte[] password) {

```

通过在ChooseLockGeneric.java中这个设置锁屏方式的页面注释掉其他的锁屏方式的相关代码,和去掉关于设置其他锁屏方式的相关代码实现了去掉屏幕锁屏功能





