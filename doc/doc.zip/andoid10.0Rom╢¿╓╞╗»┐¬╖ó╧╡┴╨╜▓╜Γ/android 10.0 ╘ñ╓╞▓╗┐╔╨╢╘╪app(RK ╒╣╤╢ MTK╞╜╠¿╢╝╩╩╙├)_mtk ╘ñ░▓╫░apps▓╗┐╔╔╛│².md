






### 1.概述


在10.0的系统产品进行定制化开发新手来说，对怎么预制apk感觉很陌生，但是也很简单的，可以把预制的apk放在vendor 目录下 也可以放在package/app下 配置好mk 让系统能编译到就行


[预制可卸载app](https://blog.csdn.net/baidu_41666295/article/details/118414269?spm=1001.2014.3001.5501)


### 2.对于预制不可卸载app具体步骤如下:


Android.mk是Android提供的一种makefile文件，用来指定诸如编译生成so库名、引用的头文件目录、需要编译的.c/.cpp文件和.a静态库文件等  
 下面的变量用于向编译系统描述你的模块。应该定义在’include $(CLEAR\_VARS)’和’include  
 
 
 
 
 ( 
 
 
 B 
 
 
 U 
 
 
 I 
 
 
 L 
 
 
 
 D 
 
 
 X 
 
 
 
 X 
 
 
 X 
 
 
 X 
 
 
 X 
 
 
 ) 
 
 
 ’之间。 
 
 
 
 (BUILD\_XXXXX)’之间。 
 
 
 (BUILDX​XXXX)’之间。(CLEAR\_VARS)是一个脚本，清除所有这些变量。  
 （1）LOCAL\_PATH: 这个变量用于给出当前文件的路径。  
 必须在 Android.mk 的开头定义，可以这样使用：LOCAL\_PATH := $(call my-dir)  
 如当前目录下有个文件夹名称 src，则可以这样写  
 
 
 
 
 ( 
 
 
 c 
 
 
 a 
 
 
 l 
 
 
 l 
 
 
 s 
 
 
 r 
 
 
 c 
 
 
 ) 
 
 
 ，那么就会得到 
 
 
 s 
 
 
 r 
 
 
 c 
 
 
 目录的完整路径这个变量不会被 
 
 
 
 (call src)，那么就会得到 src 目录的完整路径 这个变量不会被 
 
 
 (callsrc)，那么就会得到src目录的完整路径这个变量不会被(CLEAR\_VARS)清除，因此每个 Android.mk 只需要定义一次(即使在一个文件中定义了几个模块的情况下)。  
 （2）LOCAL\_MODULE: 这是模块的名字，它必须是唯一的，而且不能包含空格。  
 必须在包含任一的$(BUILD\_XXXX)脚本之前定义它。模块的名字决定了生成文件的名字。  
 （3）LOCAL\_SRC\_FILES: 这是要编译的源代码文件列表。  
 只要列出要传递给编译器的文件，因为编译系统自动计算依赖。注意源代码文件名称都是相对于 LOCAL\_PATH的，你可以使用路径部分，例如：  
 LOCAL\_SRC\_FILES := foo.c toto/bar.c  
 Hello.c  
 文件之间可以用空格或Tab键进行分割,换行请用”\“  
 如果是追加源代码文件的话，请用LOCAL\_SRC\_FILES +=  
 注意：可以LOCAL\_SRC\_FILES := KaTeX parse error: Double subscript at position 70: …a文件。 （4）LOCAL\_C\_̲INCLUDES: 可选变量，…(TARGET\_ROOT\_OUT)  
 至于LOCAL\_MODULE\_PATH 和LOCAL\_UNSTRIPPED\_PATH的区别，暂时还不清楚。  
 （9）LOCAL\_JNI\_SHARED\_LIBRARIES：定义了要包含的so库文件的名字，如果程序没有采用jni，不需要  
 LOCAL\_JNI\_SHARED\_LIBRARIES := libxxx 这样在编译的时候，NDK自动会把这个libxxx打包进apk； 放在youapk/lib/目录下


常用路径的分析  
 TOPDIR – 源码根目录  
 OUT\_DIR – out目录，默认情况下是源码目录下的out目录，如果指定OUT\_DIR\_COMMON\_BASE这个环境变量，则为这个变量指定的目录  
 TARGET\_BUILD\_TYPE – 是release还是debug的编译，在环境变量TARGET\_BUILD\_TYPE中指定  
 SOONG\_OUT\_DIR – soong目录，默认情况下是out/soong  
 DEBUG\_OUT\_DIR – TARGET\_BUILD\_TYPE为debug时会用到此目录，默认是out/debug  
 TARGET\_OUT\_ROOT – target目录，默认是out/target，debug时为out/debug/target  
 TARGET\_PRODUCT\_OUT\_ROOT – 默认是out/target/product目录  
 TARGET\_COMMON\_OUT\_ROOT – 默认是out/target/common目录，用于生成编译时的中间文件  
 PRODUCT\_OUT – 默认是out/target/product/{设备型号}，真正的编译生成文件的目录  
 TARGET\_OUT – $(PRODUCT\_OUT)/system目录  
 TARGET\_OUT\_GEN – $(PRODUCT\_OUT)/gen  
 TARGET\_OUT\_EXECUTABLES – $(TARGET\_OUT)/bin  
 TARGET\_OUT\_OPTIONAL\_EXECUTABLES – $(TARGET\_OUT)/xbin  
 TARGET\_OUT\_RENDERSCRIPT\_BITCODE :=  
 
 
 
 
 ( 
 
 
 T 
 
 
 A 
 
 
 R 
 
 
 G 
 
 
 E 
 
 
 
 T 
 
 
 O 
 
 
 
 U 
 
 
 
 T 
 
 
 S 
 
 
 
 H 
 
 
 A 
 
 
 R 
 
 
 E 
 
 
 
 D 
 
 
 L 
 
 
 
 I 
 
 
 B 
 
 
 R 
 
 
 A 
 
 
 R 
 
 
 I 
 
 
 E 
 
 
 S 
 
 
 ) 
 
 
 T 
 
 
 A 
 
 
 R 
 
 
 G 
 
 
 E 
 
 
 
 T 
 
 
 O 
 
 
 
 U 
 
 
 
 T 
 
 
 J 
 
 
 
 A 
 
 
 V 
 
 
 
 A 
 
 
 L 
 
 
 
 I 
 
 
 B 
 
 
 R 
 
 
 A 
 
 
 R 
 
 
 I 
 
 
 E 
 
 
 S 
 
 
 : 
 
 
 = 
 
 
 
 (TARGET\_OUT\_SHARED\_LIBRARIES) TARGET\_OUT\_JAVA\_LIBRARIES := 
 
 
 (TARGETO​UTS​HAREDL​IBRARIES)TARGETO​UTJ​AVAL​IBRARIES:=(PRODUCT\_OUT)/system/framework  
 TARGET\_OUT\_APPS := 
 
 
 
 
 ( 
 
 
 P 
 
 
 R 
 
 
 O 
 
 
 D 
 
 
 U 
 
 
 C 
 
 
 
 T 
 
 
 O 
 
 
 
 U 
 
 
 T 
 
 
 ) 
 
 
 / 
 
 
 s 
 
 
 y 
 
 
 s 
 
 
 t 
 
 
 e 
 
 
 m 
 
 
 / 
 
 
 a 
 
 
 p 
 
 
 p 
 
 
 T 
 
 
 A 
 
 
 R 
 
 
 G 
 
 
 E 
 
 
 
 T 
 
 
 O 
 
 
 
 U 
 
 
 
 T 
 
 
 A 
 
 
 
 P 
 
 
 P 
 
 
 
 S 
 
 
 P 
 
 
 
 R 
 
 
 I 
 
 
 V 
 
 
 I 
 
 
 L 
 
 
 E 
 
 
 G 
 
 
 E 
 
 
 D 
 
 
 : 
 
 
 = 
 
 
 
 (PRODUCT\_OUT)/system/app TARGET\_OUT\_APPS\_PRIVILEGED := 
 
 
 (PRODUCTO​UT)/system/appTARGETO​UTA​PPSP​RIVILEGED:=(PRODUCT\_OUT)/system/priv-app  
 TARGET\_OUT\_KEYLAYOUT := 
 
 
 
 
 ( 
 
 
 P 
 
 
 R 
 
 
 O 
 
 
 D 
 
 
 U 
 
 
 C 
 
 
 
 T 
 
 
 O 
 
 
 
 U 
 
 
 T 
 
 
 ) 
 
 
 / 
 
 
 s 
 
 
 y 
 
 
 s 
 
 
 t 
 
 
 e 
 
 
 m 
 
 
 / 
 
 
 u 
 
 
 s 
 
 
 r 
 
 
 / 
 
 
 k 
 
 
 e 
 
 
 y 
 
 
 l 
 
 
 a 
 
 
 y 
 
 
 o 
 
 
 u 
 
 
 t 
 
 
 T 
 
 
 A 
 
 
 R 
 
 
 G 
 
 
 E 
 
 
 
 T 
 
 
 O 
 
 
 
 U 
 
 
 
 T 
 
 
 K 
 
 
 
 E 
 
 
 Y 
 
 
 C 
 
 
 H 
 
 
 A 
 
 
 R 
 
 
 S 
 
 
 : 
 
 
 = 
 
 
 
 (PRODUCT\_OUT)/system/usr/keylayout TARGET\_OUT\_KEYCHARS := 
 
 
 (PRODUCTO​UT)/system/usr/keylayoutTARGETO​UTK​EYCHARS:=(PRODUCT\_OUT)/system/usr/keychars  
 TARGET\_OUT\_ETC :=$(PRODUCT\_OUT)/system/etc  
 TARGET\_OUT\_FAKE := $(PRODUCT\_OUT)/fake\_packages  
 TARGET\_OUT\_TESTCASES := $(PRODUCT\_OUT)/testcases  
 HOST\_OUT\_ROOT – host目录，默认是out/host  
 HOST\_OUT –  
 SOONG\_HOST\_OUT –  
 HOST\_CROSS\_OUT –


1.android.mk的编写  
 有源码的apk



```
LOCAL_PATH:= $(call my-dir)
include $(CLEAR\_VARS)

LOCAL_MODULE_TAGS := optional
LOCAL_SRC_FILES := $(call all-subdir-java-files)
LOCAL_PACKAGE_NAME := Launcher_105 app名称

LOCAL_CERTIFICATE := platform
LOCAL_SDK_VERSION = current
LOCAL_PRODUCT_MODULE := true 预制到product 下  如果预制到system 下可以注释掉
LOCAL_PRIVILEGED_MODULE := true //预制到 priv-app 下 如果预制到app 下可以注释掉
#include $(BUILD\_PREBUILT)
include $(BUILD\_PACKAGE)

```

无源码apk的mk 编写



```
LOCAL_PATH:= $(call my-dir)
include $(CLEAR\_VARS)

LOCAL_MODULE_TAGS := optional

LOCAL_MODULE := Debug //app 名称

LOCAL_MODULE_CLASS := APPS

LOCAL_CERTIFICATE := platform

LOCAL_SRC_FILES := Debug.apk

LOCAL_PRODUCT_MODULE := true //预制到product 下  如果预制到system 下可以注释掉
LOCAL_PRIVILEGED_MODULE := true //预制到 priv-app 下 如果预制到app 下可以注释掉
include $(BUILD\_PREBUILT)
#include $(BUILD\_PACKAGE)

```

### 2. 预制apk如图


![在这里插入图片描述](https://img-blog.csdnimg.cn/20210715185814303.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70#pic_center)  
 如果apk 带有so 库的 就拷贝lib文件夹到这里  
 这样就会编译到out 相应的目录下


### 3.添加app名称到系统参与编译的mk中


先看下handheld\_product.mk的源码



```
#
# Copyright (C) 2019 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
 # Unless required by applicable law or agreed to in writing, software
 # distributed under the License is distributed on an "AS IS" BASIS,
 # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 # See the License for the specific language governing permissions and
 # limitations under the License.
 #
 
 # This makefile contains the product partition contents for
 # a generic phone or tablet device. Only add something here if
 # it definitely doesn't belong on other types of devices (if it
 # does, use base\_vendor.mk).
 $(call inherit-product, $(SRC\_TARGET\_DIR)/product/media\_product.mk)
 
 # /product packages
 PRODUCT_PACKAGES += \
     Browser2 \
     Calendar \
     Camera2 \
     Contacts \
     DeskClock \
     Email \
     Gallery2 \
     LatinIME \
     Launcher3QuickStep \
     Music \
     OneTimeInitializer \
     Provision \
     QuickSearchBox \
     Settings \
     SettingsIntelligence \
     StorageManager \
     SystemUI \
     WallpaperCropper \
     frameworks-base-overlays
 
 PRODUCT_PACKAGES_DEBUG += \
     frameworks-base-overlays-debug

```

在PRODUCT\_PACKAGES 中添加编译app的名称  
 添加如下:



```
build/make/target/product/handheld_product.mk

PRODUCT_PACKAGES += \
Baidu  //添加 Baidu文件名

```




