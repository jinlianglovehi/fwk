






### 1.概述


在10.0的系统产品定制化开发中，在SystemUI中对下拉状态栏定制化修改需求定制，比如在下拉状态栏的  
 QuickQSPanel添加亮度进度条布局，而在 QSPanel中有这个亮度条布局，所以要求从QSPanel移植亮度条到这个页面就可以了


### 2.QuickQSPanel添加亮度进度条布局调整核心类



```
frameworks / base / packages / SystemUI / src / com / android / systemui / qs / QuickQSPanel.java

```

### 3.QuickQSPanel添加亮度进度条布局调整的核心功能实现和分析


在SystemUI的首次下拉的文件就是QuickQSPanel.java，  
 接下来首选看QuickQSPanel.java的布局文件，看下在布局中，怎么添加亮度条布局  
 这个文件的  
 路径为:frameworks / base / packages / SystemUI / src / com / android / systemui / qs / QuickQSPanel.java


### 3.1QuickQSPanel的相关代码分析



```
  /**
  * Version of QSPanel that only shows N Quick Tiles in the QS Header.
  */
 public class QuickQSPanel extends QSPanel {
 
     public static final String NUM_QUICK_TILES = "sysui\_qqs\_count";
     private static final String TAG = "QuickQSPanel";
 
     private boolean mDisabledByPolicy;
     private static int mDefaultMaxTiles;
     private int mMaxTiles;
     protected QSPanel mFullPanel;
 
     @Inject
     public QuickQSPanel(@Named(VIEW_CONTEXT) Context context, AttributeSet attrs,
             DumpController dumpController) {
         super(context, attrs, dumpController);
         if (mFooter != null) {
             removeView(mFooter.getView());
         }
         if (mTileLayout != null) {
             for (int i = 0; i < mRecords.size(); i++) {
                 mTileLayout.removeTile(mRecords.get(i));
             }
             removeView((View) mTileLayout);
 }
 mDefaultMaxTiles = getResources().getInteger(R.integer.quick\_qs\_panel\_max\_columns);
 mTileLayout = new HeaderTileLayout(context);
 mTileLayout.setListening(mListening);
 addView((View) mTileLayout, 0 /\* Between brightness and footer \*/);
 super.setPadding(0, 0, 0, 0);
 }
 
 @Override
 public void setPadding(int left, int top, int right, int bottom) {
 // Always have no padding.
 }
 
 @Override
 protected void addDivider() {
 }
 
 @Override
 protected void onAttachedToWindow() {
 super.onAttachedToWindow();
 Dependency.get(TunerService.class).addTunable(mNumTiles, NUM\_QUICK\_TILES);
 }
 
 @Override
 protected void onDetachedFromWindow() {
 super.onDetachedFromWindow();
 Dependency.get(TunerService.class).removeTunable(mNumTiles);
 }
 
 public void setQSPanelAndHeader(QSPanel fullPanel, View header) {
 mFullPanel = fullPanel;
 }
 
 @Override
 protected boolean shouldShowDetail() {
 return !mExpanded;
 }
 
 @Override
 protected void drawTile(TileRecord r, State state) {
 if (state instanceof SignalState) {
 SignalState copy = new SignalState();
 state.copyTo(copy);
 // No activity shown in the quick panel.
 copy.activityIn = false;
 copy.activityOut = false;
 state = copy;
 }
 super.drawTile(r, state);
 }
 
 @Override
 public void setHost(QSTileHost host, QSCustomizer customizer) {
 super.setHost(host, customizer);
 setTiles(mHost.getTiles());
      }
  
      public void setMaxTiles(int maxTiles) {
          mMaxTiles = maxTiles;
          if (mHost != null) {
              setTiles(mHost.getTiles());
          }
      }
  
      @Override
      public void onTuningChanged(String key, String newValue) {
          if (QS_SHOW_BRIGHTNESS.equals(key)) {
              // No Brightness or Tooltip for you!
              super.onTuningChanged(key, "0");
          }
      }
      private void setAccessibilityOrder() {
              if (mRecords != null && mRecords.size() > 0) {
                  View previousView = this;
                  for (TileRecord record : mRecords) {
                      if (record.tileView.getVisibility() == GONE) continue;
                      previousView = record.tileView.updateAccessibilityOrder(previousView);
                  }
                  mRecords.get(mRecords.size() - 1).tileView.setAccessibilityTraversalBefore(
                          R.id.expand_indicator);
              }
          }
      /**
       * Sets the visibility of this {@link QuickQSPanel}. This method has no effect when this panel
       * is disabled by policy through {@link #setDisabledByPolicy(boolean)}, and in this case the
       * visibility will always be {@link View#GONE}. This method is called externally by
       * {@link QSAnimator} only.
       */
      @Override
      public void setVisibility(int visibility) {
          if (mDisabledByPolicy) {
              if (getVisibility() == View.GONE) {
                  return;
              }
              visibility = View.GONE;
          }
          super.setVisibility(visibility);
      }
        @Override
          protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
              // Measure each QS tile.
              for (TileRecord record : mRecords) {
                  if (record.tileView.getVisibility() == GONE) continue;
                  record.tileView.measure(exactly(mCellWidth), exactly(mCellHeight));
              }
  
              int height = mCellHeight;
              if (height < 0) height = 0;
  
              setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), height);
          }
  
          @Override
          public int getNumVisibleTiles() {
              return mColumns;
          }
  
          @Override
          protected int getColumnStart(int column) {
              return getPaddingStart() + column *  (mCellWidth + mCellMarginHorizontal);
          }

```

从QuickQSPanel构造方法的代码发现  
 addView((View) mTileLayout,0);就是在通过添加子项到QuickQSPanel的布局中，这样的  
 我们就可以通过添加亮度条布局到QuickQSPanel中去进行重新布局，


所以添加亮度条ui为：



```
+    protected View mBrightnessView = null;
+    private BrightnessController mBrightnessController=null;

+        mBrightnessView = LayoutInflater.from(mContext).inflate(
+            R.layout.quick_settings_brightness_dialog, this, false);
+        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
+        layoutParams.topMargin = context.getResources().getDimensionPixelSize(R.dimen.status_bar_padding_start);
+        mBrightnessView.setLayoutParams(layoutParams);
+               addView(mBrightnessView,1);
+        mBrightnessController = new BrightnessController(getContext(),
+                findViewById(R.id.brightness_slider));
+               setBrightnessListening(true);

亮度条相关回调方法
+    public void setBrightnessListening(boolean listening) {
+        if (listening) {
+            mBrightnessController.registerCallbacks();
+        } else {
+            mBrightnessController.unregisterCallbacks();
+        }
+    }
     @Override
     protected void onDetachedFromWindow() {
         super.onDetachedFromWindow();
@@ -182,6 +199,7 @@ public class QuickQSPanel extends QSPanel {
                 return;
             }
             visibility = View.GONE;
+                       setBrightnessListening(false);
         }
         super.setVisibility(visibility);
     }

```

通过上述方法把mBrightnessView 和mBrightnessController关于亮度条的相关ui添加进去





