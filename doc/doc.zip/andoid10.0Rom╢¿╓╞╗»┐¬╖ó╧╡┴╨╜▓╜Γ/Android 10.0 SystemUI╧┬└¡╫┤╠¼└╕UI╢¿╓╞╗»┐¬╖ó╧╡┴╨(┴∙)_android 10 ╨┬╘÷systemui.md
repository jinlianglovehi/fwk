



**目录**



[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码部分](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E9%83%A8%E5%88%86)


[3.核心代码分析以及功能实现](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E4%BB%A5%E5%8F%8A%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1亮度条样式相关代码的分析](#%C2%A03.1%E4%BA%AE%E5%BA%A6%E6%9D%A1%E6%A0%B7%E5%BC%8F%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E7%9A%84%E5%88%86%E6%9E%90)


[3.2分析ToggleSliderView的代码](#3.2%E5%88%86%E6%9E%90ToggleSliderView%E7%9A%84%E4%BB%A3%E7%A0%81)


[3.3修改亮度条样式布局](#3.3%E4%BF%AE%E6%94%B9%E4%BA%AE%E5%BA%A6%E6%9D%A1%E6%A0%B7%E5%BC%8F%E5%B8%83%E5%B1%80)


[4.修改亮度条在拖动的时候隐藏状态栏的功能](#4.%E4%BF%AE%E6%94%B9%E4%BA%AE%E5%BA%A6%E6%9D%A1%E5%9C%A8%E6%8B%96%E5%8A%A8%E7%9A%84%E6%97%B6%E5%80%99%E9%9A%90%E8%97%8F%E7%8A%B6%E6%80%81%E6%A0%8F%E7%9A%84%E5%8A%9F%E8%83%BD)


[4.1查看分析亮度条的代码](#%C2%A04.1%E6%9F%A5%E7%9C%8B%E5%88%86%E6%9E%90%E4%BA%AE%E5%BA%A6%E6%9D%A1%E7%9A%84%E4%BB%A3%E7%A0%81)


[4.2修改功能实现拖动不隐藏状态栏](#4.2%E4%BF%AE%E6%94%B9%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E6%8B%96%E5%8A%A8%E4%B8%8D%E9%9A%90%E8%97%8F%E7%8A%B6%E6%80%81%E6%A0%8F)




---



## 1.概述


系统SystemUi下拉状态栏UI定制化开发第六讲 本篇主要讲解QuickQSPanel.java新增亮度条样式的修改和去掉拖动亮度条时隐藏状态栏


## 2.核心代码部分



```
代码主要分布在:
frameworks/base/packages/SystemUI/res/layout/status_bar_toggle_slider.xml
/frameworks/base/packages/SystemUI/res/layout/quick_settings_brightness_dialog.xml

frameworks/base/packages/SystemUI/src/com/android/systemui/settings/ToggleSliderView.java
```

## 3.核心代码分析以及功能实现


####  3.1亮度条样式相关代码的分析



```
mBrightnessView = LayoutInflater.from(mContext).inflate(
           R.layout.quick_settings_brightness_dialog, this, false);
发现亮度条的布局就是quick_settings_brightness_dialog.xml
布局路径：/frameworks/base/packages/SystemUI/res/layout/quick_settings_brightness_dialog.xml

<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2012 The Android Open Source Project

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
xmlns:systemui="http://schemas.android.com/apk/res-auto"
android:layout_height="wrap_content"
android:layout_width="match_parent"
android:layout_gravity="center_vertical"
android:paddingLeft="16dp"
android:paddingRight="16dp"
style="@style/BrightnessDialogContainer">

<com.android.systemui.settings.ToggleSliderView
android:id="@+id/brightness_slider"
android:layout_width="0dp"
android:layout_height="48dp"
android:layout_gravity="center_vertical"
android:layout_weight="1"
android:contentDescription="@string/accessibility_brightness"
android:importantForAccessibility="no"
systemui:text="@string/status_bar_settings_auto_brightness_label" />

</LinearLayout>

```

从相关代码发现亮度条布局其实就是自定义的



```
com.android.systemui.settings.ToggleSliderView

```

#### 3.2分析ToggleSliderView的代码



```
public class ToggleSliderView extends RelativeLayout implements ToggleSlider {
private Listener mListener;
private boolean mTracking;

private CompoundButton mToggle;
private ToggleSeekBar mSlider;
private TextView mLabel;

private ToggleSliderView mMirror;
private BrightnessMirrorController mMirrorController;

public ToggleSliderView(Context context) {
this(context, null);
}

public ToggleSliderView(Context context, AttributeSet attrs) {
this(context, attrs, 0);
}

public ToggleSliderView(Context context, AttributeSet attrs, int defStyle) {
super(context, attrs, defStyle);

View.inflate(context, R.layout.status_bar_toggle_slider, this);

final Resources res = context.getResources();
final TypedArray a = context.obtainStyledAttributes(
attrs, R.styleable.ToggleSliderView, defStyle, 0);

mToggle = findViewById(R.id.toggle);
mToggle.setOnCheckedChangeListener(mCheckListener);

mSlider = findViewById(R.id.slider);
mSlider.setOnSeekBarChangeListener(mSeekListener);

mLabel = findViewById(R.id.label);
mLabel.setText(a.getString(R.styleable.ToggleSliderView_text));

mSlider.setAccessibilityLabel(getContentDescription().toString());

a.recycle();
}
```

从构造方法发现布局文件为status\_bar\_toggle\_slider.xml文件


## 3.3修改亮度条样式布局



```
<!--    android:background="@drawable/status_bar_closed_default_background" -->
-<merge xmlns:android="http://schemas.android.com/apk/res/android">
+<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
+    xmlns:systemui="http://schemas.android.com/apk/res-auto"
+    android:layout_height="wrap_content"
+    android:layout_width="match_parent"
+       android:orientation="horizontal">
     <CheckBox
         android:id="@+id/toggle"
         android:layout_width="48dp"
         android:background="@*android:drawable/switch_track_material"
         android:visibility="gone"
         />
+       <ImageView
+           android:id="@+id/bright_img"
+        android:layout_width="0dp"
+        android:layout_height="wrap_content"
+        android:layout_marginTop = "10dp"
+               android:layout_weight="1"
+               android:layout_toEndOf="@id/toggle"
+        android:scaleType="fitCenter"
+        android:background="@drawable/icon_bright"/>
     <com.android.systemui.settings.ToggleSeekBar
         android:id="@+id/slider"
         android:layout_width="0dp"
         android:layout_height="wrap_content"
-        android:layout_toEndOf="@id/toggle"
+        android:layout_toEndOf="@id/bright_img"
         android:layout_centerVertical="true"
         android:layout_alignParentStart="true"
-        android:layout_alignParentEnd="true"
+               android:layout_marginLeft="20dp"
+               android:layout_marginRight="20dp"
+               android:layout_weight="18"
         android:paddingStart="20dp"
-        android:paddingEnd="20dp"
-        android:paddingTop="16dp"
-        android:paddingBottom="16dp"
-        android:thumb="@drawable/ic_brightness_thumb"
+               android:paddingEnd="20dp"
+        android:paddingTop="5dp"
+        android:paddingBottom="0dp"
+        android:thumb="@drawable/icon_jindu"
         android:progressDrawable="@drawable/brightness_progress_drawable"
         android:splitTrack="false"
         />
-    <TextView
-        android:id="@+id/label"
+       <ImageView
         android:layout_width="0dp"
         android:layout_height="wrap_content"
+        android:layout_marginTop = "10dp"
+               android:layout_toEndOf="@id/slider"
+               android:layout_weight="1"
+        android:scaleType="fitCenter"
+        android:background="@drawable/icon_dark"/>
+    <TextView
+        android:id="@+id/label"
+        android:layout_width="match_parent"
+        android:layout_height="0dp"
         android:layout_alignStart="@id/toggle"
         android:layout_alignEnd="@id/toggle"
         android:layout_centerVertical="true"
@@ -57,4 +80,4 @@
         android:textSize="12sp"
         android:visibility="gone"
         />
-</merge>
+</LinearLayout>

增加了亮度条前后的图标 和拖动进度条图片

可根据项目的需要来修改布局和添加相应的功能布局
```

## 4.修改亮度条在拖动的时候隐藏状态栏的功能


####  4.1查看分析亮度条的代码



```
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.android.settingslib.RestrictedLockUtils;
import com.android.systemui.R;
import com.android.systemui.statusbar.policy.BrightnessMirrorController;

public class ToggleSliderView extends RelativeLayout implements ToggleSlider {
private Listener mListener;
private boolean mTracking;

private CompoundButton mToggle;
private ToggleSeekBar mSlider;
private TextView mLabel;

private ToggleSliderView mMirror;
private BrightnessMirrorController mMirrorController;

public ToggleSliderView(Context context) {
this(context, null);
}

public ToggleSliderView(Context context, AttributeSet attrs) {
this(context, attrs, 0);
}

public ToggleSliderView(Context context, AttributeSet attrs, int defStyle) {
super(context, attrs, defStyle);

View.inflate(context, R.layout.status_bar_toggle_slider, this);

final Resources res = context.getResources();
final TypedArray a = context.obtainStyledAttributes(
attrs, R.styleable.ToggleSliderView, defStyle, 0);

mToggle = findViewById(R.id.toggle);
mToggle.setOnCheckedChangeListener(mCheckListener);

mSlider = findViewById(R.id.slider);
mSlider.setOnSeekBarChangeListener(mSeekListener);

mLabel = findViewById(R.id.label);
mLabel.setText(a.getString(R.styleable.ToggleSliderView_text));

mSlider.setAccessibilityLabel(getContentDescription().toString());

a.recycle();
}

public void setMirror(ToggleSliderView toggleSlider) {
mMirror = toggleSlider;
if (mMirror != null) {
mMirror.setChecked(mToggle.isChecked());
mMirror.setMax(mSlider.getMax());
mMirror.setValue(mSlider.getProgress());
}
}

public void setMirrorController(BrightnessMirrorController c) {
mMirrorController = c;
}

@Override
protected void onAttachedToWindow() {
super.onAttachedToWindow();
if (mListener != null) {
mListener.onInit(this);
}
}

public void setEnforcedAdmin(RestrictedLockUtils.EnforcedAdmin admin) {
mToggle.setEnabled(admin == null);
mSlider.setEnabled(admin == null);
mSlider.setEnforcedAdmin(admin);
}

public void setOnChangedListener(Listener l) {
mListener = l;
}

@Override
public void setChecked(boolean checked) {
mToggle.setChecked(checked);
}

@Override
public boolean isChecked() {
return mToggle.isChecked();
}

@Override
public void setMax(int max) {
mSlider.setMax(max);
if (mMirror != null) {
mMirror.setMax(max);
}
}

@Override
public void setValue(int value) {
mSlider.setProgress(value);
if (mMirror != null) {
mMirror.setValue(value);
}
}

@Override
public int getValue() {
return mSlider.getProgress();
}

@Override
public boolean dispatchTouchEvent(MotionEvent ev) {
if (mMirror != null) {
MotionEvent copy = ev.copy();
mMirror.dispatchTouchEvent(copy);
copy.recycle();
}
return super.dispatchTouchEvent(ev);
}

private final OnCheckedChangeListener mCheckListener = new OnCheckedChangeListener() {
@Override
public void onCheckedChanged(CompoundButton toggle, boolean checked) {
mSlider.setEnabled(!checked);

if (mListener != null) {
mListener.onChanged(
ToggleSliderView.this, mTracking, checked, mSlider.getProgress(), false);
}

if (mMirror != null) {
mMirror.mToggle.setChecked(checked);
}
}
};

private final OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener() {
@Override
public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
if (mListener != null) {
mListener.onChanged(
ToggleSliderView.this, mTracking, mToggle.isChecked(), progress, false);
}
}

@Override
public void onStartTrackingTouch(SeekBar seekBar) {
mTracking = true;

if (mListener != null) {
mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
mSlider.getProgress(), false);
}

mToggle.setChecked(false);

if (mMirrorController != null) {
mMirrorController.showMirror();
mMirrorController.setLocation((View) getParent());
}
}

@Override
public void onStopTrackingTouch(SeekBar seekBar) {
mTracking = false;

if (mListener != null) {
mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
mSlider.getProgress(), true);
}

if (mMirrorController != null) {
mMirrorController.hideMirror();
}
}
};
}
```

从上述代码可以分析出OnSeekBarChangeListener就是亮度条在拖动的时候调用的相关代码



```
private final OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener() {
@Override
public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
if (mListener != null) {
mListener.onChanged(
ToggleSliderView.this, mTracking, mToggle.isChecked(), progress, false);
}
}

@Override
public void onStartTrackingTouch(SeekBar seekBar) {
mTracking = true;

if (mListener != null) {
mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
mSlider.getProgress(), false);
}

mToggle.setChecked(false);

if (mMirrorController != null) {
mMirrorController.showMirror();
mMirrorController.setLocation((View) getParent());
}
}

@Override
public void onStopTrackingTouch(SeekBar seekBar) {
mTracking = false;

if (mListener != null) {
mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
mSlider.getProgress(), true);
}

if (mMirrorController != null) {
mMirrorController.hideMirror();
}
}
};
```

而mMirrorController.showMirror();就是状态栏隐藏 mMirrorController.hideMirror();就是状态栏显示


#### 4.2修改功能实现拖动不隐藏状态栏



```
private final OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener() {
@Override
public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
if (mListener != null) {
mListener.onChanged(
ToggleSliderView.this, mTracking, mToggle.isChecked(), progress, false);
}
}

@Override
public void onStartTrackingTouch(SeekBar seekBar) {
mTracking = true;

if (mListener != null) {
mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
mSlider.getProgress(), false);
}

mToggle.setChecked(false);

/*if (mMirrorController != null) {
mMirrorController.showMirror();
mMirrorController.setLocation((View) getParent());
}*/
}

@Override
public void onStopTrackingTouch(SeekBar seekBar) {
mTracking = false;

if (mListener != null) {
mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
mSlider.getProgress(), true);
}

/*if (mMirrorController != null) {
mMirrorController.hideMirror();
}*/
}
};
```



