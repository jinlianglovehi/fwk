






在进行定制化开发中，客户反应app弹出的通知 在状态栏显示为白色，显示不了正常的背景色，这就跟通知的背景颜色有关


接下来首选看下通知显示的流程


framework/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarNotificationPresenter.java



```
 private final NotificationPanelView mNotificationPanel;
    @Override
    public void updateNotificationViews() {
        // The function updateRowStates depends on both of these being non-null, so check them here.
        // We may be called before they are set from DeviceProvisionedController's callback.
        if (mScrimController == null) return;

        // Do not modify the notifications during collapse.
        if (isCollapsing()) {
            mShadeController.addPostCollapseAction(this::updateNotificationViews);
            return;
        }

        mViewHierarchyManager.updateNotificationViews();

        mNotificationPanel.updateNotificationViews();
    }

```

调用NotificationPanel.updateNotificationViews()来处理通知事件


framework/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java



```
protected NotificationStackScrollLayout mNotificationStackScroller;
public void updateNotificationViews() {
    mNotificationStackScroller.updateSectionBoundaries();
    mNotificationStackScroller.updateSpeedBumpIndex();
    mNotificationStackScroller.updateFooter();
    updateShowEmptyShadeView();
    mNotificationStackScroller.updateIconAreaViews();
}

```

调用 mNotificationStackScroller.updateIconAreaViews()的方法处理通知事件


framework/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java



```
private NotificationIconAreaController mIconAreaController;
public void updateIconAreaViews() {
    mIconAreaController.updateNotificationIcons();
}

```

继续往下走：  
 framework/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationIconAreaController.java



```
/**
 * Updates the notifications with the given list of notifications to display.
 */
public void updateNotificationIcons() {
    updateStatusBarIcons();
    updateShelfIcons();
    updateCenterIcon();

    applyNotificationIconsTint();
}

```

applyNotificationIconsTint(); 主要负责对通知的背景色进行着色的



```
/**
 * Applies {@link #mIconTint} to the notification icons.
 * Applies {@link #mCenteredIconTint} to the center notification icon.
 */
private void applyNotificationIconsTint() {
    for (int i = 0; i < mNotificationIcons.getChildCount(); i++) {
        final StatusBarIconView iv = (StatusBarIconView) mNotificationIcons.getChildAt(i);
        if (iv.getWidth() != 0) {
            updateTintForIcon(iv, mIconTint);
        } else {
            iv.executeOnLayout(() -> updateTintForIcon(iv, mIconTint));
        }
    }

    for (int i = 0; i < mCenteredIcon.getChildCount(); i++) {
        final StatusBarIconView iv = (StatusBarIconView) mCenteredIcon.getChildAt(i);
        if (iv.getWidth() != 0) {
            updateTintForIcon(iv, mCenteredIconTint);
        } else {
            iv.executeOnLayout(() -> updateTintForIcon(iv, mCenteredIconTint));
        }
    }
}

private void updateTintForIcon(StatusBarIconView v, int tint) {
    boolean isPreL = Boolean.TRUE.equals(v.getTag(R.id.icon_is_pre_L));
    int color = StatusBarIconView.NO_COLOR;
    /*Unisoc bug 906697:Notification icon display as a white icon{@*/
    //boolean colorize = !isPreL || NotificationUtils.isGrayscale(v, mContrastColorUtil);
    boolean colorize = CHECK_SDK_VERSION ? !isPreL || NotificationUtils.isGrayscale(v, mContrastColorUtil)
            : NotificationUtils.isGrayscale(v, mContrastColorUtil);
    /*@}*/

    if (colorize) {
        color = DarkIconDispatcher.getTint(mTintArea, v, tint);
    }
    v.setStaticDrawableColor(color);
    v.setDecorColor(tint);
}

```


```
private int mIconTint = Color.WHITE;
private int mCenteredIconTint = Color.WHITE;

```

而 mIconTint 和 mCenteredIconTint 都代表纯白色的背景


这就是app发送通知的Icon 会进行判断然后进行着色


所以修改方案 就是不让着色：



```
 private void updateTintForIcon(StatusBarIconView v, int tint) {
        boolean isPreL = Boolean.TRUE.equals(v.getTag(R.id.icon_is_pre_L));
        int color = StatusBarIconView.NO_COLOR;
        /*Unisoc bug 906697:Notification icon display as a white icon{@*/
        //boolean colorize = !isPreL || NotificationUtils.isGrayscale(v, mContrastColorUtil);
        boolean colorize = CHECK_SDK_VERSION ? !isPreL || NotificationUtils.isGrayscale(v, mContrastColorUtil)
                : NotificationUtils.isGrayscale(v, mContrastColorUtil);
        /*@}*/

        if (colorize) {
            color = DarkIconDispatcher.getTint(mTintArea, v, tint);
        }
     -   v.setStaticDrawableColor(color);
     -   v.setDecorColor(tint);
    }

```

去掉着色的setStaticDrawableColor 和 setDecorColor





