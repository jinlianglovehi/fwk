






### 1.概述


10.0定制化开发中，在app开发过程中 会遇到获取系列号 总是返回unknow 的情况 即使app是系统内置app 也会出现这样的情况 找寻原因找了好久，最终发现是权限的问题导致的


app中如这样获取



```
public String getSN() {
String sn = SystemProperties.get("ro.serialno","unkown");
return sn;
}
或者
public String getSN() {
String sn = Build.getSerial();
return sn;
}

```

依然获取不到系统序列号的值，折腾了好几天 都找不到原因 在debug版本可以 但是在user版本不行  
 询问相关同事 得知是不是DeviceIdentifiersPolicyService的原因  
 所以只能阅读下源码看下


### 2.app获取不到序列号解决方案的核心代码



```
framework/base/services/core/java/com/android/server/os/DeviceIdentifiersPolicyService.java
framework/base/core/java/android/os/Build.java

```

### 3.app获取不到序列号解决方案的核心代码功能分析


### 3.1关于Build.java获取sn的代码调用



```
 public class Build {
     private static final String TAG = "Build";
 
     /** Value used for when a build property is unknown. */
     public static final String UNKNOWN = "unknown";
 
     /** Either a changelist number, or a label like "M4-rc20". */
     public static final String ID = getString("ro.build.id");
 
     /** A build ID string meant for displaying to the user */
     public static final String DISPLAY = getString("ro.build.display.id");
 
     /** The name of the overall product. */
     public static final String PRODUCT = getString("ro.product.name");
 
     /** The name of the industrial design. */
     public static final String DEVICE = getString("ro.product.device");
 
     /** The name of the underlying board, like "goldfish". */
     public static final String BOARD = getString("ro.product.board");
 
     /**
      * The name of the instruction set (CPU type + ABI convention) of native code.
      *
      * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
      */
     @Deprecated
     public static final String CPU_ABI;
 
     /**
      * The name of the second instruction set (CPU type + ABI convention) of native code.
      *
      * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
      */
     @Deprecated
     public static final String CPU_ABI2;
 
     /** The manufacturer of the product/hardware. */
     public static final String MANUFACTURER = getString("ro.product.manufacturer");
 
     /** The consumer-visible brand with which the product/hardware will be associated, if any. */
     public static final String BRAND = getString("ro.product.brand");
 
     /** The end-user-visible name for the end product. */
     public static final String MODEL = getString("ro.product.model");
 
     /** The system bootloader version number. */
     public static final String BOOTLOADER = getString("ro.bootloader");
 
     /**
      * The radio firmware version number.
      *
      * @deprecated The radio firmware version is frequently not
      * available when this class is initialized, leading to a blank or
      * "unknown" value for this string.  Use
      * {@link #getRadioVersion} instead.
       */
      @Deprecated
      public static final String RADIO = joinListOrElse(
              TelephonyProperties.baseband_version(), UNKNOWN);
  
      /** The name of the hardware (from the kernel command line or /proc). */
      public static final String HARDWARE = getString("ro.hardware");
  
      /**
       * Whether this build was for an emulator device.
       * @hide
       */
      @UnsupportedAppUsage
      @TestApi
      public static final boolean IS_EMULATOR = getString("ro.kernel.qemu").equals("1");
 @Deprecated
      // IMPORTANT: This field should be initialized via a function call to
      // prevent its value being inlined in the app during compilation because
      // we will later set it to the value based on the app's target SDK.
 public static final String SERIAL = getString("no.such.thing");
 
 /\*\*
 \* Gets the hardware serial number, if available.
 \*
 \* <p class="note"><b>Note:</b> Root access may allow you to modify device identifiers, such as
 \* the hardware serial number. If you change these identifiers, you can use
 \* <a href="/training/articles/security-key-attestation.html">key attestation</a> to obtain
 \* proof of the device's original identifiers.
       *
       * <p>Starting with API level 29, persistent device identifiers are guarded behind additional
       * restrictions, and apps are recommended to use resettable identifiers (see <a
       * href="/training/articles/user-data-ids">Best practices for unique identifiers</a>). This
       * method can be invoked if one of the following requirements is met:
       * <ul>
       *     <li>If the calling app has been granted the READ_PRIVILEGED_PHONE_STATE permission; this
       *     is a privileged permission that can only be granted to apps preloaded on the device.
       *     <li>If the calling app is the device or profile owner and has been granted the
       *     {@link Manifest.permission#READ\_PHONE\_STATE} permission. The profile owner is an app that
       *     owns a managed profile on the device; for more details see <a
       *     href="https://developer.android.com/work/managed-profiles">Work profiles</a>.
       *     Profile owner access is deprecated and will be removed in a future release.
       *     <li>If the calling app has carrier privileges (see {@link
       *     android.telephony.TelephonyManager#hasCarrierPrivileges}) on any active subscription.
       *     <li>If the calling app is the default SMS role holder (see {@link
       *     android.app.role.RoleManager#isRoleHeld(String)}).
       * </ul>
       *
       * <p>If the calling app does not meet one of these requirements then this method will behave
       * as follows:
       *
       * <ul>
       *     <li>If the calling app's target SDK is API level 28 or lower and the app has the
 \* READ\_PHONE\_STATE permission then {@link Build#UNKNOWN} is returned.</li>
 \* <li>If the calling app's target SDK is API level 28 or lower and the app does not have
       *     the READ_PHONE_STATE permission, or if the calling app is targeting API level 29 or
       *     higher, then a SecurityException is thrown.</li>
       * </ul>
       *
       * @return The serial number if specified.
       */
      @SuppressAutoDoc // No support for device / profile owner.
      @RequiresPermission(Manifest.permission.READ_PRIVILEGED_PHONE_STATE)
      public static String getSerial() {
          IDeviceIdentifiersPolicyService service = IDeviceIdentifiersPolicyService.Stub
                  .asInterface(ServiceManager.getService(Context.DEVICE_IDENTIFIERS_SERVICE));
          try {
              Application application = ActivityThread.currentApplication();
              String callingPackage = application != null ? application.getPackageName() : null;
              return service.getSerialForPackage(callingPackage, null);
          } catch (RemoteException e) {
              e.rethrowFromSystemServer();
          }
          return UNKNOWN;
      }

```

所以要从getSerial()中获取序列号  
 而调用getSerial()该api需要READ\_PRIVILEGED\_PHONE\_STATE权限，  
 该权限是一个protectLevel为signature的系统级权限，只有系统签名的系统App才能获取该权限， 第三方App是无法获取的


### 3.2DeviceIdentifiersPolicyService关于获取sn的权限分析


路径为:framework/base/services/core/java/com/android/server/os/DeviceIdentifiersPolicyService.java  
 /\*\*  
 This service defines the policy for accessing device identifiers.  
 \*/



```
public final class DeviceIdentifiersPolicyService extends SystemService {
public DeviceIdentifiersPolicyService(Context context) {
super(context);
}@Override
public void onStart() {
publishBinderService(Context.DEVICE_IDENTIFIERS_SERVICE,
new DeviceIdentifiersPolicy(getContext()));
}private static final class DeviceIdentifiersPolicy
extends IDeviceIdentifiersPolicyService.Stub {
private final @NonNull Context mContext; public DeviceIdentifiersPolicy(Context context) {
     mContext = context;
 }

 @Override
 public @Nullable String getSerial() throws RemoteException {
     // Since this invocation is on the server side a null value is used for the
     // callingPackage as the server's package name (typically android) should not be used
     // for any device / profile owner checks. The majority of requests for the serial number
     // should use the getSerialForPackage method with the calling package specified.
     if (!TelephonyPermissions.checkCallingOrSelfReadDeviceIdentifiers(mContext,
             /* callingPackage */ null, "getSerial")) {
         return Build.UNKNOWN;
     }
     return SystemProperties.get("ro.serialno", Build.UNKNOWN);
 }

 @Override
 public @Nullable String getSerialForPackage(String callingPackage) throws RemoteException {
     if (!TelephonyPermissions.checkCallingOrSelfReadDeviceIdentifiers(mContext,
             callingPackage, "getSerial")) {
         return Build.UNKNOWN;
     }
     return SystemProperties.get("ro.serialno", Build.UNKNOWN);
 }
}
}

```

通过源码发现 getSerial() 会检验是否有权限 没权限就返回 unknow字符 和我遇到现象很像  
 所以注释掉 直接返回序列号 发现居然可以了  
 所以具体修改方案为:  
 @Override



```
public @Nullable String getSerial() throws RemoteException {
// Since this invocation is on the server side a null value is used for the
// callingPackage as the server's package name (typically android) should not be used
// for any device / profile owner checks. The majority of requests for the serial number
// should use the getSerialForPackage method with the calling package specified.
/* if (!TelephonyPermissions.checkCallingOrSelfReadDeviceIdentifiers(mContext,
/* callingPackage / null, "getSerial")) {return Build.UNKNOWN;}/
return SystemProperties.get("ro.serialno", Build.UNKNOWN);
}
    @Override
    public @Nullable String getSerialForPackage(String callingPackage) throws RemoteException {
        /*if (!TelephonyPermissions.checkCallingOrSelfReadDeviceIdentifiers(mContext,
                callingPackage, "getSerial")) {
            return Build.UNKNOWN;
        }*/
        return SystemProperties.get("ro.serialno", Build.UNKNOWN);
    }
}

```




