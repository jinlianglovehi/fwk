



## 1.前言


 在10.0的系统开发中，usb连接pc端的时候有好几种模式，在做otg连接pc端的时候，改成mtp模式的时候，在pc端可以看到产品设备  
 的显示的文件夹的内容，对于产品设备里面的文件在pc端禁止做删除重命名拷贝等操作功能的实现


![](https://img-blog.csdnimg.cn/7f44e6862bbf4459b65fe2a7ee81c7e0.png)


## 2.mtp模式下连接pc后显示的文件夹禁止删除copy重命名功能实现的核心类



```
frameworks\base\media\java\android\mtp\MtpDatabase.java

```

## 3.mtp模式下连接pc后显示的文件夹禁止删除copy重命名功能实现的核心功能分析和实现


MtpService负责启动MtpServer和加载存储设备的信息到数据库。MtpServer负责通过jni接口去启动/停止C++层中MtpServer以及处理Storage的添加和删除  
 而具体处理mtp格式文件扫描的就是在MtpDatabase.java中处理的，  
 当手机连上usb线后，UsbReceiver会收到来自系统的USB\_STATE广播事件。接着它需要从UsbManager中查询USB的链接状态，MTP的设置信息和PTP的设置信息。  
 当用户设置为使用MTP模式时，UsbReceiver将通过startService函数启动MtpService。  
 MtpService启动，在其onStartCommand中将创建MtpDatabase对象和MtpServer对象。  
 UsbReceiver同时通过insert一条特殊uri（值为“content://media/none/mtp\_connected”）的方式，触发MdiaProvder调用  
 MtpService的bindService函数。这样，MediaProvider和MtpService就建立了紧密联系.接下来具体处理文件扫描的  
 就需要MtpDatabase.java中相关方法分析



```
    @VisibleForNative
    private int beginCopyObject(int handle, int newParent, int newStorage) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        MtpStorageManager.MtpObject parent = newParent == 0 ?
                mManager.getStorageRoot(newStorage) : mManager.getObject(newParent);
        if (obj == null || parent == null)
            return MtpConstants.RESPONSE_INVALID_OBJECT_HANDLE;
//add core start
        if (true) {
            return MtpConstants.RESPONSE_OBJECT_WRITE_PROTECTED;
        }
//add core end
        return mManager.beginCopyObject(obj, parent);
    }

    @VisibleForNative
    private void endCopyObject(int handle, boolean success) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        if (obj == null || !mManager.endCopyObject(obj, success)) {
            Log.e(TAG, "Failed to end copy object");
            return;
        }
//add core start
        if (true) {
            return;
        }
//add core end
        if (!success) {
            return;
        }

        updateMediaStore(mContext, obj.getPath().toFile());
    }
```

在上述的MtpDatabase.java的相关源码中，在mtp模式下关于从pc端拷贝文件主要就是在  
 beginCopyObject(int handle, int newParent, int newStorage)和  
 endCopyObject(int handle, boolean success) 这两个方法中负责开始拷贝和结束拷贝然后做  
 相关文件扫描显示的处理，所以就可以在开始拷贝的时候return掉不去执行核心文件的方法  
  mManager.beginCopyObject(obj, parent);在结束拷贝的时候同样也是return掉不去执行  
 核心方法updateMediaStore(mContext, obj.getPath().toFile());就这样就可以禁止在mtp  
 模式下pc端往内部存储里面拷贝文件



```
    @VisibleForNative
    private int beginMoveObject(int handle, int newParent, int newStorage) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        MtpStorageManager.MtpObject parent = newParent == 0 ?
                mManager.getStorageRoot(newStorage) : mManager.getObject(newParent);
        if (obj == null || parent == null)
            return MtpConstants.RESPONSE_INVALID_OBJECT_HANDLE;
//add core start
        if (true) {
            return MtpConstants.RESPONSE_ACCESS_DENIED;
        }
//add core end
        boolean allowed = mManager.beginMoveObject(obj, parent);
        return allowed ? MtpConstants.RESPONSE_OK : MtpConstants.RESPONSE_GENERAL_ERROR;
    }

    @VisibleForNative
    private void endMoveObject(int oldParent, int newParent, int oldStorage, int newStorage,
            int objId, boolean success) {
        MtpStorageManager.MtpObject oldParentObj = oldParent == 0 ?
                mManager.getStorageRoot(oldStorage) : mManager.getObject(oldParent);
        MtpStorageManager.MtpObject newParentObj = newParent == 0 ?
                mManager.getStorageRoot(newStorage) : mManager.getObject(newParent);
        MtpStorageManager.MtpObject obj = mManager.getObject(objId);
        String name = obj.getName();
        if (newParentObj == null || oldParentObj == null
                ||!mManager.endMoveObject(oldParentObj, newParentObj, name, success)) {
            Log.e(TAG, "Failed to end move object");
            return;
        }
//add core start
        if (true) {
            return;
        }
//add core end
        obj = mManager.getObject(objId);
        if (!success || obj == null)
            return;

        Path path = newParentObj.getPath().resolve(name);
        Path oldPath = oldParentObj.getPath().resolve(name);

        updateMediaStore(mContext, oldPath.toFile());
        updateMediaStore(mContext, path.toFile());
    }
```

在上述的MtpDatabase.java的相关源码中，在mtp模式下关于从pc端移动文件主要就是在  
 beginMoveObject(int handle, int newParent, int newStorage)和endMoveObject(int oldParent, int newParent, int oldStorage, int newStorage,  
             int objId, boolean success) 这两个方法中负责开始移动和结束移动然后做  
 相关文件扫描显示的处理，所以就可以在开始移动的时候return掉不去执行核心文件的方法  
  mManager.beginMoveObject(obj, parent);在结束移动的时候同样也是return掉不去执行  
 核心方法 updateMediaStore(mContext, oldPath.toFile());;就这样就可以禁止在mtp  
 模式下pc端往内部存储里面移动文件的相关功能



```
   private int renameFile(int handle, String newName) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        if (obj == null) {
            return MtpConstants.RESPONSE_INVALID_OBJECT_HANDLE;
        }
//add core start
        if (true) {
            return MtpConstants.RESPONSE_OBJECT_WRITE_PROTECTED;
        }
//add core end
        Path oldPath = obj.getPath();

        // now rename the file.  make sure this succeeds before updating database
        if (!mManager.beginRenameObject(obj, newName))
            return MtpConstants.RESPONSE_GENERAL_ERROR;
        Path newPath = obj.getPath();
        boolean success = oldPath.toFile().renameTo(newPath.toFile());
        try {
            Os.access(oldPath.toString(), OsConstants.F_OK);
            Os.access(newPath.toString(), OsConstants.F_OK);
        } catch (ErrnoException e) {
            // Ignore. Could fail if the metadata was already updated.
        }

        if (!mManager.endRenameObject(obj, oldPath.getFileName().toString(), success)) {
            Log.e(TAG, "Failed to end rename object");
        }
        if (!success) {
            return MtpConstants.RESPONSE_GENERAL_ERROR;
        }

        updateMediaStore(mContext, oldPath.toFile());
        updateMediaStore(mContext, newPath.toFile());
        return MtpConstants.RESPONSE_OK;
    }
```

在上述的MtpDatabase.java的相关源码中，经过源码分析得知，在mtp模式下重命令文件时，就需要  
 执行 renameFile(int handle, String newName)来给mtp模式内的文件重命名，所以就需要在这里  
 执行返回MtpConstants.RESPONSE\_OBJECT\_WRITE\_PROTECTED;就可以不用去执行重命名的  
 相关方法updateMediaStore(mContext, oldPath.toFile());这样就限制了重命名的功能实现



```
    @VisibleForNative
    private int beginDeleteObject(int handle) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        if (obj == null) {
            return MtpConstants.RESPONSE_INVALID_OBJECT_HANDLE;
        }
//add core start
        if (true) {
            return MtpConstants.RESPONSE_OBJECT_WRITE_PROTECTED;
        }
//add core end
        if (!mManager.beginRemoveObject(obj)) {
            return MtpConstants.RESPONSE_GENERAL_ERROR;
        }
        return MtpConstants.RESPONSE_OK;
    }

    @VisibleForNative
    private void endDeleteObject(int handle, boolean success) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        if (obj == null) {
            return;
        }
//add core start
        if (true) {
            return;
        }
//add core end
        if (!mManager.endRemoveObject(obj, success))
            Log.e(TAG, "Failed to end remove object");
        if (success)
            deleteFromMedia(obj, obj.getPath(), obj.isDir());
    }
```

在上述的MtpDatabase.java的相关源码中，在mtp模式下关于从pc端删除文件主要就是在  
 beginDeleteObject(int handle)和endDeleteObject(int handle, boolean success)  
  这两个方法中负责开始删除和结束删除然后做  
 相关文件扫描显示的处理，所以就可以在开始删除的时候return掉不去执行返回删除成功的值  
 MtpConstants.RESPONSE\_OK，在结束删除的时候同样也是return掉不去执行  
 核心方法 deleteFromMedia(obj, obj.getPath(), obj.isDir());就这样就可以禁止在mtp  
 模式下pc端往内部存储里面删除文件的相关功能



