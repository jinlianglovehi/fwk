



## 1.概述


  在10.0进行系统Laucher3定制中,有功能需求要求实现高斯模糊(毛玻璃)效果背景效果，在Launcher3中也是常见的功能这就需要了解Workspace的背景定义，然后对背景实现高斯模糊功能,首选要分析加载流程，然后对其背景进行高斯模糊就可以了


效果图如图：


![](https://img-blog.csdnimg.cn/b306559164ff4199893fa8d95d36b91e.png)



## 2. Launcher3单层高斯模糊(毛玻璃)效果的实现的核心代码



```
   packages\apps\Launcher3\res\layout\launcher.xml
   packages\apps\Launcher3\src\com\android\launcher3\Launcher.java
   packages\apps\Launcher3\src\com\android\launcher3\views\BlurUtil.java
```

## 3. Launcher3单层高斯模糊(毛玻璃)效果的实现代码功能分析



在Launcher3中的核心布局中，比较workspace hotseat folder等核心部件中，在  
 Launcher3中的核心部件就是在launcher.xml中，这里显示Launcher3桌面的核心控件，  
 DragLayer Workspace WorkspacePageIndicatorLine drop\_target\_bar hotseat等主要控件的布局


在虚拟桌面上可以摆放四种类型的对象：  
 1. ITEM\_SHORTCUT，应用快捷方式  
 2. ITEM\_APPWIDGET，app widget  
 3. ITEM\_LIVE\_FOLDER，文件夹  
 4. ITEM\_WALLPAPER，墙纸。


launcher3主要的类  
 LauncherModel：  
 跟数据有关系，保存了桌面运行时的状态信息，也提供了读写数据库的API，他有一个内部类LoaderTask，桌面启动从数据库中读取数据并把图标和小工具添加上去的时候用的就是他。  
 DragController：  
 DragLayer只是一个ViewGroup，具体的拖拽的处理都放到了DragController中。  
 Folder：


文件夹打开时候那个view。  
 FolderIcon：


文件夹图标。  
 LauncherProvider：


数据库类，Launcher3使用了SQLite，数据库文件保存在/data/data/包名/databases/launcher.db 下，有兴趣的同学可以把这个东西拷贝出来，用SQLite的工具看看里面都是怎么保存的。  
 ItemInfo：


运行时保存了桌面上每个项目的信息，包括图标在第几屏，第几行第几列，高度宽度等信息，每一个ItemInfo对象都对应着数据库中的一条记录。  
 LauncherProvider:


桌面信息的ContentProvider。  
 LauncherSettings:


存了数据库相关的常量，字段名，字段常量等等。  
 DatabaseHelper:


LaucherProvider的内部类，继承自SQLiteOpenHelper,数据库表的创建就是在它的onCreate方法里完成的。


LauncherAppState：  
 单例模式，主要在启动的时候用，他初始化了一些对象，并且注册了广播监听器和ContentObserver。  
 DragView：  
 在拖动图标的时候跟随手指移动的View就是他。  
 DragSource，DropTarget：  
 跟拖拽相关的接口，DragSource表示图标从哪里被拖出来，DropTarget表示图标可以被拖到哪里去。



##    3.1 增加自定义高斯模糊类BlurUtil.java



```
   package com.android.launcher3.views;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
public class BlurUtil {
	private static final float BITMAP_SCALE = 0.4f;
	private static final int BLUR_RADIUS = 7;
	public static final int BLUR_RADIUS_MAX = 25;
	public static Bitmap blur(Context context, Bitmap bitmap) {
		return blur(context, bitmap, BITMAP_SCALE, BLUR_RADIUS);
	}
	public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale) {
		return blur(context, bitmap, bitmap_scale, BLUR_RADIUS);
	}
	public static Bitmap blur(Context context, Bitmap bitmap, int blur_radius) {
		//return blur(context, bitmap, BITMAP_SCALE, blur_radius);
		return blurbitmap(context,bitmap);
	}
	public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale, int blur_radius) {
		Bitmap inputBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * bitmap_scale),
		                Math.round(bitmap.getHeight() * bitmap_scale), false);
		Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
		RenderScript rs = RenderScript.create(context);
		ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
		Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
		theIntrinsic.setRadius(blur_radius);
		theIntrinsic.setInput(tmpIn);
		theIntrinsic.forEach(tmpOut);
		tmpOut.copyTo(outputBitmap);
		rs.destroy();
		bitmap.recycle();
		return outputBitmap;
	}
	public static Bitmap blurbitmap(Context context, Bitmap bitmap) {
		//用需要创建高斯模糊bitmap创建一个空的bitmap
		Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		// 初始化Renderscript，该类提供了RenderScript context，创建其他RS类之前必须先创建这个类，其控制RenderScript的初始化，资源管理及释放
		RenderScript rs = RenderScript.create(context);
		// 创建高斯模糊对象
		ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		// 创建Allocations，此类是将数据传递给RenderScript内核的主要方 法，并制定一个后备类型存储给定类型
		Allocation allIn = Allocation.createFromBitmap(rs, bitmap);
		Allocation allOut = Allocation.createFromBitmap(rs, outBitmap);
		//设定模糊度(注：Radius最大只能设置25.f)
		blurScript.setRadius(25.0f);
		// Perform the Renderscript
		blurScript.setInput(allIn);
		blurScript.forEach(allOut);
		// Copy the final bitmap created by the out Allocation to the outBitmap
		allOut.copyTo(outBitmap);
		// recycle the original bitmap
		// bitmap.recycle();
		// After finishing everything, we destroy the Renderscript.
		rs.destroy();
		return outBitmap;
	}
	private static Bitmap blurBitmap(Bitmap bkg,Context context) {
		//设定模糊度(注：Radius最大只能设置25.f)
		float radius = 25.0f;
		//背景图片缩放处理
		bkg = smallBitmap(bkg);
		Bitmap bitmap = bkg.copy(bkg.getConfig(), false);
		final RenderScript rs = RenderScript.create(context);
		final Allocation input = Allocation.createFromBitmap(rs, bkg, Allocation.MipmapControl.MIPMAP_NONE,
		                Allocation.USAGE_SCRIPT);
		final Allocation output = Allocation.createTyped(rs, input.getType());
		final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		script.setRadius(radius);
		script.setInput(input);
		script.forEach(output);
		output.copyTo(bitmap);
		//背景图片放大处理
		bitmap = bigBitmap(bitmap);
		rs.destroy();
		return bitmap;
	}
	private static Bitmap bigBitmap(Bitmap bitmap) {
		Matrix matrix = new Matrix();
		matrix.postScale(4f,4f);
		//长和宽放大缩小的比例
		Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
		return resizeBmp;
	}
	private static Bitmap smallBitmap(Bitmap bitmap) {
		Matrix matrix = new Matrix();
		matrix.postScale(0.25f,0.25f);
		//长和宽放大缩小的比例
		Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
		return resizeBmp;
	}
}
```

## 


在上述自定义的BlurUtil.java中利用android的android.renderscript.RenderScript和android.renderscript.ScriptIntrinsicBlur等相关api 给背景设置高斯模糊或毛玻璃等


效果的背景墙，所以Launcher3的背景也可以用这些自定义的类实现给单层背景设置毛玻璃


效果的背景


## 3.2 对launcher.xml布局的分析



```
    <com.android.launcher3.LauncherRootView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:id="@+id/launcher"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fitsSystemWindows="true">

    <com.android.launcher3.dragndrop.DragLayer
        android:id="@+id/drag_layer"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:importantForAccessibility="no">

        <!-- The workspace contains 5 screens of cells -->
        <!-- DO NOT CHANGE THE ID -->
        <com.android.launcher3.Workspace
            android:id="@+id/workspace"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:layout_gravity="center"
            android:theme="@style/HomeScreenElementTheme"
            launcher:pageIndicator="@+id/page_indicator" />

        <include layout="@layout/memoryinfo_ext" />

        <!-- DO NOT CHANGE THE ID -->
        <include
            android:id="@+id/hotseat"
            layout="@layout/hotseat"
            android:visibility="gone"/>

        <include
            android:id="@+id/overview_panel"
            layout="@layout/overview_panel"
            android:visibility="gone" />



        <include
            android:id="@+id/drop_target_bar"
            layout="@layout/drop_target_bar" />

        <include
            android:id="@+id/scrim_view"
            layout="@layout/scrim_view" />

        <include
            android:id="@+id/apps_view"
            layout="@layout/all_apps"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />

    </com.android.launcher3.dragndrop.DragLayer>

</com.android.launcher3.LauncherRootView>
```

在launcher.xml中的上述代码可以看出Launcher 3的界面主要由SearchDropTargetBar、Workspace、CellLayout、PageIndicator、Hotseat组成  
 这些部分都是在DragLayer的布局中，所以说可以在DragLayout的背景实现高斯模糊的效果


## 3.3 在Launcher3中实现对DragLayout的背景实现高斯模糊的效果



```
   import android.graphics.Bitmap;
   import android.app.WallpaperManager;
   import android.graphics.drawable.BitmapDrawable;
   import android.graphics.drawable.Drawable;
   import com.android.launcher3.views.BlurUtil;
增加相关的包
public class Launcher extends BaseDraggingActivity implements LauncherExterns,
        LauncherModel.Callbacks, LauncherProviderChangeListener, UserEventDelegate,
        InvariantDeviceProfile.OnIDPChangeListener {

@Override
    protected void onCreate(Bundle savedInstanceState) {
        RaceConditionTracker.onEvent(ON_CREATE_EVT, ENTER);
....

        // We only load the page synchronously if the user rotates (or triggers a
        // configuration change) while launcher is in the foreground
        int currentScreen = PagedView.INVALID_RESTORE_PAGE;
        if (savedInstanceState != null) {
            currentScreen = savedInstanceState.getInt(RUNTIME_STATE_CURRENT_SCREEN, currentScreen);
            mWorkspace.restoreSavedInstanceState(savedInstanceState);
        }

        if (!mModel.startLoader(currentScreen)) {
            if (!internalStateHandled) {
                // If we are not binding synchronously, show a fade in animation when
                // the first page bind completes.
                mDragLayer.getAlphaProperty(ALPHA_INDEX_LAUNCHER_LOAD).setValue(0);
            }
        } else {
            // Pages bound synchronously.
            mWorkspace.setCurrentPage(currentScreen);

            setWorkspaceLoading(true);
        }

        // For handling default keys
        setDefaultKeyMode(DEFAULT_KEYS_SEARCH_LOCAL);

        setContentView(mLauncherView);
        getRootView().dispatchInsets();

        // Listen for broadcasts
        registerReceiver(mScreenOffReceiver, new IntentFilter(Intent.ACTION_SCREEN_OFF));
    // 添加监听更换壁纸广播
+    registerReceiver(mWallPaperReceiver, new IntentFilter("android.intent.action.WALLPAPER_CHANGED"));
        getSystemUiController().updateUiState(SystemUiController.UI_STATE_BASE_WINDOW,
                Themes.getAttrBoolean(this, R.attr.isWorkspaceDarkText));

        if (mLauncherCallbacks != null) {
            mLauncherCallbacks.onCreate(savedInstanceState);
        }
        mRotationHelper.initialize();

        mAppMonitor.onLauncherCreated();
        TraceHelper.endSection("Launcher-onCreate");
        RaceConditionTracker.onEvent(ON_CREATE_EVT, EXIT);
        mStateManager.addStateListener(new LauncherStateManager.StateListener() {
            @Override
            public void onStateTransitionStart(LauncherState toState) {}

            @Override
            public void onStateTransitionComplete(LauncherState finalState) {
                float alpha = 1f - mCurrentAssistantVisibility;
                if (finalState == NORMAL) {
                    mAppsView.getAlphaProperty(APPS_VIEW_ALPHA_CHANNEL_INDEX).setValue(alpha);
                } else if (finalState == OVERVIEW || finalState == OVERVIEW_PEEK) {
                    mAppsView.getAlphaProperty(APPS_VIEW_ALPHA_CHANNEL_INDEX).setValue(alpha);
                    mScrimView.getAlphaProperty(SCRIM_VIEW_ALPHA_CHANNEL_INDEX).setValue(alpha);
                } else {
                    mAppsView.getAlphaProperty(APPS_VIEW_ALPHA_CHANNEL_INDEX).setValue(1f);
                    mScrimView.getAlphaProperty(SCRIM_VIEW_ALPHA_CHANNEL_INDEX).setValue(1f);
                }
            }
        });

// 增加监听更换壁纸广播
      private final BroadcastReceiver mWallPaperReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Reset AllApps to its initial state only if we are not in the middle of
            // processing a multi-step drop
            String action = intent.getAction();
			if(action.equals("android.intent.action.WALLPAPER_CHANGED")){
				setViewBackground(Launcher.this);
			}
        }
    };

```

   在Launcher3.java的上述代码发现，在onCreate(Bundle savedInstanceState)中的setupViews();就是对Launcher3的相关布局进行初始化，所以可以在setupView()中是对drag\_layer的相关布局处理 就在这部分实现高斯模糊功能



```
 /**
     * Finds all the views we need and configure them properly.
     */
    private void setupViews() {
        mDragLayer = findViewById(R.id.drag_layer);
        mFocusHandler = mDragLayer.getFocusIndicatorHelper();
        mWorkspace = mDragLayer.findViewById(R.id.workspace);
        mWorkspace.initParentViews(mDragLayer);
        mOverviewPanel = findViewById(R.id.overview_panel);
        mHotseat = findViewById(R.id.hotseat);

        mLauncherView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        // Setup the drag layer
        mDragLayer.setup(mDragController, mWorkspace);
        mCancelTouchController = UiFactory.enableLiveUIChanges(this);

        mWorkspace.setup(mDragController);
        // Until the workspace is bound, ensure that we keep the wallpaper offset locked to the
        // default state, otherwise we will update to the wrong offsets in RTL
        mWorkspace.lockWallpaperToDefaultPage();
        mWorkspace.bindAndInitFirstWorkspaceScreen(null /* recycled qsb */);
        mDragController.addDragListener(mWorkspace);

        // Get the search/delete/uninstall bar
        mDropTargetBar = mDragLayer.findViewById(R.id.drop_target_bar);

        // Setup Apps
        mAppsView = findViewById(R.id.apps_view);

        // Setup Scrim
        mScrimView = findViewById(R.id.scrim_view);

        // Setup the drag controller (drop targets have to be added in reverse order in priority)
        mDragController.setMoveTarget(mWorkspace);
        mDropTargetBar.setup(mDragController);

        mAllAppsController.setupViews(mAppsView);

        if (MeminfoController.IS_SUPPORT_SHOW_MEMINFO) {
            new MeminfoController(this);
        }
        if (ClearAllController.IS_SUPPORT_CLEAR_ALL_ON_BOTTOM) {
            new ClearAllController(this);
        }
      
       // 增加高斯模糊功能
        setViewBackground(Launcher.this);
    }

    private void setViewBackground(Context context){
      // 获取当前壁纸
       WallpaperManager wallpaperManager = WallpaperManager.getInstance(context);
       Bitmap wallpaperBitmap = wallpaperManager.getBitmap();
      // 对当前壁纸实现高斯模糊功能
       Bitmap blurBitmap = BlurUtil.blur(context, wallpaperBitmap, BlurUtil.BLUR_RADIUS_MAX);
       Drawable drawable = new BitmapDrawable(blurBitmap);
       mDragLayer.setBackground(drawable);
  }
}
```

通过上述的自定义高斯模糊类ShelfScrimView.java和BlurUtil.java核心功能主要是实现高斯模糊功能的，然后  
 在Launcher.java这个控件类的setupView（）中实现设置高斯模糊背景功能，从而  
 就可以在整个功能中实现高斯模糊背景功能


从上述代码中可以看出，在setupView（）中增加setViewBackground(Launcher.this);获取当前壁纸，然后对壁纸做高斯模糊背景设置后，设置给mDragLayer作为背景来作为单层高斯模糊背景的功能




