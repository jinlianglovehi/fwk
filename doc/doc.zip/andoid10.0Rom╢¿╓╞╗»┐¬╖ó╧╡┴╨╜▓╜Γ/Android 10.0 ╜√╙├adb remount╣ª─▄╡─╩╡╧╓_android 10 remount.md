



## 1.概述


 在10.0的系统开发中，在进行某些产品开发中，需要禁用掉adb remount功能，就是不能让系统remount,system分区 vendor分区等  
 只能有读权限没有写权限，所以接下来看下如何禁用remount功能


## 2. 禁用adb remount功能的实现的核心类



```
system\core\fs_mgr\fs_mgr_remount.cpp
system\core\adb\daemon\services.cpp
```

## 3. 禁用adb remount功能的实现的核心功能分析和实现


  
 在pc端连接设备后，进行adb 操作时，通过socket的方式来传输相关的命令到设备来执行，所以  
 当adb 发送 remount 命令时,系统会调用命令行工具/system/bin/remount来执行具体的 remount 操作。  
 这个bin文件具体是system/core/fs\_mgr/fs\_mgr\_remount.cpp编译而成,在执行具体挂载操作时，会  
 重新挂载system分区 vendor分区 product分区等主要分区来实现对system分区 vendor分区 product分区  
 的读写操作，所以为了禁止对这些分析写操作 就需要禁用remount功能


adb remount 重新挂载system分区，实现对system分区重新挂载，重新挂载的时候将修改分区的属性，常见的修改参数为分区的读写。  
 使用该命令主要是因为android系统的system分区在启动之后是只读分区，但在开发过程中需要对system分区进行修改，则需重新挂载成读写模式。


'adb remount' 的作用相当于 'adb shell mount -o rw,remount,rw /system'。


## 3.1 services.cpp中 关于remount相关命令的分析


禁用adb remount功能的实现的核心功能实现中，在通过上述的分析得知，在system/core/adb模块关于处理remount的相关操作核心就是在services.cpp中处理的，接下来分析下


services.cpp的相关源码分析



```
unique_fd daemon_service_to_fd(std::string_view name, atransport* transport) {
    ADB_LOG(Service) << "transport " << transport->serial_name() << " opening service " << name;

#if defined(__ANDROID__) && !defined(__ANDROID_RECOVERY__)
    if (name.starts_with("abb:") || name.starts_with("abb_exec:")) {
        return execute_abb_command(name);
    }
#endif

#if defined(__ANDROID__)
    if (name.starts_with("framebuffer:")) {
        return create_service_thread("fb", framebuffer_service);
    } else if (android::base::ConsumePrefix(&name, "remount:")) {
        std::string cmd = "/system/bin/remount ";
        cmd += name;
        return StartSubprocess(cmd, nullptr, SubprocessType::kRaw, SubprocessProtocol::kNone);
    }
...
```

在services.cpp中的上述源码中，在daemon\_service\_to\_fd(std::string\_view name, atransport\* transport)中  
 通过在adb 客户端来接收pc服务端 传输过来的相关命令，来解析命令后来进行相关的adb 操作，然而  
 在else if (android::base::ConsumePrefix(&name, "remount:")) {  
         std::string cmd = "/system/bin/remount ";  
         cmd += name;  
         return StartSubprocess(cmd, nullptr, SubprocessType::kRaw, SubprocessProtocol::kNone);  
     }  
 中就是解析相关的remount的相关命令，可以看出 具体就是调用/system/bin/remount来执行  
 remount这个bin文件来对分区进行重新remount的，所以具体还是需要分析/system/bin/remount的相关文件  
 接下来分析下fs\_mgr\_remount.cpp的相关源码


## 3.2 fs\_mgr\_remount.cpp的相关源码分析


禁用adb remount功能的实现的核心功能实现中，在通过上述的分析得知，在system/core/adb模块，通过上述在services.cpp中的核心代码分析得知，在处理/system/bin/remount的相关文件主要看fs\_mgr\_remount.cpp中的核心代码分析



```
static int do_remount(int argc, char* argv[]) {
    enum {
        SUCCESS = 0,
        NOT_USERDEBUG,
        BADARG,
        NOT_ROOT,
        NO_FSTAB,
        UNKNOWN_PARTITION,
        INVALID_PARTITION,
        VERITY_PARTITION,
        BAD_OVERLAY,
        NO_MOUNTS,
        REMOUNT_FAILED,
        MUST_REBOOT,
        BINDER_ERROR,
        CHECKPOINTING
    } retval = SUCCESS;

    // If somehow this executable is delivered on a "user" build, it can
    // not function, so providing a clear message to the caller rather than
    // letting if fall through and provide a lot of confusing failure messages.
    if (!ALLOW_ADBD_DISABLE_VERITY || (android::base::GetProperty("ro.debuggable", "0") != "1")) {
        LOG(ERROR) << "only functions on userdebug or eng builds";
        return NOT_USERDEBUG;
    }

    const char* fstab_file = nullptr;
    auto can_reboot = false;

    struct option longopts[] = {
            {"fstab", required_argument, nullptr, 'T'},
            {"help", no_argument, nullptr, 'h'},
            {"reboot", no_argument, nullptr, 'R'},
            {"verbose", no_argument, nullptr, 'v'},
            {0, 0, nullptr, 0},
    };
    for (int opt; (opt = ::getopt_long(argc, argv, "hRT:v", longopts, nullptr)) != -1;) {
        switch (opt) {
            case 'h':
                usage(SUCCESS);
                break;
            case 'R':
                can_reboot = true;
                break;
            case 'T':
                if (fstab_file) {
                    LOG(ERROR) << "Cannot supply two fstabs: -T " << fstab_file << " -T" << optarg;
                    usage(BADARG);
                }
                fstab_file = optarg;
                break;
            case 'v':
                verbose = true;
                break;
            default:
                LOG(ERROR) << "Bad Argument -" << char(opt);
                usage(BADARG);
                break;
        }
    }

    // Make sure we are root.
    if (::getuid() != 0) {
        LOG(ERROR) << "Not running as root. Try \"adb root\" first.";
        return NOT_ROOT;
    }

    // Read the selected fstab.
    android::fs_mgr::Fstab fstab;
    auto fstab_read = false;
    if (fstab_file) {
        fstab_read = android::fs_mgr::ReadFstabFromFile(fstab_file, &fstab);
    } else {
        fstab_read = android::fs_mgr::ReadDefaultFstab(&fstab);
        // Manufacture a / entry from /proc/mounts if missing.
        if (!GetEntryForMountPoint(&fstab, "/system") && !GetEntryForMountPoint(&fstab, "/")) {
            android::fs_mgr::Fstab mounts;
            if (android::fs_mgr::ReadFstabFromFile("/proc/mounts", &mounts)) {
                if (auto entry = GetEntryForMountPoint(&mounts, "/")) {
                    if (entry->fs_type != "rootfs") fstab.emplace_back(*entry);
                }
            }
        }
    }
    if (!fstab_read || fstab.empty()) {
        PLOG(ERROR) << "Failed to read fstab";
        return NO_FSTAB;
    }

    if (android::base::GetBoolProperty("ro.virtual_ab.enabled", false) &&
        !android::base::GetBoolProperty("ro.virtual_ab.retrofit", false)) {
        // Virtual A/B devices can use /data as backing storage; make sure we're
        // not checkpointing.
        auto vold = GetVold();
        bool checkpointing = false;
        if (!vold->isCheckpointing(&checkpointing).isOk()) {
            LOG(ERROR) << "Could not determine checkpointing status.";
            return BINDER_ERROR;
        }
        if (checkpointing) {
            LOG(ERROR) << "Cannot use remount when a checkpoint is in progress.";
            return CHECKPOINTING;
        }
    }

    // Generate the list of supported overlayfs mount points.
    auto overlayfs_candidates = fs_mgr_overlayfs_candidate_list(fstab);

    // Generate the all remountable partitions sub-list
    android::fs_mgr::Fstab all;
    for (auto const& entry : fstab) {
        if (!remountable_partition(entry)) continue;
        if (overlayfs_candidates.empty() ||
            GetEntryForMountPoint(&overlayfs_candidates, entry.mount_point) ||
            (is_wrapped(overlayfs_candidates, entry) == nullptr)) {
            all.emplace_back(entry);
        }
    }

    }

    if (partitions.empty() && !retval) {
        partitions = all;
    }

 .....
      
        retval = REMOUNT_FAILED;
    }

    if (reboot_later) reboot(setup_overlayfs);
    if (user_please_reboot_later) {
        LOG(INFO) << "Now reboot your device for settings to take effect";
        return 0;
    }

    return retval;
}

int main(int argc, char* argv[]) {
//add core start
    std::string strCommand_down ;
    strCommand_down.assign(argv[1],strlen(argv[1]));
	PLOG(ERROR) << "argc:" << argc <<"--argv:"<< strCommand_down;
	return 0;
//add core end;


    android::base::InitLogging(argv, MyLogger);
    int result = do_remount(argc, argv);
    printf("remount %s\n", result ? "failed" : "succeeded");
    return result;
}
```

禁用adb remount功能的实现的核心功能实现中，在通过上述的分析得知，在system/core/adb模块，在fs\_mgr\_remount.cpp的上述相关源码中分析得知，在通过执行adb remount命令后，会调用  
 /system/bin/remount来执行remount的这个bin文件，然后就会执行main(int argc, char\* argv[])  
 方法，而在main(int argc, char\* argv[])方法中，会首选执行do\_remount(argc, argv);来重新挂载  
 system分区 vendor分区 product分区这些分析，然后就可以system分区 vendor分区 product分区实现  
 读写功能，所以最关键的就是执行do\_remount(argc, argv);这个方法，所以禁用remount就可以  
 禁止执行do\_remount(argc, argv);就可以了，所以就在main(int argc, char\* argv[])中，  
 在执行do\_remount(argc, argv);之前通过上面的修改，执行return 0 就实现了禁用  
 remount的功能来实现了功能开发




