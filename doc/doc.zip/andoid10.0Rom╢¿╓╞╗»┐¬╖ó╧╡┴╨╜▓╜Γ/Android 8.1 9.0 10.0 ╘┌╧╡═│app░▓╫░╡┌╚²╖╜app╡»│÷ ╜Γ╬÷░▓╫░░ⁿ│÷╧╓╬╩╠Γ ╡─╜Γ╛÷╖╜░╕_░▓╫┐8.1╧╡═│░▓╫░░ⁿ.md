






在系统app中用代码调用系统安装接口安装app时抛出Permission Denial: that is not exported from UID 1000的异常时，通常是由于Uri权限导致的问题


代码如下：



```
File apk = new File(...);

Intent intent = new Intent(Intent.ACTION_VIEW);

intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

Uri uri = FileProvider.getUriForFile(this, "com.example.demo.fileprovider", apk);

intent.setDataAndType(uri, "application/vnd.android.package-archive");

startActivity(intent);

```

7.0以后需要申请uri 权限


8.1 9.0的版本 Uri的权限管理是在AMS中  
 frameworks\base\services\core\java\com\android\server\am\ActivityManagerService.java



```
 /**
     * Check if the targetPkg can be granted permission to access uri by
     * the callingUid using the given modeFlags.  Throws a security exception
     * if callingUid is not allowed to do this.  Returns the uid of the target
     * if the URI permission grant should be performed; returns -1 if it is not
     * needed (for example targetPkg already has permission to access the URI).
     * If you already know the uid of the target, you can supply it in
     * lastTargetUid else set that to -1.
     */
    @GuardedBy("this")
    int checkGrantUriPermissionLocked(int callingUid, String targetPkg, GrantUri grantUri,
            final int modeFlags, int lastTargetUid) {
        if (!Intent.isAccessUriMode(modeFlags)) {
            return -1;
        }

        if (targetPkg != null) {
            if (DEBUG_URI_PERMISSION) Slog.v(TAG_URI_PERMISSION,
                    "Checking grant " + targetPkg + " permission to " + grantUri);
        }

        final IPackageManager pm = AppGlobals.getPackageManager();

        // If this is not a content: uri, we can't do anything with it.
 if (!ContentResolver.SCHEME\_CONTENT.equals(grantUri.uri.getScheme())) {
 if (DEBUG\_URI\_PERMISSION) Slog.v(TAG\_URI\_PERMISSION,
 "Can't grant URI permission for non-content URI: " + grantUri);
 return -1;
 }

 // Bail early if system is trying to hand out permissions directly; it
 // must always grant permissions on behalf of someone explicit.
 final int callingAppId = UserHandle.getAppId(callingUid);
 if ((callingAppId == SYSTEM\_UID) || (callingAppId == ROOT\_UID)) {
 if ("com.android.settings.files".equals(grantUri.uri.getAuthority())) {
 // Exempted authority for
 // 1. cropping user photos and sharing a generated license html
 // file in Settings app
 // 2. sharing a generated license html file in TvSettings app
 } else {
 Slog.w(TAG, "For security reasons, the system cannot issue a Uri permission"
 + " grant to " + grantUri + "; use startActivityAsCaller() instead");
 return -1;
 }
 }

 final String authority = grantUri.uri.getAuthority();
 final ProviderInfo pi = getProviderInfoLocked(authority, grantUri.sourceUserId,
 MATCH\_DEBUG\_TRIAGED\_MISSING);
 if (pi == null) {
 Slog.w(TAG, "No content provider found for permission check: " +
 grantUri.uri.toSafeString());
 return -1;
 }

 int targetUid = lastTargetUid;
 if (targetUid < 0 && targetPkg != null) {
 try {
 targetUid = pm.getPackageUid(targetPkg, MATCH\_DEBUG\_TRIAGED\_MISSING,
 UserHandle.getUserId(callingUid));
 if (targetUid < 0) {
 if (DEBUG\_URI\_PERMISSION) Slog.v(TAG\_URI\_PERMISSION,
 "Can't grant URI permission no uid for: " + targetPkg);
 return -1;
 }
 } catch (RemoteException ex) {
 return -1;
 }
 }

 // If we're extending a persistable grant, then we always need to create
        // the grant data structure so that take/release APIs work
        if ((modeFlags & Intent.FLAG\_GRANT\_PERSISTABLE\_URI\_PERMISSION) != 0) {
 return targetUid;
 }

 if (targetUid >= 0) {
 // First... does the target actually need this permission?
 if (checkHoldingPermissionsLocked(pm, pi, grantUri, targetUid, modeFlags)) {
                // No need to grant the target this permission.
                if (DEBUG_URI_PERMISSION) Slog.v(TAG_URI_PERMISSION,
                        "Target " + targetPkg + " already has full permission to " + grantUri);
                return -1;
            }
        } else {
            // First...  there is no target package, so can anyone access it?
            boolean allowed = pi.exported;
            if ((modeFlags&Intent.FLAG\_GRANT\_READ\_URI\_PERMISSION) != 0) {
 if (pi.readPermission != null) {
 allowed = false;
 }
 }
 if ((modeFlags&Intent.FLAG\_GRANT\_WRITE\_URI\_PERMISSION) != 0) {
 if (pi.writePermission != null) {
 allowed = false;
 }
 }
 if (pi.pathPermissions != null) {
 final int N = pi.pathPermissions.length;
 for (int i=0; i<N; i++) {
 if (pi.pathPermissions[i] != null
 && pi.pathPermissions[i].match(grantUri.uri.getPath())) {
                        if ((modeFlags&Intent.FLAG\_GRANT\_READ\_URI\_PERMISSION) != 0) {
 if (pi.pathPermissions[i].getReadPermission() != null) {
 allowed = false;
 }
 }
 if ((modeFlags&Intent.FLAG\_GRANT\_WRITE\_URI\_PERMISSION) != 0) {
 if (pi.pathPermissions[i].getWritePermission() != null) {
 allowed = false;
 }
 }
 break;
 }
 }
 }
 if (allowed) {
 return -1;
 }
 }

 /\* There is a special cross user grant if:
 \* - The target is on another user.
 \* - Apps on the current user can access the uri without any uid permissions.
 \* In this case, we grant a uri permission, even if the ContentProvider does not normally
 \* grant uri permissions.
 \*/
 boolean specialCrossUserGrant = UserHandle.getUserId(targetUid) != grantUri.sourceUserId
 && checkHoldingPermissionsInternalLocked(pm, pi, grantUri, callingUid,
 modeFlags, false /\*without considering the uid permissions\*/);

 // Second... is the provider allowing granting of URI permissions?
 if (!specialCrossUserGrant) {
 if (!pi.grantUriPermissions) {
 throw new SecurityException("Provider " + pi.packageName
 + "/" + pi.name
 + " does not allow granting of Uri permissions (uri "
 + grantUri + ")");
 }
 if (pi.uriPermissionPatterns != null) {
 final int N = pi.uriPermissionPatterns.length;
 boolean allowed = false;
 for (int i=0; i<N; i++) {
 if (pi.uriPermissionPatterns[i] != null
 && pi.uriPermissionPatterns[i].match(grantUri.uri.getPath())) {
                        allowed = true;
                        break;
                    }
                }
                if (!allowed) {
                    throw new SecurityException("Provider " + pi.packageName
                            + "/" + pi.name
                            + " does not allow granting of permission to path of Uri "
                            + grantUri);
                }
            }
        }

        // Third...  does the caller itself have permission to access
        // this uri?
        if (!checkHoldingPermissionsLocked(pm, pi, grantUri, callingUid, modeFlags)) {
            // Require they hold a strong enough Uri permission
            if (!checkUriPermissionLocked(grantUri, callingUid, modeFlags)) {
                if (android.Manifest.permission.MANAGE_DOCUMENTS.equals(pi.readPermission)) {
                    throw new SecurityException(
                            "UID " + callingUid + " does not have permission to " + grantUri
                                    + "; you could obtain access using ACTION\_OPEN\_DOCUMENT "
                                    + "or related APIs");
                } else {
                    throw new SecurityException(
                            "UID " + callingUid + " does not have permission to " + grantUri);
                }
            }
        }
        return targetUid;
    }

```

可以看到，只要是SYSTEM\_UID 或者root\_uid，只有com.android.settings.files这个FileProvider才有权限


所以就需要把 app的FiveProvider权限添加这里就可以了 一般为 包名.fivePorvider;


8.1 9.0 修改如下:com.example.demo.fileprovider 换成你自己的fileprovider;



```
if ((callingAppId == SYSTEM\_UID) || (callingAppId == ROOT\_UID)) {
            if ("com.android.settings.files".equals(grantUri.uri.getAuthority())
|| "com.example.demo.fileprovider".equals(grantUri.uri.getAuthority())) {
                // Exempted authority for cropping user photos in Settings app
            } else {
                Slog.w(TAG, "For security reasons, the system cannot issue a Uri permission"
                        + " grant to " + grantUri + "; use startActivityAsCaller() instead");
                return -1;
            }
        }

```

而 在10.0以后 app的FiveProvider权限 在UriGrantsManagerService.java 里面  
 路径为:frameworks\base\services\core\java\com\android\server\uri\UriGrantsManagerService.java



```
int checkGrantUriPermission(int callingUid, String targetPkg, GrantUri grantUri,
            final int modeFlags, int lastTargetUid) {
        if (!Intent.isAccessUriMode(modeFlags)) {
            return -1;
        }

        if (targetPkg != null) {
            if (DEBUG) Slog.v(TAG, "Checking grant " + targetPkg + " permission to " + grantUri);
        }

        final IPackageManager pm = AppGlobals.getPackageManager();

        // If this is not a content: uri, we can't do anything with it.
 if (!ContentResolver.SCHEME\_CONTENT.equals(grantUri.uri.getScheme())) {
 if (DEBUG) Slog.v(TAG, "Can't grant URI permission for non-content URI: " + grantUri);
 return -1;
 }

 // Bail early if system is trying to hand out permissions directly; it
 // must always grant permissions on behalf of someone explicit.
 final int callingAppId = UserHandle.getAppId(callingUid);
 if ((callingAppId == SYSTEM\_UID) || (callingAppId == ROOT\_UID)) {
 if ("com.android.settings.files".equals(grantUri.uri.getAuthority())
 || "com.android.settings.module_licenses".equals(grantUri.uri.getAuthority())) {
 // Exempted authority for
 // 1. cropping user photos and sharing a generated license html
 // file in Settings app
 // 2. sharing a generated license html file in TvSettings app
 // 3. Sharing module license files from Settings app
 } else {
 Slog.w(TAG, "For security reasons, the system cannot issue a Uri permission"
 + " grant to " + grantUri + "; use startActivityAsCaller() instead");
 return -1;
 }
 }

 final String authority = grantUri.uri.getAuthority();
 final ProviderInfo pi = getProviderInfo(authority, grantUri.sourceUserId,
 MATCH\_DEBUG\_TRIAGED\_MISSING);
 if (pi == null) {
 Slog.w(TAG, "No content provider found for permission check: " +
 grantUri.uri.toSafeString());
 return -1;
 }

 int targetUid = lastTargetUid;
 if (targetUid < 0 && targetPkg != null) {
 try {
 targetUid = pm.getPackageUid(targetPkg, MATCH\_DEBUG\_TRIAGED\_MISSING,
 UserHandle.getUserId(callingUid));
 if (targetUid < 0) {
 if (DEBUG) Slog.v(TAG, "Can't grant URI permission no uid for: " + targetPkg);
 return -1;
 }
 } catch (RemoteException ex) {
 return -1;
 }
 }

 // Figure out the value returned when access is allowed
 final int allowedResult;
 if ((modeFlags & Intent.FLAG\_GRANT\_PERSISTABLE\_URI\_PERMISSION) != 0
 || pi.forceUriPermissions) {
 // If we're extending a persistable grant or need to force, then we need to return
            // "targetUid" so that we always create a grant data structure to
            // support take/release APIs
            allowedResult = targetUid;
        } else {
            // Otherwise, we can return "-1" to indicate that no grant data
            // structures need to be created
            allowedResult = -1;
        }

        if (targetUid >= 0) {
            // First...  does the target actually need this permission?
            if (checkHoldingPermissions(pm, pi, grantUri, targetUid, modeFlags)) {
                // No need to grant the target this permission.
                if (DEBUG) Slog.v(TAG,
                        "Target " + targetPkg + " already has full permission to " + grantUri);
                return allowedResult;
            }
        } else {
            // First...  there is no target package, so can anyone access it?
            boolean allowed = pi.exported;
            if ((modeFlags&Intent.FLAG\_GRANT\_READ\_URI\_PERMISSION) != 0) {
 if (pi.readPermission != null) {
 allowed = false;
 }
 }
 if ((modeFlags&Intent.FLAG\_GRANT\_WRITE\_URI\_PERMISSION) != 0) {
 if (pi.writePermission != null) {
 allowed = false;
 }
 }
 if (pi.pathPermissions != null) {
 final int N = pi.pathPermissions.length;
 for (int i=0; i<N; i++) {
 if (pi.pathPermissions[i] != null
 && pi.pathPermissions[i].match(grantUri.uri.getPath())) {
                        if ((modeFlags&Intent.FLAG\_GRANT\_READ\_URI\_PERMISSION) != 0) {
 if (pi.pathPermissions[i].getReadPermission() != null) {
 allowed = false;
 }
 }
 if ((modeFlags&Intent.FLAG\_GRANT\_WRITE\_URI\_PERMISSION) != 0) {
 if (pi.pathPermissions[i].getWritePermission() != null) {
 allowed = false;
 }
 }
 break;
 }
 }
 }
 if (allowed) {
 return allowedResult;
 }
 }

 /\* There is a special cross user grant if:
 \* - The target is on another user.
 \* - Apps on the current user can access the uri without any uid permissions.
 \* In this case, we grant a uri permission, even if the ContentProvider does not normally
 \* grant uri permissions.
 \*/
 boolean specialCrossUserGrant = targetUid >= 0
 && UserHandle.getUserId(targetUid) != grantUri.sourceUserId
 && checkHoldingPermissionsInternal(pm, pi, grantUri, callingUid,
 modeFlags, false /\*without considering the uid permissions\*/);

 // Second... is the provider allowing granting of URI permissions?
 if (!specialCrossUserGrant) {
 if (!pi.grantUriPermissions) {
 throw new SecurityException("Provider " + pi.packageName
 + "/" + pi.name
 + " does not allow granting of Uri permissions (uri "
 + grantUri + ")");
 }
 if (pi.uriPermissionPatterns != null) {
 final int N = pi.uriPermissionPatterns.length;
 boolean allowed = false;
 for (int i=0; i<N; i++) {
 if (pi.uriPermissionPatterns[i] != null
 && pi.uriPermissionPatterns[i].match(grantUri.uri.getPath())) {
                        allowed = true;
                        break;
                    }
                }
                if (!allowed) {
                    throw new SecurityException("Provider " + pi.packageName
                            + "/" + pi.name
                            + " does not allow granting of permission to path of Uri "
                            + grantUri);
                }
            }
        }

        // Third...  does the caller itself have permission to access this uri?
        if (!checkHoldingPermissions(pm, pi, grantUri, callingUid, modeFlags)) {
            // Require they hold a strong enough Uri permission
            if (!checkUriPermission(grantUri, callingUid, modeFlags)) {
                if (android.Manifest.permission.MANAGE_DOCUMENTS.equals(pi.readPermission)) {
                    throw new SecurityException(
                            "UID " + callingUid + " does not have permission to " + grantUri
                                    + "; you could obtain access using ACTION\_OPEN\_DOCUMENT "
                                    + "or related APIs");
                } else {
                    throw new SecurityException(
                            "UID " + callingUid + " does not have permission to " + grantUri);
                }
            }
        }
        return targetUid;
    }

```

同样也是由checkGrantUriPermission来负责管理FiveProvider权限


修改如下：com.example.demo.fileprovider 替换成 自己app的fiveprovider就可以了



```
 final int callingAppId = UserHandle.getAppId(callingUid);
        if ((callingAppId == SYSTEM\_UID) || (callingAppId == ROOT\_UID)) {
            if ("com.android.settings.files".equals(grantUri.uri.getAuthority())
                   || "com.example.demo.fileprovider".equals(grantUri.uri.getAuthority())
                    || "com.android.settings.module\_licenses".equals(grantUri.uri.getAuthority())) {
                // Exempted authority for
                // 1. cropping user photos and sharing a generated license html
                //    file in Settings app
                // 2. sharing a generated license html file in TvSettings app
                // 3. Sharing module license files from Settings app
            } else {
                Slog.w(TAG, "For security reasons, the system cannot issue a Uri permission"
                        + " grant to " + grantUri + "; use startActivityAsCaller() instead");
                return -1;
            }
        }

```

编译services 然后替换services.jar 或者全编译 验证即可





