






在进行laucher3定制化开发中，也会有需求要求添加allapp 按钮 点击按钮进入所有app页面  
 具体定制如下 ：  
 添加需要的资源文件如下 ：


1 all\_apps\_button.xml



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2008 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<TextView style="@style/BaseIcon" />

```

2. all\_apps\_button\_icon.xml



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2011 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_focused="true" android:drawable="@drawable/ic\_allapps\_pressed" />
    <item android:state_pressed="true" android:drawable="@drawable/ic\_allapps\_pressed" />
    <item android:drawable="@drawable/ic\_allapps" />
</selector>

```

3. packages/apps/Launcher3/res/xml/partner\_default\_layout.xml



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2009 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<favorites xmlns:launcher="http://schemas.android.com/apk/res-auto/com.android.launcher3">


    <appwidget
    launcher:packageName="com.android.deskclock"
    launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"
    launcher:screen="0"
    launcher:x="1"
    launcher:y="1"
    launcher:spanX="4"
    launcher:spanY="2" 
  />

    <!-- Hotseat (We use the screen as the position of the item in the hotseat) -->
    <!-- Dialer, Messaging, Browser, Camera -->

    <resolve
        launcher:container="-101"
        launcher:screen="0"
        launcher:x="0"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_MAPS;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_MUSIC;end" />
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="1"
        launcher:x="1"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_GALLERY;end" />
        <favorite launcher:uri="#Intent;type=images/\*;end" />
    </resolve>

    <!--favorite
        launcher:container="-101"
        launcher:screen="2"
        launcher:x="2"
        launcher:y="0" 
        launcher:packageName="com.android.documentsui"
        launcher:className="com.android.documentsui.LauncherActivity"/-->


    <resolve
        launcher:container="-101"
        launcher:screen="3"
        launcher:x="3"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.media.action.STILL\_IMAGE\_CAMERA;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA\_BUTTON;end" />
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="4"
        launcher:x="4"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end"/>
    </resolve>

    <!-- <resolve
        launcher:container="-101"
        launcher:screen="3"
        launcher:x="3"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.media.action.STILL\_IMAGE\_CAMERA;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA\_BUTTON;end" />
    </resolve> -->

    <!-- Bottom row -->
    <!-- Email, Gallery, Music, Settings -->
    <!-- <resolve
        launcher:screen="0"
        launcher:x="0"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_EMAIL;end" />
        <favorite launcher:uri="mailto:" />
    </resolve>

    <resolve
        launcher:screen="0"
        launcher:x="1"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_GALLERY;end" />
        <favorite launcher:uri="#Intent;type=images/\*;end" />
    </resolve>

    <resolve
        launcher:screen="0"
        launcher:x="-2"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_MUSIC;end" />
    </resolve>

    <resolve
        launcher:screen="0"
        launcher:x="-1"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end" />
    </resolve> -->

    <favorite
        launcher:screen="1"
        launcher:x="0"
        launcher:y="0" 
        launcher:packageName="com.android.dialer"
        launcher:className="com.android.dialer.main.impl.MainActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="1"
        launcher:y="0" 
        launcher:packageName="com.android.messaging"
        launcher:className="com.android.messaging.ui.conversationlist.ConversationListActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="2"
        launcher:y="0" 
        launcher:packageName="com.android.contacts"
        launcher:className="com.android.contacts.activities.PeopleActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="3"
        launcher:y="0" 
        launcher:packageName="com.android.email"
        launcher:className="com.android.email.activity.Welcome"
        />
    <favorite
        launcher:screen="1"
        launcher:x="4"
        launcher:y="0" 
        launcher:packageName="com.android.chrome"
        launcher:className="com.google.android.apps.chrome.Main"
        />
    <favorite
        launcher:screen="1"
        launcher:x="5"
        launcher:y="0" 
        launcher:packageName="com.android.soundrecorder"
        launcher:className="com.sprd.soundrecorder.RecorderActivity"
        />

    <favorite
        launcher:screen="1"
        launcher:x="0"
        launcher:y="1" 
        launcher:packageName="com.android.calendar"
        launcher:className="com.android.calendar.AllInOneActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="1"
        launcher:y="1" 
        launcher:packageName="com.android.deskclock"
        launcher:className="com.android.deskclock.DeskClock"
        />
    <favorite
        launcher:screen="1"
        launcher:x="2"
        launcher:y="1" 
        launcher:packageName="com.android.calculator2"
        launcher:className="com.android.calculator2.Calculator"
        />
    <favorite
        launcher:screen="1"
        launcher:x="3"
        launcher:y="1" 
        launcher:packageName="com.android.fmradio"
        launcher:className="com.android.fmradio.FmMainActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="4"
        launcher:y="1" 
        launcher:packageName="com.android.quicksearchbox"
        launcher:className="com.android.quicksearchbox.SearchActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="5"
        launcher:y="1" 
        launcher:packageName="com.tencent.android.qqdownloader"
        launcher:className="com.tencent.pangu.link.SplashActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="0"
        launcher:y="2" 
        launcher:packageName="com.sprd.sprdnote"
        launcher:className="com.sprd.sprdnote.widget.NoteAppWidgetProvider"
        />
    <favorite
        launcher:screen="1"
        launcher:x="1"
        launcher:y="2" 
        launcher:packageName="com.android.gallery3d"
        launcher:className="com.sprd.gallery3d.app.NewVideoActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="2"
        launcher:y="2" 
        launcher:packageName="com.android.dialer"
        launcher:className="com.android.dialer.app.calllog.CallLogActivity"
        />

</favorites>

```

ic\_allapps.png  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/a4af0b57ce4c466fa091c1578ac85298.png#pic_center)ic\_allapps\_pressed.png  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/fba484e7f10b40959be859bc0da9be54.png#pic_center)


第二部分：源码修改


Hotseat.java 添加点击事件 和 加载allapp 按钮代码


4. packages/apps/Launcher3/src/com/android/launcher3/Hotseat.java



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/Hotseat.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/Hotseat.java
@@ -25,7 +25,7 @@ import android.view.View;
 import android.view.ViewDebug;
 import android.view.ViewGroup;
 import android.widget.FrameLayout;
-
+import com.android.launcher3.Utilities;
 import com.android.launcher3.graphics.RotationMode;
 import com.android.launcher3.logging.StatsLogUtils.LogContainerProvider;
 import com.android.launcher3.userevent.nano.LauncherLogProto;
@@ -33,13 +33,18 @@ import com.android.launcher3.userevent.nano.LauncherLogProto.Target;
 import com.android.launcher3.views.Transposable;
 import com.sprd.ext.LauncherAppMonitor;
 import com.sprd.ext.grid.HotseatController;
-
+import android.view.LayoutInflater;
+import android.widget.TextView;
+import android.graphics.drawable.Drawable;
 public class Hotseat extends CellLayout implements LogContainerProvider, Insettable, Transposable {
 
     @ViewDebug.ExportedProperty(category = "launcher")
     public boolean mHasVerticalHotseat;
     private final HotseatController mController;
-
+    private boolean DISABLE_ALL_APPS = false;
+    private Context mContext = null;
+    private final Launcher mLauncher;
+    private CellLayout mContent;
     public Hotseat(Context context) {
         this(context, null);
     }
@@ -51,6 +56,8 @@ public class Hotseat extends CellLayout implements LogContainerProvider, Insetta
     public Hotseat(Context context, AttributeSet attrs, int defStyle) {
         super(context, attrs, defStyle);
         mController = LauncherAppMonitor.getInstance(context).getHotseatController();
+               this.mContext = context;
+        mLauncher = Launcher.getLauncher(context);
     }
 
     public HotseatController getController() {
@@ -65,7 +72,11 @@ public class Hotseat extends CellLayout implements LogContainerProvider, Insetta
     public int getCellYFromOrder(int rank) {
         return mHasVerticalHotseat ? (getCountY() - (rank + 1)) : 0;
     }
-
+   @Override
+    protected void onFinishInflate() {
+        super.onFinishInflate();
+        mContent = findViewById(R.id.hotseat);
+    }
     public void resetLayout(boolean hasVerticalHotseat) {
         removeAllViewsInLayout();
         mHasVerticalHotseat = hasVerticalHotseat;
@@ -75,8 +86,43 @@ public class Hotseat extends CellLayout implements LogContainerProvider, Insetta
         } else {
             setGridSize(idp.numHotseatIcons, 1);
         }
+        addAllappsLayout();
     }
    加载allapp按钮
+    void addAllappsLayout() {
+ 
+        if (!DISABLE_ALL_APPS) {
+            // Add the Apps button
+            int mAllAppsButtonRank = 2;
+            LayoutInflater inflater = LayoutInflater.from(mContext);
+            TextView allAppsButton = (TextView)
+                    inflater.inflate(R.layout.all_apps_button, mContent, false);
+            Drawable d = mContext.getResources().getDrawable(R.drawable.all_apps_button_icon);
+            mLauncher.resizeIconDrawable(d);
+            allAppsButton.setCompoundDrawables(null, d, null, null);
+ 
+            allAppsButton.setContentDescription(mContext.getString(R.string.label_application));
+            if (mLauncher != null) {
+                //allAppsButton.setOnTouchListener(mLauncher.getHapticFeedbackTouchListener());
+            }
+            allAppsButton.setOnClickListener(new View.OnClickListener() {
+                @Override
+                public void onClick(android.view.View v) {
+                    if (mLauncher != null) {
+                        mLauncher.onClickAllAppsButton(v);
+                    }
+                }
+            });
+ 
+            // Note: We do this to ensure that the hotseat is always laid out in the orientation of
+            // the hotseat in order regardless of which orientation they were added
+            int x = getCellXFromOrder(mAllAppsButtonRank);
+            int y = getCellYFromOrder(mAllAppsButtonRank);
+            CellLayout.LayoutParams lp = new CellLayout.LayoutParams(2,0,1,1);
+            lp.canReorder = false;
+            mContent.addViewToCellLayout(allAppsButton, -1, allAppsButton.getId(), lp, true);
+        }
+    }
     @Override
     public void fillInLogContainerData(View v, ItemInfo info, Target target, Target targetParent) {
         target.gridX = info.cellX;

```

5. Launcher3 添加allapp 点击事件的处理



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/Launcher.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/Launcher.java
@@ -80,7 +80,7 @@ import android.view.ViewGroup;
 import android.view.accessibility.AccessibilityEvent;
 import android.view.animation.OvershootInterpolator;
 import android.widget.Toast;
-
+import android.graphics.drawable.Drawable;
 import com.android.launcher3.DropTarget.DragObject;
 import com.android.launcher3.accessibility.LauncherAccessibilityDelegate;
 import com.android.launcher3.allapps.AllAppsContainerView;
@@ -2746,4 +2746,10 @@ public class Launcher extends BaseDraggingActivity implements LauncherExterns,
     public ScrimView getScrimView() {
         return mScrimView;
     }
+    public void onClickAllAppsButton(View v){
+               mWorkspace.setCurrentPage(1);
+    }
+    public void resizeIconDrawable(Drawable icon) {
+        icon.setBounds(0, 0, mDeviceProfile.iconSizePx, mDeviceProfile.iconSizePx);
+    }
 }

```




