



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Launcher3去掉抽屉功能不显示app列表的核心代码](#2.Launcher3%E5%8E%BB%E6%8E%89%E6%8A%BD%E5%B1%89%E5%8A%9F%E8%83%BD%E4%B8%8D%E6%98%BE%E7%A4%BAapp%E5%88%97%E8%A1%A8%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.Launcher3去掉抽屉功能不显示app列表的代码分析功能实现](#3.Launcher3%E5%8E%BB%E6%8E%89%E6%8A%BD%E5%B1%89%E5%8A%9F%E8%83%BD%E4%B8%8D%E6%98%BE%E7%A4%BAapp%E5%88%97%E8%A1%A8%E7%9A%84%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 OverviewToAllAppsTouchController横屏关于抽屉上滑的控制点](#%C2%A0%203.1%20OverviewToAllAppsTouchController%E6%A8%AA%E5%B1%8F%E5%85%B3%E4%BA%8E%E6%8A%BD%E5%B1%89%E4%B8%8A%E6%BB%91%E7%9A%84%E6%8E%A7%E5%88%B6%E7%82%B9)


[3.2 PortraitStatesTouchController.java关于竖屏抽屉上滑事件控制点](#3.2%20PortraitStatesTouchController.java%E5%85%B3%E4%BA%8E%E7%AB%96%E5%B1%8F%E6%8A%BD%E5%B1%89%E4%B8%8A%E6%BB%91%E4%BA%8B%E4%BB%B6%E6%8E%A7%E5%88%B6%E7%82%B9)




---



## 1.概述


  在Launcher3开发中，各种各样的需求定制，Launcher3默认是双层抽屉式的，现在需求要求改为单层，然后去掉抽屉上滑显示app列表的功能


## 2.Launcher3去掉抽屉功能不显示app列表的核心代码



```
   packages/apps/Launcher3/quickstep/src/com/android/launcher3/uioverrides/touchcontrollers/PortraitStatesTouchController.java
   packages/apps/Launcher3/quickstep/recents_ui_overrides/src/com/android/launcher3/uioverrides/touchcontrollers/OverviewToAllAppsTouchController.java
```

## 3.Launcher3去掉抽屉功能不显示app列表的代码分析功能实现


## 


Launcher3的主要界面主要结构有如下几个  
 workspace工作区，主要包括SearchBar、CellLayout、PageIndicator、hotseat  
 CellLayout.java  //继承自viewgroup，Launcher布局的计算类，图标的显示边距等，组成workspace的view,既是一个dragSource又是一个dropTarget,可以将它里面的item拖出去，也可以容纳拖动过来的item。在workspace\_screen里面定了一些它的view参数  
 Launcher.java   //launcher主要的activity，是launcher第一次启动的activity，显示和启动一些初始化的view  
 BubbleTextView.java //继承自TextView，Launcher所有各个icon间距文字显示的父类，包括文字的大小，文字的刷新  
 Workspace.java //继承自PagedView,由N个cellLayout组成,从cellLayout更高一级的层面上对事件的处理  
 LoaderTask.java //继承Runnable,加载各个模块Task的显示类，如workspace工作区icon、所有应用icon的初始化工作  
 PackageUpdatedTask.java //继承BaseModelUpdateTask，实际也是Runnable,PMS安装应用后更新Launcher图标及逻辑的实现类  
 OverviewToAllAppsTouchController.java //继承自PortraitStatesTouchController，横向控制抽屉式All应用界面的触摸控制器  
 PortraitStatesTouchController.java 竖向控制抽屉式All应用界面的触摸控制器  
 SecondaryDropTarget.java //继承自ButtonDropTarget，实际也是TextView,长按APP icon的操作类，对icon进行移动、删除、移除、取消、卸载等操作  
 PortraitStatesTouchController.java //继承自AbstractStateChangeTouchController，纵向控制抽屉式All应用界面的触摸类,用于处理纵向UI中各种状态转换  
 通过上述的Launcher3中的核心类的功能的简单描述，发现主要控制抽屉式上滑显示app列表的类，就是  
 PortraitStatesTouchController.java和OverviewToAllAppsTouchController.java 它们分别代表横向和  
 竖向上滑显示抽屉桌面app列表的核心处理类，所以禁止上滑事件就需要在这里做处理，具体分析如下


## 


## 3.1 OverviewToAllAppsTouchController横屏关于抽屉上滑的控制点



```
  /**
 * Touch controller from going from OVERVIEW to ALL_APPS.
 *
 * This is used in landscape mode. It is also used in portrait mode for the fallback recents.
 */
public class OverviewToAllAppsTouchController extends PortraitStatesTouchController {

    public OverviewToAllAppsTouchController(Launcher l) {
        super(l, true /* allowDragToOverview */);
    }

    @Override
    protected boolean canInterceptTouch(MotionEvent ev) {
        if (mCurrentAnimation != null) {
            // If we are already animating from a previous state, we can intercept.
            return true;
        }
        if (AbstractFloatingView.getTopOpenView(mLauncher) != null) {
            return false;
        }
        if (mLauncher.isInState(ALL_APPS)) {
            // In all-apps only listen if the container cannot scroll itself
            return mLauncher.getAppsView().shouldContainerScroll(ev);
        } else if (mLauncher.isInState(NORMAL)) {
            return (ev.getEdgeFlags() & Utilities.EDGE_NAV_BAR) == 0;
        } else if (mLauncher.isInState(OVERVIEW)) {
            RecentsView rv = mLauncher.getOverviewPanel();
            return ev.getY() > (rv.getBottom() - rv.getPaddingBottom());
        } else {
            return false;
        }
    }

    @Override
    protected LauncherState getTargetState(LauncherState fromState, boolean isDragTowardPositive) {
        if (fromState == ALL_APPS && !isDragTowardPositive) {
            // Should swipe down go to OVERVIEW instead?
            return TouchInteractionService.isConnected() ?
                    mLauncher.getStateManager().getLastState() : NORMAL;
        } else if (isDragTowardPositive) {
            return ALL_APPS;
        }
        return fromState;
    }

    @Override
    protected int getLogContainerTypeForNormalState() {
        return LauncherLogProto.ContainerType.WORKSPACE;
    }
}

```

从上述的方法中可以看出，在OverviewToAllAppsTouchController.java中 的相关代码中，在  
 canInterceptTouch(MotionEvent ev)就是处理抽屉上滑事件的  
 所以只需要返回false就可以了 具体修改为:



```
@Override
    protected boolean canInterceptTouch(MotionEvent ev) {
      //add core start 
        if(true){
            return false;
       }
    //add core end
     
        if (mCurrentAnimation != null) {
            // If we are already animating from a previous state, we can intercept.
            return true;
        }
        if (AbstractFloatingView.getTopOpenView(mLauncher) != null) {
            return false;
        }
        if (mLauncher.isInState(ALL_APPS)) {
            // In all-apps only listen if the container cannot scroll itself
            return mLauncher.getAppsView().shouldContainerScroll(ev);
        } else if (mLauncher.isInState(NORMAL)) {
            return (ev.getEdgeFlags() & Utilities.EDGE_NAV_BAR) == 0;
        } else if (mLauncher.isInState(OVERVIEW)) {
            RecentsView rv = mLauncher.getOverviewPanel();
            return ev.getY() > (rv.getBottom() - rv.getPaddingBottom());
        } else {
            return false;
        }
    }


```

## 3.2 PortraitStatesTouchController.java关于竖屏抽屉上滑事件控制点



```
    public class PortraitStatesTouchController extends AbstractStateChangeTouchController {

    private static final String TAG = "PortraitStatesTouchCtrl";


    private final PortraitOverviewStateTouchHelper mOverviewPortraitStateTouchHelper;

    private final InterpolatorWrapper mAllAppsInterpolatorWrapper = new InterpolatorWrapper();

    private final boolean mAllowDragToOverview;

    // If true, we will finish the current animation instantly on second touch.
    private boolean mFinishFastOnSecondTouch;

    public PortraitStatesTouchController(Launcher l, boolean allowDragToOverview) {
        super(l, SwipeDetector.VERTICAL);
        mOverviewPortraitStateTouchHelper = new PortraitOverviewStateTouchHelper(l);
        mAllowDragToOverview = allowDragToOverview;
    }

    @Override
    protected boolean canInterceptTouch(MotionEvent ev) {
        if (mCurrentAnimation != null) {
            if (mFinishFastOnSecondTouch) {
                // TODO: Animate to finish instead.
                mCurrentAnimation.skipToEnd();
            }

            AllAppsTransitionController allAppsController = mLauncher.getAllAppsController();
            if (ev.getY() >= allAppsController.getShiftRange() * allAppsController.getProgress()) {
                // If we are already animating from a previous state, we can intercept as long as
                // the touch is below the current all apps progress (to allow for double swipe).
                return true;
            }
            // Otherwise, make sure everything is settled and don't intercept so they can scroll
            // recents, dismiss a task, etc.
            if (mAtomicAnim != null) {
                mAtomicAnim.end();
            }
            return false;
        }
        if (mLauncher.isInState(ALL_APPS)) {
            // In all-apps only listen if the container cannot scroll itself
            if (!mLauncher.getAppsView().shouldContainerScroll(ev)) {
                return false;
            }
        } else if (mLauncher.isInState(OVERVIEW)) {
            if (!mOverviewPortraitStateTouchHelper.canInterceptTouch(ev)) {
                return false;
            }
        } else {
            // If we are swiping to all apps instead of overview, allow it from anywhere.
            boolean interceptAnywhere = mLauncher.isInState(NORMAL) && !mAllowDragToOverview;
            // For all other states, only listen if the event originated below the hotseat height
            if (!interceptAnywhere && !isTouchOverHotseat(mLauncher, ev)) {
                return false;
            }
        }
        if (AbstractFloatingView.getTopOpenViewWithType(mLauncher, TYPE_ACCESSIBLE) != null) {
            return false;
        }
        return true;
    }

    @Override
    protected LauncherState getTargetState(LauncherState fromState, boolean isDragTowardPositive) {
        if (fromState == ALL_APPS && !isDragTowardPositive) {
            // Should swipe down go to OVERVIEW instead?
            return TouchInteractionService.isConnected() ?
                    mLauncher.getStateManager().getLastState() : NORMAL;
        } else if (fromState == OVERVIEW) {
            return isDragTowardPositive ? ALL_APPS : NORMAL;
        } else if (fromState == NORMAL && isDragTowardPositive) {
            int stateFlags = OverviewInteractionState.INSTANCE.get(mLauncher)
                    .getSystemUiStateFlags();
            return mAllowDragToOverview && TouchInteractionService.isConnected()
                    && (stateFlags & SYSUI_STATE_OVERVIEW_DISABLED) == 0
                    ? OVERVIEW : ALL_APPS;
        }
        return fromState;
    }

    
....
}
```

从上述的方法中可以看出，在PortraitStatesTouchController.java中 的相关代码中，在  
 canInterceptTouch(MotionEvent ev)就是处理抽屉上滑事件的  
 所以只需要返回false就可以了 具体修改为:



```
@Override
    protected boolean canInterceptTouch(MotionEvent ev) {
      //add core start 
        if(true){
            return false;
       }
    //add core end
     
        if (mCurrentAnimation != null) {
            if (mFinishFastOnSecondTouch) {
                // TODO: Animate to finish instead.
                mCurrentAnimation.skipToEnd();
            }

            AllAppsTransitionController allAppsController = mLauncher.getAllAppsController();
            if (ev.getY() >= allAppsController.getShiftRange() * allAppsController.getProgress()) {
                // If we are already animating from a previous state, we can intercept as long as
                // the touch is below the current all apps progress (to allow for double swipe).
                return true;
            }
            // Otherwise, make sure everything is settled and don't intercept so they can scroll
            // recents, dismiss a task, etc.
            if (mAtomicAnim != null) {
                mAtomicAnim.end();
            }
            return false;
        }
        if (mLauncher.isInState(ALL_APPS)) {
            // In all-apps only listen if the container cannot scroll itself
            if (!mLauncher.getAppsView().shouldContainerScroll(ev)) {
                return false;
            }
        } else if (mLauncher.isInState(OVERVIEW)) {
            if (!mOverviewPortraitStateTouchHelper.canInterceptTouch(ev)) {
                return false;
            }
        } else {
            // If we are swiping to all apps instead of overview, allow it from anywhere.
            boolean interceptAnywhere = mLauncher.isInState(NORMAL) && !mAllowDragToOverview;
            // For all other states, only listen if the event originated below the hotseat height
            if (!interceptAnywhere && !isTouchOverHotseat(mLauncher, ev)) {
                return false;
            }
        }
        if (AbstractFloatingView.getTopOpenViewWithType(mLauncher, TYPE_ACCESSIBLE) != null) {
            return false;
        }
        return true;
    }

```

通过上述的源码修改发现，在PortraitStatesTouchController.java和OverviewToAllAppsTouchController.java  
 中分别禁用上滑手势的相关代码就可以做到禁止上滑抽屉功能



