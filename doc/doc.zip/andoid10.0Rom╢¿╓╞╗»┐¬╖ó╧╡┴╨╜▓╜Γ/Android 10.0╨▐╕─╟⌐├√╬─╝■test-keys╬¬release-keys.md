






1.概述  
 在android 10.0的产品开发中，在产品设备上 一般会安装安兔兔 来测试机器的性能，但是有些机器开发的需求会被root掉，但是又不想让用户看到机器被root过所以就难免会被检测出来被root过  
 如图:


![在这里插入图片描述](https://img-blog.csdnimg.cn/998458cf7cbd495183b18b821136c049.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBA5a6J5Y2T5YW86IGMZnJhbWV3b3Jr5bqU55So5bel56iL5biI,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center)


这样显示root 用户肯定不会同意的，所以就必须修改 签名文件中的test-keys 为release-keys即可


### 2.修改签名文件test-keys为release-keys的核心类



```
build/core/Makefile
/build/make/core/config.mk

```

### 3.修改签名文件test-keys为release-keys的核心功能分析和实现


### 3.1config.mk的系统签名的分析


在系统中参阅相关源码发现，系统签名文件路径定义在config.xml中  
 DEFAULT\_SYSTEM\_DEV\_CERTIFICATE这个就是设置系统签名类型的参数



```
# If PRODUCT\_USE\_VNDK is true and BOARD\_VNDK\_VERSION is not defined yet,
 # BOARD\_VNDK\_VERSION will be set to "current" as default.
 # PRODUCT\_USE\_VNDK will be true in Android-P or later launching devices.
 PRODUCT_USE_VNDK := false
 ifneq ($(PRODUCT\_USE\_VNDK\_OVERRIDE),)
   PRODUCT_USE_VNDK := $(PRODUCT\_USE\_VNDK\_OVERRIDE)
 else ifeq ($(PRODUCT\_SHIPPING\_API\_LEVEL),)
   # No shipping level defined
 else ifeq ($(call math\_gt\_or\_eq,27,$(PRODUCT\_SHIPPING\_API\_LEVEL)),)
   PRODUCT_USE_VNDK := $(PRODUCT\_FULL\_TREBLE)
 endif
 
 ifeq ($(PRODUCT\_USE\_VNDK),true)
   ifndef BOARD_VNDK_VERSION
     BOARD_VNDK_VERSION := current
   endif
 endif
 
 $(KATI\_obsolete\_var PRODUCT\_USE\_VNDK\_OVERRIDE,Use PRODUCT\_USE\_VNDK instead)
 .KATI_READONLY := \
     PRODUCT_USE_VNDK
 
 # Set BOARD\_SYSTEMSDK\_VERSIONS to the latest SystemSDK version starting from P-launching
 # devices if unset.
 ifndef BOARD_SYSTEMSDK_VERSIONS
   ifdef PRODUCT_SHIPPING_API_LEVEL
   ifneq ($(call math\_gt\_or\_eq,$(PRODUCT\_SHIPPING\_API\_LEVEL),28),)
     ifeq (REL,$(PLATFORM\_VERSION\_CODENAME))
       BOARD_SYSTEMSDK_VERSIONS := $(PLATFORM\_SDK\_VERSION)
     else
       BOARD_SYSTEMSDK_VERSIONS := $(PLATFORM\_VERSION\_CODENAME)
     endif
   endif
   endif
 endif
 
 
 ifdef PRODUCT_SHIPPING_API_LEVEL
   ifneq ($(call numbers\_less\_than,$(PRODUCT\_SHIPPING\_API\_LEVEL),$(BOARD\_SYSTEMSDK\_VERSIONS)),)
     $(error BOARD\_SYSTEMSDK\_VERSIONS ($(BOARD\_SYSTEMSDK\_VERSIONS)) must all be greater than or equal to PRODUCT_SHIPPING_API_LEVEL ($(PRODUCT\_SHIPPING\_API\_LEVEL)))
   endif
   ifneq ($(call math\_gt\_or\_eq,$(PRODUCT\_SHIPPING\_API\_LEVEL),28),)
     ifneq ($(TARGET\_IS\_64\_BIT), true)
       ifneq ($(TARGET\_USES\_64\_BIT\_BINDER), true)
         $(error When PRODUCT\_SHIPPING\_API\_LEVEL >= 28, TARGET\_USES\_64\_BIT\_BINDER must be true)
       endif
     endif
   endif
   ifneq ($(call math\_gt\_or\_eq,$(PRODUCT\_SHIPPING\_API\_LEVEL),29),)
     ifneq ($(BOARD\_OTA\_FRAMEWORK\_VBMETA\_VERSION\_OVERRIDE),)
       $(error When PRODUCT\_SHIPPING\_API\_LEVEL >= 29, BOARD\_OTA\_FRAMEWORK\_VBMETA\_VERSION\_OVERRIDE cannot be set)
     endif
   endif
 endif
 
 # The default key if not set as LOCAL\_CERTIFICATE
 ifdef PRODUCT_DEFAULT_DEV_CERTIFICATE
   DEFAULT_SYSTEM_DEV_CERTIFICATE := $(PRODUCT\_DEFAULT\_DEV\_CERTIFICATE)
 else
   DEFAULT_SYSTEM_DEV_CERTIFICATE := build/target/product/security/testkey
 endif
 .KATI_READONLY := DEFAULT_SYSTEM_DEV_CERTIFICATE
 
 BUILD_NUMBER_FROM_FILE := $$(cat $(OUT\_DIR)/build\_number.txt)
 BUILD_DATETIME_FROM_FILE := $$(cat $(BUILD\_DATETIME\_FILE))
 
 # SEPolicy versions

```

而在config.xml中的这部分代码定义系统签名路径



```
ifdef PRODUCT_DEFAULT_DEV_CERTIFICATE
   DEFAULT_SYSTEM_DEV_CERTIFICATE := $(PRODUCT\_DEFAULT\_DEV\_CERTIFICATE)
 else
   DEFAULT_SYSTEM_DEV_CERTIFICATE := build/target/product/security/testkey

```

默认的系统签名就是build/target/product/security/testkey  
 接下来看Makefile关于系统签名的定义


### 3.2Makefile关于系统签名的定义



```
 # -----------------------------------------------------------------
 # build.prop
 INSTALLED_BUILD_PROP_TARGET := $(TARGET\_OUT)/build.prop
 ALL_DEFAULT_INSTALLED_MODULES += $(INSTALLED\_BUILD\_PROP\_TARGET)
 FINAL_BUILD_PROPERTIES := \
     $(call collapse-pairs, $(ADDITIONAL\_BUILD\_PROPERTIES))
 FINAL_BUILD_PROPERTIES := $(call uniq-pairs-by-first-component, \
 $(FINAL\_BUILD\_PROPERTIES),=)
 
 # A list of arbitrary tags describing the build configuration.
 # Force ":=" so we can use +=
 BUILD_VERSION_TAGS := $(BUILD\_VERSION\_TAGS)
 ifeq ($(TARGET\_BUILD\_TYPE),debug)
   BUILD_VERSION_TAGS += debug
 endif
 # The "test-keys" tag marks builds signed with the old test keys,
 # which are available in the SDK. "dev-keys" marks builds signed with
 # non-default dev keys (usually private keys from a vendor directory).
 # Both of these tags will be removed and replaced with "release-keys"
 # when the target-files is signed in a post-build step.
 ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/target/product/security/testkey)
 BUILD_KEYS := test-keys
 else
 BUILD_KEYS := dev-keys
 endif
 BUILD_VERSION_TAGS += $(BUILD\_KEYS)
 BUILD_VERSION_TAGS := $(subst $(space),$(comma),$(sort $(BUILD\_VERSION\_TAGS)))


```

从Makefile代码中看到BUILD\_KEYS就是系统签名而默认的就是test-keys  
 所以修改这个BUILD\_KEYS值就可以了  
 具体修改如下：


1. build/core/Makefile



```
ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/target/product/security/testkey)
BUILD_KEYS :=test-keys
else ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/target/product/security/release/releasekey)
BUILD_KEYS := release-keys
else
BUILD_KEYS := dev-keys
endif
BUILD_VERSION_TAGS += $(BUILD\_KEYS)
BUILD_VERSION_TAGS := $(subst $(space),$(comma),$(sort $(BUILD\_VERSION\_TAGS)))

```

中 修改BUILD\_KEYS的值 为



```
ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/target/product/security/testkey)
BUILD_KEYS := release-keys
else ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/target/product/security/release/releasekey)
BUILD_KEYS := release-keys

```

确保系统签名始终为release-keys 这样安兔兔在检测系统时，就不会出现root的字样


11.0 路径:/build/make/core/Makefile



```
 ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/make/target/product/security/testkey)
 BUILD_KEYS := test-keys
 else
 BUILD_KEYS := dev-keys
 endif

```

修改为：



```
 ifeq ($(DEFAULT\_SYSTEM\_DEV\_CERTIFICATE),build/make/target/product/security/testkey)
 BUILD_KEYS := release-keys
 else
 BUILD_KEYS := release-keys
 endif

```




