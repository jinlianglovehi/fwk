



## 1.概述


  
    在10.0的系统产品开发中,在Launcher3中系统默认是上滑抽屉模式，而产品需求要求修改为单层模式，而在上篇文章中已经  
 修改了一部分，接下来要继续修改Launcher3去掉抽屉模式，修改双层为单层系列的第二讲


## 2.Launcher3去掉抽屉模式 双层改成单层系列二的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/model/BaseModelUpdateTask.java
packages/apps/Launcher3/src/com/android/launcher3/model/PackageUpdatedTask.java
```

## 3.Launcher3去掉抽屉模式 双层改成单层系列二的核心功能分析和实现


## 


## 


在Launcher3中的去掉抽屉的开发过程中，需要更改的内容  
 1.显示所有app在桌面上  
 2.去掉上划展开应用列表  
 3.长按拖动图标去掉删除改成取消 卸载


Launcher3的主要界面主要结构有如下几个  
 workspace工作区，主要包括SearchBar、CellLayout、PageIndicator、hotseat  
 CellLayout.java  //继承自viewgroup，Launcher布局的计算类，图标的显示边距等，组成workspace的view,既是一个dragSource又是一个dropTarget,可以将它里面的item拖出去，也可以容纳拖动过来的item。在workspace\_screen里面定了一些它的view参数  
 Launcher.java   //launcher主要的activity，是launcher第一次启动的activity，显示和启动一些初始化的view  
 BubbleTextView.java //继承自TextView，Launcher所有各个icon间距文字显示的父类，包括文字的大小，文字的刷新  
 Workspace.java //继承自PagedView,由N个cellLayout组成,从cellLayout更高一级的层面上对事件的处理  
 LoaderTask.java //继承Runnable,加载各个模块Task的显示类，如workspace工作区icon、所有应用icon的初始化工作  
 PackageUpdatedTask.java //继承BaseModelUpdateTask，实际也是Runnable,PMS安装应用后更新Launcher图标及逻辑的实现类  
 OverviewToAllAppsTouchController.java //继承自PortraitStatesTouchController，横向控制抽屉式All应用界面的触摸控制器  
 在Launcher3的抽屉式改成单层桌面的流程中，在上面几节的博文中，讲了加载workspace的app数据，和把  
 app数据的信息绑定到workspace中，而本节主要就是处理单层桌面的app数据显示问题，在  
 安装和卸载app的时候 workspace绑定的app界面的刷新问题，


##     3.1 BaseModelUpdateTask.java中关于更新app列表的相关修改



```
     public abstract class BaseModelUpdateTask implements ModelUpdateTask {
  
      private static final boolean DEBUG_TASKS = false;
      private static final String TAG = "BaseModelUpdateTask";
  
      private LauncherAppState mApp;
      private LauncherModel mModel;
      private BgDataModel mDataModel;
      private AllAppsList mAllAppsList;
      private Executor mUiExecutor;
  
      public void init(LauncherAppState app, LauncherModel model,
              BgDataModel dataModel, AllAppsList allAppsList, Executor uiExecutor) {
          mApp = app;
          mModel = model;
          mDataModel = dataModel;
          mAllAppsList = allAppsList;
          mUiExecutor = uiExecutor;
      }
  
      @Override
      public final void run() {
          if (!mModel.isModelLoaded()) {
              if (DEBUG_TASKS) {
                  Log.d(TAG, "Ignoring model task since loader is pending=" + this);
              }
              // Loader has not yet run.
              return;
          }
          execute(mApp, mDataModel, mAllAppsList);
      }
.....
}
```

在Launcher中，BaseModelUpdateTask.java就是负责更新加载app列表的绑定数据，在run()中  
 根据mModel.isModelLoaded()的判断，看是否需要返回，而在单层模式下如果返回就不会调用  
 execute(mApp, mDataModel, mAllAppsList);继续绑定app列表了，所以具体修改为:



```
     @Override
      public final void run() {
          if (!mModel.isModelLoaded()) {
              if (DEBUG_TASKS) {
                  Log.d(TAG, "Ignoring model task since loader is pending=" + this);
              }
              // Loader has not yet run. 在双层模式下返回就可以了
             if(!BaseFlags.IS_SINGLE_MODEL) return;
          }
          execute(mApp, mDataModel, mAllAppsList);
      }
```

## 3.2 PackageUpdatedTask.java关于添加单层模式的app列表更新的相关代码



```
     public class PackageUpdatedTask extends BaseModelUpdateTask {
  
      private static final boolean DEBUG = false;
      private static final String TAG = "PackageUpdatedTask";
  
      public static final int OP_NONE = 0;
      public static final int OP_ADD = 1;
      public static final int OP_UPDATE = 2;
      public static final int OP_REMOVE = 3; // uninstalled
      public static final int OP_UNAVAILABLE = 4; // external media unmounted
      public static final int OP_SUSPEND = 5; // package suspended
      public static final int OP_UNSUSPEND = 6; // package unsuspended
      public static final int OP_USER_AVAILABILITY_CHANGE = 7; // user available/unavailable
  
      private final int mOp;
      private final UserHandle mUser;
      private final String[] mPackages;
  
      public PackageUpdatedTask(int op, UserHandle user, String... packages) {
          mOp = op;
          mUser = user;
          mPackages = packages;
      }
```

在PackageUpdatedTask中，它也是继承自BaseModelUpdateTask的，主要负责更新app列表，在app卸载和安装的时候  
 都是由PackageUpdatedTask负责更新app列表数据，然后来刷新app列表页



```
+import android.util.Pair;
+import android.content.pm.LauncherActivityInfo;
+import java.util.List;
+import com.android.launcher3.model.data.AppInfo;

@Override
     public void execute(LauncherAppState app, BgDataModel dataModel, AllAppsList appsList) {
         final Context context = app.getContext();
         final IconCache iconCache = app.getIconCache();
 
         final String[] packages = mPackages;
         final int N = packages.length;
         FlagOp flagOp = FlagOp.NO_OP;
         final HashSet<String> packageSet = new HashSet<>(Arrays.asList(packages));
         ItemInfoMatcher matcher = ItemInfoMatcher.ofPackages(packageSet, mUser);
         switch (mOp) {
             case OP_ADD: {
                 for (int i = 0; i < N; i++) {
                     if (DEBUG) Log.d(TAG, "mAllAppsList.addPackage " + packages[i]);
                      iconCache.updateIconsForPkg(packages[i], mUser);
                      if (FeatureFlags.LAUNCHER3_PROMISE_APPS_IN_ALL_APPS) {
                          appsList.removePackage(packages[i], Process.myUserHandle());
                      }
                      appsList.addPackage(context, packages[i], mUser);
  
                      // Automatically add homescreen icon for work profile apps for below O device.
                      if (!Utilities.ATLEAST_OREO && !Process.myUserHandle().equals(mUser)) {
                          SessionCommitReceiver.queueAppIconAddition(context, packages[i], mUser);
                      }
                  }
                  flagOp = FlagOp.removeFlag(WorkspaceItemInfo.FLAG_DISABLED_NOT_AVAILABLE);
                  break;
              }
              case OP_UPDATE:
                  for (int i = 0; i < N; i++) {
                      if (DEBUG) Log.d(TAG, "mAllAppsList.updatePackage " + packages[i]);
                      iconCache.updateIconsForPkg(packages[i], mUser);
                      appsList.updatePackage(context, packages[i], mUser);
                      app.getWidgetCache().removePackage(packages[i], mUser);
                  }
                  // Since package was just updated, the target must be available now.
                  flagOp = FlagOp.removeFlag(WorkspaceItemInfo.FLAG_DISABLED_NOT_AVAILABLE);
                  break;
              case OP_REMOVE: {
                  for (int i = 0; i < N; i++) {
                      iconCache.removeIconsForPkg(packages[i], mUser);
                  }
                  // Fall through
              }
              case OP_UNAVAILABLE:
                  for (int i = 0; i < N; i++) {
                      if (DEBUG) Log.d(TAG, "mAllAppsList.removePackage " + packages[i]);
                      appsList.removePackage(packages[i], mUser);
                      app.getWidgetCache().removePackage(packages[i], mUser);
                  }
                  flagOp = FlagOp.addFlag(WorkspaceItemInfo.FLAG_DISABLED_NOT_AVAILABLE);
                  break;
             
          }
  
          final ArrayList<AppInfo> addedOrModified = new ArrayList<>();
          addedOrModified.addAll(appsList.added);
          appsList.added.clear();
          addedOrModified.addAll(appsList.modified);
          appsList.modified.clear();
          if (!addedOrModified.isEmpty()) {
              scheduleCallbackTask((callbacks) -> callbacks.bindAppsAddedOrUpdated(addedOrModified));
          }
  
          final ArrayList<AppInfo> removedApps = new ArrayList<>(appsList.removed);
          appsList.removed.clear();
          final HashSet<ComponentName> removedComponents = new HashSet<>();
          if (mOp == OP_UPDATE) {
              for (AppInfo ai : removedApps) {
                  removedComponents.add(ai.componentName);
              }
          }

  //add core start 
+        if(BaseFlags.IS_SINGLE_MODEL){
+            final ArrayList<AppInfo> addedOrModified = new ArrayList<>();
+            addedOrModified.addAll(appsList.added);
+            updateToWorkSpace(context, app, appsList);
+        }
  // add core end

          final IntSparseArrayMap<Boolean> removedShortcuts = new IntSparseArrayMap<>();
  
          // Update shortcut infos
          if (mOp == OP_ADD || flagOp != FlagOp.NO_OP) {
              final ArrayList<WorkspaceItemInfo> updatedWorkspaceItems = new ArrayList<>();
              final ArrayList<LauncherAppWidgetInfo> widgets = new ArrayList<>();
  
              // For system apps, package manager send OP_UPDATE when an app is enabled.
              final boolean isNewApkAvailable = mOp == OP_ADD || mOp == OP_UPDATE;
             ......
              }
```

// 添加更新app列表的主要方法  
 +    public void updateToWorkSpace( Context context, LauncherAppState app , AllAppsList appsList){  
 +        if(BaseFlags.IS\_SINGLE\_MODEL){  
 +            ArrayList<Pair<ItemInfo, Object>> iteminfo\_queue = new ArrayList<>();  
 +            final List<UserHandle> profiles = UserCache.INSTANCE.get(context).getUserProfiles();  
 +            ArrayList<InstallShortcutReceiver.PendingInstallShortcutInfo> added = new ArrayList<InstallShortcutReceiver.PendingInstallShortcutInfo>();  
 +            for (UserHandle user : profiles) {  
 +                final List<LauncherActivityInfo> applications = context.getSystemService(LauncherApps.class).getActivityList(null, user);  
 +                synchronized (this) {  
 +                    for (LauncherActivityInfo info : applications) {  
 +                        for (AppInfo appInfo : appsList.added) {  
 +                            if(info.getComponentName().equals(appInfo.componentName)){  
 +                                InstallShortcutReceiver.PendingInstallShortcutInfo mPendingInstallShortcutInfo =  new InstallShortcutReceiver.PendingInstallShortcutInfo(info,context);  
 +                                added.add(mPendingInstallShortcutInfo);  
 +                                iteminfo\_queue.add(mPendingInstallShortcutInfo.getItemInfo());  
 +                            }  
 +                        }  
 +                    }  
 +                }  
 +            }  
 +            if (!added.isEmpty()) {  
 +                LauncherAppState.getInstance(context).getModel().addAndBindAddedWorkspaceItems(install\_queue );  
 +            }  
 +        }  
 +    }  
 在PackageUpdatedTask.java中的核心方法execute(LauncherAppState app, BgDataModel dataModel, AllAppsList appsList)  
 主要是负责更新app列表绑定的数据，在app卸载和安装后来更新app列表，所以在这里添加了updateToWorkSpace( Context context, LauncherAppState app , AllAppsList appsList)  
 来更新当前的app列表，然后从新绑定workspace的app列表页



