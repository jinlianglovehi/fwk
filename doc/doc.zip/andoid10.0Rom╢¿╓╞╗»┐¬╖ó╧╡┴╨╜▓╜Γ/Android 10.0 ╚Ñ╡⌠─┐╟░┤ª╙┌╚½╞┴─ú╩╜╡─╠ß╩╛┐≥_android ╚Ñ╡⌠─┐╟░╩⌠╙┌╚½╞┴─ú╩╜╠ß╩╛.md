






### 1.概述


在10.0的设备产品开发中，当app设置为全屏状态时，第一次进入app时会有个 目前处于全屏的 对话框提醒用户现在处于全屏状态但是对于产品来说不一定会需要这个全屏提示框，所以考虑掉要把这个提示框给去掉，这就要看弹窗是哪里弹出的，然后去掉就好了


### 2.去掉目前处于全屏模式的提示框的核心类



```
frameworks\base\services\core\java\com\android\server\wm\ImmersiveModeConfirmation.java

```

### 3.去掉目前处于全屏模式的提示框的核心功能分析和实现


在进行系统framework开发中，由于系统代码相当庞大，所以在使用grep搜索命令也是非常有必要的，所以在搜索framework下的关键词来找到相关代码引用  
 所以根据提示语开始在framework/base下搜索  
 “目前处于全屏模式”  
 接着继续搜索immersive\_cling\_title 发现在  
 R.layout.immersive\_mode\_cling 中引用了这个资源 接下来就来查找这个是哪里用到了


结果在ImmersiveModeConfirmation.java中找到了应用的地方  
 路径:frameworks\base\services\core\java\com\android\server\wm\ImmersiveModeConfirmation.java



```
    ImmersiveModeConfirmation(Context context, Looper looper, boolean vrModeEnabled) {
          final Display display = context.getDisplay();
          final Context uiContext = ActivityThread.currentActivityThread().getSystemUiContext();
          mContext = display.getDisplayId() == DEFAULT_DISPLAY
                  ? uiContext : uiContext.createDisplayContext(display);
          mHandler = new H(looper);
          mShowDelayMs = getNavBarExitDuration() * 3;
          mPanicThresholdMs = context.getResources()
                  .getInteger(R.integer.config_immersive_mode_confirmation_panic);
          mVrModeEnabled = vrModeEnabled;
      }
void confirmCurrentPrompt() {
          if (mClingWindow != null) {
              if (DEBUG) Slog.d(TAG, "confirmCurrentPrompt()");
              mHandler.post(mConfirm);
          }
      }
  
      private void handleHide() {
          if (mClingWindow != null) {
              if (DEBUG) Slog.d(TAG, "Hiding immersive mode confirmation");
              getWindowManager().removeView(mClingWindow);
              mClingWindow = null;
          }
      }
 
private class ClingWindowView extends FrameLayout {
        private static final int BGCOLOR = 0x80000000;
        private static final int OFFSET_DP = 96;
        private static final int ANIMATION_DURATION = 250;

        private final Runnable mConfirm;
        private final ColorDrawable mColor = new ColorDrawable(0);
        private final Interpolator mInterpolator;
        private ValueAnimator mColorAnim;
        private ViewGroup mClingLayout;

        private Runnable mUpdateLayoutRunnable = new Runnable() {
            @Override
            public void run() {
                if (mClingLayout != null && mClingLayout.getParent() != null) {
                    mClingLayout.setLayoutParams(getBubbleLayoutParams());
                }
            }
        };

        private ViewTreeObserver.OnComputeInternalInsetsListener mInsetsListener =
                new ViewTreeObserver.OnComputeInternalInsetsListener() {
                    private final int[] mTmpInt2 = new int[2];

                    @Override
                    public void onComputeInternalInsets(
                            ViewTreeObserver.InternalInsetsInfo inoutInfo) {
                        // Set touchable region to cover the cling layout.
                        mClingLayout.getLocationInWindow(mTmpInt2);
                        inoutInfo.setTouchableInsets(
                                ViewTreeObserver.InternalInsetsInfo.TOUCHABLE_INSETS_REGION);
                        inoutInfo.touchableRegion.set(
                                mTmpInt2[0],
                                mTmpInt2[1],
                                mTmpInt2[0] + mClingLayout.getWidth(),
                                mTmpInt2[1] + mClingLayout.getHeight());
                    }
                };

        private BroadcastReceiver mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(Intent.ACTION_CONFIGURATION_CHANGED)) {
                    post(mUpdateLayoutRunnable);
                }
            }
        };

        ClingWindowView(Context context, Runnable confirm) {
            super(context);
            mConfirm = confirm;
            setBackground(mColor);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
            mInterpolator = AnimationUtils
                    .loadInterpolator(mContext, android.R.interpolator.linear_out_slow_in);
        }

        @Override
        public void onAttachedToWindow() {
            super.onAttachedToWindow();

            DisplayMetrics metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
            float density = metrics.density;

            getViewTreeObserver().addOnComputeInternalInsetsListener(mInsetsListener);

            // create the confirmation cling
            mClingLayout = (ViewGroup)
                    View.inflate(getContext(), R.layout.immersive_mode_cling, null);

            final Button ok = mClingLayout.findViewById(R.id.ok);
            ok.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    mConfirm.run();
                }
            });
            addView(mClingLayout, getBubbleLayoutParams());

            if (ActivityManager.isHighEndGfx()) {
                final View cling = mClingLayout;
                cling.setAlpha(0f);
                cling.setTranslationY(-OFFSET_DP * density);

                postOnAnimation(new Runnable() {
                    @Override
                    public void run() {
                        cling.animate()
                                .alpha(1f)
                                .translationY(0)
                                .setDuration(ANIMATION_DURATION)
                                .setInterpolator(mInterpolator)
                                .withLayer()
                                .start();

                        mColorAnim = ValueAnimator.ofObject(new ArgbEvaluator(), 0, BGCOLOR);
                        mColorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                            @Override
                            public void onAnimationUpdate(ValueAnimator animation) {
                                final int c = (Integer) animation.getAnimatedValue();
                                mColor.setColor(c);
                            }
                        });
                        mColorAnim.setDuration(ANIMATION_DURATION);
                        mColorAnim.setInterpolator(mInterpolator);
                        mColorAnim.start();
                    }
                });
            } else {
                mColor.setColor(BGCOLOR);
            }

            mContext.registerReceiver(mReceiver,
                    new IntentFilter(Intent.ACTION_CONFIGURATION_CHANGED));
        }

        @Override
        public void onDetachedFromWindow() {
            mContext.unregisterReceiver(mReceiver);
        }

        @Override
        public boolean onTouchEvent(MotionEvent motion) {
            return true;
        }
    }

```

从上述的ImmersiveModeConfirmation.java类中可以知道，在检测到全屏的状态时，会调用handleShow()来弹出提示全屏的提示框来给用户提示表示现在已经是全屏的状态了  
 而 handleShow() 负责启动这个窗口



```
private void handleShow() {
    if (DEBUG) Slog.d(TAG, "Showing immersive mode confirmation");

    mClingWindow = new ClingWindowView(mContext, mConfirm);

    // we will be hiding the nav bar, so layout as if it's already hidden
    mClingWindow.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

    // show the confirmation
    WindowManager.LayoutParams lp = getClingWindowLayoutParams();
    getWindowManager().addView(mClingWindow, lp);
}

private final class H extends Handler {
    private static final int SHOW = 1;
    private static final int HIDE = 2;

    H(Looper looper) {
        super(looper);
    }

    @Override
    public void handleMessage(Message msg) {
        switch(msg.what) {
            case SHOW:
                //handleShow();
                break;
            case HIDE:
                handleHide();
                break;
        }
    }
}

```

在H这个hanlder的内部类收到SHOW消息就弹全屏提示框  
 这里收到Handler消息时 弹出提示窗口  
 所以 注释掉handleShow（）编译后发现不会在有提示窗口了





