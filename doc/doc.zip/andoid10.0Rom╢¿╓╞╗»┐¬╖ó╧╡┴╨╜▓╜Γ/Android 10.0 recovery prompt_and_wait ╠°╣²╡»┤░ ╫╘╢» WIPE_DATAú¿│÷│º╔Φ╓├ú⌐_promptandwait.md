






### 1.概述


在10.0的产品定制化中给，在一些产品升级过程中，如果出现问题，导致升级失败 怎样跳过recover恢复 直接恢复出厂设置呢，所以就需要跳过recovery菜单选项执行恢复出厂设置功能


### 2.recovery prompt\_and\_wait 跳过弹窗 自动 WIPE\_DATA（出厂设置）的核心类



```
 /bootable/recovery/recovery_ui/device.cpp

```

### 3.recovery prompt\_and\_wait 跳过弹窗 自动 WIPE\_DATA（出厂设置）的核心功能分析和实现


功能分析：  
 在recovery的过程中，首选进入recovery界面后 会等待用户的输入，然后进入相应的模式  
 而prompt\_and\_wait(）就是一个死循环 等待用户选择recovery模式  
 首先看prompt\_and\_wait(）相关代码分析



```
static Device::BuiltinAction prompt_and_wait(Device* device, int status) {
  for (;;) {
    finish_recovery();
    switch (status) {
      case INSTALL_SUCCESS:
      case INSTALL_NONE:
        ui->SetBackground(RecoveryUI::NO_COMMAND);
        break;

      case INSTALL_ERROR:
      case INSTALL_CORRUPT:
        ui->SetBackground(RecoveryUI::ERROR);
        break;
    }
    ui->SetProgressType(RecoveryUI::EMPTY);
   
   // 这里等待用户通过音量+ - 键选择recovery模式
    size_t chosen_item = ui->ShowMenu(
        {}, device->GetMenuItems(), 0, false,
        std::bind(&Device::HandleMenuKey, device, std::placeholders::_1, std::placeholders::_2));
    // Handle Interrupt key
    if (chosen_item == static_cast<size_t>(RecoveryUI::KeyError::INTERRUPTED)) {
      return Device::KEY_INTERRUPTED;
    }
    // Device-specific code may take some action here. It may return one of the core actions
    // handled in the switch statement below.
    Device::BuiltinAction chosen_action = 
        (chosen_item == static_cast<size_t>(RecoveryUI::KeyError::TIMED_OUT))
            ? Device::REBOOT
            : device->InvokeMenuItem(chosen_item);

    switch (chosen_action) {
      case Device::NO_ACTION:
        break;

      case Device::ENTER_FASTBOOT:
      case Device::ENTER_RECOVERY:
      case Device::REBOOT:
      case Device::REBOOT_BOOTLOADER:
      case Device::REBOOT_FASTBOOT:
      case Device::REBOOT_RECOVERY:
      case Device::REBOOT_RESCUE:
      case Device::SHUTDOWN:
        return chosen_action;

      case Device::WIPE_DATA:
        save_current_log = true;
        if (ui->IsTextVisible()) {
          if (ask_to_wipe_data(device)) {
            WipeData(device, false);
          }
        } else {
          WipeData(device, false);
          return Device::NO_ACTION;
        }
        break;

      case Device::WIPE_CACHE: {
        save_current_log = true;
        std::function<bool()> confirm_func = [&device]() {
          return yes_no(device, "Wipe cache?", " THIS CAN NOT BE UNDONE!");
        };
        WipeCache(ui, ui->IsTextVisible() ? confirm_func : nullptr);
        if (!ui->IsTextVisible()) return Device::NO_ACTION;
        break;
      }

      case Device::APPLY_ADB_SIDELOAD:
      case Device::APPLY_SDCARD:
      case Device::ENTER_RESCUE: {
        save_current_log = true;

        bool adb = true;
        Device::BuiltinAction reboot_action;
        if (chosen_action == Device::ENTER_RESCUE) {
          // Switch to graphics screen.
          ui->ShowText(false);
          status = ApplyFromAdb(device, true /* rescue_mode */, &reboot_action);
        } else if (chosen_action == Device::APPLY_ADB_SIDELOAD) {
          status = ApplyFromAdb(device, false /* rescue_mode */, &reboot_action);
        } else {
		  adb = false;
		  int required_battery_level;
		  if(is_battery_ok(&required_battery_level)){
			  status = ApplyFromSdcard(device, ui);
		  }else{
			  ui->Print("battery capacity is not enough for installing package: %d%% needed\n",
					  required_battery_level);
			  status = INSTALL_SKIPPED;
		  }
        }

        ui->Print("\nInstall from %s completed with status %d.\n", adb ? "ADB" : "SD card", status);
        if (status == INSTALL_REBOOT) {
          return reboot_action;
        }

.....
  }
}

```

在上述prompt\_and\_wait的代码中，



```
size_t chosen_item = ui->ShowMenu(
        {}, device->GetMenuItems(), 0, false,
        std::bind(&Device::HandleMenuKey, device, std::placeholders::_1, std::placeholders::_2));

```

就是等待用户选择recovery事件，所以可以把用户输入事件直接赋值为恢复出厂设置Device::WIPE\_DATA就可以了  
 所以去掉通过按键选择recovery模式，直接返回恢复出厂设置的事件 就可以了  
 具体修改如下:  
 其实根据源码做些修改就可以了



```
// Returns REBOOT, SHUTDOWN, or REBOOT_BOOTLOADER. Returning NO_ACTION means to take the default,
// which is to reboot or shutdown depending on if the --shutdown_after flag was passed to recovery.
static Device::BuiltinAction prompt_and_wait(Device* device, int status) {
  for (;;) {
    finish_recovery();
    switch (status) {
      case INSTALL_SUCCESS:
      case INSTALL_NONE:
        ui->SetBackground(RecoveryUI::NO_COMMAND);
        break;

      case INSTALL_ERROR:
      case INSTALL_CORRUPT:
        ui->SetBackground(RecoveryUI::ERROR);
        break;
    }
    ui->SetProgressType(RecoveryUI::EMPTY);
	// 弹出UI界面 手动选择  自动选择可以去掉
    /*size_t chosen_item = ui->ShowMenu(
        {}, device->GetMenuItems(), 0, false,
        std::bind(&Device::HandleMenuKey, device, std::placeholders::_1, std::placeholders::_2));
    // Handle Interrupt key
    if (chosen_item == static_cast<size_t>(RecoveryUI::KeyError::INTERRUPTED)) {
      return Device::KEY_INTERRUPTED;
    }*/
    // Device-specific code may take some action here. It may return one of the core actions
    // handled in the switch statement below.
    // 关键步骤 等待用户选择事件 然后根据事件做相应操作 可以直接返回出厂设置的事件
    Device::BuiltinAction chosen_action = Device::WIPE_DATA;
        //(chosen_item == static_cast<size_t>(RecoveryUI::KeyError::TIMED_OUT))
            //? Device::REBOOT
            //: device->InvokeMenuItem(chosen_item);
   //根据输入的值获取Device的事件
   可以直接去掉这部分代码，改为Device::WIPE_DATA；
    switch (chosen_action) {
      case Device::NO_ACTION:
        break;

      case Device::ENTER_FASTBOOT:
      case Device::ENTER_RECOVERY:
      case Device::REBOOT:
      case Device::REBOOT_BOOTLOADER:
      case Device::REBOOT_FASTBOOT:
      case Device::REBOOT_RECOVERY:
      case Device::REBOOT_RESCUE:
      case Device::SHUTDOWN:
        return chosen_action;

      case Device::WIPE_DATA:
        save_current_log = true;
        if (ui->IsTextVisible()) {
         // if (ask_to_wipe_data(device)) {
            WipeData(device, false);
            return Device::NO_ACTION;
         // }
        } else {
          WipeData(device, false);
          return Device::NO_ACTION;
        }
        break;

      case Device::WIPE_CACHE: {
        save_current_log = true;
        std::function<bool()> confirm_func = [&device]() {
          return yes_no(device, "Wipe cache?", " THIS CAN NOT BE UNDONE!");
        };
        WipeCache(ui, ui->IsTextVisible() ? confirm_func : nullptr);
        if (!ui->IsTextVisible()) return Device::NO_ACTION;
        break;
      }

      case Device::APPLY_ADB_SIDELOAD:
      case Device::APPLY_SDCARD:
      case Device::ENTER_RESCUE: {
        save_current_log = true;

        bool adb = true;
        Device::BuiltinAction reboot_action;
        if (chosen_action == Device::ENTER_RESCUE) {
          // Switch to graphics screen.
          ui->ShowText(false);
          status = ApplyFromAdb(device, true /* rescue_mode */, &reboot_action);
        } else if (chosen_action == Device::APPLY_ADB_SIDELOAD) {
          status = ApplyFromAdb(device, false /* rescue_mode */, &reboot_action);
        } else {
          adb = false;
          status = ApplyFromSdcard(device, ui);
        }
        .....
  }
}

```

在Device::WIPE\_DATA的事件中，去掉ask\_to\_wipe\_data(device)询问用户是否恢复出厂设置  
 直接调用WipeData(device, false);恢复出厂设置





