



**目录**



[1、概述](#1%E3%80%81%E6%A6%82%E8%BF%B0)


[2、核心代码](#2%E3%80%81%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3、代码分析](#3%E3%80%81%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1快捷功能项默认显示个数的分析](#3.1%E5%BF%AB%E6%8D%B7%E5%8A%9F%E8%83%BD%E9%A1%B9%E9%BB%98%E8%AE%A4%E6%98%BE%E7%A4%BA%E4%B8%AA%E6%95%B0%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 构造方法代码分析](#%C2%A0%C2%A0%203.2%20%E6%9E%84%E9%80%A0%E6%96%B9%E6%B3%95%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.3 从config.xml中修改默认布局个数](#3.3%20%E4%BB%8Econfig.xml%E4%B8%AD%E4%BF%AE%E6%94%B9%E9%BB%98%E8%AE%A4%E5%B8%83%E5%B1%80%E4%B8%AA%E6%95%B0)


[4.在QuickQSPanel.java中添加亮度条seekbar 实现调节亮度的功能](#4.%E5%9C%A8QuickQSPanel.java%E4%B8%AD%E6%B7%BB%E5%8A%A0%E4%BA%AE%E5%BA%A6%E6%9D%A1seekbar%20%E5%AE%9E%E7%8E%B0%E8%B0%83%E8%8A%82%E4%BA%AE%E5%BA%A6%E7%9A%84%E5%8A%9F%E8%83%BD)


[4.1构造方法中添加亮度条布局](#%C2%A0%204.1%E6%9E%84%E9%80%A0%E6%96%B9%E6%B3%95%E4%B8%AD%E6%B7%BB%E5%8A%A0%E4%BA%AE%E5%BA%A6%E6%9D%A1%E5%B8%83%E5%B1%80)


[4.2 增加亮度条控制代码](#4.2%20%E5%A2%9E%E5%8A%A0%E4%BA%AE%E5%BA%A6%E6%9D%A1%E6%8E%A7%E5%88%B6%E4%BB%A3%E7%A0%81)




---


1、概述


系统下拉状态栏系统第五篇 今天主要讲述 下拉状态栏布局的QuickQSPanel中的快捷功能项


布局默认个数和增加系统亮度调节框布局来实现调节屏幕亮度功能


## 2、核心代码



```
/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickQSPanel.java

frameworks/base/packages/SystemUI/res/values/config.xml
```

## 3、代码分析


#### 3.1快捷功能项默认显示个数的分析


接下来看下frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickQSPanel.java的代码



```
import static com.android.systemui.util.InjectionInflationController.VIEW_CONTEXT;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

import com.android.systemui.Dependency;
import com.android.systemui.DumpController;
import com.android.systemui.R;
import com.android.systemui.plugins.qs.QSTile;
import com.android.systemui.plugins.qs.QSTile.SignalState;
import com.android.systemui.plugins.qs.QSTile.State;
import com.android.systemui.qs.customize.QSCustomizer;
import com.android.systemui.tuner.TunerService;
import com.android.systemui.tuner.TunerService.Tunable;

import java.util.ArrayList;
import java.util.Collection;

import javax.inject.Inject;
import javax.inject.Named;

/**
* Version of QSPanel that only shows N Quick Tiles in the QS Header.
*/
public class QuickQSPanel extends QSPanel {

public static final String NUM_QUICK_TILES = "sysui_qqs_count";
private static final String TAG = "QuickQSPanel";

private boolean mDisabledByPolicy;
private static int mDefaultMaxTiles;
private int mMaxTiles;
protected QSPanel mFullPanel;

@Inject
public QuickQSPanel(@Named(VIEW_CONTEXT) Context context, AttributeSet attrs,
DumpController dumpController) {
super(context, attrs, dumpController);
if (mFooter != null) {
removeView(mFooter.getView());
}
if (mTileLayout != null) {
for (int i = 0; i < mRecords.size(); i++) {
mTileLayout.removeTile(mRecords.get(i));
}
removeView((View) mTileLayout);
}
mDefaultMaxTiles = getResources().getInteger(R.integer.quick_qs_panel_max_columns);
mTileLayout = new HeaderTileLayout(context);
mTileLayout.setListening(mListening);
addView((View) mTileLayout, 0 /* Between brightness and footer */);
super.setPadding(0, 0, 0, 0);
}

@Override
public void setPadding(int left, int top, int right, int bottom) {
// Always have no padding.
}

@Override
protected void addDivider() {
}

@Override
protected void onAttachedToWindow() {
super.onAttachedToWindow();
Dependency.get(TunerService.class).addTunable(mNumTiles, NUM_QUICK_TILES);
}

@Override
protected void onDetachedFromWindow() {
super.onDetachedFromWindow();
Dependency.get(TunerService.class).removeTunable(mNumTiles);
}

public void setQSPanelAndHeader(QSPanel fullPanel, View header) {
mFullPanel = fullPanel;
}

@Override
protected boolean shouldShowDetail() {
return !mExpanded;
}

@Override
protected void drawTile(TileRecord r, State state) {
if (state instanceof SignalState) {
SignalState copy = new SignalState();
state.copyTo(copy);
// No activity shown in the quick panel.
copy.activityIn = false;
copy.activityOut = false;
state = copy;
}
super.drawTile(r, state);
}

@Override
public void setHost(QSTileHost host, QSCustomizer customizer) {
super.setHost(host, customizer);
setTiles(mHost.getTiles());
}

public void setMaxTiles(int maxTiles) {
mMaxTiles = maxTiles;
if (mHost != null) {
setTiles(mHost.getTiles());
}
}

@Override
public void onTuningChanged(String key, String newValue) {
if (QS_SHOW_BRIGHTNESS.equals(key)) {
// No Brightness or Tooltip for you!
super.onTuningChanged(key, "0");
}
}

@Override
public void setTiles(Collection<QSTile> tiles) {
ArrayList<QSTile> quickTiles = new ArrayList<>();
for (QSTile tile : tiles) {
quickTiles.add(tile);
if (quickTiles.size() == mMaxTiles) {
break;
}
}
super.setTiles(quickTiles, true);
}

private final Tunable mNumTiles = new Tunable() {
@Override
public void onTuningChanged(String key, String newValue) {
setMaxTiles(getNumQuickTiles(mContext));
}
};

public static int getNumQuickTiles(Context context) {
return Dependency.get(TunerService.class).getValue(NUM_QUICK_TILES, mDefaultMaxTiles);
}

void setDisabledByPolicy(boolean disabled) {
if (disabled != mDisabledByPolicy) {
mDisabledByPolicy = disabled;
setVisibility(disabled ? View.GONE : View.VISIBLE);
}
}

/**
* Sets the visibility of this {@link QuickQSPanel}. This method has no effect when this panel
* is disabled by policy through {@link #setDisabledByPolicy(boolean)}, and in this case the
* visibility will always be {@link View#GONE}. This method is called externally by
* {@link QSAnimator} only.
*/
@Override
public void setVisibility(int visibility) {
if (mDisabledByPolicy) {
if (getVisibility() == View.GONE) {
return;
}
visibility = View.GONE;
}
super.setVisibility(visibility);
}

private static class HeaderTileLayout extends TileLayout {

private boolean mListening;
private Rect mClippingBounds = new Rect();

public HeaderTileLayout(Context context) {
super(context);
setClipChildren(false);
setClipToPadding(false);
LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,
LayoutParams.MATCH_PARENT);
lp.gravity = Gravity.CENTER_HORIZONTAL;
setLayoutParams(lp);
}

@Override
protected void onConfigurationChanged(Configuration newConfig) {
super.onConfigurationChanged(newConfig);
updateResources();
}

@Override
public void onFinishInflate(){
updateResources();
}

private LayoutParams generateTileLayoutParams() {
LayoutParams lp = new LayoutParams(mCellWidth, mCellHeight);
return lp;
}

@Override
protected void addTileView(TileRecord tile) {
addView(tile.tileView, getChildCount(), generateTileLayoutParams());
}

@Override
protected void onLayout(boolean changed, int l, int t, int r, int b) {
// We only care about clipping on the right side
mClippingBounds.set(0, 0, r - l, 10000);
setClipBounds(mClippingBounds);

calculateColumns();

for (int i = 0; i < mRecords.size(); i++) {
mRecords.get(i).tileView.setVisibility( i < mColumns ? View.VISIBLE : View.GONE);
}

setAccessibilityOrder();
layoutTileRecords(mColumns);
}

@Override
public boolean updateResources() {
mCellWidth = mContext.getResources().getDimensionPixelSize(R.dimen.qs_quick_tile_size);
mCellHeight = mCellWidth;

return false;
}

private boolean calculateColumns() {
int prevNumColumns = mColumns;
int maxTiles = mRecords.size();

if (maxTiles == 0){ // Early return during setup
mColumns = 0;
return true;
}

final int availableWidth = getMeasuredWidth() - getPaddingStart() - getPaddingEnd();
final int leftoverWhitespace = availableWidth - maxTiles * mCellWidth;
final int smallestHorizontalMarginNeeded;
smallestHorizontalMarginNeeded = leftoverWhitespace / Math.max(1, maxTiles - 1);

if (smallestHorizontalMarginNeeded > 0){
mCellMarginHorizontal = smallestHorizontalMarginNeeded;
mColumns = maxTiles;
} else{
mColumns = mCellWidth == 0 ? 1 :
Math.min(maxTiles, availableWidth / mCellWidth );
mCellMarginHorizontal = (availableWidth - mColumns * mCellWidth) / (mColumns - 1);
}
return mColumns != prevNumColumns;
}

private void setAccessibilityOrder() {
if (mRecords != null && mRecords.size() > 0) {
View previousView = this;
for (TileRecord record : mRecords) {
if (record.tileView.getVisibility() == GONE) continue;
previousView = record.tileView.updateAccessibilityOrder(previousView);
}
mRecords.get(mRecords.size() - 1).tileView.setAccessibilityTraversalBefore(
R.id.expand_indicator);
}
}

@Override
protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
// Measure each QS tile.
for (TileRecord record : mRecords) {
if (record.tileView.getVisibility() == GONE) continue;
record.tileView.measure(exactly(mCellWidth), exactly(mCellHeight));
}

int height = mCellHeight;
if (height < 0) height = 0;

setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), height);
}

@Override
public int getNumVisibleTiles() {
return mColumns;
}

@Override
protected int getColumnStart(int column) {
return getPaddingStart() + column *  (mCellWidth + mCellMarginHorizontal);
}
}
}
```

####    3.2 构造方法代码分析


    从构造器代码QuickQSPanel(）可以看出



```
 mDefaultMaxTiles = getResources().getInteger(R.integer.quick_qs_panel_max_columns);
        mTileLayout = new HeaderTileLayout(context);
        mTileLayout.setListening(mListening);
        addView((View) mTileLayout, 0 /* Between brightness and footer */);
quick_qs_panel_max_columns 即为默认显示个数
而这个值在config.xml中定义

```

#### 3.3 从config.xml中修改默认布局个数



```
<resources>
<!-- Whether to clip notification contents with a rounded rectangle. Might be expensive on
certain GPU's and thus can be turned off with only minimal visual impact. -->
<bool name="config_notifications_round_rect_clipping">true</bool>

<!-- Control whether status bar should distinguish HSPA data icon form UMTS
data icon on devices -->
<bool name="config_hspa_data_distinguishable">false</bool>

<!-- Component to be used as the status bar service.  Must implement the IStatusBar
interface.  This name is in the ComponentName flattened format (package/class)  -->
<string name="config_statusBarComponent" translatable="false">com.android.systemui.statusbar.phone.StatusBar</string>

<!-- Component to be used as the recents implementation.  Must implement the
RecentsImplementation interface.  This name is in the ComponentName flattened format
(package/class)  -->
<string name="config_recentsComponent" translatable="false">com.android.systemui.recents.OverviewProxyRecentsImpl</string>

<!-- Whether or not we show the number in the bar. -->
<bool name="config_statusBarShowNumber">false</bool>

<!-- If the lock screen should be dismissed after biometric auth. -->
<bool name="config_faceAuthDismissesKeyguard">false</bool>

<!-- Vibrator pattern for camera gesture launch. -->
<integer-array translatable="false" name="config_cameraLaunchGestureVibePattern">
<item>0</item>
<item>400</item>
</integer-array>

<!-- How many icons may be shown at once in the system bar. Includes any
slots that may be reused for things like IME control. -->
<integer name="config_maxNotificationIcons">5</integer>

<!-- Show phone (voice) signal strength instead of data in mobile RSSI. -->
<bool name="config_showPhoneRSSIForData">false</bool>

<!-- When true, show 1/2G networks as 3G. -->
<bool name="config_showMin3G">false</bool>

<!-- Show rotation lock toggle in System UI-->
<bool name="config_showRotationLock">true</bool>

<!-- Vibration duration for GlowPadView used in SearchPanelView -->
<integer translatable="false" name="config_vibration_duration">0</integer>

<!-- Vibration duration for GlowPadView used in SearchPanelView -->
<integer translatable="false" name="config_search_panel_view_vibration_duration">20</integer>

<!-- Show mic or phone affordance on Keyguard -->
<bool name="config_keyguardShowLeftAffordance">false</bool>

<!-- Show camera affordance on Keyguard -->
<bool name="config_keyguardShowCameraAffordance">false</bool>

<!-- The length of the vibration when the notification pops open. -->
<integer name="one_finger_pop_duration_ms">10</integer>

<!-- decay duration (from size_max -> size), in ms -->
<integer name="navigation_bar_deadzone_hold">333</integer>
<integer name="navigation_bar_deadzone_decay">333</integer>

<!-- orientation of the dead zone when touches have recently occurred elsewhere on screen -->
<integer name="navigation_bar_deadzone_orientation">0</integer>

<bool name="config_dead_zone_flash">false</bool>

<!-- Whether to enable dimming navigation buttons when wallpaper is not visible, should be
enabled for OLED devices to reduce/prevent burn in on the navigation bar (because of the
black background and static button placements) and disabled for all other devices to
prevent wasting cpu cycles on the dimming animation -->
<bool name="config_navigation_bar_enable_auto_dim_no_visible_wallpaper">true</bool>

<!-- The maximum number of tiles in the QuickQSPanel -->
-<integer name="quick_qs_panel_max_columns">6</integer>
+<integer name="quick_qs_panel_max_columns">9</integer>
....
</resources>
```

## 4.在QuickQSPanel.java中添加亮度条seekbar 实现调节亮度的功能


####   4.1构造方法中添加亮度条布局



```
import java.util.ArrayList;
 import java.util.Collection;
-
+import android.view.LayoutInflater;
 import javax.inject.Inject;
 import javax.inject.Named;
-
+import com.android.systemui.settings.BrightnessController;
 /**
  * Version of QSPanel that only shows N Quick Tiles in the QS Header.
  */
@@ -54,11 +54,13 @@ public class QuickQSPanel extends QSPanel {
     private static int mDefaultMaxTiles;
     private int mMaxTiles;
     protected QSPanel mFullPanel;
-
+    protected View mBrightnessView = null;
+    private BrightnessController mBrightnessController=null;
     @Inject
     public QuickQSPanel(@Named(VIEW_CONTEXT) Context context, AttributeSet attrs,
             DumpController dumpController) {
         super(context, attrs, dumpController);
+               setOrientation(VERTICAL);
         if (mFooter != null) {
             removeView(mFooter.getView());
         }

         mDefaultMaxTiles = getResources().getInteger(R.integer.quick_qs_panel_max_columns);
         mTileLayout = new HeaderTileLayout(context);
         mTileLayout.setListening(mListening);
-        addView((View) mTileLayout, 0 /* Between brightness and footer */);
+        addView((View) mTileLayout,0);
+        mBrightnessView = LayoutInflater.from(mContext).inflate(
+            R.layout.quick_settings_brightness_dialog, this, false);
+        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
+        layoutParams.topMargin = context.getResources().getDimensionPixelSize(R.dimen.status_bar_padding_start);
+        mBrightnessView.setLayoutParams(layoutParams);
+               addView(mBrightnessView,1);
+        mBrightnessController = new BrightnessController(getContext(),
+                findViewById(R.id.brightness_slider));
+               setBrightnessListening(true);
         super.setPadding(0, 0, 0, 0);
     }
 
增加亮度条布局主要代码
```

#### 4.2 增加亮度条控制代码



```
+    public void setBrightnessListening(boolean listening) {
+        if (listening) {
+            mBrightnessController.registerCallbacks();
+        } else {
+            mBrightnessController.unregisterCallbacks();
+        }
+    }
```

这样基本上就实现了亮度条布局的增加功能



