






### 1.概述


在10.0的系统产品开发中，对于app的卸载管理通常是有系统的PM负责管理的。所以在app应用卸载白名单功能的实现也是从PM在卸载方法中，按照白名单进行卸载


### 2.app应用卸载白名单的核心类



```
frameworks/base/core/java/android/content/pm/IPackageManager.aidl
frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

```

### 3.app应用卸载白名单的核心功能分析和实现


实现卸载白名单的思路  
 1 . 在IPackageManager.aidl中增加卸载白名单接口  
 2. 在系统安卸载 apk 核心代码，查询 app 包名列表，实施拦截卸载  
 安装卸载的核心代码都在 PackageManagerService.java 中


### 3.1 PM中增加卸载白名单接口



```
diff --git a/frameworks/base/core/java/android/content/pm/IPackageManager.aidl b/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

--- a/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

+++ b/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

@@ -798,4 +798,7 @@ interface IPackageManager {

     */

     int restoreAppData(String sourceDir, String pkgName);

    /* @} */

+   

+       void setUnInstallPackageWhiteList(in List<String> packageNames);

+       List<String> getUnInstallPackageWhiteList();

 }

diff --git a/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java b/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

index 45289f2e39..6727b10e35 100755

--- a/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

+++ b/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

@@ -111,7 +111,13 @@ import static com.android.server.pm.PackageManagerServiceUtils.getCompressedFile

 import static com.android.server.pm.PackageManagerServiceUtils.getLastModifiedTime;

 import static com.android.server.pm.PackageManagerServiceUtils.logCriticalInfo;

 import static com.android.server.pm.PackageManagerServiceUtils.verifySignatures;

 import android.Manifest;

 import android.annotation.IntDef;

 import android.annotation.NonNull;

@@ -2141,7 +2147,16 @@ public class PackageManagerService extends PackageManagerServiceExAbs

             }

         }

     }

-

+       private List<String> unInstallwhitepackageNames;

+           @Override

+    public void setInstallPackageWhiteList( List<String> packageNames) {

+               this.unInstallwhitepackageNames=packageNames;

+    }

+       

+       @Override

+    public List<String> getInstallPackageWhiteList(){

+               return this.unInstallwhitepackageNames;

+    }

```

在IPackageManager.aidl和PackageManagerService.java增加卸载白名单接口，在卸载时，看  
 卸载app是不是在白名单之内，否则不允许卸载app


### 3.2在系统 PackageManagerService 中拦截卸载非白名单之内的app


在系统中  
 不论是 adb 卸载还是通过系统设置拖拽卸载最终都会走 deletePackageX()



```
 // Queue up an async operation since the package deletion may take a little while.
          mHandler.post(() -> {
 int returnCode;
 final PackageSetting ps = mSettings.mPackages.get(internalPackageName);
 boolean doDeletePackage = true;
 if (ps != null) {
 final boolean targetIsInstantApp =
 ps.getInstantApp(UserHandle.getUserId(callingUid));
                  doDeletePackage = !targetIsInstantApp
                          || canViewInstantApps;
              }
              if (doDeletePackage) {
                  if (!deleteAllUsers) {
                      returnCode = deletePackageX(internalPackageName, versionCode,
                              userId, deleteFlags);
                  } else {
                      int[] blockUninstallUserIds = getBlockUninstallForUsers(
                              internalPackageName, users);
                      // If nobody is blocking uninstall, proceed with delete for all users
                      if (ArrayUtils.isEmpty(blockUninstallUserIds)) {
                          returnCode = deletePackageX(internalPackageName, versionCode,
                                  userId, deleteFlags);
                      } else {
                          // Otherwise uninstall individually for users with blockUninstalls=false
                          final int userFlags = deleteFlags & ~PackageManager.DELETE_ALL_USERS;
                          for (int userId1 : users) {
                              if (!ArrayUtils.contains(blockUninstallUserIds, userId1)) {
                                  returnCode = deletePackageX(internalPackageName, versionCode,
                                          userId1, userFlags);
                                  if (returnCode != PackageManager.DELETE_SUCCEEDED) {
                                      Slog.w(TAG, "Package delete failed for user " + userId1
                                              + ", returnCode " + returnCode);
                                  }
                              }
                          }
                          // The app has only been marked uninstalled for certain users.
                          // We still need to report that delete was blocked
                          returnCode = PackageManager.DELETE_FAILED_OWNER_BLOCKED;
                      }
                  }
              } else {
                  returnCode = PackageManager.DELETE_FAILED_INTERNAL_ERROR;
              }
              try {
                  observer.onPackageDeleted(packageName, returnCode, null);
              } catch (RemoteException e) {
                  Log.i(TAG, "Observer no longer exists.");
              } //end catch
          });
      }
  
/**
     *  This method is an internal method that could be get invoked either
     *  to delete an installed package or to clean up a failed installation.
     *  After deleting an installed package, a broadcast is sent to notify any
     *  listeners that the package has been removed. For cleaning up a failed
     *  installation, the broadcast is not necessary since the package's
 \* installation wouldn't have sent the initial broadcast either
     *  The key steps in deleting a package are
     *  deleting the package information in internal structures like mPackages,
     *  deleting the packages base directories through installd
     *  updating mSettings to reflect current status
     *  persisting settings for later use
     *  sending a broadcast if necessary
     */
    public int deletePackageX(String packageName, long versionCode, int userId, int deleteFlags) {
        final PackageRemovedInfo info = new PackageRemovedInfo(this);
        final boolean res;

        final int removeUser = (deleteFlags & PackageManager.DELETE_ALL_USERS) != 0
                ? UserHandle.USER_ALL : userId;

        if (isPackageDeviceAdmin(packageName, removeUser)) {
            Slog.w(TAG, "Not removing package " + packageName + ": has active device admin");
            return PackageManager.DELETE_FAILED_DEVICE_POLICY_MANAGER;
        }

        //  add for uninstaller black list start
       +  if(!isUninstallWhiteListApp(packageName)){
        +     return PackageManager.DELETE_FAILED_INTERNAL_ERROR;
        + }
        //  add for uninstaller black list end

        final PackageSetting uninstalledPs;
        final PackageSetting disabledSystemPs;
        final PackageParser.Package pkg;

        // for the uninstall-updates case and restricted profiles, remember the per-
        // user handle installed state
        int[] allUsers;


		......

}

+    private boolean isUninstallWhiteListApp(String packagename){

 

+               if(this.unInstallwhitepackageNames ==null || this.unInstallwhitepackageNames.size()==0){

+                       return true;

+               }

+               

+        Iterator<String> it = this.unInstallwhitepackageNames.iterator();

+        while (it.hasNext()) {

+            String whitelistItem = it.next();

+            if (whitelistItem.equals(packagename)) {

+                return true;

+            }

+        }

+        return false;

+    }

```

在PMS的deletePackageX中执行卸载app时，首先看app是否是白名单列表中的app,不是就不能卸载app





