



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.删除连接wifi的配置信息的核心类](#2.%E5%88%A0%E9%99%A4%E8%BF%9E%E6%8E%A5wifi%E7%9A%84%E9%85%8D%E7%BD%AE%E4%BF%A1%E6%81%AF%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.删除连接wifi的配置信息的核心功能分析和实现](#3.%E5%88%A0%E9%99%A4%E8%BF%9E%E6%8E%A5wifi%E7%9A%84%E9%85%8D%E7%BD%AE%E4%BF%A1%E6%81%AF%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0)


[3.1IWifiManager.aidl增加移除wifi配置接口](#3.1IWifiManager.aidl%E5%A2%9E%E5%8A%A0%E7%A7%BB%E9%99%A4wifi%E9%85%8D%E7%BD%AE%E6%8E%A5%E5%8F%A3)


[3.2 WifiManager.java里增加移除wifi配置相关信息和对提供删除wifi配置信息的调用](#3.2%20WifiManager.java%E9%87%8C%E5%A2%9E%E5%8A%A0%E7%A7%BB%E9%99%A4wifi%E9%85%8D%E7%BD%AE%E7%9B%B8%E5%85%B3%E4%BF%A1%E6%81%AF%E5%92%8C%E5%AF%B9%E6%8F%90%E4%BE%9B%E5%88%A0%E9%99%A4wifi%E9%85%8D%E7%BD%AE%E4%BF%A1%E6%81%AF%E7%9A%84%E8%B0%83%E7%94%A8)


[3.3 BaseWifiService.java添加 Iwifimanager.aidl的接口实现](#3.3%20BaseWifiService.java%E6%B7%BB%E5%8A%A0%20Iwifimanager.aidl%E7%9A%84%E6%8E%A5%E5%8F%A3%E5%AE%9E%E7%8E%B0)




---



## 1.概述


在10.0的产品开发中，对于产品要求输入ssid删除已连接wifi配置信息，同样也是在wifiManager中实现功能，需要可以删除已连接wifi的配置信息


## 2.删除连接wifi的配置信息的核心类



```
frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
frameworks/base/wifi/java/android/net/wifi/WifiManager.java
frameworks/opt/net/wifi/service/java/com/android/server/wifi/BaseWifiService.java


```

## 3.删除连接wifi的配置信息的核心功能分析和实现


### 3.1IWifiManager.aidl增加移除wifi配置接口



```
--- a/frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
+++ b/frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
@@ -262,4 +262,7 @@ interface IWifiManager
     boolean registerWifiRssiLinkSpeedAndFrequencyObserver(IWifiRssiLinkSpeedAndFrequencyObserver observer);
     boolean unregisterWifiRssiLinkSpeedAndFrequencyObserver(IWifiRssiLinkSpeedAndFrequencyObserver observer);
     //<-- Add for Wifi Rssi LinkSpeed And Frequency Observer
+       void removeWiFiConfiguration(String ssid);
 }
```

在IWifiManager.aidl中通过增加void removeWiFiConfiguration(String ssid);来实现对已连接wifi的配置文件的删除功能


### 3.2 WifiManager.java里增加移除wifi配置相关信息和对提供删除wifi配置信息的调用



```
  /**
  * This class provides the primary API for managing all aspects of Wi-Fi
  * connectivity.
  * <p>
  * On releases before {@link android.os.Build.VERSION_CODES#N}, this object
  * should only be obtained from an {@linkplain Context#getApplicationContext()
  * application context}, and not from any other derived context to avoid memory
  * leaks within the calling process.
  * <p>
  * It deals with several categories of items:
  * </p>
  * <ul>
  * <li>The list of configured networks. The list can be viewed and updated, and
  * attributes of individual entries can be modified.</li>
  * <li>The currently active Wi-Fi network, if any. Connectivity can be
  * established or torn down, and dynamic information about the state of the
  * network can be queried.</li>
  * <li>Results of access point scans, containing enough information to make
  * decisions about what access point to connect to.</li>
  * <li>It defines the names of various Intent actions that are broadcast upon
  * any sort of change in Wi-Fi state.
   * </ul>
   * <p>
   * This is the API to use when performing Wi-Fi specific operations. To perform
   * operations that pertain to network connectivity at an abstract level, use
   * {@link android.net.ConnectivityManager}.
   * </p>
   */
  @SystemService(Context.WIFI_SERVICE)
public class WifiManager {
  public WifiManager(@NonNull Context context, @NonNull IWifiManager service,
          @NonNull Looper looper) {
          mContext = context;
          mService = service;
          mLooper = looper;
          mTargetSdkVersion = context.getApplicationInfo().targetSdkVersion;
          updateVerboseLoggingEnabledFromService();
      }
      public List<WifiConfiguration> getConfiguredNetworks() {
          try {
              ParceledListSlice<WifiConfiguration> parceledList =
                      mService.getConfiguredNetworks(mContext.getOpPackageName(),
                              mContext.getAttributionTag());
              if (parceledList == null) {
                  return Collections.emptyList();
              }
              return parceledList.getList();
          } catch (RemoteException e) {
              throw e.rethrowFromSystemServer();
          }
      }
  
      /** @hide */
      @SystemApi
      @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE, READ_WIFI_CREDENTIAL})
      public List<WifiConfiguration> getPrivilegedConfiguredNetworks() {
          try {
              ParceledListSlice<WifiConfiguration> parceledList =
                      mService.getPrivilegedConfiguredNetworks(mContext.getOpPackageName(),
                              mContext.getAttributionTag());
              if (parceledList == null) {
                  return Collections.emptyList();
              }
              return parceledList.getList();
          } catch (RemoteException e) {
              throw e.rethrowFromSystemServer();
          }
      }

```

在 forgetNetwork(String ssid) 中根据ssid的类型调用wifimanager的.removePasspointConfiguration和forget的api来删除wifi配置



```
 
diff --git a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
index a55dbde9c0..4bdc586e9b 100755
--- a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
+++ b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
@@ -1764,7 +1764,28 @@ public class WifiManager {
             throw e.rethrowFromSystemServer();
         }
     }
+       public void removeWiFiConfiguration(String ssid){
+               try {
+            forgetNetwork(ssid)；
+        } catch (RemoteException e) {
+            throw e.rethrowFromSystemServer();
+        }
+    }

    public void forgetNetwork(String ssid) {
        if (TextUtils.isEmpty(ssid)) {
            return;
        }
        WifiManager mWifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
         WifiInfo mWifiInfo = mWifiManager.getConnectionInfo();
         WifiConfiguration mWifiConfig = IsExsits(ssid, mWifiManager);
         if (mWifiInfo != null && mWifiInfo.isEphemeral() && ssid.equals(mWifiInfo.getSSID())) {
            mWifiManager.disableEphemeralNetwork(mWifiInfo.getSSID());
         } else if (mWifiConfig != null) {
			if (mWifiConfig.isPasspoint()) {
			   mWifiManager.removePasspointConfiguration(mWifiConfig.FQDN);
			} else {
			   mWifiManager.forget(mWifiConfig.networkId, null);
			}
         } else {
            Log.e(TAG,"failed to forget ssid:" + ssid);
         }
    }
// 判断ssid是否存在
    private WifiConfiguration IsExsits(String SSID, WifiManager mWifiManager) {
        List<WifiConfiguration> existingConfigs = mWifiManager.getConfiguredNetworks();
        for (WifiConfiguration existingConfig : existingConfigs) {
            if (existingConfig.SSID.equals("\"" + SSID + "\"")) {
                return existingConfig;
            }
        }
        return null;
    }

```

### 3.3 BaseWifiService.java添加 Iwifimanager.aidl的接口实现


BaseWifiService的核心类主要承担wifi服务端binder通讯的角色，所以需要实现wifi的接口



```
diff --git a/frameworks/opt/net/wifi/service/java/com/android/server/wifi/BaseWifiService.java b/frameworks/opt/net/wifi/service/java/com/android/server/wifi/BaseWifiService.java
old mode 100644
new mode 100755
index 8ca3753b7b..d826f33a25
--- a/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
+++ b/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
@@ -565,4 +565,19 @@ public class BaseWifiService extends IWifiManager.Stub {
         throw new UnsupportedOperationException();
 
      @Override
      public boolean setWifiApConfiguration(WifiConfiguration wifiConfig, String packageName) {
          throw new UnsupportedOperationException();
      }
  
      @Override
      public boolean setSoftApConfiguration(SoftApConfiguration softApConfig, String packageName) {
          throw new UnsupportedOperationException();
+       @Override
+       public void removeWiFiConfiguration(String ssid){
+                throw new UnsupportedOperationException();
+               
+       }
 }

```



