






### 1.概述


在10.0的系统产品定制化开发手机项目中,如果专门适配老年机的时候，这时客户提出要求，如果最后一屏未满时，不让拖拽到后面一屏的空屏中想了解当前是哪一屏和当前屏item个数  
 [请进](https://blog.csdn.net/baidu_41666295/article/details/120406447?spm=1001.2014.3001.5502)


接下来当知道了当前是哪一屏和当前屏Item个数后


### 2.Launcher3长按拖拽时最后一屏未满时不让拖拽到后一屏(二)的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\WorkSpace.java

```

### 3.Launcher3长按拖拽时最后一屏未满时不让拖拽到后一屏(二)的核心功能分析和实现


在Launcher3中的源码中  
 在WorkSpace.java中的onDrop中就可以来做判断了



```
public void onDrop(final DragObject d, DragOptions options) {
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);
        CellLayout dropTargetLayout = mDropToLayout;

        // We want the point to be mapped to the dragTarget.
        if (dropTargetLayout != null) {
            mapPointFromDropLayout(dropTargetLayout, mDragViewVisualCenter);
        }

        boolean droppedOnOriginalCell = false;

        int snapScreen = -1;
        boolean resizeOnDrop = false;
        if (d.dragSource != this || mDragInfo == null) {
            final int[] touchXY = new int[] { (int) mDragViewVisualCenter[0],
                    (int) mDragViewVisualCenter[1] };
            onDropExternal(touchXY, dropTargetLayout, d);
        } else {
            AbstractFloatingView.closeOpenViews(mLauncher, false, AbstractFloatingView.TYPE_WIDGET_RESIZE_FRAME);
            final View cell = mDragInfo.cell;
            boolean droppedOnOriginalCellDuringTransition = false;
            Runnable onCompleteRunnable = null;

            // 当判断dropTargetLayout不为null并且d.cancelled为false时才执行拖拽到哪一屏动作 否则就会返回到原来的位置 所以就要在这里增加个条件
            if (dropTargetLayout != null && !d.cancelled) {
                // Move internally
                boolean hasMovedLayouts = (getParentCellLayoutForView(cell) != dropTargetLayout);
                boolean hasMovedIntoHotseat = mLauncher.isHotseatLayout(dropTargetLayout);
                int container = hasMovedIntoHotseat ?
                        LauncherSettings.Favorites.CONTAINER_HOTSEAT :
                        LauncherSettings.Favorites.CONTAINER_DESKTOP;
                int screenId = (mTargetCell[0] < 0) ?
                        mDragInfo.screenId : getIdForScreen(dropTargetLayout);
                int spanX = mDragInfo != null ? mDragInfo.spanX : 1;
                int spanY = mDragInfo != null ? mDragInfo.spanY : 1;
                // First we find the cell nearest to point at which the item is
                // dropped, without any consideration to whether there is an item there.

                mTargetCell = findNearestArea((int) mDragViewVisualCenter[0], (int)
 mDragViewVisualCenter[1], spanX, spanY, dropTargetLayout, mTargetCell);
 float distance = dropTargetLayout.getDistanceFromCell(mDragViewVisualCenter[0],
 mDragViewVisualCenter[1], mTargetCell);

 // If the item being dropped is a shortcut and the nearest drop
 // cell also contains a shortcut, then create a folder with the two shortcuts.
 if (createUserFolderIfNecessary(cell, container,
 dropTargetLayout, mTargetCell, distance, false, d.dragView) ||
 addToExistingFolderIfNecessary(cell, dropTargetLayout, mTargetCell,
 distance, d, false)) {
                    mLauncher.getStateManager().goToState(NORMAL, SPRING_LOADED_EXIT_DELAY);
                    return;
                }

                // Aside from the special case where we're dropping a shortcut onto a shortcut,
                // we need to find the nearest cell location that is vacant
                ItemInfo item = d.dragInfo;
                int minSpanX = item.spanX;
                int minSpanY = item.spanY;
                if (item.minSpanX > 0 && item.minSpanY > 0) {
                    minSpanX = item.minSpanX;
                    minSpanY = item.minSpanY;
                }

                droppedOnOriginalCell = item.screenId == screenId && item.container == container
                        && item.cellX == mTargetCell[0] && item.cellY == mTargetCell[1];
                droppedOnOriginalCellDuringTransition = droppedOnOriginalCell && mIsSwitchingState;

                // When quickly moving an item, a user may accidentally rearrange their
                // workspace. So instead we move the icon back safely to its original position.
                boolean returnToOriginalCellToPreventShuffling = !isFinishedSwitchingState()
                        && !droppedOnOriginalCellDuringTransition && !dropTargetLayout
                        .isRegionVacant(mTargetCell[0], mTargetCell[1], spanX, spanY);
                int[] resultSpan = new int[2];
                if (returnToOriginalCellToPreventShuffling) {
                    mTargetCell[0] = mTargetCell[1] = -1;
                } else {
                    mTargetCell = dropTargetLayout.performReorder((int) mDragViewVisualCenter[0],
 (int) mDragViewVisualCenter[1], minSpanX, minSpanY, spanX, spanY, cell,
 mTargetCell, resultSpan, CellLayout.MODE\_ON\_DROP);
 }

 boolean foundCell = mTargetCell[0] >= 0 && mTargetCell[1] >= 0;

 // if the widget resizes on drop
 if (foundCell && (cell instanceof AppWidgetHostView) &&
 (resultSpan[0] != item.spanX || resultSpan[1] != item.spanY)) {
                    resizeOnDrop = true;
                    item.spanX = resultSpan[0];
                    item.spanY = resultSpan[1];
                    AppWidgetHostView awhv = (AppWidgetHostView) cell;
                    AppWidgetResizeFrame.updateWidgetSizeRanges(awhv, mLauncher, resultSpan[0],
                            resultSpan[1]);
                }
......
    }

```

通过上文已经获取到当前拖拽所占屏mCurScrrenId的值 和Item的个数mCurChildCount  
 而mWorkspaceScreens.size()的个数包含了一个空屏 当在最后一屏拖拽时会显示个空屏  
 mCurScrrenId+1==mWorkspaceScreens.size()-1 则表示是最后一屏在拖拽  
 getIdForScreen(dropTargetLayout)+1>=mWorkspaceScreens.size() 则表示要拖拽到空屏


具体修改如下:



```
public void onDrop(final DragObject d, DragOptions options) {
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);
        CellLayout dropTargetLayout = mDropToLayout;

        // We want the point to be mapped to the dragTarget.
        if (dropTargetLayout != null) {
            mapPointFromDropLayout(dropTargetLayout, mDragViewVisualCenter);
        }

        boolean droppedOnOriginalCell = false;

        int snapScreen = -1;
        boolean resizeOnDrop = false;
        if (d.dragSource != this || mDragInfo == null) {
            final int[] touchXY = new int[] { (int) mDragViewVisualCenter[0],
                    (int) mDragViewVisualCenter[1] };
            onDropExternal(touchXY, dropTargetLayout, d);
        } else {
            AbstractFloatingView.closeOpenViews(mLauncher, false, AbstractFloatingView.TYPE_WIDGET_RESIZE_FRAME);
            final View cell = mDragInfo.cell;
            boolean droppedOnOriginalCellDuringTransition = false;
            Runnable onCompleteRunnable = null;
            Log.e("Launcher3","countx:"+dropTargetLayout.getCountX()+"--county:"+dropTargetLayout.getCountY()+"---childcount:"+dropTargetLayout.childCount()+"--mTargetCell[0]:"+mTargetCell[0]+"--mTargetCell[1]:"+mTargetCell[1]
			             +"--screenId:"+getIdForScreen(dropTargetLayout)+"--mWorkspaceScreens.size():"+mWorkspaceScreens.size());
			int count = dropTargetLayout.getCountX()*dropTargetLayout.getCountY();
			boolean isAllowDrag = true;
			if(mCurScrrenId+1==mWorkspaceScreens.size()-1&&mCurChildCount<count-6&&getIdForScreen(dropTargetLayout)+1>=mWorkspaceScreens.size())isAllowDrag=false;
            if (dropTargetLayout != null && !d.cancelled&&isAllowDrag) {
                // Move internally
                boolean hasMovedLayouts = (getParentCellLayoutForView(cell) != dropTargetLayout);
                boolean hasMovedIntoHotseat = mLauncher.isHotseatLayout(dropTargetLayout);
                int container = hasMovedIntoHotseat ?
                        LauncherSettings.Favorites.CONTAINER_HOTSEAT :
                        LauncherSettings.Favorites.CONTAINER_DESKTOP;
                int screenId = (mTargetCell[0] < 0) ?
                        mDragInfo.screenId : getIdForScreen(dropTargetLayout);
                int spanX = mDragInfo != null ? mDragInfo.spanX : 1;
                int spanY = mDragInfo != null ? mDragInfo.spanY : 1;
                // First we find the cell nearest to point at which the item is
                // dropped, without any consideration to whether there is an item there.

                mTargetCell = findNearestArea((int) mDragViewVisualCenter[0], (int)
 mDragViewVisualCenter[1], spanX, spanY, dropTargetLayout, mTargetCell);
 float distance = dropTargetLayout.getDistanceFromCell(mDragViewVisualCenter[0],
 mDragViewVisualCenter[1], mTargetCell);

 // If the item being dropped is a shortcut and the nearest drop
 // cell also contains a shortcut, then create a folder with the two shortcuts.
 if (createUserFolderIfNecessary(cell, container,
 dropTargetLayout, mTargetCell, distance, false, d.dragView) ||
 addToExistingFolderIfNecessary(cell, dropTargetLayout, mTargetCell,
 distance, d, false)) {
                    mLauncher.getStateManager().goToState(NORMAL, SPRING_LOADED_EXIT_DELAY);
                    return;
                }
.....
    }

```

通过在onDrop(final DragObject d, DragOptions options)中的判断条件中ddropTargetLayout != null && !d.cancelled  
 增加对当前屏的item数量的判断，看是否允许拖动下一屏  
 通过编译 发现完全实现了功能





