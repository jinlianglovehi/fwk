






### 1.概述


在10.0的产品开发中，最近在定制化开发过程中,客户有需求，通过按键控制加载挂载otg设备，当设置为卸载模式时，要求不能挂载otg设备，开机也不能挂载otg设备


### 2.卸载otg设备开机不加载otg设备的核心类



```
frameworks/base/services/core/java/com/android/server/StorageManagerService.java

```

### 3.卸载otg设备开机不加载otg设备的核心功能分析和实现


实现思路:  
 1.StorageManager根据路径来卸载otg设备  
 2.开机时在 StorageManagerService 中 不挂载otg设备


实现步骤：


### 3.1 开机状态下 根据挂载模式来判断是否需要挂载


StorageManagerService.java关于挂载的相关方法分析



```
  /**
   * Service responsible for various storage media. Connects to {@code vold} to
   * watch for and manage dynamically added storage, such as SD cards and USB mass
   * storage. Also decides how storage should be presented to users on the device.
   */
  class StorageManagerService extends IStorageManager.Stub
          implements Watchdog.Monitor, ScreenObserver {
    private final IVoldListener mListener = new IVoldListener.Stub() {
          @Override
          public void onDiskCreated(String diskId, int flags) {
              synchronized (mLock) {
                  final String value = SystemProperties.get(StorageManager.PROP_ADOPTABLE);
                  switch (value) {
                      case "force\_on":
                          flags |= DiskInfo.FLAG_ADOPTABLE;
                          break;
                      case "force\_off":
                          flags &= ~DiskInfo.FLAG_ADOPTABLE;
                          break;
                  }
                  mDisks.put(diskId, new DiskInfo(diskId, flags));
              }
          }
  
          @Override
          public void onDiskScanned(String diskId) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.get(diskId);
                  if (disk != null) {
                      onDiskScannedLocked(disk);
                  }
              }
          }
  
          @Override
          public void onDiskMetadataChanged(String diskId, long sizeBytes, String label,
                  String sysPath) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.get(diskId);
                  if (disk != null) {
                      disk.size = sizeBytes;
                      disk.label = label;
                      disk.sysPath = sysPath;
                  }
              }
          }
  
          @Override
          public void onDiskDestroyed(String diskId) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.remove(diskId);
                  if (disk != null) {
                      mCallbacks.notifyDiskDestroyed(disk);
                  }
              }
          }
  
          @Override
          public void onVolumeCreated(String volId, int type, String diskId, String partGuid) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.get(diskId);
                  final VolumeInfo vol = new VolumeInfo(volId, type, disk, partGuid);
                  mVolumes.put(volId, vol);
                  onVolumeCreatedLocked(vol);
              }
          }
  
          @Override
          public void onVolumeStateChanged(String volId, int state) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      final int oldState = vol.state;
                      final int newState = state;
                      vol.state = newState;
                      onVolumeStateChangedLocked(vol, oldState, newState);
                  }
              }
          }
  
          @Override
          public void onVolumeMetadataChanged(String volId, String fsType, String fsUuid,
                  String fsLabel) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      vol.fsType = fsType;
                      vol.fsUuid = fsUuid;
                      vol.fsLabel = fsLabel;
                  }
              }
          }
  
          @Override
          public void onVolumePathChanged(String volId, String path) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      vol.path = path;
                  }
              }
          }
  
          @Override
          public void onVolumeInternalPathChanged(String volId, String internalPath) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      vol.internalPath = internalPath;
                  }
              }
          }
  
          @Override
          public void onVolumeDestroyed(String volId) {
              synchronized (mLock) {
                  mVolumes.remove(volId);
              }
          }
      };
  

```

通过在StorageManagerService.java中的IVoldListener 在开机后注册监听usb的挂载情况，如果有挂载的otg设备就会调用onDiskCreated执行挂载动作，然后发出handle消息挂载处理挂载情况，最后调用isMountDisallowed(VolumeInfo vol)看是否挂载，执行挂载的相应方法实现usb挂载



```
--- a/frameworks/base/services/core/java/com/android/server/StorageManagerService.java
+++ b/frameworks/base/services/core/java/com/android/server/StorageManagerService.java
@@ -126,7 +126,7 @@ import android.util.Xml;
 /* SPRD: add some log for debug @{ */
 import android.util.Log;
 /* @} */
-
+import android.provider.Settings;
 import com.android.internal.annotations.GuardedBy;
 import com.android.internal.app.IAppOpsCallback;
 import com.android.internal.app.IAppOpsService;
@@ -1527,6 +1527,17 @@ class StorageManagerService extends StorageManagerServiceEx
      * Decide if volume is mountable per device policies.
      */
     private boolean isMountDisallowed(VolumeInfo vol) {
+               boolean agpsEnabled = (Settings.Global.getInt(mContext.getContentResolver(),
+               "roco\_disable\_sdcard", 0) == 1);
+               boolean otg=(Settings.Global.getInt(mContext.getContentResolver(),"roco\_disable\_otg", 0) == 1);
+               DiskInfo disk=vol.disk;
+               Log.d("StorageManager","isMountDisallowed:"+agpsEnabled+",disk:"+(vol.disk != null && vol.disk.isUsb())+",otg:"+otg);
+                File file = vol.getPath();
+           if(file!=null){

+               if(agpsEnabled && !"/storage/emulated/0".equals(file.getAbsolutePath()) && !(vol.disk != null && vol.disk.isUsb())){
+                       return true;   
+               }
+               if(otg && !"/storage/emulated/0".equals(file.getAbsolutePath()) && (vol.disk != null && vol.disk.isUsb())){
+                       return true;   
+               }
+           }
+               if(vol.getPath()==null){
+                       if(agpsEnabled && vol.disk != null){
+                               return true;
+                       }
+                       if(otg&&(vol.disk != null&&vol.disk.isUsb())){
+                               return true;
                        }
                }
         UserManager userManager = mContext.getSystemService(UserManager.class);
 
         boolean isUsbRestricted = false;

```

在isMountDisallowed()中，判断是否需要阻止挂载，实现在开机判断是否挂载otg的功能


### 3.2 自定义方法来实现挂载，卸载功能


在自定义服务或者系统app中调用该方法实现挂载卸载otg设备功能



```
public void setUSBOtgDisabled(boolean disabled){
        Settings.Global.putInt(mContext.getContentResolver(),
                "roco\_disable\_otg", disabled ? 1 : 0);
        StorageManager storageManager = (StorageManager) mContext.getSystemService(Context.STORAGE_SERVICE);
            StorageVolume[] volumeList = storageManager.getVolumeList();
            for (StorageVolume vol : volumeList) {
                Log.d("StorageManager", "path:" + vol.getPath());
				if (disabled) {
					if (!"/storage/emulated/0".equals(vol.getPath()) && "mounted".equals(vol.getState())) {
						storageManager.unmount(vol.getId());
					}
                }else{
                    if (!"/storage/emulated/0".equals(vol.getPath()) && "unmounted".equals(vol.getState())) {
						storageManager.mount(vol.getId());
					}
                }
            }
}

```




