






### 1.概述


在10.0的系统产品定制化开发中，现在定制化设备中，下拉状态栏高斯模糊背景也成为潮流，产品需要要求就10.0高斯模糊背景来实现其功能，  
 下拉状态栏布局就是status\_bar\_expanded.xml 而处理下拉的事件就是在NotificationPanelView.java中处理


### 2.SystemUI 下拉状态栏增加高斯模糊背景的核心类



```
frameworks/base/packages/SystemUI/res/layout/status_bar_expanded.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java

```

### 3.SystemUI 下拉状态栏增加高斯模糊背景的核心功能分析和实现


### 3.1首选在SystemUI中添加高斯模糊实现类



```
package com.android.systemui.util;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
public class BlurUtil {
private static final float BITMAP_SCALE = 0.4f;
private static final int BLUR_RADIUS = 7;
public static final int BLUR_RADIUS_MAX = 25;
public static Bitmap blur(Context context, Bitmap bitmap) {
    return blur(context, bitmap, BITMAP_SCALE, BLUR_RADIUS);
}

public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale) {
    return blur(context, bitmap, bitmap_scale, BLUR_RADIUS);
}

public static Bitmap blur(Context context, Bitmap bitmap, int blur_radius) {
    //return blur(context, bitmap, BITMAP_SCALE, blur_radius);
    return blurbitmap(context,bitmap);
}

public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale, int blur_radius) {
    Bitmap inputBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * bitmap_scale),
            Math.round(bitmap.getHeight() * bitmap_scale), false);
    Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
    RenderScript rs = RenderScript.create(context);
    ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
    Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
    Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
    theIntrinsic.setRadius(blur_radius);
    theIntrinsic.setInput(tmpIn);
    theIntrinsic.forEach(tmpOut);
    tmpOut.copyTo(outputBitmap);
    rs.destroy();
    bitmap.recycle();
    return outputBitmap;
}

public static Bitmap blurbitmap(Context context, Bitmap bitmap) {
//用需要创建高斯模糊bitmap创建一个空的bitmap
Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
// 初始化Renderscript，该类提供了RenderScript context，创建其他RS类之前必须先创建这个类，其控制RenderScript的初始化，资源管理及释放
RenderScript rs = RenderScript.create(context);
// 创建高斯模糊对象
ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
// 创建Allocations，此类是将数据传递给RenderScript内核的主要方 法，并制定一个后备类型存储给定类型
Allocation allIn = Allocation.createFromBitmap(rs, bitmap);
Allocation allOut = Allocation.createFromBitmap(rs, outBitmap);
//设定模糊度(注：Radius最大只能设置25.f)
blurScript.setRadius(25.0f);
// Perform the Renderscript
blurScript.setInput(allIn);
blurScript.forEach(allOut);
// Copy the final bitmap created by the out Allocation to the outBitmap
allOut.copyTo(outBitmap);
// recycle the original bitmap
// bitmap.recycle();
// After finishing everything, we destroy the Renderscript.
rs.destroy();
return outBitmap;
}
private static Bitmap blurBitmap(Bitmap bkg,Context context) {
//设定模糊度(注：Radius最大只能设置25.f)
float radius = 25.0f;
//背景图片缩放处理
bkg = smallBitmap(bkg);
Bitmap bitmap = bkg.copy(bkg.getConfig(), false);
    final RenderScript rs = RenderScript.create(context);
    final Allocation input = Allocation.createFromBitmap(rs, bkg, Allocation.MipmapControl.MIPMAP_NONE,
            Allocation.USAGE_SCRIPT);
    final Allocation output = Allocation.createTyped(rs, input.getType());
    final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
    script.setRadius(radius);
    script.setInput(input);
    script.forEach(output);
    output.copyTo(bitmap);
    //背景图片放大处理
    bitmap = bigBitmap(bitmap);
    rs.destroy();
    return bitmap;
}

private static Bitmap bigBitmap(Bitmap bitmap) {
    Matrix matrix = new Matrix();
    matrix.postScale(4f,4f); //长和宽放大缩小的比例
    Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    return resizeBmp;
}

private static Bitmap smallBitmap(Bitmap bitmap) {
    Matrix matrix = new Matrix();
    matrix.postScale(0.25f,0.25f); //长和宽放大缩小的比例
    Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    return resizeBmp;
}

}

```

在BlurUtil 高斯模糊类中用RenderScript 的相关api来实现高斯模糊背景的功能实现  
 来达到设置高斯模糊功能


### 3.2BitmapUtils.java用来设置Bitmap工具类实现图片加载



```
package com.android.systemui.util;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
public class BitmapUtils {
public static void recycleImageView(View view) {
    if (view == null) return;
    if (view instanceof ImageView) {
        Drawable drawable = ((ImageView) view).getDrawable();
 if (drawable instanceof BitmapDrawable) {
 Bitmap bmp = ((BitmapDrawable) drawable).getBitmap();
 if (bmp != null && !bmp.isRecycled()) {
                ((ImageView) view).setImageBitmap(null);
                bmp.recycle();
                bmp = null;
            }
        }
    }
}

}

```

用BitmapUtils.java来实现工具类的图片调用和绘制图片的功能


### 3.3 status\_bar\_expanded.xml 添加高斯模糊背景图片



```
--- a/frameworks/base/packages/SystemUI/res/layout/status_bar_expanded.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/status_bar_expanded.xml
@@ -24,6 +24,19 @@
android:layout_width="match\_parent"
android:layout_height="match\_parent"
android:background="@android:color/transparent" >
   <ImageView

       android:id="@+id/blur\_view"

       android:layout_width="match\_parent"

       android:scaleType="fitXY"

       android:layout_height="match\_parent"/>

  <View

       android:id="@+id/alpha\_view"

       android:layout_width="match\_parent"

       android:layout_height="match\_parent"/>
<FrameLayout
android:id="@+id/big\_clock\_container"

```

status\_bar\_expanded.xml中添加view的全屏背景功能


### 3.4在NotificationPanelView.java 下拉监听事件中，设置高斯模糊背景颜色



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java
@@ -54,7 +54,7 @@ import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;
+import android.graphics.Bitmap;
import com.android.internal.annotations.VisibleForTesting;
import com.android.internal.logging.MetricsLogger;
import com.android.internal.logging.nano.MetricsProto.MetricsEvent;
@@ -112,9 +112,13 @@ import java.util.List;
import java.util.function.Consumer;
import android.util.Log;
import static com.sprd.systemui.util.SprdActivityDebugConfigsUtil.DEBUG;
+import android.widget.ImageView;
import javax.inject.Inject;
import javax.inject.Named;
+import android.animation.ValueAnimator;
+import com.android.systemui.util.BitmapUtils;
+import com.android.systemui.util.BlurUtil;
+import android.graphics.BitmapFactory;
public class NotificationPanelView extends PanelView implements
ExpandableView.OnHeightChangedListener,
@@ -408,7 +412,8 @@ public class NotificationPanelView extends PanelView implements
KeyguardClockSwitch keyguardClockSwitch = findViewById(R.id.keyguard_clock_container);
mBigClockContainer = findViewById(R.id.big_clock_container);
keyguardClockSwitch.setBigClockContainer(mBigClockContainer);
   mAlphaView = findViewById(R.id.alpha_view);

   mBlurView = findViewById(R.id.blur_view);

   mNotificationContainerParent = findViewById(R.id.notification_container_parent);
   mNotificationStackScroller = findViewById(R.id.notification_stack_scroller);
   mNotificationStackScroller.setOnHeightChangedListener(this);

@@ -965,7 +970,7 @@ public class NotificationPanelView extends PanelView implements
return true;
}
private static final int BLUR_START = 200;
private static final int BLUR_END = 700;
private View mAlphaView;
private ImageView mBlurView;@Override
public boolean onTouchEvent(MotionEvent event) {
/* UNISOC: Modify for bug1173815,1163448,1191373 {@ */
@@ -1126,6 +1134,30 @@ public class NotificationPanelView extends PanelView implements
updateVerticalPanelPosition(event.getX());
handled = true;
}
    //添加 begin

   float y = event.getY();

   switch (event.getAction()) {

       case MotionEvent.ACTION_DOWN:

           if (!mPanelExpanded) {

               setBlurBackground();

           }

           break;

       case MotionEvent.ACTION_MOVE:

           if (y <= BLUR_END) {

               float alpha = (y - BLUR_START) / (BLUR_END - BLUR_START);

               if (alpha < 0) {

                   alpha = 0;

               }

               mAlphaView.setAlpha(alpha);

               mBlurView.setAlpha(alpha);

           }

           break;

       case MotionEvent.ACTION_UP:

           float a = mBlurView.getAlpha();

           startAlphaAnimation(a, 1.0f);

           break;

   }

   // 添加 end

   handled |= super.onTouchEvent(event);
   if (DEBUG) {
       Log.e("NotificationPanelView","end mDozing:" + mDozing + " mPulsing:" + mPulsing + " handled:" +handled);

@@ -1133,7 +1165,31 @@ public class NotificationPanelView extends PanelView implements
/* @} */
return !mDozing || mPulsing || handled;
}
private void startAlphaAnimation(float start, float end) {
   ValueAnimator va = ValueAnimator.ofFloat(start, end);

   va.setDuration((long) (Math.abs(end - start) \* 500));

   va.start();

   va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

       @Override

       public void onAnimationUpdate(ValueAnimator animation) {

           float alpha = (float) animation.getAnimatedValue();

           mAlphaView.setAlpha(alpha/2);

           mBlurView.setAlpha(alpha);

       }

   });

}
private void setBlurBackground() {
   Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.notification_bg);/*ScreenShotUtil.takeScreenShot(mContext)*/;

   if (bitmap == null) {

       Log.d("NotificationPanelView", "setBlurBackground bitmap == null");

       return;

   }

   //bitmap.setConfig(Bitmap.Config.ARGB_8888);

   Bitmap blurBitmap = BlurUtil.blur(mContext, bitmap, BlurUtil.BLUR_RADIUS_MAX);

   BitmapUtils.recycleImageView(mBlurView);

   mBlurView.setImageBitmap(blurBitmap);

}

```

在OnTounch事件中，通过监听下拉状态栏事件后，在设置高斯模糊背景到下拉状态栏中，  
 通过以上部分的修改 就实现高斯模糊背景的设置





