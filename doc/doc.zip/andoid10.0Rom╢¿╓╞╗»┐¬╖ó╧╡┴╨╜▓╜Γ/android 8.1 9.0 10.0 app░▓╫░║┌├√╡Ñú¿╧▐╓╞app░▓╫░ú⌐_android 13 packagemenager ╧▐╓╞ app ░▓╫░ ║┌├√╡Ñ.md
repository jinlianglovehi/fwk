






### 1.概述


在10.0的产品定制化开发中,客户需求要实现对某些app应用限制也就是app安装黑名单功能，在黑名单之中的应用会被限制安装，PMS就是负责管理app安装和卸载的，所以接下来看下PackManagerService.java的源码


### 2.app安装黑名单（限制app安装）的核心类



```
frameworks/base/core/java/android/content/pm/IPackageManager.aidl
frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

```

### 3.app安装黑名单（限制app安装）的核心功能分析和实现


关于在PMS中管理app的安装和卸载所以具体来看pms的相关源码



```
@GuardedBy("mInstallLock")
    private PrepareResult preparePackageLI(InstallArgs args, PackageInstalledInfo res)
            throws PrepareFailure {
        final int installFlags = args.installFlags;
        final String installerPackageName = args.installerPackageName;
        final String volumeUuid = args.volumeUuid;
        final File tmpPackageFile = new File(args.getCodePath());
        final boolean onExternal = args.volumeUuid != null;
        final boolean instantApp = ((installFlags & PackageManager.INSTALL_INSTANT_APP) != 0);
        final boolean fullApp = ((installFlags & PackageManager.INSTALL_FULL_APP) != 0);
        final boolean virtualPreload =
                ((installFlags & PackageManager.INSTALL_VIRTUAL_PRELOAD) != 0);
        @ScanFlags int scanFlags = SCAN_NEW_INSTALL | SCAN_UPDATE_SIGNATURE;
        if (args.move != null) {
            // moving a complete application; perform an initial scan on the new install location
            scanFlags |= SCAN_INITIAL;
        }
        if ((installFlags & PackageManager.INSTALL_DONT_KILL_APP) != 0) {
            scanFlags |= SCAN_DONT_KILL_APP;
        }
        if (instantApp) {
            scanFlags |= SCAN_AS_INSTANT_APP;
        }
        if (fullApp) {
            scanFlags |= SCAN_AS_FULL_APP;
        }
        if (virtualPreload) {
            scanFlags |= SCAN_AS_VIRTUAL_PRELOAD;
        }

        if (DEBUG_INSTALL) Slog.d(TAG, "installPackageLI: path=" + tmpPackageFile);

        // Sanity check
        if (instantApp && onExternal) {
            Slog.i(TAG, "Incompatible ephemeral install; external=" + onExternal);
            throw new PrepareFailure(PackageManager.INSTALL_FAILED_INSTANT_APP_INVALID);
        }

        // Retrieve PackageSettings and parse package
        @ParseFlags final int parseFlags = mDefParseFlags | PackageParser.PARSE_CHATTY
                | PackageParser.PARSE_ENFORCE_CODE
                | (onExternal ? PackageParser.PARSE_EXTERNAL_STORAGE : 0);

        PackageParser pp = new PackageParser();
        pp.setSeparateProcesses(mSeparateProcesses);
        pp.setDisplayMetrics(mMetrics);
        pp.setCallback(mPackageParserCallback);

        Trace.traceBegin(TRACE_TAG_PACKAGE_MANAGER, "parsePackage");
        final PackageParser.Package pkg;
        try {
            pkg = pp.parsePackage(tmpPackageFile, parseFlags);
            DexMetadataHelper.validatePackageDexMetadata(pkg);
        } catch (PackageParserException e) {
            throw new PrepareFailure("Failed parse during installPackageLI", e);
        } finally {
            Trace.traceEnd(TRACE_TAG_PACKAGE_MANAGER);
        }
       ....
    }

```

在上述源码中可以看出  
 无论是pm安装或者是 代码安装 都会走preparePackageLI 所以在这里添加判断包名是否在黑名单即可


### 3.1 IPackageManager.aidl 添加黑名单接口供app调用



```


diff --git a/frameworks/base/core/java/android/content/pm/IPackageManager.aidl b/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

old mode 100644

new mode 100755

index a369cc89a3..90fafe5a8f

--- a/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

+++ b/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

@@ -798,4 +798,7 @@ interface IPackageManager {

     */

     int restoreAppData(String sourceDir, String pkgName);

    /* @} */

+   

+       void setInstallPackageBlackList(in List<String> packageNames);

+       List<String> getInstallPackageBlackList();

 }

```

在IPackageManager.aidl中添加设置安装和获取黑名单


### 3.2 在PMS中实现黑名单接口和安装黑名单功能



```
diff --git a/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java b/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

index 45289f2e39..6727b10e35 100755

--- a/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

+++ b/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

@@ -111,7 +111,13 @@ import static com.android.server.pm.PackageManagerServiceUtils.getCompressedFile

 import static com.android.server.pm.PackageManagerServiceUtils.getLastModifiedTime;

 import static com.android.server.pm.PackageManagerServiceUtils.logCriticalInfo;

 import static com.android.server.pm.PackageManagerServiceUtils.verifySignatures;

-

+import java.io.BufferedReader;

+import java.io.File;

+import java.io.FileInputStream;

+import java.io.FileOutputStream;

+import java.io.InputStreamReader;

+import java.io.LineNumberReader;

+import java.io.PrintWriter;

 import android.Manifest;

 import android.annotation.IntDef;

 import android.annotation.NonNull;

@@ -2141,7 +2147,16 @@ public class PackageManagerService extends PackageManagerServiceExAbs

             }

         }

     }

-

+       private List<String> installBlackpackageNames;

+           @Override

+    public void setInstallPackageBlackList( List<String> packageNames) {

+               this.installBlackpackageNames=packageNames;

+    }

+       

+       @Override

+    public List<String> getInstallPackageBlackList(){

+               return this.installBlackpackageNames;

+    }

     private void notifyInstallObserver(String packageName) {

         Pair<PackageInstalledInfo, IPackageInstallObserver2> pair =

                 mNoKillInstallObservers.remove(packageName);

```

在PMS中实现安装黑名单的接口，方便实现功能


pms 添加过滤app安装黑名单



```
@@ -17482,7 +17497,13 @@ public class PackageManagerService extends PackageManagerServiceExAbs

 @GuardedBy("mInstallLock")
    private PrepareResult preparePackageLI(InstallArgs args, PackageInstalledInfo res)
            throws PrepareFailure {     
try {
            // either use what we've been given or parse directly from the APK
            if (args.signingDetails != PackageParser.SigningDetails.UNKNOWN) {
                pkg.setSigningDetails(args.signingDetails);
            } else {
                PackageParser.collectCertificates(pkg, false /* skipVerify */);
            }
        } catch (PackageParserException e) {
            throw new PrepareFailure("Failed collect during installPackageLI", e);
        }

-

+               if(isBlackListApp(pkg.packageName)){

+            Log.d("TAG","--isBlackListApp--");

+                       

+                       throw new PrepareFailure(INSTALL_FAILED_INSTANT_APP_INVALID,

+                    "app is not in the Blacklist. packageName");

+           

+        }

         if (instantApp && pkg.mSigningDetails.signatureSchemeVersion

                 < SignatureSchemeVersion.SIGNING_BLOCK_V2) {

             Slog.w(TAG, "Instant app package " + pkg.packageName

@@ -18039,7 +18060,21 @@ public class PackageManagerService extends PackageManagerServiceExAbs

             }

         }

     }

+    private boolean isBlackListApp(String packagename){

 

+               if(this.installBlackpackageNames ==null || this.installBlackpackageNames.size()==0){

+                       return false；

+               }

+               

+        Iterator<String> it = this.installBlackpackageNames.iterator();

+        while (it.hasNext()) {

+            String blacklistItem = it.next();

+            if (blacklistItem.equals(packagename)) {

+                return true;

+            }

+        }

+        return false;

+    }

```

在preparePackageLI中安装的时候会判断安装是不是在黑名单中黑名单中的app不允许安装





