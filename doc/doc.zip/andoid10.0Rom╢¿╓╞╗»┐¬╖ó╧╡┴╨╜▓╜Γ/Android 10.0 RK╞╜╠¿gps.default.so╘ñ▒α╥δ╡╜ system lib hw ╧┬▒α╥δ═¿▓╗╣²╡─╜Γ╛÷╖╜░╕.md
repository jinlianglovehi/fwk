






### 1.概述


在10.0的底层编译变化挺大，RK平台再用以前方式把 gps.default.so放在device\rockchip\common\device.mk下编译就编不过了,就得另外想办法了，怎么样编译到/system/lib/hw下呢


### 2.RK平台gps.default.so预编译到/system/lib/hw 下编译通不过的解决方案的实现步骤



```
另建立 Android.mk
1.Android.mk
LOCAL_PATH := $(call my-dir)
include $(CLEAR\_VARS)
LOCAL_MODULE       := gps.default.so
LOCAL_SRC_FILES    := gps.default.so
#LOCAL\_MODULE\_CLASS := EXECUTABLES
LOCAL_MODULE_TAGS  := optional
LOCAL_MODULE_CLASS := SHARED_LIBRARIES
LOCAL_MODULE_PATH  := $(TARGET\_OUT)/lib/hw
include $(BUILD\_PREBUILT)

2.device.mk 添加

#LIBPSAM
LIBGPS := gps.default.so
PRODUCT_PACKAGES += $(LIBGPS)
编译就通过了,查看/system/lib/hw 有gps.default.so这个动态库

```




