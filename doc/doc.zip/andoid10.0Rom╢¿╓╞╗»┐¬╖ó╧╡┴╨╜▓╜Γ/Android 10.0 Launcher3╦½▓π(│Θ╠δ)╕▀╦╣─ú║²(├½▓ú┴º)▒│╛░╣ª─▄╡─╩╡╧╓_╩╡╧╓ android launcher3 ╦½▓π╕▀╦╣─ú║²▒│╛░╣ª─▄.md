



## 1.概述


 在进行定制开发的功能需求方面，Launcher3的需求也挺多的，单双层抽屉高斯模糊毛玻璃背景功能也是一个需求功能，最近按照功能需求来开发 双层抽屉高斯模糊毛玻璃效果背景的功能


效果图如图:


![](https://img-blog.csdnimg.cn/c655727559d249d49bfc0fb6b67be0db.png)


##  2. Launcher3双层(抽屉)高斯模糊(毛玻璃)背景功能的实现的核心代码



```
   packages\apps\Launcher3\res\layout\launcher.xml
   packages\apps\Launcher3\res\layout\scrim_view.xml
   packages\apps\Launcher3\quickstep\src\com\android\quickstep\views\ShelfScrimView.java
```

## 3. Launcher3双层(抽屉)高斯模糊(毛玻璃)背景功能的实现功能分析


在Launcher3中的核心布局中，比较workspace hotseat folder等核心部件中，在  
 Launcher3中的核心部件就是在launcher.xml中，这里显示Launcher3桌面的核心控件，  
 DragLayer Workspace WorkspacePageIndicatorLine drop\_target\_bar hotseat等主要控件的布局


launcher3主要的类  
 LauncherModel：  
 跟数据有关系，保存了桌面运行时的状态信息，也提供了读写数据库的API，他有一个内部类LoaderTask，桌面启动从数据库中读取数据并把图标和小工具添加上去的时候用的就是他。  
 BubblTextView：  
 图标都是基于他，不过奇怪的是，他是继承自TextView  
 DragController：  
 DragLayer只是一个ViewGroup，具体的拖拽的处理都放到了DragController中。  
 LauncherAppState：  
 单例模式，主要在启动的时候用，他初始化了一些对象，并且注册了广播监听器和ContentObserver。  
 DragView：  
 在拖动图标的时候跟随手指移动的View就是他。  
 DragSource，DropTarget：  
 跟拖拽相关的接口，DragSource表示图标从哪里被拖出来，DropTarget表示图标可以被拖到哪里去。




##    3.1 launcher.xml相关代码分析



```
    <com.android.launcher3.LauncherRootView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:id="@+id/launcher"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fitsSystemWindows="true">

    <com.android.launcher3.dragndrop.DragLayer
        android:id="@+id/drag_layer"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:importantForAccessibility="no">

        <!-- The workspace contains 5 screens of cells -->
        <!-- DO NOT CHANGE THE ID -->
        <com.android.launcher3.Workspace
            android:id="@+id/workspace"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:layout_gravity="center"
            android:theme="@style/HomeScreenElementTheme"
            launcher:pageIndicator="@+id/page_indicator" />

        <include layout="@layout/memoryinfo_ext" />

        <!-- DO NOT CHANGE THE ID -->
        <include
            android:id="@+id/hotseat"
            layout="@layout/hotseat"
            android:visibility="gone"/>

        <include
            android:id="@+id/overview_panel"
            layout="@layout/overview_panel"
            android:visibility="gone" />

        <!-- Keep these behind the workspace so that they are not visible when
         we go into AllApps -->
        <com.sprd.ext.pageindicators.WorkspacePageIndicatorLine
            android:id="@+id/page_indicator"
            android:layout_width="match_parent"
            android:layout_height="@dimen/vertical_drag_handle_size"
            android:layout_gravity="bottom"
            android:theme="@style/HomeScreenElementTheme" />

        <include
            android:id="@+id/page_indicator_customize"
            layout="@layout/page_indicator_customize" />

        <include
            android:id="@+id/drop_target_bar"
            layout="@layout/drop_target_bar" />

        <include
            android:id="@+id/scrim_view"
            layout="@layout/scrim_view" />

        <include
            android:id="@+id/apps_view"
            layout="@layout/all_apps"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />

    </com.android.launcher3.dragndrop.DragLayer>

</com.android.launcher3.LauncherRootView>
```

从上述的launcher.xml布局的相关代码 可以看出scrim\_view.xml就是抽屉上滑的背景布局 而apps\_view 就是抽屉上滑展示的内容 包括app列表 搜索框等等  
 所以功能开发应该从scrim\_view查看相关源码分析功能实现


## 3.2 scrim\_view.xml 对于的是ScrimView.java关于毛玻璃效果分析



```
  <com.android.launcher3.views.ScrimView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:id="@+id/scrim_view" />
```

从scrim\_view.xml的布局中可以看到  在Launcher3QuickStep应用中真正的scrim\_view.xml是在packages\apps\Launcher3\quickstep\res\layout\scrim\_view.xml，接下来看下  在Launcher3QuickStep应用中真正的scrim\_view.xml是在packages\apps\Launcher3\quickstep\res\layout\scrim\_view.xml的相关源码分析具体的背景



```
  <com.android.quickstep.views.ShelfScrimView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:id="@+id/scrim_view" />
```

所以从scrim\_view.xml的布局可以看出具体实现是在com.android.quickstep.views.ShelfScrimView，所以说正在的背景就是ShelfScrimView来负责构建的，接下来看下ShelfScrimView的具体源码分析


## 3.3 增加高斯模糊工具类BlurUtil



```
  package com.android.launcher3.views;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
public class BlurUtil {
	private static final float BITMAP_SCALE = 0.4f;
	private static final int BLUR_RADIUS = 7;
	public static final int BLUR_RADIUS_MAX = 25;
	public static Bitmap blur(Context context, Bitmap bitmap) {
		return blur(context, bitmap, BITMAP_SCALE, BLUR_RADIUS);
	}
	public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale) {
		return blur(context, bitmap, bitmap_scale, BLUR_RADIUS);
	}
	public static Bitmap blur(Context context, Bitmap bitmap, int blur_radius) {
		//return blur(context, bitmap, BITMAP_SCALE, blur_radius);
		return blurbitmap(context,bitmap);
	}
	public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale, int blur_radius) {
		Bitmap inputBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * bitmap_scale),
		                Math.round(bitmap.getHeight() * bitmap_scale), false);
		Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
		RenderScript rs = RenderScript.create(context);
		ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
		Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
		theIntrinsic.setRadius(blur_radius);
		theIntrinsic.setInput(tmpIn);
		theIntrinsic.forEach(tmpOut);
		tmpOut.copyTo(outputBitmap);
		rs.destroy();
		bitmap.recycle();
		return outputBitmap;
	}
	public static Bitmap blurbitmap(Context context, Bitmap bitmap) {
		//用需要创建高斯模糊bitmap创建一个空的bitmap
		Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		// 初始化Renderscript，该类提供了RenderScript context，创建其他RS类之前必须先创建这个类，其控制RenderScript的初始化，资源管理及释放
		RenderScript rs = RenderScript.create(context);
		// 创建高斯模糊对象
		ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		// 创建Allocations，此类是将数据传递给RenderScript内核的主要方 法，并制定一个后备类型存储给定类型
		Allocation allIn = Allocation.createFromBitmap(rs, bitmap);
		Allocation allOut = Allocation.createFromBitmap(rs, outBitmap);
		//设定模糊度(注：Radius最大只能设置25.f)
		blurScript.setRadius(25.0f);
		// Perform the Renderscript
		blurScript.setInput(allIn);
		blurScript.forEach(allOut);
		// Copy the final bitmap created by the out Allocation to the outBitmap
		allOut.copyTo(outBitmap);
		// recycle the original bitmap
		// bitmap.recycle();
		// After finishing everything, we destroy the Renderscript.
		rs.destroy();
		return outBitmap;
	}
	private static Bitmap blurBitmap(Bitmap bkg,Context context) {
		//设定模糊度(注：Radius最大只能设置25.f)
		float radius = 25.0f;
		//背景图片缩放处理
		bkg = smallBitmap(bkg);
		Bitmap bitmap = bkg.copy(bkg.getConfig(), false);
		final RenderScript rs = RenderScript.create(context);
		final Allocation input = Allocation.createFromBitmap(rs, bkg, Allocation.MipmapControl.MIPMAP_NONE,
		                Allocation.USAGE_SCRIPT);
		final Allocation output = Allocation.createTyped(rs, input.getType());
		final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		script.setRadius(radius);
		script.setInput(input);
		script.forEach(output);
		output.copyTo(bitmap);
		//背景图片放大处理
		bitmap = bigBitmap(bitmap);
		rs.destroy();
		return bitmap;
	}
	private static Bitmap bigBitmap(Bitmap bitmap) {
		Matrix matrix = new Matrix();
		matrix.postScale(4f,4f);
		//长和宽放大缩小的比例
		Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
		return resizeBmp;
	}
	private static Bitmap smallBitmap(Bitmap bitmap) {
		Matrix matrix = new Matrix();
		matrix.postScale(0.25f,0.25f);
		//长和宽放大缩小的比例
		Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
		return resizeBmp;
	}
}
```

通过上述的BlurUtil来调用系统api的相关毛玻璃效果的api来构建双层的模糊背景的功能


## 3.4 ShelfScrimView相关抽屉背景的分析



```
   public class ShelfScrimView extends ScrimView implements NavigationModeChangeListener {

    // If the progress is more than this, shelf follows the finger, otherwise it moves faster to
    // cover the whole screen
    private static final float SCRIM_CATCHUP_THRESHOLD = 0.2f;

    // Temporarily needed until android.R.attr.bottomDialogCornerRadius becomes public
    private static final float BOTTOM_CORNER_RADIUS_RATIO = 2f;

    // In transposed layout, we simply draw a flat color.
    private boolean mDrawingFlatColor;

    // For shelf mode
    private final int mEndAlpha;
    private final float mRadius;
    private final int mMaxScrimAlpha;
    private final Paint mPaint;

    // Mid point where the alpha changes
    private int mMidAlpha;
    private float mMidProgress;

    private Interpolator mBeforeMidProgressColorInterpolator = ACCEL;
    private Interpolator mAfterMidProgressColorInterpolator = ACCEL;

    private float mShiftRange;

    private final float mShelfOffset;
    private float mTopOffset;
    private float mShelfTop;
    private float mShelfTopAtThreshold;

    private int mShelfColor;
    private int mRemainingScreenColor;

    private final Path mTempPath = new Path();
    private final Path mRemainingScreenPath = new Path();
    private boolean mRemainingScreenPathValid = false;

    private Mode mSysUINavigationMode;
   
 //添加获取高斯模糊(毛玻璃)效果的变量
    private Bitmap mBlurBitmap;
    private Context mContext;

    public ShelfScrimView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mMaxScrimAlpha = Math.round(OVERVIEW.getWorkspaceScrimAlpha(mLauncher) * 255);

        mEndAlpha = Color.alpha(mEndScrim);
        mRadius = BOTTOM_CORNER_RADIUS_RATIO * Themes.getDialogCornerRadius(context);
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        mShelfOffset = context.getResources().getDimension(R.dimen.shelf_surface_offset);
        // Just assume the easiest UI for now, until we have the proper layout information.
        mDrawingFlatColor = true;

        // add core start 添加获取高斯模糊(毛玻璃)效果功能
		setViewBlur(context);
		mContext = context;
		context.registerReceiver(mWallReceiver, new IntentFilter("android.intent.action.WALLPAPER_CHANGED"));
      // add core end
 }

// 增加监听更换壁纸广播
      private final BroadcastReceiver mWallReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Reset AllApps to its initial state only if we are not in the middle of
            // processing a multi-step drop
            String action = intent.getAction();
			if(action.equals("android.intent.action.WALLPAPER_CHANGED")){
				setViewBlur(mContext);
			}
        }
    };
  // 获取高斯模糊(毛玻璃)背景
    private void setViewBlur(Context context){
      // 获取当前壁纸
       WallpaperManager wallpaperMag = WallpaperManager.getInstance(context);
       Bitmap wallBitmap = wallpaperMag.getBitmap();
      // 对当前壁纸实现高斯模糊功能
       mBlurBitmap = BlurUtil.blur(context, wallBitmap, BlurUtil.BLUR_RADIUS_MAX);
   }

@Override
    public void reInitUi() {
        DeviceProfile dp = mLauncher.getDeviceProfile();
        mDrawingFlatColor = dp.isVerticalBarLayout();

        if (!mDrawingFlatColor) {
            mRemainingScreenPathValid = false;
            mShiftRange = mLauncher.getAllAppsController().getShiftRange();

            if ((OVERVIEW.getVisibleElements(mLauncher) & ALL_APPS_HEADER_EXTRA) == 0) {
                mMidProgress = 1;
                mMidAlpha = 0;
            } else {
                mMidAlpha = Themes.getAttrInteger(getContext(), R.attr.allAppsInterimScrimAlpha);
                Rect hotseatPadding = dp.getHotseatLayoutPadding();
                int hotseatSize = dp.hotseatBarSizePx + dp.getInsets().bottom
                        - hotseatPadding.bottom - hotseatPadding.top;
                float arrowTop = Math.min(hotseatSize, OverviewState.getDefaultSwipeHeight(dp));
                mMidProgress =  1 - (arrowTop / mShiftRange);

            }
            mTopOffset = dp.getInsets().top - mShelfOffset;
            mShelfTopAtThreshold = mShiftRange * SCRIM_CATCHUP_THRESHOLD + mTopOffset;
        }
        updateColors();
        updateDragHandleAlpha();
        invalidate();
    }

    @Override
    public void updateColors() {
        super.updateColors();
        if (mDrawingFlatColor) {
            mDragHandleOffset = 0;
            return;
        }

        mDragHandleOffset = mShelfOffset - mDragHandleSize;
        if (mProgress >= SCRIM_CATCHUP_THRESHOLD) {
            mShelfTop = mShiftRange * mProgress + mTopOffset;
        } else {
            mShelfTop = Utilities.mapRange(mProgress / SCRIM_CATCHUP_THRESHOLD, -mRadius,
                    mShelfTopAtThreshold);
        }

        if (mProgress >= 1) {
            mRemainingScreenColor = 0;
            mShelfColor = 0;
            if (mSysUINavigationMode == Mode.NO_BUTTON
                    && mLauncher.getStateManager().getState() == BACKGROUND_APP) {
                // Show the shelf background when peeking during swipe up.
                mShelfColor = setColorAlphaBound(mEndScrim, mMidAlpha);
            }
        } else if (mProgress >= mMidProgress) {
            mRemainingScreenColor = 0;

            int alpha = Math.round(Utilities.mapToRange(
                    mProgress, mMidProgress, 1, mMidAlpha, 0, mBeforeMidProgressColorInterpolator));
            mShelfColor = setColorAlphaBound(mEndScrim, alpha);
        } else {
            mDragHandleOffset += mShiftRange * (mMidProgress - mProgress);

            // Note that these ranges and interpolators are inverted because progress goes 1 to 0.
            int alpha = Math.round(
                    Utilities.mapToRange(mProgress, (float) 0, mMidProgress, (float) mEndAlpha,
                            (float) mMidAlpha, mAfterMidProgressColorInterpolator));
            mShelfColor = setColorAlphaBound(mEndScrim, alpha);

            int remainingScrimAlpha = Math.round(
                    Utilities.mapToRange(mProgress, (float) 0, mMidProgress, mMaxScrimAlpha,
                            (float) 0, LINEAR));
            mRemainingScreenColor = setColorAlphaBound(mScrimColor, remainingScrimAlpha);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawBackground(canvas);
        drawDragHandle(canvas);
    }

    private void drawBackground(Canvas canvas) {
        if (mDrawingFlatColor) {
            if (mCurrentFlatColor != 0) {
                canvas.drawColor(mCurrentFlatColor);
            }
            return;
        }

        if (Color.alpha(mShelfColor) == 0) {
            return;
        } else if (mProgress <= 0) {
            canvas.drawColor(mShelfColor);
            return;
        }

        int height = getHeight();
        int width = getWidth();
        // Draw the scrim over the remaining screen if needed.
        if (mRemainingScreenColor != 0) {
            if (!mRemainingScreenPathValid) {
                mTempPath.reset();
                // Using a arbitrary '+10' in the bottom to avoid any left-overs at the
                // corners due to rounding issues.
                mTempPath.addRoundRect(0, height - mRadius, width, height + mRadius + 10,
                        mRadius, mRadius, Direction.CW);
                mRemainingScreenPath.reset();
                mRemainingScreenPath.addRect(0, 0, width, height, Direction.CW);
                mRemainingScreenPath.op(mTempPath, Op.DIFFERENCE);
            }

            float offset = height - mRadius - mShelfTop;
            canvas.translate(0, -offset);
            mPaint.setColor(mRemainingScreenColor);
            canvas.drawPath(mRemainingScreenPath, mPaint);
            canvas.translate(0, offset);
        }

        mPaint.setColor(mShelfColor);
        canvas.drawRoundRect(0, mShelfTop, width, height + mRadius, mRadius, mRadius, mPaint);
    }
}
```

在上述的ShelfScrimView的核心代码中，注释部分讲解了重点实现高斯模糊背景的功能，主要绘制背景功能都是在drawBackground(Canvas canvas)中实现的 同时也监听壁纸更换了，也同时更新高斯模糊背景，就是通过把毛玻璃效果背景  
 绘制在这里就可以了



```
    private void drawBackground(Canvas canvas) {
        if (mDrawingFlatColor) {
            if (mCurrentFlatColor != 0) {
                canvas.drawColor(mCurrentFlatColor);
            }
            return;
        }

        if (Color.alpha(mShelfColor) == 0) {
            return;
        } else if (mProgress <= 0) {
             - canvas.drawColor(mShelfColor);
            + if (mBlurBitmap != null)canvas.drawBitmap(mBlurBitmap, 0, 0, new Paint());
            + //canvas.drawColor(mShelfColor);
            return;
        }

        int height = getHeight();
        int width = getWidth();
        // Draw the scrim over the remaining screen if needed.
        if (mRemainingScreenColor != 0) {
            if (!mRemainingScreenPathValid) {
                mTempPath.reset();
                // Using a arbitrary '+10' in the bottom to avoid any left-overs at the
                // corners due to rounding issues.
                mTempPath.addRoundRect(0, height - mRadius, width, height + mRadius + 10,
                        mRadius, mRadius, Direction.CW);
                mRemainingScreenPath.reset();
                mRemainingScreenPath.addRect(0, 0, width, height, Direction.CW);
                mRemainingScreenPath.op(mTempPath, Op.DIFFERENCE);
            }

            float offset = height - mRadius - mShelfTop;
            canvas.translate(0, -offset);
            mPaint.setColor(mRemainingScreenColor);
            - canvas.drawPath(mRemainingScreenPath, mPaint);
            + //canvas.drawPath(mRemainingScreenPath, mPaint);
            canvas.translate(0, offset);
        }

        mPaint.setColor(mShelfColor);
        -   canvas.drawRoundRect(0, mShelfTop, width, height + mRadius, mRadius, mRadius, mPaint);
        + //canvas.drawRoundRect(0, mShelfTop, width, height + mRadius, mRadius, mRadius, mPaint);
        + if (mBlurBitmap != null)canvas.drawBitmap(mBlurBitmap, 0, mShelfTop, new Paint());
    }
```

通过上述的自定义高斯模糊类ShelfScrimView.java和BlurUtil.java核心功能主要是实现高斯模糊功能的，然后  
 在ShelfScrimView.java这个控件类的drawBackground(Canvas canvas)中实现设置高斯模糊背景功能，从而  
 就可以在整个功能中实现高斯模糊背景功能



