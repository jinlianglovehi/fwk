



1 调试确认SELinux问题


为了澄清是否因为SELinux导致的问题，可先执行：


setenforce 0 （临时禁用掉SELinux）


getenforce  （得到结果为Permissive）


如果问题消失了，基本可以确认是SELinux造成的权限问题，需要通过正规的方式来解决权限问题。


遇到权限问题，在logcat或者kernel的log中一定会打印avc denied提示缺少什么权限，可以通过命令过滤出所有的avc denied，再根据这些log各个击破：


cat /proc/kmsg | grep avc


或


dmesg | grep avc


2.报错信息


报错：


avc:  denied  { execute} for  pid=19029 comm="su" path="/system/xbin/su" dev="dm-4" ino=3540 scontext=u:r:system\_app:s0 tcontext=u:object\_r:su\_exec:s0 tclass=file permissive=0


分析：


缺少什么权限：  { execute} 权限


谁缺少权限： scontext=u:r:system\_app:s0


对哪个文件缺少权限： tcontext=u:object\_r:su\_exec:s0


什么类型的文件： tclass=file



所以完整的意思是：system\_app进程对su\_exec类型的file缺少execute权限。


app对应的te文件


    system\_app -> external\sepolicy\system\_app.te  
     untrusted\_app -> external\sepolicy\untrusted\_app.te  
     platform\_app -> external\sepolicy\platform\_app.te


所以需要修改 system\_app.te ，我们这里对应的文件是：device/mediatek/sepolicy/bsp/plat\_private/system\_app.te


添加权限：


 allow system\_app su\_exec:file execute


这时出现编译报错：


libsepol.report\_failure: neverallow on line 1111 of system/sepolicy/public/domain.te (or line 12860 of policy.conf) violated by allow system\_app su\_exec:file { execute };  
 libsepol.check\_assertions: 1 neverallow failures occurred  
 Error while expanding policy


与 system/sepolicy/public/domain.te ：


neverallow { domain userdebug\_or\_eng(`-dumpstate -shell -su') } su\_exec:file no\_x\_file\_perms;


冲突。


解决：


neverallow { domain -system\_app userdebug\_or\_eng(`-dumpstate -shell -su') } su\_exec:file no\_x\_file\_perms;


文件 system/sepolicy/prebuilts/api/29.0/public/domain.te 和 system/sepolicy/public/domain.te 不同：


同步即可。



