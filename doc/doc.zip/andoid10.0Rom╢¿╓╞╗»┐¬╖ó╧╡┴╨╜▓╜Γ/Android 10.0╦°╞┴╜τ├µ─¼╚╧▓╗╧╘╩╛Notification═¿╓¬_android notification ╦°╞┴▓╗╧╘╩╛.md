






在系统开机以后，默认在锁屏界面如果有通知会显示的，但是这样客户觉得非常不方便，要求去掉显示的所有通知，为了满足客户需求  
 所以就要实现这个功能


在StatusBarNotificationPresenter.java中的getMaxNotificationsWhileLocked 获取最大锁屏时通知显示数量  
 路径:/framework/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarNotificationPresenter.java



```
@Override
    public int getMaxNotificationsWhileLocked(boolean recompute) {
        if (recompute) {
            mMaxKeyguardNotifications = Math.max(1,
                    mNotificationPanel.computeMaxKeyguardNotifications(
                            mMaxAllowedKeyguardNotifications));
            return mMaxKeyguardNotifications;
        }
        return mMaxKeyguardNotifications;
    }

```

接下来看NotificationPanelView.computeMaxKeyguardNotifications();  
 路径：/framework/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java



```
    public int computeMaxKeyguardNotifications(int maximum) {
        float minPadding = mClockPositionAlgorithm.getMinStackScrollerPadding();
        int notificationPadding = Math.max(1, getResources().getDimensionPixelSize(
                R.dimen.notification_divider_height));
        NotificationShelf shelf = mNotificationStackScroller.getNotificationShelf();
        float shelfSize = shelf.getVisibility() == GONE ? 0
                : shelf.getIntrinsicHeight() + notificationPadding;
        float availableSpace = mNotificationStackScroller.getHeight() - minPadding - shelfSize
                - Math.max(mIndicationBottomPadding, mAmbientIndicationBottomPadding)
                - mKeyguardStatusView.getLogoutButtonHeight();
        int count = 0;
        for (int i = 0; i < mNotificationStackScroller.getChildCount(); i++) {
            ExpandableView child = (ExpandableView) mNotificationStackScroller.getChildAt(i);
            if (!(child instanceof ExpandableNotificationRow)) {
                continue;
            }
            ExpandableNotificationRow row = (ExpandableNotificationRow) child;
            boolean suppressedSummary = mGroupManager != null
                    && mGroupManager.isSummaryOfSuppressedGroup(row.getStatusBarNotification());
            if (suppressedSummary) {
                continue;
            }
            if (!mLockscreenUserManager.shouldShowOnKeyguard(row.getEntry())) {
                continue;
            }
.....
}

接下来看 mLockscreenUserManager.shouldShowOnKeyguard(row.getEntry())
路径: /framework/base/packages/SystemUI/src/com/android/systemui/statusbar/NotificationLockscreenUserManagerImpl.java

    public boolean shouldShowOnKeyguard(NotificationEntry entry) {
        if (getEntryManager() == null) {
            Log.wtf(TAG, "mEntryManager was null!", new Throwable());
            return false;
        }
        boolean exceedsPriorityThreshold;
        if (NotificationUtils.useNewInterruptionModel(mContext)
                && hideSilentNotificationsOnLockscreen()) {
            exceedsPriorityThreshold = entry.isTopBucket();
        } else {
            exceedsPriorityThreshold =
                    !getEntryManager().getNotificationData().isAmbient(entry.key);
        }
        return mShowLockscreenNotifications && exceedsPriorityThreshold;
    }

```

接下来看 mShowLockscreenNotifications变量赋值



```
    private void setShowLockscreenNotifications(boolean show) {
        mShowLockscreenNotifications = show;
    }

protected void updateLockscreenNotificationSetting() {
        final boolean show = Settings.Secure.getIntForUser(mContext.getContentResolver(),
                Settings.Secure.LOCK_SCREEN_SHOW_NOTIFICATIONS,
                1,
                mCurrentUserId) != 0;
        final int dpmFlags = mDevicePolicyManager.getKeyguardDisabledFeatures(
                null /* admin */, mCurrentUserId);
        final boolean allowedByDpm = (dpmFlags
                & DevicePolicyManager.KEYGUARD_DISABLE_SECURE_NOTIFICATIONS) == 0;

        setShowLockscreenNotifications(show && allowedByDpm);

        if (ENABLE_LOCK_SCREEN_ALLOW_REMOTE_INPUT) {
            final boolean remoteInput = Settings.Secure.getIntForUser(mContext.getContentResolver(),
                    Settings.Secure.LOCK_SCREEN_ALLOW_REMOTE_INPUT,
                    0,
                    mCurrentUserId) != 0;
            final boolean remoteInputDpm =
                    (dpmFlags & DevicePolicyManager.KEYGUARD_DISABLE_REMOTE_INPUT) == 0;

            setLockscreenAllowRemoteInput(remoteInput && remoteInputDpm);
        } else {
            setLockscreenAllowRemoteInput(false);
        }
    }

  final boolean show = Settings.Secure.getIntForUser(mContext.getContentResolver(),
                Settings.Secure.LOCK_SCREEN_SHOW_NOTIFICATIONS,
                1,
                mCurrentUserId) != 0;

```

查看 Settings.Secure.LOCK\_SCREEN\_SHOW\_NOTIFICATIONS


在DatabaseHelper.java中Settings.Secure.LOCK\_SCREEN\_SHOW\_NOTIFICATIONS  
 /framework/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java



```
loadIntegerSetting(stmt, Settings.Secure.LOCK_SCREEN_SHOW_NOTIFICATIONS,
                        R.integer.def_lock_screen_show_notifications);

```

接下来看def\_lock\_screen\_show\_notifications



```
frameworks/base/packages/SettingsProvider/res/values/defaults.xml
<integer name="def\_lock\_screen\_show\_notifications">1</integer>

```

默认值是1 就是在锁屏的时候显示通知 所以说如果在锁屏界面不显示通知  
 设置0就行了


最终修改为:



```
<integer name="def\_lock\_screen\_show\_notifications">0</integer>

```




