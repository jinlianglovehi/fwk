






### 1.概述


在10.0的系统产品开发中，在定制化开发中，由于需要动态壁纸，而系统自带的只有默认的静态壁纸，  
 所以需要添加动态壁纸的功能


### 2.WallpaperPicker2添加动态壁纸服务的核心类



```
packages\apps\WallpaperPicker2\src\com\android\wallpaper\widget\GIFWallpaperService.java

```

### 3.WallpaperPicker2添加动态壁纸服务的核心功能实现和分析


而在10.0 中关于设置系统壁纸的是WallpaperPicker2 这个app 源码在package/apps/下


首选我们来看设置动态壁纸和静态壁纸的方法


静态壁纸的设置：


第一种: 设置bitmap



```
public void onSetWallpaperForBitmap(View view) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        try {
            Bitmap wallpaperBitmap = BitmapFactory.decodeResource(getResources(), R.raw.girl);
            wallpaperManager.setBitmap(wallpaperBitmap);

            // 已过时的Api
//            setWallpaper(wallpaperBitmap);
//            setWallpaper(getResources().openRawResource(R.raw.girl));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

```

第二种：通过资源文件



```
public void onSetWallpaperForBitmap(View view) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        try {
            

wallpaperManager.setResource(R.raw.wallpaper);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

```

第三种 通过流



```
public void onSetWallpaperForInputStream(View view) {
    WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
    try {
        InputStream inputStream = getResources().openRawResource(R.raw.girl)
        wallpaperManager.setStream(inputStream);
    } catch (IOException e) {
        e.printStackTrace();
    }
}

```

通过上面三种方式都可以设置静态壁纸  
 静态壁纸的设置相对比较简单点  
 而动态壁纸需要添加动态壁纸的服务来实现


### 3.1在WallpaperPicker2中添加动态壁纸服务



```
package com.android.wallpaper.widget;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.os.Handler;
import android.service.wallpaper.WallpaperService;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import com.custom.livewallpaper.R;
import java.io.InputStream;

public class GIFWallpaperService extends WallpaperService {

    @Override
    public WallpaperService.Engine onCreateEngine() {
        try {
            InputStream inputStream = getResources().openRawResource(R.raw.index);
            Movie movie = Movie.decodeStream(inputStream);

            return new GIFWallpaperEngine(movie);
        } catch (Exception e) {
            Log.d("GIF", "Could not load asset");
            e.printStackTrace();
            return null;
        }
    }

    private class GIFWallpaperEngine extends Engine {

        private final int frameDuration = 20;

        private SurfaceHolder holder;
        private Movie movie;
        private boolean visible=true;
        private Handler handler;

        public GIFWallpaperEngine(Movie movie) {
            this.movie = movie;
            handler = new Handler();
        }

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            this.holder = surfaceHolder;
        }

        private Runnable drawGIF = new Runnable() {
            public void run() {
                draw();
            }
        };


        private void draw() {
            if (visible) {
                // 自适应屏幕
                WindowManager wm = (WindowManager) getSystemService(
                        Context.WINDOW_SERVICE);
                DisplayMetrics metrics = new DisplayMetrics();
                wm.getDefaultDisplay().getMetrics(metrics);
                int width = metrics.widthPixels;
                int height = metrics.heightPixels;
                Canvas canvas = holder.lockCanvas();
                canvas.save();
                // Adjust size and position so that
                // the image looks good on your screen
                int w = movie.width();
                int h = movie.height();

                float scaleWight = ((float) width) / w;
 float scaleHeight = ((float) height) / h;

 canvas.scale(scaleWight, scaleHeight);

 movie.draw(canvas, 0, 0);
 canvas.restore();
 holder.unlockCanvasAndPost(canvas);
 movie.setTime((int) (System.currentTimeMillis() % movie.duration()));

                handler.removeCallbacks(drawGIF);
                handler.postDelayed(drawGIF, frameDuration);
            }
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (visible) {
                handler.post(drawGIF);
            } else {
                handler.removeCallbacks(drawGIF);
            }
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            handler.removeCallbacks(drawGIF);
        }
    }
}

```

通过在WallpaperPicker2 中添加GIFWallpaperService 动态壁纸服务，在更换壁纸的时候，更换动态壁纸作为系统默认的  
 动态壁纸  
 2. 在AndroidManifest.xml 注册动态壁纸服务



```
<service
    android:name="com.android.wallpaper.widget.GIFWallpaperService"
    android:enabled="true"
    android:label="GifWallpaper"
    android:permission="android.permission.BIND\_WALLPAPER">
    <intent-filter>
        <action android:name="android.service.wallpaper.WallpaperService" />
    </intent-filter>
    <meta-data
        android:name="android.service.wallpaper"
        android:resource="@xml/livepaper"></meta-data>
</service>

```

添加自定义的service服务，注册这个服务,然后在res的xml下增加livepaper.xml这个动态壁纸的文件  
 livepaper.xml



```
<?xml version="1.0" encoding="UTF-8"?>
<wallpaper
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:label="GIF Wallpaper"
    android:thumbnail="@mipmap/aac">
</wallpaper>

```

设置动态壁纸所需要的资源 增加在源码res的xml目录下面就可以了  
 mipmap/aac 为动态壁纸的一个索引图片


通过代码设置动态壁纸  
 设置动态壁纸的方式方法如下:



```
try {
    Intent localIntent = new Intent();
    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {//ICE_CREAM_SANDWICH_MR1  15
        localIntent.setAction(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);//android.service.wallpaper.CHANGE_LIVE_WALLPAPER
        //android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT
        localIntent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT
                , new ComponentName(context.getApplicationContext().getPackageName()
                        , GIFWallpaperService.class.getCanonicalName()));
    } else {
        localIntent.setAction(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);//android.service.wallpaper.LIVE_WALLPAPER_CHOOSER
    }
    paramActivity.startActivityForResult(localIntent, requestCode);
} catch (Exception localException) {
    localException.printStackTrace();
}

```

这样就添加完毕了.





