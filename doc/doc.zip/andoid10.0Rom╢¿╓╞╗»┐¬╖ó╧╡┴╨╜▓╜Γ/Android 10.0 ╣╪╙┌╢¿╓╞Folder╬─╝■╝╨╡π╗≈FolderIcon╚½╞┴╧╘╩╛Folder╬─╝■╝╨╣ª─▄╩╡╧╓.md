



## 1.前言


在10.0的系统ROM定制化开发中，在实现Folder文件夹的相关定制中，有需求要求在点击FolderIcon的文件夹缩略图的图标的时候， 当展开文件夹Folder的时候，需要全屏显示Folder的功能，所以就需要分析下文件夹展开流程，然后实现全屏展开文件夹 的功能


## 2.关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心类



```
packages\apps\Launcher3\res\layout\user_folder_icon_normalized.xml
packages\apps\Launcher3\src\com\android\launcher3\folder\Folder.java
```

## 3.关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心功能分析和实现


在Launcher3中长按桌面图标在拖动app图标，当靠近某个app的图标的时候，这时候这两个app图标就会形成文件夹图标FolderIcon的缩略图。打开的文件夹叫Folder ，桌面上和图标一样的文件夹叫FolderIcon，文件夹的主要逻辑代码都在Launcher\src\com\android\launcher3\folder包下面 在Launcher3中添加默认文件夹就是通过添加folder中的，然后展开文件夹后，显示当前的item图标，而关于 folder文件夹的布局就是user\_folder\_icon\_normalized.xml，在这里面定义了Folder里面的分页放置item图标的pageview, 和分页图标，接下来具体实现相关功能


## 3.1 user\_folder\_icon\_normalized.xml的相关功能分析


在关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心功能实现中，在通过上述的分析得知， 在 user\_folder\_icon\_normalized.xml中主要定义了关于Folder文件夹的相关布局，接下来分析下相关的布局 看下全屏功能怎么实现



```
<com.android.launcher3.folder.Folder xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:background="@drawable/round_rect_folder"
    android:elevation="5dp"
    android:orientation="vertical" >

    <com.android.launcher3.folder.FolderPagedView
        android:id="@+id/folder_content"
        android:clipToPadding="false"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:paddingLeft="8dp"
        android:paddingRight="8dp"
        android:paddingTop="16dp"
        launcher:pageIndicator="@+id/folder_page_indicator" />

    <LinearLayout
        android:id="@+id/folder_footer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:clipChildren="false"
        android:orientation="horizontal"
        android:paddingLeft="12dp"
        android:paddingRight="12dp" >

        <com.android.launcher3.folder.FolderNameEditText
            android:id="@+id/folder_name"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_gravity="center_vertical"
            style="@style/TextHeadline"
            android:layout_weight="1"
            android:background="@android:color/transparent"
            android:textStyle="bold"
            android:gravity="center_horizontal"
            android:hint="@string/folder_hint_text"
            android:imeOptions="flagNoExtractUi"
            android:paddingBottom="@dimen/folder_label_padding_bottom"
            android:paddingTop="@dimen/folder_label_padding_top"
            android:singleLine="true"
            android:textColor="?attr/folderTextColor"
            android:textColorHighlight="?android:attr/colorControlHighlight"
            android:textColorHint="?attr/folderHintColor"
            android:textSize="@dimen/folder_label_text_size" />

        <com.android.launcher3.pageindicators.PageIndicatorDots
            android:id="@+id/folder_page_indicator"
            android:layout_gravity="center_vertical"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:elevation="1dp"
            />

    </LinearLayout>

</com.android.launcher3.folder.Folder>
```

在关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心功能实现中，在通过上述的分析得知， 在 user\_folder\_icon\_normalized.xml中的上述源码中分析得知，在这个xml布局中，android:layout\_width和 android:layout\_height的Folder的宽高没有设置固定值，而在布局中核心的布局就是FolderPagedView 来显示文件夹的item内容，而在PageIndicatorDots就是显示分页的布局，在FolderNameEditText就是关于 文件夹名字的定义，所以接下来具体看下Folder,java中的相关源码关于布局宽高的定义


## 3.2 Folder.java中相关布局的相关源码分析


在关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心功能实现中，在通过上述的分析得知， 在Folder.java中的相关核心功能，就是在用户点击FolderIcon的时候，当展开 Folder文件夹的时候，负责加载FolderPagedView来显示文件夹的item,接下来看下具体的相关源码来分析下 Folder布局的相关宽高的设置



```
 /**
     * Opens the user folder described by the specified tag. The opening of the folder
     * is animated relative to the specified View. If the View is null, no animation
     * is played.
     */
    public void animateOpen() {
        animateOpen(mInfo.contents, 0);
    }

    /**
     * Opens the user folder described by the specified tag. The opening of the folder
     * is animated relative to the specified View. If the View is null, no animation
     * is played.
     */
    private void animateOpen(List<WorkspaceItemInfo> items, int pageNo) {
        animateOpen(items, pageNo, false);
    }

    /**
     * Opens the user folder described by the specified tag. The opening of the folder
     * is animated relative to the specified View. If the View is null, no animation
     * is played.
     */
    private void animateOpen(List<WorkspaceItemInfo> items, int pageNo, boolean skipUserEventLog) {
        Folder openFolder = getOpen(mLauncher);
        if (openFolder != null && openFolder != this) {
            // Close any open folder before opening a folder.
            openFolder.close(true);
        }

        mContent.bindItems(items);
        centerAboutIcon();
        mItemsInvalidated = true;
        updateTextViewFocus();

        mIsOpen = true;

        DragLayer dragLayer = mLauncher.getDragLayer();
        // Just verify that the folder hasn't already been added to the DragLayer.
        // There was a one-off crash where the folder had a parent already.
        if (getParent() == null) {
            dragLayer.addView(this);
            mDragController.addDropTarget(this);
        } else {
            if (FeatureFlags.IS_STUDIO_BUILD) {
                Log.e(TAG, "Opening folder (" + this + ") which already has a parent:"
                        + getParent());
            }
        }

        mContent.completePendingPageChanges();
        mContent.snapToPageImmediately(pageNo);

        // This is set to true in close(), but isn't reset to false until onDropCompleted(). This
        // leads to an inconsistent state if you drag out of the folder and drag back in without
        // dropping. One resulting issue is that replaceFolderWithFinalItem() can be called twice.
        mDeleteFolderOnDropCompleted = false;

        if (mCurrentAnimator != null && mCurrentAnimator.isRunning()) {
            mCurrentAnimator.cancel();
        }
......
    }
```

在关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心功能实现中，在通过上述的分析得知， 在Folder.java中的相关核心功能中，当用户点击FolderIcon的时候，就会展开文件夹，接下来就会调用Folder中的 animateOpen() 来显示文件夹的内容，最终会调用到animateOpen(List<WorkspaceItemInfo> items, int pageNo, boolean skipUserEventLog) 来负责展示，而在animateOpen(List<WorkspaceItemInfo> items, int pageNo, boolean skipUserEventLog)中 centerAboutIcon();就是负责展示文件夹的坐标布局的，看是在哪里定位显示，所以接下来分析下 centerAboutIcon(); 中的相关源码，



```
    private void centerAboutIcon() {
        DeviceProfile grid = mLauncher.getDeviceProfile();

        DragLayer.LayoutParams lp = (DragLayer.LayoutParams) getLayoutParams();
        DragLayer parent = mLauncher.getDragLayer();
        int width = getFolderWidth();
        int height = getFolderHeight();

        parent.getDescendantRectRelativeToSelf(mFolderIcon, sTempRect);
        int centerX = sTempRect.centerX();
        int centerY = sTempRect.centerY();
        int centeredLeft = centerX - width / 2;
        int centeredTop = centerY - height / 2;

        // We need to bound the folder to the currently visible workspace area
        if (mLauncher.getStateManager().getState().overviewUi) {
            parent.getDescendantRectRelativeToSelf(mLauncher.getOverviewPanel(), sTempRect);
        } else {
            mLauncher.getWorkspace().getPageAreaRelativeToDragLayer(sTempRect);
        }
        int left = Math.min(Math.max(sTempRect.left, centeredLeft),
                sTempRect.right- width);
        int top = Math.min(Math.max(sTempRect.top, centeredTop),
                sTempRect.bottom - height);

        int distFromEdgeOfScreen = mLauncher.getWorkspace().getPaddingLeft() + getPaddingLeft();

        if (grid.isPhone && (grid.availableWidthPx - width) < 4 * distFromEdgeOfScreen) {
            // Center the folder if it is very close to being centered anyway, by virtue of
            // filling the majority of the viewport. ie. remove it from the uncanny valley
            // of centeredness.
            left = (grid.availableWidthPx - width) / 2;
        } else if (width >= sTempRect.width()) {
            // If the folder doesn't fit within the bounds, center it about the desired bounds
            left = sTempRect.left + (sTempRect.width() - width) / 2;
        }
        if (height >= sTempRect.height()) {
            // Folder height is greater than page height, center on page
            top = sTempRect.top + (sTempRect.height() - height) / 2;
        } else {
            // Folder height is less than page height, so bound it to the absolute open folder
            // bounds if necessary
            Rect folderBounds = grid.getAbsoluteOpenFolderBounds();
            left = Math.max(folderBounds.left, Math.min(left, folderBounds.right - width));
            top = Math.max(folderBounds.top, Math.min(top, folderBounds.bottom - height));
        }

        int folderPivotX = width / 2 + (centeredLeft - left);
        int folderPivotY = height / 2 + (centeredTop - top);
        setPivotX(folderPivotX);
        setPivotY(folderPivotY);

//modify code start
        lp.width = 1920/*width*/;
        lp.height = 1080/*height*/;
        lp.x = 0/*left*/;
        lp.y = 0/*top*/;
//modify code end
    }
```

在关于定制Folder文件夹点击FolderIcon全屏显示Folder文件夹功能实现的核心功能实现中，在通过上述的分析得知， 在Folder.java中的相关核心功能中，当用户点击FolderIcon的时候，就会展开文件夹，接下来就会调用Folder中的 centerAboutIcon();就是负责展示文件夹的坐标布局的定位，所以在上述的源码中，lp.width lp.height就需要设置为 屏幕的宽高，而lp.x 和lp.y设置为0 就实现了Folder文件夹全屏显示的功能



