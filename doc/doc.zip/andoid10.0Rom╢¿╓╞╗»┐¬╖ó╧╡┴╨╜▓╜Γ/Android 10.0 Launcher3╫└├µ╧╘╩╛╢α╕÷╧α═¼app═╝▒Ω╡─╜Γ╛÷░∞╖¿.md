



## 1.前言


在10.0的系统ROM定制化开发中，在Launcher3的系统原生桌面中，在显示桌面的时候，在禁用和启用app的功能测试的时候，会发现有多个相同app的图标显示在桌面  
 这对Launcher3的体验效果不是很好，所以为了优化产品，需要解决这个bug，然后让产品更完善


## 2.桌面显示多个相同app图标的解决办法的核心类



```
    packages/apps/Launcher3/src/com/android/launcher3/model/PackageUpdatedTask.java
    packages/apps/Launcher3/src/com/android/launcher3/LauncherModel.java
```

## 3.桌面显示多个相同app图标的解决办法的核心功能分析和实现


在实现Launcher3桌面显示多个相同app图标的解决办法的中，LauncherModel是*Android*桌面应用程序的一个关键组件,在启动过程中通过加载应用程序数据、创建应用程序图标和布置桌面等操作来准备好展示用户的视图，所以经过分析觉得LauncherModel是特别的重要的类，是Launcher3处理数据的核心,LauncherModel是Launcher的数据中心，但是数据中心的数据是怎么加载出来的呢，这里就要说到LoaderTask了，它是LauncherModel的核心任务,LoaderTask在绑定数据的过程中会产生不同的过程状态信息,这些信息会通过回调接口通知*LauncherModel*对数据处理的状态信息


##  3.1 LauncherModel.java中相关app更新安装源码分析


在实现Launcher3桌面显示多个相同app图标的解决办法的中，Launcher的onCreate()方法,将Launcher添加到*LauncherModel*中,是以弱引用的方式添加,初始化一些其工作,解析Launcher的布局,LoaderTask一个任务是加载桌面,一个任务是加载抽屉,同步(一个接一个)进行。*LauncherModel*:waitForIdle()方法用于等待桌面加载完成再加载抽屉,接下来分析下


LauncherModel的相关源码分析



```
      public class LauncherModel extends LauncherApps.Callback implements InstallSessionTracker.Callback {
          private static final boolean DEBUG_RECEIVER = false;
      
          static final String TAG = "Launcher.Model";
          ....
          
         public void onPackageChanged(String packageName, UserHandle user) {
              int op = PackageUpdatedTask.OP_UPDATE;
              enqueueModelUpdateTask(new PackageUpdatedTask(op, user, packageName));
          }
      
          @Override
          public void onPackageRemoved(String packageName, UserHandle user) {
              onPackagesRemoved(user, packageName);
          }
      
          public void onPackagesRemoved(UserHandle user, String... packages) {
              int op = PackageUpdatedTask.OP_REMOVE;
              FileLog.d(TAG, "package removed received " + TextUtils.join(",", packages));
              enqueueModelUpdateTask(new PackageUpdatedTask(op, user, packages));
          }
      
          @Override
          public void onPackageAdded(String packageName, UserHandle user) {
              int op = PackageUpdatedTask.OP_ADD;
              enqueueModelUpdateTask(new PackageUpdatedTask(op, user, packageName));
          }
      
          @Override
          public void onPackagesAvailable(String[] packageNames, UserHandle user,
                  boolean replacing) {
              enqueueModelUpdateTask(
                      new PackageUpdatedTask(PackageUpdatedTask.OP_UPDATE, user, packageNames));
          }
      
          @Override
          public void onPackagesUnavailable(String[] packageNames, UserHandle user,
                  boolean replacing) {
              if (!replacing) {
                  enqueueModelUpdateTask(new PackageUpdatedTask(
                          PackageUpdatedTask.OP_UNAVAILABLE, user, packageNames));
              }
          }
      
          @Override
          public void onPackagesSuspended(String[] packageNames, UserHandle user) {
              enqueueModelUpdateTask(new PackageUpdatedTask(
                      PackageUpdatedTask.OP_SUSPEND, user, packageNames));
          }

```

在实现Launcher3桌面显示多个相同app图标的解决办法的中，在LauncherModel.java中的上述源码中，在onPackageChanged(String packageName, UserHandle user)中的相关方法中，会在启动和禁用app的时候，当监听到


app变化的时候，会调用这个方法来执行相关的方法流程，接下来看下onPackageChanged(String packageName, UserHandle user)的相关源码分析



```
public void enqueueModelUpdateTask(ModelUpdateTask task) {

task.init(mApp, this, mBgDataModel, mBgAllAppsList, mMainExecutor);

MODEL_EXECUTOR.execute(task);

}
```

在实现Launcher3桌面显示多个相同app图标的解决办法的中，在LauncherModel.java中的上述源码中的相关代码可以看出，在enqueueModelUpdateTask(ModelUpdateTask task)中的主要核心功能是在


task.init(mApp, this, mBgDataModel, mBgAllAppsList, mMainExecutor);中主要是ModelUpdateTask处理相关app更新功能



```
    /**
       * Extension of {@link ModelUpdateTask} with some utility methods
       */
      public abstract class BaseModelUpdateTask implements ModelUpdateTask {
      
          private static final boolean DEBUG_TASKS = false;
          private static final String TAG = "BaseModelUpdateTask";
      
          private LauncherAppState mApp;
          private LauncherModel mModel;
          private BgDataModel mDataModel;
          private AllAppsList mAllAppsList;
          private Executor mUiExecutor;
      
          public void init(LauncherAppState app, LauncherModel model,
                  BgDataModel dataModel, AllAppsList allAppsList, Executor uiExecutor) {
              mApp = app;
              mModel = model;
              mDataModel = dataModel;
              mAllAppsList = allAppsList;
              mUiExecutor = uiExecutor;
          }
      
          @Override
          public final void run() {
              if (!mModel.isModelLoaded()) {
                  if (DEBUG_TASKS) {
                      Log.d(TAG, "Ignoring model task since loader is pending=" + this);
                  }
                  // Loader has not yet run.
                  return;
              }
              execute(mApp, mDataModel, mAllAppsList);
          }
      
          /**
           * Execute the actual task. Called on the worker thread.
           */
          public abstract void execute(
                  LauncherAppState app, BgDataModel dataModel, AllAppsList apps);
```

在实现Launcher3桌面显示多个相同app图标的解决办法的中，在BaseModelUpdateTask.java中的上述代码中，可以看出在public abstract void execute(  
 LauncherAppState app, BgDataModel dataModel, AllAppsList apps);中的相关代码，主要执行app更新的动作流程  
 而这个类的主要集成类就是在PackageUpdatedTask.java中执行的 ，接下来看下PackageUpdatedTask.java中主要执行app更新的相关代码


## 3.2 PackageUpdatedTask.java中 相关app更新的相关源码分析


在实现Launcher3桌面显示多个相同app图标的解决办法的中，*在Launcher3中，PackageUpdatedTask*处理由于程序包管理器中的更改(应用程序安装、更新、删除)等功能的实现，在app安装和卸载等功能时，所以就会在*PackageUpdatedTask中来负责*


*更新Launcher3的桌面app图标的更新*



```
   @Override
         public void execute(LauncherAppState app, BgDataModel dataModel, AllAppsList appsList) {
             final Context context = app.getContext();
             final IconCache iconCache = app.getIconCache();
     
             final String[] packages = mPackages;
             final int N = packages.length;
             FlagOp flagOp = FlagOp.NO_OP;
             final HashSet<String> packageSet = new HashSet<>(Arrays.asList(packages));
             ItemInfoMatcher matcher = ItemInfoMatcher.ofPackages(packageSet, mUser);
             final HashSet<ComponentName> removedComponents = new HashSet<>();
     
              switch (mOp) {
                  case OP_ADD: {
                      for (int i = 0; i < N; i++) {
                          if (DEBUG) Log.d(TAG, "mAllAppsList.addPackage " + packages[i]);
                          iconCache.updateIconsForPkg(packages[i], mUser);
                          if (FeatureFlags.PROMISE_APPS_IN_ALL_APPS.get()) {
                              appsList.removePackage(packages[i], mUser);
                          }
                          appsList.addPackage(context, packages[i], mUser);
      
                          // Automatically add homescreen icon for work profile apps for below O device.
                          if (!Utilities.ATLEAST_OREO && !Process.myUserHandle().equals(mUser)) {
                              SessionCommitReceiver.queueAppIconAddition(context, packages[i], mUser);
                          }
                      }
                      flagOp = FlagOp.removeFlag(WorkspaceItemInfo.FLAG_DISABLED_NOT_AVAILABLE);
                      break;
                  }
                  case OP_UPDATE:
                      try (SafeCloseable t =
                                   appsList.trackRemoves(a -> removedComponents.add(a.componentName))) {
                          for (int i = 0; i < N; i++) {
                              if (DEBUG) Log.d(TAG, "mAllAppsList.updatePackage " + packages[i]);
                              iconCache.updateIconsForPkg(packages[i], mUser);
                              appsList.updatePackage(context, packages[i], mUser);
                              app.getWidgetCache().removePackage(packages[i], mUser);
                          }
                      }
                      // Since package was just updated, the target must be available now.
                  //    flagOp = FlagOp.removeFlag(WorkspaceItemInfo.FLAG_DISABLED_NOT_AVAILABLE);
                      break;
```

在实现Launcher3桌面显示多个相同app图标的解决办法的中，在PackageUpdatedTask.java中的相关源码中，可以看出主要在 execute(LauncherAppState app, BgDataModel dataModel, AllAppsList appsList)  
 中核心功能就是更新app的内容和添加app到launcher桌面 ，所以在case OP\_UPDATE中，需要注意的是注释掉  
 flagOp = FlagOp.removeFlag(WorkspaceItemInfo.FLAG\_DISABLED\_NOT\_AVAILABLE);中的这段代码就可以了 这段代码的注释就可以看出  
 绘制app更新的时候，添加app图标



