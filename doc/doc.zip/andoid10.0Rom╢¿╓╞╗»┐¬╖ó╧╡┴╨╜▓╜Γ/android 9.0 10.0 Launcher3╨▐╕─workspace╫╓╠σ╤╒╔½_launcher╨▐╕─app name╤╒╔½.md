






### 1.概述


在10.0的系统产品开发中，对于系统自带的原生Launcher3 中的workspace app  
 列表页的白色字体不太好看，所以要求更换字体颜色，这需要找到关于字体的相关样式，更换掉样式就可以了  
 就得从style.xml中入手了


### 2.Launcher3修改workspace字体颜色核心类



```
packages\apps\Launcher3\AndroidManifest.xml
packages\apps\Launcher3\res\values\style.xml

```

### 3.Launcher3修改workspace字体颜色核心功能分析和实现


对于修改app的样式，首选看AndroidManifest.xml 中的application节点的style的样式属性中的  
 样式，然后看怎么修改这个样式，接下来看这个样式分析问题  
 路径: packages\apps\Launcher3\AndroidManifest.xml


### 3.1AndroidManifest.xml关于样式的分析



```
<manifest
    xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.android.launcher3">
    <uses-sdk android:targetSdkVersion="29" android:minSdkVersion="25"/>
    <!--
    Manifest entries specific to Launcher3. This is merged with AndroidManifest-common.xml.
    Refer comments around specific entries on how to extend individual components.
    -->

    <application
        android:backupAgent="com.android.launcher3.LauncherBackupAgent"
        android:fullBackupOnly="true"
        android:fullBackupContent="@xml/backupscheme"
        android:hardwareAccelerated="true"
        android:icon="@drawable/ic\_launcher\_home"
        android:label="@string/derived\_app\_name"
        android:theme="@style/AppTheme"
        android:largeHeap="@bool/config\_largeHeap"
        android:restoreAnyVersion="true"
        android:supportsRtl="true" >

        <!--
        Main launcher activity. When extending only change the name, and keep all the
        attributes and intent filters the same
        -->
        <activity
            android:name="com.android.launcher3.Launcher"
            android:launchMode="singleTask"
            android:clearTaskOnLaunch="true"
            android:stateNotNeeded="true"
            android:windowSoftInputMode="adjustPan"
            android:screenOrientation="unspecified"
            android:configChanges="keyboard|keyboardHidden|mcc|mnc|navigation|orientation|screenSize|screenLayout|smallestScreenSize"
            android:resizeableActivity="true"
            android:resumeWhilePausing="true"
            android:taskAffinity=""
            android:enabled="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.HOME" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.MONKEY"/>
                <category android:name="android.intent.category.LAUNCHER\_APP" />
            </intent-filter>
            <meta-data
                android:name="com.android.launcher3.grid.control"
                android:value="${packageName}.grid\_control" />
        </activity>

    </application>
</manifest>

```

从AndroidManifest.xml 中可以看到用的样式是 android:theme=“@style/AppTheme”  
 接下来看下style.xml 中的AppTheme样式了  
 路径为:packages\apps\Launcher3\res\values\style.xml


### 3.2style.xml样式的分析



```
    <!-- Launcher theme -->
    <style name="BaseLauncherTheme" parent="@android:style/Theme.DeviceDefault.Light">
        <item name="android:colorBackgroundCacheHint">@null</item>
        <item name="android:colorEdgeEffect">#FF757575</item>
        <item name="android:windowActionBar">false</item>
        <item name="android:windowBackground">@android:color/transparent</item>
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowShowWallpaper">true</item>
        <item name="folderTextColor">?attr/workspaceTextColor</item>
    </style>

    <style name="LauncherTheme" parent="@style/BaseLauncherTheme">
        <item name="allAppsScrimColor">#EAFFFFFF</item>
        <item name="allAppsInterimScrimAlpha">46</item>
        <item name="allAppsNavBarScrimColor">#66FFFFFF</item>
        <item name="popupColorPrimary">#FFF</item>
        <item name="popupColorSecondary">#F5F5F5</item> <!-- Gray 100 -->
        <item name="popupColorTertiary">#E0E0E0</item> <!-- Gray 300 -->
        <item name="isMainColorDark">false</item>
        <item name="isWorkspaceDarkText">false</item>
        <item name="workspaceTextColor">@android:color/white</item>
        <item name="workspaceShadowColor">#B0000000</item>
        <item name="workspaceAmbientShadowColor">#33000000</item>
        <item name="workspaceKeyShadowColor">#44000000</item>
        <item name="workspaceStatusBarScrim">@drawable/workspace_bg</item>
        <item name="widgetsTheme">@style/WidgetContainerTheme</item>
        <item name="folderDotColor">?android:attr/colorPrimary</item>
        <item name="folderFillColor">#CDFFFFFF</item>
        <item name="folderIconBorderColor">?android:attr/colorPrimary</item>
        <item name="folderTextColor">#FF212121</item>
        <item name="loadingIconColor">#CCFFFFFF</item>

        <item name="gridFolderPageStrokeColor">#66FFFFFF</item>

        <item name="android:windowTranslucentStatus">false</item>
        <item name="android:windowTranslucentNavigation">false</item>
        <item name="android:windowDrawsSystemBarBackgrounds">true</item>
        <item name="android:statusBarColor">#00000000</item>
        <item name="android:navigationBarColor">#00000000</item>
    </style>

    <style name="LauncherTheme.DarkMainColor" parent="@style/LauncherTheme">
        <item name="folderFillColor">#FF3C4043</item> <!-- 100% GM2 800 -->
        <item name="folderTextColor">?attr/workspaceTextColor</item>
    </style>

    <style name="LauncherTheme.DarkText" parent="@style/LauncherTheme">
        <item name="workspaceTextColor">#FF212121</item>
        <item name="allAppsInterimScrimAlpha">128</item>
        <item name="workspaceShadowColor">@android:color/transparent</item>
        <item name="workspaceAmbientShadowColor">@android:color/transparent</item>
        <item name="workspaceKeyShadowColor">@android:color/transparent</item>
        <item name="isWorkspaceDarkText">true</item>
        <item name="workspaceStatusBarScrim">@null</item>
        <item name="folderDotColor">#FF464646</item>
        <item name="folderFillColor">#CDFFFFFF</item>
        <item name="folderIconBorderColor">#FF80868B</item>
        <item name="folderTextColor">?attr/workspaceTextColor</item>

        <item name="gridFolderPageStrokeColor">#FF80868B</item>
    </style>

    <style name="LauncherTheme.Dark" parent="@style/LauncherTheme">
        <item name="android:textColorPrimary">#FFFFFFFF</item>
        <item name="android:textColorSecondary">#FFFFFFFF</item>
        <item name="android:textColorTertiary">#CCFFFFFF</item>
        <item name="android:textColorHint">#A0FFFFFF</item>
        <item name="android:colorControlHighlight">#A0FFFFFF</item>
        <item name="android:colorPrimary">#FF212121</item>
        <item name="allAppsScrimColor">#EA212121</item>
        <item name="allAppsInterimScrimAlpha">102</item>
        <item name="allAppsNavBarScrimColor">#80000000</item>
        <item name="popupColorPrimary">#3C4043</item> <!-- Gray 800 -->
        <item name="popupColorSecondary">#5F6368</item> <!-- Gray 700 -->
        <item name="popupColorTertiary">#757575</item> <!-- Gray 600 -->
        <item name="widgetsTheme">@style/WidgetContainerTheme.Dark</item>
        <item name="folderDotColor">#FF464646</item>
        <item name="folderFillColor">#DD3C4043</item> <!-- 87% GM2 800 -->
        <item name="folderIconBorderColor">#FF80868B</item>
        <item name="folderTextColor">@android:color/white</item>
        <item name="isMainColorDark">true</item>
        <item name="loadingIconColor">#99FFFFFF</item>

        <item name="gridFolderPageStrokeColor">#FF80868B</item>
    </style>

    <style name="LauncherTheme.Dark.DarkMainColor" parent="@style/LauncherTheme.Dark">
        <item name="folderFillColor">#FF3C4043</item> <!-- 100% GM2 800 -->
        <item name="folderTextColor">@android:color/white</item>
    </style>

    <style name="LauncherTheme.Dark.DarkText" parent="@style/LauncherTheme.Dark">
        <item name="allAppsInterimScrimAlpha">25</item>
        <item name="folderFillColor">#CDFFFFFF</item>
        <item name="folderTextColor">?attr/workspaceTextColor</item>
        <item name="workspaceTextColor">#FF212121</item>
        <item name="workspaceShadowColor">@android:color/transparent</item>
        <item name="workspaceAmbientShadowColor">@android:color/transparent</item>
        <item name="workspaceKeyShadowColor">@android:color/transparent</item>
        <item name="isWorkspaceDarkText">true</item>
        <item name="workspaceStatusBarScrim">@null</item>
    </style>

    <!-- A derivative project can extend these themes to customize the application theme without
         affecting the base theme -->
    <style name="AppTheme" parent="@style/LauncherTheme" />

```

从style的样式中可以看出LauncherTheme就是关于workspace的样式，贼  
 LauncherTheme中的样式



```
 <item name="workspaceTextColor">#FFA07A</item>

```

即为字体样式颜色  
 所以修改颜色值即可修改workspace app的字体颜色  
 修改完后编译Launcher3QuickStep 替换apk 就可以了





