






### 1.概述


最近有客户有需求要求给app添加锁，就是点击app 图标时，会弹出Dialog,需要输入密码才能进入app中,就是应用校验锁，  
 最开始想到在Launcher3中实现，但是如果更换了默认Launcher 又不行了 所以最终还是得拦截app启动Activity 从这里入手了


### 2.app添加校验锁(输入密码才能进入app)的核心类



```
frameworks/base/services/core/java/com/android/server/wm/ActivityStarter.java

```

### 3.app添加校验锁(输入密码才能进入app)的核心功能分析和实现


Launcher与APP是在两个不同的进程中，他们之间的通信是通过Binder完成的，点击Launcher上的某个APP，这时会调用Launcher的startActivitySafely方法。



```
public boolean startActivitySafely(View v, Intent intent, ItemInfo item) {
    ...
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//1
    ...
    startActivity(intent, optsBundle);//2
    ...
}

```

上面代码我省略了一些不太重要的，重点看上面两行代码，第一行给intent设置Flag为Intent.FLAG\_ACTIVITY\_NEW\_TASK，Activity会在新的任务栈中启动，第二行代码调用startActivity方法，很简单，就是启动APP中的Activity。


最终会调用Activity的startActivity方法，Intent中携带的就是需要启动的APP的Activity信息。startActivity方法最终会调用startActivityForResult  
 在AMS 中最后会调用ActivityStarter.java的startActivity来启动Activity 所以在这里拦截启动是最好的方法



```
private int startActivity(IApplicationThread caller, Intent intent, Intent ephemeralIntent,
                              String resolvedType, ActivityInfo aInfo, ResolveInfo rInfo,
                              IVoiceInteractionSession voiceSession, IVoiceInteractor voiceInteractor,
                              IBinder resultTo, String resultWho, int requestCode, int callingPid, int callingUid,
                              String callingPackage, int realCallingPid, int realCallingUid, int startFlags,
                              SafeActivityOptions options,
                              boolean ignoreTargetSecurity, boolean componentSpecified, ActivityRecord[] outActivity,
                              TaskRecord inTask, boolean allowPendingRemoteAnimationRegistryLookup,
                              PendingIntentRecord originatingPendingIntent, boolean allowBackgroundActivityStart) {
        mSupervisor.getActivityMetricsLogger().notifyActivityLaunching(intent);
        int err = ActivityManager.START_SUCCESS;
        // Pull the optional Ephemeral Installer-only bundle out of the options early.
        final Bundle verificationBundle
                = options != null ? options.popAppVerificationBundle() : null;

        WindowProcessController callerApp = null;
        if (caller != null) {
            callerApp = mService.getProcessController(caller);
            if (callerApp != null) {
                callingPid = callerApp.getPid();
                callingUid = callerApp.mInfo.uid;
            } else {
                Slog.w(TAG, "Unable to find app for caller " + caller
                        + " (pid=" + callingPid + ") when starting: "
                        + intent.toString());
                err = ActivityManager.START_PERMISSION_DENIED;
            }
        }

        final int userId = aInfo != null && aInfo.applicationInfo != null
                ? UserHandle.getUserId(aInfo.applicationInfo.uid) : 0;

        if (err == ActivityManager.START_SUCCESS) {
            Slog.i(TAG, "START u" + userId + " {" + intent.toShortString(true, true, true, false)
                    + "} from uid " + callingUid + ", pid " + callingPid);
        }

        // NOTE: Bug #627645 low power Feature BEG-->
        String targetPkg = null;
        ActivityManagerService am = (ActivityManagerService)ActivityManager.getService();
        int targetUid = aInfo != null && aInfo.applicationInfo != null ? aInfo.applicationInfo.uid : 0;
        if (intent.getComponent() != null) targetPkg = intent.getComponent().getPackageName();
        if(!am.judgeStartAllowLocked(intent, targetPkg, targetUid, callingUid, callingPackage, "start-activity")){
            return ActivityManager.START_INTENT_NOT_RESOLVED;
        }
        // <-- NOTE: Bug #627645 low power Feature END

        ActivityRecord sourceRecord = null;
        ActivityRecord resultRecord = null;
        if (resultTo != null) {
            sourceRecord = mRootActivityContainer.isInAnyStack(resultTo);
            if (DEBUG_RESULTS) Slog.v(TAG_RESULTS,
                    "Will send result to " + resultTo + " " + sourceRecord);
            if (sourceRecord != null) {
                if (requestCode >= 0 && !sourceRecord.finishing) {
                    resultRecord = sourceRecord;
                }
            }
        }

        final int launchFlags = intent.getFlags();

        if ((launchFlags & Intent.FLAG\_ACTIVITY\_FORWARD\_RESULT) != 0 && sourceRecord != null) {
 // Transfer the result target from the source activity to the new
 // one being started, including any failures.
 if (requestCode >= 0) {
 SafeActivityOptions.abort(options);
 Slog.i(TAG,"->startActivity for " + intent
 + ", return START\_FORWARD\_AND\_REQUEST\_CONFLICT");
 return ActivityManager.START\_FORWARD\_AND\_REQUEST\_CONFLICT;
 }
 resultRecord = sourceRecord.resultTo;
 if (resultRecord != null && !resultRecord.isInStackLocked()) {
                resultRecord = null;
            }
            resultWho = sourceRecord.resultWho;
            requestCode = sourceRecord.requestCode;
            sourceRecord.resultTo = null;
            if (resultRecord != null) {
                resultRecord.removeResultsLocked(sourceRecord, resultWho, requestCode);
            }
            if (sourceRecord.launchedFromUid == callingUid) {
                // The new activity is being launched from the same uid as the previous
                // activity in the flow, and asking to forward its result back to the
                // previous.  In this case the activity is serving as a trampoline between
                // the two, so we also want to update its launchedFromPackage to be the
                // same as the previous activity.  Note that this is safe, since we know
                // these two packages come from the same uid; the caller could just as
                // well have supplied that same package name itself.  This specifially
                // deals with the case of an intent picker/chooser being launched in the app
                // flow to redirect to an activity picked by the user, where we want the final
                // activity to consider it to have been launched by the previous app activity.
                callingPackage = sourceRecord.launchedFromPackage;
            }
        }
....
        if (r.appTimeTracker == null && sourceRecord != null) {
            // If the caller didn't specify an explicit time tracker, we want to continue
            // tracking under any it has.
            r.appTimeTracker = sourceRecord.appTimeTracker;
        }
        mService.notifyActivityStateChange(r.intent, ProcessInfo.ACTIVITY_STATE_START, null);

        final ActivityStack stack = mRootActivityContainer.getTopDisplayFocusedStack();

        // If we are starting an activity that is not from the same uid as the currently resumed
        // one, check whether app switches are allowed.
        if (voiceSession == null && (stack.getResumedActivity() == null
                || stack.getResumedActivity().info.applicationInfo.uid != realCallingUid)) {
            if (!mService.checkAppSwitchAllowedLocked(callingPid, callingUid,
                    realCallingPid, realCallingUid, "Activity start")) {
                if (!(restrictedBgActivity && handleBackgroundActivityAbort(r))) {
                    mController.addPendingActivityLaunch(new PendingActivityLaunch(r,
                            sourceRecord, startFlags, stack, callerApp));
                }
                ActivityOptions.abort(checkedOptions);
                Slog.i(TAG, "->startActivity for " + intent + ", return START\_SWITCHES\_CANCELED");
                return ActivityManager.START_SWITCHES_CANCELED;
            }
        }

        mService.onStartActivitySetDidAppSwitch();
        mController.doPendingActivityLaunches(false);

        final int res = startActivity(r, sourceRecord, voiceSession, voiceInteractor, startFlags,
                true /* doResume */, checkedOptions, inTask, outActivity, restrictedBgActivity);
        mSupervisor.getActivityMetricsLogger().notifyActivityLaunched(res, outActivity[0]);
        return res;
    }

```

在这个方法里面 可以追踪到 当前具体启动哪个Activity 所以在这里拦截最合适  
 通过添加showAppCheckPasswordWindow来弹出输入密码的弹窗，然后验证密码 看是否密码正确在进入是否进入app  
 就给app添加了密码锁功能  
 具体实现方案如下:



```
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RelativeLayout;
import android.view.ViewGroup;
import android.graphics.PixelFormat;

```

// 添加输入密码窗口 输入正确密码后 进入app



```
private void showAppCheckPasswordWindow(Context mContext, IApplicationThread caller, Intent intent, Intent ephemeralIntent,
                                       String resolvedType, ActivityInfo aInfo, ResolveInfo rInfo,
                                       IVoiceInteractionSession voiceSession, IVoiceInteractor voiceInteractor,
                                       IBinder resultTo, String resultWho, int requestCode, int callingPid, int callingUid,
                                       String callingPackage, int realCallingPid, int realCallingUid, int startFlags,
                                       SafeActivityOptions options,
                                       boolean ignoreTargetSecurity, boolean componentSpecified, ActivityRecord[] outActivity,
                                       TaskRecord inTask, boolean allowPendingRemoteAnimationRegistryLookup,
                                       PendingIntentRecord originatingPendingIntent, boolean allowBackgroundActivityStart) {

    final WindowManager.LayoutParams mLayoutParams =  new WindowManager.LayoutParams();
    mLayoutParams.width = 400;
    mLayoutParams.height = 250;
mLayoutParams.dimAmount =0.5f;
    mLayoutParams.format = PixelFormat.TRANSLUCENT;
    mLayoutParams.type = WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG;
    WindowManager mWindowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);

    final LinearLayout parentLayout = new LinearLayout(mContext);
    parentLayout.setOrientation(LinearLayout.VERTICAL);
    parentLayout.setBackgroundColor(Color.WHITE);
    LinearLayout.LayoutParams layoutParams
            = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT);
    parentLayout.setLayoutParams(layoutParams);

    TextView titleText = new TextView(mContext);
    LinearLayout.LayoutParams contentParams
            = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    titleText.setLayoutParams(contentParams);
    titleText.setText("check password");
    titleText.setTextColor(Color.BLACK);
    titleText.setTypeface(Typeface.create(titleText.getTypeface(), Typeface.NORMAL), Typeface.BOLD);
    titleText.setPadding(10, 10, 0, 0);
    parentLayout.addView(titleText);

    EditText passEdtTxt = new EditText(mContext);
    passEdtTxt.setLayoutParams(contentParams);
	passEdtTxt.setHint("Please input password");
	passEdtTxt.setTextSize(14);
    passEdtTxt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    passEdtTxt.setTextColor(Color.BLACK);
	passEdtTxt.setBackgroundResource(com.android.internal.R.drawable.shape_corner);
	
    parentLayout.addView(passEdtTxt);
    RelativeLayout reLayout = new RelativeLayout(mContext);
    RelativeLayout.LayoutParams rightReal = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    rightReal.addRule(RelativeLayout.ALIGN_PARENT_TOP);
    rightReal.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
    rightReal.setMargins(0,10,15,0);
    
    Button confirmBtn = new Button(mContext);
    LinearLayout.LayoutParams btnParams
            = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    confirmBtn.setLayoutParams(btnParams);
    confirmBtn.setText("ok");
    confirmBtn.setTextColor(Color.parseColor("#BEBEBE"));
    confirmBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String password = passEdtTxt.getText().toString();

            if ("123456".equals(password)) {
                if (parentLayout!=null){
                    mWindowManager.removeViewImmediate(parentLayout);
                    //parentLayout = null;
                }
                mIsPassCheck = true;
                startActivity(caller, intent, ephemeralIntent,
                        resolvedType, aInfo, rInfo,
                        voiceSession,  voiceInteractor,
                        resultTo,  resultWho,  requestCode,  callingPid,  callingUid,
                        callingPackage,  realCallingPid,  realCallingUid,  startFlags,
                        options,
                        ignoreTargetSecurity,  componentSpecified,  outActivity,
                        inTask,  allowPendingRemoteAnimationRegistryLookup,
                        originatingPendingIntent,  allowBackgroundActivityStart);
            }else {
                mIsPassCheck = false;
                Toast.makeText(mContext,"密码错误,请重新输入...",Toast.LENGTH_SHORT).show();
            }
        }
    });
	reLayout.addView(confirmBtn, rightReal);
	RelativeLayout.LayoutParams leftReal = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    leftReal.addRule(RelativeLayout.ALIGN_PARENT_TOP);
    leftReal.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
    leftReal.setMargins(15,10,0,0);
    Button cancelBtn = new Button(mContext);
    LinearLayout.LayoutParams cancelbtnParams
            = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    cancelBtn.setLayoutParams(cancelbtnParams);
    cancelBtn.setText("cancel");
    cancelBtn.setTextColor(Color.parseColor("#BEBEBE"));
    cancelBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
               if (parentLayout!=null){
                    mWindowManager.removeViewImmediate(parentLayout);
                    //parentLayout = null;
                }
                mIsPassCheck = false;
        }
    });
	reLayout.addView(cancelBtn, leftReal);
    parentLayout.addView(reLayout);
    try {
        mWindowManager.addView(parentLayout, mLayoutParams);
    } catch (WindowManager.BadTokenException e) {
        e.printStackTrace();
    }
}

boolean mIsLocked=false;
boolean mIsPassCheck=false;
IApplicationThread mApplicationThread;
Intent mPsdIntent, mSephemeralIntent;
String mResolvedType, mResultWho, mCallingPackage;
ActivityInfo mActivityInfo;
ResolveInfo mResolveInfo;
int mRequestCode, mCallingPid, mCallUid, mRealCallingPid, mRealCallingUid, mStartflags;
boolean mSignoreTargetSecurity, mComponentSpecified, mAllowPendingRemoteAnimationRegistryLookup, mAllowBackgroundActivityStart;
IVoiceInteractionSession mVoicesessions;
IVoiceInteractor mVoiceinteractors;
IBinder mResultTo;
SafeActivityOptions mSafeoptions;
ActivityRecord[] mOutActivity;
TaskRecord mIntasks;
PendingIntentRecord mOriginatingPendingIntent;

private int startActivity(IApplicationThread caller, Intent intent, Intent ephemeralIntent,
                          String resolvedType, ActivityInfo aInfo, ResolveInfo rInfo,
                          IVoiceInteractionSession voiceSession, IVoiceInteractor voiceInteractor,
                          IBinder resultTo, String resultWho, int requestCode, int callingPid, int callingUid,
                          String callingPackage, int realCallingPid, int realCallingUid, int startFlags,
                          SafeActivityOptions options,
                          boolean ignoreTargetSecurity, boolean componentSpecified, ActivityRecord[] outActivity,
                          TaskRecord inTask, boolean allowPendingRemoteAnimationRegistryLookup,
                          PendingIntentRecord originatingPendingIntent, boolean allowBackgroundActivityStart) {
    mSupervisor.getActivityMetricsLogger().notifyActivityLaunching(intent);
    int err = ActivityManager.START_SUCCESS;
    // Pull the optional Ephemeral Installer-only bundle out of the options early.
    final Bundle verificationBundle
            = options != null ? options.popAppVerificationBundle() : null;

    WindowProcessController callerApp = null;
    if (caller != null) {
        callerApp = mService.getProcessController(caller);
        if (callerApp != null) {
            callingPid = callerApp.getPid();
            callingUid = callerApp.mInfo.uid;
        } else {
            Slog.w(TAG, "Unable to find app for caller " + caller
                    + " (pid=" + callingPid + ") when starting: "
                    + intent.toString());
            err = ActivityManager.START_PERMISSION_DENIED;
        }
    }

    final int userId = aInfo != null && aInfo.applicationInfo != null
            ? UserHandle.getUserId(aInfo.applicationInfo.uid) : 0;

    if (err == ActivityManager.START_SUCCESS) {
        Slog.i(TAG, "START u" + userId + " {" + intent.toShortString(true, true, true, false)
                + "} from uid " + callingUid + ", pid " + callingPid);
    }

    // NOTE: Bug #627645 low power Feature BEG-->
    String targetPkg = null;
    ActivityManagerService am = (ActivityManagerService)ActivityManager.getService();
    int targetUid = aInfo != null && aInfo.applicationInfo != null ? aInfo.applicationInfo.uid : 0;
    if (intent.getComponent() != null) targetPkg = intent.getComponent().getPackageName();
    if(!am.judgeStartAllowLocked(intent, targetPkg, targetUid, callingUid, callingPackage, "start-activity")){
        return ActivityManager.START_INTENT_NOT_RESOLVED;
    }
 ....

    // Merge the two options bundles, while realCallerOptions takes precedence.
    ActivityOptions checkedOptions = options != null
            ? options.getOptions(intent, aInfo, callerApp, mSupervisor) : null;
    if (allowPendingRemoteAnimationRegistryLookup) {
        checkedOptions = mService.getActivityStartController()
                .getPendingRemoteAnimationRegistry()
                .overrideOptionsIfNeeded(callingPackage, checkedOptions);
    }
    if (mService.mController != null) {
        try {
            // The Intent we give to the watcher has the extra data
            // stripped off, since it can contain private information.
            Intent watchIntent = intent.cloneFilter();
            abort |= !mService.mController.activityStarting(watchIntent,
                    aInfo.applicationInfo.packageName);
        } catch (RemoteException e) {
            mService.mController = null;
        }
    }

    mInterceptor.setStates(userId, realCallingPid, realCallingUid, startFlags, callingPackage);
    if (mInterceptor.intercept(intent, rInfo, aInfo, resolvedType, inTask, callingPid,
            callingUid, checkedOptions)) {
        // activity start was intercepted, e.g. because the target user is currently in quiet
        // mode (turn off work) or the target application is suspended
        intent = mInterceptor.mIntent;
        rInfo = mInterceptor.mRInfo;
        aInfo = mInterceptor.mAInfo;
        resolvedType = mInterceptor.mResolvedType;
        inTask = mInterceptor.mInTask;
        callingPid = mInterceptor.mCallingPid;
        callingUid = mInterceptor.mCallingUid;
        checkedOptions = mInterceptor.mActivityOptions;
    }


    //add core start  打印日志获取当前启动哪个activity
    android.util.Log.e("ActivityStarter","callingPackage="+callingPackage);
    final String packageName = intent.getComponent().getPackageName();
    final String className = intent.getComponent().getClassName();
    android.util.Log.i("ActivityStarter","packageName="+packageName+"---className:"+className+" abort="+abort);

    if (!TextUtils.isEmpty(callingPackage)&& "com.android.documentsui".equals(packageName)) {
        mIsLocked = true;
    }else{
        mIsLocked = false;
    }

    if (mIsPassCheck) {
        android.util.Log.i("ActivityStarter","isPassCheck");
        mIsLocked = false;
        mIsPassCheck = false;
    }

    mApplicationThread = caller;
    mPsdIntent = intent;
    mSephemeralIntent = ephemeralIntent;
    mResolvedType = resolvedType;
    mActivityInfo = aInfo;
    mVoicesessions = voiceSession;
    mVoiceinteractors = voiceInteractor;
    mResultTo = resultTo;
    mResultWho = resultWho;
    mRequestCode = requestCode;
    mCallingPid = callingPid;
    mCallUid = callingUid;
    mCallingPackage = callingPackage;
    mRealCallingPid = realCallingPid;
    mRealCallingUid = realCallingUid;
    mStartflags = startFlags;
    mSafeoptions = options;
    mSignoreTargetSecurity = ignoreTargetSecurity;
    mComponentSpecified = componentSpecified;
    mOutActivity = outActivity;
    mIntasks = inTask;
    mAllowPendingRemoteAnimationRegistryLookup = allowPendingRemoteAnimationRegistryLookup;
    mOriginatingPendingIntent = originatingPendingIntent;
    mAllowBackgroundActivityStart = allowBackgroundActivityStart;

    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
        @Override
        public void run() {
            if (mIsLocked) {
                showAppCheckPasswordWindow(mService.mContext, mApplicationThread, mPsdIntent, mSephemeralIntent,
                        mResolvedType, mActivityInfo, mResolveInfo,
                        mVoicesessions, mVoiceinteractors,
                        mResultTo, mResultWho, mRequestCode, mCallingPid, mCallUid,
                        mCallingPackage, mRealCallingPid, mRealCallingUid, mStartflags,
                        mSafeoptions,
                        mSignoreTargetSecurity, mComponentSpecified, mOutActivity,
                        mIntasks, mAllowPendingRemoteAnimationRegistryLookup,
                        mOriginatingPendingIntent, mAllowBackgroundActivityStart);
            }
        }
    });

    if (mIsLocked) {// 在这里拦截启动的activity
        android.util.Log.d("ActivityStarter","拦截启动的activity");
        return ActivityManager.START_SWITCHES_CANCELED;
    }
    //add core end



    if (abort) {
        if (resultRecord != null) {
            resultStack.sendActivityResultLocked(-1, resultRecord, resultWho, requestCode,
                    RESULT_CANCELED, null);
        }
        // We pretend to the caller that it was really started, but
        // they will just get a cancel result.
        ActivityOptions.abort(checkedOptions);
        Slog.i(TAG, "->startActivity for " + intent + " abort, return START\_ABORTED");
        return START_ABORTED;
    }
}

```

然后编码验证 可以正常的拦截app启动了





