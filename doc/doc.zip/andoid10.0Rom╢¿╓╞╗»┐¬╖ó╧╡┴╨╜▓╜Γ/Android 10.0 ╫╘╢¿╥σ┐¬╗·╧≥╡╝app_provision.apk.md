






在系统首次开机的时候系统源码中有个开机向导app就是Provision.apk,只是没有参与编译，所以就没有  
 开机向导的功能，接下来就来研究下 怎么自定义来适合我们自己的开机向导


Provision.apk 位于package/app/下 原生的代码非常简单 就只有一个DefaultActivity。  
 首选来看下它的AndroidMenifest.xml文件


![在这里插入图片描述](https://img-blog.csdnimg.cn/80a5d17628aa43208decdb7775d38b30.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBA5a6J5Y2T5YW86IGMZnJhbWV3b3Jr5bqU55So5bel56iL5biI,size_12,color_FFFFFF,t_70,g_se,x_16#pic_center)


发现SETUP\_WIZARD就是开机向导的关键词，区别其他lanuch的地方


而在DefaultActivity.java 中  
 setProvision()中的  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/5577d274de4746fb88fd880a4efad972.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBA5a6J5Y2T5YW86IGMZnJhbWV3b3Jr5bqU55So5bel56iL5biI,size_13,color_FFFFFF,t_70,g_se,x_16#pic_center)


可以看出在最后一步的时候 调用setProvision()来结束掉app 从而进入launch 中  
 所以在自定义开机向导的UI的时候，当到最后一个页面点击最后一步的时候  
 调用 该方法 就可以了 然后开机重启后就直接进入launcher了，在恢复出厂设置  
 后会再次进入开机向导 整个功能就算这样完成了





