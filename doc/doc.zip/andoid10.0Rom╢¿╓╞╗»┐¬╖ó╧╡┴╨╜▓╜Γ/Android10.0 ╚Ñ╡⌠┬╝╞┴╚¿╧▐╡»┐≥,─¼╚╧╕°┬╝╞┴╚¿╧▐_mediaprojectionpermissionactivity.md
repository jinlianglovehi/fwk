



## 1.前言


  
  在10.0的系统rom产品定制化开发中，在对系统录屏功能这块也是很重要的，默认在调用MediaProjectionManager的  
 录屏接口时，会弹窗录屏弹窗需要系统手动授予录屏权限，然后才可以录屏，接下来就来去掉录屏弹窗授权功能，  
 然后直接录屏


## 2.去掉录屏权限弹框,默认给录屏权限的核心类



```
frameworks/base/media/java/android/media/projection/MediaProjectionManager.java
frameworks/base/packages/SystemUI/src/com/android/systemui/media/MediaProjectionPermissionActivity.java
```

## 3.去掉录屏权限弹框,默认给录屏权限的核心功能分析和实现 3.1 MediaProjectionManager.java关于启动录屏流程的相关代码分析


  
 在app中的录屏功能中，可以通过MediaProjectionManager来获取录屏管理类，然后启动MediaProjectionPermissionActivity,  
 且当改Activity结束时得到Intent,最终调用mProjectionManager.createScreenCaptureIntent()  
 来启动录屏功能，所有接下来分析下mProjectionManager.createScreenCaptureIntent()的相关源码



```
MediaProjectionManager mProjectionManager =(MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
 startActivityForResult(mProjectionManager.createScreenCaptureIntent(), REQUEST_CODE);

/**
* Returns an Intent that must be passed to startActivityForResult()
* in order to start screen capture. The activity will prompt
* the user whether to allow screen capture.  The result of this
* activity should be passed to getMediaProjection.
*/
public Intent createScreenCaptureIntent() {
        Intent i = new Intent();
        final ComponentName mediaProjectionPermissionDialogComponent =
                ComponentName.unflattenFromString(
                        mContext.getResources().getString(
                        com.android.internal.R.string
                        .config_mediaProjectionPermissionDialogComponent));
        i.setComponent(mediaProjectionPermissionDialogComponent);
        return i;
}
    <!-- Component name of media projection permission dialog -->
     <string name="config_mediaProjectionPermissionDialogComponent" translatable="false">com.android.systemui/com.android.systemui.media.MediaProjectionPermissionActivity</string>
```

通过在MediaProjectionManager.java中的上述源码中，可以看出，在mProjectionManager.createScreenCaptureIntent()  
 中来启动录屏功能的时候，其实是调用启动的是  
 com.android.systemui/com.android.systemui.media.MediaProjectionPermissionActivity  
 这个类，接下来主要实现录屏权限的授权就是在MediaProjectionPermissionActivity中进行的  
 接下来分析下MediaProjectionPermissionActivity中关于授予录屏权限的相关方法


## 3.2 MediaProjectionPermissionActivity.java中关于录屏弹窗授权的相关功能分析



```
public class MediaProjectionPermissionActivity extends Activity
        implements DialogInterface.OnClickListener, DialogInterface.OnCancelListener {
 
    private String mPackageName;
    private int mUid;
    private IMediaProjectionManager mService;
 
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
 
        mPackageName = getCallingPackage();
        IBinder b = ServiceManager.getService(MEDIA_PROJECTION_SERVICE);
        mService = IMediaProjectionManager.Stub.asInterface(b);
 
        PackageManager packageManager = getPackageManager();
        ApplicationInfo aInfo;
        try {
            aInfo = packageManager.getApplicationInfo(mPackageName, 0);
            mUid = aInfo.uid;
        }
 
        try { //mUid, mPackageName已经有Permis
            if (mService.hasProjectionPermission(mUid, mPackageName)) {
                setResult(RESULT_OK, getMediaProjectionIntent(mUid, mPackageName));
                finish();
                return;
            }
        }
 
    @Override
    public void onClick(DialogInterface dialog, int which) {
        try {
            if (which == AlertDialog.BUTTON_POSITIVE) {
                setResult(RESULT_OK, getMediaProjectionIntent(mUid, mPackageName));
            }
        }
    }
    
    // 重点是 获得IMediaProjection, 然后转换为Binder: 赋值到Intent
    // MediaProjectionManager.EXTRA_MEDIA_PROJECTION: projection.asBinder()
    private Intent getMediaProjectionIntent(int uid, String packageName)
            throws RemoteException {
        IMediaProjection projection = mService.createProjection(uid, packageName,
                 MediaProjectionManager.TYPE_SCREEN_CAPTURE, false /* permanentGrant */);
        Intent intent = new Intent();
        intent.putExtra(MediaProjectionManager.EXTRA_MEDIA_PROJECTION, projection.asBinder());
        return intent;
    }
}
 
4. 这样 onActivityResult的输入参数 Intent 就是上面赋值的Intent
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                startService(com.mtsahakis.mediaprojectiondemo.ScreenCaptureService.getStartIntent(this, resultCode, data));
            }
        }
}
 
public int onStartCommand(Intent intent, int flags, int startId) {
   if (isStartCommand(intent)) {
            Intent data = intent.getParcelableExtra(DATA);
            startProjection(resultCode, data);
    }
}
 
5. 得到MediaProjection
private void startProjection(int resultCode, Intent data) {
        MediaProjectionManager mpManager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mMediaProjection == null) {
            mMediaProjection = mpManager.getMediaProjection(resultCode, data);
    }
}
 
public MediaProjection getMediaProjection(int resultCode, @NonNull Intent resultData) {
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            return null;
        }
        IBinder projection = resultData.getIBinderExtra(EXTRA_MEDIA_PROJECTION);
        if (projection == null) {
            return null;
        }
        return new MediaProjection(mContext, IMediaProjection.Stub.asInterface(projection));
}

```

在MediaProjectionPermissionActivity.java上述的方法中，可以看出上述源码中，在点击  
 授权按钮后，调用onClick(DialogInterface dialog, int which)来调用setResult(RESULT\_OK, getMediaProjectionIntent(mUid, mPackageName));  
 来授予录屏权限，所有可以在onCreate(Bundle icicle) 中的  
      try { //mUid, mPackageName已经有Permis  
             if (mService.hasProjectionPermission(mUid, mPackageName)) {  
                 setResult(RESULT\_OK, getMediaProjectionIntent(mUid, mPackageName));  
                 finish();  
                 return;  
             }  
         }  
 中添加定义的为true的变量默认授予默认权限，具体修改如下:  
 +    private boolean mDefaultPermissionGrant = true;  
          try {  
 -            if (mService.hasProjectionPermission(mUid, mPackageName)) {  
 +            if (mService.hasProjectionPermission(mUid, mPackageName) || mDefaultPermissionGrant ) {  
                  setResult(RESULT\_OK, getMediaProjectionIntent(mUid, mPackageName));  
                  finish();  
                  return;


在MediaProjectionPermissionActivity.java中，在onCreate(Bundle icicle) 中通过修改默认的


mService.hasProjectionPermission(mUid, mPackageName) 的授权方法，或者添加默认变量


调用setResult(RESULT\_OK, getMediaProjectionIntent(mUid, mPackageName));执行


录屏的相关功能，实现录屏权限功能



