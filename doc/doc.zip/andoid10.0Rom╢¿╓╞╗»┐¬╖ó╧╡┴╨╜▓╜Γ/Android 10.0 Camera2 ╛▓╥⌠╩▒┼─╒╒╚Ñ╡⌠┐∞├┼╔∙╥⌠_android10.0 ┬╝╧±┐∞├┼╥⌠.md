






### 1.概述


在10.0的系统产品开发中，对于Camera2相机的产品定制化中，发现在Camera2中发现一个问题 当媒体音量静音时，点击拍照还是有拍照声音，产品对这个不满意，所以要修改这个问题，所以针对这个问题就需要看源码来解决了


### 2.Camera2 静音时拍照去掉快门声音的核心类



```
vendor\sprd\platform\packages\apps\DreamCamera2/src/com/android/camera/PhotoModule.java

```

### 3.Camera2 静音时拍照去掉快门声音的核心功能分析和实现


源码路径:  
 vendor\sprd\platform\packages\apps\DreamCamera2  
 展讯的用DreamCamera2代替了Camera2


在Camera2的系统相机源码中，关于拍照的逻辑处理都是在 PhotoModule.java 中处理的  
 这里处理拍照过程中的各种参数回调等等 所以具体看这里的源码分析  
 路径为:  
 vendor\sprd\platform\packages\apps\DreamCamera2/src/com/android/camera/PhotoModule.java  
 拍照源码为:



```
@Override
    public boolean capture() {
        Log.i(TAG, "capture");
        // If we are already in the middle of taking a snapshot or the image
        // save request is full then ignore.
        if (mCameraDevice == null || mCameraState == SNAPSHOT_IN_PROGRESS
                || mCameraState == SWITCHING_CAMERA) {
            return false;
        }
        setCameraState(SNAPSHOT_IN_PROGRESS);

        mCaptureStartTime = System.currentTimeMillis();

        mPostViewPictureCallbackTime = 0;
        mJpegImageData = null;


        /* SPRD: add hide shutter animation after capture when HDR is on
        final boolean animateBefore = (mSceneMode == CameraCapabilities.SceneMode.HDR);
        if (animateBefore) {
            animateAfterShutter();
        }
        */
        updateFilterType();
        /* SPRD: fix bug672841 add for cancel burst when focusing state, burst can not stop*/
        if (!mIsImageCaptureIntent) {
            updateParametersBurstCount();
            mContinuousCaptureCount = getContinuousCount();
        }
        /* @} */
        Location loc = mActivity.getLocationManager().getCurrentLocation();
        Log.i(TAG,"location info:"+loc);
        CameraUtil.setGpsParameters(mCameraSettings, loc);
        boolean isHasEnteredBeauty = mDataModule.getBoolean(Keys.KEY_CAMERA_BEAUTY_ENTERED);
        if (!isHasEnteredBeauty) {
            setParametersHighISO(true);
        }
        /* SPRD:fix bug 823475 clear ae corrdinate before capture when after taf @ */
        if (mFocusManager != null) {
            mFocusManager.updateFocusState();
            setMeteringAreasIfSupported();
        }
        /* @} */
        if(isAutoHdr() && isHdrScene){
            Log.e(TAG,"auto hdr detect scene is hdr so change the scene to hdr");
            mCameraSettings.setSceneMode(CameraCapabilities.SceneMode.HDR);
        }
        if (mSmileCapture) {
            mCameraSettings.setSmileCapture(1);
            mSmileCapture = false;
        }
        mCameraDevice.applySettings(mCameraSettings);

        // Set JPEG orientation. Even if screen UI is locked in portrait, camera
        // orientation should
        // still match device orientation (e.g., users should always get
        // landscape photos while
        // capturing by putting device in landscape.)
        Characteristics info = mActivity.getCameraProvider()
                .getCharacteristics(mCameraId);
        int sensorOrientation = info.getSensorOrientation();
        int deviceOrientation = mAppController.getOrientationManager()
                .getDeviceOrientation().getDegrees();
        boolean isFrontCamera = info.isFacingFront();
        mJpegRotation = CameraUtil.getImageRotation(sensorOrientation,
                deviceOrientation, isFrontCamera);
        Log.i(TAG, " sensorOrientation = " + sensorOrientation
                + " ,deviceOrientation = " + deviceOrientation
                + " isFrontCamera = " + isFrontCamera);
        mCameraDevice.setJpegOrientation(mJpegRotation);
        Log.i(TAG, "takePicture start!");
        isHdrPicture = isAutoHdr() && isHdrScene;
        if (mReceiver != null) {
            //mActivity.unregisterReceiver(mReceiver);
            mActivity.unRegisterMediaBroadcastReceiver();
            mReceiver = null;
        }

        mIsHdrPicture = true;
        mIsFirstCallback = true;
        mFirstHasStartCapture = false;
        mIsNormalHdrDone = false;//SPRD:fix bug784774
        doCaptureSpecial();
        mCameraDevice.takePicture(mHandler,
        /**
         * SPRD: fix bug462021 remove capture animation
         * 
         * @{ new ShutterCallback(!animateBefore),
         */
        new ShutterCallback(CameraUtil.isCaptureAnimatationEnable() && !isBurstCapture() && !isAudioCapture() &&!isCameraFrontFacing()),//SPRD:fix bug1154938/1137366/1162992/1201491
        /**
         * @}
         */
        mRawPictureCallback, mPostViewPictureCallback, new JpegPictureCallback(loc));

        /**
         * SPRD: fix bug 473462 add for burst capture
         * mNamedImages.nameNewImage(mCaptureStartTime);
         */

        mFaceDetectionStarted = false;
        return true;
    }

```

从PhotoModule.java 中的capture()的源码中可以看出  
 在调用拍照方法中 通过ShutterCallback来回调JpegPictureCallback进行拍照回调



```
new ShutterCallback(CameraUtil.isCaptureAnimatationEnable() && !isBurstCapture() && !isAudioCapture() &&!isCameraFrontFacing()),//SPRD:fix bug1154938/1137366/1162992/1201491
        /**
         * @}
         */
        mRawPictureCallback, mPostViewPictureCallback, new JpegPictureCallback(loc));

```

注册了JpegPictureCallback 拍照后的回调具体处理是在JpegPictureCallback中  
 所以具体要看JpegPictureCallback的拍照处理


接下来看这个回调



```
private final class JpegPictureCallback implements CameraPictureCallback {
        Location mLocation;

        public JpegPictureCallback(Location loc) {
            mLocation = loc;
            mHasCaptureCount = 0;
            //mTotalCaputureCount = 0;
        }

        private void judgePlaySoundAndShutterAgain(final byte[] data) {
            // split this method for CCN optimization , Bug 839474
            Log.e(TAG,"judgePlaySoundAndShutterAgain isNeedPlaySound = " + isNeedPlaySound());
            if (isNeedPlaySound()) {
                if (mCameraSound != null) {
                    mCameraSound.play(MediaActionSound.SHUTTER_CLICK);
                }
            }
            /*
             * Add For Dream Camera in IntervalPhotoModule/ContinuePhotoModule
             *
             * @{
             */
            if (!shutterAgain() && !isAlgorithmProcessOnApp) {
                if(!mBurstNotShowShutterButton && !getServices().getMediaSaver().isQueueFull() && !mIsImageCaptureIntent && getModuleTpye()!=DreamModule.AUDIOPICTURE_MODULE) {
                    mAppController.setShutterEnabled(true);
                }
                /* dream test 50 @{ */
                doSomethingWhenonPictureTaken(data); // for dream camera if it want to do something
            }
            /* @} */
        }

        private boolean needReturnFromPictureTaken() {
            // split this method for CCN optimization , Bug 839474
            if (mPaused && (mIsFirstCallback || !isNeedThumbCallBack()))
                return true;
            return false;
        }


        private void procNamedImages() {
            // split this method for CCN optimization , Bug 839474
            if (mNamedImages == null) {
                mNamedImages = new NamedImages();
            }
            if (isNeedThumbCallBack() && !mIsFirstCallback && mIsNeedUpdatThumb) {
                mNamedImages.nameNewImageLarge(mCaptureStartTime);
            } else {
                mNamedImages.nameNewImage(mCaptureStartTime);
            }
        }


```

在JpegPictureCallback  
 在这个回调中 发下judgePlaySoundAndShutterAgain(final byte[] data) 处理有关拍照声音的事件  
 接下来看下judgePlaySoundAndShutterAgain(final byte[] data)的事件处理



```
 private void judgePlaySoundAndShutterAgain(final byte[] data) {
            // split this method for CCN optimization , Bug 839474
            Log.e(TAG,"judgePlaySoundAndShutterAgain isNeedPlaySound = " + isNeedPlaySound());
            if (isNeedPlaySound()) {
                if (mCameraSound != null) {
                    mCameraSound.play(MediaActionSound.SHUTTER_CLICK);
                }
            }

```

在judgePlaySoundAndShutterAgain来通过isNeedPlaySound() 是否需要播放快照声音



```
protected boolean isNeedPlaySound() {
    if(mAppController.isPlaySoundEnable() && ( mIsFirstCallback || inBurstMode())) {
        return true;
    }
    return false;
}

```

通过上面方法测试发现 当媒体音量为0时 同样返回true


所以修改为：



```
protected boolean isNeedPlaySound() {
   + AudioManager mAudioManager = (AudioManager)mAppController.getAndroidContext().getSystemService(mAppController.getAndroidContext().AUDIO_SERVICE);
  +	int mAudioStream = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
   +  if(mAppController.isPlaySoundEnable() && ( mIsFirstCallback || inBurstMode()) && mAudioStream!=0) {
   -   if(mAppController.isPlaySoundEnable() && ( mIsFirstCallback || inBurstMode()) ) {
        return true;
    }
    return false;
}

```

编译验证发现问题解决了





