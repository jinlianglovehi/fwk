



## 1.前言


在10.0的系统产品开发中，在系统关于低电量关机的值，每个平台都不同，根据实际开发底层硬件的要求看实际情况来调整这个值，  
 所以需要分析相关的电量变化执行的代码流程，来实现这个功能


## 2.系统framework修改低电量关机值为2%的核心类



```
frameworks\base\services\core\java\com\android\server\BatteryService.java
```

## 3.系统framework修改低电量关机值为2%的核心功能分析和实现


BatteryService 作为电池及充电相关的服务: 监听 Uevent、读取sysfs 里中的状态 、广播Intent.ACTION\_BATTERY\_CHANGED。  
 BatteryService实现了一个UevenObserver mUEventObserver。uevent是Linux 内核用来向用户空间主动上报事件的机制,  
 对于JAVA程序来说,只实现 UEventObserver的虚函数 onUEvent,然后注册即可。  
 BatteryService只关注 power\_supply 的事件，主要是通过在驱动层上报的电池相关的信息处理，同时对于电量的变化，也同样  
 在BatteryService.java中处理，在电量过低 电池发烫等等事件处理  
 关于电池的信息，电压，温度，充电状态等等这些信息，都是由BatteryService来提供的。  
 BatteryService是跑在system\_process当中，在系统初始化的时候启动  
 BatteryService通过JNI（com\_android\_server\_BatteryService.cpp）读取相关的数据，然后做出相关处理  
 接下来分析下BatteryService中关于电量变化的相关源码分析


## 3.1 BatteryService中关于电量变化的相关源码分析



```
    private final class HealthHalCallback extends IHealthInfoCallback.Stub
            implements HealthServiceWrapper.Callback {
        @Override public void healthInfoChanged(android.hardware.health.V2_0.HealthInfo props) {
            BatteryService.this.update(props);
        }

    private void update(android.hardware.health.V2_0.HealthInfo info) {
        traceBegin("HealthInfoUpdate");

        Trace.traceCounter(Trace.TRACE_TAG_POWER, "BatteryChargeCounter",
                info.legacy.batteryChargeCounter);
        Trace.traceCounter(Trace.TRACE_TAG_POWER, "BatteryCurrent",
                info.legacy.batteryCurrent);

        synchronized (mLock) {
            mRealBatteryLevel = info.legacy.batteryLevel;
            if (!mUpdatesStopped) {
                mHealthInfo = info.legacy;
                // Process the new values.
                processValuesLocked(false);
                mLock.notifyAll(); // for any waiters on new info
            } else {
                copy(mLastHealthInfo, info.legacy);
            }
        }
        traceEnd();
    }
```

在上述的BatteryService中相关源码中分析得知，在  
 BatteryService 收到底层HealthHal callback 通过发送广播来通知监听电量的继承。然后通过  
 healthInfoChanged(android.hardware.health.V2\_0.HealthInfo props) 来传递监听到的电池变化的相关  
 数据，最终在update(android.hardware.health.V2\_0.HealthInfo info) 中处理电池的相关数据，在这个  
 update(android.hardware.health.V2\_0.HealthInfo info) 中最核心的还是在processValuesLocked(false);  
 处理相关数据值,接下来分析下processValuesLocked(boolean force)的相关源码



```
   private void processValuesLocked(boolean force) {
        boolean logOutlier = false;
        long dischargeDuration = 0;

        mBatteryLevelCritical =
            mHealthInfo.batteryStatus != BatteryManager.BATTERY_STATUS_UNKNOWN
            && mHealthInfo.batteryLevel <= mCriticalBatteryLevel;
        if (mHealthInfo.chargerAcOnline) {
            mPlugType = BatteryManager.BATTERY_PLUGGED_AC;
        } else if (mHealthInfo.chargerUsbOnline) {
            mPlugType = BatteryManager.BATTERY_PLUGGED_USB;
        } else if (mHealthInfo.chargerWirelessOnline) {
            mPlugType = BatteryManager.BATTERY_PLUGGED_WIRELESS;
        } else {
            mPlugType = BATTERY_PLUGGED_NONE;
        }

        if (DEBUG) {
            Slog.d(TAG, "Processing new values: "
                    + "info=" + mHealthInfo
                    + ", mBatteryLevelCritical=" + mBatteryLevelCritical
                    + ", mPlugType=" + mPlugType);
        }

        // Let the battery stats keep track of the current level.
        try {
            mBatteryStats.setBatteryState(mHealthInfo.batteryStatus, mHealthInfo.batteryHealth,
                    mPlugType, mHealthInfo.batteryLevel, mHealthInfo.batteryTemperature,
                    mHealthInfo.batteryVoltage, mHealthInfo.batteryChargeCounter,
                    mHealthInfo.batteryFullCharge);
        } catch (RemoteException e) {
            // Should never happen.
        }

        shutdownIfNoPowerLocked();
        shutdownIfOverTempLocked();
        if (force || (mHealthInfo.batteryStatus != mLastBatteryStatus ||
                mHealthInfo.batteryHealth != mLastBatteryHealth ||
                mHealthInfo.batteryPresent != mLastBatteryPresent ||
                mHealthInfo.batteryLevel != mLastBatteryLevel ||
                mPlugType != mLastPlugType ||
                mHealthInfo.batteryVoltage != mLastBatteryVoltage ||
                mHealthInfo.batteryTemperature != mLastBatteryTemperature ||
                mHealthInfo.maxChargingCurrent != mLastMaxChargingCurrent ||
                mHealthInfo.maxChargingVoltage != mLastMaxChargingVoltage ||
                mHealthInfo.batteryChargeCounter != mLastChargeCounter ||
                mInvalidCharger != mLastInvalidCharger)) {

            if (mPlugType != mLastPlugType) {
                if (mLastPlugType == BATTERY_PLUGGED_NONE) {
                    // discharging -> charging
                    mChargeStartLevel = mHealthInfo.batteryLevel;
                    mChargeStartTime = SystemClock.elapsedRealtime();

                    final LogMaker builder = new LogMaker(MetricsEvent.ACTION_CHARGE);
                    builder.setType(MetricsEvent.TYPE_ACTION);
                    builder.addTaggedData(MetricsEvent.FIELD_PLUG_TYPE, mPlugType);
                    builder.addTaggedData(MetricsEvent.FIELD_BATTERY_LEVEL_START,
                            mHealthInfo.batteryLevel);
                    mMetricsLogger.write(builder);

...
}

  private void shutdownIfNoPowerLocked() {
        // shut down gracefully if our battery is critically low and we are not powered.
        // wait until the system has booted before attempting to display the shutdown dialog.
        if (shouldShutdownLocked()) {
            /*SPRD : add power debug log start*/
            Slog.d(TAG, "Low battery shutdown, batteryLevel : " + mHealthInfo.batteryLevel);
            /*SPRD : add power debug log end*/
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mActivityManagerInternal.isSystemReady()) {
                        Intent intent = new Intent(Intent.ACTION_REQUEST_SHUTDOWN);
                        intent.putExtra(Intent.EXTRA_KEY_CONFIRM, false);
                        intent.putExtra(Intent.EXTRA_REASON,
                                PowerManager.SHUTDOWN_LOW_BATTERY);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        mContext.startActivityAsUser(intent, UserHandle.CURRENT);
                    }
                }
            });
        }
    }

   private boolean shouldShutdownLocked() {
        if (mHealthInfo.batteryLevel > 0) {
            return false;
        }

        // Battery-less devices should not shutdown.
        if (!mHealthInfo.batteryPresent) {
            return false;
        }

        // add for bug#1021541
        boolean checkPlugState = (mUpdatesStopped && mHealthInfo.batteryLevel == mSetBatteryLevel
                && mSetBatteryLevel != mRealBatteryLevel);
        if (DEBUG) Slog.d(TAG, "shutdownIfNoPowerLocked: mUpdatesStopped: " + mUpdatesStopped
                + " mHealthInfo.batteryLevel:"  + mHealthInfo.batteryLevel
                + " mSetBatteryLevel:" + mSetBatteryLevel + " mRealBatteryLevel:" + mRealBatteryLevel);

        // If battery state is not CHARGING, shutdown.
        // - If battery present and state == unknown, this is an unexpected error state.
        // - If level <= 0 and state == full, this is also an unexpected state
        // - All other states (NOT_CHARGING, DISCHARGING) means it is not charging.
        return !checkPlugState || mHealthInfo.batteryStatus != BatteryManager.BATTERY_STATUS_CHARGING;
    }
```

在上述的BatteryService中相关源码中分析得知，在processValuesLocked(boolean force)中处理关于  
 电量BatteryService 收到底层的电池数据后，在这里处理，而在processValuesLocked(boolean force)中  
 可以调用        shutdownIfNoPowerLocked();来判断当前电量是否过低然后执行关机等相关流程，而在  
         shutdownIfOverTempLocked();中会判断当前电池的电量是否过高，然后执行相关的动作，所以  
 在这里需要具体分析下shutdownIfNoPowerLocked();中的相关源码，而在shutdownIfNoPowerLocked();中，  
 可以看到判断条件是否满足shouldShutdownLocked()，如果满足关机条件就执行Intent.ACTION\_REQUEST\_SHUTDOWN  
 来执行关机的相关指令来实现关机的功能，所以这里就需要判断当前电量是否低于2%，然后就返回true就可以了  
 接下来具体实现功能如下:



```
  private boolean shouldShutdownLocked() {
//add core start
        if (mHealthInfo.batteryLevel <= 2) {
            return true;
        }

//add core end
        if (mHealthInfo.batteryLevel > 0) {
            return false;
        }

        // Battery-less devices should not shutdown.
        if (!mHealthInfo.batteryPresent) {
            return false;
        }

        // add for bug#1021541
        boolean checkPlugState = (mUpdatesStopped && mHealthInfo.batteryLevel == mSetBatteryLevel
                && mSetBatteryLevel != mRealBatteryLevel);
        if (DEBUG) Slog.d(TAG, "shutdownIfNoPowerLocked: mUpdatesStopped: " + mUpdatesStopped
                + " mHealthInfo.batteryLevel:"  + mHealthInfo.batteryLevel
                + " mSetBatteryLevel:" + mSetBatteryLevel + " mRealBatteryLevel:" + mRealBatteryLevel);

        // If battery state is not CHARGING, shutdown.
        // - If battery present and state == unknown, this is an unexpected error state.
        // - If level <= 0 and state == full, this is also an unexpected state
        // - All other states (NOT_CHARGING, DISCHARGING) means it is not charging.
        return !checkPlugState || mHealthInfo.batteryStatus != BatteryManager.BATTERY_STATUS_CHARGING;
    }
```

在上述的BatteryService中相关源码中分析得知，在shutdownIfNoPowerLocked();中，  
 可以看到判断条件是否满足shouldShutdownLocked()，如果满足关机条件就执行Intent.ACTION\_REQUEST\_SHUTDOWN  
 来执行关机的相关指令来实现关机的功能,所以在上述的shouldShutdownLocked()方法中，添加  
 mHealthInfo.batteryLevel <= 2添加判断，当低于2%的时候就返回true,这样就实现了低电量低于2%的时候就关机的功能，



