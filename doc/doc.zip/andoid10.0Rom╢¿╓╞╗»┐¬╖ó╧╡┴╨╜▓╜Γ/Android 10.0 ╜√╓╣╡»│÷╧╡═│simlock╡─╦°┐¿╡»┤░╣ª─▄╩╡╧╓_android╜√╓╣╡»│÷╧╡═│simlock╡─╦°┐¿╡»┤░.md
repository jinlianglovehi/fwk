



## 1.前言


  
   在10.0的系统开发中，在一款产品中，需要实现simlock锁卡功能，在系统实现锁卡功能以后，在开机的过程中，或者是在插入sim卡  
 后，当系统检测到是禁用的sim卡后，就会弹出simlock锁卡弹窗，要求输入puk 解锁密码，功能需求禁用这个弹窗，所以就需要看是  
 哪里弹的，禁用不弹窗就好  
 如图:


![](https://img-blog.csdnimg.cn/6ed37bf6fa634ea8b67ffab4c9fab090.png)


## 2.禁止弹出系统simlock的锁卡弹窗功能实现的核心类



```
frameworks\base\packages\SystemUI\src\com\android\systemui\keyguard\KeyguardViewMediator.java
```

## 3.禁止弹出系统simlock的锁卡弹窗功能实现的核心功能分析和实现


锁卡即SIMLock,当手机开机启动或者插入SIM卡时，手机modem侧预置在NV项中的配置信息会与SIM卡中的信息做比对，检测是否匹配。若匹配，  
 则SIM卡可以正常使用。若不匹配，则SIM卡相关功能均无法正常使用，例如拨打电话、发送短信及上网等；或者是只能注册2G网，  
 不能注册4G


Android系统的KEYGUARD模块的相关类提供了屏幕锁屏等相关功能，虽然功能简单，但是相关的逻辑还是挺复杂的，要处理屏幕处于不同状态的情况，  
 要监控各种事件（时间，电池，Sim状态，电话状态）然后处理好对应的相关事件


Android窗口系统机制之KEYGUARD机制Android窗口系统机制之KEYGUARD机制  
 PhoneWindowManager、PowerManager、KeyguardViewMediator、KeyguardUpdateMonitor、KeyguardViewManager、  
 KeyguardViewHost、LockPatternKeyguardView、KeyguardScreen相关类之间构成中介模式，KeyguardViewMediator对象  
 处于模式的核心，起到中介者的角色，其它对象都通过KeyguardViewMediator对象相互交互。


KeyguardViewMediator对象是PhoneWindowManager成员，因此PhoneWindowManage可以直接访问KeyguardViewMediator  
 对象。KeyguardViewMediator也通过PowerManager服务创建了三个不计数WakeLock锁实现与PowerManager服务的通讯，  
 达到锁屏操作时电源状态管理的目的（mWakeLock锁用于保证在 keyguard显示时能够显示一段时间后屏幕才能睡眠；  
 mShowKeyguardWakeLock用于在 keyguard显示要打开时能够保持设备唤醒；mWakeAndHandOff由  
 PhoneWindowManager截获事件进行触发，用于在用户按键或鼠标移动时唤醒设备便于对keyguard进行操作）。  
 KeyguardUpdateMonitor、KeyguardViewManager对象作为KeyguardViewMediator对象的成员又都是由  
 KeyguardViewMediator实例化的，KeyguardViewMediator可以直接操作KeyguardUpdateMonitor、  
 KeyguardViewManager对象。所以说其中主要的锁屏处理都是在KeyguardViewMediator.java中进行的  
 相关处理



```
  KeyguardUpdateMonitorCallback mUpdateCallback = new KeyguardUpdateMonitorCallback() {

        @Override
        public void onUserSwitching(int userId) {
            // Note that the mLockPatternUtils user has already been updated from setCurrentUser.
            // We need to force a reset of the views, since lockNow (called by
            // ActivityManagerService) will not reconstruct the keyguard if it is already showing.
            synchronized (KeyguardViewMediator.this) {
                resetKeyguardDonePendingLocked();
                if (mLockPatternUtils.isLockScreenDisabled(userId)) {
                    // If we switching to a user that has keyguard disabled, dismiss keyguard.
                    dismiss(null /* callback */, null /* message */);
                } else {
                    resetStateLocked();
                }
                adjustStatusBarLocked();
            }
        }

        @Override
        public void onUserSwitchComplete(int userId) {
            if (userId != UserHandle.USER_SYSTEM) {
                UserInfo info = UserManager.get(mContext).getUserInfo(userId);
                // Don't try to dismiss if the user has Pin/Patter/Password set
                if (info == null || mLockPatternUtils.isSecure(userId)) {
                    return;
                } else if (info.isGuest() || info.isDemo()) {
                    // If we just switched to a guest, try to dismiss keyguard.
                    dismiss(null /* callback */, null /* message */);
                }
            }
        }

        @Override
        public void onSimStateChanged(int subId, int slotId, IccCardConstants.State simState) {

            if (DEBUG_SIM_STATES) {
                Log.d(TAG, "onSimStateChanged(subId=" + subId + ", slotId=" + slotId
                        + ",state=" + simState + ")");
            }

            int size = mKeyguardStateCallbacks.size();
            boolean simPinSecure = mUpdateMonitor.isSimPinSecure();
            for (int i = size - 1; i >= 0; i--) {
                try {
                    mKeyguardStateCallbacks.get(i).onSimSecureStateChanged(simPinSecure);
                } catch (RemoteException e) {
                    Slog.w(TAG, "Failed to call onSimSecureStateChanged", e);
                    if (e instanceof DeadObjectException) {
                        mKeyguardStateCallbacks.remove(i);
                    }
                }
            }

            boolean simWasLocked;
            synchronized (KeyguardViewMediator.this) {
                IccCardConstants.State lastState = mLastSimStates.get(slotId);
                simWasLocked = (lastState == PIN_REQUIRED || lastState == PUK_REQUIRED);
                mLastSimStates.append(slotId, simState);
            }

            switch (simState) {
                case NOT_READY:
                case ABSENT:
                    // only force lock screen in case of missing sim if user hasn't
                    // gone through setup wizard
                    synchronized (KeyguardViewMediator.this) {
                        if (shouldWaitForProvisioning()) {
                            if (!mShowing) {
                                if (DEBUG_SIM_STATES) Log.d(TAG, "ICC_ABSENT isn't showing,"
                                        + " we need to show the keyguard since the "
                                        + "device isn't provisioned yet.");
                                doKeyguardLocked(null);
                            } else {
                                resetStateLocked();
                            }
                        }
                        if (simState == ABSENT) {
                            // MVNO SIMs can become transiently NOT_READY when switching networks,
                            // so we should only lock when they are ABSENT.
                            if (simWasLocked) {
                                if (DEBUG_SIM_STATES) Log.d(TAG, "SIM moved to ABSENT when the "
                                        + "previous state was locked. Reset the state.");
                                resetStateLocked();
                            }
                        }
                    }
                    break;
/*                case PIN_REQUIRED:
                case PUK_REQUIRED:
                    synchronized (KeyguardViewMediator.this) {
                        if (!mShowing) {
                            if (DEBUG_SIM_STATES) Log.d(TAG,
                                    "INTENT_VALUE_ICC_LOCKED and keygaurd isn't "
                                    + "showing; need to show keyguard so user can enter sim pin");
                            doKeyguardLocked(null);
                        } else {
                            resetStateLocked();
                        }
                    }
                    break;*/
                    /* Unisoc: Support SimLock @{ */
//                case NETWORK_LOCKED:
                case NETWORK_SUBSET_LOCKED:
                case SERVICE_PROVIDER_LOCKED:
                case CORPORATE_LOCKED:
//                case SIM_LOCKED:
                case NETWORK_LOCKED_PUK:
                case NETWORK_SUBSET_LOCKED_PUK:
                case SERVICE_PROVIDER_LOCKED_PUK:
                case CORPORATE_LOCKED_PUK:
//                case SIM_LOCKED_PUK:
                    /* @} */
                    boolean hideSimLockView = mContext.getResources().getBoolean(com.android.internal.R.bool.simlock_hide_unlock_view);
                    Log.d(TAG, "hideSimLockView = " + hideSimLockView);
                    if (hideSimLockView) {
                        break;
                    }
                    synchronized (KeyguardViewMediator.this) {
                        if (!mShowing) {
                            if (DEBUG_SIM_STATES) Log.d(TAG,
                                    "INTENT_VALUE_ICC_LOCKED and keygaurd isn't "
                                    + "showing; need to show keyguard so user can enter simlock pin");
                            doKeyguardLocked(null);
                        } else {
                            resetStateLocked();
                        }
                    }
                    break;
                case PERM_DISABLED:
                    synchronized (KeyguardViewMediator.this) {
                        if (!mShowing) {
                            if (DEBUG_SIM_STATES) Log.d(TAG, "PERM_DISABLED and "
                                  + "keygaurd isn't showing.");
                            doKeyguardLocked(null);
                        } else {
                            if (DEBUG_SIM_STATES) Log.d(TAG, "PERM_DISABLED, resetStateLocked to"
                                  + "show permanently disabled message in lockscreen.");
                            resetStateLocked();
                        }
                    }
                    break;
                case READY:
                    synchronized (KeyguardViewMediator.this) {
                        if (DEBUG_SIM_STATES) Log.d(TAG, "READY, reset state? " + mShowing);
                        if (mShowing && simWasLocked) {
                            if (DEBUG_SIM_STATES) Log.d(TAG, "SIM moved to READY when the "
                                    + "previous state was locked. Reset the state.");
                            resetStateLocked();
                        }
                    }
                    break;
                default:
                    if (DEBUG_SIM_STATES) Log.v(TAG, "Unspecific state: " + simState);
                    break;
            }
        }

        /* Unisoc: Support SimLock @{ */
        @Override
        public void onShowSimLockByNv() {
            Log.d(TAG, "---- onShowSimLockByNv");
            synchronized (this) {
                if (!mShowing) {
                    if (DEBUG_SIM_STATES) Log.d(TAG,
                            "onShowSimLockByNv and keygaurd isn't "
                            + "showing; need to show keyguard so user can enter unlock");
                    doKeyguardLocked(null);
                } else {
                    resetStateLocked();
                }
            }
        };
        @Override
        public void onShowSimLockBySim() {
            Log.d(TAG, "---- onShowSimLockBySim");
            synchronized (this) {
               if (!mShowing) {
                    if (DEBUG_SIM_STATES) Log.d(TAG,
                            "onShowSimLockBySim and keygaurd isn't "
                            + "showing; need to show keyguard so user can enter unlock");
                    doKeyguardLocked(null);
                } else {
                    resetStateLocked();
                }
            }
        };

        @Override
        public void onShowSimLockForOperator() {
            Log.d(TAG, "---- onShowSimLockForOperator");
            synchronized (this) {
               if (!mShowing) {
                    if (DEBUG_SIM_STATES) Log.d(TAG,
                            "onShowSimLockForOperator and keygaurd isn't "
                            + "showing; need to show keyguard so user can enter unlock");
                    doKeyguardLocked(null);
                } else {
                    resetStateLocked();
                }
            }
        }
```

在上述的KeyguardViewMediator.java中的核心代码中，其中KeyguardUpdateMonitor是典型的观察者模式的应用，而KeyguardUpdateMonitorCallback这个子类。  
 KeyguardUpdateMonitorCallback是一个类，不是接口，也不是抽象类，来具体处理响应各种锁屏事件，指纹锁，simlock锁等等  
 所以在上述的方法中，在onSimStateChanged(int subId, int slotId, IccCardConstants.State simState)中，就是主要处理关于  
 simlock锁卡的主要功能，在锁卡功能实现后，在首次开机会检测当前的sim卡是否是允许使用的卡，不是使用的卡就弹窗要求输入  
 解锁密码，就会在switch (simState) 中根据simlock的类型 来弹出对应的类型，所以  
 会根据SIM\_LOCKED\_PUK SIM\_LOCKED NETWORK\_LOCKED PIN\_REQUIRED SIM\_LOCKED\_PUK等等来弹出不同类型的  
 锁卡弹窗，所以就可以在这里检测不同锁卡类型注释掉对应的处理锁卡类型，来实现功能  
 在通过上述的修改以后 就可以实现在禁止处理关于simlock锁卡弹窗的相关功能，就不会需要弹窗输入解锁卡的密码来解锁了  
 实现真正的解锁功能




