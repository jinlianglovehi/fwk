






由于客户需求要求去掉开机 设备正在启动 的提示框，避免顾客认为加载慢的问题，所以根据客户需求来实现功能


在 AMS的startHomeActivityLocked(currentUserId, “systemReady”);被调用，从名字既可以看得出他是要启动Home类型的Activtiy，常见的Launcher就是一种Home类型的Activity，但这里其实并不是Launcher，而是设置中的FallbackHome类型的，它也是一个Home类型的Activity，这里FallbackHome是google新加入的，主要就是因为涉及整个android系统的加密等原因，系统在还没有完全解锁前，不可以启动Launcher  
 android7.0之后，引入了directboot模式，系统启动后，开机动画走完，是先走到了Settings下一个FallbackHome.java 的activity，这个里边再去引出真正的Launcher


接下来看FallbackHome.java的源码  
 路径为:packages/apps/Settings/src/com/android/settings/FallbackHome.java



```
/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.settings;

import android.app.Activity;
import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.app.WallpaperManager.OnColorsChangedListener;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager.LayoutParams;
import android.view.animation.AnimationUtils;

import java.util.Objects;

public class FallbackHome extends Activity {
    private static final String TAG = "FallbackHome";
    private static final int PROGRESS_TIMEOUT = 2000;

    private boolean mProvisioned;
    private WallpaperManager mWallManager;

    private final Runnable mProgressTimeoutRunnable = () -> {
        View v = getLayoutInflater().inflate(
                R.layout.fallback_home_finishing_boot, null /* root */);
        setContentView(v);
        v.setAlpha(0f);
        v.animate()
                .alpha(1f)
                .setDuration(500)
                .setInterpolator(AnimationUtils.loadInterpolator(
                        this, android.R.interpolator.fast_out_slow_in))
                .start();
        getWindow().addFlags(LayoutParams.FLAG_KEEP_SCREEN_ON);
    };

    private final OnColorsChangedListener mColorsChangedListener = new OnColorsChangedListener() {
        @Override
        public void onColorsChanged(WallpaperColors colors, int which) {
            if (colors != null) {
                final View decorView = getWindow().getDecorView();
                decorView.setSystemUiVisibility(
                        updateVisibilityFlagsFromColors(colors, decorView.getSystemUiVisibility()));
                mWallManager.removeOnColorsChangedListener(this);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set ourselves totally black before the device is provisioned so that
        // we don't flash the wallpaper before SUW
 mProvisioned = Settings.Global.getInt(getContentResolver(),
 Settings.Global.DEVICE\_PROVISIONED, 0) != 0;
 final int flags;
 if (!mProvisioned) {
 setTheme(R.style.FallbackHome\_SetupWizard);
 flags = View.SYSTEM\_UI\_FLAG\_FULLSCREEN | View.SYSTEM\_UI\_FLAG\_HIDE\_NAVIGATION
 | View.SYSTEM\_UI\_FLAG\_IMMERSIVE\_STICKY;
 } else {
 flags = View.SYSTEM\_UI\_FLAG\_LAYOUT\_FULLSCREEN
 | View.SYSTEM\_UI\_FLAG\_LAYOUT\_HIDE\_NAVIGATION;
 }

 mWallManager = getSystemService(WallpaperManager.class);
 if (mWallManager == null) {
 Log.w(TAG, "Wallpaper manager isn't ready, can't listen to color changes!");
 } else {
 loadWallpaperColors(flags);
 }
 getWindow().getDecorView().setSystemUiVisibility(flags);

 registerReceiver(mReceiver, new IntentFilter(Intent.ACTION\_USER\_UNLOCKED));
 maybeFinish();
 }

 @Override
 protected void onResume() {
 super.onResume();
 if (mProvisioned) {
 mHandler.postDelayed(mProgressTimeoutRunnable, PROGRESS\_TIMEOUT);
 }
 }

 @Override
 protected void onPause() {
 super.onPause();
 mHandler.removeCallbacks(mProgressTimeoutRunnable);
 }

 protected void onDestroy() {
 super.onDestroy();
 unregisterReceiver(mReceiver);
 if (mWallManager != null) {
 mWallManager.removeOnColorsChangedListener(mColorsChangedListener);
 }
 }

 private BroadcastReceiver mReceiver = new BroadcastReceiver() {
 @Override
 public void onReceive(Context context, Intent intent) {
 maybeFinish();
 }
 };

 private void loadWallpaperColors(int flags) {
 final AsyncTask loadWallpaperColorsTask = new AsyncTask<Object, Void, Integer>() {
 @Override
 protected Integer doInBackground(Object... params) {
 final WallpaperColors colors =
 mWallManager.getWallpaperColors(WallpaperManager.FLAG\_SYSTEM);

 // Use a listener to wait for colors if not ready yet.
 if (colors == null) {
 mWallManager.addOnColorsChangedListener(mColorsChangedListener,
 null /\* handler \*/);
 return null;
 }
 return updateVisibilityFlagsFromColors(colors, flags);
 }

 @Override
 protected void onPostExecute(Integer flagsToUpdate) {
 if (flagsToUpdate == null) {
 return;
 }
 getWindow().getDecorView().setSystemUiVisibility(flagsToUpdate);
 }
 };
 loadWallpaperColorsTask.execute();
 }

 private void maybeFinish() {
 if (getSystemService(UserManager.class).isUserUnlocked()) {
 final Intent homeIntent = new Intent(Intent.ACTION\_MAIN)
 .addCategory(Intent.CATEGORY\_HOME);
 final ResolveInfo homeInfo = getPackageManager().resolveActivity(homeIntent, 0);
 if (Objects.equals(getPackageName(), homeInfo.activityInfo.packageName)) {
 if (UserManager.isSplitSystemUser()
 && UserHandle.myUserId() == UserHandle.USER\_SYSTEM) {
 // This avoids the situation where the system user has no home activity after
 // SUW and this activity continues to throw out warnings. See b/28870689.
 return;
 }
 Log.d(TAG, "User unlocked but no home; let's hope someone enables one soon?");
 mHandler.sendEmptyMessageDelayed(0, 500);
 } else {
 Log.d(TAG, "User unlocked and real home found; let's go!");
                getSystemService(PowerManager.class).userActivity(
                        SystemClock.uptimeMillis(), false);
                finish();
            }
        }
    }

    // Set the system ui flags to light status bar if the wallpaper supports dark text to match
    // current system ui color tints.
    private int updateVisibilityFlagsFromColors(WallpaperColors colors, int flags) {
        if ((colors.getColorHints() & WallpaperColors.HINT\_SUPPORTS\_DARK\_TEXT) != 0) {
 return flags | View.SYSTEM\_UI\_FLAG\_LIGHT\_STATUS\_BAR
 | View.SYSTEM\_UI\_FLAG\_LIGHT\_NAVIGATION\_BAR;
 }
 return flags & ~(View.SYSTEM\_UI\_FLAG\_LIGHT\_STATUS\_BAR)
 & ~(View.SYSTEM\_UI\_FLAG\_LIGHT\_NAVIGATION\_BAR);
 }

 private Handler mHandler = new Handler() {
 @Override
 public void handleMessage(Message msg) {
 maybeFinish();
 }
 };

 /\* UNISOC:1186856 Settings crashed in monkey test @{ \*/
 @Override
 public boolean dispatchKeyEvent(KeyEvent event) {
 switch (event.getKeyCode()) {
             case KeyEvent.KEYCODE_SEARCH:
                 return true;
             default:
                 break;
        }
        return super.dispatchKeyEvent(event);
    }
    /* @} */
}

```

在 onResume 方法中 调用



```
mHandler.postDelayed(mProgressTimeoutRunnable, PROGRESS_TIMEOUT);

```

而mProgressTimeoutRunnable 来设置显示弹窗的内容


接下来看fallback\_home\_finishing\_boot.xml的内容



```
<FrameLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:background="#80000000"
    android:forceHasOverlappingRendering="false">

    <LinearLayout
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:orientation="vertical"
        android:layout_gravity="center"
        android:layout_marginStart="16dp"
        android:layout_marginEnd="16dp">

        <TextView
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:textSize="20sp"
            android:textColor="?android:attr/textColorPrimary"
            android:text="@\*android:string/android\_start\_title"/>

        <ProgressBar
            style="@android:style/Widget.Material.ProgressBar.Horizontal"
            android:layout_width="match\_parent"
            android:layout_height="wrap\_content"
            android:layout_marginTop="12.75dp"
            android:colorControlActivated="?android:attr/textColorPrimary"
            android:indeterminate="true"/>

    </LinearLayout>
</FrameLayout>

```

android:text=“@\*android:string/android\_start\_title” 就是 android is starting 的提示语


所以去掉提示框 就需要这样修改:



```
 private final Runnable mProgressTimeoutRunnable = () -> {
        //View v = getLayoutInflater().inflate(
        //        R.layout.fallback_home_finishing_boot, null /* root */);
        /*setContentView(v);
        v.setAlpha(0f);
        v.animate()
                .alpha(1f)
                .setDuration(500)
                .setInterpolator(AnimationUtils.loadInterpolator(
                        this, android.R.interpolator.fast_out_slow_in))
                .start();
        getWindow().addFlags(LayoutParams.FLAG_KEEP_SCREEN_ON);*/
    };

```

在mProgressTimeoutRunnable 中注释掉view 加载就可以了





