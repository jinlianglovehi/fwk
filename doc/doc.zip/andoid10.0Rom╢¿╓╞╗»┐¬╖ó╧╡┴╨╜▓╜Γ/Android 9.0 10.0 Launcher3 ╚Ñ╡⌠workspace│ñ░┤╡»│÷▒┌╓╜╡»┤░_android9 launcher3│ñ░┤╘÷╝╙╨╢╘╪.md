






### 1.概述


在10.0的系统产品开发中，在Launcher3开发中，由于要默认一些设置 不让用户修改，这时候就需要 去掉长按弹窗功能了,workspace.java的长按处理事件就是 WorkspaceTouchListene.java


### 2.Launcher3 去掉workspace长按弹出壁纸弹窗的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/Workspace.java
packages/apps/Launcher3/src/com/android/launcher3/touch/WorkspaceTouchListener.java

```

### 3.Launcher3 去掉workspace长按弹出壁纸弹窗的核心功能分析和实现


在Launcher3中，对于每个屏幕绑定数据都是在workspace.java 负责处理的,长按事件也可以从这里分析相关的源码


### 3.1workspace.java 源码关于长按事件的处理



```
   /**
   * The workspace is a wide area with a wallpaper and a finite number of pages.
   * Each page contains a number of icons, folders or widgets the user can
   * interact with. A workspace is meant to be used with a fixed width only.
   */
  public class Workspace extends PagedView<WorkspacePageIndicator>
          implements DropTarget, DragSource, View.OnTouchListener,
          DragController.DragListener, Insettable, LauncherStateManager.StateHandler,
          WorkspaceLayoutManager {
      /**
       * Used to inflate the Workspace from XML.
       *
       * @param context The application's context.
 \* @param attrs The attributes set containing the Workspace's customization values.
       */
      public Workspace(Context context, AttributeSet attrs) {
          this(context, attrs, 0);
      }
  
      /**
       * Used to inflate the Workspace from XML.
       *
       * @param context The application's context.
 \* @param attrs The attributes set containing the Workspace's customization values.
       * @param defStyle Unused.
       */
public Workspace(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);

    mLauncher = Launcher.getLauncher(context);
    mStateTransitionAnimation = new WorkspaceStateTransitionAnimation(mLauncher, this);
    mWallpaperManager = WallpaperManager.getInstance(context);

    mWallpaperOffset = new WallpaperOffsetInterpolator(this);
    mOverviewModeShrinkFactor =
            70 / 100f;

    setHapticFeedbackEnabled(false);
    initWorkspace();

    // Disable multitouch across the workspace/all apps/customize tray
    setMotionEventSplittingEnabled(true);
    setOnTouchListener(new WorkspaceTouchListener(mLauncher, this));
}

```

在Workspace的构造方法中可以看出  
 setOnTouchListener(new WorkspaceTouchListener(mLauncher, this));  
 这行注册监听Touch事件了


### 3.2接下来看 WorkspaceTouchListener.java 关于长按事件分析


在onTouch事件就是对屏幕的监听事件接下来看下这里面的源码



```
@Override
    public boolean onTouch(View view, MotionEvent ev) {
        mGestureDetector.onTouchEvent(ev);

        int action = ev.getActionMasked();
        if (action == ACTION_DOWN) {
            // Check if we can handle long press.
            boolean handleLongPress = canHandleLongPress();

            if (handleLongPress) {
                // Check if the event is not near the edges
                DeviceProfile dp = mLauncher.getDeviceProfile();
                DragLayer dl = mLauncher.getDragLayer();
                Rect insets = dp.getInsets();

                mTempRect.set(insets.left, insets.top, dl.getWidth() - insets.right,
                        dl.getHeight() - insets.bottom);
                mTempRect.inset(dp.edgeMarginPx, dp.edgeMarginPx);
                handleLongPress = mTempRect.contains((int) ev.getX(), (int) ev.getY());
            }

            if (handleLongPress) {
                mLongPressState = STATE_REQUESTED;
                mTouchDownPoint.set(ev.getX(), ev.getY());
            }

            mWorkspace.onTouchEvent(ev);
            // Return true to keep receiving touch events
            return true;
        }

        if (mLongPressState == STATE_PENDING_PARENT_INFORM) {
            // Inform the workspace to cancel touch handling
            ev.setAction(ACTION_CANCEL);
            mWorkspace.onTouchEvent(ev);

            ev.setAction(action);
            mLongPressState = STATE_COMPLETED;
        }

        final boolean result;
        if (mLongPressState == STATE_COMPLETED) {
            // We have handled the touch, so workspace does not need to know anything anymore.
            result = true;
        } else if (mLongPressState == STATE_REQUESTED) {
            mWorkspace.onTouchEvent(ev);
            if (mWorkspace.isHandlingTouch()) {
                cancelLongPress();
            } else if (action == ACTION_MOVE && PointF.length(
                    mTouchDownPoint.x - ev.getX(), mTouchDownPoint.y - ev.getY()) > mTouchSlop) {
                cancelLongPress();
            }

            result = true;
        } else {
            // We don't want to handle touch, let workspace handle it as usual.
            result = false;
        }

        if (action == ACTION_UP || action == ACTION_POINTER_UP) {
            if (!mWorkspace.isHandlingTouch()) {
                final CellLayout currentPage =
                        (CellLayout) mWorkspace.getChildAt(mWorkspace.getCurrentPage());
                if (currentPage != null) {
                    mWorkspace.onWallpaperTap(ev);
                }
            }
        }

        if (action == ACTION_UP || action == ACTION_CANCEL) {
            cancelLongPress();
        }

        return result;
    }

```

在WorkspaceTouchListener中的相关源码分析得知  
 从touch事件中可以看到 canHandleLongPress 就是判断是否是长按事件的  
 接下来看下 onLongPress(MotionEvent event)如何分析是否是长按事件的



```
@Override
public void onLongPress(MotionEvent event) {
    if (mLongPressState == STATE_REQUESTED) {
        if (canHandleLongPress()) {
            mLongPressState = STATE_PENDING_PARENT_INFORM;
            mWorkspace.getParent().requestDisallowInterceptTouchEvent(true);

            mWorkspace.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
            mLauncher.getUserEventDispatcher().logActionOnContainer(Action.Touch.LONGPRESS,
                    Action.Direction.NONE, ContainerType.WORKSPACE,
                    mWorkspace.getCurrentPage());
            OptionsPopupView.showDefaultOptions(mLauncher, mTouchDownPoint.x, mTouchDownPoint.y);
        } else {
            cancelLongPress();
        }
    }
}

```

onLongPress 就是处理长按事件的而  
 从代码中看出  
 OptionsPopupView.showDefaultOptions(mLauncher, mTouchDownPoint.x, mTouchDownPoint.y);  
 就是负责处理长按弹窗


所以去掉弹窗 注释掉这段代码就行修改如下



```
@Override
public void onLongPress(MotionEvent event) {
    if (mLongPressState == STATE_REQUESTED) {
        if (canHandleLongPress()) {
            mLongPressState = STATE_PENDING_PARENT_INFORM;
            mWorkspace.getParent().requestDisallowInterceptTouchEvent(true);

            mWorkspace.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
            mLauncher.getUserEventDispatcher().logActionOnContainer(Action.Touch.LONGPRESS,
                    Action.Direction.NONE, ContainerType.WORKSPACE,
                    mWorkspace.getCurrentPage());
          -  OptionsPopupView.showDefaultOptions(mLauncher, mTouchDownPoint.x, mTouchDownPoint.y);
        } else {
            cancelLongPress();
        }
    }
}

```

经过上面的修改实现了相关的功能





