






在定制化开发手机项目中,如果专门适配老年机的时候，这时客户提出要求，如果最后一屏未满时，不让拖拽到后面一屏的空屏中  
 这样就需要获取当前是哪一屏，并且要知道当前有多少个Item，总共一屏最多多少个item


所以就需要从Workspace.java入手


首选来看源码 开始拖拽时会调用startDrag()



```
public void startDrag(CellLayout.CellInfo cellInfo, DragOptions options) {
    View child = cellInfo.cell;
    mDragInfo = cellInfo;
    child.setVisibility(INVISIBLE);
    if (options.isAccessibleDrag) {
        mDragController.addDragListener(new AccessibleDragListenerAdapter(
                this, CellLayout.WORKSPACE_ACCESSIBILITY_DRAG) {
            @Override
            protected void enableAccessibleDrag(boolean enable) {
                super.enableAccessibleDrag(enable);
                setEnableForLayout(mLauncher.getHotseat(),enable);
            }
        });
    }

    beginDragShared(child, this, options);
}

```

所以要首选看CellInfo这个内部类：



```
public static final class CellInfo extends CellAndSpan {
    public final View cell;
    final int screenId;
    public final int container;

    public CellInfo(View v, ItemInfo info) {
        cellX = info.cellX;
        cellY = info.cellY;
        spanX = info.spanX;
        spanY = info.spanY;
        cell = v;
        screenId = info.screenId;
        container = info.container;
    }

    @Override
    public String toString() {
        return "Cell[view=" + (cell == null ? "null" : cell.getClass())
                + ", x=" + cellX + ", y=" + cellY + "]";
    }
}

```

从源码中可以看出 刚好有screenId这个变量 就代表当前是哪一屏


继续看CellLayout.java源码



```
public int getCountX() {
    return mCountX;
}

public int getCountY() {
    return mCountY;
}

```

发现getCountX代表有多少行 getCountY()有多少列  
 所以最多每一屏就是getCountX()\*getCountY();


而当前屏有多少个Item  
 就是mShortcutsAndWidgets.getChildCount();


所以CellLayout.java增加个方法



```
  public int childCount(){
		if(mShortcutsAndWidgets==null)return 0;
		return mShortcutsAndWidgets.getChildCount();
	}

```

所以最终修改为：



```
+ private int mCurScrrenId=-1,mCurChildCount=-1;
public void startDrag(CellLayout.CellInfo cellInfo, DragOptions options) {
    View child = cellInfo.cell;
    mDragInfo = cellInfo;
    child.setVisibility(INVISIBLE);

    // add code start 
   mCurScrrenId = cellInfo.screenId;
	CellLayout mSourceCellLayout = mWorkspaceScreens.valueAt(mCurScrrenId);
	mCurChildCount = mSourceCellLayout.childCount();
	if(mSourceCellLayout!=null)Log.e("Launcher3","source--countx:"+mSourceCellLayout.getCountX()+"--county:"+mSourceCellLayout.getCountY()+"---childcount:"+mCurChildCount+"mCurScrrenId:"+mCurScrrenId);
  // add code end

    if (options.isAccessibleDrag) {
        mDragController.addDragListener(new AccessibleDragListenerAdapter(
                this, CellLayout.WORKSPACE_ACCESSIBILITY_DRAG) {
            @Override
            protected void enableAccessibleDrag(boolean enable) {
                super.enableAccessibleDrag(enable);
                setEnableForLayout(mLauncher.getHotseat(),enable);
            }
        });
    }

    beginDragShared(child, this, options);
}

```

经过编译验证拖拽时当前屏和Item个数都是一样的





