






在做rom 定制化开发的时候，由于有些客户在设备上安装了微信，然后用微信视频通话 发现视频画面上下颠倒 ，针对这个问题所以就要查询原因  
 看是哪里出了问题


在视频通话中会用到Camera,而Camera的CameraInfo参数  
 CAMERA\_FACING\_BACK  
 Added in API level 9


int CAMERA\_FACING\_BACK


相机的朝向与屏幕的朝向相反。


常量值：0（0x00000000）  
 CAMERA\_FACING\_FRONT  
 Added in API level 9


int CAMERA\_FACING\_FRONT


相机的面朝与屏幕相同。


常数值：1（0x00000001）


facing  
 Added in API level 9


int facing  
 相机朝向的方向。 它应该是CAMERA\_FACING\_BACK或CAMERA\_FACING\_FRONT。  
 orientation  
 Added in API level 9


int orientation  
 相机图像的方向。 该值是摄像机图像需要顺时针旋转的角度，以便以正确的方向正确显示在显示器上。 它应该是0,90,180或270。  
 例如，假设设备有一个自然高大的屏幕。 背面照相机传感器安装在横向上。 你正在看屏幕。 如果相机传感器的顶部与自然方向的屏幕右边缘对齐，则该值应为90.如果前置摄像头传感器的顶部与屏幕右边对齐，则值应为270。


orientation就是旋转的角度  
 所以可以从Camera 获取参数的时候 旋转相机角度


在Camera.java中修改  
 路径:frameworks/base/core/java/android/hardware/Camera.java



```
/**
* Returns the information about a particular camera.
* If {@link #getNumberOfCameras()} returns N, the valid id is 0 to N-1.
*
* @throws RuntimeException if an invalid ID is provided, or if there is an
*    error retrieving the information (generally due to a hardware or other
*    low-level failure).
*/
public static void getCameraInfo(int cameraId, CameraInfo cameraInfo) {
// SPRD: decouple code, change private to protected
checkCameraId(cameraId);
_getCameraInfo(cameraId, cameraInfo);

//add code start
if(ActivityThread.currentActivityThread().currentOpPackageName().contains("com.tencent.mm")){
cameraInfo.orientation = (cameraInfo.orientation+180)%360;
}
//add code end

IBinder b = ServiceManager.getService(Context.AUDIO_SERVICE);
IAudioService audioService = IAudioService.Stub.asInterface(b);
try {
if (audioService == null){
Log.w(TAG,"Unable to find IAudioService interface.");
}else if (audioService.isCameraSoundForced()){
// Only set this when sound is forced; otherwise let native code
// decide.
cameraInfo.canDisableShutterSound = false;
}
} catch (RemoteException e) {
Log.e(TAG, "Audio service is unavailable for queries");
}
}

```

\*\*


### 2.需要确保在使用camer2相机的时候 前后摄像头拍照视频正常，然后在打开下拉状态栏屏幕旋转按钮试着调sensor方向


\*\*



```
--- a/alps/frameworks/base/core/java/android/view/OrientationEventListener.java
+++ b/alps/frameworks/base/core/java/android/view/OrientationEventListener.java
@@ -22,7 +22,7 @@ import android.hardware.SensorEvent;
 import android.hardware.SensorEventListener;
 import android.hardware.SensorManager;
 import android.util.Log;
-
+import android.app.ActivityThread;
 /**
  * Helper class for receiving notifications from the SensorManager when
  * the orientation of the device has changed.
@@ -140,6 +140,12 @@ public abstract class OrientationEventListener {
             }
             if (orientation != mOrientation) {
                 mOrientation = orientation;
+                //add xx for QQ video call reverse 90 degrees 
+                if(ActivityThread.currentOpPackageName().equalsIgnoreCase("com.tencent.mm")){
+                    orientation=orientation+180;
+                }
+                //add xx for QQ video call reverse 90 degrees 
                 onOrientationChanged(orientation);
             }
         }

```

这是个难点，每个平台不同，如果硬件摄像头预览方向和屏幕方向相同就好调，但是在横屏状态下


摄像头预览方向和屏幕方向不同就不好调，关键是如果能调整底层摄像头预览方向就好办一点





