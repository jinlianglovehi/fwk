






在定制化开关中，内置app到系统中，也是在开发种，常用的工作任务，那么怎么样内置呢  
 其实也简单，拷贝app到package/app下 建立文件夹 放入app 配置好Android.mk  
 最后把文件夹名称 添加到编译的devices下参与编译的系统的device.mk文件 就可以了


LOCAL\_CERTIFICATE := PRESIGNED表示APK签名使用原来签名，即第三方签名，若要使用系统签名，则可以改为LOCAL\_CERTIFICATE := platform系统前面，可以使apk获得系统权限


如果想要内置app 可以通过运行安装调试的化，属性就要设置成为LOCAL\_CERTIFICATE := PRESIGNED


所以具体修改如下:



```
--- a/packages/apps/HangLauncher/Android.mk

+++ b/packages/apps/HangLauncher/Android.mk

@@ -6,7 +6,7 @@ LOCAL_MODULE_TAGS := optional

 LOCAL_BUILT_MODULE_STEM := package.apk

 LOCAL_MODULE_SUFFIX := $(COMMON\_ANDROID\_PACKAGE\_SUFFIX)

 #LOCAL\_PRIVILEGED\_MODULE :=

-LOCAL_CERTIFICATE := platform

+LOCAL_CERTIFICATE := PRESIGNED

 #LOCAL\_OVERRIDES\_PACKAGES :=

 LOCAL_SRC_FILES := $(LOCAL\_MODULE).apk

 #LOCAL\_REQUIRED\_MODULES :=

```




