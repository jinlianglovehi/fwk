






### 1.概述


在10.0的系统产品定制化开发中，对SystemUI 中下拉状态栏中的通知栏定制化要求，对于原生通知栏的通知  
 都是方角背景，而产品想要改成圆角背景，所以需要针对下拉状态栏中的通知栏每条Notification做ui的圆角背景，  
 首选看NotificationRow长按时，弹出的背景布局就是NotificationGuts，接下来就对NotificationGuts做背景圆角布局修改


### 2.修改NotificationGuts为圆角背景的核心类



```
frameworks/base/packages/SystemUI/res/layout/notification_info.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationGuts.java

```

### 3.修改NotificationGuts为圆角背景核心功能分析和实现


在NotificationRow的createInfoItem(Context context)发现通知布局是notification\_info.xml



```
static NotificationMenuItem createInfoItem(Context context) {
         Resources res = context.getResources();
         String infoDescription = res.getString(R.string.notification_menu_gear_description);
         NotificationInfo infoContent = (NotificationInfo) LayoutInflater.from(context).inflate(
                 R.layout.notification_info, null, false);
         return new NotificationMenuItem(context, infoDescription, infoContent,
                 R.drawable.ic_settings);
     }

```

通过阅读源码发现布局为  
 notification\_info.xml  
 接下来看下notification\_info.xml布局文件



```
--- a/frameworks/base/packages/SystemUI/res/layout/notification_info.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/notification_info.xml
@@ -25,7 +25,7 @@
    <com.android.systemui.statusbar.notification.row.NotificationInfo
     xmlns:android="http://schemas.android.com/apk/res/android"
     android:id="@+id/notification\_guts"
     android:layout_width="match\_parent"
     android:layout_height="wrap\_content"
     android:clickable="true"
     android:clipChildren="false"
     android:clipToPadding="true"
     android:orientation="vertical"
-    android:background="@color/notification\_guts\_bg\_color">
+    android:background="@drawable/qs\_background\_primary">
 
     <!-- Package Info -->
     <RelativeLayout
         android:id="@+id/header"
         android:layout_width="match\_parent"
         android:layout_height="wrap\_content"
         android:clipChildren="false"
         android:clipToPadding="false">
         <ImageView
             android:id="@+id/pkgicon"
             android:layout_width="@dimen/notification\_guts\_header\_height"
             android:layout_height="@dimen/notification\_guts\_header\_height"
             android:layout_centerVertical="true"
             android:layout_alignParentStart="true"
             android:layout_marginEnd="3dp" />
         <TextView
             android:id="@+id/pkgname"
             android:layout_width="wrap\_content"
             android:layout_height="wrap\_content"
             android:layout_centerVertical="true"
             style="@style/TextAppearance.NotificationImportanceHeader"
             android:layout_marginStart="3dp"
             android:layout_marginEnd="2dp"
             android:layout_toEndOf="@id/pkgicon"
             android:singleLine="true" />
         <TextView
             android:id="@+id/pkg\_divider"
             android:layout_width="wrap\_content"
             android:layout_height="wrap\_content"
             android:layout_centerVertical="true"
             style="@style/TextAppearance.NotificationImportanceHeader"
             android:layout_marginStart="2dp"
             android:layout_marginEnd="2dp"
             android:layout_toEndOf="@id/pkgname"
             android:text="@\*android:string/notification\_header\_divider\_symbol" />
         <TextView
             android:id="@+id/delegate\_name"
             android:layout_width="wrap\_content"
             android:layout_height="wrap\_content"
             android:layout_centerVertical="true"
             style="@style/TextAppearance.NotificationImportanceHeader"
             android:layout_marginStart="2dp"
             android:layout_marginEnd="2dp"
             android:ellipsize="end"
             android:text="@string/notification\_delegate\_header"
             android:layout_toEndOf="@id/pkg\_divider"
             android:maxLines="1" />

```

所以要给每个通知添加圆角背景如下  
 qs\_background\_primary.xml



```
<inset xmlns:android="http://schemas.android.com/apk/res/android">
    <shape>
        <solid android:color="#ffffff"/>
        <corners android:radius="20dp" />
    </shape>
</inset>

```

在notification\_info.xml中添加qs\_background\_primary.xml为默认背景，每条通知就会是圆角布局


接下来对NotificationGuts.java中的背景也改成圆角背景



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationGuts.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/NotificationGuts.java
@@ -173,7 +173,7 @@ public class NotificationGuts extends FrameLayout {
 public class NotificationGuts extends FrameLayout {
     private static final String TAG = "NotificationGuts";
public NotificationGuts(Context context, AttributeSet attrs) {
          super(context, attrs);
          setWillNotDraw(false);
          mHandler = new Handler();
          mFalsingCheck = new Runnable() {
              @Override
              public void run() {
                  if (mNeedsFalsingProtection && mExposed) {
                      closeControls(-1 /* x */, -1 /* y */, false /* save */, false /* force */);
                  }
              }
          };
          final TypedArray ta = context.obtainStyledAttributes(attrs,
                  com.android.internal.R.styleable.Theme, 0, 0);
          ta.recycle();
      }
  
      public NotificationGuts(Context context) {
          this(context, null);
      }
  
      public void setGutsContent(GutsContent content) {
          mGutsContent = content;
          removeAllViews();
          addView(mGutsContent.getContentView());
      }
   @Override
      protected void onDraw(Canvas canvas) {
          draw(canvas, mBackground);
      }
  
      private void draw(Canvas canvas, Drawable drawable) {
          int top = mClipTopAmount;
          int bottom = mActualHeight - mClipBottomAmount;
          if (drawable != null && top < bottom) {
              drawable.setBounds(0, top, getWidth(), bottom);
              drawable.draw(canvas);
          }
      }
  
     @Override
     protected void onFinishInflate() {
         super.onFinishInflate();
-        mBackground = mContext.getDrawable(R.drawable.notification_guts_bg);
+        mBackground = mContext.getDrawable(R.drawable.qs_background_primary);
         if (mBackground != null) {
             mBackground.setCallback(this);
         }

```

在NotificationGuts类中onFinishInflate()的mBackground就是设置当前默认背景所以设置成qs\_background\_primary就是默认圆角背景  
 这样就把NotificationGuts改为圆角背景





