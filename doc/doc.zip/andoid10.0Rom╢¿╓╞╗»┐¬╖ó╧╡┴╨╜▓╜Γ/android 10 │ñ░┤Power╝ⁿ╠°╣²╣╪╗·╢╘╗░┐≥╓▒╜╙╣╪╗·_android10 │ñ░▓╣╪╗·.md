






首选对Power键弹出关机Dialog框GlobalActions解析  
 长按电源键弹出的对话框  
 在frameworks\base\policy\src\com\android\internal\policy\impl\GlobalActions.java文件中  
 所有的action事件都是在这处理的


分析下GlobalActionsDialog的源码  
 当PMS收到长按电源键的时候，就会showDialog 弹出关机对话框



```
/**
     * Show the global actions dialog (creating if necessary)
     *
     * @param keyguardShowing True if keyguard is showing
     */
    public void showDialog(boolean keyguardShowing, boolean isDeviceProvisioned,
            GlobalActionsPanelPlugin panelPlugin) {
        mKeyguardShowing = keyguardShowing;
        mDeviceProvisioned = isDeviceProvisioned;
        mPanelPlugin = panelPlugin;
        if (mDialog != null) {
            mDialog.dismiss();
            mDialog = null;
            // Show delayed, so that the dismiss of the previous dialog completes
            mHandler.sendEmptyMessage(MESSAGE_SHOW);
        } else {
            handleShow();
        }
    }

```

从上面的源码可以看出 当mDialog!=null时 发出MESSAGE\_SHOW事件  
 当mDialog==null时 会handleShow(); 弹出关机对话框


所以解决方案如下:


1. handleshow() 换成关机命令
2. MESSAGE\_SHOW 也换成关机命令即可:


实现案例如下:  
 在长按关机键时会弹出窗口界面让我们选择相应的操作，如何跳过直接关机，其实就是在GlobalActionsDialog.java修改，在弹出界面的地方 直接调用关机方法就可以了



```
a/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
+++ b/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
@@ -242,7 +242,8 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
             // Show delayed, so that the dismiss of the previous dialog completes
             mHandler.sendEmptyMessage(MESSAGE_SHOW);
         } else {
-            handleShow();
+            //handleShow();
+           mWindowManagerFuncs.shutdown();
         }
     }
 
@@ -1470,7 +1471,8 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
                     mAdapter.notifyDataSetChanged();
                     break;
                 case MESSAGE_SHOW:
-                    handleShow();
+                    //handleShow();
+                    mWindowManagerFuncs.shutdown();
                     break;
             }
         }

```




