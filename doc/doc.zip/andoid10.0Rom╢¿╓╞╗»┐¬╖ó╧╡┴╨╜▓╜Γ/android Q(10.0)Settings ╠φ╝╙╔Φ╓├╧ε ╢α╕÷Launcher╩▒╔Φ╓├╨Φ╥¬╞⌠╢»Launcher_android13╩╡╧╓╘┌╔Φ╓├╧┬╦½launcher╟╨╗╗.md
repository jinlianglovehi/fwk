






### 1.概述


在10.0的系统产品开发中，最近产品有需求，要求在系统设置中，当多个launcher时,选择自己需要启动launcher，然后设置为默认Launcher的功能实现


### 2.Settings 添加设置项 多个Launcher时设置需要启动Launcher的核心类



```
packages/apps/TvSettings/Settings/src/com/android/tv/settings/DefaultLauncherFragment.java

```

### 3.Settings 添加设置项 多个Launcher时设置需要启动Launcher的核心功能分析和实现


TvSettings中增加设置默认Launcher的实现思路:  
 1.获取系统中所有launcher,然后RadioPreference动态显示出来  
 2.设置所选launcher作为启动launcher


### 3.1TvSettings中添加设置默认Launcher的具体实现案例:



```
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v7.preference.Preference;
import android.support.v7.preference.PreferenceScreen;
import android.text.TextUtils;
import android.util.Log;
import android.provider.Settings;
import com.android.internal.logging.nano.MetricsProto;
import com.android.tv.settings.R;
import com.android.tv.settings.RadioPreference;
import com.android.tv.settings.SettingsPreferenceFragment;

import java.util.Iterator;
import java.util.List;

/**
 * The location settings screen in TV settings.
 */
public class DefaultLauncherFragment extends SettingsPreferenceFragment {

    private static final String TAG = "DefaultLauncherFragment";

    private PackageManager packageManger;

    public static DefaultLauncherFragment newInstance() {
        return new DefaultLauncherFragment();
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        Log.e(TAG, "onCreatePreferences");
        final Context themedContext = getPreferenceManager().getContext();
        final PreferenceScreen screen = getPreferenceManager().createPreferenceScreen(themedContext);
        screen.setTitle(R.string.default_launcher);

        packageManger = getActivity().getPackageManager();
        PackageManager pm = packageManger;
        List<ResolveInfo> packageInfos = getResolveInfoList();
        ResolveInfo currentRI = getCurrentLauncher();

        Iterator<ResolveInfo> it = packageInfos.iterator();
        while (it.hasNext()) {
            ResolveInfo ri = it.next();
            if (ri != null && ri.activityInfo.applicationInfo.isDirectBootAware()) {
                it.remove();
            }
        }

        if (packageInfos != null && packageInfos.size() > 0) {
            Preference activePref = null;
            //动态添加RadioPreference
            for (ResolveInfo resolveInfo : packageInfos) {
                final RadioPreference radioPreference = new RadioPreference(themedContext);
                radioPreference.setKey(resolveInfo.activityInfo.packageName);
                radioPreference.setPersistent(false);
                radioPreference.setTitle(resolveInfo.loadLabel(pm).toString());
                radioPreference.setIcon(resolveInfo.loadIcon(pm));
                radioPreference.setLayoutResource(R.layout.preference_reversed_widget);

                if (!TextUtils.isEmpty(currentRI.activityInfo.packageName)
                        && !TextUtils.isEmpty(resolveInfo.activityInfo.packageName)
                        && TextUtils.equals(currentRI.activityInfo.packageName, resolveInfo.activityInfo.packageName)) {
                    radioPreference.setChecked(true);
                    activePref = radioPreference;
                }

                screen.addPreference(radioPreference);
            }
           // 选中当前launcher
            if (activePref != null && savedInstanceState == null) {
                scrollToPreference(activePref);
            }
        }
        setPreferenceScreen(screen);
    }

    @Override
    public boolean onPreferenceTreeClick(Preference preference) {
        Log.e(TAG, "onPreferenceTreeClick");
        if (preference instanceof RadioPreference) {
            final RadioPreference radioPreference = (RadioPreference) preference;
            radioPreference.clearOtherRadioPreferences(getPreferenceScreen());
            if (radioPreference.isChecked()) {
                String packageName = radioPreference.getKey();
                setDefaultLauncher(packageName);
            } else {
                radioPreference.setChecked(true);
            }
        }
        return super.onPreferenceTreeClick(preference);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int getMetricsCategory() {
        return MetricsProto.MetricsEvent.MANAGE_APPLICATIONS;
    }

    private List<ResolveInfo> getResolveInfoList() {
        PackageManager pm = packageManger;
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        return pm.queryIntentActivities(intent, 0);
    }

    private ResolveInfo getCurrentLauncher() {
        PackageManager pm = packageManger;
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        return pm.resolveActivity(intent, 0);
    }

    private void setDefaultLauncher(String packageName) {
        PackageManager pm = packageManger;
        ResolveInfo currentLauncher = getCurrentLauncher();

        List<ResolveInfo> packageInfos = getResolveInfoList();

        ResolveInfo futureLauncher = null;

        for (ResolveInfo ri : packageInfos) {
            if (!TextUtils.isEmpty(ri.activityInfo.packageName) && !TextUtils.isEmpty(packageName)
                    && TextUtils.equals(ri.activityInfo.packageName, packageName)) {
                futureLauncher = ri;
            }
        }
        Settings.Global.putString(getActivity().getContentResolver(),
                   "default\_launcher\_packagename",packageName);
        if (futureLauncher == null) {
            return;
        }

        pm.clearPackagePreferredActivities(currentLauncher.activityInfo.packageName);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_MAIN);
        intentFilter.addCategory(Intent.CATEGORY_HOME);
        intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
        ComponentName componentName = new ComponentName(futureLauncher.activityInfo.packageName,
                futureLauncher.activityInfo.name);
        ComponentName[] componentNames = new ComponentName[packageInfos.size()];
        int defaultMatch = 0;
        for (int i = 0; i < packageInfos.size(); i++) {
            ResolveInfo resolveInfo = packageInfos.get(i);
            componentNames[i] = new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
            if (defaultMatch < resolveInfo.match) {
                defaultMatch = resolveInfo.match;
            }
        }
        pm.clearPackagePreferredActivities(currentLauncher.activityInfo.packageName);
        pm.addPreferredActivity(intentFilter, defaultMatch, componentNames, componentName);
    }

}

```

在DefaultLauncherFragment 的setDefaultLauncher(String packageName)通过调用系统PM的  
 clearPackagePreferredActivities清除当前默认Launcher，然后调用addPreferredActivity设置  
 新的默认Launcher，而达到更换默认Launcher功能的实现


而在DefaultLauncherFragment 的onCreatePreferences方法中  
 通过调用下面



```
        //获取系统中所有的launcher
        List<ResolveInfo> packageInfos = getResolveInfoList();
//当前launcher
        ResolveInfo currentRI = getCurrentLauncher();

        Iterator<ResolveInfo> it = packageInfos.iterator();
        while (it.hasNext()) {
            ResolveInfo ri = it.next();
            if (ri != null && ri.activityInfo.applicationInfo.isDirectBootAware()) {
                it.remove();
            }
        }

```

getResolveInfoList()获取当前Launcher的列表。然后通过RadioPreference 来构建选择Launcher  
 的选项作为默认Launcher从而实现设置默认Launcher的功能





