






在定制化国内平板时，客户要求设置系统默认语言为中文，所以就要修改语言格式  
 其实就是在开机完成后设置系统语言为中文即可：


1.在PhoneWindowManager.java 中  
 路径为：frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java  
 开机完成后会调用systemBooted()  
 所以就在这里修改系统语言也可以



```
/** {@inheritDoc} */
@Override
public void systemBooted() {
    bindKeyguard();
    synchronized (mLock) {
        mSystemBooted = true;
        if (mSystemReady) {
            mKeyguardDelegate.onBootCompleted();
        }
    }
    startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
    finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
    screenTurningOn(null);
    screenTurnedOn();

}

```

系统设置语言的api 位于LocalePicker.java 路径为：frameworks/base/core/java/com/android/internal/app/LocalePicker.java



```
/**
     * Requests the system to update the system locale. Note that the system looks halted
     * for a while during the Locale migration, so the caller need to take care of it.
     *
     * @see #updateLocales(LocaleList)
     */
    @UnsupportedAppUsage
    public static void updateLocale(Locale locale) {
        updateLocales(new LocaleList(locale));
    }

    /**
     * Requests the system to update the list of system locales.
     * Note that the system looks halted for a while during the Locale migration,
     * so the caller need to take care of it.
     */
    @UnsupportedAppUsage
    public static void updateLocales(LocaleList locales) {
        try {
            final IActivityManager am = ActivityManager.getService();
            final Configuration config = am.getConfiguration();

            config.setLocales(locales);
            config.userSetLocale = true;

            am.updatePersistentConfiguration(config);
            // Trigger the dirty bit for the Settings Provider.
            BackupManager.dataChanged("com.android.providers.settings");
        } catch (RemoteException e) {
            // Intentionally left blank
        }
    }

```

从代码中可以看出先创建Configuration对象 ，然后通过AMS的updatePersistentConfiguration来改变系统语言


所以可以直接通过LocalePicker.updateLocale(locale); 来改变系统语言


所以第一种修改方法为：



```
 /** {@inheritDoc} */
    @Override
    public void systemBooted() {
        bindKeyguard();
        synchronized (mLock) {
            mSystemBooted = true;
            if (mSystemReady) {
                mKeyguardDelegate.onBootCompleted();
            }
        }
        startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
        finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
        screenTurningOn(null);
        screenTurnedOn();
       // 添加修改默认语言
       + LocalePicker.updateLocale(Locale.CHINESE);
    }

```

第二种方法 ：


通过反射切换系统语言



```
import java.lang.reflect.Method;
import android.content.res.Configuration;
import android.app.backup.BackupManager;
import java.util.Locale;
import com.android.internal.app.LocalePicker;
public void changeSystemLanguage(String language,String country) {
        //Locale mLocale = new Locale("en", "ZA");
       Locale mLocale = new Locale(language, country);
        try {
            Class iActivityManager = Class.forName("android.app.IActivityManager");
            Class activityManagerNative = Class.forName("android.app.ActivityManagerNative");
            Method getDefault = activityManagerNative.getDeclaredMethod("getDefault");
            Object objIActMag = getDefault.invoke(activityManagerNative);
            Method getConfiguration = iActivityManager.getDeclaredMethod("getConfiguration");
            Configuration config = (Configuration) getConfiguration.invoke(objIActMag);
            config.locale = mLocale;
            Class clzConfig = Class.forName("android.content.res.Configuration");
            java.lang.reflect.Field userSetLocale = clzConfig.getField("userSetLocale");
            userSetLocale.set(config, true);
            Class[] clzParams = {Configuration.class};
            Method updateConfiguration = iActivityManager.getDeclaredMethod("updateConfiguration", clzParams);
            updateConfiguration.invoke(objIActMag, config);
            BackupManager.dataChanged("com.android.providers.settings");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

```

具体修改如下:



```
 /** {@inheritDoc} */
    @Override
    public void systemBooted() {
        bindKeyguard();
        synchronized (mLock) {
            mSystemBooted = true;
            if (mSystemReady) {
                mKeyguardDelegate.onBootCompleted();
            }
        }
        startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
        finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
        screenTurningOn(null);
        screenTurnedOn();
       // 添加修改默认语言
       + changeSystemLanguage("zh", "CN");
    }

```

然后编译services 替换services.jar 发现系统语言修改为中文





