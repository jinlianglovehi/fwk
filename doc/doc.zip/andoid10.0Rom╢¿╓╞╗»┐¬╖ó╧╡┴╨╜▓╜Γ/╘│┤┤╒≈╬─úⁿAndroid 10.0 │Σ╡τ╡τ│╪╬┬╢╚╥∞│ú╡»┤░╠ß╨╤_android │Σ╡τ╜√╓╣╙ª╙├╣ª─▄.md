



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心需求分析](#2.%E6%A0%B8%E5%BF%83%E9%9C%80%E6%B1%82%E5%88%86%E6%9E%90)


[3.核心代码](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[4.BatteryService.java 代码分析](#4.BatteryService.java%20%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 增加全局变量：](#3.1%20%E5%A2%9E%E5%8A%A0%E5%85%A8%E5%B1%80%E5%8F%98%E9%87%8F%EF%BC%9A)


[3.3 frameworks/base 下增加相关资源](#3.3%20frameworks%2Fbase%20%E4%B8%8B%E5%A2%9E%E5%8A%A0%E7%9B%B8%E5%85%B3%E8%B5%84%E6%BA%90)




---


## 1.概述


  在10.0的产品开发中，由于对电池要求高，在充电的时候需要对电池温度做随时监听，温度过高以免引起事故要提醒所以要增加 电池温度异常弹窗功能


## 2.核心需求分析


  电池的信息，电压，温度，充电状态等等，都是由BatteryService来提供的。BatteryService是跑在system\_process当中，在系统初始化的时候启动SystemServer中启动BatteryService 所以就需要从这里入手


## 3.核心代码



```
   frameworks/base/services/core/java/com/android/server/BatteryService.java
```

## 4.BatteryService.java 代码分析


BatteryService定义了3个非常重要的阈值，分别是：


    mCriticalBatteryLevel表示严重低电，其值为4。当电量低于该值时会强制关机。该值由config.xml中的config\_criticalBatteryWarningLevel控制。  
     mLowBatteryWarningLevel表示低电，值为15，当电量低于该值时，系统会报警，例如闪烁LED灯。该值由config.xml中的config\_lowBatteryWarningLevel控制。  
     mLowBatteryCloseWarningLevel表示一旦电量大于此值，就脱离低电状态，即可停止警示灯。该值为20，表示由config.xml中的config\_lowBatteryCloseWarningLevel控制。


在BatteryService构造函数的最后调用了update函数，该函数将查询系统电池信息，以更新BatteryService内部的成员变量  
 当电池信息发生改变时，系统会发送uevent事件给BatteryService，此时BatteryService只要重新调用update即可完成工作。  
 Android电池服务BatteryService,用来监听内核上报的电池事件,并将最新的电池数据上报给系统,系统收到新数据后会去更新电池显示状态、剩余电量等信息




```
 public final class BatteryService extends SystemService {

    private static final String TAG = BatteryService.class.getSimpleName();

  

    public BatteryService(Context context) {
        super(context);

        mContext = context;
        mHandler = new Handler(true /*async*/);
        mLed = new Led(context, getLocalService(LightsManager.class));
        mBatteryStats = BatteryStatsService.getService();
        mActivityManagerInternal = LocalServices.getService(ActivityManagerInternal.class);

        mCriticalBatteryLevel = mContext.getResources().getInteger(
                com.android.internal.R.integer.config_criticalBatteryWarningLevel);
        mLowBatteryWarningLevel = mContext.getResources().getInteger(
                com.android.internal.R.integer.config_lowBatteryWarningLevel);
        mLowBatteryCloseWarningLevel = mLowBatteryWarningLevel + mContext.getResources().getInteger(
                com.android.internal.R.integer.config_lowBatteryCloseWarningBump);
        mShutdownBatteryTemperature = mContext.getResources().getInteger(
                com.android.internal.R.integer.config_shutdownBatteryTemperature);

        mBatteryLevelsEventQueue = new ArrayDeque<>();
        mMetricsLogger = new MetricsLogger();

        // watch for invalid charger messages if the invalid_charger switch exists
        if (new File("/sys/devices/virtual/switch/invalid_charger/state").exists()) {
            UEventObserver invalidChargerObserver = new UEventObserver() {
                @Override
                public void onUEvent(UEvent event) {
                    final int invalidCharger = "1".equals(event.get("SWITCH_STATE")) ? 1 : 0;
                    synchronized (mLock) {
                        if (mInvalidCharger != invalidCharger) {
                            mInvalidCharger = invalidCharger;
                        }
                    }
                }
            };
            invalidChargerObserver.startObserving(
                    "DEVPATH=/devices/virtual/switch/invalid_charger");
        }
    }

    @Override
    public void onStart() {
        registerHealthCallback();

        mBinderService = new BinderService();
        publishBinderService("battery", mBinderService);
        mBatteryPropertiesRegistrar = new BatteryPropertiesRegistrar();
        publishBinderService("batteryproperties", mBatteryPropertiesRegistrar);
        publishLocalService(BatteryManagerInternal.class, new LocalService());
    }


    private void updateBatteryWarningLevelLocked() {
        final ContentResolver resolver = mContext.getContentResolver();
       //获取默认的警告电量值
        int defWarnLevel = mContext.getResources().getInteger(
                com.android.internal.R.integer.config_lowBatteryWarningLevel);
        //获取默认的警告电量值
       mLowBatteryWarningLevel = Settings.Global.getInt(resolver,
                Settings.Global.LOW_POWER_MODE_TRIGGER_LEVEL, defWarnLevel);
        if (mLowBatteryWarningLevel == 0) {
            mLowBatteryWarningLevel = defWarnLevel;
        }
        if (mLowBatteryWarningLevel < mCriticalBatteryLevel) {
            mLowBatteryWarningLevel = mCriticalBatteryLevel;
        }
        //计算出关闭警告的电量值
        mLowBatteryCloseWarningLevel = mLowBatteryWarningLevel + mContext.getResources().getInteger(
                com.android.internal.R.integer.config_lowBatteryCloseWarningBump);
        //调用该方法来真正的更新电池信息
        processValuesLocked(true);
    }

    private boolean isPoweredLocked(int plugTypeSet) {
        // assume we are powered if battery state is unknown so
        // the "stay on while plugged in" option will work.
        if (mHealthInfo.batteryStatus == BatteryManager.BATTERY_STATUS_UNKNOWN) {
            return true;
        }
        if ((plugTypeSet & BatteryManager.BATTERY_PLUGGED_AC) != 0 && mHealthInfo.chargerAcOnline) {
            return true;
        }
        if ((plugTypeSet & BatteryManager.BATTERY_PLUGGED_USB) != 0 && mHealthInfo.chargerUsbOnline) {
            return true;
        }
        if ((plugTypeSet & BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0 && mHealthInfo.chargerWirelessOnline) {
            return true;
        }
        return false;
    }

    private boolean shouldSendBatteryLowLocked() {
        final boolean plugged = mPlugType != BATTERY_PLUGGED_NONE;
        final boolean oldPlugged = mLastPlugType != BATTERY_PLUGGED_NONE;

        /* The ACTION_BATTERY_LOW broadcast is sent in these situations:
         * - is just un-plugged (previously was plugged) and battery level is
         *   less than or equal to WARNING, or
         * - is not plugged and battery level falls to WARNING boundary
         *   (becomes <= mLowBatteryWarningLevel).
         */
        return !plugged
                && mHealthInfo.batteryStatus != BatteryManager.BATTERY_STATUS_UNKNOWN
                && mHealthInfo.batteryLevel <= mLowBatteryWarningLevel
                && (oldPlugged || mLastBatteryLevel > mLowBatteryWarningLevel);
    }

    private boolean shouldShutdownLocked() {
        if (mHealthInfo.batteryLevel > 0) {
            return false;
        }

        // Battery-less devices should not shutdown.
        if (!mHealthInfo.batteryPresent) {
            return false;
        }

        // add for bug#1021541
        boolean checkPlugState = (mUpdatesStopped && mHealthInfo.batteryLevel == mSetBatteryLevel
                && mSetBatteryLevel != mRealBatteryLevel);
        if (DEBUG) Slog.d(TAG, "shutdownIfNoPowerLocked: mUpdatesStopped: " + mUpdatesStopped
                + " mHealthInfo.batteryLevel:"  + mHealthInfo.batteryLevel
                + " mSetBatteryLevel:" + mSetBatteryLevel + " mRealBatteryLevel:" + mRealBatteryLevel);

        // If battery state is not CHARGING, shutdown.
        // - If battery present and state == unknown, this is an unexpected error state.
        // - If level <= 0 and state == full, this is also an unexpected state
        // - All other states (NOT_CHARGING, DISCHARGING) means it is not charging.
        return !checkPlugState || mHealthInfo.batteryStatus != BatteryManager.BATTERY_STATUS_CHARGING;
    }

   

    private void update(android.hardware.health.V2_0.HealthInfo info) {
        traceBegin("HealthInfoUpdate");

        Trace.traceCounter(Trace.TRACE_TAG_POWER, "BatteryChargeCounter",
                info.legacy.batteryChargeCounter);
        Trace.traceCounter(Trace.TRACE_TAG_POWER, "BatteryCurrent",
                info.legacy.batteryCurrent);

        synchronized (mLock) {
            mRealBatteryLevel = info.legacy.batteryLevel;
            if (!mUpdatesStopped) {
                mHealthInfo = info.legacy;
                // Process the new values.
                processValuesLocked(false);
                mLock.notifyAll(); // for any waiters on new info
            } else {
                copy(mLastHealthInfo, info.legacy);
            }
        }
        traceEnd();
    }

    private static void copy(HealthInfo dst, HealthInfo src) {
        dst.chargerAcOnline = src.chargerAcOnline;
        dst.chargerUsbOnline = src.chargerUsbOnline;
        dst.chargerWirelessOnline = src.chargerWirelessOnline;
        dst.maxChargingCurrent = src.maxChargingCurrent;
        dst.maxChargingVoltage = src.maxChargingVoltage;
        dst.batteryStatus = src.batteryStatus;
        dst.batteryHealth = src.batteryHealth;
        dst.batteryPresent = src.batteryPresent;
        dst.batteryLevel = src.batteryLevel;
        dst.batteryVoltage = src.batteryVoltage;
        dst.batteryTemperature = src.batteryTemperature;
        dst.batteryCurrent = src.batteryCurrent;
        dst.batteryCycleCount = src.batteryCycleCount;
        dst.batteryFullCharge = src.batteryFullCharge;
        dst.batteryChargeCounter = src.batteryChargeCounter;
        dst.batteryTechnology = src.batteryTechnology;
    }
   //主要来计算获取警告的电量值和关闭警告的电量值，然后调用processValuesLocked()方法来做真正的更新。我们知道当监听的底层电池电量发生变化的时候，回调update()方法,最终也会调用该方法来更新
    private void processValuesLocked(boolean force) {
        boolean logOutlier = false;
        long dischargeDuration = 0;

        mBatteryLevelCritical =
            mHealthInfo.batteryStatus != BatteryManager.BATTERY_STATUS_UNKNOWN
            && mHealthInfo.batteryLevel <= mCriticalBatteryLevel;
        if (mHealthInfo.chargerAcOnline) {
            mPlugType = BatteryManager.BATTERY_PLUGGED_AC;
        } else if (mHealthInfo.chargerUsbOnline) {
            mPlugType = BatteryManager.BATTERY_PLUGGED_USB;
        } else if (mHealthInfo.chargerWirelessOnline) {
            mPlugType = BatteryManager.BATTERY_PLUGGED_WIRELESS;
        } else {
            mPlugType = BATTERY_PLUGGED_NONE;
        }

        if (DEBUG) {
            Slog.d(TAG, "Processing new values: "
                    + "info=" + mHealthInfo
                    + ", mBatteryLevelCritical=" + mBatteryLevelCritical
                    + ", mPlugType=" + mPlugType);
        }

        // Let the battery stats keep track of the current level.
        try {
            mBatteryStats.setBatteryState(mHealthInfo.batteryStatus, mHealthInfo.batteryHealth,
                    mPlugType, mHealthInfo.batteryLevel, mHealthInfo.batteryTemperature,
                    mHealthInfo.batteryVoltage, mHealthInfo.batteryChargeCounter,
                    mHealthInfo.batteryFullCharge);
        } catch (RemoteException e) {
            // Should never happen.
        }

        shutdownIfNoPowerLocked();
        shutdownIfOverTempLocked();

     
....}


```

### 


BatteryService.java作为系统电池服务，负责监控电池的电压温度等状态，具体电池的变化来通过updateBatteryWarningLevelLocked()更新电池的信息 最后在在processValuesLocked(boolean force)调用自定义电池温度异常检测方法



### 3.1 增加全局变量：



```
    import android.app.AlertDialog;
    import android.view.WindowManager;
    import android.content.DialogInterface;

    private int mConfigWarningLowBatteryTemp;
    private int mConfigWarningHightBatteryTemp;
    private String mWarningLowBatteryTemp;
    private String mWarningHightBatteryTemp;
    private String mShutdownBatteryTempMsg;
    private AlertDialog mbatteryTempeDialog = null;

   在构造方法中变量赋值
        mConfigWarningLowBatteryTemp= mContext.getResources().getInteger(
                com.android.internal.R.integer.config_warningLowBatteryTemp);
        mConfigWarningHightBatteryTemp= mContext.getResources().getInteger(
                com.android.internal.R.integer.config_warningHightBatteryTemp);
        mWarningHightBatteryTemp = mContext.getResources().getString(
                com.android.internal.R.string.warningHightBatteryTemp);
        mShutdownBatteryTempMsg = mContext.getResources().getString(
                com.android.internal.R.string.shutdownBatteryTempMsg);
        mWarningLowBatteryTemp = mContext.getResources().getString(
                com.android.internal.R.string.warningLowBatteryTemp);

   private void processValuesLocked(boolean force) {
          ... ...
        shutdownIfNoPowerLocked();
        shutdownIfOverTempLocked();
        //add code start
       //调用自定义电池温度异常检测方法
        warningBatteryTemp();
        //add code end
         ... ...
    }

添加自定义电池温度异常检测方法
    private void warningBatteryTemp(){
        if(mPlugType != BATTERY_PLUGGED_NONE && mHealthInfo!=null && mbatteryTempDialog == null){
           if (mHealthInfo.batteryTemperature >= mConfigWarningHightBatteryTemp) {
                mHandler.post(new Runnable() {
                    public void run() {
                        if(mHealthInfo.batteryTemperature >= (mShutdownBatteryTemp-10)){
                            batteryTempDialog(mShutdownBatteryTempMsg);
                        }else{
                            batteryTempDialog(mWarningHightBatteryTemp);
                        }
                    }
                });
           }
           if (mHealthInfo.batteryTemperature < mConfigWarningLowBatteryTemp) {
                 mHandler.post(new Runnable() {
                    public void run() {
                        batteryTempDialog(mWarningLowBatteryTemp);
                    }
                  });
           } 
        }
    }
    // 自定义电池温度Dialog弹窗
    private void batteryTempDialog(String batteryTemp) {

        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle(mContext.getResources().getString(
                com.android.internal.R.string.batteryTempWarning));
        builder.setCancelable(false);
        builder.setMessage(batteryTemp);
        builder.setIconAttribute(android.R.attr.alertDialogIcon);
        builder.setPositiveButton(com.android.internal.R.string.batteryTempOk,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        mbatteryTempDialog = null;
                    }
                });
        mbatteryTempeDialog = builder.create();
        mbatteryTempDialog.getWindow().setType(
                WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        if (mbatteryTempDialog != null&& !mbatteryTempDialog.isShowing()) {
            mbatteryTempDialog.show();
        }

    }
```

### 


综合以上所述在processValuesLocked(boolean force)调用自定义电池温度异常检测方法


功能增加如下:


通过在processValuesLocked(boolean force)添加电池温度异常的方法warningBatteryTemp()和batteryTempDialog(String batteryTemp)来负责监控当温度异常弹窗提醒


### 


### 3.3 frameworks/base 下增加相关资源



```
  1.添加弹窗字符串资源

frameworks/base/core/res/res/values/strings.xml

<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:xliff="urn:oasis:names:tc:xliff:document:1.2">
    ... ...
    <!-- add code start-->
    <string name="warningLowBatteryTemp">"电池温度太低，请联系售后"</string>
    <string name="warningHightBatteryTemp">"电池温度太高，影响电池寿命 请停止充电"</string>
    <string name="shutdownBatteryTempMsg">"电池温度太高,稍后关机..."</string>
    <string name="batteryTempWarning">Warning</string>
    <string name="batteryTempOk">"OK"</string>
    <!-- add code end-->   
    ... ...
</resources>

2.添加自定义电池异常温度定义ui

自定义温度 主要修改alps/frameworks/base/core/res/res/values/config.xmlthis

<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:xliff="urn:oasis:names:tc:xliff:document:1.2">
    ... ...
    <!-- Shutdown if the battery temperature exceeds (this value * 0.1) Celsius. -->
    <integer name="config_shutdownBatteryTemperature">680</integer>
    <!-- add code start-->
    <integer name="config_warningHightBatteryTemp">550</integer>
    <integer name="config_warningLowBatteryTemp">0</integer>
    <!-- add code end-->
    ... ...
</resources>

3. 在symbols 文件中添加对应java-symbol方便Framework代码引用code

在symbols文件中为全部string，int值注册，方便Framework层代码的引用。
alps/frameworks/base/core/res/res/values/symbols.xmlorm

<?xml version="1.0" encoding="utf-8"?>
<resources>
  <!-- Private symbols that we need to reference from framework code.  See
       frameworks/base/core/res/MakeJavaSymbols.sed for how to easily generate
       this.

       Can be referenced in java code as: com.android.internal.R.<type>.<name>
       and in layout xml as: "@*android:<type>/<name>"
  -->
... ... 
  <java-symbol type="integer" name="config_shutdownBatteryTemperature" />
  <!-- add code start-->
  <java-symbol type="integer" name="config_warningHightBatteryTemp" />
  <java-symbol type="integer" name="config_warningLowBatteryTemp" />
  <java-symbol type="string" name="warningLowBatteryTemp" />
  <java-symbol type="string" name="warningHightBatteryTemp" />
  <java-symbol type="string" name="shutdownBatteryTempMsg" />
  <java-symbol type="string" name="batteryTempWarning" />
  <java-symbol type="string" name="batteryTempOk" />
```

添加电池温度异常弹窗的资源，通过上述的修改可以发现最终实现了在SystemUI中电池温度的


检测功能，遇到温度过高的时候，会弹出温度过高提醒弹窗功能



