



## 系列文章目录


中秋节快要到来了，对于软件工程师来说，写篇优秀的博文，来激励下自己，在前面两篇已经介绍了 关机对话框UI定制化的相关博文，今天就来继续介绍关机对话框的第三篇博文，来实现关机对话框的UI定制




#### 文章目录


[系列文章目录](#%E7%B3%BB%E5%88%97%E6%96%87%E7%AB%A0%E7%9B%AE%E5%BD%95)


[文章目录](#%E6%96%87%E7%AB%A0%E7%9B%AE%E5%BD%95)


[前言](#%E5%89%8D%E8%A8%80)



[1.简要介绍](#1.%E7%AE%80%E8%A6%81%E4%BB%8B%E7%BB%8D)


[2.定制化功能实现](#2.%E5%AE%9A%E5%88%B6%E5%8C%96%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[2.2 关机对话框添加高斯模糊背景功能](#2.2%20%E5%85%B3%E6%9C%BA%E5%AF%B9%E8%AF%9D%E6%A1%86%E6%B7%BB%E5%8A%A0%E9%AB%98%E6%96%AF%E6%A8%A1%E7%B3%8A%E8%83%8C%E6%99%AF%E5%8A%9F%E8%83%BD)


[总结](#%E6%80%BB%E7%BB%93)




---







---


## 前言


SystemUI的定制功能也是比较多的，今天就来定制化关机对话框的UI布局 也是第三篇关于定制关机对话框的UI方面的工作


## 


## 1.简要介绍


在10.0的定制化开发中，需要对关机对话框的UI界面进行定制化开发，需要对话框全屏，去掉多余项 保留关机 重启 飞行模式 静音模式等选项 现在开始定制化三的开发 实现高斯模糊背景




---


## 2.定制化功能实现


高斯模糊（Gaussian Blur）是一种图像处理技术，它可以让图像变得模糊，使图像中的细节减弱，边缘变得柔和，从而使图像变得更加平滑。它可以用来消除图像中的瑕疵，抑制噪声，美化图像等等。


高斯模糊的基本原理是对图像中的每个像素进行加权平均处理，使得其周围像素的值对结果产生影响。这种加权平均过程使用了高斯分布函数，即距离中心像素越远的像素对结果的影响越小。


在Android中，我们可以使用RenderScript、第三方库或自定义算法来实现高斯模糊效果


## 2.1 高斯模糊背景功能实现


BlurUtil是实现高斯模糊的具体实现类 根据传入的Bitmap值和设置


private static final float BITMAP\_SCALE = 0.4f;  
 private static final int BLUR\_RADIUS = 7;  
 public static final int BLUR\_RADIUS\_MAX = 25;


这三个参数来设置高斯模糊程度 然后根据RenderScript相关api来实现高斯模糊功能



```
package com.android.systemui.util;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
public class BlurUtil {
private static final float BITMAP_SCALE = 0.4f;
private static final int BLUR_RADIUS = 7;
public static final int BLUR_RADIUS_MAX = 25;
public static Bitmap blur(Context context, Bitmap bitmap) {
    return blur(context, bitmap, BITMAP_SCALE, BLUR_RADIUS);
}

public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale) {
    return blur(context, bitmap, bitmap_scale, BLUR_RADIUS);
}

public static Bitmap blur(Context context, Bitmap bitmap, int blur_radius) {
    //return blur(context, bitmap, BITMAP_SCALE, blur_radius);
    return blurbitmap(context,bitmap);
}

public static Bitmap blur(Context context, Bitmap bitmap, float bitmap_scale, int blur_radius) {
    Bitmap inputBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * bitmap_scale),
            Math.round(bitmap.getHeight() * bitmap_scale), false);
    Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
    RenderScript rs = RenderScript.create(context);
    ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
    Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
    Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
    theIntrinsic.setRadius(blur_radius);
    theIntrinsic.setInput(tmpIn);
    theIntrinsic.forEach(tmpOut);
    tmpOut.copyTo(outputBitmap);
    rs.destroy();
    bitmap.recycle();
    return outputBitmap;
}

public static Bitmap blurbitmap(Context context, Bitmap bitmap) {
//用需要创建高斯模糊bitmap创建一个空的bitmap
Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
// 初始化Renderscript，该类提供了RenderScript context，创建其他RS类之前必须先创建这个类，其控制RenderScript的初始化，资源管理及释放
RenderScript rs = RenderScript.create(context);
// 创建高斯模糊对象
ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
// 创建Allocations，此类是将数据传递给RenderScript内核的主要方 法，并制定一个后备类型存储给定类型
Allocation allIn = Allocation.createFromBitmap(rs, bitmap);
Allocation allOut = Allocation.createFromBitmap(rs, outBitmap);
//设定模糊度(注：Radius最大只能设置25.f)
blurScript.setRadius(25.0f);
// Perform the Renderscript
blurScript.setInput(allIn);
blurScript.forEach(allOut);
// Copy the final bitmap created by the out Allocation to the outBitmap
allOut.copyTo(outBitmap);
// recycle the original bitmap
// bitmap.recycle();
// After finishing everything, we destroy the Renderscript.
rs.destroy();
return outBitmap;
}
private static Bitmap blurBitmap(Bitmap bkg,Context context) {
//设定模糊度(注：Radius最大只能设置25.f)
float radius = 25.0f;
//背景图片缩放处理
bkg = smallBitmap(bkg);
Bitmap bitmap = bkg.copy(bkg.getConfig(), false);
    final RenderScript rs = RenderScript.create(context);
    final Allocation input = Allocation.createFromBitmap(rs, bkg, Allocation.MipmapControl.MIPMAP_NONE,
            Allocation.USAGE_SCRIPT);
    final Allocation output = Allocation.createTyped(rs, input.getType());
    final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
    script.setRadius(radius);
    script.setInput(input);
    script.forEach(output);
    output.copyTo(bitmap);
    //背景图片放大处理
    bitmap = bigBitmap(bitmap);
    rs.destroy();
    return bitmap;
}

private static Bitmap bigBitmap(Bitmap bitmap) {
    Matrix matrix = new Matrix();
    matrix.postScale(4f,4f); //长和宽放大缩小的比例
    Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    return resizeBmp;
}

private static Bitmap smallBitmap(Bitmap bitmap) {
    Matrix matrix = new Matrix();
    matrix.postScale(0.25f,0.25f); //长和宽放大缩小的比例
    Bitmap resizeBmp = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    return resizeBmp;
}
}


```

## 


通过上述的BlurUtil.java的相关源码中，分析相关的源码得知，在这里Bitmap blur(Context context, Bitmap bitmap, float bitmap\_scale, int blur\_radius)等利用相关的高斯模糊的api来实现对背景图标的高斯模糊效果的实现


## 


## 


BitmapUtils.java 工具类



```

package com.android.systemui.util;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import com.android.systemui.globalactions.GlobalActionsLayout;
public class BitmapUtils {
public static void recycleImageView(View view) {
    if (view == null) return;
    if (view instanceof GlobalActionsLayout) {
        Drawable drawable = ((GlobalActionsLayout) view).getBackground();
        if (drawable instanceof BitmapDrawable) {
            Bitmap bmp = ((BitmapDrawable) drawable).getBitmap();
            if (bmp != null && !bmp.isRecycled()) {
                ((GlobalActionsLayout) view).setBackground(null);
                bmp.recycle();
                bmp = null;
            }
        }
    }
}
}
```


从上述的BitmapUtils.java工具类的相关源码分析得知看出在这个BitmapUtils.java工具类中的核心功能，主要是清除原来背景设置一个空背景，然后重新设置一个高斯模糊毛玻璃的背景给全屏的


关键对话框画面的就这样来实现主要的高斯模糊毛玻璃的背景功能


## 2.2 关机对话框添加高斯模糊背景功能


关机对话框就是GlobalActionsDialog.java  
 路径:frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java


增加设置高斯模糊背景方法



```

		private void setBlurBackground() {
		   Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), com.android.systemui.R.drawable.bg_action);/*ScreenShotUtil.takeScreenShot(mContext)*/;
		   if (bitmap == null) {
			   Log.e(TAG, "setBlurBackground bitmap == null");
			   return;
		   }
		   //bitmap.setConfig(Bitmap.Config.ARGB_8888);
		   Bitmap blurBitmap = BlurUtil.blur(mContext, bitmap, BlurUtil.BLUR_RADIUS_MAX);
		   BitmapUtils.recycleImageView(mGlobalActionsLayout);
		   BitmapDrawable bitmapdrawable = new BitmapDrawable(blurBitmap);
		   mGlobalActionsLayout.setBackground(bitmapdrawable);
		}



```

在GlobalActionsDialog.java中的上述方法中，分析相关源码发现，在initializeLayout() 中这个初始化关机对话框的页面中，添加 setBlurBackground()；来设置关机对话框的高斯模糊毛玻璃背景来实现功能具体实现  
 修改如下:



```
private void initializeLayout() {
            setContentView(getGlobalActionsLayoutId(mContext));
            fixNavBarClipping();
            mGlobalActionsLayout = findViewById(com.android.systemui.R.id.global_actions_view);
            mGlobalActionsLayout.setOutsideTouchListener(view -> dismiss());
            ((View) mGlobalActionsLayout.getParent()).setOnClickListener(view -> dismiss());
            mGlobalActionsLayout.setListViewAccessibilityDelegate(new View.AccessibilityDelegate() {
                @Override
                public boolean dispatchPopulateAccessibilityEvent(
                        View host, AccessibilityEvent event) {
                    // Populate the title here, just as Activity does
                    event.getText().add(mContext.getString(R.string.global_actions));
                    return true;
                }
            });
            mGlobalActionsLayout.setRotationListener(this::onRotate);
            mGlobalActionsLayout.setAdapter(mAdapter);
            RelativeLayout airphone_area = findViewById(com.android.systemui.R.id.airphone_area);
			airphone_area.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View view) {
					int mode = Settings.Global.getInt(mContext.getContentResolver(),Settings.System.AIRPLANE_MODE_ON,-1);
					if(mode == 0){
					     Settings.Global.putInt(mContext.getContentResolver(),Settings.System.AIRPLANE_MODE_ON,1);
					}else{
						 Settings.Global.putInt(mContext.getContentResolver(),Settings.System.AIRPLANE_MODE_ON,0);
					}
					Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
					intent.putExtra("state", mode==0?false:true);
					mContext.sendBroadcast(intent);
					dismiss();
				}
			});
            RelativeLayout ring_area = findViewById(com.android.systemui.R.id.ring_area);
			ring_area.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View view) {
					AudioManager audioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
					int ringerMode = audioManager.getRingerMode();
					if(ringerMode==AudioManager.RINGER_MODE_SILENT){
						audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
					}else if(ringerMode==AudioManager.RINGER_MODE_NORMAL){
						audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
					}
					dismiss();
				}
			});
            if (shouldUsePanel()) {
                initializePanel();
            }
            if (mBackgroundDrawable == null) {
                mBackgroundDrawable = new ScrimDrawable();
                mScrimAlpha = ScrimController.GRADIENT_SCRIM_ALPHA;
            }
			setBlurBackground();
            //getWindow().setBackgroundDrawable(mBackgroundDrawable);
        }

```

## 总结


对于定制化开发，就是找准相关代码，然后在原有基础上进行定制就能满足需要



