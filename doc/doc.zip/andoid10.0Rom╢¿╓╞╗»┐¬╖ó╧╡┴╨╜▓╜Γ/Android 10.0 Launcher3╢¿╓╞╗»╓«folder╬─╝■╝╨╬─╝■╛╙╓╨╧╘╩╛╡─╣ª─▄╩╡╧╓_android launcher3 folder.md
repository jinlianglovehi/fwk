



## 1.概述


在10.0的系统产品开发中，在对Launcher3的定制开发中的功能，在最近的产品项目中，有需求要求带默认文件夹功能，所以需要对文件夹的ui做定制化功能的修改在文件夹全屏以后，需要对子文件部分做居中处理，在居中显示比较美观，接下来就来处理居中显示的部分.


如图:


![](https://img-blog.csdnimg.cn/c04d25a7111b4e0892f9b446b03c8a32.png)


## 2.Launcher3 folder文件夹文件居中显示的定制的核心类



```
    packages\apps\Launcher3\res\layout\user_folder_icon_normalized.xml
    packages\apps\Launcher3\src\com\android\launcher3\folder\FolderPagedView.java
```

## 3.Launcher3 folder文件夹文件居中显示的定制的核心功能分析和实现


在Launcher3的定制化功能中，在对folder文件夹做UI定制时，需要首先找到系统添加文件夹里面的相关Item的布局，在查阅Launcher3中的源码后发现Folder文件夹类的引用的layout布局就是  
 user\_folder\_icon\_normalized.xml，接下来看下它的相关布局分析


*FolderIcon*:出现在workspace的*icon* 代表了一个*folder*


FolderInfo: ItemInfo子类 HandleView:launcher抽屉的开关


ItemInfo:代表Launcher中一个Item（例如folder）对item的抽象，所有类型item的父类，item包含的属性有id（标识item的id）,cellX(在横向位置上的位置，从0开始),cellY（在纵向位置上的位置，从0开始）,spanX（在横向位置上所占的单位格）,spanY（在纵向位置上所占的单位格）,screen（在workspace的第几屏，从0开始）,itemType（item的类型，有widget，search，application等）,container（item所在的）


## 3.1 user\_folder\_icon\_normalized.xml的布局分析



```
    <com.android.launcher3.folder.Folder xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:launcher="http://schemas.android.com/apk/res-auto"
        android:layout_width="1920px"
        android:layout_height="1080px"
        android:background="@drawable/round_rect_folder"
        android:elevation="5dp"
        android:orientation="vertical" >
        <com.android.launcher3.folder.FolderNameEditText
                android:id="@+id/folder_name"
                android:layout_width="200px"
                android:layout_height="50px"
                android:layout_gravity="center_horizontal"
                android:textStyle="bold"
                android:background="@android:color/transparent"
                android:gravity="center"
                android:hint="@string/folder_hint_text"
                android:singleLine="true"
                android:layout_marginTop="100px"
                android:textColor="@android:color/white"
                android:textSize="40sp" />
        <com.android.launcher3.folder.FolderPagedView
            android:id="@+id/folder_content"
            android:clipToPadding="false"
            android:layout_width="650px"
            android:layout_height="650px"
            android:layout_gravity="center_horizontal"
            android:background="@drawable/shape_folders"
            android:paddingTop="40px"
            android:layout_marginTop="50px"
            launcher:pageIndicator="@+id/folder_page_indicator" />
     
        <LinearLayout
            android:id="@+id/folder_footer"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:clipChildren="false"
            android:orientation="horizontal"
            android:layout_gravity="center_horizontal"
            android:paddingLeft="12dp"
            android:paddingRight="12dp" >
     
            <com.android.launcher3.pageindicators.PageIndicatorDots
                android:id="@+id/folder_page_indicator"
                android:layout_gravity="center_vertical"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:elevation="1dp"
                />
     
        </LinearLayout>
```

在上述Launcher3的代码中可以看出，在user\_folder\_icon\_normalized.xml中的相关代码中，在com.android.launcher3.folder.FolderPagedView  
 就是中间的所有文件的布局，所有居中就需要添加属性android:layout\_gravity="center\_horizontal"，并且添加圆角背景android:background="@drawable/shape\_folders"  
 然后在修改了 工具的位置,就是com.android.launcher3.folder.FolderNameEditText,这里就是默认的显示工具的名称，  
 可以默认编辑的，布局就移动了最上边，也需要重新布局，添加属性android:layout\_gravity="center\_horizontal"，所以具体关于默认的  
 文件夹显示布局的区域就是com.android.launcher3.folder.FolderPagedView，负责显示文件夹的相关布局，接下来看下FolderPagedView的相关源码分析


## 3.2 FolderPagedView的相关源码分析


在实现folder文件夹文件居中显示的定制的核心实现功能中，在上述Launcher3的代码中可以看出，在关于folder文件夹的管理folder文件的分页布局中，在FolderPagedView负责翻页文件夹的


布局功能，所以接下来重点分析下FolderPagedView的相关源码



```

        public View createAndAddViewForRank(WorkspaceItemInfo item, int rank) {
            View icon = createNewView(item);
            if (!mViewsBound) {
                return icon;
            }
            ArrayList<View> views = new ArrayList<>(mFolder.getIconsInReadingOrder());
            views.add(rank, icon);
            arrangeChildren(views);
            return icon;
        }
     
        public void addViewForRank(View view, WorkspaceItemInfo item, int rank) {
            int pageNo = rank / mOrganizer.getMaxItemsPerPage();
     
            CellLayout.LayoutParams lp = (CellLayout.LayoutParams) view.getLayoutParams();
            lp.setXY(mOrganizer.getPosForRank(rank));
            getPageAt(pageNo).addViewToCellLayout(view, -1, item.getViewId(), lp, true);
        }
     
        @SuppressLint("InflateParams")
        public View createNewView(WorkspaceItemInfo item) {
            if (item == null) {
                return null;
            }
            final BubbleTextView textView = mViewCache.getView(
                    R.layout.folder_application, getContext(), null);
            textView.applyFromWorkspaceItem(item);
            textView.setOnClickListener(ItemClickHandler.INSTANCE);
            textView.setOnLongClickListener(mFolder);
            textView.setOnFocusChangeListener(mFocusIndicatorHelper);
            textView.setCompoundDrawablePadding(-20);
            CellLayout.LayoutParams lp = (CellLayout.LayoutParams) textView.getLayoutParams();
            if (lp == null) {
                textView.setLayoutParams(new CellLayout.LayoutParams(
                        item.cellX, item.cellY, item.spanX, item.spanY));
            } else {
                lp.cellX = item.cellX;
                lp.cellY = item.cellY;
                lp.cellHSpan = lp.cellVSpan = 1;
            }
            return textView;
        }
```

在实现folder文件夹文件居中显示的定制的核心实现功能中，


在上述代码中可以看出在FolderPagedView.java中createNewView(WorkspaceItemInfo item)就是构建每个文件的布局，  
 createAndAddViewForRank(WorkspaceItemInfo item, int rank)添加子文件，在createNewView(WorkspaceItemInfo item)  
 构建每个文件的点击事件等等，所以接下来分析下相关的核心源码，具体看下构建文件夹的相关布局的相关  
 源码进行分析 然后来具体实现文件夹的居中显示功能



```
   @SuppressLint("RtlHardcoded")
        public void arrangeChildren(List<View> list) {
            int itemCount = list.size();
            ArrayList<CellLayout> pages = new ArrayList<>();
            for (int i = 0; i < getChildCount(); i++) {
                CellLayout page = (CellLayout) getChildAt(i);
                page.removeAllViews();
                pages.add(page);
            }
            mOrganizer.setFolderInfo(mFolder.getInfo());
            setupContentDimensions(itemCount);
     
            Iterator<CellLayout> pageItr = pages.iterator();
            CellLayout currentPage = null;
     
            int position = 0;
            int rank = 0;
     
            for (int i = 0; i < itemCount; i++) {
                View v = list.size() > i ? list.get(i) : null;
                if (currentPage == null || position >= mOrganizer.getMaxItemsPerPage()) {
                    // Next page
                    if (pageItr.hasNext()) {
                        currentPage = pageItr.next();
                    } else {
                        currentPage = createAndAddNewPage();
                    }
                    position = 0;
                }
     
                if (v != null) {
                    CellLayout.LayoutParams lp = (CellLayout.LayoutParams) v.getLayoutParams();
                    ItemInfo info = (ItemInfo) v.getTag();
                    lp.setXY(mOrganizer.getPosForRank(rank));
                    currentPage.addViewToCellLayout(v, -1, info.getViewId(), lp, true);
     
                    if (mOrganizer.isItemInPreview(rank) && v instanceof BubbleTextView) {
                        ((BubbleTextView) v).verifyHighRes();
                    }
                }
     
                rank++;
                position++;
            }
     
            // Remove extra views.
            boolean removed = false;
            while (pageItr.hasNext()) {
                removeView(pageItr.next());
                removed = true;
            }
            if (removed) {
                setCurrentPage(0);
            }
     
            setEnableOverscroll(getPageCount() > 1);
     
            // Update footer
            mPageIndicator.setVisibility(getPageCount() > 1 ? View.VISIBLE : View.GONE);
            // Set the gravity as LEFT or RIGHT instead of START, as START depends on the actual text.
            mFolder.mFolderName.setGravity(getPageCount() > 1 ?
                    (mIsRtl ? Gravity.RIGHT : Gravity.LEFT) : Gravity.CENTER_HORIZONTAL);
        }

```

在实现folder文件夹文件居中显示的定制的核心实现功能中，在上述方法中，在FolderPagedView.java中arrangeChildren(List<View> list)中负责布局每个文件的图标的布局设置mFolder.mFolderName.setGravity的文件夹的名称，然后通过遍历每个文件夹的设置相关布局和显示相关的名称，mFolder.mFolderName.setGravity设置文件夹内部的item的布局显示，而createAndAddNewPage()判断当前页是否能显示全item，不然就需要重新  
 增加文件页类显示item，接下来看下相关的文件夹整体布局



```
       public int getDesiredWidth() {
            return getPageCount() > 0 ?
                    /*(getPageAt(0).getDesiredWidth() + getPaddingLeft() + getPaddingRight())*/600 : 0;
        }
     
        public int getDesiredHeight()  {
            return  getPageCount() > 0 ?
                    /*(getPageAt(0).getDesiredHeight() + getPaddingTop() + getPaddingBottom())*/600 : 0;
        }

```

在实现folder文件夹文件居中显示的定制的核心实现功能中，而在上述代码中，在FolderPagedView.java中的getDesiredWidth()和getDesiredHeight()的两个方法  
 就是当前FolderPagedView.java的宽高，所以可以设置这两个方法，来设置默认文件夹内的每个文件页的宽高所以修改为了600的高度，就是修改默认的文件夹的文件页宽高为600，通过布局属性就可以在全屏显示文件夹的时候，文件夹中间的item布局居中显示



