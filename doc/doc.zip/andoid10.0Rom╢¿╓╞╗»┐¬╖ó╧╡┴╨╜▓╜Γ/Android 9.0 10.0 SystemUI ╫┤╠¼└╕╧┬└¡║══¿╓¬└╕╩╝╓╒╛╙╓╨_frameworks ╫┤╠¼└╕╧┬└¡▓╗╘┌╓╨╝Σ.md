






### 1.概述


在10.0的系统产品中，在下拉SystemUI 状态栏下拉和通知栏，默认是根据手势的x 坐标的位置居中显示，但是如果太靠两边感觉不太好，下拉太靠边不太好看，所以产品提出不管手势在哪里下滑 都要去下拉和通知栏居中显示 会比较好看些 下面就来实现这个需求


### 2.SystemUI 状态栏下拉和通知栏始终居中的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java

```

### 3.SystemUI 状态栏下拉和通知栏始终居中的核心功能分析和实现


在系统的默认的下拉状态中的布局分析得知  
 而在SystemUI中处理下拉展示UI的就是NotificationPanelView.java  
 接下来就来看NotificationPanelView.java的源码 分析原因  
 下拉触摸是在onTouchEvent(MotionEvent event) 中处理的



```
@Override
      public boolean onInterceptTouchEvent(MotionEvent event) {
          if (mBlockTouches || mQsFullyExpanded && mQs.onInterceptTouchEvent(event)) {
              return false;
          }
          initDownStates(event);
          // Do not let touches go to shade or QS if the bouncer is visible,
          // but still let user swipe down to expand the panel, dismissing the bouncer.
          if (mStatusBar.isBouncerShowing()) {
              return true;
          }
          if (mBar.panelEnabled() && mHeadsUpTouchHelper.onInterceptTouchEvent(event)) {
              mIsExpansionFromHeadsUp = true;
              MetricsLogger.count(mContext, COUNTER_PANEL_OPEN, 1);
              MetricsLogger.count(mContext, COUNTER_PANEL_OPEN_PEEK, 1);
              return true;
          }
          if (mPulseExpansionHandler.onInterceptTouchEvent(event)) {
              return true;
          }
  
          if (!isFullyCollapsed() && onQsIntercept(event)) {
              return true;
          }
          return super.onInterceptTouchEvent(event);
      }
  
      private boolean onQsIntercept(MotionEvent event) {
          int pointerIndex = event.findPointerIndex(mTrackingPointer);
          if (pointerIndex < 0) {
              pointerIndex = 0;
              mTrackingPointer = event.getPointerId(pointerIndex);
          }
          final float x = event.getX(pointerIndex);
          final float y = event.getY(pointerIndex);
  
          switch (event.getActionMasked()) {
              case MotionEvent.ACTION_DOWN:
                  mIntercepting = true;
                  mInitialTouchY = y;
                  mInitialTouchX = x;
                  initVelocityTracker();
                  trackMovement(event);
                  if (shouldQuickSettingsIntercept(mInitialTouchX, mInitialTouchY, 0)) {
                      getParent().requestDisallowInterceptTouchEvent(true);
                  }
                  if (mQsExpansionAnimator != null) {
                      onQsExpansionStarted();
                      mInitialHeightOnTouch = mQsExpansionHeight;
                      mQsTracking = true;
                      mIntercepting = false;
                      mNotificationStackScroller.cancelLongPress();
                  }
                  break;
              case MotionEvent.ACTION_POINTER_UP:
                  final int upPointer = event.getPointerId(event.getActionIndex());
                  if (mTrackingPointer == upPointer) {
                      // gesture is ongoing, find a new pointer to track
                      final int newIndex = event.getPointerId(0) != upPointer ? 0 : 1;
                      mTrackingPointer = event.getPointerId(newIndex);
                      mInitialTouchX = event.getX(newIndex);
                      mInitialTouchY = event.getY(newIndex);
                  }
                  break;
  
              case MotionEvent.ACTION_MOVE:
                  final float h = y - mInitialTouchY;
                  trackMovement(event);
                  if (mQsTracking) {
  
                      // Already tracking because onOverscrolled was called. We need to update here
                      // so we don't stop for a frame until the next touch event gets handled in
 // onTouchEvent.
 setQsExpansion(h + mInitialHeightOnTouch);
 trackMovement(event);
 mIntercepting = false;
 return true;
 }
 if (Math.abs(h) > mTouchSlop && Math.abs(h) > Math.abs(x - mInitialTouchX)
 && shouldQuickSettingsIntercept(mInitialTouchX, mInitialTouchY, h)) {
 mQsTracking = true;
 onQsExpansionStarted();
 notifyExpandingFinished();
 mInitialHeightOnTouch = mQsExpansionHeight;
 mInitialTouchY = y;
 mInitialTouchX = x;
 mIntercepting = false;
 mNotificationStackScroller.cancelLongPress();
 return true;
 }
 break;
 
 case MotionEvent.ACTION\_CANCEL:
 case MotionEvent.ACTION\_UP:
 trackMovement(event);
 if (mQsTracking) {
 flingQsWithCurrentVelocity(y,
 event.getActionMasked() == MotionEvent.ACTION\_CANCEL);
 mQsTracking = false;
 }
 mIntercepting = false;
 break;
 }
 return false;
 }
 @Override
 public boolean onTouchEvent(MotionEvent event) {
 /\* UNISOC: Modify for bug1173815,1163448,1191373 {@ \*/
 if (DEBUG) {
 Log.d("NotificationPanelView","onTouchEvent mBlockTouches=" + mBlockTouches);
 }

 if (mBlockTouches || (mQs != null && mQs.isCustomizing())) {
 if (DEBUG && mQs != null && mQs.isCustomizing()) {
 Log.d("NotificationPanelView","onTouchEvent false");
 }
 return false;
 }

 // Do not allow panel expansion if bouncer is scrimmed, otherwise user would be able to
 // pull down QS or expand the shade.
 if (mStatusBar.isBouncerShowingScrimmed()) {
 if (DEBUG) {
 Log.d("NotificationPanelView","onTouchEvent bouncer false ");
 }
 return false;
 }

 initDownStates(event);
 // Make sure the next touch won't the blocked after the current ends.
        if (event.getAction() == MotionEvent.ACTION_UP
                || event.getAction() == MotionEvent.ACTION_CANCEL) {
            mBlockingExpansionForCurrentTouch = false;
        }
        if (!mIsExpanding && mPulseExpansionHandler.onTouchEvent(event)) {
            if (DEBUG) {
                Log.d("NotificationPanelView","onTouchEvent handler true");
            }
            // We're expanding all the other ones shouldn't get this anymore
            return true;
        }
        if (mListenForHeadsUp && !mHeadsUpTouchHelper.isTrackingHeadsUp()
                && mHeadsUpTouchHelper.onInterceptTouchEvent(event)) {
            mIsExpansionFromHeadsUp = true;
            MetricsLogger.count(mContext, COUNTER_PANEL_OPEN_PEEK, 1);
        }
        boolean handled = false;
        if ((!mIsExpanding || mHintAnimationRunning)
 && !mQsExpanded
 && mBarState != StatusBarState.SHADE
 && !mDozing) {
 handled |= mAffordanceHelper.onTouchEvent(event);
 }
 if (mOnlyAffordanceInThisMotion) {
 if (DEBUG) {
 Log.d("NotificationPanelView","onTouchEvent motion true");
 }
 return true;
 }
 handled |= mHeadsUpTouchHelper.onTouchEvent(event);

 if (!mHeadsUpTouchHelper.isTrackingHeadsUp() && handleQsTouch(event)) {
            if (DEBUG) {
                Log.d("NotificationPanelView","onTouchEvent qstouch true");
            }
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN && isFullyCollapsed()) {
            MetricsLogger.count(mContext, COUNTER_PANEL_OPEN, 1);
            updateVerticalPanelPosition(event.getX());
            handled = true;
        }
        handled |= super.onTouchEvent(event);
        if (DEBUG) {
            Log.d("NotificationPanelView","end mDozing:" + mDozing + " mPulsing:" + mPulsing + " handled:" +handled);
        }
        /* @} */
        return !mDozing || mPulsing || handled;
    }

```

在onTouchEvent(MotionEvent event)中的触摸事件，在  
 下拉时在 updateVerticalPanelPosition(event.getX()); 来处理通知栏的x轴的具体偏移量  
 然后根据具体偏移量来确定x坐标的位置 接下来看下updateVerticalPanelPosition(float x)的  
 x坐标位置是怎么显示通知栏的位置的



```
protected void updateVerticalPanelPosition(float x) {
    if (mNotificationStackScroller.getWidth() * 1.75f > getWidth()) {
        resetHorizontalPanelPosition();
        return;
    }
    float leftMost = mPositionMinSideMargin + mNotificationStackScroller.getWidth() / 2;
    float rightMost = getWidth() - mPositionMinSideMargin
            - mNotificationStackScroller.getWidth() / 2;
    if (Math.abs(x - getWidth() / 2) < mNotificationStackScroller.getWidth() / 4) {
        x = getWidth() / 2;
    }
    x = Math.min(rightMost, Math.max(leftMost, x));
    float center =
            mNotificationStackScroller.getLeft() + mNotificationStackScroller.getWidth() / 2;
    setHorizontalPanelTranslation(x - center);
}

```

在updateVerticalPanelPosition(float x) 中的最后的代码可以看到最终还是通过调用  
 setHorizontalPanelTranslation(x - center); 来具体计算需要偏移多少，而是在这里设置下拉和通知栏偏移多少



```
protected void setHorizontalPanelTranslation(float translation) {
    mNotificationStackScroller.setHorizontalPanelTranslation(translation);
    mQsFrame.setTranslationX(translation);
    int size = mVerticalTranslationListener.size();
    for (int i = 0; i < size; i++) {
        mVerticalTranslationListener.get(i).run();
    }
}

```

而在setHorizontalPanelTranslation(float translation)中具体处理的是在



```
  mNotificationStackScroller.setHorizontalPanelTranslation(translation);
        mQsFrame.setTranslationX(translation);

```

来具体计算通知栏和下拉框具体偏移多少，更加偏移量来计算显示位置


所以如果不想偏移 就注释掉这两行代码修改如下:



```
protected void setHorizontalPanelTranslation(float translation) {
        //mNotificationStackScroller.setHorizontalPanelTranslation(translation);
        //mQsFrame.setTranslationX(translation);
        int size = mVerticalTranslationListener.size();
        for (int i = 0; i < size; i++) {
            mVerticalTranslationListener.get(i).run();
        }
    }

```

重新编译SystemUI 发现下滑后下拉和通知栏始终居中显示 完成了需求





