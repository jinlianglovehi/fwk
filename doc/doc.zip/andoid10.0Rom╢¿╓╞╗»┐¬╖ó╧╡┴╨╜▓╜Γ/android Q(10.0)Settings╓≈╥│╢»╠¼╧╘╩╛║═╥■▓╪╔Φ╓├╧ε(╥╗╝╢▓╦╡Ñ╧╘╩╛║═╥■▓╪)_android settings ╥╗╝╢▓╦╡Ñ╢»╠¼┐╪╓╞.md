






在定制化开发Settings时,客户对主页设置项需要动态控制显示和隐藏，这就需要用两个页面来区分加载不同settings页面  
 实现思路:  
 1.用系统变量控制显示和隐藏某些项  
 2.增加一个自定义页面来适配不同页面


原理分析


从启动开始说起


进入setting的AndroidManifest.xml里看一看，找启动Activity



```
 <!-- Alias for launcher activity only, as this belongs to each profile. -->
        <activity-alias android:name="Settings"
                android:label="@string/settings\_label\_launcher"
                android:launchMode="singleTask"
                android:targetActivity=".homepage.SettingsHomepageActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <meta-data android:name="android.app.shortcuts" android:resource="@xml/shortcuts"/>
        </activity-alias>

```

发现启动Activity是Settings,但是前面的标签是activity-alias，所以这是另一个Activity的别名，然后它真实的启动Activity应该是targetActivity所标注的SettingsHomepageActivity。


走进SettingsHomepageActivity.java



```
packages\apps\Settings\src\com\android\settings\homepage\SettingsHomepageActivity.java

public class SettingsHomepageActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_homepage_container);
        final View root = findViewById(R.id.settings_homepage_container);
        root.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        
        setHomepageContainerPaddingTop();

        final Toolbar toolbar = findViewById(R.id.search_action_bar);
        FeatureFactory.getFactory(this).getSearchFeatureProvider()
                .initSearchToolbar(this /* activity */, toolbar, SettingsEnums.SETTINGS_HOMEPAGE);

        final ImageView avatarView = findViewById(R.id.account_avatar);
        final AvatarViewMixin avatarViewMixin = new AvatarViewMixin(this, avatarView);
        getLifecycle().addObserver(avatarViewMixin);

        if (!getSystemService(ActivityManager.class).isLowRamDevice()) {
            // Only allow contextual feature on high ram devices.
            showFragment(new ContextualCardsFragment(), R.id.contextual_cards_content);
        }
        showFragment(new TopLevelSettings(), R.id.main_content);
        ((FrameLayout) findViewById(R.id.main\_content))
                .getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
    }

    private void showFragment(Fragment fragment, int id) {
        final FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        final Fragment showFragment = fragmentManager.findFragmentById(id);

        if (showFragment == null) {
            fragmentTransaction.add(id, fragment);
        } else {
            fragmentTransaction.show(showFragment);
        }
        fragmentTransaction.commit();
    }

    @VisibleForTesting
    void setHomepageContainerPaddingTop() {
        final View view = this.findViewById(R.id.homepage_container);

        final int searchBarHeight = getResources().getDimensionPixelSize(R.dimen.search_bar_height);
        final int searchBarMargin = getResources().getDimensionPixelSize(R.dimen.search_bar_margin);

        // The top padding is the height of action bar(48dp) + top/bottom margins(16dp)
        final int paddingTop = searchBarHeight + searchBarMargin * 2;
        view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
    }
}

```

代码不多，布局文件对应 settings\_homepage\_container.xml, 布局加载完成后增加顶部padding为了给SearchActionBar预留空间，


如果不需要SeacherActionBar直接将这部分代码注释即可。接下来看到新创建 TopLevelSettings 填充 main\_content，主角登场啦。


TopLevelSettings 就是我们看到的Settings主界面。


进入TopLevelSettings



```
packages\apps\Settings\src\com\android\settings\homepage\TopLevelSettings.java

public class TopLevelSettings extends DashboardFragment implements
        PreferenceFragmentCompat.OnPreferenceStartFragmentCallback {

    private static final String TAG = "TopLevelSettings";

    public TopLevelSettings() {
        final Bundle args = new Bundle();
        // Disable the search icon because this page uses a full search view in actionbar.
        args.putBoolean(NEED_SEARCH_ICON_IN_ACTION_BAR, false);
        setArguments(args);
    }

    @Override
    protected int getPreferenceScreenResId() {
        return R.xml.top_level_settings;
    }

```

top\_level\_settings.xml


packages\apps\Settings\res\xml\top\_level\_settings.xml



```
<PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:key="top\_level\_settings">

    <Preference
        android:key="top\_level\_network"
        android:title="@string/network\_dashboard\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_network"
        android:order="-120"
        android:fragment="com.android.settings.network.NetworkDashboardFragment"
        settings:controller="com.android.settings.network.TopLevelNetworkEntryPreferenceController"/>

    <Preference
        android:key="top\_level\_connected\_devices"
        android:title="@string/connected\_devices\_dashboard\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_connected\_device"
        android:order="-110"
        android:fragment="com.android.settings.connecteddevice.ConnectedDeviceDashboardFragment"
        settings:controller="com.android.settings.connecteddevice.TopLevelConnectedDevicesPreferenceController"/>

    <Preference
        android:key="top\_level\_apps\_and\_notifs"
        android:title="@string/app\_and\_notification\_dashboard\_title"
        android:summary="@string/app\_and\_notification\_dashboard\_summary"
        android:icon="@drawable/ic\_homepage\_apps"
        android:order="-100"
        android:fragment="com.android.settings.applications.AppAndNotificationDashboardFragment"/>

```

可以看到主界面对应布局 top\_level\_settings.xml中都是一个个Preference，也就对应了主页面每一个条目，可以看到


xml 中 Preference数目和主界面显示数目是不对等了，为啥呢？因为存在动态添加的，查阅 TopLevelSettings 代码发现没啥


特殊而且代码量很少，看到 TopLevelSettings 继承 DashboardFragment，点进去看看


DashboardFragment.java



```
packages\apps\Settings\src\com\android\settings\dashboard\DashboardFragment.java

@Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mSuppressInjectedTileKeys = Arrays.asList(context.getResources().getStringArray(
                R.array.config_suppress_injected_tile_keys));
        mDashboardFeatureProvider = FeatureFactory.getFactory(context).
                getDashboardFeatureProvider(context);
        final List<AbstractPreferenceController> controllers = new ArrayList<>();
        // Load preference controllers from code
        final List<AbstractPreferenceController> controllersFromCode =
                createPreferenceControllers(context);
        // Load preference controllers from xml definition
        final List<BasePreferenceController> controllersFromXml = PreferenceControllerListHelper
                .getPreferenceControllersFromXml(context, getPreferenceScreenResId());
        // Filter xml-based controllers in case a similar controller is created from code already.
        final List<BasePreferenceController> uniqueControllerFromXml =
                PreferenceControllerListHelper.filterControllers(
                        controllersFromXml, controllersFromCode);

        // Add unique controllers to list.
        if (controllersFromCode != null) {
            controllers.addAll(controllersFromCode);
        }
        controllers.addAll(uniqueControllerFromXml);
      
    }

```

注释已经写得很清楚了，分别从java代码和xml中加载PreferenceController，然后过滤去重最终加载页面显示。


java代码加载


createPreferenceControllers() return null,而且子类TopLevelSettings并未覆盖实现，所以 controllersFromCode 为 null


xml加载


getPreferenceControllersFromXml(context, getPreferenceScreenResId()), getPreferenceScreenResId对应刚刚的 top\_level\_settings


具体的遍历解析xml文件,然后显示出来主页面的设置项,所以我们可以根据系统变量的值 来显示不同的页面


自定义top\_level\_settings\_custom.xml 注释掉不需要显示的设置项即可 如下:



```
<?xml version="1.0" encoding="utf-8"?>
<!--
  Copyright (C) 2018 The Android Open Source Project

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  -->

<PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:key="top\_level\_settings">

    <Preference
        android:key="top\_level\_network"
        android:title="@string/network\_dashboard\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_network"
        android:order="-120"
        android:fragment="com.android.settings.network.NetworkDashboardFragment"
        settings:controller="com.android.settings.network.TopLevelNetworkEntryPreferenceController"/>

    <!--Preference
        android:key="top\_level\_connected\_devices"
        android:title="@string/connected\_devices\_dashboard\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_connected\_device"
        android:order="-110"
        android:fragment="com.android.settings.connecteddevice.ConnectedDeviceDashboardFragment"
        settings:controller="com.android.settings.connecteddevice.TopLevelConnectedDevicesPreferenceController"/-->

    <!--Preference
        android:key="top\_level\_apps\_and\_notifs"
        android:title="@string/app\_and\_notification\_dashboard\_title"
        android:summary="@string/app\_and\_notification\_dashboard\_summary"
        android:icon="@drawable/ic\_homepage\_apps"
        android:order="-100"
        android:fragment="com.android.settings.applications.AppAndNotificationDashboardFragment"/-->

    <!--Preference
        android:key="top\_level\_battery"
        android:title="@string/power\_usage\_summary\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_battery"
        android:fragment="com.android.settings.fuelgauge.PowerUsageSummary"
        android:order="-90"
        settings:controller="com.android.settings.fuelgauge.TopLevelBatteryPreferenceController"/-->

    <Preference
        android:key="top\_level\_display"
        android:title="@string/display\_settings"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_display"
        android:order="-80"
        android:fragment="com.android.settings.DisplaySettings"
        settings:controller="com.android.settings.display.TopLevelDisplayPreferenceController"/>

     <!--Preference
        android:key="top\_level\_timerpower"
        android:title="@string/swtichmachine"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_timerpower"
        android:order="-75"
        android:fragment="com.sprd.settings.timerpower.TimerPower"
        settings:controller="com.sprd.settings.timerpower.TopLevelTimerPowerPreferenceController"/-->

    <Preference
        android:key="top\_level\_sound"
        android:title="@string/sound\_settings"
        android:summary="@string/sound\_dashboard\_summary"
        android:icon="@drawable/ic\_homepage\_sound"
        android:order="-70"
        android:fragment="com.android.settings.notification.SoundSettings"/>

    <!--Preference
        android:key="top\_level\_storage"
        android:title="@string/storage\_settings"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_storage"
        android:order="-60"
        android:fragment="com.android.settings.deviceinfo.StorageSettings"
        settings:controller="com.android.settings.deviceinfo.TopLevelStoragePreferenceController"/-->

    <!--Preference
        android:key="top\_level\_privacy"
        android:title="@string/privacy\_dashboard\_title"
        android:summary="@string/privacy\_dashboard\_summary"
        android:icon="@drawable/ic\_homepage\_privacy"
        android:order="-55"
        android:fragment="com.android.settings.privacy.PrivacyDashboardFragment"/-->

    <!--Preference
        android:key="top\_level\_location"
        android:title="@string/location\_settings\_title"
        android:summary="@string/location\_settings\_loading\_app\_permission\_stats"
        android:icon="@drawable/ic\_homepage\_location"
        android:order="-50"
        android:fragment="com.android.settings.location.LocationSettings"
        settings:controller="com.android.settings.location.TopLevelLocationPreferenceController"/-->

    <!--Preference
        android:key="top\_level\_security"
        android:title="@string/security\_settings\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_security"
        android:order="-40"
        android:fragment="com.android.settings.security.SecuritySettings"
        settings:controller="com.android.settings.security.TopLevelSecurityEntryPreferenceController"/-->

    <!--Preference
        android:key="top\_level\_accounts"
        android:title="@string/account\_dashboard\_title"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_accounts"
        android:order="-30"
        android:fragment="com.android.settings.accounts.AccountDashboardFragment"
        settings:controller="com.android.settings.accounts.TopLevelAccountEntryPreferenceController"/-->

    <!--Preference
        android:key="top\_level\_accessibility"
        android:title="@string/accessibility\_settings"
        android:summary="@string/accessibility\_settings\_summary"
        android:icon="@drawable/ic\_homepage\_accessibility"
        android:order="-20"
        android:fragment="com.android.settings.accessibility.AccessibilitySettings"
        settings:controller="com.android.settings.accessibility.TopLevelAccessibilityPreferenceController"/-->

    <!-- Add for Smart Controls -->
    <!--Preference
        android:key="top\_level\_smartcontrols"
        android:title="@string/smart\_controls"
        android:icon="@drawable/ic\_settings\_smart\_controls"
        android:order="-10"
        android:fragment="com.sprd.settings.smartcontrols.SmartControlsSettings"
        settings:controller="com.sprd.settings.smartcontrols.TopLevelSmartControlsPreferenceController"/-->

    <Preference
        android:key="top\_level\_system"
        android:title="@string/header\_category\_system"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_system\_dashboard"
        android:order="10"
        android:fragment="com.android.settings.system.SystemDashboardFragment"
        settings:controller="com.android.settings.system.TopLevelSystemPreferenceController"/>

    <Preference
        android:key="top\_level\_about\_device"
        android:title="@string/about\_settings"
        android:summary="@string/summary\_placeholder"
        android:icon="@drawable/ic\_homepage\_about"
        android:order="20"
        android:fragment="com.android.settings.deviceinfo.aboutphone.MyDeviceInfoFragment"
        settings:controller="com.android.settings.deviceinfo.aboutphone.TopLevelAboutDevicePreferenceController"/>

    <Preference
        android:key="top\_level\_support"
        android:summary="@string/support\_summary"
        android:title="@string/page\_tab\_title\_support"
        android:icon="@drawable/ic\_homepage\_support"
        android:order="100"
        settings:controller="com.android.settings.support.SupportPreferenceController"/>

</PreferenceScreen>

```

TopLevelSettings.java 修改部分如下:



```
--- a/packages/apps/Settings/src/com/android/settings/homepage/TopLevelSettings.java
+++ b/packages/apps/Settings/src/com/android/settings/homepage/TopLevelSettings.java
@@ -39,7 +39,7 @@ import com.android.settingslib.search.SearchIndexable;
 import android.provider.Settings;
 import java.util.Arrays;
 import java.util.List;
-
+import android.util.Log;
 @SearchIndexable(forTarget = MOBILE)
 public class TopLevelSettings extends DashboardFragment implements
         PreferenceFragmentCompat.OnPreferenceStartFragmentCallback {
@@ -79,7 +79,7 @@ public class TopLevelSettings extends DashboardFragment implements

 
     //重点部分就是这里，根据显示和隐藏 加载不同的页面即可
@Override
     protected int getPreferenceScreenResId() {
-        return R.xml.top_level_settings;
+               int settings_custom = Settings.Global.getInt(getContext().getContentResolver(),"settings\_custom",1);
+        Log.e("Settings","getPreferenceScreenResId---settings\_custom:"+settings_custom);
+        if(settings_custom==1){
+           return R.xml.top_level_settings;
+               }else{
+           return R.xml.top_level_settings_custom;
+               }
     }

```




