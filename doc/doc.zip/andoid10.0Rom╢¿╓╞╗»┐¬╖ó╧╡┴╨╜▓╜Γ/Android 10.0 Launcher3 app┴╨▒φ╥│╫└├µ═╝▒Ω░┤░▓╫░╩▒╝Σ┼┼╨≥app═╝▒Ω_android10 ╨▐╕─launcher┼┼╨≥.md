



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2. Launcher3 app列表页桌面图标按安装时间排序app图标的功能实现分析](#2.%20Launcher3%20app%E5%88%97%E8%A1%A8%E9%A1%B5%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87%E6%8C%89%E5%AE%89%E8%A3%85%E6%97%B6%E9%97%B4%E6%8E%92%E5%BA%8Fapp%E5%9B%BE%E6%A0%87%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E5%88%86%E6%9E%90)


[3.Launcher3 app列表页桌面图标按安装时间排序app图标的主要代码分析](#3.Launcher3%20app%E5%88%97%E8%A1%A8%E9%A1%B5%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87%E6%8C%89%E5%AE%89%E8%A3%85%E6%97%B6%E9%97%B4%E6%8E%92%E5%BA%8Fapp%E5%9B%BE%E6%A0%87%E7%9A%84%E4%B8%BB%E8%A6%81%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 AlphabeticalAppsList.java 相关排序的代码分析](#3.1%20AlphabeticalAppsList.java%20%E7%9B%B8%E5%85%B3%E6%8E%92%E5%BA%8F%E7%9A%84%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 AppInfoComparator相关排序代码分析](#3.2%20AppInfoComparator%E7%9B%B8%E5%85%B3%E6%8E%92%E5%BA%8F%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[4. Launcher3 app列表页桌面图标按安装时间排序app图标的功能实现](#4.%20Launcher3%20app%E5%88%97%E8%A1%A8%E9%A1%B5%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87%E6%8C%89%E5%AE%89%E8%A3%85%E6%97%B6%E9%97%B4%E6%8E%92%E5%BA%8Fapp%E5%9B%BE%E6%A0%87%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)




---



## 1.概述


在定制化开发中，Launcher3相关的定制相关功能也是常有的事情，系统默认的app列表页的Icon是按照app名称排序的，同时也会有各种各样的  
 排序要求，按照安装时间排序app图标就是其中的一种方式，本篇就来简单介绍下按照安装时间排序



## 2. Launcher3 app列表页桌面图标按安装时间排序app图标的功能实现分析


在Launcher3中首选找到排序在哪，然后查看排序方法，通过查询代码发现AlphabeticalAppsList.java 就是负责排序 主要排序的就是  
 Collections.sort(mApps, mAppNameComparator);来负责排序


## 3.Launcher3 app列表页桌面图标按安装时间排序app图标的主要代码分析


#### 3.1 AlphabeticalAppsList.java 相关排序的代码分析



```
public class AlphabeticalAppsList implements AllAppsStore.OnUpdateListener {

    public static final String TAG = "AlphabeticalAppsList";

    private static final int FAST_SCROLL_FRACTION_DISTRIBUTE_BY_ROWS_FRACTION = 0;
    private static final int FAST_SCROLL_FRACTION_DISTRIBUTE_BY_NUM_SECTIONS = 1;

    private static final int sFastScrollDistributionMode = FAST_SCROLL_FRACTION_DISTRIBUTE_BY_NUM_SECTIONS;

    /**
     * Info about a fast scroller section, depending if sections are merged, the fast scroller
     * sections will not be the same set as the section headers.
     */
    public static class FastScrollSectionInfo {
        // The section name
        public String sectionName;
        // The AdapterItem to scroll to for this section
        public AdapterItem fastScrollToItem;
        // The touch fraction that should map to this fast scroll section info
        public float touchFraction;

        public FastScrollSectionInfo(String sectionName) {
            this.sectionName = sectionName;
        }
    }

    /**
     * Info about a particular adapter item (can be either section or app)
     */
    public static class AdapterItem {
        /** Common properties */
        // The index of this adapter item in the list
        public int position;
        // The type of this item
        public int viewType;

        /** App-only properties */
        // The section name of this app.  Note that there can be multiple items with different
        // sectionNames in the same section
        public String sectionName = null;
        // The row that this item shows up on
        public int rowIndex;
        // The index of this app in the row
        public int rowAppIndex;
        // The associated AppInfo for the app
        public AppInfo appInfo = null;
        // The index of this app not including sections
        public int appIndex = -1;
        // The icon view of this app
        BubbleTextView iconView = null;

        public static AdapterItem asApp(int pos, String sectionName, AppInfo appInfo,
                int appIndex) {
            AdapterItem item = new AdapterItem();
            item.viewType = AllAppsGridAdapter.VIEW_TYPE_ICON;
            item.position = pos;
            item.sectionName = sectionName;
            item.appInfo = appInfo;
            item.appIndex = appIndex;
            return item;
        }

        public static AdapterItem asEmptySearch(int pos) {
            AdapterItem item = new AdapterItem();
            item.viewType = AllAppsGridAdapter.VIEW_TYPE_EMPTY_SEARCH;
            item.position = pos;
            return item;
        }

        public static AdapterItem asAllAppsDivider(int pos) {
            AdapterItem item = new AdapterItem();
            item.viewType = AllAppsGridAdapter.VIEW_TYPE_ALL_APPS_DIVIDER;
            item.position = pos;
            return item;
        }

        public static AdapterItem asMarketSearch(int pos) {
            AdapterItem item = new AdapterItem();
            item.viewType = AllAppsGridAdapter.VIEW_TYPE_SEARCH_MARKET;
            item.position = pos;
            return item;
        }

        public static AdapterItem asWorkTabFooter(int pos) {
            AdapterItem item = new AdapterItem();
            item.viewType = AllAppsGridAdapter.VIEW_TYPE_WORK_TAB_FOOTER;
            item.position = pos;
            return item;
        }
    }
    public AlphabeticalAppsList(Context context, AllAppsStore appsStore, boolean isWork) {
        mAllAppsStore = appsStore;
        mLauncher = Launcher.getLauncher(context);
        mIndexer = new AlphabeticIndexCompat(context);
        mAppNameComparator = new AppInfoComparator(context);
        mIsWork = isWork;
        mNumAppsPerRow = mLauncher.getDeviceProfile().inv.numColumns;
        mAllAppsStore.addUpdateListener(this);
    }

    public void updateItemFilter(ItemInfoMatcher itemFilter) {
        this.mItemFilter = itemFilter;
        onAppsUpdated();
    }

/**
     * Updates internals when the set of apps are updated.
     */
    @Override
    public void onAppsUpdated() {
        // Sort the list of apps
        mApps.clear();

        for (AppInfo app : mAllAppsStore.getApps()) {
            if (mItemFilter == null || mItemFilter.matches(app, null) || hasFilter()) {
                mApps.add(app);
            }
        }

        Collections.sort(mApps, mAppNameComparator);

        // As a special case for some languages (currently only Simplified Chinese), we may need to
        // coalesce sections
        Locale curLocale = mLauncher.getResources().getConfiguration().locale;
        boolean localeRequiresSectionSorting = curLocale.equals(Locale.SIMPLIFIED_CHINESE);
        if (localeRequiresSectionSorting) {
            // Compute the section headers. We use a TreeMap with the section name comparator to
            // ensure that the sections are ordered when we iterate over it later
            TreeMap<String, ArrayList<AppInfo>> sectionMap = new TreeMap<>(new LabelComparator());
            for (AppInfo info : mApps) {
                // Add the section to the cache
                String sectionName = getAndUpdateCachedSectionName(info.title);

                // Add it to the mapping
                ArrayList<AppInfo> sectionApps = sectionMap.get(sectionName);
                if (sectionApps == null) {
                    sectionApps = new ArrayList<>();
                    sectionMap.put(sectionName, sectionApps);
                }
                sectionApps.add(info);
            }

            // Add each of the section apps to the list in order
            mApps.clear();
            for (Map.Entry<String, ArrayList<AppInfo>> entry : sectionMap.entrySet()) {
                mApps.addAll(entry.getValue());
            }
        } else {
            // Just compute the section headers for use below
            for (AppInfo info : mApps) {
                // Add the section to the cache
                getAndUpdateCachedSectionName(info.title);
            }
        }

        LauncherAppMonitor.getInstance(mLauncher).onAllAppsListUpdated(mApps);
        // Recompose the set of adapter items from the current set of apps
        updateAdapterItems();
    }

在onAppsUpdated() 中    Collections.sort(mApps, mAppNameComparator);
来负责排序app列表
```

#### 3.2 AppInfoComparator相关排序代码分析



```
 /**
 * A comparator to arrange items based on user profiles.
 */
public class AppInfoComparator implements Comparator<AppInfo> {

    private final UserManagerCompat mUserManager;
    private final UserHandle mMyUser;
    private final LabelComparator mLabelComparator;

    public AppInfoComparator(Context context) {
        mUserManager = UserManagerCompat.getInstance(context);
        mMyUser = Process.myUserHandle();
        mLabelComparator = new LabelComparator();
    }

    @Override
    public int compare(AppInfo a, AppInfo b) {
        // Order by the title in the current locale
        int result = mLabelComparator.compare(a.title.toString(), b.title.toString());
        if (result != 0) {
            return result;
        }

        // If labels are same, compare component names
        result = a.componentName.compareTo(b.componentName);
        if (result != 0) {
            return result;
        }

        if (mMyUser.equals(a.user)) {
            return -1;
        } else {
            Long aUserSerial = mUserManager.getSerialNumberForUser(a.user);
            Long bUserSerial = mUserManager.getSerialNumberForUser(b.user);
            return aUserSerial.compareTo(bUserSerial);
        }
    }
}

在compare(AppInfo a, AppInfo b)中根据title比较进行排序
经过分析 所以具体修改功能 按安装时间排序就是在这里增加功能就可以了
```

## **4. Launcher3 app列表页桌面图标按安装时间排序app图标的功能实现**



```
在AppInfoComparator的主要代码如下:
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
@Override
public int compare(AppInfo a, AppInfo b) {
// Order by the title in the current locale
/int result = mLabelComparator.compare(a.title.toString(), b.title.toString());if (result != 0) {return result;}/
    //add code start
    String a_packagename = a.componentName.getPackageName();
	String b_packagename = b.componentName.getPackageName();
	int result = getInstallTime(a_packagename).compareTo(getInstallTime(b_packagename));
    if (result != 0) {
        return result;
    }
   //add code end

    // If labels are same, compare component names
    result = a.componentName.compareTo(b.componentName);
    if (result != 0) {
        return result;
    }

    if (mMyUser.equals(a.user)) {
        return -1;
    } else {
        Long aUserSerial = mUserManager.getSerialNumberForUser(a.user);
        Long bUserSerial = mUserManager.getSerialNumberForUser(b.user);
        return aUserSerial.compareTo(bUserSerial);
    }
}
//根据包名获取安装时间
public String getInstallTime(String packageName){
	String installtime ="";
	try {
        PackageManager mPackageManager = mContext.getPackageManager();
        PackageInfo packageInfo = mPackageManager.getPackageInfo(packageName,0);
        installtime = packageInfo.firstInstallTime+"";
        android.util.Log.e("MainActivity","packageName:"+packageName+"--installtime:"+installtime);
    } catch (Exception e) {
        e.printStackTrace();
    }
	return installtime;
}
```



