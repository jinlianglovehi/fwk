






在开发板卡系统中，由于每个硬件型号不同，所以在系统中也要修改成相应的型号  
 而在Build.java中各种系统信息都是从系统属性中获取的  
 来看下Build.java的类



```
/**
 * Information about the current build, extracted from system properties.
 */
public class Build {
    private static final String TAG = "Build";

    /** Value used for when a build property is unknown. */
    public static final String UNKNOWN = "unknown";

    /** Either a changelist number, or a label like "M4-rc20". */
    public static final String ID = getString("ro.build.id");

    /** A build ID string meant for displaying to the user */
    public static final String DISPLAY = getString("ro.build.display.id");

    /** The name of the overall product. */
    public static final String PRODUCT = getString("ro.product.name");

    /** The name of the industrial design. */
    public static final String DEVICE = getString("ro.product.device");

    /** The name of the underlying board, like "goldfish". */
    public static final String BOARD = getString("ro.product.board");

    /**
     * The name of the instruction set (CPU type + ABI convention) of native code.
     *
     * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
     */
    @Deprecated
    public static final String CPU_ABI;

    /**
     * The name of the second instruction set (CPU type + ABI convention) of native code.
     *
     * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
     */
    @Deprecated
    public static final String CPU_ABI2;

    /** The manufacturer of the product/hardware. */
    public static final String MANUFACTURER = getString("ro.product.manufacturer");

    /** The consumer-visible brand with which the product/hardware will be associated, if any. */
    public static final String BRAND = getString("ro.product.brand");

    /** The end-user-visible name for the end product. */
    public static final String MODEL = getString("ro.product.model");

    /** The system bootloader version number. */
    public static final String BOOTLOADER = getString("ro.bootloader");

    /**
     * The radio firmware version number.
     *
     * @deprecated The radio firmware version is frequently not
     * available when this class is initialized, leading to a blank or
     * "unknown" value for this string.  Use
     * {@link #getRadioVersion} instead.
     */
    @Deprecated
    public static final String RADIO = getString(TelephonyProperties.PROPERTY_BASEBAND_VERSION);

    /** The name of the hardware (from the kernel command line or /proc). */
    public static final String HARDWARE = getString("ro.hardware");

    /**
     * Whether this build was for an emulator device.
     * @hide
     */
    @TestApi
    public static final boolean IS_EMULATOR = getString("ro.kernel.qemu").equals("1");

    /**
     * A hardware serial number, if available. Alphanumeric only, case-insensitive.
     * This field is always set to {@link Build#UNKNOWN}.
     *
     * @deprecated Use {@link #getSerial()} instead.
     **/
    @Deprecated
    // IMPORTANT: This field should be initialized via a function call to
    // prevent its value being inlined in the app during compilation because
    // we will later set it to the value based on the app's target SDK.
 public static final String SERIAL = getString("no.such.thing");/\*\*
 \* Information about the current build, extracted from system properties.
 \*/
public class Build {
 private static final String TAG = "Build";

 /\*\* Value used for when a build property is unknown. \*/
 public static final String UNKNOWN = "unknown";

 /\*\* Either a changelist number, or a label like "M4-rc20". \*/
 public static final String ID = getString("ro.build.id");

 /\*\* A build ID string meant for displaying to the user \*/
 public static final String DISPLAY = getString("ro.build.display.id");

 /\*\* The name of the overall product. \*/
 public static final String PRODUCT = getString("ro.product.name");

 /\*\* The name of the industrial design. \*/
 public static final String DEVICE = getString("ro.product.device");

 /\*\* The name of the underlying board, like "goldfish". \*/
 public static final String BOARD = getString("ro.product.board");

 /\*\*
 \* The name of the instruction set (CPU type + ABI convention) of native code.
 \*
 \* @deprecated Use {@link #SUPPORTED\_ABIS} instead.
 \*/
 @Deprecated
 public static final String CPU\_ABI;

 /\*\*
 \* The name of the second instruction set (CPU type + ABI convention) of native code.
 \*
 \* @deprecated Use {@link #SUPPORTED\_ABIS} instead.
 \*/
 @Deprecated
 public static final String CPU\_ABI2;

 /\*\* The manufacturer of the product/hardware. \*/
 public static final String MANUFACTURER = getString("ro.product.manufacturer");

 /\*\* The consumer-visible brand with which the product/hardware will be associated, if any. \*/
 public static final String BRAND = getString("ro.product.brand");

 /\*\* The end-user-visible name for the end product. \*/
 public static final String MODEL = getString("ro.product.model");

 /\*\* The system bootloader version number. \*/
 public static final String BOOTLOADER = getString("ro.bootloader");

 /\*\*
 \* The radio firmware version number.
 \*
 \* @deprecated The radio firmware version is frequently not
 \* available when this class is initialized, leading to a blank or
 \* "unknown" value for this string. Use
 \* {@link #getRadioVersion} instead.
 \*/
 @Deprecated
 public static final String RADIO = getString(TelephonyProperties.PROPERTY\_BASEBAND\_VERSION);

 /\*\* The name of the hardware (from the kernel command line or /proc). \*/
 public static final String HARDWARE = getString("ro.hardware");

 /\*\*
 \* Whether this build was for an emulator device.
 \* @hide
 \*/
 @TestApi
 public static final boolean IS\_EMULATOR = getString("ro.kernel.qemu").equals("1");

 /\*\*
 \* A hardware serial number, if available. Alphanumeric only, case-insensitive.
 \* This field is always set to {@link Build#UNKNOWN}.
 \*
 \* @deprecated Use {@link #getSerial()} instead.
 \*\*/
 @Deprecated
 // IMPORTANT: This field should be initialized via a function call to
 // prevent its value being inlined in the app during compilation because
 // we will later set it to the value based on the app's target SDK.
    public static final String SERIAL = getString("no.such.thing");
}

```

从Build.java的源码可以看出 public static final String MODEL = getString(“ro.product.model”);  
 Build.MODEL 的值是从ro.product.model的系统属性中获取的  
 而ro.product.model的值是在build/make/tools/buildinfo\_common.sh和build/make/tools/buildinfo.sh 根据系统信息编译生成的  
 在10.0的版本中，ro.product.model的值是在buildinfo\_common.sh中设置的  
 路径:build/make/tools/buildinfo\_common.sh  
 buildinfo\_common.sh的代码如下:



```
#!/bin/bash

partition="$1"

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <partition>" 1>&2
  exit 1
fi

echo "# begin common build properties"
echo "# autogenerated by $0"

echo "ro.${partition}.build.date=`$DATE`"
echo "ro.${partition}.build.date.utc=`$DATE +%s`"
echo "ro.${partition}.build.fingerprint=$BUILD\_FINGERPRINT"
echo "ro.${partition}.build.id=$BUILD\_ID"
echo "ro.${partition}.build.tags=$BUILD\_VERSION\_TAGS"
echo "ro.${partition}.build.type=$TARGET\_BUILD\_TYPE"
echo "ro.${partition}.build.version.incremental=$BUILD\_NUMBER"
echo "ro.${partition}.build.version.release=$PLATFORM\_VERSION"
echo "ro.${partition}.build.version.sdk=$PLATFORM\_SDK\_VERSION"

echo "ro.product.${partition}.brand=PLOYER "
echo "ro.product.${partition}.device=MID"
echo "ro.product.${partition}.manufacturer=PLOYER"
echo "ro.product.${partition}.model=U8788"
echo "ro.product.${partition}.name=MID"

echo "# end common build properties"

```

从上面的代码可以看出echo “ro.product.${partition}.model=U8788” 就是设置了ro.product.model 和 ro.product.system.model ro.product.vendor.model  
 ro.product.product.model ro.product.odm.model的这几个系统属性的值


所以要修改系统型号model的值 就修改 ro.product.${partition}.model的值就可以了


然后编译固件，烧录固件 发现值已经修改了





