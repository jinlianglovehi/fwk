



## 1.前言


在10.0的系统rom定制化开发中，在一些Launcher3的定制化功能中，有些产品禁用appwidget微件功能，要求Launcher 去掉加载widget微件功能，接下来具体分析下widget微件的加载流程


## 2.Launcher3禁用widget微件功能实现的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/config/BaseFlags.java
packages/apps/Launcher3/src/com/android/launcher3/popup/SystemShortcutFactory.java
```

## 3.Launcher3禁用widget微件功能实现的核心功能分析和实现


Launcher顾名思义,就是桌面的意思,也是android系统启动后第一个启动的应用程序, :Launcher3负责管理和展示用户手机桌面上的各个应用程序图标。它通过GridView或者LinearLayout等布局管理器将 图标进行排列,并支持滑动、放大缩小等手势操作 在Launcher3中SystemShortcutFactory.java中就是具体处理关于长按弹窗布局的， SystemShortcutFactory.java可以看出长按图标时的弹框加载的功能，


## 3.1 BaseFlags.java的相关源码分析


在实现Launcher3禁用widget微件功能实现的核心功能中，通过上述的分析得知， 在BaseFlags.java的相关源码中，这里主要是管理Launcher3的常量类的，接下来看下 关于widget的常量管理类



```
abstract class BaseFlags {
 
     private static final Object sLock = new Object();
     @GuardedBy("sLock")
     private static final List<TogglableFlag> sFlags = new ArrayList<>();
 
     static final String FLAGS_PREF_NAME = "featureFlags";
 
     BaseFlags() {
         throw new UnsupportedOperationException("Don't instantiate BaseFlags");
     }
 
     public static boolean showFlagTogglerUi(Context context) {
         return Utilities.IS_DEBUG_DEVICE && Utilities.isDevelopersOptionsEnabled(context);
     }
 
     public static final boolean IS_DOGFOOD_BUILD = false;
 
     // When enabled the promise icon is visible in all apps while installation an app.
     public static final boolean LAUNCHER3_PROMISE_APPS_IN_ALL_APPS = false;
 
     // Enable moving the QSB on the 0th screen of the workspace
     public static final boolean QSB_ON_FIRST_SCREEN = true;
 
     public static final TogglableFlag EXAMPLE_FLAG = new TogglableFlag("EXAMPLE_FLAG", true,
             "An example flag that doesn't do anything. Useful for testing");
 
     //Feature flag to enable pulling down navigation shade from workspace.
     public static final boolean PULL_DOWN_STATUS_BAR = true;
 
     // When true, custom widgets are loaded using CustomWidgetParser.
     public static final boolean ENABLE_CUSTOM_WIDGETS = false;
 
     // Features to control Launcher3Go behavior
-     public static final boolean GO_DISABLE_WIDGETS = false;
+     public static final boolean GO_DISABLE_WIDGETS = true; 

     // When enabled shows a work profile tab in all apps
     public static final boolean ALL_APPS_TABS_ENABLED = true;
 
     public static final boolean OVERVIEW_USE_SCREENSHOT_ORIENTATION = true;
 
     public static final TogglableFlag APPLY_CONFIG_AT_RUNTIME = new TogglableFlag(
             "APPLY_CONFIG_AT_RUNTIME", true, "Apply display changes dynamically");
 
     public static final TogglableFlag QUICKSTEP_SPRINGS = new TogglableFlag("QUICKSTEP_SPRINGS",
             false, "Enable springs for quickstep animations");
 
      public static final TogglableFlag ADAPTIVE_ICON_WINDOW_ANIM = new TogglableFlag(
              "ADAPTIVE_ICON_WINDOW_ANIM", true,
              "Use adaptive icons for window animations.");
  
      public static final TogglableFlag ENABLE_QUICKSTEP_LIVE_TILE = new TogglableFlag(
              "ENABLE_QUICKSTEP_LIVE_TILE", false, "Enable live tile in Quickstep overview");
  
      public static final TogglableFlag ENABLE_HINTS_IN_OVERVIEW = new TogglableFlag(
              "ENABLE_HINTS_IN_OVERVIEW", false,
              "Show chip hints and gleams on the overview screen");
  
      public static final TogglableFlag FAKE_LANDSCAPE_UI = new TogglableFlag(
              "FAKE_LANDSCAPE_UI", false,
              "Rotate launcher UI instead of using transposed layout");
  
      public static void initialize(Context context) {
          // Avoid the disk read for user builds
          if (Utilities.IS_DEBUG_DEVICE) {
              synchronized (sLock) {
                  for (TogglableFlag flag : sFlags) {
                      flag.initialize(context);
                  }
              }
          }
      }
  
      static List<TogglableFlag> getTogglableFlags() {
          // By Java Language Spec 12.4.2
          // https://docs.oracle.com/javase/specs/jls/se7/html/jls-12.html#jls-12.4.2, the
          // TogglableFlag instances on BaseFlags will be created before those on the FeatureFlags
          // subclass. This code handles flags that are redeclared in FeatureFlags, ensuring the
          // FeatureFlags one takes priority.
          SortedMap<String, TogglableFlag> flagsByKey = new TreeMap<>();
          synchronized (sLock) {
              for (TogglableFlag flag : sFlags) {
                  flagsByKey.put(flag.key, flag);
              }
          }
          return new ArrayList<>(flagsByKey.values());
      }

```

在实现Launcher3禁用widget微件功能实现的核心功能中，通过上述的分析得知，  
 在BaseFlags.java的相关源码中，在上述的这些常量中public static final boolean GO\_DISABLE\_WIDGETS = true;  
 就是设置是否需要Launcher3支持widget功能，所以就可以将这个参数GO\_DISABLE\_WIDGETS  
 设置为true，表示不支持widget功能，这样在laucher中不支持widget功能，接下来  
 就来看下关于长按弹窗中去掉widget的功能


## 3.2 SystemShortcutFactory.java中关于微件的管理分析


在实现Launcher3禁用widget微件功能实现的核心功能中，通过上述的分析得知， 在SystemShortcutFactory.java中的相关源码中主要负责管理长按workspace后，弹窗显示的 应用信息 微件等信息的支持，接下来看下怎么样去掉微件信息的管理



```
 public class SystemShortcutFactory implements ResourceBasedOverride {
  
      public static final MainThreadInitializedObject<SystemShortcutFactory> INSTANCE =
              new MainThreadInitializedObject<>(c -> Overrides.getObject(
                      SystemShortcutFactory.class, c, R.string.system_shortcut_factory_class));
  
      /** Note that these are in order of priority. */
      private final SystemShortcut[] mAllShortcuts;
  
      @SuppressWarnings("unused")
      public SystemShortcutFactory() {
          this(new SystemShortcut.AppInfo(),
                  new SystemShortcut.Widgets(), new SystemShortcut.Install());
      }
  
      protected SystemShortcutFactory(SystemShortcut... shortcuts) {
          mAllShortcuts = shortcuts;
      }
  
      public @NonNull List<SystemShortcut> getEnabledShortcuts(Launcher launcher, ItemInfo info) {
          List<SystemShortcut> systemShortcuts = new ArrayList<>();
          for (SystemShortcut systemShortcut : mAllShortcuts) {
              if (systemShortcut.getOnClickListener(launcher, info) != null) {
                  systemShortcuts.add(systemShortcut);
              }
          }
          return systemShortcuts;
      }
  }
```

在实现Launcher3禁用widget微件功能实现的核心功能中，通过上述的分析得知， 在SystemShortcutFactory.java中的相关源码中，在SystemShortcutFactory()的构造方法中 来添加所有的弹窗布局控件，如this(new SystemShortcut.AppInfo(), new SystemShortcut.Widgets(), new SystemShortcut.Install()); 在这里new SystemShortcut.Widgets()就是添加微件功能，所有就可以去掉这个微件 具体修改如下



```
      @SuppressWarnings("unused")
      public SystemShortcutFactory() {
          this(new SystemShortcut.AppInfo(),
 -                 new SystemShortcut.Widgets(), new SystemShortcut.Install());
+                 new SystemShortcut.Install());
      }
```



