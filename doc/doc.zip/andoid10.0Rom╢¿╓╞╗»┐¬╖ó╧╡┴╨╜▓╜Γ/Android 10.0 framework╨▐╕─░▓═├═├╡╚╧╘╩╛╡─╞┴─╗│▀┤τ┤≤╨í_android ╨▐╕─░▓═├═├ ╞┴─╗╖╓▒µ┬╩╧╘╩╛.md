



## 1.前言


 在10.0的系统开发中，在使用第三方app检测系统的一些信息中，比如安兔兔 设备信息等检测app中，有时候显示的屏幕尺寸大小和  
 产品规格书等信息不同，稍微有些差异，所以就需要看下系统framework层中，相关的设备信息是怎么读出来的，然后做些调整  
 接下来就来分析相关功能


## 2.framework修改安兔兔等显示的屏幕尺寸大小的核心类



```
frameworks/base/core/java/android/view/DisplayInfo.java
```

## 3.framework修改安兔兔等显示的屏幕尺寸大小的核心功能分析和实现


android获取当前设备屏幕信息（分辨率，密度以及物理尺寸）  
 要想知道屏幕的基本信息，就要先获取一个基本的类（DisplayMetics），这个对象存放着当前的窗口的一些通用信息，  
 如显示大小，分辨率和字体等等。  
 而在系统framework中的DisplayInfo.java中，内置这些屏幕的相关属性信息，比如  
 " app 1280 x 672":是指当下可用的屏幕分辨率；  
 “real 1280 x 720”：是指真实的屏幕分辨率；  
 “largest app 1280 x 1207”：是指当前能支持的最大分辨率；  
 “smallest app 720 x 647”：是指当前能支持的最小分辨率；  
 “50.0 fps”：帧频，即屏幕每秒刷新次数；  
 “rotation 0”：转屏，0代表没有旋转；  
 “density 160（160.0 x 160.0）dpi”： density表示每英寸有多少个dp，它的单位是dpi：dot per inch ；


DisplayMetrics{  
 “density”：真实dpi(对角线打印点（dp）/对角线的英寸)与基准dpi(160)的比值；  
  " width":是指当下可用的宽度；  
 “height”：是指当下可用的高度；  
 “scaledDensity”：字体缩放值；  
 “xdpi”：x轴方向上，每英寸的像素数；  
 “ydpi”：y轴方向上，每英寸的像素数；  
 }  
 通过上面的分析 发现在framework层中，关于屏幕的相关信息主要就是通过DisplayMetrics和  
 DisplayInfo中相关属性来获取，接下来看下app中是如何获取屏幕尺寸大小的



```
    public double calcScreenSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        Point point = new Point();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getDisplay().getRealSize(point);
        } else {
            getWindowManager().getDefaultDisplay().getSize(point);
        }
        double w = point.x / metrics.xdpi; // unit is inch
        double h = point.y / metrics.ydpi; // unit is inch
        double size = Math.sqrt(w * w + h * h);
        Log.e(TAG,"x:"+point.x+"---xdpi:"+metrics.xdpi+"--y:"+point.y+"---ydpi:"+metrics.ydpi);
        Log.e(TAG, String.format("Screen size: %.2f", size));
        return size;
    }
```

通过上述的calcScreenSize()可以获取当前屏幕的尺寸大小的值，主要就是通过屏幕的宽高point.x和  
 point.y 屏幕xdpi ydpi的值来计算的屏幕尺寸的值


## 3.1 DisplayInfo.java相关屏幕尺寸的源码分析


framework修改安兔兔等显示的屏幕尺寸大小的核心功能实现中，在通过上述的分析中，得知在关于屏幕尺寸大小的  
 相关参数都是在DisplayMetrics和DisplayInfo中相关属性来获取，系统中由DisplayInfo负责保存这些信息参数，  
 接下来分析下DisplayInfo相关方法和属性



```
    @UnsupportedAppUsage(maxTargetSdk = Build.VERSION_CODES.P, trackingBug = 123769467)
    public DisplayInfo() {
    }

    public DisplayInfo(DisplayInfo other) {
        copyFrom(other);
    }

    private DisplayInfo(Parcel source) {
        readFromParcel(source);
    }
   public void getAppMetrics(DisplayMetrics outMetrics) {
        getAppMetrics(outMetrics, CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO, null);
    }

    public void getAppMetrics(DisplayMetrics outMetrics, DisplayAdjustments displayAdjustments) {
        getMetricsWithSize(outMetrics, displayAdjustments.getCompatibilityInfo(),
                displayAdjustments.getConfiguration(), appWidth, appHeight);
    }

    public void getAppMetrics(DisplayMetrics outMetrics, CompatibilityInfo ci,
            Configuration configuration) {
        getMetricsWithSize(outMetrics, ci, configuration, appWidth, appHeight);
    }

    /**
     * Populates {@code outMetrics} with details of the logical display. Bounds are limited
     * by the logical size of the display.
     *
     * @param outMetrics the {@link DisplayMetrics} to be populated
     * @param compatInfo the {@link CompatibilityInfo} to be applied
     * @param configuration the {@link Configuration}
     */
    public void getLogicalMetrics(DisplayMetrics outMetrics, CompatibilityInfo compatInfo,
            Configuration configuration) {
        getMetricsWithSize(outMetrics, compatInfo, configuration, logicalWidth, logicalHeight);
    }

    /**
     * Similar to {@link #getLogicalMetrics}, but the limiting bounds are determined from
     * {@link WindowConfiguration#getMaxBounds()}
     */
    public void getMaxBoundsMetrics(DisplayMetrics outMetrics, CompatibilityInfo compatInfo,
            Configuration configuration) {
        Rect bounds = configuration.windowConfiguration.getMaxBounds();
        // Pass in null configuration to ensure width and height are not overridden to app bounds.
        getMetricsWithSize(outMetrics, compatInfo, /* configuration= */ null,
                bounds.width(), bounds.height());
    }

    public int getNaturalWidth() {
        return rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180 ?
                logicalWidth : logicalHeight;
    }

    public int getNaturalHeight() {
        return rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180 ?
                logicalHeight : logicalWidth;
    }

    public boolean isHdr() {
        int[] types = hdrCapabilities != null ? hdrCapabilities.getSupportedHdrTypes() : null;
        return types != null && types.length > 0;
    }

    public boolean isWideColorGamut() {
        for (int colorMode : supportedColorModes) {
            if (colorMode == Display.COLOR_MODE_DCI_P3 || colorMode > Display.COLOR_MODE_SRGB) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if the specified UID has access to this display.
     */
    public boolean hasAccess(int uid) {
        return Display.hasAccess(uid, flags, ownerUid, displayId);
    }

    private void getMetricsWithSize(DisplayMetrics outMetrics, CompatibilityInfo compatInfo,
            Configuration configuration, int width, int height) {
        outMetrics.densityDpi = outMetrics.noncompatDensityDpi = logicalDensityDpi;
        outMetrics.density = outMetrics.noncompatDensity =
                logicalDensityDpi * DisplayMetrics.DENSITY_DEFAULT_SCALE;
        outMetrics.scaledDensity = outMetrics.noncompatScaledDensity = outMetrics.density;
        outMetrics.xdpi = outMetrics.noncompatXdpi = physicalXDpi;
        outMetrics.ydpi = outMetrics.noncompatYdpi = physicalYDpi;

        final Rect appBounds = configuration != null
                ? configuration.windowConfiguration.getAppBounds() : null;
        width = appBounds != null ? appBounds.width() : width;
        height = appBounds != null ? appBounds.height() : height;

        outMetrics.noncompatWidthPixels  = outMetrics.widthPixels = width;
        outMetrics.noncompatHeightPixels = outMetrics.heightPixels = height;

        if (!compatInfo.equals(CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO)) {
            compatInfo.applyToDisplayMetrics(outMetrics);
        }
    }
```

framework修改安兔兔等显示的屏幕尺寸大小的核心功能实现中，在通过DisplayInfo.java上述的分析中，  
 getAppMetrics(DisplayMetrics outMetrics, DisplayAdjustments displayAdjustments)等相关的  
 构造方法中都是调用getMetricsWithSize(DisplayMetrics outMetrics, CompatibilityInfo compatInfo,  
             Configuration configuration, int width, int height) 来获取当前屏幕的相关参数，而通过  
 上述的app获取屏幕相关参数来计算屏幕尺寸的方法中，最终是通过outMetrics.xdpi和outMetrics.ydpi  
 等计算的，所以可以修改这两个值来满足相关需求，具体修改为:



```
    private void getMetricsWithSize(DisplayMetrics outMetrics, CompatibilityInfo compatInfo,
            Configuration configuration, int width, int height) {
        outMetrics.densityDpi = outMetrics.noncompatDensityDpi = logicalDensityDpi;
        outMetrics.density = outMetrics.noncompatDensity =
                logicalDensityDpi * DisplayMetrics.DENSITY_DEFAULT_SCALE;
        outMetrics.scaledDensity = outMetrics.noncompatScaledDensity = outMetrics.density;
   -   outMetrics.xdpi = outMetrics.noncompatXdpi = physicalXDpi;
   +     outMetrics.xdpi = 261.49f/*outMetrics.noncompatXdpi = physicalXDpi*/;
        outMetrics.ydpi = outMetrics.noncompatYdpi = physicalYDpi;

        final Rect appBounds = configuration != null
                ? configuration.windowConfiguration.getAppBounds() : null;
        width = appBounds != null ? appBounds.width() : width;
        height = appBounds != null ? appBounds.height() : height;

        outMetrics.noncompatWidthPixels  = outMetrics.widthPixels = width;
        outMetrics.noncompatHeightPixels = outMetrics.heightPixels = height;

        if (!compatInfo.equals(CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO)) {
            compatInfo.applyToDisplayMetrics(outMetrics);
        }
    }
```

framework修改安兔兔等显示的屏幕尺寸大小的核心功能实现中，在通过DisplayInfo.java上述的分析中，  
 在getMetricsWithSize(DisplayMetrics outMetrics, CompatibilityInfo compatInfo,  
             Configuration configuration, int width, int height) 中通过修改outMetrics.xdpi  
 的值来满足计算屏幕尺寸大小的功能



