



## 1.概述


  
   在10.0的系统产品开发中,在Launcher3中系统默认是上滑抽屉模式，通过上滑可以拉出app列表页，产品需求要求改成去掉上滑抽屉模式  
 就是改成单层模式，所以本系列就来讲解下双层改单层系列第一讲


## 2.Launcher3去掉抽屉模式 双层改成单层系列一的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/config/BaseFlags.java
packages/apps/Launcher3/src/com/android/launcher3/model/LoaderTask.java
packages/apps/Launcher3/src/com/android/launcher3/model/AddWorkspaceItemsTask.java
packages/apps/Launcher3/src/com/android/launcher3/InstallShortcutReceiver.java
```

## 3.Launcher3去掉抽屉模式 双层改成单层系列一的核心功能分析和实现


## 


在Launcher3中的去掉抽屉的开发过程中，需要更改的内容  
 1.显示所有app在桌面上  
 2.去掉上划展开应用列表  
 3.长按拖动图标去掉删除改成取消 卸载


在Launcher3的界面的布局的launcher.xml中, 从上往下分别为:DeleteDropTarget(应用卸载区域,它是一个DropTarget)  
 Workspace(页面容器,一个页面是一个CellLayout)  
 PageIndicator(指示器,指示workspace当前位于第几个页面)  
 Hotseat(底部图标区域)


在Launcher3的去掉抽屉式桌面的第一步，需要先设置个抽屉式桌面和单层桌面的开关，就是通过这个变量  
 来控制当前显示抽屉式桌面还是单层桌面的功能，然后在LoaderTask.java中开始绑定桌面app列表的数据，  
 LauncherModel中有一个很重要的方法：startLoader，从startLoader源码中可以看出该方法中创建了LoaderTask用来加载数据，  
 该类实现了Runnable接口，我们直接看它的run方法：  
 最先执行的是loadWorkspace方法，里面是对Workspace的一些加载，包括屏幕数、应用数据、widget组建信息等等


##    3.1 在BaseFlags.java中定义全局变量区分开启单双层模式



```
  abstract class BaseFlags {
  
      private static final Object sLock = new Object();
      @GuardedBy("sLock")
      private static final List<TogglableFlag> sFlags = new ArrayList<>();
  
      static final String FLAGS_PREF_NAME = "featureFlags";
  
      BaseFlags() {
          throw new UnsupportedOperationException("Don't instantiate BaseFlags");
      }
  
      public static boolean showFlagTogglerUi(Context context) {
          return Utilities.IS_DEBUG_DEVICE && Utilities.isDevelopersOptionsEnabled(context);
      }
  
      public static final boolean IS_DOGFOOD_BUILD = false;
  
      // When enabled the promise icon is visible in all apps while installation an app.
      public static final boolean LAUNCHER3_PROMISE_APPS_IN_ALL_APPS = false;
  
      // Enable moving the QSB on the 0th screen of the workspace
      public static final boolean QSB_ON_FIRST_SCREEN = true;
  
      public static final TogglableFlag EXAMPLE_FLAG = new TogglableFlag("EXAMPLE_FLAG", true,
              "An example flag that doesn't do anything. Useful for testing");
  
      //Feature flag to enable pulling down navigation shade from workspace.
      public static final boolean PULL_DOWN_STATUS_BAR = true;
  
      // When true, custom widgets are loaded using CustomWidgetParser.
      public static final boolean ENABLE_CUSTOM_WIDGETS = false;
  
      // Features to control Launcher3Go behavior
      public static final boolean GO_DISABLE_WIDGETS = false;
  
      // When enabled shows a work profile tab in all apps
      public static final boolean ALL_APPS_TABS_ENABLED = true;
  
      // When true, overview shows screenshots in the orientation they were taken rather than
      // trying to make them fit the orientation the device is in.
      public static final boolean OVERVIEW_USE_SCREENSHOT_ORIENTATION = true;

+        //定义单双层模式的开关 true表示双层模式 false表示单层模式
+      public static final boolean IS_SINGLE_MODEL = true;
  .....
}
```

在BaseFlags.java的相关源码中可以看出通过定义 IS\_SINGLE\_MODEL常量来决定当前是单层模式还是双层模式  
 来区分定义整个Launcher3的系统定义


## 3.2 LoaderTask.java中定义加载单层app的相关源码



```
  public void run() {
          synchronized (this) {
              // Skip fast if we are already stopped.
              if (mStopped) {
                  return;
              }
          }
  
          TraceHelper.beginSection(TAG);
          try (LauncherModel.LoaderTransaction transaction = mApp.getModel().beginLoader(this)) {
              TraceHelper.partitionSection(TAG, "step 1.1: loading workspace");
              loadWorkspace();
  
              verifyNotStopped();
              TraceHelper.partitionSection(TAG, "step 1.2: bind workspace workspace");
              mResults.bindWorkspace();
  
              // Notify the installer packages of packages with active installs on the first screen.
              TraceHelper.partitionSection(TAG, "step 1.3: send first screen broadcast");
              sendFirstScreenActiveInstallsBroadcast();
  
              // Take a break
              TraceHelper.partitionSection(TAG, "step 1 completed, wait for idle");
              waitForIdle();
              verifyNotStopped();
  
              // second step
              TraceHelper.partitionSection(TAG, "step 2.1: loading all apps");
              List<LauncherActivityInfo> allActivityList = loadAllApps();

  // add core start
 if(BaseFlags.IS_SINGLE_MODEL){
  binderAppsToWorkspace();
 }
//add core end


      }

// 添加绑定单层app的列表
private void binderAppsToWorkspace() {
        Context context = mApp.getContext();
        ArrayList<Pair<ItemInfo, Object>> iteminfo_list = new ArrayList<>();
        final List<UserHandle> profiles = mUserManager.getUserProfiles();
        for (UserHandle user : profiles) {
            final List<LauncherActivityInfo> apps = mLauncherApps.getActivityList(null, user);
            ArrayList<InstallShortcutReceiver.PendingInstallShortcutInfo> added = new ArrayList<InstallShortcutReceiver.PendingInstallShortcutInfo>();
            synchronized (this) {
                for (LauncherActivityInfo appinfo : apps) {
                    InstallShortcutReceiver.PendingInstallShortcutInfo pendingInstallShortcutInfo = new InstallShortcutReceiver.PendingInstallShortcutInfo(appinfo, context);
                    added.add(pendingInstallShortcutInfo);
                    iteminfo_list .add(pendingInstallShortcutInfo.getItemInfo());
                }
            }
 
            if (!added.isEmpty()) {
                LauncherAppState.getInstance(context).getModel().addAndBindAddedWorkspaceItems(iteminfo_list);
            }
        }
    }
```

最先执行的是 loadAndBindWorkspace()方法,加载和绑定Workspace的数据，包括屏幕数，应用数据，widget组件信息等等，然后调用waitForIdle() 等待loadAndBindWorkspace()里创建的一些子线程执行完，修改mStopped和mLoadAndBindStepFinished的状态后执行loadAndBindAllApps()，加载所有应用，完成整个加载应用的流程。  
 整体流程就是上面的run方法


在LoaderTask.java中的run()中负责加载数据，比如workspace屏幕的folder hotseat app列表等数据，而这里就需要在loadAllApps();后添加  
 加载单层app的数据，然后通过LauncherAppState.getInstance(context).getModel().addAndBindAddedWorkspaceItems(iteminfo\_list);  
 来绑定单层workspace的app列表页的数据，显示单层app列表页


## 3.3 关于PendingInstallShortcutInfo的私有内部类改成公有类


在获取单层app的方法中，需要用到InstallShortcutReceiver.PendingInstallShortcutInfo，作为集合对象  
 而PendingInstallShortcutInfo在InstallShortcutReceiver中是私有的内部类，所以需要修改为:



```
-  private static PendingInstallShortcutInfo createPendingInfo(Context context, Intent data) {
+  public static PendingInstallShortcutInfo createPendingInfo(Context context, Intent data) {
          if (!isValidExtraType(data, Intent.EXTRA_SHORTCUT_INTENT, Intent.class) ||
                  !(isValidExtraType(data, Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                          Intent.ShortcutIconResource.class)) ||
                  !(isValidExtraType(data, Intent.EXTRA_SHORTCUT_ICON, Bitmap.class))) {
  
              if (DBG) Log.e(TAG, "Invalid install shortcut intent");
              return null;
          }
  
          PendingInstallShortcutInfo info = new PendingInstallShortcutInfo(
                  data, Process.myUserHandle(), context);
          if (info.launchIntent == null || info.label == null) {
              if (DBG) Log.e(TAG, "Invalid install shortcut intent");
              return null;
          }
  
          return convertToLauncherActivityIfPossible(info);
      }
```



