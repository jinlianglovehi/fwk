



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.屏蔽短信功能(短信发送开关)的核心类](#2.%E5%B1%8F%E8%94%BD%E7%9F%AD%E4%BF%A1%E5%8A%9F%E8%83%BD%28%E7%9F%AD%E4%BF%A1%E5%8F%91%E9%80%81%E5%BC%80%E5%85%B3%29%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.屏蔽短信功能(短信发送开关)的核心功能分析和实现](#3.%E5%B1%8F%E8%94%BD%E7%9F%AD%E4%BF%A1%E5%8A%9F%E8%83%BD%28%E7%9F%AD%E4%BF%A1%E5%8F%91%E9%80%81%E5%BC%80%E5%85%B3%29%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0)


[SmsManager.java是负责发送短信的管理类，调](#SmsManager.java%E6%98%AF%E8%B4%9F%E8%B4%A3%E5%8F%91%E9%80%81%E7%9F%AD%E4%BF%A1%E7%9A%84%E7%AE%A1%E7%90%86%E7%B1%BB%EF%BC%8C%E8%B0%83)


[smsManager.sendTextMessage();](#smsManager.sendTextMessage%28%29%3B)




---



## 1.概述


在10.0的产品定制化开发中,由于开发的是wifi产品，需要去掉产品的短信功能，就是去掉系统短信发送功能，这就要从发送短信的流程中来分析了


## 2.屏蔽短信功能(短信发送开关)的核心类



```
frameworks/opt/telephony/src/java/com/android/internal/telephony/SMSDispatcher.java
frameworks/base/telephony/java/android/telephony/SmsMessage.java
frameworks/opt/telephony/src/java/com/android/internal/telephony/IccSmsInterfaceManager.java
frameworks/opt/telephony/src/java/com/android/internal/telephony/SmsDispatchersController.java
```

## 3.屏蔽短信功能(短信发送开关)的核心功能分析和实现


功能分析:


#### SmsManager.java是负责发送短信的管理类，调


#### smsManager.sendTextMessage();


就可以发送短信了



```
      @UnsupportedAppUsage
      public void sendTextMessage(
              String destinationAddress, String scAddress, String text,
              PendingIntent sentIntent, PendingIntent deliveryIntent,
              int priority, boolean expectMore, int validityPeriod) {
          sendTextMessageInternal(destinationAddress, scAddress, text, sentIntent, deliveryIntent,
                  true /* persistMessage*/, priority, expectMore, validityPeriod);
      }
  
      private void sendTextMessageInternal(
              String destinationAddress, String scAddress, String text,
              PendingIntent sentIntent, PendingIntent deliveryIntent, boolean persistMessage,
              int priority, boolean expectMore, int validityPeriod) {
          if (TextUtils.isEmpty(destinationAddress)) {
              throw new IllegalArgumentException("Invalid destinationAddress");
          }
  
          if (TextUtils.isEmpty(text)) {
              throw new IllegalArgumentException("Invalid message body");
          }
  
          if (priority < 0x00 || priority > 0x03) {
              priority = SMS_MESSAGE_PRIORITY_NOT_SPECIFIED;
          }
  
          if (validityPeriod < 0x05 || validityPeriod > 0x09b0a0) {
              validityPeriod = SMS_MESSAGE_PERIOD_NOT_SPECIFIED;
          }
  
          final int finalPriority = priority;
          final int finalValidity = validityPeriod;
          final Context context = ActivityThread.currentApplication().getApplicationContext();
          // We will only show the SMS disambiguation dialog in the case that the message is being
          // persisted. This is for two reasons:
          // 1) Messages that are not persisted are sent by carrier/OEM apps for a specific
          //    subscription and require special permissions. These messages are usually not sent by
          //    the device user and should not have an SMS disambiguation dialog associated with them
          //    because the device user did not trigger them.
          // 2) The SMS disambiguation dialog ONLY checks to make sure that the user has the SEND_SMS
          //    permission. If we call resolveSubscriptionForOperation from a carrier/OEM app that has
          //    the correct MODIFY_PHONE_STATE or carrier permissions, but no SEND_SMS, it will throw
          //    an incorrect SecurityException.
          if (persistMessage) {
              resolveSubscriptionForOperation(new SubscriptionResolverResult() {
                  @Override
                  public void onSuccess(int subId) {
                      try {
                          ISms iSms = getISmsServiceOrThrow();
                          if (iSms != null) {
                              iSms.sendTextForSubscriberWithOptions(subId,
                                      ActivityThread.currentPackageName(), destinationAddress,
                                      scAddress,
                                      text, sentIntent, deliveryIntent, persistMessage, finalPriority,
                                      expectMore, finalValidity);
                          }
                      } catch (RemoteException e) {
                          Log.e(TAG, "sendTextMessageInternal: Couldn't send SMS, exception - "
                                  + e.getMessage());
                          notifySmsGenericError(sentIntent);
                      }
                  }
  
                  @Override
                  public void onFailure() {
                      notifySmsErrorNoDefaultSet(context, sentIntent);
                  }
              });
          } else {
              try {
                  ISms iSms = getISmsServiceOrThrow();
                  if (iSms != null) {
                      iSms.sendTextForSubscriberWithOptions(getSubscriptionId(),
                              ActivityThread.currentPackageName(), destinationAddress,
                              scAddress,
                              text, sentIntent, deliveryIntent, persistMessage, finalPriority,
                              expectMore, finalValidity);
                  }
              } catch (RemoteException e) {
                  Log.e(TAG, "sendTextMessageInternal(no persist): Couldn't send SMS, exception - "
                          + e.getMessage());
                  notifySmsGenericError(sentIntent);
              }
          }
      }
```

从源码中可以看出在SmsManager调用的sendTextMessage()继续调用


IccSmsInterfaceManager.java的 sendText()方法继续发送短信通知，所以需要继续看


IccSmsInterfaceManager.java的 sendText()的源码分析问题  
    



```
public void sendText(String callingPackage, String destAddr, String scAddr,
            String text, PendingIntent sentIntent, PendingIntent deliveryIntent,
            boolean persistMessageForNonDefaultSmsApp) {
        sendTextInternal(callingPackage, destAddr, scAddr, text, sentIntent, deliveryIntent,
                persistMessageForNonDefaultSmsApp, SMS_MESSAGE_PRIORITY_NOT_SPECIFIED,
                false /* expectMore */, SMS_MESSAGE_PERIOD_NOT_SPECIFIED, false /* isForVvm */);
    }


    public void sendTextWithSelfPermissions(String callingPackage, String destAddr, String scAddr,
            String text, PendingIntent sentIntent, PendingIntent deliveryIntent,
            boolean persistMessage, boolean isForVvm) {
        if (!mSmsPermissions.checkCallingOrSelfCanSendSms(callingPackage, "Sending SMS message")) {
            returnUnspecifiedFailure(sentIntent);
            return;
        }
        sendTextInternal(callingPackage, destAddr, scAddr, text, sentIntent, deliveryIntent,
                persistMessage, SMS_MESSAGE_PRIORITY_NOT_SPECIFIED, false /* expectMore */,
                SMS_MESSAGE_PERIOD_NOT_SPECIFIED, isForVvm);
    }

  

    private void sendTextInternal(String callingPackage, String destAddr, String scAddr,
            String text, PendingIntent sentIntent, PendingIntent deliveryIntent,
            boolean persistMessageForNonDefaultSmsApp, int priority, boolean expectMore,
            int validityPeriod, boolean isForVvm) {
        if (Rlog.isLoggable("SMS", Log.VERBOSE)) {
            log("sendText: destAddr=" + destAddr + " scAddr=" + scAddr
                    + " text='" + text + "' sentIntent=" + sentIntent + " deliveryIntent="
                    + deliveryIntent + " priority=" + priority + " expectMore=" + expectMore
                    + " validityPeriod=" + validityPeriod + " isForVVM=" + isForVvm);
        }
        destAddr = filterDestAddress(destAddr);
        mDispatchersController.sendText(destAddr, scAddr, text, sentIntent, deliveryIntent,
                null/*messageUri*/, callingPackage, persistMessageForNonDefaultSmsApp,
                priority, expectMore, validityPeriod, isForVvm);
    }
```

在通过上述源码发现IccSmsInterfaceManager.java的 sendText()的相关发送短信流程发现，最后是调用了SmsDispatchersController的sendText()发送短信，


接下来看SmsDispatchersController的sendText()的源码



```
    public void sendText(String destAddr, String scAddr, String text, PendingIntent sentIntent,
            PendingIntent deliveryIntent, Uri messageUri, String callingPkg, boolean persistMessage,
            int priority, boolean expectMore, int validityPeriod, boolean isForVvm) {
        if (mImsSmsDispatcher.isAvailable() || mImsSmsDispatcher.isEmergencySmsSupport(destAddr)) {
            mImsSmsDispatcher.sendText(destAddr, scAddr, text, sentIntent, deliveryIntent,
                    messageUri, callingPkg, persistMessage, SMS_MESSAGE_PRIORITY_NOT_SPECIFIED,
                    false /*expectMore*/, SMS_MESSAGE_PERIOD_NOT_SPECIFIED, isForVvm);
        } else {
            if (isCdmaMo()) {
                mCdmaDispatcher.sendText(destAddr, scAddr, text, sentIntent, deliveryIntent,
                        messageUri, callingPkg, persistMessage, priority, expectMore,
                        validityPeriod, isForVvm);
            } else {
                mGsmDispatcher.sendText(destAddr, scAddr, text, sentIntent, deliveryIntent,
                        messageUri, callingPkg, persistMessage, priority, expectMore,
                        validityPeriod, isForVvm);
            }
        }
    }
```

又调用 GsmSMSDispatcher类mDispatche的sendText()


继续往下看 调用SMSDispatcher的 sendSubmitPdu()方法 完成发送功能


接下来看的相关源码



```
     @UnsupportedAppUsage
      private void sendSubmitPdu(SmsTracker tracker) {
          if (shouldBlockSmsForEcbm()) {
              Rlog.d(TAG, "Block SMS in Emergency Callback mode");
              tracker.onFailed(mContext, SmsManager.RESULT_ERROR_NO_SERVICE, 0/*errorCode*/);
          } else {
              sendRawPdu(tracker);
          }
      }
    @VisibleForTesting
      public void sendRawPdu(SmsTracker tracker) {
          HashMap map = tracker.getData();
          byte pdu[] = (byte[]) map.get(MAP_KEY_PDU);
  
          if (mSmsSendDisabled) {
              Rlog.e(TAG, "Device does not support sending sms.");
              tracker.onFailed(mContext, RESULT_ERROR_NO_SERVICE, 0/*errorCode*/);
              return;
          }
  
          if (pdu == null) {
              Rlog.e(TAG, "Empty PDU");
              tracker.onFailed(mContext, RESULT_ERROR_NULL_PDU, 0/*errorCode*/);
              return;
          }
  
          String packageName = tracker.getAppPackageName();
          PackageManager pm = mContext.getPackageManager();
  
          // Get package info via packagemanager
          PackageInfo appInfo;
          try {
              appInfo = pm.getPackageInfoAsUser(
                      packageName, PackageManager.GET_SIGNATURES, tracker.mUserId);
          } catch (PackageManager.NameNotFoundException e) {
              Rlog.e(TAG, "Can't get calling app package info: refusing to send SMS");
              tracker.onFailed(mContext, RESULT_ERROR_GENERIC_FAILURE, 0/*errorCode*/);
              return;
          }
  
          // checkDestination() returns true if the destination is not a premium short code or the
          // sending app is approved to send to short codes. Otherwise, a message is sent to our
          // handler with the SmsTracker to request user confirmation before sending.
          if (checkDestination(tracker)) {
              // check for excessive outgoing SMS usage by this app
              if (!mSmsDispatchersController.getUsageMonitor().check(
                      appInfo.packageName, SINGLE_PART_SMS)) {
                  sendMessage(obtainMessage(EVENT_SEND_LIMIT_REACHED_CONFIRMATION, tracker));
                  return;
              }
  
              sendSms(tracker);
          }
  
          if (PhoneNumberUtils.isLocalEmergencyNumber(mContext, tracker.mDestAddress)) {
              new AsyncEmergencyContactNotifier(mContext).execute();
          }
      }
```

通过上述对发送短信源码分析最后是在SMSDispatcher的 sendSubmitPdu()方法具体完成短信的发送的，所以说屏蔽短信的发送可以在这里进行控制


具体修改如下:



```
--- a/frameworks/opt/telephony/src/java/com/android/internal/telephony/SMSDispatcher.java
+++ b/frameworks/opt/telephony/src/java/com/android/internal/telephony/SMSDispatcher.java
@@ -83,7 +83,8 @@ import com.android.internal.telephony.cdma.sms.UserData;
 import com.android.internal.telephony.gsm.GsmSMSDispatcher;
 import com.android.internal.telephony.uicc.UiccCard;
 import com.android.internal.telephony.uicc.UiccController;
-
+import android.provider.Settings;
+import android.util.Log;
 import java.util.ArrayList;
 import java.util.HashMap;
 import java.util.List;
@@ -646,6 +647,14 @@ public abstract class SMSDispatcher extends Handler {
      */
     @UnsupportedAppUsage
     private void sendSubmitPdu(SmsTracker tracker) {
+           boolean isIntercept = Settings.Global.getInt(mContext.getContentResolver(),
+                "roco_sms_disable", 0) == 1;
+               Log.d("dong","getBlockStatus:"+isIntercept);
+               if(isIntercept){
+                         Rlog.d(TAG, "Block SMS in Emergency Callback mode");
+            tracker.onFailed(mContext, SmsManager.RESULT_ERROR_NO_SERVICE, 0/*errorCode*/);
+            return ;
+                               }
         if (shouldBlockSmsForEcbm()) {
             Rlog.d(TAG, "Block SMS in Emergency Callback mode");
             tracker.onFailed(mContext, SmsManager.RESULT_ERROR_NO_SERVICE, 0/*errorCode*/);
```



