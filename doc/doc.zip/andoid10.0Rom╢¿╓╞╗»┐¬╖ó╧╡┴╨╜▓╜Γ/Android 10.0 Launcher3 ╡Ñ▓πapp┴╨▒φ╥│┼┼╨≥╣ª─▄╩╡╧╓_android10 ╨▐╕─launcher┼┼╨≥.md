



## 1.概述


在定制化开发中，对于Launcher3的功能定制也是好多的，而对于单层app列表页来说排序功能的开发，也是常有的功能这就需要了解加载app数据的流程，然后根据需要进行排序就可以了，


如图:


![](https://img-blog.csdnimg.cn/b859a143d6cd4188a74939a8d7b31df8.png)


##  2. Launcher3 单层app列表页排序功能实现



```

       packages\apps\Launcher3\src\com\android\launcher3\Launcher.java
       packages\apps\Launcher3\src\com\android\launcher3\LauncherModel.java
       packages\apps\Launcher3\src\com\android\launcher3\LoaderTask.java
       packages\apps\Launcher3\src\com\android\launcher3\LauncherProvider.java
```

## 3. Launcher3 单层app列表页排序功能实现


###   3.1 Launcher.java关于app加载的相关代码



```
      public class Launcher extends BaseDraggingActivity implements LauncherExterns,
            LauncherModel.Callbacks, LauncherProviderChangeListener, UserEventDelegate,
            InvariantDeviceProfile.OnIDPChangeListener {
        public static final String TAG = "Launcher";
        static final boolean LOGD = false;
     
        static final boolean DEBUG_STRICT_MODE = false;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
            
     
            mAppMonitor = LauncherAppMonitor.getInstance(this);
            mAppMonitor.onLauncherPreCreate(this);
     
            super.onCreate(savedInstanceState);
            TraceHelper.partitionSection("Launcher-onCreate", "super call");
     
            LauncherAppState app = LauncherAppState.getInstance(this);
            mOldConfig = new Configuration(getResources().getConfiguration());
            mModel = app.setLauncher(this);
            mRotationHelper = new RotationHelper(this);
            InvariantDeviceProfile idp = app.getInvariantDeviceProfile();
            initDeviceProfile(idp);
            idp.addOnChangeListener(this);
            mSharedPrefs = Utilities.getPrefs(this);
            mIconCache = app.getIconCache();
            mAccessibilityDelegate = new LauncherAccessibilityDelegate(this);
     
            mDragController = new DragController(this);
            mAllAppsController = new AllAppsTransitionController(this);
            mStateManager = new LauncherStateManager(this);
            UiFactory.onCreate(this);
     
            mAppWidgetManager = AppWidgetManagerCompat.getInstance(this);
     
            mAppWidgetHost = new LauncherAppWidgetHost(this);
            mAppWidgetHost.startListening();
     
            mLauncherView = LayoutInflater.from(this).inflate(R.layout.launcher, null);
     
            setupViews();
            mPopupDataProvider = new PopupDataProvider(this);
     
            mAppTransitionManager = LauncherAppTransitionManager.newInstance(this);
     
            boolean internalStateHandled = InternalStateHandler.handleCreate(this, getIntent());
            if (internalStateHandled) {
                if (savedInstanceState != null) {
                    // InternalStateHandler has already set the appropriate state.
                    // We dont need to do anything.
                    savedInstanceState.remove(RUNTIME_STATE);
                }
            }
            restoreState(savedInstanceState);
            mStateManager.reapplyState();
     
            // We only load the page synchronously if the user rotates (or triggers a
            // configuration change) while launcher is in the foreground
            int currentScreen = PagedView.INVALID_RESTORE_PAGE;
            if (savedInstanceState != null) {
                currentScreen = savedInstanceState.getInt(RUNTIME_STATE_CURRENT_SCREEN, currentScreen);
                mWorkspace.restoreSavedInstanceState(savedInstanceState);
            }
     
            if (!mModel.startLoader(currentScreen)) {
                if (!internalStateHandled) {
                    // If we are not binding synchronously, show a fade in animation when
                    // the first page bind completes.
                    mDragLayer.getAlphaProperty(ALPHA_INDEX_LAUNCHER_LOAD).setValue(0);
                }
            } else {
                // Pages bound synchronously.
                mWorkspace.setCurrentPage(currentScreen);
     
                setWorkspaceLoading(true);
            }
     
            // For handling default keys
            setDefaultKeyMode(DEFAULT_KEYS_SEARCH_LOCAL);
     
            setContentView(mLauncherView);
            getRootView().dispatchInsets();
     
            // Listen for broadcasts
            registerReceiver(mScreenOffReceiver, new IntentFilter(Intent.ACTION_SCREEN_OFF));
     
            ....
        }
```

而代码中的  
  if (!mModel.startLoader(currentScreen)) {  
             if (!internalStateHandled) {  
                 // If we are not binding synchronously, show a fade in animation when  
                 // the first page bind completes.  
                 mDragLayer.getAlphaProperty(ALPHA\_INDEX\_LAUNCHER\_LOAD).setValue(0);  
             }  
         } else {  
             // Pages bound synchronously.  
             mWorkspace.setCurrentPage(currentScreen);


            setWorkspaceLoading(true);  
         }  
 负责开始加载workspace相关数据


### 3.2 LauncherModel中关于加载数据的方法



```
/**
         * Starts the loader. Tries to bind {@params synchronousBindPage} synchronously if possible.
         * @return true if the page could be bound synchronously.
         */
        public boolean startLoader(int synchronousBindPage) {
            // Enable queue before starting loader. It will get disabled in Launcher#finishBindingItems
            InstallShortcutReceiver.enableInstallQueue(InstallShortcutReceiver.FLAG_LOADER_RUNNING);
            synchronized (mLock) {
                // Don't bother to start the thread if we know it's not going to do anything
                if (mCallbacks != null && mCallbacks.get() != null) {
                    final Callbacks oldCallbacks = mCallbacks.get();
                    // Clear any pending bind-runnables from the synchronized load process.
                    mUiExecutor.execute(oldCallbacks::clearPendingBinds);
     
                    // If there is already one running, tell it to stop.
                    stopLoader();
                    LoaderResults loaderResults = new LoaderResults(mApp, sBgDataModel,
                            mBgAllAppsList, synchronousBindPage, mCallbacks);
                    if (mModelLoaded && !mIsLoaderTaskRunning) {
                        // Divide the set of loaded items into those that we are binding synchronously,
                        // and everything else that is to be bound normally (asynchronously).
                        loaderResults.bindWorkspace();
                        // For now, continue posting the binding of AllApps as there are other
                        // issues that arise from that.
                        loaderResults.bindAllApps();
                        loaderResults.bindDeepShortcuts();
                        loaderResults.bindWidgets();
                        return true;
                    } else {
                        startLoaderForResults(loaderResults);
                    }
                }
            }
            return false;
        }
        public void startLoaderForResults(LoaderResults results) {
            synchronized (mLock) {
                stopLoader();
                mLoaderTask = new LoaderTask(mApp, mBgAllAppsList, sBgDataModel, results);
     
                // Always post the loader task, instead of running directly (even on same thread) so
                // that we exit any nested synchronized blocks
                sWorker.post(mLoaderTask);
            }
        }
```

在LauncherModel的相关方法中发现最后在run（）中加载和绑定workspace的数据



```
private void loadWorkspace() {
       ....
     
                            case LauncherSettings.Favorites.ITEM_TYPE_FOLDER:
                                FolderInfo folderInfo = mBgDataModel.findOrMakeFolder(c.id);
                                c.applyCommonProperties(folderInfo);
     
                                // Do not trim the folder label, as is was set by the user.
                                folderInfo.title = c.getString(c.titleIndex);
                                folderInfo.spanX = 1;
                                folderInfo.spanY = 1;
                                folderInfo.options = c.getInt(optionsIndex);
     
                                // no special handling required for restored folders
                                c.markRestored();
     
                                c.checkAndAddItem(folderInfo, mBgDataModel);
                                break;
     
                            case LauncherSettings.Favorites.ITEM_TYPE_APPWIDGET:
                                if (FeatureFlags.GO_DISABLE_WIDGETS) {
                                    c.markDeleted("Only legacy shortcuts can have null package");
                                    continue;
                                }
                                // Follow through
                            .....
            }
        }
     
            LogUtils.d(TAG, "loadWorkspace: loading default favorites");
            LauncherSettings.Settings.call(contentResolver,
                    LauncherSettings.Settings.METHOD_LOAD_DEFAULT_FAVORITES);
```

调用LauncherProvider的loadDefaultFavoritesIfNecessary()方法,此方法比较简单,有很详细的注解,主要功能就是读取客制化主界面的配置文件,保存到数据库


### 3.3 LauncherProvider关于加载默认数据方法



```
/**
         * Loads the default workspace based on the following priority scheme:
         * 1) From the app restrictions
         * 2) From a package provided by play store
         * 3) From a partner configuration APK, already in the system image
         * 4) The default configuration for the particular device
         */
        synchronized private void loadDefaultFavoritesIfNecessary() {
     
            if (getFlagEmptyDbCreated(getContext(), mOpenHelper.getDatabaseName())) {
                Log.d(TAG, "loading default workspace");
     
                AppWidgetHost widgetHost = mOpenHelper.newLauncherWidgetHost();
                AutoInstallsLayout loader = createWorkspaceLoaderFromAppRestriction(widgetHost);
                if (loader == null) {
                    loader = AutoInstallsLayout.get(getContext(), widgetHost, mOpenHelper);
                }
                if (loader == null) {
                    final Partner partner = Partner.get(getContext().getPackageManager());
                    if (partner != null && partner.hasDefaultLayout()) {
                        final Resources partnerRes = partner.getResources();
                        int workspaceResId = partnerRes.getIdentifier(Partner.RES_DEFAULT_LAYOUT,
                                "xml", partner.getPackageName());
                        if (workspaceResId != 0) {
                            loader = new DefaultLayoutParser(getContext(), widgetHost,
                                    mOpenHelper, partnerRes, workspaceResId);
                        }
                    }
                }
     
                final boolean usingExternallyProvidedLayout = loader != null;
                if (loader == null) {
                    loader = getDefaultLayoutParser(widgetHost);
                }
     
                // There might be some partially restored DB items, due to buggy restore logic in
                // previous versions of launcher.
                mOpenHelper.createEmptyDB(mOpenHelper.getWritableDatabase());
                // Populate favorites table with initial favorites
                if ((mOpenHelper.loadFavorites(mOpenHelper.getWritableDatabase(), loader) <= 0)
                        && usingExternallyProvidedLayout) {
                    // Unable to load external layout. Cleanup and load the internal layout.
                    mOpenHelper.createEmptyDB(mOpenHelper.getWritableDatabase());
                    mOpenHelper.loadFavorites(mOpenHelper.getWritableDatabase(),
                            getDefaultLayoutParser(widgetHost));
                }
                clearFlagEmptyDbCreated(getContext(), mOpenHelper.getDatabaseName());
            }
        }
```

这段代码  
 final Resources partnerRes = partner.getResources();  
                     int workspaceResId = partnerRes.getIdentifier(Partner.RES\_DEFAULT\_LAYOUT,  
                             "xml", partner.getPackageName());  
                     if (workspaceResId != 0) {  
                         loader = new DefaultLayoutParser(getContext(), widgetHost,  
                                 mOpenHelper, partnerRes, workspaceResId);  
                     }  
 就是解析默认xml的数据来加载到数据库


Partner.RES\_DEFAULT\_LAYOUT就是res/xml/partner\_default\_layout.xml 文件


### 3.4 Launcher3 单层app列表页排序功能具体实现



```
    修改partner_default_layout.xml的布局排序
       <favorites xmlns:launcher="http://schemas.android.com/apk/res-auto/com.android.launcher3">
     
     
        <appwidget
        launcher:packageName="com.android.deskclock"
        launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"
        launcher:screen="0"
        launcher:x="1"
        launcher:y="1"
        launcher:spanX="4"
        launcher:spanY="2" 
      />
     
        <!-- Hotseat (We use the screen as the position of the item in the hotseat) -->
        <!-- Dialer, Messaging, Browser, Camera -->
     
        <resolve
            launcher:container="-101"
            launcher:screen="0"
            launcher:x="0"
            launcher:y="0" >
            <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_MAPS;end" />
            <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_MUSIC;end" />
        </resolve>
     
        <resolve
            launcher:container="-101"
            launcher:screen="1"
            launcher:x="1"
            launcher:y="0" >
            <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_GALLERY;end" />
            <favorite launcher:uri="#Intent;type=images/*;end" />
        </resolve>
     
        <favorite
            launcher:container="-101"
            launcher:screen="2"
            launcher:x="2"
            launcher:y="0" 
            launcher:packageName="com.android.documentsui"
            launcher:className="com.android.documentsui.LauncherActivity"/>
     
     
        <resolve
            launcher:container="-101"
            launcher:screen="3"
            launcher:x="3"
            launcher:y="0" >
            <favorite launcher:uri="#Intent;action=android.media.action.STILL_IMAGE_CAMERA;end" />
            <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA_BUTTON;end" />
        </resolve>
     
        <resolve
            launcher:container="-101"
            launcher:screen="4"
            launcher:x="4"
            launcher:y="0" >
            <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end"/>
        </resolve>
     
        <!-- <resolve
            launcher:container="-101"
            launcher:screen="3"
            launcher:x="3"
            launcher:y="0" >
            <favorite launcher:uri="#Intent;action=android.media.action.STILL_IMAGE_CAMERA;end" />
            <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA_BUTTON;end" />
        </resolve> -->
     
        <!-- Bottom row -->
        <!-- Email, Gallery, Music, Settings -->
        <!-- <resolve
            launcher:screen="0"
            launcher:x="0"
            launcher:y="-1" >
            <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_EMAIL;end" />
            <favorite launcher:uri="mailto:" />
        </resolve>
        <resolve
            launcher:screen="0"
            launcher:x="1"
            launcher:y="-1" >
            <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_GALLERY;end" />
            <favorite launcher:uri="#Intent;type=images/*;end" />
        </resolve>
        <resolve
            launcher:screen="0"
            launcher:x="-2"
            launcher:y="-1" >
            <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_MUSIC;end" />
        </resolve>
        <resolve
            launcher:screen="0"
            launcher:x="-1"
            launcher:y="-1" >
            <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end" />
        </resolve> -->
     
        <favorite
            launcher:screen="1"
            launcher:x="0"
            launcher:y="0" 
            launcher:packageName="com.android.music"
            launcher:className="com.android.music.MusicBrowserActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="1"
            launcher:y="0" 
            launcher:packageName="com.android.deskclock"
            launcher:className="com.android.deskclock.DeskClock"
            />
        <favorite
            launcher:screen="1"
            launcher:x="2"
            launcher:y="0" 
            launcher:packageName="com.android.soundrecorder"
            launcher:className="com.sprd.soundrecorder.RecorderActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="3"
            launcher:y="0" 
            launcher:packageName="com.android.calendar"
            launcher:className="com.android.calendar.AllInOneActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="4"
            launcher:y="0" 
            launcher:packageName="com.sprd.sprdnote"
            launcher:className="com.sprd.sprdnote.NoteActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="5"
            launcher:y="0" 
            launcher:packageName="com.android.calculator2"
            launcher:className="com.android.calculator2.Calculator"
            />
     
        <!--favorite
            launcher:screen="1"
            launcher:x="0"
            launcher:y="1" 
            launcher:packageName="com.android.calendar"
            launcher:className="com.android.calendar.AllInOneActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="1"
            launcher:y="1" 
            launcher:packageName="com.android.deskclock"
            launcher:className="com.android.deskclock.DeskClock"
            />
        <favorite
            launcher:screen="1"
            launcher:x="2"
            launcher:y="1" 
            launcher:packageName="com.android.calculator2"
            launcher:className="com.android.calculator2.Calculator"
            /-->
        <favorite
            launcher:screen="1"
            launcher:x="3"
            launcher:y="1" 
            launcher:packageName="com.android.fmradio"
            launcher:className="com.android.fmradio.FmMainActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="4"
            launcher:y="1" 
            launcher:packageName="com.android.quicksearchbox"
            launcher:className="com.android.quicksearchbox.SearchActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="5"
            launcher:y="1" 
            launcher:packageName="com.tencent.android.qqdownloader"
            launcher:className="com.tencent.pangu.link.SplashActivity"
            />
        <favorite
            launcher:screen="1"
            launcher:x="0"
            launcher:y="2" 
            launcher:packageName="com.sprd.sprdnote"
            launcher:className="com.sprd.sprdnote.widget.NoteAppWidgetProvider"
            />
        <favorite
            launcher:screen="1"
            launcher:x="1"
            launcher:y="2" 
            launcher:packageName="com.android.dialer"
            launcher:className="com.android.dialer.app.calllog.CallLogActivity"
            />
        <!--favorite
            launcher:screen="1"
            launcher:x="2"
            launcher:y="2" 
            launcher:packageName="com.android.dialer"
            launcher:className=""
            /-->
     
    </favorites>
```

根据自己的需要排序  
     favorite:应用程序快捷方式。  
     shortcut:链接，如网址，本地磁盘路径等。  
     search:搜索框。  
     clock:桌面上的钟表Widget  
        
     //支持的属性有：  
     launcher:title:图标下面的文字，目前只支持引用，不能直接书写字符串;  
     launcher:icon:图标引用;  
     launcher:uri:链接地址,链接网址用的，使用shortcut标签就可以定义一个超链接，打开某个网址。  
     launcher:packageName:应用程序的包名;  
     launcher:className:应用程序的启动类名;  
     launcher:screen:图标所在的屏幕编号，从0开始表示在第几屏;  
     launcher:x:图标在横向排列上的序号;  
     launcher:y:图标在纵向排列上的序号;  
        
     //例如：  
     <appwidget  
         launcher:packageName="com.android.deskclock" //应用包名  
         launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"         //该应用的类名  
         launcher:screen="1"             //第1屏,0-4屏共5屏  
         launcher:x="2"                      //图标X位置,左上角第一个为0,向左递增,0-4共5个  
         launcher:y="1"                                                 //图标Y位置,左上角第一个为0,向下递增,0-2共3个  
         launcher:spanX="3"                                             //在x方向上所占格数  
         launcher:spanY="2" />                                          //在y方向上所占格数



