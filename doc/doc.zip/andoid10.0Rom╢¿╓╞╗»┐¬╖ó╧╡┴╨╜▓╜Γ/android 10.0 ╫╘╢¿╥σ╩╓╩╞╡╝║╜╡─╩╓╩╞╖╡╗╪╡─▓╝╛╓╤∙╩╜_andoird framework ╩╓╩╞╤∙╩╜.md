






### 1.概述


在android 原生系统中 有三键导航和手势导航，当默认为手势导航时，手势返回的布局样式就是一个左箭头 感觉不是太美观，所以需要自定义手势返回的布局


### 2.自定义手势导航的手势返回的布局样式的核心代码



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/EdgeBackGestureHandler.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarEdgePanel.java

```

### 3.自定义手势导航的手势返回的布局样式功能分析和实现


### 3.1关于手势导航中返回布局的代码分析


在NavigationBarView.java中通过加载mEdgeBackGestureHandler来构建手势导航的基本功能  
 先来查看NavigationBarView.java的源码



```
public NavigationBarView(Context context, AttributeSet attrs) {
    super(context, attrs);
    mIsVertical = false;
    mLongClickableAccessibilityButton = false;
    mNavBarMode = Dependency.get(NavigationModeController.class).addListener(this);
    /* UNISCO: Bug 1072090,1116092 new feature of dynamic navigationbar @{*/
    mSupportDynamicBar = isSupportDynamicNavBar(mContext, mNavBarMode);
    /* }@ */
    boolean isGesturalMode = isGesturalMode(mNavBarMode);
    // Set up the context group of buttons
    mContextualButtonGroup = new ContextualButtonGroup(R.id.menu_container);
    final ContextualButton imeSwitcherButton = new ContextualButton(R.id.ime_switcher,
            R.drawable.ic_ime_switcher_default);
    final RotationContextButton rotateSuggestionButton = new RotationContextButton(
            R.id.rotate_suggestion, R.drawable.ic_sysbar_rotate_button);
    final ContextualButton accessibilityButton =
            new ContextualButton(R.id.accessibility_button,
                    R.drawable.ic_sysbar_accessibility_button);
    mContextualButtonGroup.addButton(imeSwitcherButton);
    if (!isGesturalMode) {
        mContextualButtonGroup.addButton(rotateSuggestionButton);
    }
    mContextualButtonGroup.addButton(accessibilityButton);
    mKeyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
    mOverviewProxyService = Dependency.get(OverviewProxyService.class);
    mRecentsOnboarding = new RecentsOnboarding(context, mOverviewProxyService);
    mFloatingRotationButton = new FloatingRotationButton(context);
    mRotationButtonController = new RotationButtonController(context,
            R.style.RotateButtonCCWStart90,
            isGesturalMode ? mFloatingRotationButton : rotateSuggestionButton);
    final ContextualButton backButton = new ContextualButton(R.id.back, 0);
    mConfiguration = new Configuration();
    mTmpLastConfiguration = new Configuration();
    mConfiguration.updateFrom(context.getResources().getConfiguration());
    mScreenPinningNotify = new ScreenPinningNotify(mContext);
    mBarTransitions = new NavigationBarTransitions(this);
    mButtonDispatchers.put(R.id.back, backButton);
    mButtonDispatchers.put(R.id.home, new ButtonDispatcher(R.id.home));
    mButtonDispatchers.put(R.id.home_handle, new ButtonDispatcher(R.id.home_handle));
    mButtonDispatchers.put(R.id.recent_apps, new ButtonDispatcher(R.id.recent_apps));
    mButtonDispatchers.put(R.id.ime_switcher, imeSwitcherButton);
    mButtonDispatchers.put(R.id.accessibility_button, accessibilityButton);
    mButtonDispatchers.put(R.id.rotate_suggestion, rotateSuggestionButton);
    mButtonDispatchers.put(R.id.menu_container, mContextualButtonGroup);
    mDeadZone = new DeadZone(this);
    /* UNISOC: Bug 1072090 new feature of dynamic navigationbar @{ */
    if(mSupportDynamicBar){
        mStatusBar = SysUiServiceProvider.getComponent(getContext(), StatusBar.class);
        mButtonDispatchers.put(R.id.hide, new ButtonDispatcher(R.id.hide));
        mButtonDispatchers.put(R.id.pull, new ButtonDispatcher(R.id.pull));
    }
    /* }@ */
    mEdgeBackGestureHandler = new EdgeBackGestureHandler(context, mOverviewProxyService);
    mTintController = new NavBarTintController(this, getLightTransitionsController());
}

```

在构造方法中实例化EdgeBackGestureHandler 而就是手势的相关类，通过调用mEdgeBackGestureHandler的相关方法来实现手势的相关功能


在看EdgeBackGestureHandler.java类源码


### 3.2EdgeBackGestureHandler.java关于手势相关代码分析


先看EdgeBackGestureHandler.java的构造方法这里初始化手势导航的相关功能



```
public EdgeBackGestureHandler(Context context, OverviewProxyService overviewProxyService) {
final Resources res = context.getResources();
mContext = context;
mDisplayId = context.getDisplayId();
mMainExecutor = context.getMainExecutor();
mWm = context.getSystemService(WindowManager.class);
mOverviewProxyService = overviewProxyService;
// Reduce the default touch slop to ensure that we can intercept the gesture
// before the app starts to react to it.
// TODO(b/130352502) Tune this value and extract into a constant
mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop() * 0.75f;
mLongPressTimeout = Math.min(MAX_LONG_PRESS_TIMEOUT,
ViewConfiguration.getLongPressTimeout());
mNavBarHeight = res.getDimensionPixelSize(R.dimen.navigation_bar_frame_height);
mMinArrowPosition = res.getDimensionPixelSize(R.dimen.navigation_edge_arrow_min_y);
mFingerOffset = res.getDimensionPixelSize(R.dimen.navigation_edge_finger_offset);
updateCurrentUserResources(res);
}
public void updateCurrentUserResources(Resources res) {
mEdgeWidth = res.getDimensionPixelSize(
com.android.internal.R.dimen.config_backGestureInset);
}
/**
* @see NavigationBarView#onAttachedToWindow()
*/
public void onNavBarAttached() {
mIsAttached = true;
updateIsEnabled();
}

private void updateIsEnabled() {
boolean isEnabled = mIsAttached && mIsGesturalModeEnabled;
if (isEnabled == mIsEnabled) {
return;
}
mIsEnabled = isEnabled;
disposeInputChannel();
if (mEdgePanel != null) {
mWm.removeView(mEdgePanel);
mEdgePanel = null;
mRegionSamplingHelper.stop();
mRegionSamplingHelper = null;
}
if (!mIsEnabled) {
WindowManagerWrapper.getInstance().removePinnedStackListener(mImeChangedListener);
mContext.getSystemService(DisplayManager.class).unregisterDisplayListener(this);
try {
WindowManagerGlobal.getWindowManagerService()
.unregisterSystemGestureExclusionListener(
mGestureExclusionListener, mDisplayId);
} catch (RemoteException e) {
Log.e(TAG, "Failed to unregister window manager callbacks", e);
}
} else {
updateDisplaySize();
mContext.getSystemService(DisplayManager.class).registerDisplayListener(this,
mContext.getMainThreadHandler());
try {
WindowManagerWrapper.getInstance().addPinnedStackListener(mImeChangedListener);
WindowManagerGlobal.getWindowManagerService()
.registerSystemGestureExclusionListener(
mGestureExclusionListener, mDisplayId);
} catch (RemoteException e) {
Log.e(TAG, "Failed to register window manager callbacks", e);
}
// Register input event receiver
mInputMonitor = InputManager.getInstance().monitorGestureInput(
"edge-swipe", mDisplayId);
mInputEventReceiver = new SysUiInputEventReceiver(
mInputMonitor.getInputChannel(), Looper.getMainLooper());
// Add a nav bar panel window
mEdgePanel = new NavigationBarEdgePanel(mContext);
mEdgePanelLp = new WindowManager.LayoutParams(
mContext.getResources()
.getDimensionPixelSize(R.dimen.navigation_edge_panel_width),
mContext.getResources()
.getDimensionPixelSize(R.dimen.navigation_edge_panel_height),
WindowManager.LayoutParams.TYPE_NAVIGATION_BAR_PANEL,
WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
| WindowManager.LayoutParams.FLAG_SPLIT_TOUCH
| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
PixelFormat.TRANSLUCENT);
mEdgePanelLp.privateFlags |=
WindowManager.LayoutParams.PRIVATE_FLAG_SHOW_FOR_ALL_USERS;
mEdgePanelLp.setTitle(TAG + mDisplayId);
mEdgePanelLp.accessibilityTitle = mContext.getString(R.string.nav_bar_edge_panel);
mEdgePanelLp.windowAnimations = 0;
mEdgePanel.setLayoutParams(mEdgePanelLp);
mWm.addView(mEdgePanel, mEdgePanelLp);
mRegionSamplingHelper = new RegionSamplingHelper(mEdgePanel,
new RegionSamplingHelper.SamplingCallback() {
@Override
public void onRegionDarknessChanged(boolean isRegionDark) {
mEdgePanel.setIsDark(!isRegionDark, true /* animate */);
}
@Override
public Rect getSampledRegion(View sampledView) {
return mSamplingRect;
}
});
}
}

```

onNavBarAttached()绑定手势布局的相关方法中，通过updateIsEnabled()调用mEdgePanel来进行手势导航返回布局方面的绘制  
 继续查看private NavigationBarEdgePanel mEdgePanel的相关代码


### 3.3NavigationBarEdgePanel手势布局返回代码分析



```
public NavigationBarEdgePanel(Context context) {
        super(context);

        mVibratorHelper = Dependency.get(VibratorHelper.class);

        mDensity = context.getResources().getDisplayMetrics().density;

        mBaseTranslation = dp(BASE_TRANSLATION_DP);
        mArrowLength = dp(ARROW_LENGTH_DP);
        mArrowThickness = dp(ARROW_THICKNESS_DP);
        mMinDeltaForSwitch = dp(32);

        mPaint.setStrokeWidth(mArrowThickness);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);

        mArrowColorAnimator = ValueAnimator.ofFloat(0.0f, 1.0f);
        mArrowColorAnimator.setDuration(COLOR_ANIMATION_DURATION_MS);
        mArrowColorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int newColor = ColorUtils.blendARGB(mArrowStartColor, mArrowColor,
                        animation.getAnimatedFraction());
                setCurrentArrowColor(newColor);
            }
        });

        mArrowDisappearAnimation = ValueAnimator.ofFloat(0.0f, 1.0f);
        mArrowDisappearAnimation.setDuration(DISAPPEAR_ARROW_ANIMATION_DURATION_MS);
        mArrowDisappearAnimation.setInterpolator(Interpolators.FAST_OUT_SLOW_IN);
        mArrowDisappearAnimation.addUpdateListener(animation -> {
            mDisappearAmount = (float) animation.getAnimatedValue();
            invalidate();
        });

        mAngleAnimation =
                new SpringAnimation(this, CURRENT_ANGLE);
        mAngleAppearForce = new SpringForce()
                .setStiffness(500)
                .setDampingRatio(0.5f);
        mAngleDisappearForce = new SpringForce()
                .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                .setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY)
                .setFinalPosition(90);
        mAngleAnimation.setSpring(mAngleAppearForce).setMaxValue(90);

        mTranslationAnimation =
                new SpringAnimation(this, CURRENT_TRANSLATION);
        mRegularTranslationSpring = new SpringForce()
                .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY);
        mTriggerBackSpring = new SpringForce()
                .setStiffness(450)
                .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY);
        mTranslationAnimation.setSpring(mRegularTranslationSpring);
        mVerticalTranslationAnimation =
                new SpringAnimation(this, CURRENT_VERTICAL_TRANSLATION);
        mVerticalTranslationAnimation.setSpring(
                new SpringForce()
                        .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                        .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY));

        mProtectionPaint = new Paint(mPaint);
        mProtectionPaint.setStrokeWidth(mArrowThickness + PROTECTION_WIDTH_PX);
        loadDimens();

        loadColors(context);
        updateArrowDirection();

        mSwipeThreshold = context.getResources()
                .getDimension(R.dimen.navigation_edge_action_drag_threshold);
        setVisibility(GONE);
    }

@Override
protected void onDraw(Canvas canvas) {
    float pointerPosition = mCurrentTranslation - mArrowThickness / 2.0f;
    canvas.save();
    canvas.translate(
            mIsLeftPanel ? pointerPosition : getWidth() - pointerPosition,
            (getHeight() * 0.5f) + mVerticalTranslation);
    // Let's calculate the position of the end based on the angle
    float x = (polarToCartX(mCurrentAngle) * mArrowLength);
    float y = (polarToCartY(mCurrentAngle) * mArrowLength);
    Path arrowPath = calculatePath(x,y);
    if (mShowProtection) {
        canvas.drawPath(arrowPath, mProtectionPaint);
    }
    canvas.drawPath(arrowPath, mPaint);
    canvas.restore();
}

可以看到onDraw()负责绘制手势的布局 修改就从这里开始
修改布局代码如下:
private float[][] mArray;
private static final int CUSTOM_ARROW_LENGTH_DP = 11;
private static final float CUSTOM_ARROW_THICKNESS_DP = 1.5f;
mArray = (float[][]) Array.newInstance(Float.TYPE, new int[]{50, 2});
mArrowLength = dp(CUSTOM_ARROW_LENGTH_DP);

mArrowThickness = dp(CUSTOM_ARROW_THICKNESS_DP);


protected void onDraw(Canvas canvas) 中添加如下代码
  int i;

 float[][] fArr;

 float f;

 Path cosPath = new Path();

Paint bgPaint = new Paint();

bgPaint.setAntiAlias(true);

bgPaint.setStyle(Paint.Style.FILL_AND_STROKE);

bgPaint.setStrokeWidth(1.0f);

 bgPaint.setColor(0x88000000);

 int bgHeight = getHeight();

 int bgWidth = getWidth();

 if (mIsLeftPanel) {

cosPath.moveTo(0.0f, 0.0f);

for (i = 0; i < 50; i++) {

   fArr = mArray;

   fArr[i][1] = (((float) bgHeight) / 50.0f) \* ((float) (i + 1));

   fArr[i][0] = (float) ((((double) (mCurrentTranslation / 2.0f)) * Math.cos(((((double) fArr[i][1]) \* 6.283185307179586d) / ((double) bgHeight)) + 3.141592653589793d))

       + ((double) (mCurrentTranslation / 2.0f)));

          }

      } else {

          cosPath.moveTo((float) bgWidth, 0.0f);

 for (i = 0; i < 50; i++) {

 fArr = mArray;

 fArr[i][1] = (((float) bgHeight) / 50.0f) \* ((float) (i + 1));

              fArr[i][0] = ((float) bgWidth) - ((float) ((((double) (mCurrentTranslation / 2.0f)) * Math.cos(((((double) fArr[i][1]) \* 6.283185307179586d) / ((double) bgHeight)) + 3.141592653589793d)) + ((double) (mCurrentTranslation / 2.0f))));

          }

       }

     for (i = 0; i < 48; i += 2) {

          fArr = mArray;

           cosPath.quadTo(fArr[i + 1][0], fArr[i + 1][1], fArr[i + 2][0], fArr[i + 2][1]);

      }

     if (mIsLeftPanel) {

           f = 0.0f;

       } else {

           f = ((float) bgWidth) + 0.0f;

 }

 cosPath.lineTo(f, ((float) bgHeight) + 0.0f);

 canvas.drawPath(cosPath, bgPaint);

 //arrow

 float x = (polarToCartX(mCurrentAngle) \* mArrowLength);

 float y = (polarToCartY(mCurrentAngle) \* mArrowLength);

 float pointerPosition = mCurrentTranslation - mArrowThickness / 2.0f;

 canvas.save();

 Path arrowPath = calculatePath(x,y);

 if (mShowProtection) {

 canvas.drawPath(arrowPath, mProtectionPaint);
 }

 if (mIsLeftPanel) {

 f = (mArray[25][0] - x) \* 0.5f;

 } else {

 f = mArray[25][0] + ((((float) getWidth()) - mArray[25][0]) * 0.5f);

      }

       canvas.translate(f, (((float) getHeight()) * 0.5f) + mVerticalTranslation);

      canvas.drawPath(arrowPath, mPaint);

      canvas.restore();

```

在onDraw（）中进行手势导航返回布局的绘制所以可以在这里进行自定义手势导航布局的定义，  
 具体修改补丁为:



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarEdgePanel.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarEdgePanel.java
@@ -45,7 +45,9 @@ import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.FloatPropertyCompat;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;
+// add for edge core begin
+import java.lang.reflect.Array;
+// add for edge core end
public class NavigationBarEdgePanel extends View {
 private static final long COLOR_ANIMATION_DURATION_MS = 120;

@@ -192,6 +194,12 @@ public class NavigationBarEdgePanel extends View {
private long mVibrationTime;
private int mScreenSize;
//add for edge back new style begin
private float[][] mArray;
private static final int CUSTOM_ARROW_LENGTH_DP = 11;
private static final float CUSTOM_ARROW_THICKNESS_DP = 1.5f;
//add for edge back new style end
private DynamicAnimation.OnAnimationEndListener mSetGoneEndListener
= new DynamicAnimation.OnAnimationEndListener() {
@Override
@@ -251,8 +259,20 @@ public class NavigationBarEdgePanel extends View {
mDensity = context.getResources().getDisplayMetrics().density;   mBaseTranslation = dp(BASE_TRANSLATION_DP);

   mArrowLength = dp(ARROW_LENGTH_DP);

   mArrowThickness = dp(ARROW_THICKNESS_DP);

   // add for edge back new style begin

   //mArrowLength = dp(ARROW_LENGTH_DP);

   //mArrowThickness = dp(ARROW_THICKNESS_DP);


       mArray = (float[][]) Array.newInstance(Float.TYPE, new int[]{50, 2});

       mArrowLength = dp(CUSTOM_ARROW_LENGTH_DP);

       mArrowThickness = dp(CUSTOM_ARROW_THICKNESS_DP);


   // add for edge back new style end

   mMinDeltaForSwitch = dp(32);

   mPaint.setStrokeWidth(mArrowThickness);

@@ -426,6 +446,8 @@ public class NavigationBarEdgePanel extends View {
 @Override
 protected void onDraw(Canvas canvas) {

   // add for edge back new style begin

   /*

   float pointerPosition = mCurrentTranslation - mArrowThickness / 2.0f;
   canvas.save();
   canvas.translate(

@@ -442,6 +464,85 @@ public class NavigationBarEdgePanel extends View {
     canvas.drawPath(arrowPath, mPaint);
     canvas.restore();
*/


       //bg

       int i;

       float[][] fArr;

       float f;

       Path cosPath = new Path();

       Paint bgPaint = new Paint();

       bgPaint.setAntiAlias(true);

       bgPaint.setStyle(Paint.Style.FILL_AND_STROKE);

       bgPaint.setStrokeWidth(1.0f);

       bgPaint.setColor(0x88000000);

       int bgHeight = getHeight();

       int bgWidth = getWidth();

       if (mIsLeftPanel) {

           cosPath.moveTo(0.0f, 0.0f);

           for (i = 0; i < 50; i++) {

               fArr = mArray;

               fArr[i][1] = (((float) bgHeight) / 50.0f) \* ((float) (i + 1));

               fArr[i][0] = (float) ((((double) (mCurrentTranslation / 2.0f)) * Math.cos(((((double) fArr[i][1]) \* 6.283185307179586d) / ((double) bgHeight)) + 3.141592653589793d))

                   + ((double) (mCurrentTranslation / 2.0f)));

           }

       } else {

           cosPath.moveTo((float) bgWidth, 0.0f);

 for (i = 0; i < 50; i++) {

 fArr = mArray;

 fArr[i][1] = (((float) bgHeight) / 50.0f) \* ((float) (i + 1));

               fArr[i][0] = ((float) bgWidth) - ((float) ((((double) (mCurrentTranslation / 2.0f)) * Math.cos(((((double) fArr[i][1]) \* 6.283185307179586d) / ((double) bgHeight)) + 3.141592653589793d)) + ((double) (mCurrentTranslation / 2.0f))));

           }

       }

       for (i = 0; i < 48; i += 2) {

           fArr = mArray;

           cosPath.quadTo(fArr[i + 1][0], fArr[i + 1][1], fArr[i + 2][0], fArr[i + 2][1]);

       }

       if (mIsLeftPanel) {

           f = 0.0f;

       } else {

           f = ((float) bgWidth) + 0.0f;

 }

 cosPath.lineTo(f, ((float) bgHeight) + 0.0f);

 canvas.drawPath(cosPath, bgPaint);

 //arrow

 float x = (polarToCartX(mCurrentAngle) \* mArrowLength);

 float y = (polarToCartY(mCurrentAngle) \* mArrowLength);

 float pointerPosition = mCurrentTranslation - mArrowThickness / 2.0f;

 canvas.save();

 Path arrowPath = calculatePath(x,y);

 if (mShowProtection) {

 canvas.drawPath(arrowPath, mProtectionPaint);

 }

 if (mIsLeftPanel) {

 f = (mArray[25][0] - x) \* 0.5f;

 } else {

 f = mArray[25][0] + ((((float) getWidth()) - mArray[25][0]) * 0.5f);

       }

       canvas.translate(f, (((float) getHeight()) * 0.5f) + mVerticalTranslation);

       canvas.drawPath(arrowPath, mPaint);

       canvas.restore();

}

```




