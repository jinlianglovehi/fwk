



## 1. 概述


在10.0的rom系统开发定制化中，在系统SystemUI的下拉状态栏中，产品开发功能需求要求添加黑白模式功能开关的功能，就是打开黑白模式，系统颜色就会变成黑白颜色，  
 关闭黑白模式开关系统就会变成彩色模式，所以就需要了解下系统是怎么设置黑白模式和彩色模式的，然后添加到systemui的下拉状态栏的功能开关里面，接下来先  
 查看系统是怎么实现黑白模式功能的，然后实现功能


效果图如图:


![](https://img-blog.csdnimg.cn/3b25d543549e415abec6ddea7454ccb7.png)


## 2. 系统开启和关闭黑白模式主题功能实现的核心类



```
     frameworks/base/packages/SettingsLib/res/values/arrays.xml
     packages/apps/Settings/res/xml/development_settings.xml
     packages/apps/Settings/src/com/android/settings/development/SimulateColorSpacePreferenceController.java
```

## 3.系统开启和关闭黑白模式主题功能实现的核心功能分析和实现


在通过阅读10.0的系统源码,发现原来在系统Settings开发中，就很多关于系统的各种样式的设置模块，经过相关搜寻发现可以在模拟颜色空间的相关模式中通过相关的设置可以切换彩色和黑白模式，然后选择彩色模式 就进入彩色模式，所以就来看下这段代码，然后来实现系统黑白模式功能,接下来就来分析下  
 关于系统开发者模式的相关布局来实现功能


## 3.1 development\_settings.xml中关于模拟颜色空间的相关布局



```
          <PreferenceCategory
            android:key="debug_hw_drawing_category"
            android:title="@string/debug_hw_drawing_category"
            android:order="700">
     
            <SwitchPreference
                android:key="show_hw_screen_updates"
                android:title="@string/show_hw_screen_updates"
                android:summary="@string/show_hw_screen_updates_summary" />

     
            <ListPreference
                android:entries="@array/simulate_color_space_entries"
                android:entryValues="@array/simulate_color_space_values"
                android:key="simulate_color_space"
                android:summary="%s"
                android:title="@string/simulate_color_space" />
     
        </PreferenceCategory>

```

在系统设置的开发者模式的布局文件development\_settings.xml的上述的方法中，可以看出simulate\_color\_space就是模拟颜色空间对应的ListPreference下拉选择控件，可以通过下拉选择项来设置对应的


系统黑白模式，和彩色模式 等等模式，而@array/simulate\_color\_space\_entries和@array/simulate\_color\_space\_values就是对应的模拟颜色空间的系统颜色模式的


选择项和系统颜色模式的值，接下来看下array.xml中对应的颜色空间的值



```
     <!-- Display color space adjustment modes for developers -->
        <string-array name="simulate_color_space_entries" translatable="false">
            <item>@string/daltonizer_mode_disabled</item>
            <item>@string/daltonizer_mode_monochromacy</item>
            <item>@string/daltonizer_mode_deuteranomaly</item>
            <item>@string/daltonizer_mode_protanomaly</item>
            <item>@string/daltonizer_mode_tritanomaly</item>
        </string-array>
     
        <!-- Values for display color space adjustment modes for developers -->
        <string-array name="simulate_color_space_values" translatable="false">
            <item>-1</item>
            <item>0</item>
            <item>2</item>
            <item>1</item>
            <item>3</item>
        </string-array>
```

在 frameworks/base/packages/SettingsLib/res/values/arrays.xml的上述的代码中，可以看出系统颜色模式对应的simulate\_color\_space\_entries和simulate\_color\_space\_values


就是设置系统颜色模式对应的选择项和颜色模式的值，而@string/daltonizer\_mode\_monochromacy就是全色盲即黑白模式对应的值为0，而@string/daltonizer\_mode\_disabled


就是系统彩色模式对应的值为-1，接下来看下系统settings里面是如何设置黑白模式的


## 3.2 SimulateColorSpacePreferenceController.java中关于设置黑白模式的相关代码分析



```
    public class SimulateColorSpacePreferenceController extends DeveloperOptionsPreferenceController
            implements Preference.OnPreferenceChangeListener, PreferenceControllerMixin {
     
        private static final String SIMULATE_COLOR_SPACE = "simulate_color_space";
     
        @VisibleForTesting
        static final int SETTING_VALUE_OFF = 0;
        @VisibleForTesting
        static final int SETTING_VALUE_ON = 1;
     
        public SimulateColorSpacePreferenceController(Context context) {
            super(context);
        }
     
        @Override
        public String getPreferenceKey() {
            return SIMULATE_COLOR_SPACE;
        }
     
        @Override
        public boolean onPreferenceChange(Preference preference, Object newValue) {
            writeSimulateColorSpace(newValue);
            return true;
        }

```

在SimulateColorSpacePreferenceController.java上述的方法中，可以看出onPreferenceChange(Preference preference, Object newValue)就是在ListPreference控件  
 选择其他值，在值改变的时候调用writeSimulateColorSpace(newValue);来设置系统颜色模式的值，所以可以通过查看writeSimulateColorSpace(newValue);的  
 相关源码来分析设置系统颜色模式的功能



```
        @Override
        public void updateState(Preference preference) {
            updateSimulateColorSpace();
        }
     
        @Override
        public void onDeveloperOptionsDisabled() {
            super.onDeveloperOptionsDisabled();
            if (usingDevelopmentColorSpace()) {
                writeSimulateColorSpace(-1);
            }
        }
```

在SimulateColorSpacePreferenceController.java上述的方法中，可以看出在onDeveloperOptionsDisabled()关闭其他颜色模式设置系统彩色模式的时候，调用  
 writeSimulateColorSpace(-1);就可以设置系统为彩色模式即可



```
       private void writeSimulateColorSpace(Object value) {
            final ContentResolver cr = mContext.getContentResolver();
            final int newMode = Integer.parseInt(value.toString());
            if (newMode < 0) {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED,
                        SETTING_VALUE_OFF);
            } else {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED,
                        SETTING_VALUE_ON);
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER, newMode);
            }
        }
```

在SimulateColorSpacePreferenceController.java上述的方法中，可以看出在writeSimulateColorSpace(Object value)中，主要是通过  
 Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY\_DISPLAY\_DALTONIZER\_ENABLED来设置是否开启模拟颜色空间的功能，设置系统黑白模式就设置为1，  
 关闭模拟颜色空间功能就设置为-1 ，然后在通过Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY\_DISPLAY\_DALTONIZER, newMode);  
 来设置具体的颜色空间的值，黑白模式就设置为0 即可，所以通过上面的功能分析可以得知开启和关闭系统黑白模式功能可以这样实现



```
       private void blackAndWhiteMode(boolean isOpen) {
            final ContentResolver cr = mContext.getContentResolver();
            if (!isOpen) {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED,
                        0);
            } else {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED,
                        1);
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER, 0);
            }
        }

        private void blackAndWhiteMode(boolean isOpen) {
            final ContentResolver cr = mContext.getContentResolver();
            if (!isOpen) {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED,
                        0);
            } else {
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED,
                        1);
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER, 0);
            }
        }
```



