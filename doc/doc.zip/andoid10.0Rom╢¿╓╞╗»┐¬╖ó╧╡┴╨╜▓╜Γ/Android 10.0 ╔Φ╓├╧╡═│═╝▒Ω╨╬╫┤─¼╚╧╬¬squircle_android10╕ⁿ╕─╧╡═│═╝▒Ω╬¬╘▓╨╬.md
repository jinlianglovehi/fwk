






在android系统中，图标形状分为teardrop,squircle,square,roundedrect和默认图标，客户需求要求设置默认图标形状为squircle  
 如图：


![在这里插入图片描述](https://img-blog.csdnimg.cn/981a2d85ab9e4088b29ae3e8cac30816.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBA5a6J5Y2T5YW86IGMZnJhbWV3b3Jr5bqU55So5bel56iL5biI,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center)


而在开发者模式中，刚好有修改图标形状的ListPreference 可以做参考


于是就来查看OverlayCategoryPreferenceController.java的源码  
 路径为:


接下来看具体源码



```
private boolean setOverlay(String packageName) {
        final String currentPackageName = getOverlayInfos().stream()
                .filter(info -> info.isEnabled())
                .map(info -> info.packageName)
                .findFirst()
                .orElse(null);
        if (PACKAGE_DEVICE_DEFAULT.equals(packageName) && TextUtils.isEmpty(currentPackageName)
                || TextUtils.equals(packageName, currentPackageName)) {
            // Already set.
            return true;
        }

        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... params) {
                try {
                    if (PACKAGE_DEVICE_DEFAULT.equals(packageName)) {
                        return mOverlayManager.setEnabled(currentPackageName, false, USER_SYSTEM);
                    } else {
                        return mOverlayManager.setEnabledExclusiveInCategory(packageName,
                                USER_SYSTEM);
                    }
                } catch (RemoteException re) {
                    Log.w(TAG, "Error enabling overlay.", re);
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {
                updateState(mPreference);
                if (!success) {
                    Toast.makeText(
                            mContext, R.string.overlay_toast_failed_to_apply, Toast.LENGTH_LONG)
                            .show();
                }
            }
        }.execute();

        return true; // Assume success; toast on failure.
    }

```

通过源码发现  
 mOverlayManager.setEnabledExclusiveInCategory(packageName,  
 USER\_SYSTEM);  
 通过这里设置图标形状


而:teardrop 对应的packageName为：com.android.theme.icon.teardrop,  
 squircle 对应的packageName为：com.android.theme.icon.squircle,  
 square 对应的packageName为：com.android.theme.icon.square,  
 roundedrect 对应的packageName为：com.android.theme.icon.roundedrect,


所以要设置默认图标为squircle 就需要这样设置  
 overlayManager.setEnabledExclusiveInCategory(  
 “com.android.theme.icon.squircle”, UserHandle.USER\_CURRENT);  
 即可


具体修改如下：  
 在PMS中修改如下:  
 路径:frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java



```
/** {@inheritDoc} */
@Override
public void systemBooted() {
    bindKeyguard();
    synchronized (mLock) {
        mSystemBooted = true;
        if (mSystemReady) {
            mKeyguardDelegate.onBootCompleted();
        }
    }
    startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
    finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
    screenTurningOn(null);
    screenTurnedOn();
setOverlay();
}

```

在此方法中添加setOverlay()即可



```
private void setOverlay() {
	int overlay = Settings.Global.getInt(mContext.getContentResolver(),"setoverlay",0);
    android.util.Log.e("Overlay","overlay:"+overlay);
	if(overlay==0){
        final IOverlayManager overlayManager = IOverlayManager.Stub.asInterface(
                            ServiceManager.getService(Context.OVERLAY_SERVICE));
                    try {
                        overlayManager.setEnabledExclusiveInCategory(
                                "com.android.theme.icon.squircle", UserHandle.USER_CURRENT);
                    } catch (RemoteException e) {
                        throw new IllegalStateException(
                                "Failed to set nav bar interaction mode overlay");
                    }
        Settings.Global.putInt(mContext.getContentResolver(),"setoverlay",1);						
	}			
}

```

然后编译发现实现了功能





