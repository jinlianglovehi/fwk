



**目录**



[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.分析核心代码](#3.%E5%88%86%E6%9E%90%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.1分析NotificationPanelView.java的源码](#3.1%E5%88%86%E6%9E%90NotificationPanelView.java%E7%9A%84%E6%BA%90%E7%A0%81)


[3.2分析NotificationStackScrollLayout.java代码](#3.2%E5%88%86%E6%9E%90NotificationStackScrollLayout.java%E4%BB%A3%E7%A0%81)


[4.解决方案](#4.%E8%A7%A3%E5%86%B3%E6%96%B9%E6%A1%88)




---



## 1.概述


系统systemUI下拉状态栏UI定制 第九节 本篇主要讲解如何在下拉状态栏展开同时也要展开


通知栏，跟随上节的功能，继续实现功能，在系列七博客功能实现后 发现展开状态栏后没有展开通知栏，所以这就是本篇要解决 的问题


## 2.核心代码



```
主要是下列代码
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NotificationPanelView.java
frameworks\base\packages\SystemUI\src\com\android\systemui\notification\stack\NotificationStackScrollLayout.java
```

## 3.分析核心代码


#### 3.1分析NotificationPanelView.java的源码



```
public class NotificationPanelView extends PanelView implements
ExpandableView.OnHeightChangedListener,
View.OnClickListener, NotificationStackScrollLayout.OnOverscrollTopChangedListener,
KeyguardAffordanceHelper.Callback, NotificationStackScrollLayout.OnEmptySpaceClickListener,
OnHeadsUpChangedListener, QS.HeightListener, ZenModeController.Callback,
ConfigurationController.ConfigurationListener, StateListener,
PulseExpansionHandler.ExpansionCallback, DynamicPrivacyController.Listener {

private static final boolean DEBUG = false;

/**
* Fling expanding QS.
*/
public static final int FLING_EXPAND = 0;

/**
* Fling collapsing QS, potentially stopping when QS becomes QQS.
*/
public static final int FLING_COLLAPSE = 1;

/**
* Fling until QS is completely hidden.
*/
public static final int FLING_HIDE = 2;

// Cap and total height of Roboto font. Needs to be adjusted when font for the big clock is
// changed.
private static final int CAP_HEIGHT = 1456;
private static final int FONT_HEIGHT = 2163;

static final String COUNTER_PANEL_OPEN = "panel_open";
static final String COUNTER_PANEL_OPEN_QS = "panel_open_qs";
private static final String COUNTER_PANEL_OPEN_PEEK = "panel_open_peek";

private static final Rect mDummyDirtyRect = new Rect(0, 0, 1, 1);
private static final Rect mEmptyRect = new Rect();

private static final AnimationProperties CLOCK_ANIMATION_PROPERTIES = new AnimationProperties()
setDuration(StackStateAnimator.ANIMATION_DURATION_STANDARD);

private final InjectionInflationController mInjectionInflationController;
private final PowerManager mPowerManager;
private final AccessibilityManager mAccessibilityManager;
private final NotificationWakeUpCoordinator mWakeUpCoordinator;
private final PulseExpansionHandler mPulseExpansionHandler;

@VisibleForTesting
protected KeyguardAffordanceHelper mAffordanceHelper;
private KeyguardUserSwitcher mKeyguardUserSwitcher;
@VisibleForTesting
protected KeyguardStatusBarView mKeyguardStatusBar;
@VisibleForTesting
protected ViewGroup mBigClockContainer;
private QS mQs;
@VisibleForTesting
protected FrameLayout mQsFrame;
@VisibleForTesting
protected KeyguardStatusView mKeyguardStatusView;
private View mQsNavbarScrim;
protected NotificationsQuickSettingsContainer mNotificationContainerParent;
protected NotificationStackScrollLayout mNotificationStackScroller;
private boolean mAnimateNextPositionUpdate;

private int mTrackingPointer;
private VelocityTracker mQsVelocityTracker;
private boolean mQsTracking;

/**
* If set, the ongoing touch gesture might both trigger the expansion in {@link PanelView} and
* the expansion for quick settings.
*/
private boolean mConflictingQsExpansionGesture;

/**
* Whether we are currently handling a motion gesture in #onInterceptTouchEvent, but haven't
* intercepted yet.
*/
private boolean mIntercepting;
private boolean mPanelExpanded;
private boolean mQsExpanded;
private boolean mQsExpandedWhenExpandingStarted;
private boolean mQsFullyExpanded;
private boolean mKeyguardShowing;
private boolean mDozing;
private boolean mDozingOnDown;
protected int mBarState;
private float mInitialHeightOnTouch;
private float mInitialTouchX;
private float mInitialTouchY;
private float mLastTouchX;
private float mLastTouchY;
protected float mQsExpansionHeight;
protected int mQsMinExpansionHeight;
protected int mQsMaxExpansionHeight;
private int mQsPeekHeight;
private boolean mStackScrollerOverscrolling;
private boolean mQsExpansionFromOverscroll;
private float mLastOverscroll;
protected boolean mQsExpansionEnabled = true;
private ValueAnimator mQsExpansionAnimator;
private FlingAnimationUtils mFlingAnimationUtils;
private int mStatusBarMinHeight;
private int mNotificationsHeaderCollideDistance;
private int mUnlockMoveDistance;
private float mEmptyDragAmount;

private final KeyguardClockPositionAlgorithm mClockPositionAlgorithm =
new KeyguardClockPositionAlgorithm();
private final KeyguardClockPositionAlgorithm.Result mClockPositionResult =
new KeyguardClockPositionAlgorithm.Result();
private boolean mIsExpanding;

private boolean mBlockTouches;
// Used for two finger gesture as well as accessibility shortcut to QS.
private boolean mQsExpandImmediate;
private boolean mTwoFingerQsExpandPossible;

/**
* If we are in a panel collapsing motion, we reset scrollY of our scroll view but still
* need to take this into account in our panel height calculation.
*/
private boolean mQsAnimatorExpand;
private boolean mIsLaunchTransitionFinished;
private boolean mIsLaunchTransitionRunning;
private Runnable mLaunchAnimationEndRunnable;
private boolean mOnlyAffordanceInThisMotion;
private boolean mKeyguardStatusViewAnimating;
private ValueAnimator mQsSizeChangeAnimator;

private boolean mShowEmptyShadeView;

private boolean mQsScrimEnabled = true;
private boolean mLastAnnouncementWasQuickSettings;
private boolean mQsTouchAboveFalsingThreshold;
private int mQsFalsingThreshold;

private float mKeyguardStatusBarAnimateAlpha = 1f;
private int mOldLayoutDirection;
private HeadsUpTouchHelper mHeadsUpTouchHelper;
private boolean mIsExpansionFromHeadsUp;
private boolean mListenForHeadsUp;
private int mNavigationBarBottomHeight;
private boolean mExpandingFromHeadsUp;
private boolean mCollapsedOnDown;
private int mPositionMinSideMargin;
private int mMaxFadeoutHeight;
private int mLastOrientation = -1;
private boolean mClosingWithAlphaFadeOut;
private boolean mHeadsUpAnimatingAway;
private boolean mLaunchingAffordance;
private boolean mAffordanceHasPreview;
private FalsingManager mFalsingManager;

@Override
public boolean onInterceptTouchEvent(MotionEvent event) {
if (mBlockTouches || mQsFullyExpanded && mQs.onInterceptTouchEvent(event)) {
return false;
}
initDownStates(event);
// Do not let touches go to shade or QS if the bouncer is visible,
// but still let user swipe down to expand the panel, dismissing the bouncer.
if (mStatusBar.isBouncerShowing()) {
return true;
}
if (mBar.panelEnabled() && mHeadsUpTouchHelper.onInterceptTouchEvent(event)) {
mIsExpansionFromHeadsUp = true;
MetricsLogger.count(mContext, COUNTER_PANEL_OPEN, 1);
MetricsLogger.count(mContext, COUNTER_PANEL_OPEN_PEEK, 1);
return true;
}
if (mPulseExpansionHandler.onInterceptTouchEvent(event)) {
return true;
}

if (!isFullyCollapsed() && onQsIntercept(event)) {
return true;
}
return super.onInterceptTouchEvent(event);
}

private boolean onQsIntercept(MotionEvent event) {
int pointerIndex = event.findPointerIndex(mTrackingPointer);
if (pointerIndex < 0) {
pointerIndex = 0;
mTrackingPointer = event.getPointerId(pointerIndex);
}
final float x = event.getX(pointerIndex);
final float y = event.getY(pointerIndex);

switch (event.getActionMasked()) {
case MotionEvent.ACTION_DOWN:
mIntercepting = true;
mInitialTouchY = y;
mInitialTouchX = x;
initVelocityTracker();
trackMovement(event);
if (shouldQuickSettingsIntercept(mInitialTouchX, mInitialTouchY, 0)) {
getParent().requestDisallowInterceptTouchEvent(true);
}
if (mQsExpansionAnimator != null) {
onQsExpansionStarted();
mInitialHeightOnTouch = mQsExpansionHeight;
mQsTracking = true;
mIntercepting = false;
mNotificationStackScroller.cancelLongPress();
}
break;
case MotionEvent.ACTION_POINTER_UP:
final int upPointer = event.getPointerId(event.getActionIndex());
if (mTrackingPointer == upPointer) {
// gesture is ongoing, find a new pointer to track
final int newIndex = event.getPointerId(0) != upPointer ? 0 : 1;
mTrackingPointer = event.getPointerId(newIndex);
mInitialTouchX = event.getX(newIndex);
mInitialTouchY = event.getY(newIndex);
}
break;

case MotionEvent.ACTION_MOVE:
final float h = y - mInitialTouchY;
trackMovement(event);
if (mQsTracking) {

// Already tracking because onOverscrolled was called. We need to update here
// so we don't stop for a frame until the next touch event gets handled in
// onTouchEvent.
setQsExpansion(h + mInitialHeightOnTouch);
trackMovement(event);
mIntercepting = false;
return true;
}
if (Math.abs(h) > mTouchSlop && Math.abs(h) > Math.abs(x - mInitialTouchX)
&& shouldQuickSettingsIntercept(mInitialTouchX, mInitialTouchY, h)) {
mQsTracking = true;
onQsExpansionStarted();
notifyExpandingFinished();
mInitialHeightOnTouch = mQsExpansionHeight;
mInitialTouchY = y;
mInitialTouchX = x;
mIntercepting = false;
mNotificationStackScroller.cancelLongPress();
return true;
}
break;

case MotionEvent.ACTION_CANCEL:
case MotionEvent.ACTION_UP:
trackMovement(event);
if (mQsTracking) {
flingQsWithCurrentVelocity(y,
event.getActionMasked() == MotionEvent.ACTION_CANCEL);
mQsTracking = false;
}
mIntercepting = false;
break;
}
return false;
}
}

```

从上面的滑动事件可以看出随着手指下滑的过程中 setQsExpansion(h + mInitialHeightOnTouch); 计算下拉状态栏的高度 接下来看下setQsExpansion(h + mInitialHeightOnTouch);源码



```
private void setQsExpansion(float height) {
        height = Math.min(Math.max(height, mQsMinExpansionHeight), mQsMaxExpansionHeight);
        mQsFullyExpanded = height == mQsMaxExpansionHeight && mQsMaxExpansionHeight != 0;
        if (height > mQsMinExpansionHeight && !mQsExpanded && !mStackScrollerOverscrolling) {
            setQsExpanded(true);
        } else if (height <= mQsMinExpansionHeight && mQsExpanded) {
            setQsExpanded(false);
        }
        mQsExpansionHeight = height;
        updateQsExpansion();
        requestScrollerTopPaddingUpdate(false /* animate */);
        updateHeaderKeyguardAlpha();
        if (mBarState == StatusBarState.SHADE_LOCKED
                || mBarState == StatusBarState.KEYGUARD) {
            updateKeyguardBottomAreaAlpha();
            updateBigClockAlpha();
        }
        if (mBarState == StatusBarState.SHADE && mQsExpanded
                && !mStackScrollerOverscrolling && mQsScrimEnabled) {
            mQsNavbarScrim.setAlpha(getQsExpansionFraction());
        }

        if (mAccessibilityManager.isEnabled()) {
            setAccessibilityPaneTitle(determineAccessibilityPaneTitle());
        }

        if (!mFalsingManager.isUnlockingDisabled() && mQsFullyExpanded
                && mFalsingManager.shouldEnforceBouncer()) {
            mStatusBar.executeRunnableDismissingKeyguard(null, null /* cancelAction */,
                    false /* dismissShade */, true /* afterKeyguardGone */, false /* deferred */);
        }
        if (mExpansionListener != null) {
            mExpansionListener.onQsExpansionChanged(mQsMaxExpansionHeight != 0
                    ? mQsExpansionHeight / mQsMaxExpansionHeight : 0);
        }
        if (DEBUG) {
            invalidate();
        }
    }


    private void setQsExpanded(boolean expanded) {
        boolean changed = mQsExpanded != expanded;
        if (changed) {
            mQsExpanded = expanded;
            updateQsState();
            requestPanelHeightUpdate();
            mFalsingManager.setQsExpanded(expanded);
            mStatusBar.setQsExpanded(expanded);
            mNotificationContainerParent.setQsExpanded(expanded);
        }
    }


    private void updateQsState() {
        /*mNotificationStackScroller.setQsExpanded(mQsExpanded);*/
        mNotificationStackScroller.setScrollingEnabled(
                mBarState != StatusBarState.KEYGUARD && (!mQsExpanded
                        || mQsExpansionFromOverscroll));
        updateEmptyShadeView();
        mQsNavbarScrim.setVisibility(mBarState == StatusBarState.SHADE && mQsExpanded
                && !mStackScrollerOverscrolling && mQsScrimEnabled
                ? View.VISIBLE
                : View.INVISIBLE);
        if (mKeyguardUserSwitcher != null && mQsExpanded && !mStackScrollerOverscrolling) {
            mKeyguardUserSwitcher.hideIfNotSimple(true /* animate */);
        }
        if (mQs == null) return;
        mQs.setExpanded(mQsExpanded);
    }
```

#### setQsExpanded()判断是否展开通知栏


 updateQsState(); 负责具体更新通知的状态


#### 3.2分析NotificationStackScrollLayout.java代码



```
public class NotificationStackScrollLayout extends ViewGroup implements ScrollAdapter,
NotificationListContainer, ConfigurationListener, Dumpable,
DynamicPrivacyController.Listener {

public static final float BACKGROUND_ALPHA_DIMMED = 0.7f;
private static final String TAG = "StackScroller";
private static final boolean DEBUG = false;
private static final float RUBBER_BAND_FACTOR_NORMAL = 0.35f;
private static final float RUBBER_BAND_FACTOR_AFTER_EXPAND = 0.15f;
private static final float RUBBER_BAND_FACTOR_ON_PANEL_EXPAND = 0.21f;
/**
* Sentinel value for no current active pointer. Used by {@link #mActivePointerId}.
*/
private static final int INVALID_POINTER = -1;
static final int NUM_SECTIONS = 2;
/**
* The distance in pixels between sections when the sections are directly adjacent (no visible
* gap is drawn between them). In this case we don't want to round their corners.
*/
private static final int DISTANCE_BETWEEN_ADJACENT_SECTIONS_PX = 1;
private final AmbientPulseManager mAmbientPulseManager;

private ExpandHelper mExpandHelper;
private final NotificationSwipeHelper mSwipeHelper;
private int mCurrentStackHeight = Integer.MAX_VALUE;
private final Paint mBackgroundPaint = new Paint();
private final boolean mShouldDrawNotificationBackground;
private boolean mHighPriorityBeforeSpeedBump;
private final boolean mAllowLongPress;
private boolean mDismissRtl;

private float mExpandedHeight;
private int mOwnScrollY;
private View mScrollAnchorView;
private int mScrollAnchorViewY;
private int mMaxLayoutHeight;

private VelocityTracker mVelocityTracker;
private OverScroller mScroller;
/** Last Y position reported by {@link #mScroller}, used to calculate scroll delta. */
private int mLastScrollerY;
/**
* True if the max position was set to a known position on the last call to {@link #mScroller}.
*/
private boolean mIsScrollerBoundSet;
private Runnable mFinishScrollingCallback;
private int mTouchSlop;
private int mMinimumVelocity;
private int mMaximumVelocity;
private int mOverflingDistance;
private float mMaxOverScroll;
private boolean mIsBeingDragged;
private int mLastMotionY;
private int mDownX;
private int mActivePointerId = INVALID_POINTER;
private boolean mTouchIsClick;
private float mInitialTouchX;
private float mInitialTouchY;
。。。省略代码
public void setQsExpanded(boolean qsExpanded) {
        mQsExpanded = qsExpanded;
        updateAlgorithmLayoutMinHeight();
        updateScrollability();
    }
    private void updateAlgorithmLayoutMinHeight() {
        mAmbientState.setLayoutMinHeight(mQsExpanded || isHeadsUpTransition()
                ? getLayoutMinHeight() : 0);
    }
```

从setQsExpanded()可以看到会吧通知栏高度设置为最小


## 4.解决方案



```
private void updateQsState() {
        /*mNotificationStackScroller.setQsExpanded(mQsExpanded);*/
        mNotificationStackScroller.setScrollingEnabled(
                mBarState != StatusBarState.KEYGUARD && (!mQsExpanded
                        || mQsExpansionFromOverscroll));
        updateEmptyShadeView();
        mQsNavbarScrim.setVisibility(mBarState == StatusBarState.SHADE && mQsExpanded
                && !mStackScrollerOverscrolling && mQsScrimEnabled
                ? View.VISIBLE
                : View.INVISIBLE);
        if (mKeyguardUserSwitcher != null && mQsExpanded && !mStackScrollerOverscrolling) {
            mKeyguardUserSwitcher.hideIfNotSimple(true /* animate */);
        }
        if (mQs == null) return;
        mQs.setExpanded(mQsExpanded);
    }

```

注释掉mNotificationStackScroller.setQsExpanded(mQsExpanded);就可以了



