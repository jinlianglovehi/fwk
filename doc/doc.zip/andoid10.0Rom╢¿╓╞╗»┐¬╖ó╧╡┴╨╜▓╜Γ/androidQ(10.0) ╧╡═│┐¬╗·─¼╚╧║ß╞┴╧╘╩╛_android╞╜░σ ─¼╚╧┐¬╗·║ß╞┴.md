






### 1.概述


在10.0的产品开发中，在大多数平板等设备定制化开发过程中，多数都会要求默认横屏显示，为了实现这个需求，就得从开机动画和系统旋转方向方面解决


### 2.系统开机默认横屏显示的核心类



```
frameworks/base/cmds/bootanimation/BootAnimation.cpp
frameworks/base/services/core/java/com/android/server/wm/DisplayContent.java
frameworks/base/services/core/java/com/android/server/wm/DisplayRotation.java 
frameworks/native/services/surfaceflinger/CompositionEngine/src/OutputLayer.cpp
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarWindowController.java

```

### 3.系统开机默认横屏显示的核心功能分析和实现


实现思路  
 1.开机动画默认横屏  
 2.系统旋转方向设置为横屏


3.1 在开机动画中设置默认横屏显示



```

diff --git a/frameworks/base/cmds/bootanimation/BootAnimation.cpp b/frameworks/base/cmds/bootanimation/BootAnimation.cpp

old mode 100644

new mode 100755

index db84a57ec8..3adb349a8d

--- a/frameworks/base/cmds/bootanimation/BootAnimation.cpp

+++ b/frameworks/base/cmds/bootanimation/BootAnimation.cpp

@@ -348,7 +348,7 @@ status_t BootAnimation::readyToRun() {

 

     // create the native surface

     sp<SurfaceControl> control = session()->createSurface(String8("BootAnimation"),

-            dinfo.w, dinfo.h, PIXEL_FORMAT_RGB_565);

+            dinfo.h, dinfo.w, PIXEL_FORMAT_RGB_565);

 

     SurfaceComposerClient::Transaction t;

     t.setLayer(control, 0x40000000)

```

在开机动画中的readyToRun()设置开机画面横屏显示，设置createSurface中画面宽和高  
 的调整来实现开机动画默认横屏显示


### 3.2 默认屏幕旋转方向横屏显示


在负责对屏幕的旋转中的DisplayContent.java关于旋转方向的源码分析



```
diff --git a/frameworks/base/services/core/java/com/android/server/wm/DisplayContent.java b/frameworks/base/services/core/java/com/android/server/wm/DisplayContent.java

old mode 100644

new mode 100755

index 5a5b75c736..66d4539e19

--- a/frameworks/base/services/core/java/com/android/server/wm/DisplayContent.java

+++ b/frameworks/base/services/core/java/com/android/server/wm/DisplayContent.java

@@ -908,6 +908,9 @@ class DisplayContent extends WindowContainer<DisplayContent.DisplayChildWindowCo

         mSystemGestureExclusionLimit = mWmService.mSystemGestureExclusionLimitDp

                 * mDisplayMetrics.densityDpi / DENSITY_DEFAULT;

         isDefaultDisplay = mDisplayId == DEFAULT_DISPLAY;

+               if (isDefaultDisplay) {

+           mRotation = 1;

+        }

         mDisplayFrames = new DisplayFrames(mDisplayId, mDisplayInfo,

                 calculateDisplayCutoutForRotation(mDisplayInfo.rotation));

         initializeDisplayBaseInfo();


```

DisplayContent.java的源码中在isDefaultDisplay中设置旋转方向默认为1就是横屏显示



```
diff --git a/frameworks/base/services/core/java/com/android/server/wm/DisplayRotation.java b/frameworks/base/services/core/java/com/android/server/wm/DisplayRotation.java

old mode 100644

new mode 100755

index 194b45c152..fda1341b29

--- a/frameworks/base/services/core/java/com/android/server/wm/DisplayRotation.java

+++ b/frameworks/base/services/core/java/com/android/server/wm/DisplayRotation.java

@@ -96,7 +96,9 @@ public class DisplayRotation {

 

     private int mAllowAllRotations = -1;

     private int mUserRotationMode = WindowManagerPolicy.USER_ROTATION_FREE;

-    private int mUserRotation = Surface.ROTATION_0;

+    private int mUserRotation = Surface.ROTATION_90;

+    private int mInitLauncherRotation = mUserRotation;

+    private boolean mSensorChanged = false;

 



@@ -173,6 +175,9 @@ public class DisplayRotation {

             mSettingsObserver = new SettingsObserver(uiHandler);

             mSettingsObserver.observe();

         }

+               final ContentResolver res = mContext.getContentResolver();

+        Settings.System.putIntForUser(res, Settings.System.USER_ROTATION,

+                            Surface.ROTATION_90, UserHandle.USER_CURRENT);

     }

 

     private int readRotation(int resID) {

@@ -712,7 +717,7 @@ public class DisplayRotation {

                     }

                     return preferredRotation;

                 }

-                return Surface.ROTATION_0;

+                return Surface.ROTATION_90;

         }

     }

```

关于在DisplayRotation.java中关于屏幕旋转方向的设置中，在readRotation(int resID)中，返回屏幕旋转默认设置为90来实现默认屏幕旋转为横屏显示



```
diff --git a/frameworks/native/services/surfaceflinger/CompositionEngine/src/OutputLayer.cpp b/frameworks/native/services/surfaceflinger/CompositionEngine/src/OutputLayer.cpp

old mode 100644

new mode 100755

index 5ce72b0879..0abc8f3f8e

--- a/frameworks/native/services/surfaceflinger/CompositionEngine/src/OutputLayer.cpp

+++ b/frameworks/native/services/surfaceflinger/CompositionEngine/src/OutputLayer.cpp

@@ -122,6 +122,13 @@ Rect OutputLayer::calculateInitialCrop() const {

     if (!activeCrop.intersect(layerState.geomBufferSize, &activeCrop)) {

         activeCrop.clear();

     }

+               if (strstr(mLayerFE->getDebugName(), "BootAnimation#0"))

+               {

+                       activeCrop.left = 0;

+                       activeCrop.top = 0;

+                       activeCrop.right = 1920;

+                       activeCrop.bottom = 1200;

+               }

     return activeCrop;

 }

 

@@ -244,6 +251,13 @@ Rect OutputLayer::calculateOutputDisplayFrame() const {

     if (!frame.intersect(outputState.viewport, &frame)) {

         frame.clear();

     }

+       if (strstr(mLayerFE->getDebugName(), "BootAnimation#0"))

+               {

+                       frame.left = 0;

+                       frame.top = 0;

+                       frame.right = 1200;

+                       frame.bottom = 1920;

+               }

     const ui::Transform displayTransform{outputState.transform};

 

     return displayTransform.transform(frame);

@@ -340,12 +354,24 @@ void OutputLayer::writeStateToHWC(bool includeGeometry) const {

                   to_string(error).c_str(), static_cast<int32_t>(error));

         }

 

-        if (auto error =

-                    hwcLayer->setTransform(static_cast<HWC2::Transform>(mState.bufferTransform));

-            error != HWC2::Error::None) {

-            ALOGE("[%s] Failed to set transform %s: %s (%d)", mLayerFE->getDebugName(),

-                  toString(mState.bufferTransform).c_str(), to_string(error).c_str(),

-                  static_cast<int32_t>(error));

+                  ALOGE("[%s] transform is %s", mLayerFE->getDebugName(),

+                  toString(mState.bufferTransform).c_str()); 

+               if (strstr(mLayerFE->getDebugName(), "BootAnimation#0"))

+               {

+                       if (auto error =

+                                               hwcLayer->setTransform(static_cast<HWC2::Transform>(ui::Transform::ROT_90));//D<A8><A8><A8><B0>a<A6><CC>?

Dy<A1><C1>a???<A8><A8>

+                               error != HWC2::Error::None) {

+                               ALOGE("[%s] Failed to set transform %s: %s (%d)", mLayerFE->getDebugName(),

+                                         toString(mState.bufferTransform).c_str(), to_string(error).c_str(),

+                                        static_cast<int32_t>(error));

+                       }

+               }

+              else if (auto error =

+                       hwcLayer->setTransform(static_cast<HWC2::Transform>(mState.bufferTransform));

+                       error != HWC2::Error::None) {

+                       ALOGE("[%s] Failed to set transform %s: %s (%d)", mLayerFE->getDebugName(),

+                       toString(mState.bufferTransform).c_str(), to_string(error).c_str(),

+                       static_cast<int32_t>(error));

         }

```

在OutputLayer.cpp中关于开机画面的输出到页面的时候，设置宽高的高度，然后把当前默认的竖屏修改成横屏显示，所以就需要设置开机动画绘制的宽高的调整达到设置默认横屏的功能



```
 --- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarWindowController.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarWindowController.java
@@ -129,8 +129,8 @@ public class StatusBarWindowController implements Callback, Dumpable, Configurat
 
     private boolean shouldEnableKeyguardScreenRotation() {
         Resources res = mContext.getResources();
-        return SystemProperties.getBoolean("lockscreen.rot\_override", false)
-                || res.getBoolean(R.bool.config_enableLockScreenRotation);
+        return false/*SystemProperties.getBoolean("lockscreen.rot\_override", false)
+                || res.getBoolean(R.bool.config_enableLockScreenRotation)*/;
     }
 
     
@@ -234,7 +234,7 @@ public class StatusBarWindowController implements Callback, Dumpable, Configurat
             if (mKeyguardScreenRotation) {
                 mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_USER;
             } else {
-                mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_NOSENSOR;
+                mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE/*ActivityInfo.SCREEN_ORIENTATION_NOSENSOR*/;
             }
         } else {
             mLpChanged.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

```

在管理状态栏的管理的StatusBarWindowController 中的锁屏页面中，设置屏幕默认横屏显示  
 就是设置mLpChanged.screenOrientation为默认横屏就可以了





