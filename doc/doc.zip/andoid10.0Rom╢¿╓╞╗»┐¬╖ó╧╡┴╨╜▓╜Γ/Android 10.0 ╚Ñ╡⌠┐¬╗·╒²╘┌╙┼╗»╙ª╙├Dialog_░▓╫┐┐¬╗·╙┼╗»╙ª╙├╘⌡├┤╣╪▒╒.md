






### 1.概述


Android10.0的产品定制化开发中，在某些设备开机的过程中 有时候会显示正在优化应用的对话框，这些对产品不太友好，所以产品由于不想让用户看到这个对话框，怕影响销量，所以要求去掉这个对话框，下面就来寻找哪里弹出的这个对话框，然后注释掉就可以了


### 2.去掉开机正在优化应用Dialog核心类



```
frameworks\base\core\res\res\values-zh-rCN\strings.xml 
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java

```

### 3.去掉开机正在优化应用Dialog核心功能分析和实现


在frameworks\base\core\res\res\values-zh-rCN\strings.xml 中，搜索相关关键词  
 R.string.android\_upgrading\_title  
 所以就要看哪里用了这个字符串


在framework/base 下搜索 发现  
 services/core/java/com/android/server/policy/PhoneWindowManager.java:5214: `mBootMsgDialog.setTitle(R.string.android_upgrading_title);`


所以就要看PhoneWindowManager.java 怎么实现的了



```
  public class PhoneWindowManager implements WindowManagerPolicy {
      private class PolicyHandler extends Handler {
          @Override
          public void handleMessage(Message msg) {
              switch (msg.what) {
                  case MSG_DISPATCH_MEDIA_KEY_WITH_WAKE_LOCK:
                      dispatchMediaKeyWithWakeLock((KeyEvent)msg.obj);
 break;
 case MSG\_DISPATCH\_MEDIA\_KEY\_REPEAT\_WITH\_WAKE\_LOCK:
 dispatchMediaKeyRepeatWithWakeLock((KeyEvent)msg.obj);
 break;
 case MSG\_DISPATCH\_SHOW\_RECENTS:
 showRecentApps(false);
 break;
 case MSG\_DISPATCH\_SHOW\_GLOBAL\_ACTIONS:
 showGlobalActionsInternal();
 break;
 case MSG\_KEYGUARD\_DRAWN\_COMPLETE:
 if (DEBUG\_WAKEUP) Slog.w(TAG, "Setting mKeyguardDrawComplete");
 finishKeyguardDrawn();
 break;
 case MSG\_KEYGUARD\_DRAWN\_TIMEOUT:
 Slog.w(TAG, "Keyguard drawn timeout. Setting mKeyguardDrawComplete");
 finishKeyguardDrawn();
 break;
 case MSG\_WINDOW\_MANAGER\_DRAWN\_COMPLETE:
 if (DEBUG\_WAKEUP) Slog.w(TAG, "Setting mWindowManagerDrawComplete");
 finishWindowsDrawn();
 break;
 case MSG\_HIDE\_BOOT\_MESSAGE:
 handleHideBootMessage();
 break;
 case MSG\_LAUNCH\_ASSIST:
 final int deviceId = msg.arg1;
 final String hint = (String) msg.obj;
 launchAssistAction(hint, deviceId);
 break;
 case MSG\_LAUNCH\_ASSIST\_LONG\_PRESS:
 launchAssistLongPressAction();
 break;
 case MSG\_LAUNCH\_VOICE\_ASSIST\_WITH\_WAKE\_LOCK:
 launchVoiceAssistWithWakeLock();
 break;
 case MSG\_POWER\_DELAYED\_PRESS:
 powerPress((Long) msg.obj, msg.arg1 != 0, msg.arg2);
 finishPowerKeyPress();
 break;
 case MSG\_POWER\_LONG\_PRESS:
 powerLongPress();
 break;
 case MSG\_POWER\_VERY\_LONG\_PRESS:
 powerVeryLongPress();
 break;
 case MSG\_SHOW\_PICTURE\_IN\_PICTURE\_MENU:
 showPictureInPictureMenuInternal();
 break;
 case MSG\_BACK\_LONG\_PRESS:
 backLongPress();
 break;
 case MSG\_ACCESSIBILITY\_SHORTCUT:
 accessibilityShortcutActivated();
 break;
 case MSG\_BUGREPORT\_TV:
 requestFullBugreport();
 break;
 case MSG\_ACCESSIBILITY\_TV:
 if (mAccessibilityShortcutController.isAccessibilityShortcutAvailable(false)) {
                          accessibilityShortcutActivated();
                      }
                      break;
                  case MSG_DISPATCH_BACK_KEY_TO_AUTOFILL:
                      mAutofillManagerInternal.onBackKeyPressed();
                      break;
                  case MSG_SYSTEM_KEY_PRESS:
                      sendSystemKeyToStatusBar(msg.arg1);
                      break;
                  case MSG_HANDLE_ALL_APPS:
                      launchAllAppsAction();
                      break;
                  case MSG_NOTIFY_USER_ACTIVITY:
                      removeMessages(MSG_NOTIFY_USER_ACTIVITY);
                      Intent intent = new Intent(ACTION_USER_ACTIVITY_NOTIFICATION);
                      intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY);
                      mContext.sendBroadcastAsUser(intent, UserHandle.ALL,
                              android.Manifest.permission.USER_ACTIVITY);
                      break;
                  case MSG_RINGER_TOGGLE_CHORD:
                      handleRingerChordGesture();
                      break;
                  case MSG_MOVE_DISPLAY_TO_TOP:
                      mWindowManagerFuncs.moveDisplayToTop(msg.arg1);
                      mMovingDisplayToTopKeyTriggered = false;
                      break;
              }
          }
      }
 /** {@inheritDoc} */
      @Override
      public void systemReady() {
          // In normal flow, systemReady is called before other system services are ready.
          // So it is better not to bind keyguard here.
          mKeyguardDelegate.onSystemReady();
  
          mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
          if (mVrManagerInternal != null) {
              mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
          }
  
          readCameraLensCoverState();
          updateUiMode();
          mDefaultDisplayRotation.updateOrientationListener();
          synchronized (mLock) {
              mSystemReady = true;
              mHandler.post(new Runnable() {
                  @Override
                  public void run() {
                      updateSettings();
                  }
              });
              // If this happens, for whatever reason, systemReady came later than systemBooted.
              // And keyguard should be already bound from systemBooted
              if (mSystemBooted) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
  
          mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
      }
  
      /** {@inheritDoc} */
      @Override
      public void systemBooted() {
          bindKeyguard();
          synchronized (mLock) {
              mSystemBooted = true;
              if (mSystemReady) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
          startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
          finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
          screenTurningOn(null);
          screenTurnedOn();
      }
      
/** {@inheritDoc} */
    @Override
    public void showBootMessage(final CharSequence msg, final boolean always) {
        mHandler.post(new Runnable() {
            @Override public void run() {
                if (mBootMsgDialog == null) {
                    int theme;
                    if (mContext.getPackageManager().hasSystemFeature(FEATURE_LEANBACK)) {
                        theme = com.android.internal.R.style.Theme_Leanback_Dialog_Alert;
                    } else {
                        theme = 0;
                    }

                    mBootMsgDialog = new ProgressDialog(mContext, theme) {
                        // This dialog will consume all events coming in to
                        // it, to avoid it trying to do things too early in boot.
                        @Override public boolean dispatchKeyEvent(KeyEvent event) {
                            return true;
                        }
                        @Override public boolean dispatchKeyShortcutEvent(KeyEvent event) {
                            return true;
                        }
                        @Override public boolean dispatchTouchEvent(MotionEvent ev) {
                            return true;
                        }
                        @Override public boolean dispatchTrackballEvent(MotionEvent ev) {
                            return true;
                        }
                        @Override public boolean dispatchGenericMotionEvent(MotionEvent ev) {
                            return true;
                        }
                        @Override public boolean dispatchPopulateAccessibilityEvent(
                                AccessibilityEvent event) {
                            return true;
                        }
                    };
                    if (mContext.getPackageManager().isDeviceUpgrading()) {
                        mBootMsgDialog.setTitle(R.string.android_upgrading_title);
                    } else {
                        mBootMsgDialog.setTitle(R.string.android_start_title);
                    }
                    mBootMsgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    mBootMsgDialog.setIndeterminate(true);
                    mBootMsgDialog.getWindow().setType(
                            WindowManager.LayoutParams.TYPE_BOOT_PROGRESS);
                    mBootMsgDialog.getWindow().addFlags(
                            WindowManager.LayoutParams.FLAG_DIM_BEHIND
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
                    mBootMsgDialog.getWindow().setDimAmount(1);
                    WindowManager.LayoutParams lp = mBootMsgDialog.getWindow().getAttributes();
                    lp.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_NOSENSOR;
                    mBootMsgDialog.getWindow().setAttributes(lp);
                    mBootMsgDialog.setCancelable(false);
                    mBootMsgDialog.show();
                }
                mBootMsgDialog.setMessage(msg);
            }
        });
    }

```

在PhoneWindowManager的类中的PolicyHandler 负责接收其他传给的PhoneWindowManager中的handler事件  
 而在showBootMessage(final CharSequence msg, final boolean always) 中，负责弹窗应用正在升级  
 和应用正在启动等提醒式窗口信息，所以对于应用正在启动的提醒消息就可以在这里去掉  
 从源码中看mBootMsgDialog.show(); 就是弹出这个Dialog的  
 所以注释掉即可





