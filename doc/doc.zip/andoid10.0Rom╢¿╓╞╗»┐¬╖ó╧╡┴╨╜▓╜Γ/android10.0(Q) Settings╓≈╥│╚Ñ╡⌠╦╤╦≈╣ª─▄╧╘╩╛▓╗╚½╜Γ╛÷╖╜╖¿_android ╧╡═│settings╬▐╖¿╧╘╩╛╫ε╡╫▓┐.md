






### 1.概述


在10.0的系统产品开发中，由于产品需求要求去掉 Settings 主页面的搜索功能，在去掉搜索项后 导致显示不全,分析后是由于homepage\_container 布局的padding底部间距设置为0导致的


### 2.Settings主页去掉搜索功能显示不全解决方法的核心类



```
packages/apps/Settings/res/layout/settings_homepage_container.xml
/packages/apps/Settings/src/com/android/settings/homepage/SettingsHomepageActivity.java

```

### 3.Settings主页去掉搜索功能显示不全解决方法的核心功能分析和实现


在系统Settings的主页面就是在SettingsHomepageActivity ，而它的xml布局文件就是  
 settings\_homepage\_container.xml 接下来就看下怎么设置间距  
 解决方案一：


### 3.1 在layout/settings\_homepage\_container.xml 设置底部间距



```
<androidx.coordinatorlayout.widget.CoordinatorLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:id="@+id/settings\_homepage\_container"
    android:fitsSystemWindows="true"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent">

    <androidx.core.widget.NestedScrollView
        android:id="@+id/main\_content\_scrollable\_container"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        app:layout_behavior="com.android.settings.widget.FloatingAppBarScrollingViewBehavior">

        <LinearLayout
            android:id="@+id/homepage\_container"
            android:layout_width="match\_parent"
            android:layout_height="wrap\_content"
            android:orientation="vertical"
            android:descendantFocusability="blocksDescendants">

            <FrameLayout
                android:id="@+id/contextual\_cards\_content"
                android:layout_width="match\_parent"
                android:layout_height="wrap\_content"
                android:layout_marginStart="@dimen/contextual\_card\_side\_margin"
                android:layout_marginEnd="@dimen/contextual\_card\_side\_margin"/>

            <FrameLayout
                android:id="@+id/main\_content"
                android:layout_width="match\_parent"
                android:layout_height="wrap\_content"
                android:animateLayoutChanges="true"
                android:background="?android:attr/windowBackground"/>

        </LinearLayout>
    </androidx.core.widget.NestedScrollView>

    <com.google.android.material.appbar.AppBarLayout
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content">
        <include layout="@layout/search\_bar"/>
    </com.google.android.material.appbar.AppBarLayout>
</androidx.coordinatorlayout.widget.CoordinatorLayout>

```

通过分析发现在main\_content\_scrollable\_container 设置合适的间距可以解决问题  
 修改如下:  
 main\_content\_scrollable\_container 添加底部间距



```
diff --git a/packages/apps/Settings/res/layout/settings_homepage_container.xml b/packages/apps/Settings/res/layout/settings_homepage_container.xml
index 0ec1eea9de..2345c8c4b6 100755
--- a/packages/apps/Settings/res/layout/settings_homepage_container.xml
+++ b/packages/apps/Settings/res/layout/settings_homepage_container.xml
@@ -27,6 +27,7 @@
        <androidx.core.widget.NestedScrollView
        android:id="@+id/main\_content\_scrollable\_container"
        android:layout_width="match\_parent"
         android:layout_height="match\_parent"
+               android:layout_marginBottom="30dp"
         app:layout_behavior="com.android.settings.widget.FloatingAppBarScrollingViewBehavior">

```

通过在main\_content\_scrollable\_container中设置底部间距30dp 解决了Settings主页在去掉搜索框以后底部显示不全的问题


方案二


### 3.2 在SettingsHomepageActivity 设置 homepage\_container 的padding边距


下面先看源码分析问题



```
public class SettingsHomepageActivity extends FragmentActivity {
  
      @Override
      protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
  
          setContentView(R.layout.settings_homepage_container);
          final View root = findViewById(R.id.settings_homepage_container);
          root.setSystemUiVisibility(
                  View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  
          setHomepageContainerPaddingTop();
  
          final Toolbar toolbar = findViewById(R.id.search_action_bar);
          FeatureFactory.getFactory(this).getSearchFeatureProvider()
                  .initSearchToolbar(this /* activity */, toolbar, SettingsEnums.SETTINGS_HOMEPAGE);
  
          final ImageView avatarView = findViewById(R.id.account_avatar);
          final AvatarViewMixin avatarViewMixin = new AvatarViewMixin(this, avatarView);
          getLifecycle().addObserver(avatarViewMixin);
  
          if (!getSystemService(ActivityManager.class).isLowRamDevice()) {
              // Only allow contextual feature on high ram devices.
              showFragment(new ContextualCardsFragment(), R.id.contextual_cards_content);
          }
          showFragment(new TopLevelSettings(), R.id.main_content);
          ((FrameLayout) findViewById(R.id.main\_content))
                  .getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
      }
  
      private void showFragment(Fragment fragment, int id) {
          final FragmentManager fragmentManager = getSupportFragmentManager();
          final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
          final Fragment showFragment = fragmentManager.findFragmentById(id);
  
          if (showFragment == null) {
              fragmentTransaction.add(id, fragment);
          } else {
              fragmentTransaction.show(showFragment);
          }
          fragmentTransaction.commit();
      }
  
      @VisibleForTesting
      void setHomepageContainerPaddingTop() {
          final View view = this.findViewById(R.id.homepage_container);
  
          final int searchBarHeight = getResources().getDimensionPixelSize(R.dimen.search_bar_height);
          final int searchBarMargin = getResources().getDimensionPixelSize(R.dimen.search_bar_margin);
  
          // The top padding is the height of action bar(48dp) + top/bottom margins(16dp)
          final int paddingTop = searchBarHeight + searchBarMargin * 2;
          view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
      }
  }

```

在SettingsHomepageActivity 中的setHomepageContainerPaddingTop()就是设置主页面的padding距离,所以也可以设置底部距离，具体如下：



```
  @VisibleForTesting
    void setHomepageContainerPaddingTop() {
        final View view = this.findViewById(R.id.homepage_container);

        final int searchBarHeight = getResources().getDimensionPixelSize(R.dimen.search_bar_height);
        final int searchBarMargin = getResources().getDimensionPixelSize(R.dimen.search_bar_margin);

        // The top padding is the height of action bar(48dp) + top/bottom margins(16dp)
        final int paddingTop = searchBarHeight + searchBarMargin * 2;
         - view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
         + view.setPadding(0 /* left */, 0, 0 /* right */, 30 /* bottom */);
          // 修改底部边距为30 就可以了
    }

```

通过修改view.setPadding的底部距离实现主页底部的距离





