



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.状态栏隐藏输入法的核心代码](#2.%E7%8A%B6%E6%80%81%E6%A0%8F%E9%9A%90%E8%97%8F%E8%BE%93%E5%85%A5%E6%B3%95%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.状态栏隐藏输入法的核心代码分析以及功能实现](#3.%E7%8A%B6%E6%80%81%E6%A0%8F%E9%9A%90%E8%97%8F%E8%BE%93%E5%85%A5%E6%B3%95%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E4%BB%A5%E5%8F%8A%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 InputMethodManagerService这个输入法服务的交互流程](#%C2%A0%203.1%20InputMethodManagerService%E8%BF%99%E4%B8%AA%E8%BE%93%E5%85%A5%E6%B3%95%E6%9C%8D%E5%8A%A1%E7%9A%84%E4%BA%A4%E4%BA%92%E6%B5%81%E7%A8%8B)


[3.1.1.与WindowManagerSerivce的交互](#%C2%A0%20%C2%A0%C2%A0%C2%A0%203.1.1.%E4%B8%8EWindowManagerSerivce%E7%9A%84%E4%BA%A4%E4%BA%92)


[3.1.2 与InputMethodService的交互](#3.1.2%20%E4%B8%8EInputMethodService%E7%9A%84%E4%BA%A4%E4%BA%92)


[3.1.3与InputMethodManager的交互](#%C2%A0%203.1.3%E4%B8%8EInputMethodManager%E7%9A%84%E4%BA%A4%E4%BA%92)


[3.2InputMethodManagerService.java输入法源码分析](#%C2%A0%203.2InputMethodManagerService.java%E8%BE%93%E5%85%A5%E6%B3%95%E6%BA%90%E7%A0%81%E5%88%86%E6%9E%90)


[3.3状态栏隐藏输入法图标的具体修改为:](#3.3%E7%8A%B6%E6%80%81%E6%A0%8F%E9%9A%90%E8%97%8F%E8%BE%93%E5%85%A5%E6%B3%95%E5%9B%BE%E6%A0%87%E7%9A%84%E5%85%B7%E4%BD%93%E4%BF%AE%E6%94%B9%E4%B8%BA%3A)




---



## 1.概述


 在进行10.0定制化开发中，由于系统默认输入法为搜狗输入法，在调用输入法的时候，就会在状态栏中显示搜狗输入法的图标，而由于状态栏不允许显示第三方app的图标 所以要求去掉输入法图标来完成这个功能的开发


## 2.状态栏隐藏输入法的核心代码



```
frameworks/base/services/core/java/com/android/server/inputmethod/InputMethodManagerService.java
```

## 3.状态栏隐藏输入法的核心代码分析以及功能实现


###   3.1 InputMethodManagerService这个输入法服务的交互流程


###       3.1.1.与WindowManagerSerivce的交互


首先，InputMethodManagerService在初始化时，会调用IWindowManager.Stub.asInterface(ServiceManager.getService(Context.WINDOW\_SERVICE))，得到IWindowManager这个代理，  
 然后通过IWindowManager与WindowManagerService交互。比如这些api的调用：  
 调用mIWindowManager.addWindowToken(mCurToken, WindowManager.LayoutParams.TYPE\_INPUT\_METHOD)，让WindowManagerService显示输入法界面。  
 调用mIWindowManager.removeWindowToken(mCurToken)让输入法界面关闭。  
 调用mIWindowManager.inputMethodClientHasFocus(client)判断输入法是否聚焦。


### 3.1.2 与InputMethodService的交互


InputMethodManagerService在内部维护着一个ArrayList<InputMethodInfo> mMethodList。这个列表会在服务启动时通过PackageManager查询当前系统中的输入法程序来得到。  
 与之对应的，每一个输入法程序的AndroidManifest.xml中都会有一个Service，而每个Service中都会有标记来告诉系统，自己是个输入法程序


###   3.1.3与InputMethodManager的交互


InputMethodManager中会包含一个IInputMethodManager，这个东西就是InputMethodManagerService的代理，  
 打开关闭输入法这些操作就是由InputMethodManager中的某些方法调用IInputMethodManager中相应的方法来实现的。比如：  
 mService.getInputMethodList()获取输入法列表。  
 mService.updateStatusIcon(imeToken, packageName, iconId)更新输入法图标，即屏幕上方状态栏中的输入法图标。  
 mService.finishInput(mClient)隐藏当前输入法。这所以不说关闭输入法，是因为输入法服务启动起来以后，只有在系统关闭或者切换输入法时才会关闭。  
 mService.showSoftInput(mClient, flags, resultReceiver)打开当前输入法。


###   3.2InputMethodManagerService.java输入法源码分析



```
   private static final class InputMethodPrivilegedOperationsImpl
            extends IInputMethodPrivilegedOperations.Stub {
        private final InputMethodManagerService mImms;
        @NonNull
        private final IBinder mToken;
        InputMethodPrivilegedOperationsImpl(InputMethodManagerService imms,
                @NonNull IBinder token) {
            mImms = imms;
            mToken = token;
        }

        @BinderThread
        @Override
        public void setImeWindowStatus(int vis, int backDisposition) {
            mImms.setImeWindowStatus(mToken, vis, backDisposition);
        }

        @BinderThread
        @Override
        public void reportStartInput(IBinder startInputToken) {
            mImms.reportStartInput(mToken, startInputToken);
        }

        @BinderThread
        @Override
        public IInputContentUriToken createInputContentUriToken(Uri contentUri,
                String packageName) {
            return mImms.createInputContentUriToken(mToken, contentUri, packageName);
        }

        @BinderThread
        @Override
        public void reportFullscreenMode(boolean fullscreen) {
            mImms.reportFullscreenMode(mToken, fullscreen);
        }

        @BinderThread
        @Override
        public void setInputMethod(String id) {
            mImms.setInputMethod(mToken, id);
        }

        @BinderThread
        @Override
        public void setInputMethodAndSubtype(String id, InputMethodSubtype subtype) {
            mImms.setInputMethodAndSubtype(mToken, id, subtype);
        }

        @BinderThread
        @Override
        public void hideMySoftInput(int flags) {
            mImms.hideMySoftInput(mToken, flags);
        }

        @BinderThread
        @Override
        public void showMySoftInput(int flags) {
            mImms.showMySoftInput(mToken, flags);
        }

        @BinderThread
        @Override
        public void updateStatusIcon(String packageName, @DrawableRes int iconId) {
            mImms.updateStatusIcon(mToken, packageName, iconId);
        }

        @BinderThread
        @Override
        public boolean switchToPreviousInputMethod() {
            return mImms.switchToPreviousInputMethod(mToken);
        }

        @BinderThread
        @Override
        public boolean switchToNextInputMethod(boolean onlyCurrentIme) {
            return mImms.switchToNextInputMethod(mToken, onlyCurrentIme);
        }

        @BinderThread
        @Override
        public boolean shouldOfferSwitchingToNextInputMethod() {
            return mImms.shouldOfferSwitchingToNextInputMethod(mToken);
        }

        @BinderThread
        @Override
        public void notifyUserAction() {
            mImms.notifyUserAction(mToken);
        }

        @BinderThread
        @Override
        public void reportPreRendered(EditorInfo info) {
            mImms.reportPreRendered(mToken, info);
        }

        @BinderThread
        @Override
        public void applyImeVisibility(boolean setVisible) {
            mImms.applyImeVisibility(mToken, setVisible);
        }
    }

 @BinderThread
    private void updateStatusIcon(@NonNull IBinder token, String packageName,
            @DrawableRes int iconId) {
        synchronized (mMethodMap) {
            if (!calledWithValidTokenLocked(token)) {
                return;
            }
            final long ident = Binder.clearCallingIdentity();
            try {
                if (iconId == 0) {
                    if (DEBUG) Slog.d(TAG, "hide the small icon for the input method");
                    if (mStatusBar != null) {
                        mStatusBar.setIconVisibility(mSlotIme, false);
                    }
                } else if (packageName != null) {
                    if (DEBUG) Slog.d(TAG, "show a small icon for the input method");
                    CharSequence contentDescription = null;
                    try {
                        // Use PackageManager to load label
                        final PackageManager packageManager = mContext.getPackageManager();
                        contentDescription = packageManager.getApplicationLabel(
                                mIPackageManager.getApplicationInfo(packageName, 0,
                                        mSettings.getCurrentUserId()));
                    } catch (RemoteException e) {
                        /* ignore */
                    }
                    if (mStatusBar != null) {
                        mStatusBar.setIcon(mSlotIme, packageName, iconId, 0,
                                contentDescription  != null
                                        ? contentDescription.toString() : null);
                        mStatusBar.setIconVisibility(mSlotIme, true);
                    }
                }
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }
    }


```

### 


在上述的InputMethodManagerService.java的相关源码中，可以看到，分析相关源码发现最终


在updateStatusIcon(）中可以看到mStatusBar.setIconVisibility()负责在调用输入法的时候来在状态栏显示输入法图标的，所以说可以在updateStatusIcon(）中看下相关隐藏输入法图标的功能实现


### 


### 3.3状态栏隐藏输入法图标的具体修改为:



```
@BinderThread
    private void updateStatusIcon(@NonNull IBinder token, String packageName,
            @DrawableRes int iconId) {
        synchronized (mMethodMap) {
            if (!calledWithValidTokenLocked(token)) {
                return;
            }
            final long ident = Binder.clearCallingIdentity();
            try {
                if (iconId == 0) {
                    if (DEBUG) Slog.d(TAG, "hide the small icon for the input method");
                    if (mStatusBar != null) {
                        mStatusBar.setIconVisibility(mSlotIme, false);
                    }
                } else if (packageName != null) {
                    if (DEBUG) Slog.d(TAG, "show a small icon for the input method");
                    CharSequence contentDescription = null;
                    try {
                        // Use PackageManager to load label
                        final PackageManager packageManager = mContext.getPackageManager();
                        contentDescription = packageManager.getApplicationLabel(
                                mIPackageManager.getApplicationInfo(packageName, 0,
                                        mSettings.getCurrentUserId()));
                    } catch (RemoteException e) {
                        /* ignore */
                    }
                    if (mStatusBar != null) {
                        mStatusBar.setIcon(mSlotIme, packageName, iconId, 0,
                                contentDescription  != null
                                        ? contentDescription.toString() : null);
                    // 负责在状态栏显示图标
                     -   mStatusBar.setIconVisibility(mSlotIme, true);
                     +  mStatusBar.setIconVisibility(mSlotIme, false);
                    }
                }
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }
    }
```

在上述的InputMethodManagerService.java的相关源码中，可以看到，分析相关源码发现最终


在updateStatusIcon(）通过上述的修改最终实现了功能



