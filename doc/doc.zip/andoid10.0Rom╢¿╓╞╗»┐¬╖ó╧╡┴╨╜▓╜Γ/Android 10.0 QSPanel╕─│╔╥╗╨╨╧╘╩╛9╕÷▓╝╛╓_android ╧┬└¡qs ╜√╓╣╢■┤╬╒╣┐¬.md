






在SystemUI下拉状态栏第二次展开时，显示QSPanel快捷功能键默认是3行3列显示的 现在由于功能的需要修改为1行9列显示  
 这样就需要看详细布局的代码


QSPanel.java  
 路径为：  
 frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSPanel.java



```
@Inject
    public QSPanel(@Named(VIEW_CONTEXT) Context context, AttributeSet attrs,
            DumpController dumpController) {
        super(context, attrs);
        mContext = context;

        setOrientation(VERTICAL);
        mTileLayout = (QSTileLayout) LayoutInflater.from(mContext).inflate(
                R.layout.qs_paged_tile_layout, this, false);
        mTileLayout.setListening(mListening);
        addView((View) mTileLayout);
 mBrightnessView = LayoutInflater.from(mContext).inflate(
 R.layout.quick\_settings\_brightness\_dialog, this, false);
 addView(mBrightnessView);
 /\* UNISOC: Bug 1074234,885650 Super power feature @{ \*/
 if(SprdPowerManagerUtil.SUPPORT\_SUPER\_POWER\_SAVE){
 int mode = SprdPowerManagerUtil.getPowerSaveModeInternal();
 mMode = mode;
 updateVisiable(mode);
 }
 /\* @} \*/
 mQsTileRevealController = new QSTileRevealController(mContext, this,
 (PagedTileLayout) mTileLayout);

 addDivider();

 mFooter = new QSSecurityFooter(this, context);
 addView(mFooter.getView());
        updateResources();

        mBrightnessController = new BrightnessController(getContext(),
                findViewById(R.id.brightness_slider));
        mDumpController = dumpController;

    }

```

从 mQsTileRevealController = new QSTileRevealController(mContext, this,  
 (PagedTileLayout) mTileLayout);  
 看出PagedTileLayout 为每页的布局  
 PagedTileLayout又是实现QSTileLayout的一些接口  
 经过追踪代码发现 布局其实有frameworks/base/packages/SystemUI/src/com/android/systemui/qs/TileLayout.java  
 来实现的  
 所以具体行列修改如下：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/TileLayout.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/TileLayout.java
@@ -85,15 +85,15 @@ public class TileLayout extends ViewGroup implements QSTileLayout {
     public boolean updateResources() {
         final Resources res = mContext.getResources();
         /* UNISOC: Bug 1107201 modify for super power @{ */
-        final int columns = Math.max(1, res.getInteger(SprdPowerManagerUtil.isSuperPower() ?
-            R.integer.quick_settings_num_columns_for_ultraSave : R.integer.quick_settings_num_columns));
+        final int columns = 9/*Math.max(1, res.getInteger(SprdPowerManagerUtil.isSuperPower() ?
+            R.integer.quick_settings_num_columns_for_ultraSave : R.integer.quick_settings_num_columns))*/;
         /* @} */
         mCellHeight = mContext.getResources().getDimensionPixelSize(R.dimen.qs_tile_height);
         mCellMarginHorizontal = res.getDimensionPixelSize(R.dimen.qs_tile_margin_horizontal);
         mCellMarginVertical= res.getDimensionPixelSize(R.dimen.qs_tile_margin_vertical);
         mCellMarginTop = res.getDimensionPixelSize(R.dimen.qs_tile_margin_top);
         mSidePadding = res.getDimensionPixelOffset(R.dimen.qs_tile_layout_margin_side);
-        mMaxAllowedRows = Math.max(1, getResources().getInteger(R.integer.quick_settings_max_rows));
+        mMaxAllowedRows = 1/*Math.max(1, getResources().getInteger(R.integer.quick_settings_max_rows))*/;
         if (mColumns != columns) {
             mColumns = columns;
             requestLayout();

```

这样就修改为1行9列的布局了





