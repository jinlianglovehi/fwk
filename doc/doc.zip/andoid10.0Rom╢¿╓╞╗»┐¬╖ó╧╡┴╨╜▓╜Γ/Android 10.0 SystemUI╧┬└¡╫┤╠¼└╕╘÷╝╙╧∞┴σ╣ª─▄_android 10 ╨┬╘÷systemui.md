






### 1.概述


在10.0的系统产品开发中，系统原生的SystemUI下拉状态栏的QuickQSPanel区域有一行功能开关，点击打开各自的功能，由于产品需要要求在QuickQSPanel需要增加响铃功能开关功能，方便控制产品关于声音响铃静音功能，接下来就来实现这个功能


### 2.SystemUI下拉状态栏增加响铃功能核心类



```
frameworks/base/packages/SystemUI/res/values/config.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java

```

### 3.SystemUI下拉状态栏增加响铃功能的核心功能实现和分析


首选需要在config.xml中关于下拉状态栏相关属性的quick\_settings\_tiles\_default中添加响铃对应的  
 字符串来增加响铃功能  
 具体实现如下：


### 第一步 config.xml中添加ring 字符串表示响铃功能



```
diff --git a/frameworks/base/packages/SystemUI/res/values/config.xml b/frameworks/base/packages/SystemUI/res/values/config.xml
index b3b2ca4..d59ac48 100755 (executable)
--- a/frameworks/base/packages/SystemUI/res/values/config.xml
+++ b/frameworks/base/packages/SystemUI/res/values/config.xml
@@ -93,7 +93,7 @@
     <bool name="config\_navigation\_bar\_enable\_auto\_dim\_no\_visible\_wallpaper">true</bool>
 
     <!-- The maximum number of tiles in the QuickQSPanel -->
-    <integer name="quick\_qs\_panel\_max\_columns">6</integer>
+    <integer name="quick\_qs\_panel\_max\_columns">9</integer>
 
     <!-- Whether QuickSettings is in a phone landscape -->
     <bool name="quick\_settings\_wide">false</bool>
@@ -109,11 +109,11 @@
     <!-- The number of columns that the top level tiles span in the QuickSettings -->
     <integer name="quick\_settings\_user\_time\_settings\_tile\_span">1</integer>
 
-    <!-- The default tiles to display in QuickSettings rotation cast lte1,lte2,cell,airplane-->
+    <!-- The default tiles to display in QuickSettings -->
     <string name="quick\_settings\_tiles\_default" translatable="false">
-        volte1,volte2,wifi,bt,dnd,vowifi,onehand,flashlight,battery
+        volte1,volte2,wifi,bt,vowifi,onehand,ring,screenshot,cast,rotation,night,airplane,flashlight
     </string>
-
+    <string name="quick\_config\_icon\_mask" translatable="false">"M50,50m-50,0a50,50 0,1 1,100 0a50,50 0,1 1,-100 0"</string>
     <!-- The minimum number of tiles to display in QuickSettings -->
     <integer name="quick\_settings\_min\_num\_tiles">6</integer>

```

在quick\_settings\_tiles\_default增加ring代表响铃


### 第二步 首选增加RingTile.java 功能开关


根据其他Tiles的快捷功能键的相关接口，来实现响铃功能键的Tile，首选自定义RingTile来作为  
 下拉状态栏的响铃功能键 实现如下:  
 实现思路:根据AudioManager 来获取当前的响铃模式，然后来设置响铃模式  
 具体实现代码如下:



```
package com.android.systemui.qs.tiles;

import android.app.ActivityManager;
import android.content.Intent;
import android.service.quicksettings.Tile;
import android.widget.Switch;

import com.android.systemui.R;
import com.android.systemui.plugins.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSHost;
import com.android.systemui.qs.tileimpl.QSTileImpl;
import com.android.internal.util.ScreenshotHelper;
import android.os.RemoteException;
import android.os.Handler;
import android.util.Log;
import android.os.Message;
import javax.inject.Inject;
import android.media.AudioManager;
import android.content.Context;
/** Quick settings tile: Control flashlight **/
public class RingTile extends QSTileImpl<BooleanState>{

    private final Icon mIcon = ResourceIcon.get(R.drawable.ic_icon_information_h);
    private Handler mHandler;
    private AudioManager mAudioManager;
    @Inject
    public RingTile(QSHost host) {
        super(host);
        mHandler = new Handler();
        mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public BooleanState newTileState() {
        return new BooleanState();
    }

    @Override
    protected void handleClick() {
        //点击开关后来刷新背景
        boolean newState = !mState.value;
        refreshState(newState);
        //获取当前响铃模式 然后更改响铃模式
        int ringerMode = mAudioManager.getRingerMode();
		if(ringerMode!=AudioManager.RINGER_MODE_SILENT){
			mAudioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
		}else{
            mAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);	
		}
    }

    @Override
    protected void handleUpdateState(BooleanState state, Object arg) {
		int ringerMode = mAudioManager.getRingerMode();
        //根据state.value的值 来更换开关背景
        state.value = ringerMode!=AudioManager.RINGER_MODE_SILENT;
        state.icon = mIcon;
        state.label = mContext.getString(R.string.quick_settings_ring_label);
        state.contentDescription = mContext.getString(R.string.quick_settings_ring_label);
		state.state = state.value ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE;
    }

    @Override
    public int getMetricsCategory() {
        return 0;
    }

    @Override
    public Intent getLongClickIntent() {
        return new Intent();
    }

    @Override
    protected void handleSetListening(boolean listening) {

    }

    @Override
    public CharSequence getTileLabel() {
        return mContext.getString(R.string.quick_settings_ring_label);
    }
}

```

通过handleUpdateState更新响铃状态 在handleClick()相应响铃的相关功能


### 第三步 在QSFactoryImpl.java中添加加载RingTile的相关配置方法


frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java



```
diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
index ffca7b0..291a721 100755 (executable)
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
@@ -55,7 +55,8 @@ import com.android.systemui.qs.tiles.WorkModeTile;
 import com.android.systemui.util.leak.GarbageMonitor;
 import com.sprd.systemui.qs.tiles.LongScreenshotTile;
 import com.sprd.systemui.qs.tiles.OneHandTile;

+import com.android.systemui.qs.tiles.RingTile;
 import com.sprd.systemui.util.SprdPowerManagerUtil;
 
 import javax.inject.Inject;
@@ -90,7 +91,8 @@ public class QSFactoryImpl implements QSFactory {
     private final Provider<NfcTile> mNfcTileProvider;
     private final Provider<GarbageMonitor.MemoryTile> mMemoryTileProvider;
     private final Provider<UiModeNightTile> mUiModeNightTileProvider;
-

+    private final Provider<RingTile> mRingTileProvider;
     private QSTileHost mHost;
 
     @Inject
@@ -108,6 +110,8 @@ public class QSFactoryImpl implements QSFactory {
             Provider<LocationTile> locationTileProvider,
             Provider<CastTile> castTileProvider,
             Provider<HotspotTile> hotspotTileProvider,
+                       Provider<RingTile> ringTileProvider,
             Provider<UserTile> userTileProvider,
             Provider<BatterySaverTile> batterySaverTileProvider,
             Provider<DataSaverTile> dataSaverTileProvider,
@@ -136,6 +140,8 @@ public class QSFactoryImpl implements QSFactory {
         mNfcTileProvider = nfcTileProvider;
         mMemoryTileProvider = memoryTileProvider;
         mUiModeNightTileProvider = uiModeNightTileProvider;
+               mRingTileProvider = ringTileProvider;
     }
 
     public void setHost(QSTileHost host) {
@@ -183,6 +189,10 @@ public class QSFactoryImpl implements QSFactory {
                 return mLongScreenshotTileProvider.get();
             case "onehand":
                 return mOneHandTileProvider.get();

+                       case "ring":
+                return mRingTileProvider.get();
             case "location":
                 return mLocationTileProvider.get();
  }

```

通过响铃的ring属性来获取响铃对应的自定义类RingTile，从而实现响铃的相关功能  
 整个添加流程就是这样，编译发现响铃功能已经正常使用了





