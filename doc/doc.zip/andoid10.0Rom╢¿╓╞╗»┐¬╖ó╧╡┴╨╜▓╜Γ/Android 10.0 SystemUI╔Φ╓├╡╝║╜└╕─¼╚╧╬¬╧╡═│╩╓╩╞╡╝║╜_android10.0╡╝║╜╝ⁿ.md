






### 1.概述


在10.0 的系统中，导航栏默认的是三键导航，Home Back Recent键三个键显示在底部  
 但是对于一些全屏的app 感觉操作起来不太方便，所以客户要求使用系统手势导航这时  
 系统底部就不会被占用了


### 2.SystemUI设置导航栏默认为系统手势导航的核心类



```
frameworks\base\core\res\res\values\config.xml
frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

```

### 3.SystemUI设置导航栏默认为系统手势导航的核心功能分析和实现


这样该怎么设置系统手势为默认的导航方式呢，系统手势在系统开机的时候会读取config文件，看设置的是哪种系统手势


### 第一步在config.xml中设置系统手势方式


路径为：frameworks\base\core\res\res\values\config.xml



```
 <!-- Controls the opacity of the navigation bar depending on the visibility of the
         various workspace stacks.
         0 - Nav bar is always opaque when either the freeform stack or docked stack is visible.
         1 - Nav bar is always translucent when the freeform stack is visible, otherwise always
             opaque.
         2 - Nav bar is never forced opaque.
         -->
    <integer name="config\_navBarOpacityMode">0</integer>

    <!-- Controls the navigation bar interaction mode:
         0: 3 button mode (back, home, overview buttons)
         1: 2 button mode (back, home buttons + swipe up for overview)
         2: gestures only for back, home and overview -->
    <integer name="config\_navBarInteractionMode">0</integer>

    <!-- Controls whether the nav bar can move from the bottom to the side in landscape.
         Only applies if the device display is not square. -->
    <bool name="config\_navBarCanMove">true</bool>

    <!-- Controls whether the navigation bar lets through taps. -->
    <bool name="config\_navBarTapThrough">false</bool>

    <!-- Controls whether the side edge gestures can always trigger the transient nav bar to
         show. -->
    <bool name="config\_navBarAlwaysShowOnSideEdgeGesture">false</bool>

```

通过注释我们可以看到2 就是手势导航所以  
 修改`<integer name="config_navBarInteractionMode">2</integer>`


### 第二步：在DatabaseHelper.java中设置默认导航栏为手势导航


在系统数据库里面增加设置默认系统手势功能的相关属性  
 在这里通过调用系统手势的相关api来设置系统导航为默认手势导航



```
      @Override
      public void onCreate(SQLiteDatabase db) {
          db.execSQL("CREATE TABLE system (" +
                      "\_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                      "name TEXT UNIQUE ON CONFLICT REPLACE," +
                      "value TEXT" +
                      ");");
          db.execSQL("CREATE INDEX systemIndex1 ON system (name);");
  
          createSecureTable(db);
  
          // Only create the global table for the singleton 'owner/system' user
          if (mUserHandle == UserHandle.USER_SYSTEM) {
              createGlobalTable(db);
          }
  
          db.execSQL("CREATE TABLE bluetooth\_devices (" +
                      "\_id INTEGER PRIMARY KEY," +
                      "name TEXT," +
                      "addr TEXT," +
                      "channel INTEGER," +
                      "type INTEGER" +
                      ");");
  
          db.execSQL("CREATE TABLE bookmarks (" +
                      "\_id INTEGER PRIMARY KEY," +
                      "title TEXT," +
                      "folder TEXT," +
                      "intent TEXT," +
                      "shortcut INTEGER," +
                      "ordering INTEGER" +
                      ");");
  
          db.execSQL("CREATE INDEX bookmarksIndex1 ON bookmarks (folder);");
          db.execSQL("CREATE INDEX bookmarksIndex2 ON bookmarks (shortcut);");
  
          // Populate bookmarks table with initial bookmarks
          boolean onlyCore = false;
          try {
              onlyCore = IPackageManager.Stub.asInterface(ServiceManager.getService(
                      "package")).isOnlyCoreApps();
          } catch (RemoteException e) {
          }
          if (!onlyCore) {
              loadBookmarks(db);
          }
  
          // Load initial volume levels into DB
          loadVolumeLevels(db);
  
          // Load inital settings values
          loadSettings(db);
      }
  
private void loadSettings(SQLiteDatabase db) {
          loadSystemSettings(db);
          loadSecureSettings(db);
          // The global table only exists for the 'owner/system' user
          if (mUserHandle == UserHandle.USER_SYSTEM) {
              loadGlobalSettings(db);
          }
      }
  
      private void loadSystemSettings(SQLiteDatabase db) {
          SQLiteStatement stmt = null;
          try {
              stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                      + " VALUES(?,?);");
  
              loadBooleanSetting(stmt, Settings.System.DIM_SCREEN,
                      R.bool.def_dim_screen);
              loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                      R.integer.def_screen_off_timeout);
  
              // Set default cdma DTMF type
              loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);
  
              // Set default hearing aid
              loadSetting(stmt, Settings.System.HEARING_AID, 0);
  
              // Set default tty mode
              loadSetting(stmt, Settings.System.TTY_MODE, 0);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                      R.integer.def_screen_brightness);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_FOR_VR,
                      com.android.internal.R.integer.config_screenBrightnessForVrSettingDefault);
  
              loadBooleanSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_MODE,
                      R.bool.def_screen_brightness_automatic_mode);
  
              loadBooleanSetting(stmt, Settings.System.ACCELEROMETER_ROTATION,
                      R.bool.def_accelerometer_rotation);
  
              loadDefaultHapticSettings(stmt);
  
              loadBooleanSetting(stmt, Settings.System.NOTIFICATION_LIGHT_PULSE,
                      R.bool.def_notification_pulse);
  
              loadUISoundEffectsSettings(stmt);
  
              loadIntegerSetting(stmt, Settings.System.POINTER_SPEED,
                      R.integer.def_pointer_speed);
  
              /*
               * IMPORTANT: Do not add any more upgrade steps here as the global,
               * secure, and system settings are no longer stored in a database
               * but are kept in memory and persisted to XML.
               *
               * See: SettingsProvider.UpgradeController#onUpgradeLocked
               */
          } finally {
              if (stmt != null) stmt.close();
          }
      }

```

在添加loadSettings(SQLiteDatabase db)设置系统默认手势的方法来实现系统导航为  
 默认手势导航



```
 int navBar_mode = mContext.getResources().getInteger(com.android.internal.R.integer.config_navBarInteractionMode);
  if(navBar_mode == 2){
     try {
               IOverlayManager mOverlayManager = IOverlayManager.Stub.
       asInterface(ServiceManager.getService(Context.OVERLAY_SERVICE));
    mOverlayManager.setEnabledExclusiveInCategory(NAV_BAR_MODE_GESTURAL_OVERLAY, USER_CURRENT);
   } catch (RemoteException e) {
    throw e.rethrowFromSystemServer();
   }

```

通过在loadSettings(SQLiteDatabase db)实现为：  
 具体实现如下:



```
private void loadSettings(SQLiteDatabase db) {
          loadSystemSettings(db);
          loadSecureSettings(db);
          // The global table only exists for the 'owner/system' user
          if (mUserHandle == UserHandle.USER_SYSTEM) {
              loadGlobalSettings(db);
          }
           int navBar_mode = mContext.getResources().getInteger(com.android.internal.R.integer.config_navBarInteractionMode);
  if(navBar_mode == 2){
     try {
               IOverlayManager mOverlayManager = IOverlayManager.Stub.
       asInterface(ServiceManager.getService(Context.OVERLAY_SERVICE));
    mOverlayManager.setEnabledExclusiveInCategory(NAV_BAR_MODE_GESTURAL_OVERLAY, USER_CURRENT);
   } catch (RemoteException e) {
    throw e.rethrowFromSystemServer();
   }
      }

```

然后编译发现功能已经实现了





