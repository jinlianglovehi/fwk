



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.核心代码功能分析](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1BatterySaverTile.java 省电模式功能开关相关代码](#%C2%A0%C2%A0%203.1BatterySaverTile.java%20%E7%9C%81%E7%94%B5%E6%A8%A1%E5%BC%8F%E5%8A%9F%E8%83%BD%E5%BC%80%E5%85%B3%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


在系统中系统设置里面省电模式的选择中，有智能省电模式 省电模式 和超级省电模式三种  
 由于对系统做了大量定制，所以在进入省电模式的时候 会出现某些不必要的问题，于是觉得  
 就要求去掉省电模式 不让平板进入省电模式


## 2.核心代码



```
frameworks\base\packages\SystemUI\src\com\android\systemui\qs\tiles\BatterySaverTile.java
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\policy\BatteryController.java
frameworks/base/packages/SettingsLib/src/com/android/settingslib/fuelgauge/BatterySaverUtils.java
frameworks/base/core/java/android/os/PowerManager.java
frameworks/base/services/core/java/com/android/server/power/PowerManagerService.java
frameworks\base\services\core\java\com\android\server\power\batterysaver
```

## 3.核心代码功能分析


在系统SystemUI的下拉状态栏中，在通过下拉状态栏后，发现有一个  
 省电快捷模块，通过查看SystemUI的相关源码发现，这个省电模块就是  
 BatterySaverTile.java通过查看BatterySaverTile.java的相关源码发现，在  
 BatterySaverTile的handleCllick响应了对于省电模式的点击。  
 mBatteryController是BatteryController类的一个实例化的对象，  
 所以setPowerSaveMode是BatteryControllerImpl中进行了实现。  
 最终省电模式功能还是在Powermanager.java的省电模式的模块中实现的  
 最终的功能的，所以还是需要在Powermanager.java来实现去掉省电模式的功能



###    3.1BatterySaverTile.java 省电模式功能开关相关代码



```
      @Override
    protected void handleClick() {
        mBatteryController.setPowerSaveMode(!mPowerSave);
    }
   
    @Override
    public void setPowerSaveMode(boolean powerSave) {
        BatterySaverUtils.setPowerSaveMode(mContext, powerSave, /*needFirstTimeWarning*/ true);
    }
   接下来由BatterySaverUtils.setPowerSaveMode()处理事件
   public static synchronized boolean setPowerSaveMode(Context context,
            boolean enable, boolean needFirstTimeWarning) {
        if (DEBUG) {
            Log.d(TAG, "Battery saver turning " + (enable ? "ON" : "OFF"));
        }
        final ContentResolver cr = context.getContentResolver();

        final Bundle confirmationExtras = new Bundle(1);
        confirmationExtras.putBoolean(EXTRA_CONFIRM_TEXT_ONLY, false);
        if (enable && needFirstTimeWarning
                && maybeShowBatterySaverConfirmation(context, confirmationExtras)) {
            return false;
        }
        if (enable && !needFirstTimeWarning) {
            setBatterySaverConfirmationAcknowledged(context);
        }

        if (context.getSystemService(PowerManager.class).setPowerSaveModeEnabled(enable)) {
            if (enable) {
                final int count =
                        Secure.getInt(cr, Secure.LOW_POWER_MANUAL_ACTIVATION_COUNT, 0) + 1;
                Secure.putInt(cr, Secure.LOW_POWER_MANUAL_ACTIVATION_COUNT, count);

                final Parameters parameters = new Parameters(context);

                if ((count >= parameters.startNth)
                        && (count <= parameters.endNth)
                        && Global.getInt(cr, Global.LOW_POWER_MODE_TRIGGER_LEVEL, 0) == 0
                        && Secure.getInt(cr,
                        Secure.SUPPRESS_AUTO_BATTERY_SAVER_SUGGESTION, 0) == 0) {
                    showAutoBatterySaverSuggestion(context, confirmationExtras);
                }
            }

            return true;
        }
        return false;
    }



    public boolean setPowerSaveModeEnabled(boolean mode) {
        try {
            return mService.setPowerSaveModeEnabled(mode);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }
   



```

BatterySaverTile的handleCllick响应了对于省电模式的点击。调用mBatteryController的setPowerSaveMode方法


这个类里面，实现的方法主要为context.getSystemService(PowerManager.class).setPowerSaveModeEnabled(enable)。  
 会通过getSystemService去拿到PowerManager的对象，然后去调用setPowerSaveModeEnabled的函数进行具体的设置。


接下来具体看下BatterySaverStateMachine中的相关代码



```
BatterySaverStateMachine中的相关代码
    /**
     * {@link com.android.server.power.PowerManagerService} calls it when
     * {@link android.os.PowerManager#setPowerSaveModeEnabled} is called.
     *
     * Note this could? be called before {@link #onBootCompleted} too.
     */
    public void setBatterySaverEnabledManually(boolean enabled) {
        if (DEBUG) {
            Slog.d(TAG, "setBatterySaverEnabledManually: enabled=" + enabled);
        }
        synchronized (mLock) {
            updateStateLocked(true, enabled);
            // TODO: maybe turn off adaptive if it's on and advertiseIsEnabled is true and
            //  enabled is false
        }
    }

/**
     * Update the state machine based on the current settings and battery/charge status.
     *
     * @param manual Whether the change was made by the user.
     * @param enable Whether the user wants to turn battery saver on or off. Is only used if {@param
     *               manual} is true.
     */
    @GuardedBy("mLock")
    private void updateStateLocked(boolean manual, boolean enable) {
        if (!manual && !(mBootCompleted && mSettingsLoaded && mBatteryStatusSet)) {
            return; // Not fully initialized yet.
        }

        switch (mState) {
            case STATE_OFF: {
                if (!PowerManagerEx.isPowerControllerEnabled()) {
                    if (!mIsPowered) {
                        if (manual) {
                            if (!enable) {
                                Slog.e(TAG, "Tried to disable BS when it's already OFF");
                                return;
                            }
                            enableBatterySaverLocked(/*enable*/ true, /*manual*/ true,
                                    BatterySaverController.REASON_MANUAL_ON);
                            hideStickyDisabledNotification();
                            mState = STATE_MANUAL_ON;
                        } else if (isAutomaticModeActiveLocked() && isInAutomaticLowZoneLocked()) {
                            enableBatterySaverLocked(/*enable*/ true, /*manual*/ false,
                                    BatterySaverController.REASON_PERCENTAGE_AUTOMATIC_ON);
                            hideStickyDisabledNotification();
                            mState = STATE_AUTOMATIC_ON;
                        } else if (isDynamicModeActiveLocked() && isInDynamicLowZoneLocked()) {
                            enableBatterySaverLocked(/*enable*/ true, /*manual*/ false,
                                    BatterySaverController.REASON_DYNAMIC_POWER_SAVINGS_AUTOMATIC_ON);
                            hideStickyDisabledNotification();
                            mState = STATE_AUTOMATIC_ON;
                        }
                    }
                } else {
                    if (manual) {
                        if (!enable) {
                            Slog.e(TAG, "Tried to disable BS when it's already OFF");
                            return;
                        }

                        Slog.d(TAG, "enable battery saver manually");
                        enableBatterySaverLocked(/*enable*/ true, /*manual*/ true,
                                BatterySaverController.REASON_MANUAL_ON);
                        hideStickyDisabledNotification();
                        mState = STATE_MANUAL_ON;
                    }
                }
                break;
            }

            case STATE_MANUAL_ON: {
                if (manual) {
                    if (enable) {
                        Slog.e(TAG, "Tried to enable BS when it's already MANUAL_ON");
                        return;
                    }
                    enableBatterySaverLocked(/*enable*/ false, /*manual*/ true,
                            BatterySaverController.REASON_MANUAL_OFF);
                    mState = STATE_OFF;
                    mEnabledReason = "";
                } else if (mIsPowered && (!PowerManagerEx.isPowerControllerEnabled() || "command".equals(mEnabledReason))) {
                    enableBatterySaverLocked(/*enable*/ false, /*manual*/ false,
                            BatterySaverController.REASON_PLUGGED_IN);
                    if (mSettingBatterySaverEnabledSticky
                            && !mBatterySaverStickyBehaviourDisabled) {
                        mState = STATE_PENDING_STICKY_ON;
                    } else {
                        mState = STATE_OFF;
                    }
                    mEnabledReason = "";
                }
                break;
            }

 ....

            default:
                Slog.wtf(TAG, "Unknown state: " + mState);
                break;
        }
    }
```

通过代码分析发现最终调用PowerManager.java的代码最终处理省电模式


接下来看下Powermanager.java的相关代码



```
接下来在继续看下PowerManagerService.java中关于setPowerSaveModeEnabled()的调用
           @Override // Binder call
        public boolean setPowerSaveModeEnabled(boolean enabled) {
            if (mContext.checkCallingOrSelfPermission(android.Manifest.permission.POWER_SAVER)
                    != PackageManager.PERMISSION_GRANTED) {
                mContext.enforceCallingOrSelfPermission(
                        android.Manifest.permission.DEVICE_POWER, null);
            }
            final long ident = Binder.clearCallingIdentity();
            try {
                return setLowPowerModeInternal(enabled);
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }

    private boolean setLowPowerModeInternal(boolean enabled) {
        synchronized (mLock) {
            if (DEBUG) {
                Slog.d(TAG, "setLowPowerModeInternal " + enabled + " mIsPowered=" + mIsPowered);
            }

            // NOTE: Bug #746963 low power Feature BEG-->
            if (!PowerManagerEx.isPowerControllerEnabled()) {
                if (mIsPowered) {
                    return false;
                }
            }
            // <-- NOTE: Bug #746963 low power Feature END

            mBatterySaverStateMachine.setBatterySaverEnabledManually(enabled);

            return true;
        }
    }



```

setLowPowerModeInternal的操作其实是很简单的，使用BatterySaverStateMachine的对象mBatterySaverStateMachine，去调用了setBatterySaverEnabledManually。


综上所述 其实就是在PowerManagerService.java 中 设置省电模式 setPowerSaveModeEnabled(boolean enabled)里面修改


最终修改为:



```
具体修改如下:
        public boolean setPowerSaveModeEnabled(boolean enabled) {
            if (mContext.checkCallingOrSelfPermission(android.Manifest.permission.POWER_SAVER)
                    != PackageManager.PERMISSION_GRANTED) {
                mContext.enforceCallingOrSelfPermission(
                        android.Manifest.permission.DEVICE_POWER, null);
            }
            final long ident = Binder.clearCallingIdentity();
            try {
               - return setLowPowerModeInternal(enabled);
               + return setLowPowerModeInternal(false);
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }

```



