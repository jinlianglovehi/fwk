






### 1.概述


在系统原生10.0 Launcher3的双层布局的页面 底部有一个箭头 点击一下箭头会进入apps 页面，其实作用也不大  
 由于客户需求要求去掉这个箭头布局 今天就来看看这个箭头布局


### 2. Launcher3 去掉底部箭头布局的核心代码



```
packages/apps/Launcher3/res/launcher.xml
packages/apps/Launcher3/src/com/android/launcher3/views/ScrimView.java

```

### 3. Launcher3 去掉底部箭头布局的核心代码功能分析


底部箭头是在launcher3首页布局的，所以需要  
 首先看下launcher.xml布局


### 3.1launcher.xml布局分析



```
<com.android.launcher3.LauncherRootView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:id="@+id/launcher"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:fitsSystemWindows="true">

    <com.android.launcher3.dragndrop.DragLayer
        android:id="@+id/drag\_layer"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:importantForAccessibility="no">

        <!-- The workspace contains 5 screens of cells -->
        <!-- DO NOT CHANGE THE ID -->
        <com.android.launcher3.Workspace
            android:id="@+id/workspace"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent"
            android:layout_gravity="center"
            android:theme="@style/HomeScreenElementTheme"
            launcher:pageIndicator="@+id/page\_indicator" />

        <!-- DO NOT CHANGE THE ID -->
        <include
            android:id="@+id/hotseat"
            layout="@layout/hotseat" />

        <include
            android:id="@+id/overview\_panel"
            layout="@layout/overview\_panel"
            android:visibility="gone" />

        <!-- Keep these behind the workspace so that they are not visible when
         we go into AllApps -->
        <com.android.launcher3.pageindicators.WorkspacePageIndicator
            android:id="@+id/page\_indicator"
            android:layout_width="match\_parent"
            android:layout_height="@dimen/vertical\_drag\_handle\_size"
            android:layout_gravity="bottom|center\_horizontal"
            android:theme="@style/HomeScreenElementTheme" />

        <include
            android:id="@+id/drop\_target\_bar"
            layout="@layout/drop\_target\_bar" />

        <include
            android:id="@+id/scrim\_view"
            layout="@layout/scrim\_view" />

        <include
            android:id="@+id/apps\_view"
            layout="@layout/all\_apps"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent" />

    </com.android.launcher3.dragndrop.DragLayer>

</com.android.launcher3.LauncherRootView>

```

通过上述代码分析发现  
 其中   
 就是箭头布局  
 而scrim\_view.xml的布局



```
<com.android.launcher3.views.ScrimView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:id="@+id/scrim\_view" />

```

ScrimView就是箭头的布局文件  
 接下来看下ScrimView.java 源码


### 3.2ScrimView.java相关箭头源码分析


接下来看ScrimView关于箭头布局的相关代码  
 路径为:packages/apps/Launcher3/src/com/android/launcher3/views/ScrimView.java



```
public class ScrimView extends View implements Insettable, OnChangeListener,
        AccessibilityStateChangeListener, StateListener {

    public static final Property<ScrimView, Integer> DRAG_HANDLE_ALPHA =
            new Property<ScrimView, Integer>(Integer.TYPE, "dragHandleAlpha") {

                @Override
                public Integer get(ScrimView scrimView) {
                    return scrimView.mDragHandleAlpha;
                }

                @Override
                public void set(ScrimView scrimView, Integer value) {
                    scrimView.setDragHandleAlpha(value);
                }
            };
            
 @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        updateDragHandleBounds();
    }
    
    protected void updateDragHandleBounds() {
        DeviceProfile grid = mLauncher.getDeviceProfile();
        final int left;
        final int width = getMeasuredWidth();
        final int top = getMeasuredHeight() - mDragHandleSize - grid.getInsets().bottom;
        final int topMargin;

        if (grid.isVerticalBarLayout()) {
            topMargin = grid.workspacePadding.bottom;
            if (grid.isSeascape()) {
                left = width - grid.getInsets().right - mDragHandleSize;
            } else {
                left = mDragHandleSize + grid.getInsets().left;
            }
        } else {
            left = (width - mDragHandleSize) / 2;
            topMargin = grid.hotseatBarSizePx;
        }
        mDragHandleBounds.offsetTo(left, top - topMargin);
        mHitRect.set(mDragHandleBounds);
        float inset = -mDragHandleSize / 2;
        mHitRect.inset(inset, inset);

        if (mDragHandle != null) {
            mDragHandle.setBounds(mDragHandleBounds);
        }
    }

    @Override
    public void onAccessibilityStateChanged(boolean enabled) {
        LauncherStateManager stateManager = mLauncher.getStateManager();
        stateManager.removeStateListener(this);

        if (enabled) {
            stateManager.addStateListener(this);
            handleStateChangedComplete(mLauncher.getStateManager().getState());
        } else {
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        }
        updateDragHandleVisibility(null);
    }

    private void updateDragHandleVisibility(Drawable recycle) {
        boolean visible = mLauncher.getDeviceProfile().isVerticalBarLayout() || mAM.isEnabled();
        boolean wasVisible = mDragHandle != null;
        if (visible != wasVisible) {
            if (visible) {
                mDragHandle = recycle != null ? recycle :
                        mLauncher.getDrawable(R.drawable.drag_handle_indicator);
                mDragHandle.setBounds(mDragHandleBounds);

                updateDragHandleAlpha();
            } else {
                mDragHandle = null;
            }
            invalidate();
        }
    }

```

在代码中onMeasure()负责测量布局，而真正工作的是updateDragHandleBounds()而最终绘制图片的是在updateDragHandleVisibility(Drawable recycle)中绘制，通过获取图片  
 R.drawable.drag\_handle\_indicator 就是箭头的UI图片  
 所以就在updateDragHandleVisibility 修改如下:



```
   private void updateDragHandleVisibility(Drawable recycle) {
     -   boolean visible = mLauncher.getDeviceProfile().isVerticalBarLayout() || mAM.isEnabled();
      + boolean visible = false;
  boolean wasVisible = mDragHandle != null;
        if (visible != wasVisible) {
            if (visible) {
                mDragHandle = recycle != null ? recycle :
                        mLauncher.getDrawable(R.drawable.drag_handle_indicator);
                mDragHandle.setBounds(mDragHandleBounds);

                updateDragHandleAlpha();
            } else {
                mDragHandle = null;
            }
            invalidate();
        }
    }

```

直接不去绘制设置visible为false即可  
 这样编译Launcher3 发现箭头就没有了





