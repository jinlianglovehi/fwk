






对于定制化开发的，由于硬件板卡不同，系统源码中，对于系统属性的值也需要做相应的修改  
 今天就来实现对Build.ID和Build.DISPLAY的值来做修改  
 先看下Build.java的源码



```
public class Build {
    private static final String TAG = "Build";

    /** Value used for when a build property is unknown. */
    public static final String UNKNOWN = "unknown";

    /** Either a changelist number, or a label like "M4-rc20". */
    public static final String ID = getString("ro.build.id");

    /** A build ID string meant for displaying to the user */
    public static final String DISPLAY = getString("ro.build.display.id");

    /** The name of the overall product. */
    public static final String PRODUCT = getString("ro.product.name");

    /** The name of the industrial design. */
    public static final String DEVICE = getString("ro.product.device");

    /** The name of the underlying board, like "goldfish". */
    public static final String BOARD = getString("ro.product.board");

    /**
     * The name of the instruction set (CPU type + ABI convention) of native code.
     *
     * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
     */
    @Deprecated
    public static final String CPU_ABI;

    /**
     * The name of the second instruction set (CPU type + ABI convention) of native code.
     *
     * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
     */
    @Deprecated
    public static final String CPU_ABI2;

    /** The manufacturer of the product/hardware. */
    public static final String MANUFACTURER = getString("ro.product.manufacturer");

    /** The consumer-visible brand with which the product/hardware will be associated, if any. */
    public static final String BRAND = getString("ro.product.brand");

    /** The end-user-visible name for the end product. */
    public static final String MODEL = getString("ro.product.model");

    /** The system bootloader version number. */
    public static final String BOOTLOADER = getString("ro.bootloader");

    /**
     * The radio firmware version number.
     *
     * @deprecated The radio firmware version is frequently not
     * available when this class is initialized, leading to a blank or
     * "unknown" value for this string.  Use
     * {@link #getRadioVersion} instead.
     */
    @Deprecated
    public static final String RADIO = getString(TelephonyProperties.PROPERTY_BASEBAND_VERSION);

    /** The name of the hardware (from the kernel command line or /proc). */
    public static final String HARDWARE = getString("ro.hardware");

    /**
     * Whether this build was for an emulator device.
     * @hide
     */
    @TestApi
    public static final boolean IS_EMULATOR = getString("ro.kernel.qemu").equals("1");

    /**
     * A hardware serial number, if available. Alphanumeric only, case-insensitive.
     * This field is always set to {@link Build#UNKNOWN}.
     *
     * @deprecated Use {@link #getSerial()} instead.
     **/
    @Deprecated
    // IMPORTANT: This field should be initialized via a function call to
    // prevent its value being inlined in the app during compilation because
    // we will later set it to the value based on the app's target SDK.
 public static final String SERIAL = getString("no.such.thing");

 /\*\*
 \* Gets the hardware serial number, if available.
 \*
 \* <p class="note"><b>Note:</b> Root access may allow you to modify device identifiers, such as
 \* the hardware serial number. If you change these identifiers, you can use
 \* <a href="/training/articles/security-key-attestation.html">key attestation</a> to obtain
 \* proof of the device's original identifiers.
     *
     * <p>Requires Permission: READ_PRIVILEGED_PHONE_STATE, for the calling app to be the device or
     * profile owner and have the READ_PHONE_STATE permission, or that the calling app has carrier
     * privileges (see {@link android.telephony.TelephonyManager#hasCarrierPrivileges}). The profile
     * owner is an app that owns a managed profile on the device; for more details see <a
     * href="https://developer.android.com/work/managed-profiles">Work profiles</a>. Profile owner
     * access is deprecated and will be removed in a future release.
     *
     * <p>If the calling app does not meet one of these requirements then this method will behave
     * as follows:
     *
     * <ul>
     *     <li>If the calling app's target SDK is API level 28 or lower and the app has the
 \* READ\_PHONE\_STATE permission then {@link Build#UNKNOWN} is returned.</li>
 \* <li>If the calling app's target SDK is API level 28 or lower and the app does not have
     *     the READ_PHONE_STATE permission, or if the calling app is targeting API level 29 or
     *     higher, then a SecurityException is thrown.</li>
     * </ul>
     * *
     * @return The serial number if specified.
     */
    @SuppressAutoDoc // No support for device / profile owner.
    @RequiresPermission(Manifest.permission.READ_PRIVILEGED_PHONE_STATE)
    public static String getSerial() {
        IDeviceIdentifiersPolicyService service = IDeviceIdentifiersPolicyService.Stub
                .asInterface(ServiceManager.getService(Context.DEVICE_IDENTIFIERS_SERVICE));
        try {
            Application application = ActivityThread.currentApplication();
            String callingPackage = application != null ? application.getPackageName() : null;
            return service.getSerialForPackage(callingPackage);
        } catch (RemoteException e) {
            e.rethrowFromSystemServer();
        }
        return UNKNOWN;
    }

    /**
     * An ordered list of ABIs supported by this device. The most preferred ABI is the first
     * element in the list.
     *
     * See {@link #SUPPORTED\_32\_BIT\_ABIS} and {@link #SUPPORTED\_64\_BIT\_ABIS}.
     */
    public static final String[] SUPPORTED_ABIS = getStringList("ro.product.cpu.abilist", ",");

    /**
     * An ordered list of <b>32 bit</b> ABIs supported by this device. The most preferred ABI
     * is the first element in the list.
     *
     * See {@link #SUPPORTED\_ABIS} and {@link #SUPPORTED\_64\_BIT\_ABIS}.
     */
    public static final String[] SUPPORTED_32_BIT_ABIS =
            getStringList("ro.product.cpu.abilist32", ",");

    /**
     * An ordered list of <b>64 bit</b> ABIs supported by this device. The most preferred ABI
     * is the first element in the list.
     *
     * See {@link #SUPPORTED\_ABIS} and {@link #SUPPORTED\_32\_BIT\_ABIS}.
     */
    public static final String[] SUPPORTED_64_BIT_ABIS =
            getStringList("ro.product.cpu.abilist64", ",");

    /** {@hide} */
    @TestApi
    public static boolean is64BitAbi(String abi) {
        return VMRuntime.is64BitAbi(abi);
    }

    static {
        /*
         * Adjusts CPU_ABI and CPU_ABI2 depending on whether or not a given process is 64 bit.
         * 32 bit processes will always see 32 bit ABIs in these fields for backward
         * compatibility.
         */
        final String[] abiList;
        if (VMRuntime.getRuntime().is64Bit()) {
            abiList = SUPPORTED_64_BIT_ABIS;
        } else {
            abiList = SUPPORTED_32_BIT_ABIS;
        }

        CPU_ABI = abiList[0];
        if (abiList.length > 1) {
            CPU_ABI2 = abiList[1];
        } else {
            CPU_ABI2 = "";
        }
    }

    @UnsupportedAppUsage
    private static String getString(String property) {
        return SystemProperties.get(property, UNKNOWN);
    }

```

通过源码发现 Build.ID 就是获取系统属性ro.build.id的值  
 Build.DISPLAY 就是系统属性ro.build.display.id的值  
 而系统的这些属性值 都是在而ro.product.model的值是在build/make/tools/buildinfo\_common.sh和build/make/tools/buildinfo.sh 根据系统信息编译生成的


接下来我们看build/make/tools/buildinfo.sh的源码



```
#!/bin/bash

echo "# begin build properties"
echo "# autogenerated by buildinfo.sh"

echo "ro.build.id=$BUILD\_ID"
echo "ro.build.display.id=$BUILD\_DISPLAY\_ID"
echo "ro.build.version.incremental=$BUILD\_NUMBER"
echo "ro.build.version.sdk=$PLATFORM\_SDK\_VERSION"
echo "ro.build.version.preview\_sdk=$PLATFORM\_PREVIEW\_SDK\_VERSION"
echo "ro.build.version.preview\_sdk\_fingerprint=$PLATFORM\_PREVIEW\_SDK\_FINGERPRINT"
echo "ro.build.version.codename=$PLATFORM\_VERSION\_CODENAME"
echo "ro.build.version.all\_codenames=$PLATFORM\_VERSION\_ALL\_CODENAMES"
echo "ro.build.version.release=$PLATFORM\_VERSION"
echo "ro.build.version.security\_patch=$PLATFORM\_SECURITY\_PATCH"
echo "ro.build.version.base\_os=$PLATFORM\_BASE\_OS"
echo "ro.build.version.min\_supported\_target\_sdk=$PLATFORM\_MIN\_SUPPORTED\_TARGET\_SDK\_VERSION"
echo "ro.build.date=`$DATE`"
echo "ro.build.date.utc=`$DATE +%s`"
echo "ro.build.type=$TARGET\_BUILD\_TYPE"
echo "ro.build.user=$BUILD\_USERNAME"
echo "persist.sys.timezone=Asia/Shanghai"
echo "ro.config.media\_vol\_default=20"
echo "ro.product.bt=MID"

if [ -n "$BRANCH\_BUILDTYPE" ] ; then
  echo "ro.sprd.extrainfo=$BRANCH\_BUILDTYPE"
fi
if test "$HOSTNAME" = ""
then
 echo "ro.build.host=$BUILD\_HOSTNAME"
else
 echo "ro.build.host=$HOSTNAME"
fi

echo "ro.build.tags=$BUILD\_VERSION\_TAGS"
echo "ro.build.flavor=$TARGET\_BUILD\_FLAVOR"
if [ -n "$BOARD\_BUILD\_SYSTEM\_ROOT\_IMAGE" ] ; then
  echo "ro.build.system\_root\_image=$BOARD\_BUILD\_SYSTEM\_ROOT\_IMAGE"
fi
if [ -n "$AB\_OTA\_UPDATER" ] ; then
  echo "ro.build.ab\_update=$AB\_OTA\_UPDATER"
fi

# These values are deprecated, use "ro.product.cpu.abilist"
# instead (see below).
echo "# ro.product.cpu.abi and ro.product.cpu.abi2 are obsolete,"
echo "# use ro.product.cpu.abilist instead."
echo "ro.product.cpu.abi=$TARGET\_CPU\_ABI"
if [ -n "$TARGET\_CPU\_ABI2" ] ; then
  echo "ro.product.cpu.abi2=$TARGET\_CPU\_ABI2"
fi
echo "ro.product.cpu.abilist=$TARGET\_CPU\_ABI\_LIST"
echo "ro.product.cpu.abilist32=$TARGET\_CPU\_ABI\_LIST\_32\_BIT"
echo "ro.product.cpu.abilist64=$TARGET\_CPU\_ABI\_LIST\_64\_BIT"

if [ -n "$PRODUCT\_DEFAULT\_LOCALE" ] ; then
  echo "ro.product.locale=$PRODUCT\_DEFAULT\_LOCALE"
fi
echo "ro.wifi.channels=$PRODUCT\_DEFAULT\_WIFI\_CHANNELS"

echo "# ro.build.product is obsolete; use ro.product.device"
echo "ro.build.product=$TARGET\_DEVICE"

echo "# Do not try to parse description or thumbprint"
echo "ro.build.description=$PRIVATE\_BUILD\_DESC"
if [ -n "$BUILD\_THUMBPRINT" ] ; then
  echo "ro.build.thumbprint=$BUILD\_THUMBPRINT"
fi

echo "# end build properties"

```

发现echo “ro.build.id=$ BUILD\_ID”  
 echo “ro.build.display.id=$ BUILD\_DISPLAY\_ID”  
 在这里定义的值



```
而BUILD_DISPLAY_ID在文件build/core/Makefile中:
BUILD_DISPLAY_ID := $(BUILD\_ID).$(BUILD\_NUMBER)
其中 BUILD_ID在build/core/build_id.mk中赋值
BUILD_ID:=OPENMASTER
BUILD_NUMBER在 build/core/version_defaults.mk中赋值:
BUILD_NUMBER := eng.$(USER).$(shell date +%Y%m%d.%H%M%S)

```

所以修改BUILD\_ID的值 就是在build/core/build\_id.mk 中修改即可


而BUILD\_DISPLAY\_ID的值 在build/core/Makefile  
 中修改为:



```
ifeq ($(TARGET\_BUILD\_VARIANT),user)
  # User builds should show:
  # release build number or branch.buld\_number non-release builds

  # Dev. branches should have DISPLAY\_BUILD\_NUMBER set
  ifeq (true,$(DISPLAY\_BUILD\_NUMBER))
    BUILD_DISPLAY_ID := $(BUILD\_ID).$(BUILD\_NUMBER\_FROM\_FILE) $(BUILD\_KEYS)
  else
  -  BUILD_DISPLAY_ID := $(BUILD\_ID).$(BUILD\_NUMBER)
  +  BUILD_DISPLAY_ID := $(BUILD\_ID)-$(shell date +"%Y%m%d")-hangzhiyun
  endif
else
  # Non-user builds should show detailed build information
  BUILD_DISPLAY_ID := $(build\_desc)
endif

```

然后编译验证发现build.info的值变了





