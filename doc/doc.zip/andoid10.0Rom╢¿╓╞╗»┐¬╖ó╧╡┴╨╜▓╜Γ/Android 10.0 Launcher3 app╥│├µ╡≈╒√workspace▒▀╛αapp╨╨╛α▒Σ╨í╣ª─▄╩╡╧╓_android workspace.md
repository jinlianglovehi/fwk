



## 1.前言


在10.0的系统rom定制化开发中，在launcher3的一些开发定制功能中，在对于大分辨率比如1600\*2560的设备进行开发的时候， 会在竖屏的时候，在默认7\*4的布局的时候，显得行距有点宽，这样就需要调整整个CellLayout的上下左右边距，然后就 会显得行距会小一点，接下来具体分析相关功能来实现需求


![](https://img-blog.csdnimg.cn/direct/f85b9daf8a1b41bbbc4d21d5420d54c7.png)


## 2. Launcher3 app页面调整workspace边距app行距变小功能实现的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\DeviceProfile.java
```

## 3. Launcher3 app页面调整workspace边距app行距变小功能实现的核心功能分析和实现


Launcher3是用工作区的形式来显示系统安装的应用程序的快捷图标，每一个workspace工作区都是来描述一个抽象桌面的， 它由n个屏幕组成，每个屏幕又分n个单元格，每个单元格用来显示一个应用程序的快捷图标。 1, 界面的布局, 从上往下分别为:DeleteDropTarget(应用卸载区域,它是一个DropTarget) Workspace(页面容器,一个页面是一个CellLayout) PageIndicator(指示器,指示workspace当前位于第几个页面) Hotseat(底部图标区域) 桌面核心类 1、Workspace：主屏幕对应的布局，是直接添加到Launcher.xml中的布局对象 2、CellLayout：主屏幕中的每一页，其父布局就是Workspace，左右滑动屏幕，就是每一个CellLayout的变化过程，这个类中有很多处理拖拽相关方法。 3、ShortcutAndWidgetContainer：装载图标的容器（布局），其父布局是CellLayout。 4、BubbleTextView：launcher中的图标对象（单击、长按图标的实际载体）


## 3.1 DeviceProfile.java相关桌面布局参数分析


在实现Launcher3 app页面调整workspace边距app行距变小功能实现，通过上述的分析得知， DeviceProfile.java:图标大小、各个图标间距,布局等计算实体类,可配置各个参数 的全局变量 所以接下来具体分析下DeviceProfile.java中的相关参数



```
// Workspace
    public final int desiredWorkspaceLeftRightMarginPx;
    public final int cellLayoutPaddingLeftRightPx;
    public final int cellLayoutBottomPaddingPx;
    public final int edgeMarginPx;
    public float workspaceSpringLoadShrinkFactor;
    public final int workspaceSpringLoadedBottomSpace;

    // Workspace page indicator
    public final int workspacePageIndicatorHeight;
    private final int mWorkspacePageIndicatorOverlapWorkspace;

    // Workspace icons
    public int iconSizePx;
    public int iconTextSizePx;
    public int iconDrawablePaddingPx;
    public int iconDrawablePaddingOriginalPx;

    public int cellWidthPx;
    public int cellHeightPx;
    public int workspaceCellPaddingXPx;

   DeviceProfile(Context context, InvariantDeviceProfile inv, DefaultDisplay.Info info,
            Point minSize, Point maxSize, int width, int height, boolean isLandscape,
            boolean isMultiWindowMode, boolean transposeLayoutWithOrientation,
            Point windowPosition) {

        this.inv = inv;
        this.isLandscape = isLandscape;
        this.isMultiWindowMode = isMultiWindowMode;
        windowX = windowPosition.x;
        windowY = windowPosition.y;

        // Determine sizes.
        widthPx = width;
        heightPx = height;
        if (isLandscape) {
            availableWidthPx = maxSize.x;
            availableHeightPx = minSize.y;
        } else {
            availableWidthPx = minSize.x;
            availableHeightPx = maxSize.y;
        }

        mInfo = info;

        // Constants from resources
        float swDPs = Utilities.dpiFromPx(
                Math.min(info.smallestSize.x, info.smallestSize.y), info.metrics);
        isTablet = swDPs >= TABLET_MIN_DPS;
        isLargeTablet = swDPs >= LARGE_TABLET_MIN_DPS;
        isPhone = !isTablet && !isLargeTablet;
        aspectRatio = ((float) Math.max(widthPx, heightPx)) / Math.min(widthPx, heightPx);
        boolean isTallDevice = Float.compare(aspectRatio, TALL_DEVICE_ASPECT_RATIO_THRESHOLD) >= 0;

        // Some more constants
        this.transposeLayoutWithOrientation = transposeLayoutWithOrientation;

        context = getContext(context, info, isVerticalBarLayout()
                ? Configuration.ORIENTATION_LANDSCAPE
                : Configuration.ORIENTATION_PORTRAIT);
        final Resources res = context.getResources();

        edgeMarginPx = res.getDimensionPixelSize(R.dimen.dynamic_grid_edge_margin);
        desiredWorkspaceLeftRightMarginPx = isVerticalBarLayout() ? 0 : edgeMarginPx;

        int cellLayoutPaddingLeftRightMultiplier = !isVerticalBarLayout() && isTablet
                ? PORTRAIT_TABLET_LEFT_RIGHT_PADDING_MULTIPLIER : 1;
        int cellLayoutPadding = res.getDimensionPixelSize(R.dimen.dynamic_grid_cell_layout_padding);
        if (isLandscape) {
            cellLayoutPaddingLeftRightPx = 0;
            cellLayoutBottomPaddingPx = cellLayoutPadding;
        } else {
            cellLayoutPaddingLeftRightPx = cellLayoutPaddingLeftRightMultiplier * cellLayoutPadding;
            cellLayoutBottomPaddingPx = 0;
        }

        workspacePageIndicatorHeight = res.getDimensionPixelSize(
                R.dimen.workspace_page_indicator_height);
        mWorkspacePageIndicatorOverlapWorkspace =
                res.getDimensionPixelSize(R.dimen.workspace_page_indicator_overlap_workspace);

        iconDrawablePaddingOriginalPx =
                res.getDimensionPixelSize(R.dimen.dynamic_grid_icon_drawable_padding);
        dropTargetBarSizePx = res.getDimensionPixelSize(R.dimen.dynamic_grid_drop_target_size);
        workspaceSpringLoadedBottomSpace =
                res.getDimensionPixelSize(R.dimen.dynamic_grid_min_spring_loaded_space);

        workspaceCellPaddingXPx = res.getDimensionPixelSize(R.dimen.dynamic_grid_cell_padding_x);

        hotseatBarTopPaddingPx =
                res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_top_padding);
        hotseatBarBottomPaddingPx = (isTallDevice ? 0
                : res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_bottom_non_tall_padding))
                + res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_bottom_padding);
        hotseatBarSidePaddingEndPx =
                res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_side_padding);
        // Add a bit of space between nav bar and hotseat in vertical bar layout.
        hotseatBarSidePaddingStartPx = isVerticalBarLayout() ? workspacePageIndicatorHeight : 0;
        hotseatBarSizePx = ResourceUtils.pxFromDp(inv.iconSize, mInfo.metrics)
                + (isVerticalBarLayout()
                ? (hotseatBarSidePaddingStartPx + hotseatBarSidePaddingEndPx)
                : (res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_extra_vertical_size)
                        + hotseatBarTopPaddingPx + hotseatBarBottomPaddingPx));

        // Calculate all of the remaining variables.
        updateAvailableDimensions(res);

        updateWorkspacePadding();

        // This is done last, after iconSizePx is calculated above.
        mDotRendererWorkSpace = new DotRenderer(iconSizePx, IconShape.getShapePath(),
                IconShape.DEFAULT_PATH_SIZE);
        mDotRendererAllApps = iconSizePx == allAppsIconSizePx ? mDotRendererWorkSpace :
                new DotRenderer(allAppsIconSizePx, IconShape.getShapePath(),
                        IconShape.DEFAULT_PATH_SIZE);
    }


  
```

在实现Launcher3 app页面调整workspace边距app行距变小功能实现，通过上述的分析得知，  
 在上述的DeviceProfile.java的构造方法中，主要是就是hotseat folder celllayout等相关参数的  
 宽高，边距 图标的宽高等等，而关于整个workspace的布局celllayout的相关参数就是  
 cellLayoutPaddingLeftRightPx cellLayoutBottomPaddingPx和cellwidth 等等参数，接下来  
 具体看下相关的计算方法



```
 private Point getCellSize(int numColumns, int numRows) {
        Point result = new Point();
        // Since we are only concerned with the overall padding, layout direction does
        // not matter.
        Point padding = getTotalWorkspacePadding();
        result.x = calculateCellWidth(availableWidthPx - padding.x
                - cellLayoutPaddingLeftRightPx * 2, numColumns);
        result.y = calculateCellHeight(availableHeightPx - padding.y
                - cellLayoutBottomPaddingPx, numRows);
        return result;
    }

    public Point getTotalWorkspacePadding() {
        updateWorkspacePadding();
        return new Point(workspacePadding.left + workspacePadding.right,
                workspacePadding.top + workspacePadding.bottom);
    }

```

在实现Launcher3 app页面调整workspace边距app行距变小功能实现，通过上述的分析得知， 在上述的DeviceProfile.java的相关源码中，在getCellSize(int numColumns, int numRows) 中 具体计算每一个app hotseat等所占的宽高，在这里面通过 Point padding = getTotalWorkspacePadding(); result.x = calculateCellWidth(availableWidthPx - padding.x - cellLayoutPaddingLeftRightPx \* 2, numColumns); result.y = calculateCellHeight(availableHeightPx - padding.y - cellLayoutBottomPaddingPx, numRows); 来计算宽高，availableWidthPx，availableHeightPx就是屏幕的宽高，cellLayoutPaddingLeftRightPx 和cellLayoutBottomPaddingPx就是左右边距和底部边距，而padding就是指workspace的 整个页面布局的边距，所以可以从updateWorkspacePadding()从进行调整边距， 这样整个celllayout布局就会变小了



```
    private void updateWorkspacePadding() {
        Rect padding = workspacePadding;
        if (isVerticalBarLayout()) {
            padding.top = 0;
            padding.bottom = edgeMarginPx;
            if (isSeascape()) {
                padding.left = hotseatBarSizePx;
                padding.right = hotseatBarSidePaddingStartPx;
            } else {
                padding.left = hotseatBarSidePaddingStartPx;
                padding.right = hotseatBarSizePx;
            }
        } else {
            int paddingBottom = hotseatBarSizePx + workspacePageIndicatorHeight
                    - mWorkspacePageIndicatorOverlapWorkspace;
            if (isTablet) {
                // Pad the left and right of the workspace to ensure consistent spacing
                // between all icons
                // The amount of screen space available for left/right padding.
                int availablePaddingX = Math.max(0, widthPx - ((inv.numColumns * cellWidthPx) +
                        ((inv.numColumns - 1) * cellWidthPx)));
                availablePaddingX = (int) Math.min(availablePaddingX,
                        widthPx * MAX_HORIZONTAL_PADDING_PERCENT);
                int availablePaddingY = Math.max(0, heightPx - edgeMarginPx - paddingBottom
                        - (2 * inv.numRows * cellHeightPx) - hotseatBarTopPaddingPx
                        - hotseatBarBottomPaddingPx);

// modify code start
                padding.set(200/*availablePaddingX / 2*/, 150/*edgeMarginPx + availablePaddingY / 2*/,
                        200/*availablePaddingX / 2*/, 150/*paddingBottom + availablePaddingY / 2*/);
// modify code end
            } else {
// modify code start
                padding.set(200/*desiredWorkspaceLeftRightMarginPx*/,
                        150/*edgeMarginPx*/,
                        200/*desiredWorkspaceLeftRightMarginPx*/,
                        150/*paddingBottom*/);
// modify code end
            }
        }
    }
```

在实现Launcher3 app页面调整workspace边距app行距变小功能实现，通过上述的分析得知， 在上述的DeviceProfile.java的相关源码中，通过分析主要是在updateWorkspacePadding() 中 调整padding的边距值，所以通过上述的修改基本达到要求



