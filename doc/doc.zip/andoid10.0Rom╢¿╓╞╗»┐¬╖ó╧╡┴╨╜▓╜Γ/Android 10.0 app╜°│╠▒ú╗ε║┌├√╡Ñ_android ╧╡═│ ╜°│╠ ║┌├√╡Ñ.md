



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.app杀进程黑名单的核心功能代码](#2.app%E6%9D%80%E8%BF%9B%E7%A8%8B%E9%BB%91%E5%90%8D%E5%8D%95%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81)


[3.app进程保活黑名单的核心功能代码和功能实现](#3.app%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E9%BB%91%E5%90%8D%E5%8D%95%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81%E5%92%8C%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 IActivityManager.aidl增加杀进程黑名单](#3.1%20IActivityManager.aidl%E5%A2%9E%E5%8A%A0%E6%9D%80%E8%BF%9B%E7%A8%8B%E9%BB%91%E5%90%8D%E5%8D%95)


[3.2 ActivityManager.java增加杀进程的方法](#3.2%20ActivityManager.java%E5%A2%9E%E5%8A%A0%E6%9D%80%E8%BF%9B%E7%A8%8B%E7%9A%84%E6%96%B9%E6%B3%95)


[3.3 ActivityManagerService.java实现杀进程黑名单的方法](#3.3%20ActivityManagerService.java%E5%AE%9E%E7%8E%B0%E6%9D%80%E8%BF%9B%E7%A8%8B%E9%BB%91%E5%90%8D%E5%8D%95%E7%9A%84%E6%96%B9%E6%B3%95)




---



## 1.概述


在10.0的产品开发中，对于低内存的go产品而言，对于内存不足时，杀进程是必然的，这就需要设置杀黑名单来当内存不足时，首先杀掉这些app进程，而杀进程的相关的核心方法在AMS中所有要从这里来实现功能


## 2.app杀进程黑名单的核心功能代码



```
核心代码:
  frameworks/base/core/java/android/app/IActivityManager.aidl
  frameworks/base/core/java/android/app/ActivityManager.java
  frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
```

## 3.app进程保活黑名单的核心功能代码和功能实现


#### 3.1 IActivityManager.aidl增加杀进程黑名单



```
 frameworks/base/core/java/android/app/IActivityManager.aidl
  List<String> getBlackAppList();
  void setBlackAppList(in List<String> blackAppList);

```

#### 3.2 ActivityManager.java增加杀进程的方法



```
public class ActivityManager {
private static String TAG = "ActivityManager";

@UnsupportedAppUsage
private final Context mContext;

private static volatile boolean sSystemReady = false;


private static final int FIRST_START_FATAL_ERROR_CODE = -100;
private static final int LAST_START_FATAL_ERROR_CODE = -1;
private static final int FIRST_START_SUCCESS_CODE = 0;
private static final int LAST_START_SUCCESS_CODE = 99;
private static final int FIRST_START_NON_FATAL_ERROR_CODE = 100;
private static final int LAST_START_NON_FATAL_ERROR_CODE = 199;

/**
* Disable hidden API checks for the newly started instrumentation.
* @hide
*/
public static final int INSTR_FLAG_DISABLE_HIDDEN_API_CHECKS = 1 << 0;
/**
* Mount full external storage for the newly started instrumentation.
* @hide
*/
public static final int INSTR_FLAG_MOUNT_EXTERNAL_STORAGE_FULL = 1 << 1;

static final class UidObserver extends IUidObserver.Stub {
final OnUidImportanceListener mListener;
final Context mContext;

UidObserver(OnUidImportanceListener listener, Context clientContext) {
mListener = listener;
mContext = clientContext;
}

@Override
public void onUidStateChanged(int uid, int procState, long procStateSeq) {
mListener.onUidImportance(uid, RunningAppProcessInfo.procStateToImportanceForClient(
procState, mContext));
}

@Override
public void onUidGone(int uid, boolean disabled) {
mListener.onUidImportance(uid, RunningAppProcessInfo.IMPORTANCE_GONE);
}

@Override
public void onUidActive(int uid) {
}

@Override
public void onUidIdle(int uid, boolean disabled) {
}

@Override public void onUidCachedChanged(int uid, boolean cached) {
}
}



```

#### 增加方法: public List<String> getBlackAppList() {         try {             return getService().getBlackAppList();         } catch (RemoteException e) {             throw e.rethrowFromSystemServer();         }     }     public void setBlackAppList(List<String> blackAppList) {         try {             getService().setBlackAppList(blackAppList);         } catch (RemoteException e) {             throw e.rethrowFromSystemServer();         }     }


#### 3.3 ActivityManagerService.java实现杀进程黑名单的方法



```
public class ActivityManagerService extends IActivityManager.Stub
implements Watchdog.Monitor, BatteryStatsImpl.BatteryCallback {

/**
* Priority we boost main thread and RT of top app to.
*/
public static final int TOP_APP_PRIORITY_BOOST = -10;

private static final String SYSTEM_PROPERTY_DEVICE_PROVISIONED =
"persist.sys.device_provisioned";

static final String TAG = TAG_WITH_CLASS_NAME ? "ActivityManagerService" : TAG_AM;
static final String TAG_BACKUP = TAG + POSTFIX_BACKUP;
private static final String TAG_BROADCAST = TAG + POSTFIX_BROADCAST;
private static final String TAG_CLEANUP = TAG + POSTFIX_CLEANUP;
private static final String TAG_CONFIGURATION = TAG + POSTFIX_CONFIGURATION;
private static final String TAG_LOCKTASK = TAG + POSTFIX_LOCKTASK;
static final String TAG_LRU = TAG + POSTFIX_LRU;
private static final String TAG_MU = TAG + POSTFIX_MU;
private static final String TAG_NETWORK = TAG + POSTFIX_NETWORK;
static final String TAG_OOM_ADJ = TAG + POSTFIX_OOM_ADJ;
private static final String TAG_POWER = TAG + POSTFIX_POWER;
static final String TAG_PROCESS_OBSERVERS = TAG + POSTFIX_PROCESS_OBSERVERS;
static final String TAG_PROCESSES = TAG + POSTFIX_PROCESSES;
private static final String TAG_PROVIDER = TAG + POSTFIX_PROVIDER;
static final String TAG_PSS = TAG + POSTFIX_PSS;
private static final String TAG_SERVICE = TAG + POSTFIX_SERVICE;
private static final String TAG_SWITCH = TAG + POSTFIX_SWITCH;
static final String TAG_UID_OBSERVERS = TAG + POSTFIX_UID_OBSERVERS;

// Mock "pretend we're idle now" broadcast action to the job scheduler; declared
// here so that while the job scheduler can depend on AMS, the other way around
// need not be the case.
public static final String ACTION_TRIGGER_IDLE = "com.android.server.ACTION_TRIGGER_IDLE";

/** Control over CPU and battery monitoring */
// write battery stats every 30 minutes.
static final long BATTERY_STATS_TIME = 30 * 60 * 1000;
static final boolean MONITOR_CPU_USAGE = true;
// don't sample cpu less than every 5 seconds.
static final long MONITOR_CPU_MIN_TIME = 5 * 1000;
// wait possibly forever for next cpu sample.
static final long MONITOR_CPU_MAX_TIME = 0x0fffffff;
static final boolean MONITOR_THREAD_CPU_USAGE = false;

// The flags that are set for all calls we make to the package manager.
public static final int STOCK_PM_FLAGS = PackageManager.GET_SHARED_LIBRARY_FILES;

static final String SYSTEM_DEBUGGABLE = "ro.debuggable";

public static final String ANR_TRACE_DIR = "/data/anr";

// Maximum number of receivers an app can register.
private static final int MAX_RECEIVERS_ALLOWED_PER_APP = 1000;

// How long we wait for a launched process to attach to the activity manager
// before we decide it's never going to come up for real.
static final int PROC_START_TIMEOUT = 10*1000;
// How long we wait for an attached process to publish its content providers
// before we decide it must be hung.
static final int CONTENT_PROVIDER_PUBLISH_TIMEOUT = 10*1000;

// How long we wait to kill an application zygote, after the last process using
// it has gone away.
static final int KILL_APP_ZYGOTE_DELAY_MS = 5 * 1000;
/**
* How long we wait for an provider to be published. Should be longer than
* {@link #CONTENT_PROVIDER_PUBLISH_TIMEOUT}.
*/
static final int CONTENT_PROVIDER_WAIT_TIMEOUT = 20 * 1000;

// How long we wait for a launched process to attach to the activity manager
// before we decide it's never going to come up for real, when the process was
// started with a wrapper for instrumentation (such as Valgrind) because it
// could take much longer than usual.
static final int PROC_START_TIMEOUT_WITH_WRAPPER = 1200*1000;

// How long we allow a receiver to run before giving up on it.
static final int BROADCAST_FG_TIMEOUT = 10*1000;
static final int BROADCAST_BG_TIMEOUT = 60*1000;

public static final int MY_PID = myPid();

static final String[] EMPTY_STRING_ARRAY = new String[0];

// How many bytes to write into the dropbox log before truncating
static final int DROPBOX_MAX_SIZE = 192 * 1024;
// Assumes logcat entries average around 100 bytes; that's not perfect stack traces count
// as one line, but close enough for now.
static final int RESERVED_BYTES_PER_LOGCAT_LINE = 100;

/** If a UID observer takes more than this long, send a WTF. */
private static final int SLOW_UID_OBSERVER_THRESHOLD_MS = 20;

// Necessary ApplicationInfo flags to mark an app as persistent
static final int PERSISTENT_MASK =
ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_PERSISTENT;

// Intent sent when remote bugreport collection has been completed
private static final String INTENT_REMOTE_BUGREPORT_FINISHED =
"com.android.internal.intent.action.REMOTE_BUGREPORT_FINISHED";

// If set, we will push process association information in to procstats.
static final boolean TRACK_PROCSTATS_ASSOCIATIONS = true;

....省略代码 
增加方法
private List<String> mBlackAppList = new ArrayList<String>();

    @Override
    public List<String> getBlackAppList() {
        return mBlackAppList;
    }
    @Override
    public void setBlackAppList(List<String> blackAppList) {
        this.mBlackAppList = blackAppList;
    }

void serviceDoneExecutingLocked(ServiceRecord r, int type, int startId, int res) {
        boolean inDestroying = mDestroyingServices.contains(r);
        if (r != null) {
            if (type == ActivityThread.SERVICE_DONE_EXECUTING_START) {
                // This is a call from a service start...  take care of
                // book-keeping.
                r.callStart = true;
                switch (res) {
                    case Service.START_STICKY_COMPATIBILITY:
                    case Service.START_STICKY: {
                        // We are done with the associated start arguments.
                        r.findDeliveredStart(startId, false, true);
                        // Don't stop if killed.
                        r.stopIfKilled = false;
                        break;
                    }
                    case Service.START_NOT_STICKY: {
                        // We are done with the associated start arguments.
                        r.findDeliveredStart(startId, false, true);
                        if (r.getLastStartId() == startId) {
                            // There is no more work, and this service
                            // doesn't want to hang around if killed.
                            r.stopIfKilled = true;
                        }
                        break;
                    }
                    case Service.START_REDELIVER_INTENT: {
                        // We'll keep this item until they explicitly
                        // call stop for it, but keep track of the fact
                        // that it was delivered.
                        ServiceRecord.StartItem si = r.findDeliveredStart(startId, false, false);
                        if (si != null) {
                            si.deliveryCount = 0;
                            si.doneExecutingCount++;
                            // Don't stop if killed.
                            r.stopIfKilled = true;
                        }
                        break;
                    }
                    case Service.START_TASK_REMOVED_COMPLETE: {
                        // Special processing for onTaskRemoved().  Don't
                        // impact normal onStartCommand() processing.
                        r.findDeliveredStart(startId, true, true);
                        break;
                    }
                    default:
                        throw new IllegalArgumentException(
                                "Unknown service start result: " + res);
                }
                if (res == Service.START_STICKY_COMPATIBILITY) {
                    r.callStart = false;
                }
            } else if (type == ActivityThread.SERVICE_DONE_EXECUTING_STOP) {
                // This is the final call from destroying the service...  we should
                // actually be getting rid of the service at this point.  Do some
                // validation of its state, and ensure it will be fully removed.
                if (!inDestroying) {
                    // Not sure what else to do with this...  if it is not actually in the
                    // destroying list, we don't need to make sure to remove it from it.
                    // If the app is null, then it was probably removed because the process died,
                    // otherwise wtf
                    if (r.app != null) {
                        Slog.w(TAG, "Service done with onDestroy, but not inDestroying: "
                                + r + ", app=" + r.app);
                    }
                } else if (r.executeNesting != 1) {
                    Slog.w(TAG, "Service done with onDestroy, but executeNesting="
                            + r.executeNesting + ": " + r);
                    // Fake it to keep from ANR due to orphaned entry.
                    r.executeNesting = 1;
                }
            }
            final long origId = Binder.clearCallingIdentity();
            serviceDoneExecutingLocked(r, inDestroying, inDestroying);
            Binder.restoreCallingIdentity(origId);
        } else {
            Slog.w(TAG, "Done executing unknown service from pid "
                    + Binder.getCallingPid());
        }
    }


void serviceDoneExecutingLocked(ServiceRecord r, int type, int startId, int res) {
        boolean inDestroying = mDestroyingServices.contains(r);
        if (r != null) {
            if (type == ActivityThread.SERVICE_DONE_EXECUTING_START) {
                Log.e(TAG, "service " + r.name.toString() + " started");

                //add code start
                if(shouldKillService(r)){
                    Log.e(TAG, "service " + r.name.toString() + " should be stopped");
                    res = Service.START_NOT_STICKY;
                }
                //add code end

                // This is a call from a service start...  take care of
                // book-keeping.
                r.callStart = true;
                //上面限制后，进行判断
                switch (res) {
                    case Service.START_STICKY_COMPATIBILITY:
                    case Service.START_STICKY: {
                        // We are done with the associated start arguments.
                        r.findDeliveredStart(startId, true);
                        // Don't stop if killed.
                        r.stopIfKilled = false;
                        break;
                    }
                    case Service.START_NOT_STICKY: {
                        // We are done with the associated start arguments.
                        r.findDeliveredStart(startId, true);
                        if (r.getLastStartId() == startId) {
                            // There is no more work, and this service
                            // doesn't want to hang around if killed.
                            r.stopIfKilled = true;
                        }
                        break;
                    }
                    case Service.START_REDELIVER_INTENT: {
                        
                    }
                    case Service.START_TASK_REMOVED_COMPLETE: {
                      
                    }
                    default:
                }
                if (res == Service.START_STICKY_COMPATIBILITY) {
                    r.callStart = false;
                }
            } else if (type == ActivityThread.SERVICE_DONE_EXECUTING_STOP) {
               
            }
            final long origId = Binder.clearCallingIdentity();
            serviceDoneExecutingLocked(r, inDestroying, inDestroying);
            Binder.restoreCallingIdentity(origId);
        } else {
            Slog.w(TAG, "Done executing unknown service from pid "
                    + Binder.getCallingPid());
        }
    }
  
```

  
 serviceDoneExecutingLocked()负责来kill到进程


所以杀进程黑名单具体修改为:  
 //add code start  
  private boolean shouldKillService(ServiceRecord r){  
      boolean rst = false;  
      List<String> blackApps = mAm.getBlackAppList();  
      Log.i(TAG, "check whether service should stop " + r);  
      Log.i(TAG, "black list contains " + blackApps);  
      if(null != blackApps  
              && blackApps.size() > 0  
              && null != r  
              && null != r.app  
              && r.app.uid >= 10000  
              && null != r.appInfo  
              && !TextUtils.isEmpty(r.appInfo.packageName)){  
          for(String pkgName : blackApps){  
              if(!TextUtils.isEmpty(pkgName)  
                      && pkgName.equals(r.appInfo.packageName)){  
                  rst = true;  
                  break;  
              }  
          }  
      }  
      String tmp = rst?"is":"is not";  
      return rst;  
  }  
  //add code end



