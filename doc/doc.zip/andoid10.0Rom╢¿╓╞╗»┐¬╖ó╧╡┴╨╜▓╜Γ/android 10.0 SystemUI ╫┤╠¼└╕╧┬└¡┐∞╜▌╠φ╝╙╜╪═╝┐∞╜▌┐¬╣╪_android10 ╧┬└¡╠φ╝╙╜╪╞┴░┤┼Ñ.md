






### 1.概述


在10.0的系统产品开发中，在SystemUI下拉状态栏中 添加快捷开关，也是常有的开发功能，  
 下面就以添加 截图功能为例 进行讲解


![在这里插入图片描述](https://img-blog.csdnimg.cn/4942e7e787694223bdffed3cd778b445.png#pic_center)


### 2.SystemUI 状态栏下拉快捷添加截图快捷开关的核心类



```
frameworks/base/packages/SystemUI/res/values/config.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java

```

### 3.SystemUI 状态栏下拉快捷添加截图快捷开关的核心功能分析和实现


在SystemUI关于下拉快捷的源码中得知需要在config.xml中添加字符来代表截图


### 3.1.在quick\_settings\_tiles\_default 和 quick\_settings\_tiles\_stock 中添加 screenshot 截图


修改如下:



```
diff --git a/frameworks/base/packages/SystemUI/res/values/config.xml b/frameworks/base/packages/SystemUI/res/values/config.xml
index 2ddc56ada3..ff13d52f67 100755
--- a/frameworks/base/packages/SystemUI/res/values/config.xml
+++ b/frameworks/base/packages/SystemUI/res/values/config.xml
@@ -111,7 +111,7 @@
 
     <!-- The default tiles to display in QuickSettings -->
     <string name="quick\_settings\_tiles\_default" translatable="false">
-        volte1,volte2,wifi,bt,dnd,vowifi,lte1,lte2,onehand,flashlight,rotation,battery,cell,cast
+        volte1,volte2,wifi,bt,dnd,vowifi,lte1,lte2,onehand,flashlight,screenshot,rotation,battery,cell,cast
     </string>
 
     <!-- The minimum number of tiles to display in QuickSettings -->
@@ -119,7 +119,7 @@
 
     <!-- Tiles native to System UI. Order should match "quick\_settings\_tiles\_default" -->
     <string name="quick\_settings\_tiles\_stock" translatable="false">
-        volte1,volte2,wifi,cell,battery,dnd,vowifi,lte1,lte2,flashlight,rotation,bt,airplane,location,hotspot,inversion,saver,dark,work,cast,night,onehand,longscreenshot
+        volte1,volte2,wifi,cell,battery,dnd,vowifi,lte1,lte2,flashlight,screenshot,rotation,bt,airplane,location,hotspot,inversion,saver,dark,work,cast,night,onehand,longscreenshot
     </string>

```

在quick\_settings\_tiles\_default添加screenshot代表是截图开关功能键


### 3.2添加自定义 Tile ScreenShotTile.java



```
package com.android.systemui.qs.tiles;

import android.app.ActivityManager;
import android.content.Intent;
import android.service.quicksettings.Tile;
import android.widget.Switch;

import com.android.systemui.R;
import com.android.systemui.plugins.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSHost;
import com.android.systemui.qs.tileimpl.QSTileImpl;
import com.android.internal.util.ScreenshotHelper;
import android.os.RemoteException;
import android.os.Handler;
import android.util.Log;
import android.os.Message;
import javax.inject.Inject;

/** Quick settings tile: Control flashlight **/
public class ScreenShotTile extends QSTileImpl<BooleanState>{

    private final Icon mIcon = ResourceIcon.get(com.android.internal.R.drawable.ic_screenshot);
    private Handler mHandler;

    //这个Inject还是必须要有的，不然会导致编译不过，一开始就入坑了
    @Inject
    public ScreenShotTile(QSHost host) {
        super(host);
        mHandler = new Handler();
		
    }

    @Override
    public BooleanState newTileState() {
        return new BooleanState();
    }

// 添加点击事件
    @Override
    protected void handleClick() {
        mHost.collapsePanels();

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.e(TAG, "gww ScreenshotAction onPress will takeScreenshot");
                //我这里是参考的原生的，长按power键出现的截图的方法。
                   execShell("screencap -p /sdcard/01.png");
                }
            }, 500);
    }

    @Override
    protected void handleUpdateState(BooleanState state, Object arg) {
        state.icon = mIcon;
        state.label = "screen shot";
        state.contentDescription = "screen shot";
    }

    @Override
    public int getMetricsCategory() {
        return 0;
    }

    @Override
    public Intent getLongClickIntent() {
        return null;
    }

    @Override
    protected void handleSetListening(boolean listening) {

    }

    @Override
    public CharSequence getTileLabel() {
    //quick_settings_screenshot_label 这种字符串String.xml中添加就可以了
        return "screen shot";
    }
    public int execShell(String cmd) {
        int result = -1;
        Process pro = null;
        try {
            pro = Runtime.getRuntime().exec(cmd);
            pro.waitFor();
            result = pro.exitValue();
            Log.e(TAG, "result:" + result);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(pro!=null)pro.destroy();
            return result;
        }
    }
}

```

在自定义的截图功能开关键中，增加handleUpdateState和handleClick()来实现截图功能的  
 下拉快捷功能键


### 3. 3添加 ScreenShotTile到QSFactoryImpl中


如下:



```
diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
index ffca7b01d1..140f6405ca 100755
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
@@ -52,6 +52,7 @@ import com.android.systemui.qs.tiles.VolteTile;
 import com.android.systemui.qs.tiles.VoWifiTile;
 import com.android.systemui.qs.tiles.WifiTile;
 import com.android.systemui.qs.tiles.WorkModeTile;
+import com.android.systemui.qs.tiles.ScreenShotTile;
 import com.android.systemui.util.leak.GarbageMonitor;
 import com.sprd.systemui.qs.tiles.LongScreenshotTile;
 import com.sprd.systemui.qs.tiles.OneHandTile;
@@ -90,7 +91,7 @@ public class QSFactoryImpl implements QSFactory {
     private final Provider<NfcTile> mNfcTileProvider;
     private final Provider<GarbageMonitor.MemoryTile> mMemoryTileProvider;
     private final Provider<UiModeNightTile> mUiModeNightTileProvider;
-
+    private final Provider<ScreenShotTile> mScreenShotTileProvider;
     private QSTileHost mHost;
 
     @Inject
@@ -114,6 +115,7 @@ public class QSFactoryImpl implements QSFactory {
             Provider<NightDisplayTile> nightDisplayTileProvider,
             Provider<NfcTile> nfcTileProvider,
             Provider<GarbageMonitor.MemoryTile> memoryTileProvider,
+                       Provider<ScreenShotTile> screenShotTileProvider,
             Provider<UiModeNightTile> uiModeNightTileProvider) {
         mWifiTileProvider = wifiTileProvider;
         mBluetoothTileProvider = bluetoothTileProvider;
@@ -136,6 +138,7 @@ public class QSFactoryImpl implements QSFactory {
         mNfcTileProvider = nfcTileProvider;
         mMemoryTileProvider = memoryTileProvider;
         mUiModeNightTileProvider = uiModeNightTileProvider;
+               mScreenShotTileProvider = screenShotTileProvider;
     }
 
     public void setHost(QSTileHost host) {
@@ -191,6 +194,8 @@ public class QSFactoryImpl implements QSFactory {
                 return mHotspotTileProvider.get();
             case "user":
                 return mUserTileProvider.get();
+            case "screenshot":
+                return mScreenShotTileProvider.get();
             case "battery":
                 /*UNISOC Bug 1074234, 885650, Super power feature @{ */
                 if (SprdPowerManagerUtil.SUPPORT_SUPER_POWER_SAVE) {

```

通过在QSFactoryImpl 增加截图下拉功能键的调用，以便显示在下拉状态栏的下拉快捷功能键的  
 列表中，实现截图功能  
 4.经过编译验证结果





