



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.第三方输入法app设置系统默认输入法的核心类](#2.%E7%AC%AC%E4%B8%89%E6%96%B9%E8%BE%93%E5%85%A5%E6%B3%95app%E8%AE%BE%E7%BD%AE%E7%B3%BB%E7%BB%9F%E9%BB%98%E8%AE%A4%E8%BE%93%E5%85%A5%E6%B3%95%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.第三方输入法app设置系统默认输入法的核心功能分析和实现](#3.%E7%AC%AC%E4%B8%89%E6%96%B9%E8%BE%93%E5%85%A5%E6%B3%95app%E8%AE%BE%E7%BD%AE%E7%B3%BB%E7%BB%9F%E9%BB%98%E8%AE%A4%E8%BE%93%E5%85%A5%E6%B3%95%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0)


[3.1 SettingsProvider 默认输入法添加到系统数据库](#3.1%20SettingsProvider%20%E9%BB%98%E8%AE%A4%E8%BE%93%E5%85%A5%E6%B3%95%E6%B7%BB%E5%8A%A0%E5%88%B0%E7%B3%BB%E7%BB%9F%E6%95%B0%E6%8D%AE%E5%BA%93)


[3.2在defaults.xml中添加默认输入法id](#%C2%A03.2%E5%9C%A8defaults.xml%E4%B8%AD%E6%B7%BB%E5%8A%A0%E9%BB%98%E8%AE%A4%E8%BE%93%E5%85%A5%E6%B3%95id)




---



## 1.概述


在10.0的产品定制化开发中，由于系统默认的谷歌输入法 满足不了需求 要求替换成其他的输入法  
 所以就需要内置输入法app后，要求把默认id替换成新输入法的id


## 2.第三方输入法app设置系统默认输入法的核心类



```
frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
frameworks/base/packages/SettingsProvider/res/values/defaults.xml
```

## 3.第三方输入法app设置系统默认输入法的核心功能分析和实现


所以要求分两步实现  
 1.在系统数据库加载的时候来加载默认的输入法的id 来设置成默认输入法  
 2.在config中修改输入法id号


### 3.1 SettingsProvider 默认输入法添加到系统数据库


在系统默认数据中，会在SettingsProvider中进行数据的默认加载，所以添加默认系统输入法也是在这里添加的



```
     private void loadSettings(SQLiteDatabase db) {
          loadSystemSettings(db);
          loadSecureSettings(db);
          // The global table only exists for the 'owner/system' user
          if (mUserHandle == UserHandle.USER_SYSTEM) {
              loadGlobalSettings(db);
          }
      }
  
      private void loadSystemSettings(SQLiteDatabase db) {
          SQLiteStatement stmt = null;
          try {
              stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                      + " VALUES(?,?);");
  
              loadBooleanSetting(stmt, Settings.System.DIM_SCREEN,
                      R.bool.def_dim_screen);
              loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                      R.integer.def_screen_off_timeout);
  
              // Set default cdma DTMF type
              loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);
  
              // Set default hearing aid
              loadSetting(stmt, Settings.System.HEARING_AID, 0);
  
              // Set default tty mode
              loadSetting(stmt, Settings.System.TTY_MODE, 0);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                      R.integer.def_screen_brightness);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_FOR_VR,
                      com.android.internal.R.integer.config_screenBrightnessForVrSettingDefault);
  
              loadBooleanSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_MODE,
                      R.bool.def_screen_brightness_automatic_mode);
  
              loadBooleanSetting(stmt, Settings.System.ACCELEROMETER_ROTATION,
                      R.bool.def_accelerometer_rotation);
  
              loadDefaultHapticSettings(stmt);
  
              loadBooleanSetting(stmt, Settings.System.NOTIFICATION_LIGHT_PULSE,
                      R.bool.def_notification_pulse);
  
              loadUISoundEffectsSettings(stmt);
  
              loadIntegerSetting(stmt, Settings.System.POINTER_SPEED,
                      R.integer.def_pointer_speed);
  
              /*
               * IMPORTANT: Do not add any more upgrade steps here as the global,
               * secure, and system settings are no longer stored in a database
               * but are kept in memory and persisted to XML.
               *
               * See: SettingsProvider.UpgradeController#onUpgradeLocked
               */
          } finally {
              if (stmt != null) stmt.close();
          }
      }
```

在上述的loadSettings(db)中加载系统的各种初始化参数数据时


所以需要添加默认输入法修改参数


也需要在loadSettings(db);中添加如下:



```
​

diff --git a/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java b/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
index 62996cbdcc..60eacba782 100755
--- a/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
+++ b/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
@@ -2398,7 +2398,8 @@ class DatabaseHelper extends SQLiteOpenHelper {
                     com.android.internal.R.string.config_dreamsDefaultComponent);
             loadStringSetting(stmt, Settings.Secure.SCREENSAVER_DEFAULT_COMPONENT,
                     com.android.internal.R.string.config_dreamsDefaultComponent);
-
+            loadStringSetting(stmt, Settings.Secure.ENABLED_INPUT_METHODS,
+                   R.string.def_enabled_input_methods);
             loadBooleanSetting(stmt, Settings.Secure.ACCESSIBILITY_DISPLAY_MAGNIFICATION_ENABLED,
                     R.bool.def_accessibility_display_magnification_enabled);

​
```

### 通过上面的代码分析发现默认输入法是在default.xml中的def\_enabled\_input\_methods的值保存默认输入法id


###   3.2在defaults.xml中添加默认输入法id


在default.xml相关参数的分析



```
<resources>
     <bool name="def_dim_screen">true</bool>
     <integer name="def_screen_off_timeout">60000</integer>
     <integer name="def_sleep_timeout">-1</integer>
     <bool name="def_airplane_mode_on">false</bool>
     <bool name="def_theater_mode_on">false</bool>
     <!-- Comma-separated list of bluetooth, wifi, and cell. -->
     <string name="def_airplane_mode_radios" translatable="false">cell,bluetooth,wifi,nfc,wimax</string>
     <string name="airplane_mode_toggleable_radios" translatable="false">bluetooth,wifi,nfc</string>
     <string name="def_bluetooth_disabled_profiles" translatable="false">0</string>
     <bool name="def_auto_time">true</bool>
     <bool name="def_auto_time_zone">true</bool>
     <bool name="def_accelerometer_rotation">false</bool>
     <!-- Default screen brightness, from 0 to 255.  102 is 40%. -->
     <integer name="def_screen_brightness">102</integer>
     <bool name="def_screen_brightness_automatic_mode">false</bool>
     <fraction name="def_window_animation_scale">100%</fraction>
     <fraction name="def_window_transition_scale">100%</fraction>
     <bool name="def_haptic_feedback">true</bool>
 
     <bool name="def_bluetooth_on">true</bool>
     <bool name="def_wifi_display_on">false</bool>
     <bool name="def_install_non_market_apps">false</bool>
     <bool name="def_package_verifier_enable">true</bool>
     <!-- 0 == off, 3 == on -->
     <integer name="def_location_mode">3</integer>
     <bool name="assisted_gps_enabled">true</bool>
     <bool name="def_netstats_enabled">true</bool>
     <bool name="def_usb_mass_storage_enabled">true</bool>
     <bool name="def_wifi_on">false</bool>

 
```

在default.xml中发现原生没有def\_enabled\_input\_methods这个参数，所以要添加这个参数来设置


系统默认输入法id参数


具体修改如下:



```

diff --git a/frameworks/base/packages/SettingsProvider/res/values/defaults.xml b/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
index 98c2e66159..4d7f9bde83 100755
--- a/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
+++ b/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
@@ -79,7 +79,7 @@
     <string name="def_trusted_sound" translatable="false">/product/media/audio/ui/Trusted.ogg</string>
     <string name="def_wireless_charging_started_sound" translatable="false">/product/media/audio/ui/WirelessChargingStarted.ogg</string>
     <string name="def_charging_started_sound" translatable="false">/product/media/audio/ui/ChargingStarted.ogg</string>
-
+    <string name="def_enabled_input_methods" translatable="false">com.xinshuru.inputmethod/.FTInputService</string>
     <!-- sound trigger detection service default values -->
     <integer name="def_max_sound_trigger_detection_service_ops_per_day" translatable="false">1000</integer>
```



