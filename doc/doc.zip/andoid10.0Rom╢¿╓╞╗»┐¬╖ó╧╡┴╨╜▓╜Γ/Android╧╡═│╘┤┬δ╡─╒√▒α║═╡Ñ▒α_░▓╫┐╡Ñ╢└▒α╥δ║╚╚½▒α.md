






1.编译系统概述


了解以下一些概念，会对Android编译系统有大概的了解。  
 Makefile  
 Android平台的编译系统，其实就是用Makefile写出来的一个独立项目。它定义了编译的规则，实现了“自动化编译”，不仅把分散在数百个Git库中的代码整合起来、统一编译， 而且还把产物分门别类地输出到一个目录，打包成手机ROM，还可以生成应用开发时所使用的SDK、NDK等。  
 因此，采用Makefile编写的编译系统，也可以称为Makefile编译系统。  
 Android.mk  
 Makefile编译系统的一部分，定义了一个模块的必要参数，使模块随着平台编译。通俗来讲就是告诉编译系统，以什么样的规则编译你的源代码，并生成对应的目标文件。


Ninja  
 Ninja是一个致力于速度的小型编译系统，如果把其他的编译系统看作高级语言，那么Ninja 目标就是汇编。


Soong  
 Soong是谷歌用来替代此前的Makefile编译系统的替代品，负责解析Android.bp文件，并将之转换为Ninja文件


Blueprint  
 Blueprint用来解析Android.bp文件翻译成Ninja语法文件。


kati  
 kati是谷歌专门为了Android而开发的一个小项目，基于Golang和C++。 目的是把Android中的Makefile，转换成Ninja文件。


Android.bp  
 Android.bp，是用来替换Android.mk的配置文件。


Android.mk、Ninja、Soong、Blueprint、kati、Android.bp的概念之间的联系为：  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20191130161246815.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)  
 Blueprint负责解析Android.bp文件内容，Blueprint类似一个处理相关语法的库文件，Soong则是定义具体如何处理相应的语法以及命令实现。通俗来讲就是Soong借助于Blueprint定义的Android.bp语法，完成Android.bp的解析，最终转换成Ninja文件。  
 Makefile文件会通过kati转换为Ninja文件。  
 随着Android工程越来越大，采用Makefile的编译系统花费的时间也越来越长，因此谷歌在Android 7.0开始引入了Ninja来编译系统，相对于Makefile来说Ninja在大的项目管理中速度和并行方面有突出的优势。  
 Makefile默认文件名为Makefile或makefile，也常用.make或.mk作为文件后缀。 Ninja的默认文件名是build.ninja，其它文件以.ninja为后缀。Makefile与Ninja的区别在于, Makefile是设计来给开发编写的，而Ninja设计出来是给其它程序生成的。如果Makefile是Java语言，那么Ninja就是汇编语言。  
 2.编译源码的方式


Androd系统源码编译有很多种方式，主要有以下几种：



```
在Linux中直接进行系统源码编译（Android官方支持）
在Mac OS中直接进行系统源码编译（Android官方支持）
使用Docker编译，支持Mac OS和Windows

```

其中需要注意的是，Docker的最低支持版本为Windows7，建议用Windows10环境下使用Docker，因为在Windows7种还需要借助Docker Toolbox和VirtualBox中的容器进行通信，效率相对低些。  
 考虑到大多数人的设备和上手难易程度，本为讲解在Linux中直接进行系统源码编译，如果你的系统不是Ubuntu，可以查看Android AOSP基础（一）VirtualBox 安装 Ubuntu这篇文章。  
 3.准备编译环境


1.安装 jdk8


sudo apt-get update  
 sudo apt-get install openjdk-8-jdk


2.使用 ubuntu 14+，需要安装以下依赖包：


sudo apt-get install git-core gnupg flex bison gperf build-essential zip curl zlib1g-dev gcc-multilib g+±multilib libc6-dev-i386 lib32ncurses5-dev x11proto-core-dev libx11-dev lib32z-dev ccache libgl1-mesa-dev libxml2-utils xsltproc unzip


3.设置处理器数量  
 在设置–>系统–>处理器选项，设置处理器数量，建议选择能设置的最大值，这里设置的是6。  
 4.源码整编


整编就是编译整个Android 源码，整编主要有三个步骤，下面分别就行介绍。


1.初始化环境


在AOSP的根目录，输入如下的命令：


source build/envsetup.sh  
 // 编译前删除build文件夹A  
 make clobber


使用 build目录中的envsetup.sh 脚本初始化环境，这个脚本会引入其他的执行脚本。


2. 选择编译目标  
 输入命令：


lunch


lunch命令是envsetup.sh里定义的一个命令，用来让用户选择编译目标。  
 会有以下信息输出：



```
You're building on Linux

Lunch menu... pick a combo:
     1. aosp_arm-eng
     2. aosp_arm64-eng
     3. aosp_mips-eng
     4. aosp_mips64-eng
     5. aosp_x86-eng
     6. aosp_x86_64-eng
     7. aosp_car_arm-userdebug
     8. aosp_car_arm64-userdebug
     9. aosp_car_x86-userdebug
     10. aosp_car_x86_64-userdebug
     11. mini_emulator_arm64-userdebug
     12. m_e_arm-userdebug
     13. m_e_mips64-eng
     14. m_e_mips-userdebug
     15. mini_emulator_x86_64-userdebug
     16. mini_emulator_x86-userdebug
     17. uml-userdebug
     18. aosp_cf_x86_auto-userdebug
     19. aosp_cf_x86_phone-userdebug
     20. aosp_cf_x86_tablet-userdebug
     21. aosp_cf_x86_tablet_3g-userdebug
     22. aosp_cf_x86_tv-userdebug
     23. aosp_cf_x86_wear-userdebug
     24. aosp_cf_x86_64_auto-userdebug
     25. aosp_cf_x86_64_phone-userdebug
     26. aosp_cf_x86_64_tablet-userdebug
     27. aosp_cf_x86_64_tablet_3g-userdebug
     28. aosp_cf_x86_64_tv-userdebug
     29. aosp_cf_x86_64_wear-userdebug
     30. cf_x86_auto-userdebug
     31. cf_x86_phone-userdebug
     32. cf_x86_tablet-userdebug
     33. cf_x86_tablet_3g-userdebug
     34. cf_x86_tv-userdebug
     35. cf_x86_wear-userdebug
     36. cf_x86_64_auto-userdebug
     37. cf_x86_64_phone-userdebug
     38. cf_x86_64_tablet-userdebug
     39. cf_x86_64_tablet_3g-userdebug
     40. cf_x86_64_tv-userdebug
     41. cf_x86_64_wear-userdebug
     42. aosp_marlin-userdebug
     43. aosp_marlin_svelte-userdebug
     44. aosp_sailfish-userdebug
     45. aosp_walleye-userdebug
     46. aosp_walleye_test-userdebug
     47. aosp_taimen-userdebug
     48. hikey-userdebug
     49. hikey64_only-userdebug
     50. hikey960-userdebug

Which would you like? [aosp_arm-eng]

```

意思就是要你选择编译目标的格式，编译目标的格式组成为BUILD-BUILDTYPE，比如aosp\_arm-eng的BUILD为aosp\_arm，BUILDTYPE为eng。


其中BUILD表示编译出的镜像可以运行在什么环境，aosp代表Android开源项目，arm表示系统是运行在arm架构的处理器上。  
 更多参考官方文档。  
 BUILDTYPE 指的是编译类型，有以下三种：



```
user：用来正式发布到市场的版本，权限受限，如没有 root 权限，不能 dedug，adb默认处于停用状态。
userdebug：在user版本的基础上开放了 root 权限和 debug 权限，adb默认处于启用状态。一般用于调试真机。
eng：开发工程师的版本，拥有最大的权限(root等)，具有额外调试工具的开发配置。一般用于模拟器。

```

如果你没有Nexus设备，只想编译完后运行在模拟器查看，那么BUILD可以选择aosp\_x86，BUILDTYPE选择eng，Which would you like? [aosp\_arm-eng]后面直接输入对应序号5就可以。


也可以直接指定编译的目标：


lunch aosp\_x86-eng


或者（不同的系统版本，序号的对应会有差别，建议不要直接用序号）


lunch 5


3. 开始编译  
 通过-jN参数来设置编译的并行任务数，以提高编译速度，在此前我的CPU核心数为6，这里N值最好选在6到12之间，这里我们设置6个并行任务进行编译:


make -j6


整编成功后会打印类似如下内容：  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/2019113016122086.png)  
 由于采用的是虚拟机整编，编译速度会慢一些，这里花费了2小时46分钟.  
 最终会在 out/target/product/generic\_x86/目录生成了三个重要的镜像文件： system.img、userdata.img、ramdisk.img。大概介绍着三个镜像文件：  
 system.img：系统镜像，里面包含了Android系统主要的目录和文件，通过init.c进行解析并mount挂载到/system目录下。  
 userdata.img：用户镜像，是Android系统中存放用户数据的，通过init.c进行解析并mount挂载到/data目录下。  
 ramdisk.img：根文件系统镜像，包含一些启动Android系统的重要文件，比如init.rc。


运行模拟器  
 在编译完成之后,就可以通过以下命令运行Android虚拟机了，命令如下:


source build/envsetup.sh  
 lunch 5  
 emulator


如果是在编译完后运行虚拟机，由于之前已经执行过source和lunch命令了，可以直接运行：


emulator


如果不出意外就会启动模拟器，如果出现报错，网上也有很多的解决方案。  
 5.源码单编


比如我们要编译系统的Settings应用模块，  
 在AOSP根目录执行：


source build/envsetup.sh  
 lunch 5


进入Settings的目录：


cd packages/apps/Settings


mm编译当前目录下的模块，不编译依赖模块。


mm


编译成功后会有提示生成文件的存放路径。


除了Settings.odex文件，还会在out/target/product/generic\_x86/system/priv-app/Settings目录下生成Settings.apk。


此外还有以下命令可以进行单编：



```
mmm：编译指定目录下的模块，不编译它所依赖的其它模块。
mma：编译当前目录下的模块及其依赖项。
mmma：编译指定路径下所有模块，并且包含依赖。

```

如果你修改了源码，想查看生成的APK文件，有两种方式：



```
通过adb push或者adb install 来安装APK。
使用make snod命令，重新生成 system.img，运行模拟器查看。

```




