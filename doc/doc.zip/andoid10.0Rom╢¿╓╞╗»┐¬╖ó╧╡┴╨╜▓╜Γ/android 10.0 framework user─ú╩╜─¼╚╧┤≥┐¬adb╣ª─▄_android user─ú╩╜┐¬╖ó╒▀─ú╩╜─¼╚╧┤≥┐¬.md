






### 1.概述


在10.0定制化开发中，为了方便在产品上线后，需求要求user版本的软件也要默认打开adb连接的，方便抓取log，等等需求  
 这就需要打开user模式的调试接口，然后就可以方便用adb来获取产品的log日志了


### 2.framework user模式默认打开adb功能的核心类



```
build/make/core/main.mk b/build/make/core/main.mk
frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java
/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java
/system/core/adb/Android.mk

```

### 3.framework user模式默认打开adb功能的核心功能分析和实现


解决思路  
 1.打开main.mk的user 调试模式 将ro.debuggable=1就可以了  
 2.默认授予usb权限 去掉usb授权弹窗


### 第一步 给与user模式 调试权限


修改如下:



```
diff --git a/build/make/core/main.mk b/build/make/core/main.mk

index 9c04d96f6c..79a0a0c302 100755

--- a/build/make/core/main.mk

+++ b/build/make/core/main.mk

 ifeq ($(user\_variant),user)
-    ADDITIONAL_DEFAULT_PROPERTIES += ro.adb.secure=1
+    ADDITIONAL_DEFAULT_PROPERTIES += ro.adb.secure=0
 endif

 else # !enable\_target\_debugging 
    # Target is less debuggable and adbd is off by default 
-    ADDITIONAL_DEFAULT_PROPERTIES += ro.debuggable=0
+    ADDITIONAL_DEFAULT_PROPERTIES += ro.debuggable=1
 endif # !enable\_target\_debugging

```

在main.mk文件中，设置ro.adb.secure为1 关闭secure模式  
 设置ro.debuggable为1打开debug模式


### 第二步 当adb连接电脑时 授予usb权限


2. UsbDebuggingActivity.java 授权usb权限  
 修改如下：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java

@@ -126,9 +126,9 @@ public class UsbDebuggingActivity extends AlertActivity
@Override
    public void onCreate(Bundle icicle) {
        Window window = getWindow();
        window.addSystemFlags(
                WindowManager.LayoutParams.SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS);
        window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG);

        super.onCreate(icicle);

        if (SystemProperties.getInt("service.adb.tcp.port", 0) == 0) {
            mDisconnectedReceiver = new UsbDisconnectedReceiver(this);
            IntentFilter filter = new IntentFilter(UsbManager.ACTION_USB_STATE);
            mBroadcastDispatcher.registerReceiver(mDisconnectedReceiver, filter);
        }

        Intent intent = getIntent();
        String fingerprints = intent.getStringExtra("fingerprints");
        mKey = intent.getStringExtra("key");

        if (fingerprints == null || mKey == null) {
            finish();
            return;
        }

        final AlertController.AlertParams ap = mAlertParams;
        ap.mTitle = getString(R.string.usb_debugging_title);
        ap.mMessage = getString(R.string.usb_debugging_message, fingerprints);
        ap.mPositiveButtonText = getString(R.string.usb_debugging_allow);
        ap.mNegativeButtonText = getString(android.R.string.cancel);
        ap.mPositiveButtonListener = this;
        ap.mNegativeButtonListener = this;

        // add "always allow" checkbox
        LayoutInflater inflater = LayoutInflater.from(ap.mContext);
        View checkbox = inflater.inflate(com.android.internal.R.layout.always_use_checkbox, null);
        mAlwaysAllow = (CheckBox)checkbox.findViewById(com.android.internal.R.id.alwaysUse);
        mAlwaysAllow.setText(getString(R.string.usb_debugging_always));
        ap.mView = checkbox;
         window.setCloseOnTouchOutside(false);
 
         setupAlert();
     }

             if (!UsbManager.ACTION_USB_STATE.equals(action)) {

                 return;

             }

-            boolean connected = intent.getBooleanExtra(UsbManager.USB_CONNECTED, false);

+            //boolean connected = intent.getBooleanExtra(UsbManager.USB_CONNECTED, false);

             //modified by elink_qyj start<<<

-            try {

+            /*try {

                 if(android.provider.Settings.Global.getInt(content.getContentResolver(), "elink.admin.adb", 0) == 1){

                     connected = false;

                     IBinder b = ServiceManager.getService(ADB_SERVICE);

@@ -137,11 +137,25 @@ public class UsbDebuggingActivity extends AlertActivity

                 }

             } catch (Exception e) {

                 Log.e(TAG, "Unable to notify Usb service", e);

-            }

+            }*/

             //modified end>>>

-            if (!connected) {

+            boolean connected = false;

+                       if (!connected) {

+                 mActivity.finish();

+             }

+             //usb授权

+

+                       try {

+                                IBinder b = ServiceManager.getService(ADB_SERVICE); 

+                                IAdbManager service = IAdbManager.Stub.asInterface(b);

+                                service.allowDebugging(true, mKey);

+                       } catch (Exception e) {

+                                       Log.e(TAG, "Unable to notify Usb service", e); 

+                       }

+

+            /*if (!connected) {

                 mActivity.finish();

-            }

+            }*/

         }

     }

```

在onCreate中监听UsbDisconnectedReceiver广播，在连接为false时，然后再次连接usb,挂载usb  
 可以就可以使用adb连接设备


### 3.UsbPermissionActivity.java 去掉授权弹窗


修改如下:



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java

@@ -117,7 +117,10 @@ public class UsbPermissionActivity extends AlertActivity

     @Override
     public void onCreate(Bundle icicle) {
         super.onCreate(icicle);
 
         Intent intent = getIntent();
         mDevice = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
         mAccessory = (UsbAccessory)intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
         mPendingIntent = (PendingIntent)intent.getParcelableExtra(Intent.EXTRA_INTENT);
         mUid = intent.getIntExtra(Intent.EXTRA_UID, -1);
         mPackageName = intent.getStringExtra(UsbManager.EXTRA_PACKAGE);
         boolean canBeDefault = intent.getBooleanExtra(UsbManager.EXTRA_CAN_BE_DEFAULT, false);
 
         PackageManager packageManager = getPackageManager();
         ApplicationInfo aInfo;
         try {
             aInfo = packageManager.getApplicationInfo(mPackageName, 0);
         } catch (PackageManager.NameNotFoundException e) {
             Log.e(TAG, "unable to look up package name", e);
             finish();
             return;
         }
         String appName = aInfo.loadLabel(packageManager).toString();
 
         final AlertController.AlertParams ap = mAlertParams;
         ap.mTitle = appName;
         boolean useRecordWarning = false;
         if (mDevice == null) {
             // Accessory Case
 
             ap.mMessage = getString(R.string.usb_accessory_permission_prompt, appName,
                     mAccessory.getDescription());
             mDisconnectedReceiver = new UsbDisconnectedReceiver(this, mAccessory);
         } else {
             boolean hasRecordPermission =
                     PermissionChecker.checkPermissionForPreflight(
                             this, android.Manifest.permission.RECORD_AUDIO, -1, aInfo.uid,
                             mPackageName)
                             == android.content.pm.PackageManager.PERMISSION_GRANTED;
              boolean isAudioCaptureDevice = mDevice.getHasAudioCapture();
              useRecordWarning = isAudioCaptureDevice && !hasRecordPermission;
  
              int strID = useRecordWarning
                      ? R.string.usb_device_permission_prompt_warn
                      : R.string.usb_device_permission_prompt;
              ap.mMessage = getString(strID, appName, mDevice.getProductName());
              mDisconnectedReceiver = new UsbDisconnectedReceiver(this, mDevice);
  
          }
  
          ap.mPositiveButtonText = getString(android.R.string.ok);
          ap.mNegativeButtonText = getString(android.R.string.cancel);
          ap.mPositiveButtonListener = this;
          ap.mNegativeButtonListener = this;
  
          // Don't show the "always use" checkbox if the USB/Record warning is in effect
          if (!useRecordWarning && canBeDefault && (mDevice != null || mAccessory != null)) {
              // add "open when" checkbox
              LayoutInflater inflater = (LayoutInflater) getSystemService(
                      Context.LAYOUT_INFLATER_SERVICE);
              ap.mView = inflater.inflate(com.android.internal.R.layout.always_use_checkbox, null);
              mAlwaysUse = (CheckBox) ap.mView.findViewById(com.android.internal.R.id.alwaysUse);
              if (mDevice == null) {
                  mAlwaysUse.setText(getString(R.string.always_use_accessory, appName,
                          mAccessory.getDescription()));
              } else {
                  mAlwaysUse.setText(getString(R.string.always_use_device, appName,
                          mDevice.getProductName()));
              }
              mAlwaysUse.setOnCheckedChangeListener(this);
  
              mClearDefaultHint = (TextView)ap.mView.findViewById(
                      com.android.internal.R.id.clearDefaultHint);
              mClearDefaultHint.setVisibility(View.GONE);
          }
 

-        setupAlert();

+        //setupAlert();

+               Log.d(TAG, "grant usb permission automatically");

+               mPermissionGranted = true;

+       finish();

     }

```

在onCreate方法中注释掉setupAlert();然后finish()掉窗口就可以了默认去掉usb授权弹窗  
 然后编译发现adb已经默认可以连接电脑了


### 4.adb相关属性



```
/system/core/adb/Android.mk

```


```
- LOCAL_CFLAGS += -DALLOW_ADBD_NO_AUTH=$(if $(filter userdebug eng,$(TARGET\_BUILD\_VARIANT)),1,0)
+ LOCAL_CFLAGS += -DALLOW_ADBD_NO_AUTH=$(if $(filter user userdebug eng,$(TARGET\_BUILD\_VARIANT)),1,0)

```

在DALLOW\_ADBD\_NO\_AUTH增加user模式的签名验证





