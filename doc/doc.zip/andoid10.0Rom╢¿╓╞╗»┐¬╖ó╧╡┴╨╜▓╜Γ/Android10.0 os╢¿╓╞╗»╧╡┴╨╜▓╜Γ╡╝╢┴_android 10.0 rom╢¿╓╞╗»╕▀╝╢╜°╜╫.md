



​


## 一.前言


本专栏主要是作者本人在10.0 frameworks定制化实战功能系列的解读，在从事几年的frameworks定制化功能的经验的积累，开发过平板，广告机，会议机，车机等一系列系统上层定制的功能性开发，写博客的目的，一方面是整理自己做的功能知识点沉淀技术，一方面帮助专栏小伙伴共同进步共同探讨知识点


##  二.专栏伙伴互助学习交流群


为了方便伙伴们互相学习交流组建了交流群


订阅付费专栏伙伴内部交流群:385286204


android系统定制开发行业交流群:309212664


专栏博客每周更新三篇，当然博客到一定篇数，价格也会随之上涨


##   三.专栏内容的简单介绍


在系统frameworks上层定制的内容 主要就是Launcher3,Settings,SystemUI,wifi,蓝牙,recovery,摄像头模块蓝牙模块TF卡模块短信电话模块adb模块otg模块USB模块NFC模块等系统应用和frameworks的相关内容的定制  
 3.1关于Launcher3的定制的部分博客介绍  
 Android 10.0 Launcher3 禁止首屏时钟AppWidget拖动到其他屏  
 Android 10.0 屏蔽Launcher3桌面app图标的长按功能  
 Android 10.0 Launcher3 app图标和hotseat 添加背景(焦点选中背景)  
 Android 10.0 Launcher3 禁止卸载某个第三方app  
 Android 10.0 Launcher3 电话和短信app图标显示未读短信和未接来电的条数Android 10.0 仿ios的hotseat效果修改hotseat样式  
 Android 10.0Launcher3修改桌面时钟字体大小和字体颜色  
 android 8.1 9.0 10.0Launcher3 背景和icon重影的问题解决android 8.1 9.0 10.0 Launcher3长按拖拽时最后一屏未满时不让拖拽到后一屏(二)android 8.1 9.0 10.0 Launcher3长按拖拽时，获取当前是哪一屏，获取当前多少个应用图标Android 9.0 10.0 Launcher3 去掉workspace长按弹出壁纸弹窗  
 android 9.0 10.0 Launcher3添加负一屏(左一屏)功能  
 android 8.1 9.0 10.0Launcher3 workspace 加载默认的布局(自定义workspace布局)android 9.0 10.0 修改Launcher3 app hotseat 图标形状为圆角图标android10.0 Launcher3修改某个app icon的图标  
 android 8.1 9.0 10.0 Launcher3禁止拖拽app图标到第一屏  
 android 8.1 9.0 10.0 Launcher3禁止拖动图标到Hotseat  
 android 9.0 10.0 Hotseat 添加allapp button  
 Android8.1 9.0 10.0 Launcher3 禁止在HotSeat创建文件夹


这些就是关于Launcher3的部分博客，每周博客更新中...


3.2 关于SystemUI的部分博客  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(十三)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(十二)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(十一)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(十)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(九)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(八)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(七)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(六)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(五)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(四)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(三)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(二)  
 Android 10.0 SystemUI下拉状态栏UI定制化开发系列(一)  
 Android 10.0 SystemUI 下拉通知栏通知默认展开  
 android 10.0 SystemUI自定义手势导航的手势返回的布局样式  
 Android 10.0 SystemUI 状态栏屏蔽弹出的 提醒式通知  
 Android 10.0 SystemUI设置导航栏默认为系统手势导航


以上都是关于SystemUI的博客部分内容，每周博客更新中...  
 3.3 recovery功能的相关博客  
 Android 10.0 进入recovery模式(等待用户选择recovery模式界面)实现自动恢复出厂设置  
 Android 10.0修改recovery 菜单项字体大小  
 Android 10.0 修改Recovery字体图片的大小(正在清理)文字大小  
 Android 10.0 recovery竖屏界面旋转为横屏  
 android 10.0去掉recovery模式UI页面的选项  
 Android 10.0 recovery prompt\_and\_wait 跳过弹窗 自动 WIPE\_DATA（出厂设置）  
 Android 10.0 cache目录下恢复出厂设置不会被删除的文件的修改


以上就是recovery的相关部分博客  
 3.4 关于Settings部分博客  
 android Q(10.0)Settings主页动态显示和隐藏设置项(一级菜单显示和隐藏)android10.0(Q)Settings 休眠时间项(屏幕超时)添加永不休眠功能  
 android Q(10.0)Settings 添加设置项 多个Launcher时设置需要启动Launcher  
 android10.0(Q) Settings主页去掉搜索功能显示不全解决方法  
 android 10.0 Settings去掉二级三级菜单搜索功能  
 Android 9.0 10.0 Settings增加屏保功能(屏保时间必须小于休眠时间)  
 Android 10.0 Settings 显示 去掉二级菜单 壁纸  
 Android 10.0 Settings音量条样式修改(二）  
 android 9.0 10.0 Settings系统默认字体大小的修改  
 Android 10.0 Settings 搜索功能屏蔽某个app  
 Android 10.0 Settings去掉搜索框  
 3.5 关于frameworks层定制的部分博客  
 Android 10.0 关于startActivity finishActivity displayActivity流程详解  
 Android 10.0 存在中文字符,中文文件名，中文系统属性，编译报错的解决方案  
 Android 10.0 添加自定义开机广播  
 Android 10.0 User版本通过属性来开启或关闭root权限  
 Android 10.0 app授予通知权限 默认开启通知  
 Android 10.0 进入Launcher前黑屏2秒的解决办法  
 Android 10.0 framework 增加音量+音量-键唤醒屏幕的功能  
 Android 10.0微信视频通话上下颠倒的解决方案  
 android 10.0 去掉未知来源弹窗 默认授予安装未知来源权限  
 Android 10.0 强制app横屏显示  
 android 10.0屏蔽FallbackHome 直接进入默认Launcher(去掉android正在启动弹窗)  
 Android 10.0 framework普通app发隐式广播受到限制的解决方案  
 Android 10.0 系统上滑手势增加home的功能  
 Android 10.0 实现屏幕10s无操作自动播放视频  
 Android 10.0 app添加校验锁(输入密码才能进入app)  
 Android 10.0以上后台不能启动Activity的解决方法  
 Android 10.0进程加入白名单,避免被杀掉  
 Android 10.0 根据包名授予app所需的权限  
 android 9.0 10.0 framework层 Camera旋转摄像头方向


Android 10.0 framework层KeyEvent按键添加流程  
 android 9.0 10.0拦截所有陌生来电防骚扰功能  
 android 9.0 10.0 设置上网应用白名单(上网app白名单)  
 android 8.1 9.0 10.0 app安装黑名单（限制app安装）  
 android 10.0 设置wifi白名单  
 android 7.1 8.0 9.0 10.0 禁止app启动和允许app运行  
 android 10.0屏蔽短信功能(短信发送开关)  
 android 10.0 屏蔽所有电话来电功能  
 android 9.0 10.0启用和停用蓝牙模块(蓝牙模块功能开关控制)


以上都是关于frameworks定制的一些功能


更多博客详情请点击


##  4.总结


对于系统frameworks上层定制来说，熟悉系统框架层的大致源码是必备的，这也需要一点一滴的积累的，当然更应该是在实战开发项目中积累相关的经验，通过共同探讨共同进步，由于作者的水平有限，在本专栏有不足之处请伙伴们指出来，和伙伴们共同进步


​



