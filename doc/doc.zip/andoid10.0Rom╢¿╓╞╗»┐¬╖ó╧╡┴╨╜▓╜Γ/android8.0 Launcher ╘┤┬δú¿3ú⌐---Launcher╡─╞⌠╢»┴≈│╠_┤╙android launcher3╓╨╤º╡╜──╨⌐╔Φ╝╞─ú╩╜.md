






Launcher启动流程分析  
 我们知道android系统是运行在Linux内核上，整个launcher的启动流程如图所示，接下来我们一步一步进行分析。


![在这里插入图片描述](https://img-blog.csdnimg.cn/2019112809072750.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)  
 【init进程】  
 Linux内核启动后巡行的第一个进程是init。这个进程是一个守护进程。生命周期贯穿整个Linux内核 运行的始终。  
 我们知道android系统是运行在Linux内核上的所以google实现了android系统的init进程。


init进程主要做了三件事：  
 创建一些文件夹并挂在设备  
 初始化和启动属性服务  
 解析init.rc配置文件并启动zygote进程  
 【Zygote孵化器】  
 创建JavaVm（java虚拟机），应用程序进程，运行系统的关键服务，systemservice进程  
 它是通过fock（复制进程）的形式来创建应用程序和systemservice进程  
 sygote在启动时会创建javaVm，所以fock创建的应用进程和systemserver进程内部可以获取一个javaVm的实例拷贝。


Zygote孵化器做了什么：  
 创建AppRuntime并调用start方法，启动zygote进程。  
 创建JavaVM并为JVM注册JNI。  
 通过JNI调用zygoteInit的main函数进入zygote的Java框架层  
 通过registerzygotesocket函数创建服务端socket，并通过runselectloop等向ActivityManagerService的请求来创建新的应用进程。  
 启动SystemServer进程。  
 【SystemServer】  
 SystemServer进程其实也是由Zygote进程fork出来的，并且执行其main方法。


那他都做了哪些工作？  
 启动Binder线程池，这样就可以与其他进程进行通信。  
 创建SystemserviceManager用于对系统的服务进行创建，启动和生命周期的管理。  
 启动各种系统服务包括（ActivityManagerService，WindowManager，PackageManagerService，WindowManagerService等）。  
 【ActivityManagerService】  
 Activity会调用startHomeActivityLocked方法，此方法会创建一个Intent，mTopAction和mTopData传给Intent，其中mTopAction为Intent.ACTION\_MAIN，Intent的category为android.intent.category.Home。而Launcher的AndroidMainfest.xml文件里面给Launcher定义的category也是Home，根据匹配原则，这样就会启动这个Launcher。


这就是Launcher的启动流程，这样就清楚手机是怎么启动launcher的了，接下来我们就真正开始源码的分析。





