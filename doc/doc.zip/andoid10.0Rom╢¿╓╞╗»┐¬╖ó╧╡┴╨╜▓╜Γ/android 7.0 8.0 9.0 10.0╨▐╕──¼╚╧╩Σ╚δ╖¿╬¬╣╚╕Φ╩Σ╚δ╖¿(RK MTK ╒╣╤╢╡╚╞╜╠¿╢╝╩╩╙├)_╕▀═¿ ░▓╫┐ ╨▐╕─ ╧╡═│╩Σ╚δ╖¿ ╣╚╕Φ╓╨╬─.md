






在定制化开发过程中，由于客户不喜欢系统输入法，所以说对于修改系统输入法的需求，也是经常需要改的需求，


常用的输入法id如下:  
 1.系统默认的输入法ID为:



```
com.android.inputmethod.latin/.LatinIME

```

2.谷歌拼音输入法的输入法ID为:



```
com.google.android.inputmethod.pinyin/.PinyinIME

```

3.搜狗输入法的输入法ID为:



```
com.sohu.inputmethod.sogou/.SogouIME

```

4.微软必应输入法的输入法ID为:



```
com.bingime.ime/.BingIme

```

5.讯飞输入法ID为:



```
com.iflytek.inputmethod/.FlyIME

```

而系统默认的输入法 都是保存在系统Settings的数据库里面的  
 所以只需要修改默认的系统输入法为谷歌拼音输入法就可以了


展讯默认输入法改为谷歌拼音输入法  
 只需要将系统输入法换成谷歌输入法就可以了



```
--- a/device/google/atv/overlay/frameworks/base/core/res/res/values/config.xml
+++ b/device/google/atv/overlay/frameworks/base/core/res/res/values/config.xml
@@ -84,12 +84,12 @@
          And the disabled_until_used state for an IME is released by InputMethodManagerService
          when the IME is selected as an enabled IME. -->
     <string-array name="config\_disabledUntilUsedPreinstalledImes" translatable="false">
+        <item>com.google.android.inputmethod.pinyin</item>
         <item>com.google.android.inputmethod.latin</item>
         <item>com.google.android.apps.inputmethod.hindi</item>
         <item>com.google.android.apps.inputmethod.zhuyin</item>
         <item>com.google.android.inputmethod.japanese</item>
         <item>com.google.android.inputmethod.korean</item>
-        <item>com.google.android.inputmethod.pinyin</item>
     </string-array>
 
     <!-- Whether to keep background restricted profiles running after exiting. If set to false,
diff --git a/frameworks/base/core/res/res/values/config.xml b/frameworks/base/core/res/res/values/config.xml
index fa65de109e..ca57a9b260 100755
--- a/frameworks/base/core/res/res/values/config.xml
+++ b/frameworks/base/core/res/res/values/config.xml
@@ -2712,7 +2712,7 @@
          And the disabled_until_used state for an IME is released by InputMethodManagerService
          when the IME is selected as an enabled IME. -->
     <string-array name="config\_disabledUntilUsedPreinstalledImes" translatable="false">
-        <item>com.android.inputmethod.latin</item>
+        <item>com.google.android.inputmethod.pinyin</item>
     </string-array>

```

2. 设置默认输入法:



```
Settings.Secure.putString(context.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD, R.string.config_disabledUntilUsedPreinstalledImes);

```




