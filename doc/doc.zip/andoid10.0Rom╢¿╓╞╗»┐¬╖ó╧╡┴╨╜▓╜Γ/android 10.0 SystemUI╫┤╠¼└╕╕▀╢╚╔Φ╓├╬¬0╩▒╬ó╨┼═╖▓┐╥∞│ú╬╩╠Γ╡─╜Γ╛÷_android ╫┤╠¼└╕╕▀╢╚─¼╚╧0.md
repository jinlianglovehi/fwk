






### 1.概述


在10.0的系统产品定制化开发中，由于不需要SystemUI的导航栏所以就把高度设置为0，这样虽然导航栏是隐藏不见了,但是又会有新的问题出现，比如安装微信，qq等 首页的头像好像被挡住了一部分，经过思考影响头部的只可能是Status.java了


### 2.状态栏高度设置为0时微信头部异常问题的解决的核心类



```
frameworks/base/core/res/res/values/dimens.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java

```

### 3.状态栏高度设置为0时微信头部异常问题的解决的核心功能分析和实现


首选在dimens.xml中设置高度不为0  
 首先把导航栏高度修改为1dp


### 3.1 关于导航栏高度修改



```
diff --git a/frameworks/base/core/res/res/values/dimens.xml b/frameworks/base/core/res/res/values/dimens.xml
index 9886a4f..af7038e 100755 (executable)
--- a/frameworks/base/core/res/res/values/dimens.xml
+++ b/frameworks/base/core/res/res/values/dimens.xml

     <!-- Height of the status bar in portrait -->
-    <dimen name="status\_bar\_height\_portrait">0dp</dimen>
+    <dimen name="status\_bar\_height\_portrait">1dp</dimen>
     <!-- Height of the status bar in landscape -->
     <dimen name="status\_bar\_height\_landscape">@dimen/status_bar_height_portrait</dimen>

```


```
 <!-- Height of area above QQS where battery/time go -->

```

### 3.2查看StatusBar.java源码寻找问题的根源



```
 // ================================================================================
    // Constructing the view
    // ================================================================================
    protected void makeStatusBarView(@Nullable RegisterStatusBarResult result) {
        final Context context = mContext;
        updateDisplaySize(); // populates mDisplayMetrics
        updateResources();
        updateTheme();

        inflateStatusBarWindow(context);
        mStatusBarWindow.setService(this);
        mStatusBarWindow.setOnTouchListener(getStatusBarWindowTouchListener());

        // TODO: Deal with the ugliness that comes from having some of the statusbar broken out
        // into fragments, but the rest here, it leaves some awkward lifecycle and whatnot.
        mNotificationPanel = mStatusBarWindow.findViewById(R.id.notification_panel);
        mStackScroller = mStatusBarWindow.findViewById(R.id.notification_stack_scroller);
        mZenController.addCallback(this);
        NotificationListContainer notifListContainer = (NotificationListContainer) mStackScroller;
        mNotificationLogger.setUpWithContainer(notifListContainer);

        mNotificationIconAreaController = SystemUIFactory.getInstance()
                .createNotificationIconAreaController(context, this, mStatusBarStateController);
        inflateShelf();
        mNotificationIconAreaController.setupShelf(mNotificationShelf);

        FragmentHostManager.get(mStatusBarWindow)
                .addTagListener(CollapsedStatusBarFragment.TAG, (tag, fragment) -> {
                    CollapsedStatusBarFragment statusBarFragment =
                            (CollapsedStatusBarFragment) fragment;
                    statusBarFragment.initNotificationIconArea(mNotificationIconAreaController);
                    PhoneStatusBarView oldStatusBarView = mStatusBarView;
                    mStatusBarView = (PhoneStatusBarView) fragment.getView();
                    mStatusBarView.setBar(this);
                    mStatusBarView.setPanel(mNotificationPanel);
                    mStatusBarView.setScrimController(mScrimController);

                    // CollapsedStatusBarFragment re-inflated PhoneStatusBarView and both of
                    // mStatusBarView.mExpanded and mStatusBarView.mBouncerShowing are false.
                    // PhoneStatusBarView's new instance will set to be gone in
 // PanelBar.updateVisibility after calling mStatusBarView.setBouncerShowing
 // that will trigger PanelBar.updateVisibility. If there is a heads up showing,
 // it needs to notify PhoneStatusBarView's new instance to update the correct
                    // status by calling mNotificationPanel.notifyBarPanelExpansionChanged().
                    if (mHeadsUpManager.hasPinnedHeadsUp()) {
                        mNotificationPanel.notifyBarPanelExpansionChanged();
                    }
                    mStatusBarView.setBouncerShowing(mBouncerShowing);
                    if (oldStatusBarView != null) {
                        float fraction = oldStatusBarView.getExpansionFraction();
                        boolean expanded = oldStatusBarView.isExpanded();
                        mStatusBarView.panelExpansionChanged(fraction, expanded);
                    }

                    HeadsUpAppearanceController oldController = mHeadsUpAppearanceController;
                    if (mHeadsUpAppearanceController != null) {
                        // This view is being recreated, let's destroy the old one
                        mHeadsUpAppearanceController.destroy();
                    }
                    mHeadsUpAppearanceController = new HeadsUpAppearanceController(
                            mNotificationIconAreaController, mHeadsUpManager, mStatusBarWindow);
                    mHeadsUpAppearanceController.readFrom(oldController);
                    mStatusBarWindow.setStatusBarView(mStatusBarView);
                    updateAreThereNotifications();
                    checkBarModes();
                }).getFragmentManager()
                .beginTransaction()
                .replace(R.id.status_bar_container, new CollapsedStatusBarFragment(),
                        CollapsedStatusBarFragment.TAG)
                .commit();
        mIconController = Dependency.get(StatusBarIconController.class);
....
        createNavigationBar(result);

        if (ENABLE_LOCKSCREEN_WALLPAPER) {
            mLockscreenWallpaper = new LockscreenWallpaper(mContext, this, mHandler);
        }

        mKeyguardIndicationController =
                SystemUIFactory.getInstance().createKeyguardIndicationController(mContext,
                        mStatusBarWindow.findViewById(R.id.keyguard_indication_area),
                        mStatusBarWindow.findViewById(R.id.lock_icon));
        mNotificationPanel.setKeyguardIndicationController(mKeyguardIndicationController);

        mAmbientIndicationContainer = mStatusBarWindow.findViewById(
                R.id.ambient_indication_container);

        // TODO: Find better place for this callback.
        mBatteryController.addCallback(new BatteryStateChangeCallback() {
            @Override
            public void onPowerSaveChanged(boolean isPowerSave) {
                mHandler.post(mCheckBarModes);
                if (mDozeServiceHost != null) {
                    mDozeServiceHost.firePowerSaveChanged(isPowerSave);
                }
            }

            @Override
            public void onBatteryLevelChanged(int level, boolean pluggedIn, boolean charging) {
                // noop
            }
        });

        mAutoHideController = Dependency.get(AutoHideController.class);
        mAutoHideController.setStatusBar(this);

        mLightBarController = Dependency.get(LightBarController.class);

        ScrimView scrimBehind = mStatusBarWindow.findViewById(R.id.scrim_behind);
        ScrimView scrimInFront = mStatusBarWindow.findViewById(R.id.scrim_in_front);
        mScrimController = SystemUIFactory.getInstance().createScrimController(
                scrimBehind, scrimInFront, mLockscreenWallpaper,
                (state, alpha, color) -> mLightBarController.setScrimState(state, alpha, color),
                scrimsVisible -> {
                    if (mStatusBarWindowController != null) {
                        mStatusBarWindowController.setScrimsVisibility(scrimsVisible);
                    }
                    if (mStatusBarWindow != null) {
                        mStatusBarWindow.onScrimVisibilityChanged(scrimsVisible);
                    }
                }, DozeParameters.getInstance(mContext),
                mContext.getSystemService(AlarmManager.class));
        mNotificationPanel.initDependencies(this, mGroupManager, mNotificationShelf,
                mHeadsUpManager, mNotificationIconAreaController, mScrimController);
        mDozeScrimController = new DozeScrimController(DozeParameters.getInstance(context));

        BackDropView backdrop = mStatusBarWindow.findViewById(R.id.backdrop);
        mMediaManager.setup(backdrop, backdrop.findViewById(R.id.backdrop_front),
                backdrop.findViewById(R.id.backdrop_back), mScrimController, mLockscreenWallpaper);

        // Other icons
        mVolumeComponent = getComponent(VolumeComponent.class);

        mNotificationPanel.setUserSetupComplete(mUserSetup);
        if (UserManager.get(mContext).isUserSwitcherEnabled()) {
            createUserSwitcher();
        }

        mNotificationPanel.setLaunchAffordanceListener(
                mStatusBarWindow::onShowingLaunchAffordanceChanged);

        // Set up the quick settings tile panel
        View container = mStatusBarWindow.findViewById(R.id.qs_frame);
        if (container != null) {
            FragmentHostManager fragmentHostManager = FragmentHostManager.get(container);
            ExtensionFragmentListener.attachExtensonToFragment(container, QS.TAG, R.id.qs_frame,
                    Dependency.get(ExtensionController.class)
                            .newExtension(QS.class)
                            .withPlugin(QS.class)
                            .withDefault(this::createDefaultQSFragment)
                            .build());
            mBrightnessMirrorController = new BrightnessMirrorController(mStatusBarWindow,
                    (visible) -> {
                        mBrightnessMirrorVisible = visible;
                        updateScrimController();
                    });
            fragmentHostManager.addTagListener(QS.TAG, (tag, f) -> {
                QS qs = (QS) f;
                if (qs instanceof QSFragment) {
                    mQSPanel = ((QSFragment) qs).getQsPanel();
 mQSPanel.setBrightnessMirror(mBrightnessMirrorController);
 mFooter = ((QSFragment) qs).getFooter();
 }
 });
 }

 // receive broadcasts
 IntentFilter filter = new IntentFilter();
 filter.addAction(Intent.ACTION\_CLOSE\_SYSTEM\_DIALOGS);
 filter.addAction(Intent.ACTION\_SCREEN\_OFF);
 filter.addAction(DevicePolicyManager.ACTION\_SHOW\_DEVICE\_MONITORING\_DIALOG);
 /\* UNISOC: Bug 1074234, 885650, Super power feature @{ \*/
 if(SprdPowerManagerUtil.SUPPORT\_SUPER\_POWER\_SAVE){
 filter.addAction(SprdPowerManagerUtil.ACTION\_POWEREX\_SAVE\_MODE\_CHANGED);
 }
 /\* @} \*/
 context.registerReceiverAsUser(mBroadcastReceiver, UserHandle.ALL, filter, null, null);

 IntentFilter demoFilter = new IntentFilter();
 if (DEBUG\_MEDIA\_FAKE\_ARTWORK) {
 demoFilter.addAction(ACTION\_FAKE\_ARTWORK);
 }
 demoFilter.addAction(ACTION\_DEMO);
 context.registerReceiverAsUser(mDemoReceiver, UserHandle.ALL, demoFilter,
 android.Manifest.permission.DUMP, null);

 // listen for USER\_SETUP\_COMPLETE setting (per-user)
 mDeviceProvisionedController.addCallback(mUserSetupObserver);
 mUserSetupObserver.onUserSetupChanged();

 // disable profiling bars, since they overlap and clutter the output on app windows
 ThreadedRenderer.overrideProperty("disableProfileBars", "true");

 // Private API call to make the shadows look better for Recents
 ThreadedRenderer.overrideProperty("ambientRatio", String.valueOf(1.5f));
    }

```

在Status.java中makeStatusBarView(@Nullable RegisterStatusBarResult result) 来初始化一切状态栏导航栏等  
 相关类  
 而在  
 FragmentHostManager.get(mStatusBarWindow)  
 .addTagListener  
 当重新加载状态栏和状态栏有变化都会回调这里


所以修改如下:


diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java  
 index 776f872…28bc07b 100755 (executable)



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
@@ -907,6 +907,14 @@ public class StatusBar extends SystemUI implements DemoMode,
                     statusBarFragment.initNotificationIconArea(mNotificationIconAreaController);
                     PhoneStatusBarView oldStatusBarView = mStatusBarView;
                     mStatusBarView = (PhoneStatusBarView) fragment.getView();
+                    //add code start

+                        if(mStatusBarView!=null){
+                           if(mStatusBarView.getVisibility()==View.VISIBLE)

+                           mStatusBarView.setVisibility(View.GONE);
+                        }
+                    }
+                    //add code end
                     mStatusBarView.setBar(this);
                     mStatusBarView.setPanel(mNotificationPanel);
                     mStatusBarView.setScrimController(mScrimController);

```

在makeStatusBarView(@Nullable RegisterStatusBarResult result) 初始化状态栏的时候 判断如果状态栏显示  
 就隐藏掉





