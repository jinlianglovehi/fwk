






### 1.概述


在10.0的系统产品开发中，对于SystemUI的状态栏上显示的时间由于只显示到分，由于产品的特殊需求要求时间精确到秒，所以就要修改下显示时间的格式，完成时间格式的要求


### 2.SystemUI 状态栏时间显示秒的核心类



```
 /frameworks/base/packages/SystemUI/res/layout/status_bar.xml

```

### 3.SystemUI 状态栏时间显示秒的核心功能分析和实现


在SystemUI状态栏中，时间控件就是status\_bar.xml中的


### 3.1 status\_bar.xml中的相关源码分析



```
 <!--    android:background="@drawable/status\_bar\_closed\_default\_background" -->
 <com.android.systemui.statusbar.phone.PhoneStatusBarView
     xmlns:android="http://schemas.android.com/apk/res/android"
     xmlns:systemui="http://schemas.android.com/apk/res/com.android.systemui"
     android:layout_width="match\_parent"
     android:layout_height="@dimen/status\_bar\_height"
     android:id="@+id/status\_bar"
     android:background="@drawable/system\_bar\_background"
     android:orientation="vertical"
     android:focusable="false"
     android:descendantFocusability="afterDescendants"
     android:accessibilityPaneTitle="@string/status\_bar"
     >
 
     <ImageView
         android:id="@+id/notification\_lights\_out"
         android:layout_width="@dimen/status\_bar\_icon\_size"
         android:layout_height="match\_parent"
         android:paddingStart="@dimen/status\_bar\_padding\_start"
         android:paddingBottom="2dip"
         android:src="@drawable/ic\_sysbar\_lights\_out\_dot\_small"
         android:scaleType="center"
         android:visibility="gone"
         />
 
     <LinearLayout android:id="@+id/status\_bar\_contents"
         android:layout_width="match\_parent"
         android:layout_height="match\_parent"
         android:paddingStart="@dimen/status\_bar\_padding\_start"
         android:paddingEnd="@dimen/status\_bar\_padding\_end"
         android:paddingTop="@dimen/status\_bar\_padding\_top"
         android:orientation="horizontal"
         >
         <FrameLayout
             android:layout_height="match\_parent"
             android:layout_width="0dp"
             android:layout_weight="1">
 
             <include layout="@layout/heads\_up\_status\_bar\_layout" />
 
             <!-- The alpha of the left side is controlled by PhoneStatusBarTransitions, and the
              individual views are controlled by StatusBarManager disable flags DISABLE_CLOCK and
              DISABLE_NOTIFICATION_ICONS, respectively -->
             <LinearLayout
                 android:id="@+id/status\_bar\_left\_side"
                 android:layout_height="match\_parent"
                 android:layout_width="match\_parent"
                 android:clipChildren="false"
             >
                 <ViewStub
                     android:id="@+id/operator\_name"
                     android:layout_width="wrap\_content"
                     android:layout_height="match\_parent"
                     android:layout="@layout/operator\_name" />
 
                 <com.android.systemui.statusbar.policy.Clock
                     android:id="@+id/clock"
                     android:layout_width="wrap\_content"
                     android:layout_height="match\_parent"
                     android:textAppearance="@style/TextAppearance.StatusBar.Clock"
                     android:singleLine="true"
                     android:paddingStart="@dimen/status\_bar\_left\_clock\_starting\_padding"
                     android:paddingEnd="@dimen/status\_bar\_left\_clock\_end\_padding"
                     android:gravity="center\_vertical|start"
                 />
 
                 <com.android.systemui.statusbar.AlphaOptimizedFrameLayout
                     android:id="@+id/notification\_icon\_area"
                     android:layout_width="0dp"
                     android:layout_height="match\_parent"
                     android:layout_weight="1"
                     android:orientation="horizontal"
                     android:clipChildren="false"/>
 
             </LinearLayout>
         </FrameLayout>

```

从status\_bar.xml中的源码中发现  
 com.android.systemui.statusbar.policy.Clock  
 也就是Clock .java 这个就是状态栏的时间格式  
 接下来看 Clock.java源码  
 private boolean mShowSeconds;  
 是否显示秒


### 3.2 Clock.java关于时间显示格式化分析



```
public class Clock extends TextView implements DemoMode, Tunable, CommandQueue.Callbacks,
         DarkReceiver, ConfigurationListener {
      public Clock(Context context) {
          this(context, null);
      }
  
      public Clock(Context context, AttributeSet attrs) {
          this(context, attrs, 0);
      }
  
      public Clock(Context context, AttributeSet attrs, int defStyle) {
          super(context, attrs, defStyle);
          TypedArray a = context.getTheme().obtainStyledAttributes(
                  attrs,
                  R.styleable.Clock,
                  0, 0);
          try {
              mAmPmStyle = a.getInt(R.styleable.Clock_amPmStyle, AM_PM_STYLE_GONE);
              mShowDark = a.getBoolean(R.styleable.Clock_showDark, true);
              mNonAdaptedColor = getCurrentTextColor();
          } finally {
              a.recycle();
          }
          mCurrentUserTracker = new CurrentUserTracker(context) {
              @Override
              public void onUserSwitched(int newUserId) {
                  mCurrentUserId = newUserId;
              }
          };
      }
private void updateShowSeconds() {
    if (mShowSeconds) {
        // Wait until we have a display to start trying to show seconds.
        if (mSecondsHandler == null && getDisplay() != null) {
            mSecondsHandler = new Handler();
            if (getDisplay().getState() == Display.STATE_ON) {
                mSecondsHandler.postAtTime(mSecondTick,
                        SystemClock.uptimeMillis() / 1000 * 1000 + 1000);
            }
            IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            mContext.registerReceiver(mScreenReceiver, filter);
        }
    } else {
        if (mSecondsHandler != null) {
            mContext.unregisterReceiver(mScreenReceiver);
            mSecondsHandler.removeCallbacks(mSecondTick);
            mSecondsHandler = null;
            updateClock();
        }
    }
}

```

在Clock.java中当时间每秒变化时都会调用updateShowSeconds()的所有也是  
 在这里根据mShowSeconds 是否显示秒来显示时间  
 所以要查看哪里赋值了



```
在     @Override
    public void onTuningChanged(String key, String newValue) {
        if (CLOCK_SECONDS.equals(key)) {
            mShowSeconds = TunerService.parseIntegerSwitch(newValue, false);
            updateShowSeconds();
        } else {
            setClockVisibleByUser(!StatusBarIconController.getIconBlacklist(newValue)
                    .contains("clock"));
            updateClockVisibility();
        }
    }

```

在onTuningChanged(String key, String newValue)  
 中有针对mShowSeconds 赋值  
 所有可以  
 在这里 吧mShowSeconds=true 就行了


修改如下:



```
public void onTuningChanged(String key, String newValue) {
        if (CLOCK_SECONDS.equals(key)) {
            mShowSeconds = TunerService.parseIntegerSwitch(newValue, false);
			mShowSeconds = true;
            updateShowSeconds();
        } else {
            setClockVisibleByUser(!StatusBarIconController.getIconBlacklist(newValue)
                    .contains("clock"));
            updateClockVisibility();
        }
    }

```




