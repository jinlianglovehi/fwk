






在做定制化开发的过程中，对于系统的工厂测试模式，有客户也是不想看到这种模式的，需要去掉工厂测试模式，  
 而工厂测试模式又是在开机启动的时候 长按power + 音量加 会进入工厂测试模式，所以在bootloader里面处理工厂测试模式


接下来 从bootloader 开始入手 分析源码


bootloader/u-boot15/common/loader/boot\_mode.c  
 boot\_mode.c 里面详细介绍了各种启动模式如下:



```
void normal_mode(void)
{
#ifndef CONFIG\_ZEBU
	vibrator_hw_init();

	set_vibrator(1);
	vlx_nand_boot(BOOT_PART, BACKLIGHT_ON, LCD_ON);
#else
	vlx_nand_boot_zebu(BOOT_PART, BACKLIGHT_ON, LCD_ON);
#endif
	return;
}

void calibration_mode(void)
{
	debugf("calibration\_mode\n");

	setenv("bootmode", "cali");
#ifdef CONFIG\_CALIMODE\_USE\_BOOTIMG
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_OFF);
#else
	vlx_nand_boot(RECOVERY_PART, BACKLIGHT_OFF, LCD_OFF);
#endif
	return;
}

void autotest_mode(void)
{
	debugf("sprd aadd CHGR\_CTRL closed charge start\n");
	ANA_REG_MSK_OR(ANA_REG_GLB_CHGR_CTRL, BIT_CHGR_PD,BIT_CHGR_PD);
	debugf("autotest\_mode\n");

	setenv("bootmode", "autotest");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;
}

void recovery_mode(void)
{
    debugf("recovery\_mode\n");
    setenv("bootmode", "recovery");
    vlx_nand_boot(RECOVERY_PART, BACKLIGHT_ON, LCD_ON);
    return;

}


void special_mode(void)
{
	debugf("special\_mode\n");

	setenv("bootmode", "special");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;
}

void iq_mode(void)
{
	debugf("iq\_mode\n");
	setenv("bootmode", "iq");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;

}

void watchdog_mode(void)
{
	debugf("watchdog\_mode\n");
	setenv("bootmode", "wdgreboot");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;

}

void ap_watchdog_mode(void)
{
	debugf("ap\_watchdog\_mode\n");
	setenv("bootmode", "apwdgreboot");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;

}

void unknow_reboot_mode(void)
{
	debugf("unknow\_reboot\_mode\n");
	setenv("bootmode", "unknowreboot");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;

}

void panic_reboot_mode(void)
{
	debugf("enter\n");
	setenv("bootmode", "panic");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);
	return;

}

void fastboot_mode(void)
{
	debugf("enter\n");
#ifdef CONFIG\_SPLASH\_SCREEN
extern int drv_lcd_init (void);
	debug("[LCD] Drawing the logo...\n");
	drv_lcd_init();
	lcd_splash(LOGO_PART);
	lcd_enable();

	vibrator_hw_init();
	set_vibrator(1);

	extern void set_backlight(uint32_t value);
	fastboot_lcd_printf();
	set_backlight(BACKLIGHT_ON);
	mdelay(400);
	set_vibrator(0);
#endif
	//MMU_DisableIDCM();
#if (defined CONFIG\_X86) && (defined CONFIG\_MOBILEVISOR) && (defined CONFIG\_SPRD\_SOC\_SP9853I)
	tos_start_notify();
#endif
#ifdef CONFIG\_SECBOOT
	if (get_lock_status() == VBOOT_STATUS_UNLOCK){
		debugf("INFO: LOCK FLAG IS : UNLOCK!!!\n");
		lcd_printf("\n INFO: LOCK FLAG IS : UNLOCK!!!\n");
	}
	get_secboot_base_from_dt();
#endif

	do_fastboot();

	return;
}

#ifdef CONFIG\_ERASE\_SPL\_AUTO\_DOWNLOAD
/**
 * If the SPL is erased, the romcode will enter the download process.
 * Notice: SPL must download.
 */
int erase_spl_enter_download_mode(void)
{
	if (0 != common_raw_erase("splloader", (uint64_t)0, (uint64_t)0)) {
		debugf("erase partition splloader fail!\n");
		return -1;
	} else {
		if (0 != common_raw_erase("splloader\_bak", (uint64_t)0, (uint64_t)0)) {
			debugf("erase partition splloader\_bak fail!\n");
			return -2;
		} else {
			debugf("erase partition splloader and splloader\_bak ok\n");
			reset_to_normal(CMD_NORMAL_MODE);
			while(1);
		}
	}

	return 0;
}
#endif

void autodloader_mode(void)
{
	debugf("Enter autodloader mode\n");

#ifdef CONFIG\_ERASE\_SPL\_AUTO\_DOWNLOAD
	if (0 != erase_spl_enter_download_mode()) {
		debugf("erase partition splloader and splloader\_bak fail!\n");
		debugf("enter old autodloader\_mode!\n");
	}
#endif

#if (defined CONFIG\_X86) && (defined CONFIG\_MOBILEVISOR) && (defined CONFIG\_SPRD\_SOC\_SP9853I)
	tos_start_notify();
#endif

#ifdef CONFIG\_SECBOOT
	get_secboot_base_from_dt();
#endif
	/* remap iram */
	//autodlader_remap();
	/* main handler receive and jump */
	autodloader_mainhandler();

	/*reach here means error happened*/
	return;
}

void charge_mode(void)
{
	debugf("enter\n");

	g_charger_mode = 1;
	setenv("bootmode", "charger");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_ON, LCD_ON);

}

void engtest_mode(void)
{
	printf("enter\n");
	setenv("bootmode", "engtest");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);

}


void alarm_mode(void)
{
	debugf("enter\n");
	setenv("bootmode", "alarm");
	vlx_nand_boot(BOOT_PART, BACKLIGHT_OFF, LCD_ON);

}

void factorytest_mode(void)
{
    debugf("factorytest enter\n");
    setenv("bootmode", "factorytest");
#ifdef CONFIG\_CALIMODE\_USE\_BOOTIMG
	vlx_nand_boot(BOOT_PART, BACKLIGHT_ON, LCD_ON);
#else
	vlx_nand_boot(RECOVERY_PART, BACKLIGHT_ON, LCD_ON);
#endif
    return;
}

```

从上面的源码可以看出 factorytest\_mode 就是工厂测试模式


下面看在哪里注册启动 工厂测试模式  
 我目前的驱动版本是 ums512\_1h10  
 所以在相应的board下找到对应的c文件看下  
 进入 bsp/bootloader/u-boot15/board/spreadtrum/ums512\_1h10/ums512\_1h10.c



```
void board_boot_mode_regist(CBOOT_MODE_ENTRY *array)
{
	MODE_REGIST(CMD_NORMAL_MODE, normal_mode);
	MODE_REGIST(CMD_RECOVERY_MODE, recovery_mode);
	MODE_REGIST(CMD_FASTBOOT_MODE, fastboot_mode);
	MODE_REGIST(CMD_WATCHDOG_REBOOT, watchdog_mode);
	MODE_REGIST(CMD_AP_WATCHDOG_REBOOT, ap_watchdog_mode);
	MODE_REGIST(CMD_UNKNOW_REBOOT_MODE, unknow_reboot_mode);
	MODE_REGIST(CMD_PANIC_REBOOT, panic_reboot_mode);
	MODE_REGIST(CMD_AUTODLOADER_REBOOT, autodloader_mode);
	MODE_REGIST(CMD_SPECIAL_MODE, special_mode);
	MODE_REGIST(CMD_CHARGE_MODE, charge_mode);
	MODE_REGIST(CMD_ENGTEST_MODE,engtest_mode);
	MODE_REGIST(CMD_FACTORYTEST_MODE, factorytest_mode);
	MODE_REGIST(CMD_CALIBRATION_MODE, calibration_mode);
	MODE_REGIST(CMD_EXT_RSTN_REBOOT_MODE, normal_mode);
	MODE_REGIST(CMD_IQ_REBOOT_MODE, iq_mode);
	MODE_REGIST(CMD_ALARM_MODE, alarm_mode);
	MODE_REGIST(CMD_SPRDISK_MODE, sprdisk_mode);
	MODE_REGIST(CMD_AUTOTEST_MODE, autotest_mode);
	MODE_REGIST(CMD_APKMMI_MODE, apkmmi_mode);
	MODE_REGIST(CMD_UPT_MODE, upt_mode);
	return ;
}

```

board\_boot\_mode\_regist 在这里注册各种启动模式，然后根据启动模式 调用对应的代码


所以去掉工厂模式 只需要将注册的工厂模式 改成 正常启动模式即可


具体实现如下:



```
diff --git a/bsp/bootloader/u-boot15/board/spreadtrum/ums512_1h10/ums512_1h10.c b/bsp/bootloader/u-boot15/board/spreadtrum/ums512_1h10/ums512_1h10.c
index 615c2d0ee6..f6704f38b7 100755
--- a/bsp/bootloader/u-boot15/board/spreadtrum/ums512_1h10/ums512_1h10.c
+++ b/bsp/bootloader/u-boot15/board/spreadtrum/ums512_1h10/ums512_1h10.c
@@ -196,7 +196,7 @@ void board_boot_mode_regist(CBOOT_MODE_ENTRY *array)
        MODE_REGIST(CMD_SPECIAL_MODE, special_mode);
        MODE_REGIST(CMD_CHARGE_MODE, charge_mode);
        MODE_REGIST(CMD_ENGTEST_MODE,engtest_mode);
-       MODE_REGIST(CMD_FACTORYTEST_MODE, factorytest_mode);
+       MODE_REGIST(CMD_FACTORYTEST_MODE, normal_mode);
        MODE_REGIST(CMD_CALIBRATION_MODE, calibration_mode);
        MODE_REGIST(CMD_EXT_RSTN_REBOOT_MODE, normal_mode);
        MODE_REGIST(CMD_IQ_REBOOT_MODE, iq_mode);

```




