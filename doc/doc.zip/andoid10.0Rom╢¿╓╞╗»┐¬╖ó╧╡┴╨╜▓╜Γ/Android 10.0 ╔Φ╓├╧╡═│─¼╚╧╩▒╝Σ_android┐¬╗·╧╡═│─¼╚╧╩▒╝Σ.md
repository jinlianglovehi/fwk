






### 1.概述


在android 系统默认的时间为86400000ms时间为1970年 01月 02日，但是显得系统默认时间太早了，  
 客户要求系统默认时间改为2022年01月01日，所以系统时间要改为1640966400000ms，来实现系统默认时间功能实现


### 2.设置系统默认时间的核心代码



```
frameworks/base/services/java/com/android/server/SystemServer.java

```

### 3.设置系统默认时间的核心代码核心功能分析和实现


对于系统默认时间通过代码查看发现是在SystemServer.java中在systemserver进程启动的时候就设置了系统时间所以修改默认时间也是在这里修改  
 现在就来看如何修改默认时间了  
 先看SystemServer.java的源码 默认时间修改从这里开始  
 路径：frameworks/base/services/java/com/android/server/SystemServer.java



```
// The earliest supported time.  We pick one day into 1970, to
// give any timezone code room without going into negative time.
private static final long EARLIEST_SUPPORTED_TIME = 86400000L;//19700102 00:00:00
EARLIEST_SUPPORTED_TIME 变量就是系统默认时间
所以修改为
private static final long EARLIEST_SUPPORTED_TIME = 1640966400000L;//20220101 00:00:00
private void run() {
          try {
              traceBeginAndSlog("InitBeforeStartServices");
  
              // Record the process start information in sys props.
              SystemProperties.set(SYSPROP_START_COUNT, String.valueOf(mStartCount));
              SystemProperties.set(SYSPROP_START_ELAPSED, String.valueOf(mRuntimeStartElapsedTime));
              SystemProperties.set(SYSPROP_START_UPTIME, String.valueOf(mRuntimeStartUptime));
  
              EventLog.writeEvent(EventLogTags.SYSTEM_SERVER_START,
                      mStartCount, mRuntimeStartUptime, mRuntimeStartElapsedTime);
  
              // If a device's clock is before 1970 (before 0), a lot of
 // APIs crash dealing with negative numbers, notably
 // java.io.File#setLastModified, so instead we fake it and
 // hope that time from cell towers or NTP fixes it shortly.
 if (System.currentTimeMillis() < EARLIEST\_SUPPORTED\_TIME) {
 Slog.w(TAG, "System clock is before 1970; setting to 1970.");
 SystemClock.setCurrentTimeMillis(EARLIEST\_SUPPORTED\_TIME);
 }
 
 //
 // Default the timezone property to GMT if not set.
 //
 String timezoneProperty = SystemProperties.get("persist.sys.timezone");
 if (timezoneProperty == null || timezoneProperty.isEmpty()) {
 Slog.w(TAG, "Timezone not set; setting to GMT.");
 SystemProperties.set("persist.sys.timezone", "GMT");
 }
 
 // If the system has "persist.sys.language" and friends set, replace them with
 // "persist.sys.locale". Note that the default locale at this point is calculated
 // using the "-Duser.locale" command line flag. That flag is usually populated by
 // AndroidRuntime using the same set of system properties, but only the system\_server
 // and system apps are allowed to set them.
 //
 // NOTE: Most changes made here will need an equivalent change to
 // core/jni/AndroidRuntime.cpp
 if (!SystemProperties.get("persist.sys.language").isEmpty()) {
 final String languageTag = Locale.getDefault().toLanguageTag();
 
 SystemProperties.set("persist.sys.locale", languageTag);
 SystemProperties.set("persist.sys.language", "");
 SystemProperties.set("persist.sys.country", "");
 SystemProperties.set("persist.sys.localevar", "");
 }
 
 // The system server should never make non-oneway calls
 Binder.setWarnOnBlocking(true);
 // The system server should always load safe labels
 PackageItemInfo.forceSafeLabels();
 
 // Default to FULL within the system server.
 SQLiteGlobal.sDefaultSyncMode = SQLiteGlobal.SYNC\_MODE\_FULL;
 
 // Deactivate SQLiteCompatibilityWalFlags until settings provider is initialized
 SQLiteCompatibilityWalFlags.init(null);
 
 // Here we go!
 Slog.i(TAG, "Entered the Android system server!");
 int uptimeMillis = (int) SystemClock.elapsedRealtime();
 EventLog.writeEvent(EventLogTags.BOOT\_PROGRESS\_SYSTEM\_RUN, uptimeMillis);
 if (!mRuntimeRestart) {
 MetricsLogger.histogram(null, "boot\_system\_server\_init", uptimeMillis);
 }
 
 // In case the runtime switched since last boot (such as when
 // the old runtime was removed in an OTA), set the system
 // property so that it is in sync. We can | xq oqi't do this in
              // libnativehelper's JniInvocation::Init code where we already
 // had to fallback to a different runtime because it is
 // running as root and we need to be the system user to set
 // the property. http://b/11463182
 SystemProperties.set("persist.sys.dalvik.vm.lib.2", VMRuntime.getRuntime().vmLibrary());
 
 // Mmmmmm... more memory!
 VMRuntime.getRuntime().clearGrowthLimit();
 
 // The system server has to run all of the time, so it needs to be
 // as efficient as possible with its memory usage.
 VMRuntime.getRuntime().setTargetHeapUtilization(0.8f);
 
 // Some devices rely on runtime fingerprint generation, so make sure
 // we've defined it before booting further.
              Build.ensureFingerprintProperty();
  
              // Within the system server, it is an error to access Environment paths without
              // explicitly specifying a user.
              Environment.setUserRequired(true);
  
              // Within the system server, any incoming Bundles should be defused
              // to avoid throwing BadParcelableException.
             BaseBundle.setShouldDefuse(true);
  
              // Within the system server, when parceling exceptions, include the stack trace
              Parcel.setStackTraceParceling(true);
  
              // Ensure binder calls into the system always run at foreground priority.
             BinderInternal.disableBackgroundScheduling(true);
  
             // Increase the number of binder threads in system_server
              BinderInternal.setMaxThreads(sMaxBinderThreads);
  
              // Prepare the main looper thread (this thread).
              android.os.Process.setThreadPriority(
                     android.os.Process.THREAD_PRIORITY_FOREGROUND);
              android.os.Process.setCanSelfBackground(false);
              Looper.prepareMainLooper();
             Looper.getMainLooper().setSlowLogThresholdMs(
                      SLOW_DISPATCH_THRESHOLD_MS, SLOW_DELIVERY_THRESHOLD_MS);
  
              // Initialize native services.
             System.loadLibrary("android\_servers");
  
             // Debug builds - allow heap profiling.
              if (Build.IS_DEBUGGABLE) {
                  initZygoteChildHeapProfiling();
             }
 
              // Check whether we failed to shut down last time we tried.
              // This call may not return.
              performPendingShutdown();
 
              // Initialize the system context.
              createSystemContext();
  
              // Create the system service manager.
             mSystemServiceManager = new SystemServiceManager(mSystemContext);
              mSystemServiceManager.setStartInfo(mRuntimeRestart,
                      mRuntimeStartElapsedTime, mRuntimeStartUptime);
             LocalServices.addService(SystemServiceManager.class, mSystemServiceManager);
              // Prepare the thread pool for init tasks that can be parallelized
              SystemServerInitThreadPool.get();
          } finally {
              traceEnd();  // InitBeforeStartServices
          }
  
          // Start services.
          try {
              traceBeginAndSlog("StartServices");
              startBootstrapServices();
              startCoreServices();
              startOtherServices();
              SystemServerInitThreadPool.shutdown();
          } catch (Throwable ex) {
              Slog.e("System", "\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*");
              Slog.e("System", "\*\*\*\*\*\*\*\*\*\*\*\* Failure starting system services", ex);
              throw ex;
          } finally {
              traceEnd();
          }
  
          StrictMode.initVmDefaults(null);
  
          if (!mRuntimeRestart && !isFirstBootOrUpgrade()) {
              int uptimeMillis = (int) SystemClock.elapsedRealtime();
              MetricsLogger.histogram(null, "boot\_system\_server\_ready", uptimeMillis);
              final int MAX_UPTIME_MILLIS = 60 * 1000;
              if (uptimeMillis > MAX_UPTIME_MILLIS) {
                  Slog.wtf(SYSTEM_SERVER_TIMING_TAG,
                          "SystemServer init took too long. uptimeMillis=" + uptimeMillis);
              }
          }
  
          // Diagnostic to ensure that the system is in a base healthy state. Done here as a common
          // non-zygote process.
          if (!VMRuntime.hasBootImageSpaces()) {
              Slog.wtf(TAG, "Runtime is not running with a boot image!");
          }
  
          // Loop forever.
          Looper.loop();
          throw new RuntimeException("Main thread loop unexpectedly exited");
      }

```

看源码中可以看到 在run()中设置默认时间SystemClock.setCurrentTimeMillis(EARLIEST\_SUPPORTED\_TIME);  
 设置当前的时间为EARLIEST\_SUPPORTED\_TIME，每个平台不同设置的地方不同  
 但是有些平台设置无效果 最好是在startOtherServices()之后 设置时间为需要修改的默认时间为1640966400000L  
 就是2022年01月01日的时间


具体修改为:



```
private void run() {
          try {
              traceBeginAndSlog("InitBeforeStartServices");
  
              // Record the process start information in sys props.
              SystemProperties.set(SYSPROP_START_COUNT, String.valueOf(mStartCount));
              SystemProperties.set(SYSPROP_START_ELAPSED, String.valueOf(mRuntimeStartElapsedTime));
              SystemProperties.set(SYSPROP_START_UPTIME, String.valueOf(mRuntimeStartUptime));
  
              EventLog.writeEvent(EventLogTags.SYSTEM_SERVER_START,
                      mStartCount, mRuntimeStartUptime, mRuntimeStartElapsedTime);
  
              // If a device's clock is before 1970 (before 0), a lot of
 // APIs crash dealing with negative numbers, notably
 // java.io.File#setLastModified, so instead we fake it and
 // hope that time from cell towers or NTP fixes it shortly.
 - if (System.currentTimeMillis() < EARLIEST\_SUPPORTED\_TIME) {
 - Slog.w(TAG, "System clock is before 1970; setting to 1970.");
 - SystemClock.setCurrentTimeMillis(EARLIEST\_SUPPORTED\_TIME);
 - }
 
 //
 // Default the timezone property to GMT if not set.
 //
 String timezoneProperty = SystemProperties.get("persist.sys.timezone");
 if (timezoneProperty == null || timezoneProperty.isEmpty()) {
 Slog.w(TAG, "Timezone not set; setting to GMT.");
 SystemProperties.set("persist.sys.timezone", "GMT");
 }
 
 // If the system has "persist.sys.language" and friends set, replace them with
 // "persist.sys.locale". Note that the default locale at this point is calculated
 // using the "-Duser.locale" command line flag. That flag is usually populated by
 // AndroidRuntime using the same set of system properties, but only the system\_server
 // and system apps are allowed to set them.
 //
 // NOTE: Most changes made here will need an equivalent change to
 // core/jni/AndroidRuntime.cpp
 if (!SystemProperties.get("persist.sys.language").isEmpty()) {
 final String languageTag = Locale.getDefault().toLanguageTag();
 
 SystemProperties.set("persist.sys.locale", languageTag);
 SystemProperties.set("persist.sys.language", "");
 SystemProperties.set("persist.sys.country", "");
 SystemProperties.set("persist.sys.localevar", "");
 }
 
 // The system server should never make non-oneway calls
 Binder.setWarnOnBlocking(true);
 // The system server should always load safe labels
 PackageItemInfo.forceSafeLabels();
 
 // Default to FULL within the system server.
 SQLiteGlobal.sDefaultSyncMode = SQLiteGlobal.SYNC\_MODE\_FULL;
 
 // Deactivate SQLiteCompatibilityWalFlags until settings provider is initialized
 SQLiteCompatibilityWalFlags.init(null);
 
 // Here we go!
 Slog.i(TAG, "Entered the Android system server!");
 int uptimeMillis = (int) SystemClock.elapsedRealtime();
 EventLog.writeEvent(EventLogTags.BOOT\_PROGRESS\_SYSTEM\_RUN, uptimeMillis);
 if (!mRuntimeRestart) {
 MetricsLogger.histogram(null, "boot\_system\_server\_init", uptimeMillis);
 }
 
 // In case the runtime switched since last boot (such as when
 // the old runtime was removed in an OTA), set the system
 // property so that it is in sync. We can | xq oqi't do this in
              // libnativehelper's JniInvocation::Init code where we already
 // had to fallback to a different runtime because it is
 // running as root and we need to be the system user to set
 // the property. http://b/11463182
 SystemProperties.set("persist.sys.dalvik.vm.lib.2", VMRuntime.getRuntime().vmLibrary());
 
 // Mmmmmm... more memory!
 VMRuntime.getRuntime().clearGrowthLimit();
 
 // The system server has to run all of the time, so it needs to be
 // as efficient as possible with its memory usage.
 VMRuntime.getRuntime().setTargetHeapUtilization(0.8f);
 
 // Some devices rely on runtime fingerprint generation, so make sure
 // we've defined it before booting further.
              Build.ensureFingerprintProperty();
  
              // Within the system server, it is an error to access Environment paths without
              // explicitly specifying a user.
              Environment.setUserRequired(true);
  
              // Within the system server, any incoming Bundles should be defused
              // to avoid throwing BadParcelableException.
             BaseBundle.setShouldDefuse(true);
  
              // Within the system server, when parceling exceptions, include the stack trace
              Parcel.setStackTraceParceling(true);
  
              // Ensure binder calls into the system always run at foreground priority.
             BinderInternal.disableBackgroundScheduling(true);
  
             // Increase the number of binder threads in system_server
              BinderInternal.setMaxThreads(sMaxBinderThreads);
  
              // Prepare the main looper thread (this thread).
              android.os.Process.setThreadPriority(
                     android.os.Process.THREAD_PRIORITY_FOREGROUND);
              android.os.Process.setCanSelfBackground(false);
              Looper.prepareMainLooper();
             Looper.getMainLooper().setSlowLogThresholdMs(
                      SLOW_DISPATCH_THRESHOLD_MS, SLOW_DELIVERY_THRESHOLD_MS);
  
              // Initialize native services.
             System.loadLibrary("android\_servers");
  
             // Debug builds - allow heap profiling.
              if (Build.IS_DEBUGGABLE) {
                  initZygoteChildHeapProfiling();
             }
 
              // Check whether we failed to shut down last time we tried.
              // This call may not return.
              performPendingShutdown();
 
              // Initialize the system context.
              createSystemContext();
  
              // Create the system service manager.
             mSystemServiceManager = new SystemServiceManager(mSystemContext);
              mSystemServiceManager.setStartInfo(mRuntimeRestart,
                      mRuntimeStartElapsedTime, mRuntimeStartUptime);
             LocalServices.addService(SystemServiceManager.class, mSystemServiceManager);
              // Prepare the thread pool for init tasks that can be parallelized
              SystemServerInitThreadPool.get();
          } finally {
              traceEnd();  // InitBeforeStartServices
          }
  
          // Start services.
          try {
              traceBeginAndSlog("StartServices");
              startBootstrapServices();
              startCoreServices();
              startOtherServices();
            +   if (System.currentTimeMillis() < EARLIEST_SUPPORTED_TIME) {
            +      Slog.w(TAG, "System clock is before 2022; setting to 2022.");
            +      SystemClock.setCurrentTimeMillis(EARLIEST_SUPPORTED_TIME);
            +  }
              SystemServerInitThreadPool.shutdown();
          } catch (Throwable ex) {
              Slog.e("System", "\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*");
              Slog.e("System", "\*\*\*\*\*\*\*\*\*\*\*\* Failure starting system services", ex);
              throw ex;
          } finally {
              traceEnd();
          }
  
          StrictMode.initVmDefaults(null);
  
          if (!mRuntimeRestart && !isFirstBootOrUpgrade()) {
              int uptimeMillis = (int) SystemClock.elapsedRealtime();
              MetricsLogger.histogram(null, "boot\_system\_server\_ready", uptimeMillis);
              final int MAX_UPTIME_MILLIS = 60 * 1000;
              if (uptimeMillis > MAX_UPTIME_MILLIS) {
                  Slog.wtf(SYSTEM_SERVER_TIMING_TAG,
                          "SystemServer init took too long. uptimeMillis=" + uptimeMillis);
              }
          }
  
          // Diagnostic to ensure that the system is in a base healthy state. Done here as a common
          // non-zygote process.
          if (!VMRuntime.hasBootImageSpaces()) {
              Slog.wtf(TAG, "Runtime is not running with a boot image!");
          }
  
          // Loop forever.
          Looper.loop();
          throw new RuntimeException("Main thread loop unexpectedly exited");
      }

```

经过编译验证 发现默认时间已经修改成功了





