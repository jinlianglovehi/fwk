



## 1.前言


  
  在10.0的系统产品定制化开发过程中，在对于wifi扫描二维码的时候，可以看到相关的wifi信息，在竖屏的情况下 不会有什么问题，但是如何  
 在系统settings横屏的情况下 扫描wifi的二维码的时候，发现识别不了，接下来就来分析下相关的wifi扫描相关流程，看如何实现相关功能


## 2.系统Settings横屏状态下wifi扫码不能识别功能修复的核心类



```
packages\apps\Settings\src\com\android\settings\wifi\qrcode\QrCamera.java
packages\apps\Settings\src\com\android\settings\wifi\dpp\WifiDppQrCodeScannerFragment.java
```

## 3.系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能分析和实现


在系统Settings的模块中，在用wifi扫码识别功能中，通过分析相关settings源码，在通过核心关键字搜索，查询相关源码分析，最后  
 发现在扫码wifi二维码的类就是在WifiDppQrCodeScannerFragment.java中进行的处理扫码二维码功能，在这个WifiDppQrCodeScannerFragment.java  
 类中同时也是调用QrCamera.java的类中相关的扫描方法来具体识别二维码功能的操作，接下来首选看下  
 WifiDppQrCodeScannerFragment.java中相关的扫描wifi二维码的相关操作


## 3.1 WifiDppQrCodeScannerFragment.java中相关的扫描二维码操作


 在系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能中，通过上面的分析就可以了解到了  
 在WifiDppQrCodeScannerFragment.java中相关的扫描wifi二维码的功能实现，接下来分析下看是  
 怎么样调用QrCamera.java的类中相关的扫描方法来具体识别二维码功能的操作的相关源码



```
   @Override
    public final View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        return inflater.inflate(R.layout.wifi_dpp_qrcode_scanner_fragment, container,
                /* attachToRoot */ false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mTextureView = (TextureView) view.findViewById(R.id.preview_view);
        mTextureView.setSurfaceTextureListener(this);

        mDecorateView = (QrDecorateView) view.findViewById(R.id.decorate_view);

        setHeaderIconImageResource(R.drawable.ic_scan_24dp);

        mProgressBar = view.findViewById(R.id.indeterminate_bar);
        mProgressBar.setVisibility(isGoingInitiator() ? View.VISIBLE : View.INVISIBLE);

        if (mIsConfiguratorMode) {
            mTitle.setText(R.string.wifi_dpp_add_device_to_network);

            WifiNetworkConfig wifiNetworkConfig = ((WifiNetworkConfig.Retriever) getActivity())
                .getWifiNetworkConfig();
            if (!WifiNetworkConfig.isValidConfig(wifiNetworkConfig)) {
                throw new IllegalStateException("Invalid Wi-Fi network for configuring");
            }
            mSummary.setText(getString(R.string.wifi_dpp_center_qr_code,
                    wifiNetworkConfig.getSsid()));
        } else {
            mTitle.setText(R.string.wifi_dpp_scan_qr_code);

            updateEnrolleeSummary();
        }

        mErrorMessage = view.findViewById(R.id.error_message);
    }
```

 在系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能中，通过上面的分析就可以了解到  
 在onCreateView方法和onViewCreated(View view, Bundle savedInstanceState)主要就是构建  
 扫描wifi二维码的界面布局，接下来看关于调用QrCamera.java的类中相关的扫描方法来具体识别二维码功能的操作的相关源码



```
  @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
        initCamera(surface);
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        // Do nothing
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
        destroyCamera();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        // Do nothing
    }

    private void initCamera(SurfaceTexture surface) {
        // Check if the camera has already created.
        if (mCamera == null) {
            mCamera = new QrCamera(getContext(), this);

            if (isGoingInitiator()) {
                if (mDecorateView != null) {
                    mDecorateView.setFocused(true);
                }
            } else {
                mCamera.start(surface);
            }
        }
    }
```

在系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能中，通过上面的分析就可以了解到  
 在WifiDppQrCodeScannerFragment.java中的相关源码中，在调用扫描二维码摄像头关于摄像的核心  
 方法中onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height)调用  
 initCamera(SurfaceTexture surface)来进行扫描识别二维码，而在initCamera(SurfaceTexture surface)中  
 主要是调用QrCamera.java的类中的start(surface);来进行识别二维码了，接下来分析下相关源码


## 3.2 QrCamera.java的类中扫描二维码相关功能分析


在系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能中，通过上面的分析就可以了解到  
 QrCamera.java的类中相关的扫描方法来具体识别二维码功能的操作，接下来分析下QrCamera.java的类中相关的扫描方法



```
    public void start(SurfaceTexture surface) {
        if (mDecodeTask == null) {
            mDecodeTask = new DecodingTask(surface);
            // Execute in the separate thread pool to prevent block other AsyncTask.
            mDecodeTask.executeOnExecutor(Executors.newSingleThreadExecutor());
        }
    }
    private class DecodingTask extends AsyncTask<Void, Void, String> {
        private QrYuvLuminanceSource mImage;
        private SurfaceTexture mSurface;

        private DecodingTask(SurfaceTexture surface) {
            mSurface = surface;
        }

        @Override
        protected String doInBackground(Void... tmp) {
            if (!initCamera(mSurface)) {
                return null;
            }

            final Semaphore imageGot = new Semaphore(0);
            while (true) {
                // This loop will try to capture preview image continuously until a valid QR Code
                // decoded. The caller can also call {@link #stop()} to interrupts scanning loop.
                mCamera.setOneShotPreviewCallback(
                        (imageData, camera) -> {
                            mImage = getFrameImage(imageData);
                            imageGot.release();
                        });
                try {
                    // Semaphore.acquire() blocking until permit is available, or the thread is
                    // interrupted.
                    imageGot.acquire();
                    Result qrCode = null;
                    try {
                        qrCode =
                                mReader.decodeWithState(
                                        new BinaryBitmap(new HybridBinarizer(mImage)));
                    } catch (ReaderException e) {
                        // No logging since every time the reader cannot decode the
                        // image, this ReaderException will be thrown.
                    } finally {
                        mReader.reset();
                    }
                    if (qrCode != null) {
                        if (mScannerCallback.isValid(qrCode.getText())) {
                            return qrCode.getText();
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
        }
    private QrYuvLuminanceSource getFrameImage(byte[] imageData) {
        final Rect frame = mScannerCallback.getFramePosition(mPreviewSize, mCameraOrientation);
  -      final QrYuvLuminanceSource image = new QrYuvLuminanceSource(imageData,
 +      final QrYuvLuminanceSource image = new QrYuvLuminanceSource(rotateByte(imageData),
                mPreviewSize.getWidth(), mPreviewSize.getHeight());
        return (QrYuvLuminanceSource)
                image.crop(frame.left, frame.top, frame.width(), frame.height());
    }
```

 在系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能中，通过上面的分析就可以了解到  
 在QrCamera.java中的相关源码中，在调用start(SurfaceTexture surface)中扫描二维码的过程中，核心内容就是  
 调用DecodingTask内部类进行识别，关于采集数据就是在getFrameImage(byte[] imageData) 中  
 所以就是在这里来扫描识别二维码的，具体需要添加以下兼容横屏识别二维码的操作



```
   private byte[] rotateByte(byte[] data) {
        final int rotation = mWindowManager.getDefaultDisplay().getRotation();
        if (rotation== Surface.ROTATION_180 || rotation == Surface.ROTATION_270){
            return rotateYUV420Landscape(data,mPreviewSize.getWidth(),mPreviewSize.getHeight());
        }
        return data;
    }
    private byte[] rotateYUV420Landscape(byte[] data, int width, int height) {
        byte[] yuv = new byte[width * height * 3 / 2];
        int i;
        int count = 0;
        for (i = width * height - 1; i >= 0; i--) {
            yuv[count] = data[i];
            count++;
        }
        for (i = width * height * 3 / 2 - 1; i >= width
                *height; i -= 2) {
            yuv[count++] = data[i - 1];
            yuv[count++] = data[i];
        }
        return yuv;
    }
```

 在系统Settings横屏状态下wifi扫码不能识别功能修复的核心功能中，通过上面的分析就可以了解到  
 在QrCamera.java中的相关源码中，在getFrameImage(byte[] imageData)关于识别二维码数据中  
 做横竖屏旋转的适配来完成相关wifi二维码识别的功能



