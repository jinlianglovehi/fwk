






改变系统字体大小



```
/**
 * @see
 * @param size
 */
public void setFontSize(int size) {
    float value = 1.0f;
    if (0 == size) {
        value = 0.85f;
    } else if (1 == size) {
        value = 1.0f;
    } else if (2 == size) {
        value = 1.15f;
    } else if (3 == size) {
        value = 1.30f;
    } else {
        value = 1.0f;
    }
    Settings.System.putFloat(mContext.getContentResolver(), Settings.System.FONT_SCALE, value);
}

/**
 * @see
 * @return
 */
public int getFontSize() {
    int value = 0;
    float f = Settings.System.getFloat(mContext.getContentResolver(), Settings.System.FONT_SCALE, 1.0f);
    if (f == 1.0f) {
        value = 1;
    } else if (f == 0.85f) {
        value = 0;
    } else if (f == 1.15f) {
        value = 2;
    } else if (f == 1.30f) {
        value = 3;
    }
    return value;
}

```

改变density



```
/**
 * @see
 * @param size
 */
public void setDisplaySize(int size) {
    //Configuration origConfig = mContext.getResources().getConfiguration();
    int densityDpi = 320;
    switch (size) {
        case 0:
            densityDpi = 120;
            break;
        case 1:
            densityDpi = 160;
            break;
        case 2:
            densityDpi = 240;
            break;
        case 3:
            densityDpi = 320;
            break;
        case 4:
            densityDpi = 480;
            break;
    }
    //mContext.getResources().updateConfiguration(origConfig, mContext.getResources().getDisplayMetrics());
    execShell("wm density " + densityDpi);
}



/**
 * @see
 * @return
 */
public int getDisplaySize() {
    Configuration origConfig = mContext.getResources().getConfiguration();
    int densityDpi = origConfig.densityDpi;
    int displaysize = 0;
    switch (densityDpi) {
        case 120:
            displaysize = 0;
            break;
        case 160:
            displaysize = 1;
            break;
        case 240:
            displaysize = 2;
            break;
        case 320:
            displaysize = 3;
            break;
        case 480:
            displaysize = 4;
            break;
    }
    return displaysize;
}

/**
 *
 * @param cmd
 * @see
 */
public void execShell(String cmd) {
    Process pro = null;
    try {
        pro = Runtime.getRuntime().exec(cmd);
        pro.waitFor();
        int value = pro.exitValue();
        Log.e(TAG, "value:" + value);
    } catch (Throwable t) {
        t.printStackTrace();
    } finally {
        pro.destroy();
    }
}

```

2.app需要系统签名 android:sharedUserId=“android.uid.system”



```
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.arc.funcation"
    android:sharedUserId="android.uid.system">

```




