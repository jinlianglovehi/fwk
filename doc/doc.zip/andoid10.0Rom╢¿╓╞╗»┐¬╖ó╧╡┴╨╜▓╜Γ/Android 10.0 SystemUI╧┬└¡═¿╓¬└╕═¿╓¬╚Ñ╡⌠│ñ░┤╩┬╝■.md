



## 1.前言


在10.0的系统产品开发中，在systemui模块中关于下拉状态栏这块也是非常重要的部分，最近在关于systemui下拉通知栏的每条通知部分 要求去掉通知栏通知的长按事件，不需要长按功能，所以就需要分析下关于长按事件是在哪里注册的，然后去掉就可以了，接下来分析实现 相关功能


## 2.SystemUI下拉通知栏通知去掉长按事件的核心类



```
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\notification\row\ExpandableNotificationRowController.java
```

## 3.SystemUI下拉通知栏通知去掉长按事件的核心功能分析和实现


在android系统中，Android应用在发送通知的流程中，都需要先用Notification.Builder来构建一个通知，然后NotificationManager.notify() 来将这个通知发送出来。发送出来的通知Notification将通过Binder通信， 在框架中被处理后，封装成StatusBarNotification，传递到systemUI系统应用中，在通知栏中呈现出ExpandableNotificationRow， 所以说在系统systemui的下拉状态栏的通知栏中，关于构建通知的核心类就是在ExpandableNotificationRow.java中负责 构建的通知布局


## 3.1 ExpandableNotificationRowController.java相关通知源码分析


SystemUI中NotificationListenerService的实现类是NotificationListener，所以通知会先到达NotificationListenerNotificationListener获取到通知后， 会将通知分发给NotificationHandler，哪个功能模块需要收取通知就可以实现一个NotificationHandler并注册到NotificationListenerNotificationEntryManager收取到通知， 根据key判断是更新通知还是添加通知，先保存到mPendingNotifications如果是添加通知，使用AsyncLayoutInflater异步加载通知布局， 加载完后将ExpandableNotificationRow回调获取到row之后首先绑定到各种控制器和管理器， 而在ExpandableNotificationRowController.java中的相关源码中是关于ExpandableNotificationRow下拉通知栏通知的相关控制类的 管理，所以说现在就来具体分析下关于下拉通知栏通知的相关长按事件相关功能分析



```
 @Inject
    public ExpandableNotificationRowController(ExpandableNotificationRow view,
            ActivatableNotificationViewController activatableNotificationViewController,
            NotificationMediaManager mediaManager, PluginManager pluginManager,
            SystemClock clock, @AppName String appName, @NotificationKey String notificationKey,
            KeyguardBypassController keyguardBypassController,
            NotificationGroupManager notificationGroupManager,
            RowContentBindStage rowContentBindStage,
            NotificationLogger notificationLogger, HeadsUpManager headsUpManager,
            ExpandableNotificationRow.OnExpandClickListener onExpandClickListener,
            StatusBarStateController statusBarStateController,
            NotificationGutsManager notificationGutsManager,
            @Named(ALLOW_NOTIFICATION_LONG_PRESS_NAME) boolean allowLongPress,
            @DismissRunnable Runnable onDismissRunnable, FalsingManager falsingManager,
            PeopleNotificationIdentifier peopleNotificationIdentifier) {
        mView = view;
        mActivatableNotificationViewController = activatableNotificationViewController;
        mMediaManager = mediaManager;
        mPluginManager = pluginManager;
        mClock = clock;
        mAppName = appName;
        mNotificationKey = notificationKey;
        mKeyguardBypassController = keyguardBypassController;
        mNotificationGroupManager = notificationGroupManager;
        mRowContentBindStage = rowContentBindStage;
        mNotificationLogger = notificationLogger;
        mHeadsUpManager = headsUpManager;
        mOnExpandClickListener = onExpandClickListener;
        mStatusBarStateController = statusBarStateController;
        mNotificationGutsManager = notificationGutsManager;
        mOnDismissRunnable = onDismissRunnable;
        mOnAppOpsClickListener = mNotificationGutsManager::openGuts;
        mAllowLongPress = allowLongPress;
        mFalsingManager = falsingManager;
        mPeopleNotificationIdentifier = peopleNotificationIdentifier;
    }

    /**
     * Initialize the controller.
     */
    public void init() {
        mActivatableNotificationViewController.init();
        mView.initialize(
                mAppName,
                mNotificationKey,
                mExpansionLogger,
                mKeyguardBypassController,
                mNotificationGroupManager,
                mHeadsUpManager,
                mRowContentBindStage,
                mOnExpandClickListener,
                mMediaManager,
                mOnAppOpsClickListener,
                mFalsingManager,
                mStatusBarStateController,
                mPeopleNotificationIdentifier
        );
        mView.setOnDismissRunnable(mOnDismissRunnable);
        mView.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (mAllowLongPress) {
            mView.setLongPressListener((v, x, y, item) -> {
                if (mView.isSummaryWithChildren()) {
                    mView.expandNotification();
                    return true;
                }
                return mNotificationGutsManager.openGuts(v, x, y, item);
            });
        }
        if (ENABLE_REMOTE_INPUT) {
            mView.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        }

        mView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                mView.getEntry().setInitializationTime(mClock.elapsedRealtime());
                mPluginManager.addPluginListener(mView,
                        NotificationMenuRowPlugin.class, false /* Allow multiple */);
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                mPluginManager.removePluginListener(mView);
            }
        });
    }
```

在SystemUI下拉通知栏通知去掉长按事件的核心功能实现中，在上述的ExpandableNotificationRowController.java相关源码分析 中得知，在这里ExpandableNotificationRowController的构造方法中，在这里就是初始化配置相关ExpandableNotificationRow的 参数配置，而在ExpandableNotificationRow view就是相关通知的相关配置，所以说在init()方法中，就是 相关初始化ExpandableNotificationRow的相关布局配置，在mView.setLongPressListener这个事件中，就是配置相关 长按事件的回调事件，从这个事件中分析得知，主要处理展开通知的部分就是在mNotificationGutsManager.openGuts(v, x, y, item) 这个方法中，所以接下来看下openGuts(v, x, y, item)中的相关源码分析


## 3.2 NotificationGutsManager相关源码分析


在系统systemui的相关功能模块中，关于NotificationGutsManager的相关通知的管理，就是关于NotificationGuts长按 通知布局的管理，所以说在长按通知的时候，就会调用NotificationGutsManager的openGuts(v, x, y, item)中的相关源码 来构建布局，接下来具体看下相关源码



```
 public boolean openGuts(
            View view,
            int x,
            int y,
            NotificationMenuRowPlugin.MenuItem menuItem) {
//add core start
if(true)return true;

//add core end
        if (menuItem.getGutsView() instanceof NotificationGuts.GutsContent) {
            NotificationGuts.GutsContent gutsView =
                    (NotificationGuts.GutsContent)  menuItem.getGutsView();
            if (gutsView.needsFalsingProtection()) {
                if (mStatusBarStateController instanceof StatusBarStateControllerImpl) {
                    ((StatusBarStateControllerImpl) mStatusBarStateController)
                            .setLeaveOpenOnKeyguardHide(true);
                }

                Runnable r = () -> mMainHandler.post(
                        () -> openGutsInternal(view, x, y, menuItem));

                mStatusBarLazy.get().executeRunnableDismissingKeyguard(
                        r,
                        null /* cancelAction */,
                        false /* dismissShade */,
                        true /* afterKeyguardGone */,
                        true /* deferred */);

                return true;
            }
        }
        return openGutsInternal(view, x, y, menuItem);
    }
```

在SystemUI下拉通知栏通知去掉长按事件的核心功能实现中，在上述的NotificationGutsManager.java相关源码分析 中得知，在openGuts(View view, int x,int y,NotificationMenuRowPlugin.MenuItem menuItem)这个方法中， 负责构建关于长按下拉通知栏通知的布局，所以说如需去掉关于长按下拉通知栏通知弹出相关布局功能，就需要在 这里返回注释掉这个方法的代码 返回true就可以了,添加if(true)return true;就可以实现功能了，或者同时也可以 注释掉上面的ExpandableNotificationRowController的mView.setLongPressListener这个事件中相关方法就 可以了，同样实现功能，上面两种方法都可以实现去掉关于长按下拉通知栏通知弹出相关布局的功能



