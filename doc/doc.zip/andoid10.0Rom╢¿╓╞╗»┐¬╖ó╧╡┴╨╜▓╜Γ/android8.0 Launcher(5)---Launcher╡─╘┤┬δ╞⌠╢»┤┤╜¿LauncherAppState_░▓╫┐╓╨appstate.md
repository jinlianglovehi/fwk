






第一步是创建LauncherAppState，他是一个全局的管理类，初始化一些对象和注册广播，获取硬件设备信息。  
 在Launcher的oncreate方法中是通过


LauncherAppState app = LauncherAppState.getInstance(this);  
 来获得LauncherAppState的实例，从方法名可以看出是采用的单例的模式创建的，顾名思义就是创建且只创建一次对象，于是整个代码的核心是创建对象，我们就来看一下这段代码



```
public static LauncherAppState getInstance(final Context context) {
        if (INSTANCE == null) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                INSTANCE = new LauncherAppState(context.getApplicationContext());
            } else {
                try {
                    return new MainThreadExecutor().submit(new Callable<LauncherAppState>() {
                        @Override
                        public LauncherAppState call() throws Exception {
                            return LauncherAppState.getInstance(context);
                        }
                    }).get();
                } catch (InterruptedException|ExecutionException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return INSTANCE;
    }

```

我们从代码中看到一处写的很严谨的地方就是在创建LauncherAppState的时候传入的Context是通过context.getApplicationContext()，来获取的，而不是传入的Activity，这样一来可以减少内存泄漏。


new LauncherAppState  
 我们来看一些LauncherAppState的构造方法



```
private LauncherAppState(Context context) {
    if (getLocalProvider(context) == null) {
        throw new RuntimeException(
                "Initializing LauncherAppState in the absence of LauncherProvider");
    }
    Log.v(Launcher.TAG, "LauncherAppState initiated");
    Preconditions.assertUIThread();
    mContext = context;

    if (TestingUtils.MEMORY_DUMP_ENABLED) {
        TestingUtils.startTrackingMemory(mContext);
    }

    mInvariantDeviceProfile = new InvariantDeviceProfile(mContext);
    mIconCache = new IconCache(mContext, mInvariantDeviceProfile);
    mWidgetCache = new WidgetPreviewLoader(mContext, mIconCache);
    mModel = new LauncherModel(this, mIconCache, AppFilter.newInstance(mContext));

    LauncherAppsCompat.getInstance(mContext).addOnAppsChangedCallback(mModel);

    // Register intent receivers
    IntentFilter filter = new IntentFilter();
    filter.addAction(Intent.ACTION_LOCALE_CHANGED);
    // For handling managed profiles
    filter.addAction(Intent.ACTION_MANAGED_PROFILE_ADDED);
    filter.addAction(Intent.ACTION_MANAGED_PROFILE_REMOVED);
    filter.addAction(Intent.ACTION_MANAGED_PROFILE_AVAILABLE);
    filter.addAction(Intent.ACTION_MANAGED_PROFILE_UNAVAILABLE);
    filter.addAction(Intent.ACTION_MANAGED_PROFILE_UNLOCKED);
    filter.addAction(OGesturesDataService.ACTION_GESTURE_ASSIGNMENTS_UPDATED);
    // For extracting colors from the wallpaper
    if (Utilities.ATLEAST_NOUGAT) {
        // TODO: add a broadcast entry to the manifest for pre-N.
        filter.addAction(Intent.ACTION_WALLPAPER_CHANGED);
    }

    mContext.registerReceiver(mModel, filter);
    UserManagerCompat.getInstance(mContext).enableAndResetCache();
    new ConfigMonitor(mContext).register();     
}

```

在构造方法中最关键的一点就是创建了InvariantDeviceProfile，这个类就是用来获取设备硬件信息的（下一篇具体详细讲解）。紧接着还创建了InconCache图标管理工具，初始化了Weight加载缓存工具mWidgetCache ，初始化广播接收器LauncherModel，处理数据，最后还注册了广播 mContext.registerReceiver(mModel, filter);那么我们就来一一分析。


创建IconCache  
 mIconDb = new IconDB(context, inv.iconBitmapSize);  
 在IconCache的构造方法中，出了对一些对象的赋值外最重要的一个地方就是创建了IconDB对象，它继承SQLiteCacheHelper，创建IconDB会查询或创建一个名叫“app\_icons.db”的数据库，用于存放图标的数据。



```
创建WidgetPreviewLoader
public WidgetPreviewLoader(Context context, IconCache iconCache) {
    mContext = context;
    mIconCache = iconCache;
    mWidgetManager = AppWidgetManagerCompat.getInstance(context);
    mUserManager = UserManagerCompat.getInstance(context);
    mDb = new CacheDb(context);
    mWorkerHandler = new Handler(LauncherModel.getWorkerLooper());
}

```

这段构造方法中也有基本的赋值，但是最重要的也是创建了一个对象 mDb = new CacheDb(context); 对于CacheDb这个对象也是继承SQLiteCacheHelper。也就是说也创建了一个数据库名字叫：widgetpreviews.db，用来存储weight的一些信息。当我们获取了设备的硬件信息以后，计算出尺寸和规格，然后创建了图标和widget图片的缓存，然后在对应到图标和widget分别对应的数据库。


new LauncherModel(this, mIconCache, AppFilter.newInstance(mContext));  
 接下来就创建最重要的一个类LauncherMode类，所有的App信息都会在这个类里面进行处理，包括Launcher桌面和allapp菜单栏里面的图标和widget的信息等。看一下构造方法先



```
LauncherModel(LauncherAppState app, IconCache iconCache, AppFilter appFilter) {
        mApp = app;
        mBgAllAppsList = new AllAppsList(iconCache, appFilter);
    }

```

这里创建了AllAppsList对象，主要用于存储allApp的信息，以方便LauncherModel后面的使用。


注册广播到LauncherModel  
 好的我们接着回过头来看LauncherAppState的构造方法，早创建完LauncherModel后创建了一个LauncherAppsCompat对象，这个对象是用来兼容不同版本的。这里不多做讲解。  
 紧接着，这里进行了广播的注册



```
 // Register intent receivers
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_LOCALE_CHANGED);
        // For handling managed profiles
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_ADDED);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_REMOVED);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_AVAILABLE);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_UNAVAILABLE);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_UNLOCKED);
        // For extracting colors from the wallpaper
        if (Utilities.ATLEAST_NOUGAT) {
            // TODO: add a broadcast entry to the manifest for pre-N.
            filter.addAction(Intent.ACTION_WALLPAPER_CHANGED);
        }

        mContext.registerReceiver(mModel, filter);

```

这些广播主要是对手机中的应用发生变化时的一个监听。然后在LauncherModel中进行处理。


到这里我们LauncherAppState的构造方法就分析完了。接下来分析在这个构造方法中几个重要的对象。





