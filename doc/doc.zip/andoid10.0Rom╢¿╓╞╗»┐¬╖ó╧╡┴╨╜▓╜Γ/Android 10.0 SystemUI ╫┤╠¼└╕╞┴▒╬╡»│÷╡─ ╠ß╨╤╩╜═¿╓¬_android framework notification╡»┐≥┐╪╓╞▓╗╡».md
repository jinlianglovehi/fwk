






### 1.概述


在11.0SystemUI中 有一种提醒式通知 就是在状态栏 弹出通知后 停留几秒钟后消失 这种通知就是提醒式通知 ，然后在下拉状态栏后可以看到这种通知但是 由于客户需求要求不要弹出这种通知 所以就要求屏蔽掉 接下来就来分析这种通知是如何弹出来的


### 2.SystemUI 状态栏屏蔽弹出的 提醒式通知的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/interruption/HeadsUpController.java
 /frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/HeadsUpManager.java

```

### 3.SystemUI 状态栏屏蔽弹出的 提醒式通知的核心功能实现


关于提醒式弹窗功能，主要是像wifi,闹钟，特殊的通知，通过查看SystemUI的代码，发现 HeadsUpController.java负责显示 悬浮式 提醒式的通知管理  
 首先看下提醒式弹窗的流程


### 3.1HeadsUpController中相关弹窗的源码分析



```
        @Inject
     HeadsUpController(
             HeadsUpViewBinder headsUpViewBinder,
             NotificationInterruptStateProvider notificationInterruptStateProvider,
             HeadsUpManager headsUpManager,
             NotificationRemoteInputManager remoteInputManager,
             StatusBarStateController statusBarStateController,
             VisualStabilityManager visualStabilityManager,
             NotificationListener notificationListener) {
         mHeadsUpViewBinder = headsUpViewBinder;
         mHeadsUpManager = headsUpManager;
         mInterruptStateProvider = notificationInterruptStateProvider;
         mRemoteInputManager = remoteInputManager;
         mStatusBarStateController = statusBarStateController;
         mVisualStabilityManager = visualStabilityManager;
         mNotificationListener = notificationListener;
     }
 
     /**
      * Attach this controller and add its listeners.
      */
     public void attach(
             NotificationEntryManager entryManager,
             HeadsUpManager headsUpManager) {
         entryManager.addCollectionListener(mCollectionListener);
         headsUpManager.addListener(mOnHeadsUpChangedListener);
     }
 
     private NotifCollectionListener mCollectionListener = new NotifCollectionListener() {
         @Override
         public void onEntryAdded(NotificationEntry entry) {
             if (mInterruptStateProvider.shouldHeadsUp(entry)) {
                 mHeadsUpViewBinder.bindHeadsUpView(
                         entry, HeadsUpController.this::showAlertingView);
             }
         }
 
         @Override
         public void onEntryUpdated(NotificationEntry entry) {
             updateHunState(entry);
         }
 
         @Override
         public void onEntryRemoved(NotificationEntry entry, int reason) {
             stopAlerting(entry);
          }
  
          @Override
          public void onEntryCleanUp(NotificationEntry entry) {
              mHeadsUpViewBinder.abortBindCallback(entry);
          }
      };
  
      /**
       * Adds the entry to the HUN manager and show it for the first time.
       */
      private void showAlertingView(NotificationEntry entry) {
          mHeadsUpManager.showNotification(entry);
          if (!mStatusBarStateController.isDozing()) {
              // Mark as seen immediately
              setNotificationShown(entry.getSbn());
          }
      }
  
      private void updateHunState(NotificationEntry entry) {
          boolean hunAgain = alertAgain(entry, entry.getSbn().getNotification());
          // includes check for whether this notification should be filtered:
          boolean shouldHeadsUp = mInterruptStateProvider.shouldHeadsUp(entry);
          final boolean wasHeadsUp = mHeadsUpManager.isAlerting(entry.getKey());
          if (wasHeadsUp) {
              if (shouldHeadsUp) {
                  mHeadsUpManager.updateNotification(entry.getKey(), hunAgain);
              } else if (!mHeadsUpManager.isEntryAutoHeadsUpped(entry.getKey())) {
                  // We don't want this to be interrupting anymore, let's remove it
                  mHeadsUpManager.removeNotification(entry.getKey(), false /* removeImmediately */);
              }
          } else if (shouldHeadsUp && hunAgain) {
              mHeadsUpViewBinder.bindHeadsUpView(entry, mHeadsUpManager::showNotification);
          }
      }
  
      private void setNotificationShown(StatusBarNotification n) {
          try {
              mNotificationListener.setNotificationsShown(new String[]{n.getKey()});
          } catch (RuntimeException e) {
              Log.d(TAG, "failed setNotificationsShown: ", e);
          }
      }

```

在HeadsUpController中的相关代码中showAlertingView(entry, inflatedFlags);负责弹窗弹出通知，mHeadsUpManager.showNotification(entry); 负责显示通知 而  
 HeadUpManager.java 继承AlertingNotificationManager.java 负责构造弹窗  
 接下来看下AlertingNotificationManager.java 的相关源码


### 3.2 AlertingNotificationManager.java 的相关弹窗源码分析



```
public abstract class AlertingNotificationManager implements NotificationLifetimeExtender {
private static final String TAG = "AlertNotifManager";
protected final Clock mClock = new Clock();
protected final ArrayMap<String, AlertEntry> mAlertEntries = new ArrayMap<>();
/*

This is the list of entries that have already been removed from the
NotificationManagerService side, but we keep it to prevent the UI from looking weird and
will remove when possible. See {@link NotificationLifetimeExtender}/
protected final ArraySet<NotificationEntry> mExtendedLifetimeAlertEntries = new ArraySet<>();
protected NotificationSafeToRemoveCallback mNotificationLifetimeFinishedCallback;
protected int mMinimumDisplayTime;
protected int mAutoDismissNotificationDecay;
@VisibleForTesting
public Handler mHandler = new Handler(Looper.getMainLooper());
/*
Called when posting a new notification that should alert the user and appear on screen.
Adds the notification to be managed.
@param entry entry to show/
public void showNotification(@NonNull NotificationEntry entry) {
if (Log.isLoggable(TAG, Log.VERBOSE)) {
Log.v(TAG, "showNotification");
}
addAlertEntry(entry);
updateNotification(entry.key, true / alert */);
entry.setInterruption();
}
。。。
}

public void showNotification(@NonNull NotificationEntry entry) {
if (Log.isLoggable(TAG, Log.VERBOSE)) {
Log.v(TAG, "showNotification");
}
addAlertEntry(entry);
updateNotification(entry.key, true / alert */);
entry.setInterruption();
}

```

在上述的通知弹窗的流程中可以发现由showNotification(@NonNull NotificationEntry entry)来负责弹窗显示通知展示出来悬浮在状态栏 于是注释掉这里关于弹窗的部分代码就可以屏蔽掉通知了  
 修改如下:



```
/**
 * Called when posting a new notification that should alert the user and appear on screen.
 * Adds the notification to be managed.
 * @param entry entry to show
 */
public void showNotification(@NonNull NotificationEntry entry) {
    if (Log.isLoggable(TAG, Log.VERBOSE)) {
        Log.v(TAG, "showNotification");
    }
    //addAlertEntry(entry);
    //updateNotification(entry.key, true /* alert */);
    //entry.setInterruption();
}

```




