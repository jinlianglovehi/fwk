



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.SystemUI手势上滑显示导航栏和隐藏导航栏的核心类](#2.SystemUI%E6%89%8B%E5%8A%BF%E4%B8%8A%E6%BB%91%E6%98%BE%E7%A4%BA%E5%AF%BC%E8%88%AA%E6%A0%8F%E5%92%8C%E9%9A%90%E8%97%8F%E5%AF%BC%E8%88%AA%E6%A0%8F%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.SystemUI手势上滑显示导航栏和隐藏导航栏的核心功能分析和实现](#3.SystemUI%E6%89%8B%E5%8A%BF%E4%B8%8A%E6%BB%91%E6%98%BE%E7%A4%BA%E5%AF%BC%E8%88%AA%E6%A0%8F%E5%92%8C%E9%9A%90%E8%97%8F%E5%AF%BC%E8%88%AA%E6%A0%8F%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0)


[3.1 DisplayPolicy.java关于全局手势事件监听的分析](#3.1%20DisplayPolicy.java%E5%85%B3%E4%BA%8E%E5%85%A8%E5%B1%80%E6%89%8B%E5%8A%BF%E4%BA%8B%E4%BB%B6%E7%9B%91%E5%90%AC%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 StatusBar监听自定义广播然后实现导航栏显示和隐藏功能](#3.2%20StatusBar%E7%9B%91%E5%90%AC%E8%87%AA%E5%AE%9A%E4%B9%89%E5%B9%BF%E6%92%AD%E7%84%B6%E5%90%8E%E5%AE%9E%E7%8E%B0%E5%AF%BC%E8%88%AA%E6%A0%8F%E6%98%BE%E7%A4%BA%E5%92%8C%E9%9A%90%E8%97%8F%E5%8A%9F%E8%83%BD)


[3.3修改隐藏导航栏方法](#3.3%E4%BF%AE%E6%94%B9%E9%9A%90%E8%97%8F%E5%AF%BC%E8%88%AA%E6%A0%8F%E6%96%B9%E6%B3%95)




---



## 1.概述


在10.0的系统产品开发中，由于平板定制化开发过程中，有产品需求要求全屏显示，上滑显示导航栏，然后3秒钟后隐藏导航栏的功能实现，所以需要在SystemUI中来分析实现功能


## 2.SystemUI手势上滑显示导航栏和隐藏导航栏的核心类



```
frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/NavigationBarController.java
```

## 3.SystemUI手势上滑显示导航栏和隐藏导航栏的核心功能分析和实现


### 3.1 DisplayPolicy.java关于全局手势事件监听的分析



```
 mSystemGestures = new SystemGesturesPointerEventListener(mContext, mHandler,
                  new SystemGesturesPointerEventListener.Callbacks() {
                      @Override
                      public void onSwipeFromTop() {
                          if (mStatusBar != null) {
                              requestTransientBars(mStatusBar);
                          }
                      }
  
                      @Override
                      public void onSwipeFromBottom() {
                          if (mNavigationBar != null && mNavigationBarPosition == NAV_BAR_BOTTOM) {
                              requestTransientBars(mNavigationBar);
                          }
                      }
  
                      @Override
                      public void onSwipeFromRight() {
                          final Region excludedRegion;
                          synchronized (mLock) {
                              excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
                          }
                          final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
                                  || mNavigationBarPosition == NAV_BAR_RIGHT;
                          if (mNavigationBar != null && sideAllowed
                                  && !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
                              requestTransientBars(mNavigationBar);
                          }
                      }
  
                      @Override
                      public void onSwipeFromLeft() {
                          final Region excludedRegion;
                          synchronized (mLock) {
                              excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
                          }
                          final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
                                  || mNavigationBarPosition == NAV_BAR_LEFT;
                          if (mNavigationBar != null && sideAllowed
                                  && !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
                              requestTransientBars(mNavigationBar);
                          }
                      }
  
                      @Override
                      public void onFling(int duration) {
                          if (mService.mPowerManagerInternal != null) {
                              mService.mPowerManagerInternal.powerHint(
                                      PowerHint.INTERACTION, duration);
                          }
                      }
  
                      @Override
                      public void onDebug() {
                          // no-op
                      }
  
                      private WindowOrientationListener getOrientationListener() {
                          final DisplayRotation rotation = mDisplayContent.getDisplayRotation();
                          return rotation != null ? rotation.getOrientationListener() : null;
                      }
  
                      @Override
                      public void onDown() {
                          final WindowOrientationListener listener = getOrientationListener();
                          if (listener != null) {
                              listener.onTouchStart();
                          }
                      }
  
                      @Override
                      public void onUpOrCancel() {
                          final WindowOrientationListener listener = getOrientationListener();
                          if (listener != null) {
                              listener.onTouchEnd();
                          }
                      }
  
                      @Override
                      public void onMouseHoverAtTop() {
                          mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
                          Message msg = mHandler.obtainMessage(MSG_REQUEST_TRANSIENT_BARS);
                          msg.arg1 = MSG_REQUEST_TRANSIENT_BARS_ARG_STATUS;
                          mHandler.sendMessageDelayed(msg, 500 /* delayMillis */);
                      }
  
                      @Override
                      public void onMouseHoverAtBottom() {
                          mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
                          Message msg = mHandler.obtainMessage(MSG_REQUEST_TRANSIENT_BARS);
                          msg.arg1 = MSG_REQUEST_TRANSIENT_BARS_ARG_NAVIGATION;
                          mHandler.sendMessageDelayed(msg, 500 /* delayMillis */);
                      }
  
                      @Override
                      public void onMouseLeaveFromEdge() {
                          mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
                      }
                  });
```

通过上述的mSystemGestures系统手势事件的分析发现在onSwipeFromBottom()就是系统手势上滑事件，所以监听上滑事件可以在这里发送自己的自定义上滑广播，然后在SystemUI中监听广播


实现导航栏显示和隐藏功能


具体实现如下:



```
--- a/frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java
+++ b/frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java
@@ -178,7 +178,7 @@ import com.android.server.policy.WindowOrientationListener;
 import com.android.server.statusbar.StatusBarManagerInternal;
 import com.android.server.wallpaper.WallpaperManagerInternal;
 import com.android.server.wm.utils.InsetUtils;
-
+import android.util.Log;
 import java.io.PrintWriter;
 //unisoc: For Power Hint
 import android.os.PowerHintVendorSprd;
@@ -472,6 +472,7 @@ public class DisplayPolicy extends AbsDisplayPolicy {
                         if (mStatusBar != null) {
                             requestTransientBars(mStatusBar);
                         }
+                                               //mContext.sendBroadcast(new Intent("com.android.action.swipefromtop"));
                     }
 
                     @Override
@@ -488,6 +489,8 @@ public class DisplayPolicy extends AbsDisplayPolicy {
                                 updateShowHideNavSettings(true);
                             }
                         }
     //自定义上滑广播
+                        mContext.sendBroadcast(new Intent("com.android.action.swipefrombottom"));
+                                               Log.e("StatusBar","onSwipeFromBottom");
                     }
```

### 3.2 StatusBar监听自定义广播然后实现导航栏显示和隐藏功能



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
@@ -673,7 +673,7 @@ public class StatusBar extends SystemUI implements DemoMode,
             };
     private ActivityIntentHelper mActivityIntentHelper;
     private ShadeController mShadeController;
+    private boolean navigationBarState = false;
-
+    private RegisterStatusBarResult result = null;
     @Override
     public void onActiveStateChanged(int code, int uid, String packageName, boolean active) {
         Dependency.get(MAIN_HANDLER).post(() -> {
@@ -779,7 +779,6 @@ public class StatusBar extends SystemUI implements DemoMode,
         mCommandQueue = getComponent(CommandQueue.class);
         mCommandQueue.addCallback(this);
 
-        RegisterStatusBarResult result = null;
         try {
             result = mBarService.registerStatusBar(mCommandQueue);
         } catch (RemoteException ex) {
@@ -824,6 +823,8 @@ public class StatusBar extends SystemUI implements DemoMode,
         IntentFilter internalFilter = new IntentFilter();
         internalFilter.addAction(BANNER_ACTION_CANCEL);
         internalFilter.addAction(BANNER_ACTION_SETUP);
+        internalFilter.addAction("com.android.action.swipefrombottom");
         //internalFilter.addAction("com.android.action.swipefromtop");
         mContext.registerReceiver(mBannerActionBroadcastReceiver, internalFilter, PERMISSION_SELF,
                 null);
 
@@ -963,7 +964,7 @@ public class StatusBar extends SystemUI implements DemoMode,
         mNotificationLogger.setHeadsUpManager(mHeadsUpManager);
         putComponent(HeadsUpManager.class, mHeadsUpManager);
 
-        createNavigationBar(result);
+        //createNavigationBar(result);
 
         if (ENABLE_LOCKSCREEN_WALLPAPER) {
             mLockscreenWallpaper = new LockscreenWallpaper(mContext, this, mHandler);
@@ -4515,7 +4516,19 @@ public class StatusBar extends SystemUI implements DemoMode,
 
                     );
                 }
-            }
+            }else if("com.android.action.swipefrombottom".equals(action)){
+                 //上滑事件               android.util.Log.d("StatusBar","swipefrombottom-----");
 + if(!navigationBarState = false){
 + navigationBarState = true;
                   //加载导航栏
+                 createNavigationBar(result);
+                                mHandler.postDelayed(new Runnable() {
+                    @Override
+                    public void run() {
// 移除导航栏
+                       mNavigationBarController.removeNavigationBar(mDisplayId);
+                    }
+                 },3000);
+  }
+                       }else if("com.android.action.swipefromtop".equals(action)){
+                                android.util.Log.d("StatusBar","swipefromtop---");
+                 下滑事件
//mNavigationBarController.removeNavigationBar(mDisplayId);
+                       }
         }
     };

```

在 StatusBar的makeStatusBarView中去掉加载导航栏的方法createNavigationBar(result)而在


start()方法中监听系统手势上滑的自定义广播，然后在收到自定义广播后，弹出系统导航栏，三秒钟后消失导航栏


### 3.3修改隐藏导航栏方法



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/NavigationBarController.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/NavigationBarController.java
@@ -164,7 +164,7 @@ public class NavigationBarController implements Callbacks {
         });
     }
     //隐藏导航栏方法变为public 方便调用
-    private void removeNavigationBar(int displayId) {
+    public void removeNavigationBar(int displayId) {
         NavigationBarFragment navBar = mNavigationBars.get(displayId);
         if (navBar != null) {
             View navigationWindow = navBar.getView().getRootView();
```



