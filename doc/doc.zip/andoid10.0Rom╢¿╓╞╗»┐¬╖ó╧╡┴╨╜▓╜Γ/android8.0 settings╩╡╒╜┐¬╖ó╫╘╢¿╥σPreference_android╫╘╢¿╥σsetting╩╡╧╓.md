






当系统设置的UI不美观时，这时候我们需要自定义Preference。首先要继承Prefercence类，然后绑定自定义布局 代码如下:



```
package com.xinrui.smartboard.view;

import android.content.Context;
import android.support.v7.preference.PreferenceViewHolder;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;
import android.support.v7.preference.Preference;
import com.xinrui.smartboard.R;

import java.util.Calendar;
import java.util.TimeZone;

public class PreferenceWithPowerOn extends Preference {
    private static final String TAG = "PreferenceWithPowerOn";
    private TimePicker mTimepicker;
    private Button btn;
    private Context mContext;

    public PreferenceWithPowerOn(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext=context;
    }

    public PreferenceWithPowerOn(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PreferenceWithPowerOn(Context context) {
        super(context);
    }

    public PreferenceWithPowerOn(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr,defStyleRes);
    }

    private void getCurData(){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        mTimepicker.setHour(calendar.get(Calendar.HOUR_OF_DAY));
        mTimepicker.setMinute(calendar.get(Calendar.MINUTE));
        mTimepicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {  //获取当前选择的时间
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                Log.e(TAG,"hour:"+hourOfDay+"--minute:"+minute);
                Toast.makeText(mContext,"hour:"+hourOfDay+"--minute:"+minute,Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public void onBindViewHolder(PreferenceViewHolder holder) {
        super.onBindViewHolder(holder);
        mTimepicker = (TimePicker) holder.itemView.findViewById(R.id.timepicker);
        mTimepicker.setDescendantFocusability(TimePicker.FOCUS_BLOCK_DESCENDANTS);
        mTimepicker.setIs24HourView(true);
        getCurData();
        btn = (Button)holder.itemView.findViewById(R.id.power_on_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}

```

2.然后在xml布局文件中引用自定义Preference



```
<?xml version="1.0" encoding="utf-8"?>
<!--
  Copyright (C) 2015 The Android Open Source Project

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License
  -->

<PreferenceScreen xmlns:android="http://schemas.android.com/apk/res/android"
                  xmlns:app="http://schemas.android.com/apk/res-auto">

    <com.android.tv.settings.system.PreferenceWithPowerOn
        android:key="set\_poweron\_time"
        android:persistent="false"
        android:title="@string/setting\_power\_on"
        android:layout="@layout/fragment\_power"/>//这里绑定布局文件
</PreferenceScreen>

```

3.在Fragment中引用xml文件



```
package com.android.tv.settings.system;

import android.os.Bundle;
import android.support.v17.preference.LeanbackPreferenceFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TimePicker;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.android.tv.settings.R;
import android.support.v7.preference.Preference;
import java.util.Calendar;
import java.util.TimeZone;
import android.app.Activity;
import android.support.annotation.Keep;
import android.widget.Toast;
import android.widget.Button;

@Keep
public class PowerOnFragment extends LeanbackPreferenceFragment {
    private String TAG = "PowerOnFragment";
    private TimePicker mTimepicker;
    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final Activity activity = getActivity();
            if (activity != null) {

            }
        }
    };

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.power_on, null); //添加xml文件

    }

   @Override
    public void onResume() {
        super.onResume();
        // Register for zone changes
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        getActivity().registerReceiver(mIntentReceiver, filter, null, null);
    }

    @Override
    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(mIntentReceiver);
    }

    @Override
    public boolean onPreferenceTreeClick(Preference preference) {

        return super.onPreferenceTreeClick(preference);
    }
}

```

这就是一个完整的自定义Preference控件，由于时间关系不多说废话了，关键在多实战.





