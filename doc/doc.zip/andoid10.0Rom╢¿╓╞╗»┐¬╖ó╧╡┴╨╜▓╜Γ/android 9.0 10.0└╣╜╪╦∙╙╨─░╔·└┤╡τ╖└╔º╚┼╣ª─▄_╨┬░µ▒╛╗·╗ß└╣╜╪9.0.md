






### 1.概述


在10.0的产品定制化开发中，产品需要开发拦截所有未知来电(陌生电话）防骚扰功能  
 所有就需要从拦截黑名单电话入手  
 在Telecomm 模块中 BlockChecker.getBlockStatus()是判断是否是黑名单的  
 而他被BlockCheckerAdapter.getBlockStatus()调用,AsyncBlockCheckFilter 又调用 BlockCheckerAdapter.getBlockStatus() 根据返回值来判断  
 是否是黑名单需要拦截来电


### 2.拦截所有陌生来电防骚扰功能的核心类



```
vendor\mediatek\proprietary\packages\services\Telecomm\src\com\android\server\telecom\callfiltering
\AsyncBlockCheckFilter.java

```

### 3.拦截所有陌生来电防骚扰功能的核心功能实现和分析


在AsyncBlockCheckFilter中调用 BlockCheckerAdapter 的isBlocked(),而BlockCheckerAdapter最终调用到BlockChecker中，所以要单独屏蔽电话，可在AsyncBlockCheckFilter中操作屏蔽陌生来电  
 所以分析AsyncBlockCheckFilter.java



```
 @Override
    protected Boolean doInBackground(String... params) {
        try {
            Log.continueSession(mBackgroundTaskSubsession, "ABCF.dIB");
            Log.addEvent(mIncomingCall, LogUtils.Events.BLOCK_CHECK_INITIATED);
            Bundle extras = new Bundle();
            if (params.length > 1) {
                extras.putInt(BlockedNumberContract.EXTRA_CALL_PRESENTATION,
                        Integer.valueOf(params[1]));
            }
            if (params.length > 2) {
                extras.putBoolean(BlockedNumberContract.EXTRA_CONTACT_EXIST,
                        Boolean.valueOf(params[2]));
            }
            // Unisoc FL0108060002: CallFireWall
            int callBlockType = MARK_CALL_BLOCK_TYPE;
            mBlockStatus = mBlockCheckerAdapter.getBlockStatus(mContext, params[0], extras, callBlockType);
            return mBlockStatus != BlockedNumberContract.STATUS_NOT_BLOCKED;
        } finally {
            Log.endSession();
        }
    }

    @Override
    protected void onPostExecute(Boolean isBlocked) {
        Log.continueSession(mPostExecuteSubsession, "ABCF.oPE");
        try {
            CallFilteringResult result;
            if (isBlocked) {
                result = new CallFilteringResult(
                        false, // shouldAllowCall
                        true, //shouldReject
                        true, //shouldAddToCallLog
                        false, // shouldShowNotification
                        convertBlockStatusToReason(), //callBlockReason
                        null, //callScreeningAppName
                        null //callScreeningComponentName
                );
                if (mCallBlockListener != null) {
                    String number = mIncomingCall.getHandle() == null ? null
                            : mIncomingCall.getHandle().getSchemeSpecificPart();
                    mCallBlockListener.onCallBlocked(mBlockStatus, number,
                            mIncomingCall.getInitiatingUser());
                }
            } else {
                result = new CallFilteringResult(
                        true, // shouldAllowCall
                        false, // shouldReject
                        true, // shouldAddToCallLog
                        true // shouldShowNotification
                );
            }
            Log.addEvent(mIncomingCall, LogUtils.Events.BLOCK_CHECK_FINISHED,
                    BlockedNumberContract.SystemContract.blockStatusToString(mBlockStatus) + " "
                            + result);
            mCallback.onCallFilteringComplete(mIncomingCall, result);
        } finally {
            Log.endSession();
        }
    }

```

在AsyncBlockCheckFilter.java 中的  
 onPostExecute 的isBlocked 是根据doInBackground的返回值来判断是否需要拦截  
 所以 就需要在doInBackground 中添加 查询是否是联系人的电话号码 不是就返回true


修改如下：



```
@Override
protected Boolean doInBackground(String... params) {
    try {
        Log.continueSession(mBackgroundTaskSubsession, "ABCF.dIB");
        Log.addEvent(mIncomingCall, LogUtils.Events.BLOCK_CHECK_INITIATED);
        Bundle extras = new Bundle();
        if (params.length > 1) {
            extras.putInt(BlockedNumberContract.EXTRA_CALL_PRESENTATION,
                    Integer.valueOf(params[1]));
        }
        if (params.length > 2) {
            extras.putBoolean(BlockedNumberContract.EXTRA_CONTACT_EXIST,
                    Boolean.valueOf(params[2]));
        }
        // Unisoc FL0108060002: CallFireWall
        int callBlockType = MARK_CALL_BLOCK_TYPE;
        mBlockStatus = mBlockCheckerAdapter.getBlockStatus(mContext, params[0], extras, callBlockType);
           // add core start 
	List<String> list = getContactAllPhotoNumber();
            String callTelNum = params[0];
            boolean isIntercepte = list.contains(callTelNum);
	if(isIntercept){
			return true;
	}
     // add core end 
        return mBlockStatus != BlockedNumberContract.STATUS_NOT_BLOCKED;
    } finally {
        Log.endSession();
    }
}

```

增加方法用系统联系人的api来获取所有联系人电话



```
private List<String> getContactAllPhotoNumber(){
    List<String> mTelNumList = new ArrayList<>();
    Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
    ContentResolver cr = this.getContentResolver();
    Cursor cursor = cr.query(uri, null, null, null, null);
    //移动到游标到联系人表第一行
    if (cursor != null) {
        while (cursor.moveToNext()) {
            //联系人姓名
            String nameStr = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            //读取通讯录的号码
            String phoneStr = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            Log.e("MainActivity","nameStr:"+nameStr+"---phoneStr:"+phoneStr);
            mTelNumList.add(phoneStr);
        }
        cursor.close();
    }
    // Sim1的URI
    Uri uri1 = Uri.parse("content://icc/adn/subId/1");
    Cursor cursor1 = this.getContentResolver().query(uri1, null, null,
            null, null);
    if (cursor1 != null) {
        while (cursor1.moveToNext()) {
            int columId = cursor1.getColumnIndex(Contacts.People._ID);// id下标
            int displayNameColum = cursor1.getColumnIndex(Contacts.People.NAME);// 名称下标
            int phoneNo = cursor1.getColumnIndex(Contacts.People.NUMBER);// 电话号码列
            String contactId = cursor1.getString(columId);
            // 获得联系人姓名
            String disPlayName = cursor1.getString(displayNameColum);
            String phonenum = cursor1.getString(phoneNo);// 号码
            mTelNumList.add(phonenum);
        }
    }
    // Sim1的URI
    Uri uri2 = Uri.parse("content://icc/adn/subId/1");
    Cursor cursor2 = this.getContentResolver().query(uri2, null, null,
            null, null);
    if (cursor2 != null) {
        while (cursor2.moveToNext()) {
            int columId = cursor2.getColumnIndex(Contacts.People._ID);// id下标
            int displayNameColum = cursor2.getColumnIndex(Contacts.People.NAME);// 名称下标
            int phoneNo = cursor2.getColumnIndex(Contacts.People.NUMBER);// 电话号码列
            String contactId = cursor2.getString(columId);
            // 获得联系人姓名
            String disPlayName = cursor2.getString(displayNameColum);
            String phonenum = cursor2.getString(phoneNo);// 号码
            mTelNumList.add(phonenum);
        }
    }
    return mTelNumList;
}

```

通过在doInBackground(String… params) 中增加对手机通讯录号码的判断来实现电话拦截  
 修改完以后 编译验证即可





