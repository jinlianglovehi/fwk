



## 1.前言


 在10.0的系统定制化开发中，其中系统中对于sim卡的管理模块也是很重要的功能，在一些产品开发中，有需求要求禁用sim卡功能，不能  
 使用sim卡 插入sim卡也不能使用，所以就需要从系统的sim卡启用和禁用的相关功能中来找api实现这些功能


## 2.framework实现禁用SIM卡的功能的核心类



```
frameworks\base\services\core\java\com\android\server\power\ShutdownThread.java
frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java

```

## 3.framework实现禁用SIM卡的功能的核心功能分析和实现


在framework实现禁用SIM卡的功能的实现中，  
 首选分析Android 系统的关机流程是从用户按 power 键开始的，所有的按键处理都是通过  
  PhoneWindowManager.interceptKeyBeforeQueueing() 方法进行处理,  
 然后通过按键长按处理弹出关机对话框，在通过点击关机按扭，通过调用WindowManagerService.shutdown()  
 的方法，在shutdown()方法中，最终通过调用Android 关机的流程最终是通过 ShutdownThread 线程实现。  
 最核心的方法都是在ShutdownThread中处理关于关机的流程，接下来分析下  
  ShutdownThread.java的相关方法


## 3.1 ShutdownThread.java中相关关机源码分析功能实现


在framework实现禁用SIM卡的功能的实现中，通过上述的分析得知，在处理关机流程中，在  
 调用WindowManagerService.shutdown()  
 的方法，在shutdown()方法中，最终通过调用Android 关机的流程最终是通过 ShutdownThread 线程实现。  
 接下来具体看下关机的相关方法



```
   /* SPRD: add shutdown mode for PowerOffAlarm @{ */
    public static void shutdownForAlarm(final Context context, boolean confirm, boolean isPowerOffAlarm) {
        Log.i(TAG, "shutdownForAlarm isPowerOffAlarm = " + isPowerOffAlarm);
        sIsPowerOffAlarm = isPowerOffAlarm;
        shutdownInner(context, confirm);
    }
   private static void shutdownInner(final Context context, boolean confirm) {
        // ShutdownThread is called from many places, so best to verify here that the context passed
        // in is themed.
        context.assertRuntimeOverlayThemable();

        // ensure that only one thread is trying to power down.
        // any additional calls are just returned
        synchronized (sIsStartedGuard) {
            if (sIsStarted) {
                Log.d(TAG, "Request to shutdown already running, returning.");
                return;
            }
        }

        final int longPressBehavior = context.getResources().getInteger(
                        com.android.internal.R.integer.config_longPressOnPowerBehavior);
        final int resourceId = mRebootSafeMode
                ? com.android.internal.R.string.reboot_safemode_confirm
                /*UNISOC bug 908624,add confirm dialog.*/
                : (mReboot
                ? com.android.internal.R.string.reboot_device_confirm
                /*UNISOC bug 908624,add confirm dialog.*/
                : (longPressBehavior == 2
                        ? com.android.internal.R.string.shutdown_confirm_question
                        : com.android.internal.R.string.shutdown_confirm));

        Log.d(TAG, "Notifying thread to start shutdown longPressBehavior=" + longPressBehavior);

        if (sInstance.mPowerManager == null) {
            sInstance.mPowerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        }

        if (confirm) {
            final CloseDialogReceiver closer = new CloseDialogReceiver(context);
            if (sConfirmDialog != null) {
                sConfirmDialog.dismiss();
            }

            //bug:1162804 add dark theme.
            if (sInstance.mUiModeManager == null) {
                sInstance.mUiModeManager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
            }
            if (sInstance.mUiModeManager != null && sInstance.mPowerManager != null &&(sInstance.mUiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES
                    || sInstance.mPowerManager.isPowerSaveMode())) {
                sInstance.mThemeResId = AlertDialog.THEME_DEVICE_DEFAULT_DARK;
            } else {
                sInstance.mThemeResId = AlertDialog.THEME_DEVICE_DEFAULT_LIGHT;
            }

            sConfirmDialog = new AlertDialog.Builder(context, sInstance.mThemeResId)
                    .setTitle(mRebootSafeMode
                            ? com.android.internal.R.string.reboot_safemode_title
                            /*UNISOC bug 908624*/
                            :(mReboot
                            ? com.android.internal.R.string.reboot_device_title
                            /*UNISOC bug 908624*/
                            : com.android.internal.R.string.power_off))
                    .setMessage(resourceId)
                    .setPositiveButton(com.android.internal.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            beginShutdownSequence(context);
                        }
                    })
                    .setNegativeButton(com.android.internal.R.string.no, null)
                    .create();
            closer.dialog = sConfirmDialog;
            sConfirmDialog.setOnDismissListener(closer);
            sConfirmDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG);
            sConfirmDialog.show();
        } else {
            beginShutdownSequence(context);
        }
    }
```

在framework实现禁用SIM卡的功能的实现中，在上述的 ShutdownThread.java中的相关源码分析得知，在  
 shutdownInner(final Context context, boolean confirm)中是主要负责处理关机的核心方法中，在  
 shutdownInner(final Context context, boolean confirm)中，首选是调用beginShutdownSequence(context);  
 来执行相关的关机动画，然后在run()方法里面执行相关的关机指令，接下来分析下相关的run()方法的相关源码



```
    public void run() {
.....
        shutdownTimingLog.traceEnd(); // ShutdownPackageManager
        metricEnded(METRIC_PM);

        // Shutdown radios.
        shutdownTimingLog.traceBegin("ShutdownRadios");
        metricStarted(METRIC_RADIOS);
        shutdownRadios(MAX_RADIO_WAIT_TIME);
        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(RADIO_STOP_PERCENT, null);
        }
        shutdownTimingLog.traceEnd(); // ShutdownRadios
        metricEnded(METRIC_RADIOS);

        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(MOUNT_SERVICE_STOP_PERCENT, null);

            // If it's to reboot to install an update and uncrypt hasn't been
            // done yet, trigger it now.
            uncrypt();
        }

        shutdownTimingLog.traceEnd(); // SystemServerShutdown
        metricEnded(METRIC_SYSTEM_SERVER);
        saveMetrics(mReboot, mReason);
        // SPRD:add for shutdownanim
        shutdownAnim.waitForBootanim();
        // Remaining work will be done by init, including vold shutdown
        rebootOrShutdown(mContext, mReboot, mReason);
    }

   private void shutdownRadios(final int timeout) {
        final long endTime = SystemClock.elapsedRealtime() + timeout;
        final boolean[] done = new boolean[1];
        Thread t = new Thread() {
            public void run() {
                TimingsTraceLog shutdownTimingsTraceLog = newTimingsLog();
                boolean radioOff;

                final ITelephony phone =
                        ITelephony.Stub.asInterface(ServiceManager.checkService("phone"));

                try {
                    radioOff = phone == null || !phone.needMobileRadioShutdown();
                    if (!radioOff) {
                        Log.w(TAG, "Turning off cellular radios...");
                        metricStarted(METRIC_RADIO);
                        if (SystemProperties.getBoolean("gsm.fast.shutdown", false) == false) {
                            Log.d(TAG, "no fast shutdown");
                            phone.shutdownMobileRadios();
                        }
                    }
                } catch (RemoteException ex) {
                    Log.e(TAG, "RemoteException during radio shutdown", ex);
                    radioOff = true;
                }

                Log.i(TAG, "Waiting for Radio...");

                long delay = endTime - SystemClock.elapsedRealtime();
                while (delay > 0) {
                    if (mRebootHasProgressBar) {
                        int status = (int)((timeout - delay) * 1.0 *
                                (RADIO_STOP_PERCENT - PACKAGE_MANAGER_STOP_PERCENT) / timeout);
                        status += PACKAGE_MANAGER_STOP_PERCENT;
                        sInstance.setRebootProgress(status, null);
                    }

                    if (!radioOff) {
                        try {
                            radioOff = !phone.needMobileRadioShutdown();
                        } catch (RemoteException ex) {
                            Log.e(TAG, "RemoteException during radio shutdown", ex);
                            radioOff = true;
                        }
                        if (radioOff) {
                            Log.i(TAG, "Radio turned off.");
                            metricEnded(METRIC_RADIO);
                            shutdownTimingsTraceLog
                                    .logDuration("ShutdownRadio", TRON_METRICS.get(METRIC_RADIO));
                        }
                    }

                    if (radioOff) {
                        Log.i(TAG, "Radio shutdown complete.");
                        done[0] = true;
                        break;
                    }
                    SystemClock.sleep(RADIOS_STATE_POLL_SLEEP_MS);
                    delay = endTime - SystemClock.elapsedRealtime();
                }
            }
        };

        t.start();
        try {
            t.join(timeout);
        } catch (InterruptedException ex) {
        }
        if (!done[0]) {
            Log.w(TAG, "Timed out waiting for Radio shutdown.");
        }
    }
```

在framework实现禁用SIM卡的功能的实现中，在上述的 ShutdownThread.java中的相关源码分析得知，  
 在这个run()方法中，关于sim卡的关闭就是调用shutdownRadios(MAX\_RADIO\_WAIT\_TIME);来实现的  
 具体实现关闭sim卡功能就是在这里处理的，在shutdownRadios(final int timeout)中的方法中，会  
 核心代码就是phone.shutdownMobileRadios();来实现具体的关闭sim卡的功能，所以就可以在系统  
 开机完成后 实现关机功能


##  3.2 PhoneWindowManager.java中实现开机禁用sim卡的功能



```
    @Override
    public void systemReady() {
        mKeyguardDelegate.onSystemReady();

        Settings.System.putInt(mContext.getContentResolver(),
                Settings.System.TIGO_CMAS_STATUS, 0);

        mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
        if (mVrManagerInternal != null) {
            mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
        }

        readCameraLensCoverState();
        updateUiMode();
        mDefaultDisplayRotation.updateOrientationListener();
        synchronized (mLock) {
            mSystemReady = true;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    updateSettings();
                }
            });
            // If this happens, for whatever reason, systemReady came later than systemBooted.
            // And keyguard should be already bound from systemBooted
            if (mSystemBooted) {
                mKeyguardDelegate.onBootCompleted();
            }
        }

        mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
//add core start
        final long identity = Binder.clearCallingIdentity();
        try {
            for (int i = 0; i < TelephonyManager.getDefault().getPhoneCount(); i++) {
                logv("Shutting down Phone " + i);
                shutdownRadioUsingPhoneId(i);
            }
        } finally {
            Binder.restoreCallingIdentity(identity);
        }
//add core end
    }
    private void shutdownRadioUsingPhoneId(int phoneId) {
        Phone phone = PhoneFactory.getPhone(phoneId);
        if (phone != null && phone.isRadioAvailable()) {
            phone.shutdownRadio();
        }
    }
```

在framework实现禁用SIM卡的功能的实现中，在上述的 PhoneWindowManager.java中的相关源码分析得知，  
 在systemReady()中系统开机完成以后，通过添加Phone的 phone.shutdownRadio();方法，调用  
 shutdownRadio()来实现禁用sim卡，首选获取当前多少涨sim卡，然后遍历获取Phone对象，最后  
 调用phone.shutdownRadio();来实现sim卡的禁用功能



