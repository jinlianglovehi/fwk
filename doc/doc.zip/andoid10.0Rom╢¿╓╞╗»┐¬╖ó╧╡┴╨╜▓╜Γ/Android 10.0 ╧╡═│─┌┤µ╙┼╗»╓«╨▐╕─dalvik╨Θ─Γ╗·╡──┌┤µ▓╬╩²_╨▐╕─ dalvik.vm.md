



## 1.前言


 在10.0的系统开发定制中，app应用也是运行在dalvik虚拟机上的，所以对于一些内存低的系统中，在某些大应用会出现耗内存  
 卡顿情况，这是系统分配的内存不够大，在进行耗内存的操作，就会出现频繁gc等等原因造成不流畅的现象，接下来就分析下  
 虚拟机分配内存的相关原理


## 2.系统内存优化之修改dalvik虚拟机的内存参数的核心类



```
vendor\sprd\generic\misc\system\core\init\init_expand.rc
framework/native/build/tablet-7in-xhdpi-2048-dalvik-heap.mk
art/runtime/runtime.cc
```

## 3.系统内存优化之修改dalvik虚拟机的内存参数的核心功能分析和实现


dalvik虚拟机内存分配参数说明:  
 dalvik.vm.heapstartsize：堆分配的初始大小。这个值越大应用启动越流畅。  
 这里分配的内存容量会影响到整个系统对RAM的使用程度，和第一次使用应用程序时的流畅程序。  
 这个值越大，系统消耗RAM则越快，但是应用程序打开后的反应也越快。  
 值越小，系统的RAM剩余则越多，但是程序在启动后会比较慢


dalvik.vm.heapgrowthlimit：正常情况下（即未设置android:largeHeap="true"）dalvik能申请到的最大堆内存，超过这个大小将会引发oom（out of memory）异常。


dalvik.vm.heapsize：所有情况下（包括设置android:largeHeap="true"的情形）的最大堆内存值，超过直接oom。  
 所以，在我们未设置android:largeHeap="true"的时候，只要申请的内存超过了heapgrowthlimit就会触发oom，而当设置android:largeHeap="true"的时候，只有内存超过了heapsize才会触发oom。heapsize已经是该应用能申请的最大内存（这里不包括native申请的内存）。  
 这里分配的内存容量会影响到整个系统对RAM的使用程序，和程序在运行一段时间后的反应速度。这个值越大，  
 系统消耗RAM则越快，但是程序会运行的非常稳 定，尤其是游戏和视频程序的内容加载速度可以大幅度提升。值越小，  
 系统的RAM剩余则越多，但是程序会很卡，尤其是游戏在切换场景Loading的时候会 花费很多的时间。若应用程序需要使  
 用超过这个值的内存时，将会触发系统的垃圾收集器，系统和程序就会卡顿。


dalvik.vm.heaptargetutilization：当前存活对象的对大小 / 堆大小  
 英文解释：This converts to a -XX:HeapTargetUtilization option. It gives the VM a hint as to how full the managed heap should be allowed to become.


dalvik.vm.heapminfree：单次内存调整的最小值  
 dalvik.vm.heapmaxfree：单次内存调整的最大值


## 3.1runtime.cc相关虚拟机内存参数的分析



```
bool Runtime::Init(const Options& raw_options, bool ignore_unrecognized) {  
 bool Runtime::Init(RuntimeArgumentMap&& runtime_options_in) {
  // (b/30160149): protect subprocesses from modifications to LD_LIBRARY_PATH, etc.
  // Take a snapshot of the environment at the time the runtime was created, for use by Exec, etc.
  env_snapshot_.TakeSnapshot();

  using Opt = RuntimeArgumentMap;
  Opt runtime_options(std::move(runtime_options_in));
  ScopedTrace trace(__FUNCTION__);
  CHECK_EQ(sysconf(_SC_PAGE_SIZE), kPageSize);

  // Early override for logging output.
  if (runtime_options.Exists(Opt::UseStderrLogger)) {
    android::base::SetLogger(android::base::StderrLogger);
  }

  MemMap::Init();

  {
    constexpr uintptr_t kSentinelAddr =
        RoundDown(static_cast<uintptr_t>(Context::kBadGprBase), kPageSize);
    protected_fault_page_ = MemMap::MapAnonymous("Sentinel fault page",
                                                 reinterpret_cast<uint8_t*>(kSentinelAddr),
                                                 kPageSize,
                                                 PROT_NONE,
                                                 /*low_4gb=*/ true,
                                                 /*reuse=*/ false,
                                                 /*reservation=*/ nullptr,
                                                 /*error_msg=*/ nullptr);
    if (!protected_fault_page_.IsValid()) {
      LOG(WARNING) << "Could not reserve sentinel fault page";
    } else if (reinterpret_cast<uintptr_t>(protected_fault_page_.Begin()) != kSentinelAddr) {
      LOG(WARNING) << "Could not reserve sentinel fault page at the right address.";
      protected_fault_page_.Reset();
    }
  }

  VLOG(startup) << "Runtime::Init -verbose:startup enabled";

  QuasiAtomic::Startup();

  oat_file_manager_ = new OatFileManager;

 
  core_platform_api_policy_ = runtime_options.GetOrDefault(Opt::CorePlatformApiPolicy);
  if (core_platform_api_policy_ != hiddenapi::EnforcementPolicy::kDisabled) {
    LOG(INFO) << "Core platform API reporting enabled, enforcing="
        << (core_platform_api_policy_ == hiddenapi::EnforcementPolicy::kEnabled ? "true" : "false");
  }
  
  UniquePtr<ParsedOptions> options(ParsedOptions::Create(raw_options, ignore_unrecognized));  
  ......  

}
```

在通过上述的runtime.cc的相关源码分析得知，在  
 Runtime类的成员函数Init首先是调用ParsedOptions类的静态成员函数Create解析ART运行时的启动选项，并且保存在变量options  
 指向的一个ParsedOptions对象的各个成员变量中，与堆相关的各个选项的含义


## 3.2 tablet-7in-xhdpi-2048-dalvik-heap.mk中相关虚拟机参数分析



```
#
# Copyright (C) 2012 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Provides overrides to configure the Dalvik heap for a standard tablet device.

PRODUCT_PROPERTY_OVERRIDES += \
    dalvik.vm.heapstartsize=16m \
    dalvik.vm.heapgrowthlimit=192m \
    dalvik.vm.heapsize=512m \
    dalvik.vm.heaptargetutilization=0.75 \
    dalvik.vm.heapminfree=512k \
    dalvik.vm.heapmaxfree=8m

```

在上述的tablet-7in-xhdpi-2048-dalvik-heap.mk的相关源码中分析得知 ，在这里  
 设置了dalvik虚拟机的相关参数设置，dalvik.vm.heapstartsize dalvik.vm.heapsize  
 dalvik.vm.heapmaxfree dalvik.vm.heapminfree等参数等等，当然也需要根据  
 机器的实际参数来确定是否在这个mk里面配置


## 3.3 展讯的dalvik虚拟机参数配置



```
on early-init && property:ro.debuggable=1
   # Control avc rate limit through property and proc node.
   setprop ro.logd.auditd false
   write /proc/sys/kernel/printk_ratelimit 0

on early-init && property:ro.boot.ddrsize.range="[0,512)"
   setprop dalvik.vm.foreground-heap-growth-multiplier 1.0
   setprop dalvik.vm.heapstartsize 5m
   setprop dalvik.vm.heapsize 32m
   setprop dalvik.vm.heaptargetutilization 0.75
   setprop dalvik.vm.heapminfree 512k
   setprop dalvik.vm.heapmaxfree 2m

on early-init && property:ro.boot.ddrsize.range="[512,1024)"
   setprop dalvik.vm.foreground-heap-growth-multiplier 1.0
   setprop dalvik.vm.heapstartsize 5m
   setprop dalvik.vm.heapgrowthlimit 128m
   setprop dalvik.vm.heapsize 256m
   setprop dalvik.vm.heaptargetutilization 0.75
   setprop dalvik.vm.heapminfree 512k
   setprop dalvik.vm.heapmaxfree 2m

on early-init && property:ro.boot.ddrsize.range="[1024,2048)"
   setprop dalvik.vm.heapstartsize 8m
   setprop dalvik.vm.heapgrowthlimit 128m
   setprop dalvik.vm.heapsize 256m
   setprop dalvik.vm.heaptargetutilization 0.75
   setprop dalvik.vm.heapminfree 512k
   setprop dalvik.vm.heapmaxfree 8m

on early-init && property:ro.boot.ddrsize.range="[2048,3072)"
   setprop dalvik.vm.heapstartsize 8m
   setprop dalvik.vm.heapgrowthlimit 192m
   setprop dalvik.vm.heapsize 512m
   setprop dalvik.vm.heaptargetutilization 0.75
   setprop dalvik.vm.heapminfree 512k
   setprop dalvik.vm.heapmaxfree 8m

on early-init && property:ro.boot.ddrsize.range="[3072,4096)"
   setprop dalvik.vm.heapstartsize 8m
   setprop dalvik.vm.heapgrowthlimit 192m
   setprop dalvik.vm.heapsize 512m
   setprop dalvik.vm.heaptargetutilization 0.75
   setprop dalvik.vm.heapminfree 512k
   setprop dalvik.vm.heapmaxfree 8m

on early-init && property:ro.boot.ddrsize.range="[4096,5120)"
-   setprop dalvik.vm.heapstartsize 8m
+   setprop dalvik.vm.heapstartsize 16m
   setprop dalvik.vm.heapgrowthlimit 192m
   setprop dalvik.vm.heapsize 512m
   setprop dalvik.vm.heaptargetutilization 0.75
-   setprop dalvik.vm.heapminfree 8m
-   setprop dalvik.vm.heapmaxfree 16m
+   setprop dalvik.vm.heapminfree 2m
+   setprop dalvik.vm.heapmaxfree 64m

on early-init && property:ro.boot.ddrsize.range="[5120,6144)"
   setprop dalvik.vm.heapstartsize 8m
   setprop dalvik.vm.heapgrowthlimit 192m
   setprop dalvik.vm.heapsize 512m
   setprop dalvik.vm.heaptargetutilization 0.6
   setprop dalvik.vm.heapminfree 8m
   setprop dalvik.vm.heapmaxfree 16m

on early-init && property:ro.boot.ddrsize.range="[6144,)"
   setprop dalvik.vm.heapstartsize 16m
   setprop dalvik.vm.heapgrowthlimit 256m
   setprop dalvik.vm.heapsize 512m
   setprop dalvik.vm.heaptargetutilization 0.5
   setprop dalvik.vm.heapminfree 8m
   setprop dalvik.vm.heapmaxfree 32m

```

在上述的init\_expand.rc的相关虚拟机参数配置源码中，分析得知，在这个rc文件中，是展讯具体  
 给虚拟机分配内存的地方，所以看出这里会根据property:ro.boot.ddrsize.range这个ddr的大小  
 来设置不同的参数，本机ddr是4g的内存，所以在on early-init && property:ro.boot.ddrsize.range="[4096,5120)"  
 这里来设置上述的参数，具体功能就这样实现了




