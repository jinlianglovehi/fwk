






### 1.概述


在10.0的产品开发中，产品需要，在跟踪某个页面启动的时候显示和隐藏导航栏，而AMS中 所有的Activity 都是由AMS来负责启动的，那么要想深入了解AMS的启动流程，就得从AMS处了解


### 2.AMS跟踪Activity启动流程来显示和隐藏导航栏的核心类



```
frameworks/base/services/core/java/com/android/server/am/ActivityStarter.java

```

### 3.AMS跟踪Activity启动流程来显示和隐藏导航栏的核心功能实现和分析


在对AMS的启动流程跟踪完后，发现最重要的startActivity的处理是在ActivityStarter.java中处理的，接下来就看ActivityStarter.java中是怎么处理的  
 如下:



```

 private int startActivity(IApplicationThread caller, Intent intent, Intent ephemeralIntent,
            String resolvedType, ActivityInfo aInfo, ResolveInfo rInfo,
            IVoiceInteractionSession voiceSession, IVoiceInteractor voiceInteractor,
            IBinder resultTo, String resultWho, int requestCode, int callingPid, int callingUid,
            String callingPackage, int realCallingPid, int realCallingUid, int startFlags,
            SafeActivityOptions options,
            boolean ignoreTargetSecurity, boolean componentSpecified, ActivityRecord[] outActivity,
            TaskRecord inTask, boolean allowPendingRemoteAnimationRegistryLookup,
            PendingIntentRecord originatingPendingIntent, boolean allowBackgroundActivityStart) {
        mSupervisor.getActivityMetricsLogger().notifyActivityLaunching(intent);
        int err = ActivityManager.START_SUCCESS;
        // Pull the optional Ephemeral Installer-only bundle out of the options early.
        final Bundle verificationBundle
                = options != null ? options.popAppVerificationBundle() : null;

        WindowProcessController callerApp = null;
        if (caller != null) {
            callerApp = mService.getProcessController(caller);
            if (callerApp != null) {
                callingPid = callerApp.getPid();
                callingUid = callerApp.mInfo.uid;
            } else {
                Slog.w(TAG, "Unable to find app for caller " + caller
                        + " (pid=" + callingPid + ") when starting: "
                        + intent.toString());
                err = ActivityManager.START_PERMISSION_DENIED;
            }
        }

```

通过上述代码发现，在startActivity中启动Activity的过程中  
 在ActivityMetricsLogger类中，记录下开始启动APP的时间 mSupervisor.mActivityMetricsLogger.notifyActivityLaunching();  
 来记录启动日志，  
 接下来看下notifyActivityLaunching();



```
 void notifyActivityLaunched(int resultCode, ActivityRecord launchedActivity) {
        final WindowProcessController processRecord = findProcessForActivity(launchedActivity);
        final boolean processRunning = processRecord != null;

        // We consider this a "process switch" if the process of the activity that gets launched
        // didn't have an activity that was in started state. In this case, we assume that lot
 // of caches might be purged so the time until it produces the first frame is very
 // interesting.
 final boolean processSwitch = processRecord == null
 || !processRecord.hasStartedActivity(launchedActivity);

 notifyActivityLaunched(resultCode, launchedActivity, processRunning, processSwitch);
 }

 /\*\*
 \* Notifies the tracker the the activity is actually launching.
 \*
 \* @param resultCode one of the ActivityManager.START\_\* flags, indicating the result of the
 \* launch
 \* @param launchedActivity the activity being launched
 \* @param processRunning whether the process that will contains the activity is already running
 \* @param processSwitch whether the process that will contain the activity didn't have any
     *                      activity that was stopped, i.e. the started activity is "switching"
     *                      processes
     */
    private void notifyActivityLaunched(int resultCode, ActivityRecord launchedActivity,
            boolean processRunning, boolean processSwitch) {

        if (DEBUG_METRICS) Slog.i(TAG, "notifyActivityLaunched"
                + " resultCode=" + resultCode
                + " launchedActivity=" + launchedActivity
                + " processRunning=" + processRunning
                + " processSwitch=" + processSwitch);

        // If we are already in an existing transition, only update the activity name, but not the
        // other attributes.
        final @WindowingMode int windowingMode = launchedActivity != null
                ? launchedActivity.getWindowingMode()
                : WINDOWING_MODE_UNDEFINED;
        final WindowingModeTransitionInfo info = mWindowingModeTransitionInfo.get(windowingMode);
        if (mCurrentTransitionStartTime == INVALID_START_TIME) {
            // No transition is active ignore this launch.
            return;
        }

        if (launchedActivity != null && launchedActivity.mDrawn) {
            // Launched activity is already visible. We cannot measure windows drawn delay.
            reset(true /* abort */, info, "launched activity already visible");
            return;
        }

        if (launchedActivity != null && info != null) {
            // If we are already in an existing transition, only update the activity name, but not
            // the other attributes.

            // Coalesce multiple (trampoline) activities from a single sequence together.
            info.launchedActivity = launchedActivity;
            return;
        }

        final boolean otherWindowModesLaunching =
                mWindowingModeTransitionInfo.size() > 0 && info == null;
        if ((!isLoggableResultCode(resultCode) || launchedActivity == null || !processSwitch
 || windowingMode == WINDOWING\_MODE\_UNDEFINED) && !otherWindowModesLaunching) {
 // Failed to launch or it was not a process switch, so we don't care about the timing.
 reset(true /\* abort \*/, info, "failed to launch or not a process switch");
 return;
 } else if (otherWindowModesLaunching) {
 // Don't log this windowing mode but continue with the other windowing modes.
 return;
 }

 if (DEBUG\_METRICS) Slog.i(TAG, "notifyActivityLaunched successful");

 // A new launch sequence [with the windowingMode] has begun.
 // Start tracking it.
 final WindowingModeTransitionInfo newInfo = new WindowingModeTransitionInfo();
 newInfo.launchedActivity = launchedActivity;
 newInfo.currentTransitionProcessRunning = processRunning;
 newInfo.startResult = resultCode;
 mWindowingModeTransitionInfo.put(windowingMode, newInfo);
 mLastWindowingModeTransitionInfo.put(windowingMode, newInfo);
 mCurrentTransitionDeviceUptime = (int) (SystemClock.uptimeMillis() / 1000);
 startTraces(newInfo);
 launchObserverNotifyActivityLaunched(newInfo);
 }

 private void reset(boolean abort, WindowingModeTransitionInfo info, String cause) {
 if (DEBUG\_METRICS) Slog.i(TAG, "reset abort=" + abort + ",cause=" + cause);
 if (!abort && isAnyTransitionActive()) {
            logAppTransitionMultiEvents();
        }
        stopLaunchTrace(info);

        // Ignore reset-after reset.
        if (isAnyTransitionActive()) {
            // LaunchObserver callbacks.
            if (abort) {
                launchObserverNotifyActivityLaunchCancelled(info);
            } else {
                launchObserverNotifyActivityLaunchFinished(info);
            }
        } else {
            launchObserverNotifyIntentFailed();
        }

        mCurrentTransitionStartTime = INVALID_START_TIME;
        mCurrentTransitionDelayMs = INVALID_DELAY;
        mLoggedTransitionStarting = false;
        mWindowingModeTransitionInfo.clear();
    }

    private void logAppTransitionMultiEvents() {
        if (DEBUG_METRICS) Slog.i(TAG, "logging transition events");
        for (int index = mWindowingModeTransitionInfo.size() - 1; index >= 0; index--) {
            final WindowingModeTransitionInfo info = mWindowingModeTransitionInfo.valueAt(index);
            final int type = getTransitionType(info);
            if (type == INVALID_TRANSITION_TYPE) {
                if (DEBUG_METRICS) {
                    Slog.i(TAG, "invalid transition type"
                            + " processRunning=" + info.currentTransitionProcessRunning
                            + " startResult=" + info.startResult);
                }
                return;
            }

            // Take a snapshot of the transition info before sending it to the handler for logging.
            // This will avoid any races with other operations that modify the ActivityRecord.
            final WindowingModeTransitionInfoSnapshot infoSnapshot =
                    new WindowingModeTransitionInfoSnapshot(info);
            final int currentTransitionDeviceUptime = mCurrentTransitionDeviceUptime;
            final int currentTransitionDelayMs = mCurrentTransitionDelayMs;
            BackgroundThread.getHandler().post(() -> logAppTransition(
 currentTransitionDeviceUptime, currentTransitionDelayMs, infoSnapshot));
            BackgroundThread.getHandler().post(() -> logAppDisplayed(infoSnapshot));

            info.launchedActivity.info.launchToken = null;
        }
    }

    private void logAppDisplayed(WindowingModeTransitionInfoSnapshot info) {
        if (info.type != TYPE_TRANSITION_WARM_LAUNCH && info.type != TYPE_TRANSITION_COLD_LAUNCH) {
            return;
        }

        EventLog.writeEvent(AM_ACTIVITY_LAUNCH_TIME,
                info.userId, info.activityRecordIdHashCode, info.launchedActivityShortComponentName,
                info.windowsDrawnDelayMs);

        StringBuilder sb = mStringBuilder;
        sb.setLength(0);
        sb.append("Displayed ");
        sb.append(info.launchedActivityShortComponentName);
        sb.append(": ");
        TimeUtils.formatDuration(info.windowsDrawnDelayMs, sb);
        Log.i(TAG, sb.toString());
    }

```

通过对notifyActivityLaunching源码的分析，发现调用logAppTransitionMultiEvents()，又调用logAppDisplayed  
 在logAppDisplayed中判断当前是哪个Activity



```
diff --git a/frameworks/base/services/core/java/com/android/server/wm/ActivityMetricsLogger.java b/frameworks/base/services/core/java/com/android/server/

wm/ActivityMetricsLogger.java

old mode 100644

new mode 100755

index a571e35e77..dc22e01e11

--- a/frameworks/base/services/core/java/com/android/server/wm/ActivityMetricsLogger.java

+++ b/frameworks/base/services/core/java/com/android/server/wm/ActivityMetricsLogger.java

@@ -92,7 +92,7 @@ import com.android.internal.logging.MetricsLogger;

 import com.android.internal.os.BackgroundThread;

 import com.android.internal.os.SomeArgs;

 import com.android.server.LocalServices;

-

+import android.provider.Settings;

 /**

  * Listens to activity launches, transitions, visibility changes and window drawn callbacks to

  * determine app launch times and draw delays. Source of truth for activity metrics and provides

@@ -771,7 +771,13 @@ class ActivityMetricsLogger {

   private void logAppDisplayed(WindowingModeTransitionInfoSnapshot info) {
        if (info.type != TYPE_TRANSITION_WARM_LAUNCH && info.type != TYPE_TRANSITION_COLD_LAUNCH) {
            return;
        }
        EventLog.writeEvent(AM_ACTIVITY_LAUNCH_TIME,
                info.userId, info.activityRecordIdHashCode, info.launchedActivityShortComponentName,
                info.windowsDrawnDelayMs);
// 根据日志判断当前进入lancher首页是哪个app




+         //add code start

+                if(info.launchedActivityName!=null && info.launchedActivityName.equals("cn.wps.moffice.documentmanager.PreStartActivity")){

+                        Settings.System.putInt(mContext.getContentResolver(), "show\_navigationbar", 0);

+                }else {

+                        Settings.System.putInt(mContext.getContentResolver(), "show\_navigationbar", 1);

+                }

+                //add code end

         StringBuilder sb = mStringBuilder;

         sb.setLength(0);

         sb.append("Displayed ");
        sb.append(info.launchedActivityShortComponentName);
        sb.append(": ");
        TimeUtils.formatDuration(info.windowsDrawnDelayMs, sb);
        Log.i(TAG, sb.toString());
    }

```

在logAppDisplayed中监听记录activity的显示和隐藏，然后设置show\_navigationbar的值


### 3.2 根据值来隐藏和显示导航栏



```
diff --git a/frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java b/frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java

old mode 100644

new mode 100755

index fe7a6d9fa0..3bb227fadf

--- a/frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java

+++ b/frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java

@@ -182,7 +182,7 @@ import com.android.server.wm.utils.InsetUtils;

 import java.io.PrintWriter;

 //unisoc: For Power Hint

 import android.os.PowerHintVendorSprd;

-

+import android.provider.Settings;

 /**

  * The policy that provides the basic behaviors and states of a display to show UI.

  */

@@ -488,6 +488,12 @@ public class DisplayPolicy extends AbsDisplayPolicy {

mSystemGestures = new SystemGesturesPointerEventListener(mContext, mHandler,
                new SystemGesturesPointerEventListener.Callbacks() {
                    @Override
                    public void onSwipeFromTop() {
                        if (mStatusBar != null) {
                            requestTransientBars(mStatusBar);
                        }
                    }

                    @Override
                    public void onSwipeFromBottom() {
                        if (mNavigationBar != null && mNavigationBarPosition == NAV_BAR_BOTTOM) {
                            requestTransientBars(mNavigationBar);
                            /**
                             * unisoc bug 1074912: add for dynamic navigationbar
                             * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                             * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                             */
                            if (mDynamicNavigationBar&&!mService.isKeyguardShowingAndNotOccluded()&&!isNavigationBarShowing()) {
                                Slog.d(TAG," onSwipeFromBottom show = true");
                                updateShowHideNavSettings(true);
                            }
                        }
                       //全局手势事件，判断如果是隐藏，然后显示导航栏
						//add code start
					    int showNavigationbarValue = Settings.System.getInt(mContext.getContentResolver(),"show\_navigationbar",0);
						if(showNavigationbarValue == 0){
						   Settings.System.putInt(mContext.getContentResolver(), "show\_navigationbar", 1);
					    }
						//add code end
                    }

                    @Override
                    public void onSwipeFromRight() {
                        final Region excludedRegion;
                        synchronized (mLock) {
                            excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
                        }
                        final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
                                || mNavigationBarPosition == NAV_BAR_RIGHT;
                        if (mNavigationBar != null && sideAllowed
                                && !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
                            requestTransientBars(mNavigationBar);
                        }
                        /**
                         * unisoc bug 1074912/1145137: add for dynamic navigationbar
                         * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                         * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                         */
                        if ((mNavigationBarPosition == NAV\_BAR\_RIGHT)&&mDynamicNavigationBar
 &&!mService.isKeyguardShowingAndNotOccluded()
 &&!isNavigationBarShowing()) {
                            Slog.d(TAG," onSwipeFromRight show = true");
                            updateShowHideNavSettings(true);
                         }
                    }

                    @Override
                    public void onSwipeFromLeft() {
                        final Region excludedRegion;
                        synchronized (mLock) {
                            excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
                        }
                        final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
                                || mNavigationBarPosition == NAV_BAR_LEFT;
                        if (mNavigationBar != null && sideAllowed
                                && !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
                            requestTransientBars(mNavigationBar);
                        }
                        /**
                         * unisoc bug 1074912/1145137: add for dynamic navigationbar
                         * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                         * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                         */
                        if ((mNavigationBarPosition == NAV\_BAR\_LEFT)&&mDynamicNavigationBar
 &&!mService.isKeyguardShowingAndNotOccluded()
 &&!isNavigationBarShowing()) {
                            Slog.d(TAG," onSwipeFromLeft show = true");
                            updateShowHideNavSettings(true);
                        }
                    }

                    @Override
                    public void onFling(int duration) {
                        if (mPerformance != null) mPerformance.scheduleBoostWhenTouch();
                        if (mService.mPowerManagerInternal != null) {
                            //unisoc: modify scene ID
                            mService.mPowerManagerInternal.powerHint(
                                    PowerHintVendorSprd.POWER_HINT_VENDOR_INTERACTION_FLING, duration);
                        }
                    }

                    @Override
                    public void onDebug() {
                        // no-op
                    }

                    private WindowOrientationListener getOrientationListener() {
                        final DisplayRotation rotation = mDisplayContent.getDisplayRotation();
                        return rotation != null ? rotation.getOrientationListener() : null;
                    }

                    @Override
                    public void onDown() {
                        if (mPerformance != null) mPerformance.scheduleBoostWhenTouch();
                        final WindowOrientationListener listener = getOrientationListener();
                        if (listener != null) {
                            listener.onTouchStart();
                        }

                    }

                    @Override
                    public void onUpOrCancel() {
                        if (mPerformance != null) mPerformance.scheduleBoostWhenTouch();
                        final WindowOrientationListener listener = getOrientationListener();
                        if (listener != null) {
                            listener.onTouchEnd();
                        }
                    }

                    @Override
                    public void onMouseHoverAtTop() {
                        mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
                        Message msg = mHandler.obtainMessage(MSG_REQUEST_TRANSIENT_BARS);
                        msg.arg1 = MSG_REQUEST_TRANSIENT_BARS_ARG_STATUS;
                        mHandler.sendMessageDelayed(msg, 500 /* delayMillis */);
                    }

                    @Override
                    public void onMouseHoverAtBottom() {
                        mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
                        Message msg = mHandler.obtainMessage(MSG_REQUEST_TRANSIENT_BARS);
                        msg.arg1 = MSG_REQUEST_TRANSIENT_BARS_ARG_NAVIGATION;
                        mHandler.sendMessageDelayed(msg, 500 /* delayMillis */);
                    }

                    @Override
                    public void onMouseLeaveFromEdge() {
                        mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
                    }
                });

```

在手势导航中的onSwipeFromBottom()根据设定的show\_navigationbar的值来设置是否显示导航栏





