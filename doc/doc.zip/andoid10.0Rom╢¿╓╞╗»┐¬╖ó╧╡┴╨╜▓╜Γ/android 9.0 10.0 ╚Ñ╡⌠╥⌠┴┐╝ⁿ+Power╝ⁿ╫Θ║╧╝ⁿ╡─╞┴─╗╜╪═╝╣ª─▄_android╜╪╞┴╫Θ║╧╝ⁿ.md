






### 1.概述


在10.0的系统中由WindowManagerService这个系统服务来循环读取窗口获取的消息（包括按下，弹起，双击，单击等）然后分发到各个类接收处理这些消息，在这个过程中PhoneWindowManager会进行消息过滤处理，PhoneWindowManager中有两个方法interceptKeyBeforeDispatching和interceptKeyBeforeQueueing，其中包括了几乎所有按键的处理，interceptKeyBeforeDispatching主要处理Home键、Menu键、Search键等，


interceptKeyBeforeQueueing主要处理音量键、电源键、耳机键等。接下来分析下源码


### 2.去掉音量键+Power键组合键的屏幕截图功能的核心类



```
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java

```

### 3.去掉音量键+Power键组合键的屏幕截图功能的核心功能分析和实现


通过上述对截图的功能分析，接下来看PhoneWindowManager.java的核心代码  
 interceptKeyBeforeQueueing（）如下:



```
// TODO(b/117479243): handle it in InputPolicy
    /** {@inheritDoc} */
    @Override
    public int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
        if (!mSystemBooted) {
            // If we have not yet booted, don't let key events do anything.
 return 0;
 }
 // add for control disable all the key operation while receive the emergency cb message
 if (mDisableAllKeyAction){
 return 0;
 }
 final boolean interactive = (policyFlags & FLAG\_INTERACTIVE) != 0;
 final boolean down = event.getAction() == KeyEvent.ACTION\_DOWN;
 final boolean canceled = event.isCanceled();
 final int keyCode = event.getKeyCode();
 final int displayId = event.getDisplayId();

 final boolean isInjected = (policyFlags & WindowManagerPolicy.FLAG\_INJECTED) != 0;

 // If screen is off then we treat the case where the keyguard is open but hidden
 // the same as if it were open and in front.
 // This will prevent any keys other than the power button from waking the screen
 // when the keyguard is hidden by another activity.
 final boolean keyguardActive = (mKeyguardDelegate == null ? false :
 (interactive ?
 isKeyguardShowingAndNotOccluded() :
 mKeyguardDelegate.isShowing()));

 if (DEBUG\_INPUT) {
 Log.d(TAG, "interceptKeyTq keycode=" + keyCode
 + " interactive=" + interactive + " keyguardActive=" + keyguardActive
 + " policyFlags=" + Integer.toHexString(policyFlags));
 }

 // Basic policy based on interactive state.
 int result;
 boolean isWakeKey = (policyFlags & WindowManagerPolicy.FLAG\_WAKE) != 0
 || event.isWakeKey();
 if (interactive || (isInjected && !isWakeKey)) {
 // When the device is interactive or the key is injected pass the
 // key to the application.
 result = ACTION\_PASS\_TO\_USER;
 isWakeKey = false;

 if (interactive) {
 // If the screen is awake, but the button pressed was the one that woke the device
 // then don't pass it to the application
                if (keyCode == mPendingWakeKey && !down) {
                    result = 0;
                }
                // Reset the pending key
                mPendingWakeKey = PENDING_KEY_NULL;
            }
        } else if (!interactive && shouldDispatchInputWhenNonInteractive(displayId, keyCode)) {
            // If we're currently dozing with the screen on and the keyguard showing, pass the key
 // to the application but preserve its wake key status to make sure we still move
 // from dozing to fully interactive if we would normally go from off to fully
 // interactive.
 result = ACTION\_PASS\_TO\_USER;
 // Since we're dispatching the input, reset the pending key
            mPendingWakeKey = PENDING_KEY_NULL;
        } else {
            // When the screen is off and the key is not injected, determine whether
            // to wake the device but don't pass the key to the application.
 result = 0;
 if (isWakeKey && (!down || !isWakeKeyWhenScreenOff(keyCode))) {
 isWakeKey = false;
 }
 // Cache the wake key on down event so we can also avoid sending the up event to the app
 if (isWakeKey && down) {
 mPendingWakeKey = keyCode;
 }
 }

 // If the key would be handled globally, just return the result, don't worry about special
        // key processing.
        if (isValidGlobalKey(keyCode)
                && mGlobalKeyManager.shouldHandleGlobalKey(keyCode, event)) {
            if (isWakeKey) {
                wakeUp(event.getEventTime(), mAllowTheaterModeWakeFromKey,
                        PowerManager.WAKE_REASON_WAKE_KEY, "android.policy:KEY");
            }
            return result;
        }

        // Enable haptics if down and virtual key without multiple repetitions. If this is a hard
        // virtual key such as a navigation bar button, only vibrate if flag is enabled.
        final boolean isNavBarVirtKey = ((event.getFlags() & KeyEvent.FLAG\_VIRTUAL\_HARD\_KEY) != 0);
 boolean useHapticFeedback = down
 && (policyFlags & WindowManagerPolicy.FLAG\_VIRTUAL) != 0
 && (!isNavBarVirtKey || mNavBarVirtualKeyHapticFeedbackEnabled)
 && event.getRepeatCount() == 0;

 // Handle special keys.
 switch (keyCode) {
 case KeyEvent.KEYCODE\_BACK: {
 /\*String enable=SystemProperties.get("persist.sys.nv.back", "false");
 android.util.Log.d("dong","onback enable:"+enable);
 if("true".equals(enable) ){
 break;
 }\*/
 if (down) {
 interceptBackKeyDown();
 } else {
 boolean handled = interceptBackKeyUp(event);

 // Don't pass back press to app if we've already handled it via long press
 if (handled) {
 result &= ~ACTION\_PASS\_TO\_USER;
 }
 }
 break;
 }

 case KeyEvent.KEYCODE\_VOLUME\_DOWN:
 case KeyEvent.KEYCODE\_VOLUME\_UP:
 case KeyEvent.KEYCODE\_VOLUME\_MUTE: {
 handleVolumeKey(event, policyFlags);
 if (down) {
 sendSystemKeyToStatusBarAsync(event.getKeyCode());

                    TelecomManager telecomManager = getTelecommService();
                    if (telecomManager != null && !mHandleVolumeKeysInWM) {
                        // When {@link #mHandleVolumeKeysInWM} is set, volume key events
                        // should be dispatched to WM.
                        if (telecomManager.isRinging()) {
                            // If an incoming call is ringing, either VOLUME key means
                            // "silence ringer".  We handle these keys here, rather than
                            // in the InCallScreen, to make sure we'll respond to them
 // even if the InCallScreen hasn't come to the foreground yet.
                            // Look for the DOWN event here, to agree with the "fallback"
                            // behavior in the InCallScreen.
                            Log.i(TAG, "interceptKeyBeforeQueueing:"
                                  + " VOLUME key-down while ringing: Silence ringer!");

                            // Silence the ringer.  (It's safe to call this
 // even if the ringer has already been silenced.)
 telecomManager.silenceRinger();

 // And \*don't* pass this key thru to the current activity
                            // (which is probably the InCallScreen.)
                            result &= ~ACTION_PASS_TO_USER;
                            break;
                        }
                    }
                    int audioMode = AudioManager.MODE_NORMAL;
                    try {
                        audioMode = getAudioService().getMode();
                    } catch (Exception e) {
                        Log.e(TAG, "Error getting AudioService in interceptKeyBeforeQueueing.", e);
                    }
                    boolean isInCall = (telecomManager != null && telecomManager.isInCall()) ||
                            audioMode == AudioManager.MODE_IN_COMMUNICATION;
                    if (isInCall && (result & ACTION_PASS_TO_USER) == 0) {
                        // If we are in call but we decided not to pass the key to
                        // the application, just pass it to the session service.
                        MediaSessionLegacyHelper.getHelper(mContext).sendVolumeKeyEvent(
                                event, AudioManager.USE_DEFAULT_STREAM_TYPE, false);
                        break;
                    }
                   //unisoc bug 1074917:add for Quick Capture
                   handleQuickCamera(event, down);
                }
                if (mUseTvRouting || mHandleVolumeKeysInWM) {
                    // Defer special key handlings to
                    // {@link interceptKeyBeforeDispatching()}.
                    result |= ACTION_PASS_TO_USER;
                } else if ((result & ACTION\_PASS\_TO\_USER) == 0) {
 // If we aren't passing to the user and no one else
 // handled it send it to the session manager to
 // figure out.
 MediaSessionLegacyHelper.getHelper(mContext).sendVolumeKeyEvent(
 event, AudioManager.USE\_DEFAULT\_STREAM\_TYPE, true);
 }
 break;
 }
 //unisoc bug 1074917:add for Quick Capture
 case KeyEvent.KEYCODE\_CAMERA: {
 handleQuickCamera(event, down);
 break;
 }
 case KeyEvent.KEYCODE\_ENDCALL: {
 result &= ~ACTION\_PASS\_TO\_USER;
 if (down) {
 TelecomManager telecomManager = getTelecommService();
 boolean hungUp = false;
 if (telecomManager != null) {
 hungUp = telecomManager.endCall();
 }
 if (interactive && !hungUp) {
 mEndCallKeyHandled = false;
 mHandler.postDelayed(mEndCallLongPress,
 ViewConfiguration.get(mContext).getDeviceGlobalActionKeyTimeout());
                    } else {
                        mEndCallKeyHandled = true;
                    }
                } else {
                    if (!mEndCallKeyHandled) {
                        mHandler.removeCallbacks(mEndCallLongPress);
                        if (!canceled) {
                            if ((mEndcallBehavior
 & Settings.System.END\_BUTTON\_BEHAVIOR\_HOME) != 0) {
 if (goHome()) {
                                    break;
                                }
                            }
                            if ((mEndcallBehavior
 & Settings.System.END\_BUTTON\_BEHAVIOR\_SLEEP) != 0) {
 goToSleep(event.getEventTime(),
 PowerManager.GO\_TO\_SLEEP\_REASON\_POWER\_BUTTON, 0);
 isWakeKey = false;
 }
 }
 }
 }
 break;
 }

 case KeyEvent.KEYCODE\_POWER: {
 EventLogTags.writeInterceptPower(
 KeyEvent.actionToString(event.getAction()),
                        mPowerKeyHandled ? 1 : 0, mPowerKeyPressCounter);
                // Any activity on the power button stops the accessibility shortcut
                cancelPendingAccessibilityShortcutAction();
                result &= ~ACTION_PASS_TO_USER;
                isWakeKey = false; // wake-up will be handled separately
                if (down) {
                    /*SPRD : add power debug log start*/
                    Slog.d(TAG, "Receive Input KeyEvent of Powerkey down");
                    /*SPRD : add power debug log end*/
                    interceptPowerKeyDown(event, interactive);
                } else {
                    /*SPRD : add power debug log start*/
                    Slog.d(TAG, "Receive Input KeyEvent of Powerkey up");
                    /*SPRD : add power debug log end*/
                    interceptPowerKeyUp(event, interactive, canceled);
                }
                break;
            }

            case KeyEvent.KEYCODE_SYSTEM_NAVIGATION_DOWN:
                // fall through
            case KeyEvent.KEYCODE_SYSTEM_NAVIGATION_UP:
                // fall through
            case KeyEvent.KEYCODE_SYSTEM_NAVIGATION_LEFT:
                // fall through
            case KeyEvent.KEYCODE_SYSTEM_NAVIGATION_RIGHT: {
                result &= ~ACTION_PASS_TO_USER;
                interceptSystemNavigationKey(event);
                break;
            }

            case KeyEvent.KEYCODE_SLEEP: {
                result &= ~ACTION_PASS_TO_USER;
                isWakeKey = false;
                if (!mPowerManager.isInteractive()) {
                    useHapticFeedback = false; // suppress feedback if already non-interactive
                }
                if (down) {
                    sleepPress();
                } else {
                    sleepRelease(event.getEventTime());
                }
                break;
            }
..
        }


```

在interceptKeyBeforeQueueing(KeyEvent event, int policyFlags)的源码中，发现在对  
 音量处理的方法中是在handleVolumeKey(KeyEvent event, int policyFlags)中处理音量的  
 处理音量键的方法：



```
//UNISOC BUG1162036  do not intercept special function for volume key
    public void handleVolumeKey(KeyEvent event, int policyFlags){
        final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        final int keyCode = event.getKeyCode();
        final boolean interactive = (policyFlags & FLAG_INTERACTIVE) != 0;
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (down) {
                // Any activity on the vol down button stops the ringer toggle shortcut
                cancelPendingRingerToggleChordAction();

                if (interactive && !mScreenshotChordVolumeDownKeyTriggered
                        && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
                    mScreenshotChordVolumeDownKeyTriggered = true;
                    mScreenshotChordVolumeDownKeyTime = event.getDownTime();
                    mScreenshotChordVolumeDownKeyConsumed = false;
                    cancelPendingPowerKeyAction();
                    interceptScreenshotChord();
                    interceptAccessibilityShortcutChord();
                }
            } else {
                mScreenshotChordVolumeDownKeyTriggered = false;
                cancelPendingScreenshotChordAction();
                cancelPendingAccessibilityShortcutAction();
            }
        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (down) {
                if (interactive && !mA11yShortcutChordVolumeUpKeyTriggered
                        && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
                    mA11yShortcutChordVolumeUpKeyTriggered = true;
                    mA11yShortcutChordVolumeUpKeyTime = event.getDownTime();
                    mA11yShortcutChordVolumeUpKeyConsumed = false;
                    cancelPendingPowerKeyAction();
                    cancelPendingScreenshotChordAction();
                    cancelPendingRingerToggleChordAction();

                    interceptAccessibilityShortcutChord();
                    interceptRingerToggleChord();
                }
            } else {
                mA11yShortcutChordVolumeUpKeyTriggered = false;
                cancelPendingScreenshotChordAction();
                cancelPendingAccessibilityShortcutAction();
                cancelPendingRingerToggleChordAction();
            }
        }
        return;
    }

```

在上述方法中，发现对电源键处理的代码是在interceptPowerKeyDown(KeyEvent event, boolean interactive) 中，接下来看具体的源码  
 处理power键的地方：



```
 private void interceptPowerKeyDown(KeyEvent event, boolean interactive) {
        // Hold a wake lock until the power key is released.
        if (!mPowerKeyWakeLock.isHeld()) {
            mPowerKeyWakeLock.acquire();
        }

        // Cancel multi-press detection timeout.
        if (mPowerKeyPressCounter != 0) {
            mHandler.removeMessages(MSG_POWER_DELAYED_PRESS);
        }

        mWindowManagerFuncs.onPowerKeyDown(interactive);

        // Latch power key state to detect screenshot chord.
        if (interactive && !mScreenshotChordPowerKeyTriggered
                && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
            mScreenshotChordPowerKeyTriggered = true;
            mScreenshotChordPowerKeyTime = event.getDownTime();
            interceptScreenshotChord();
            interceptRingerToggleChord();
        }

        // Stop ringing or end call if configured to do so when power is pressed.
        TelecomManager telecomManager = getTelecommService();
        boolean hungUp = false;
        if (telecomManager != null) {
            if (telecomManager.isRinging()) {
                // Pressing Power while there's a ringing incoming
 // call should silence the ringer.
 telecomManager.silenceRinger();
 } else if ((mIncallPowerBehavior
 & Settings.Secure.INCALL\_POWER\_BUTTON\_BEHAVIOR\_HANGUP) != 0
 && telecomManager.isInCall() && interactive) {
 // Otherwise, if "Power button ends call" is enabled,
 // the Power button will hang up any current active call.
 hungUp = telecomManager.endCall();
 }
 }

 //SprdGestureLauncherService gestureService = LocalServices.getService(
 // SprdGestureLauncherService.class);
 boolean gesturedServiceIntercepted = false;
 if (getGestureLauncherService()) {
 gesturedServiceIntercepted = mGestureService.interceptPowerKeyDown(event, interactive,
 mTmpBoolean, isScreenOn(), hasInPowerUtrlSavingMode());
 if (mTmpBoolean.value && mRequestedOrGoingToSleep) {
 mCameraGestureTriggeredDuringGoingToSleep = true;
 }
 }

 // Inform the StatusBar; but do not allow it to consume the event.
 sendSystemKeyToStatusBarAsync(event.getKeyCode());

 schedulePossibleVeryLongPressReboot();

 // If the power key has still not yet been handled, then detect short
 // press, long press, or multi press and decide what to do.
 mPowerKeyHandled = hungUp || mScreenshotChordVolumeDownKeyTriggered
 || mA11yShortcutChordVolumeUpKeyTriggered || gesturedServiceIntercepted;
 if (!mPowerKeyHandled) {
 if (interactive) {
 // When interactive, we're already awake.
                // Wait for a long press or for the button to be released to decide what to do.
                if (hasLongPressOnPowerBehavior()) {
                    if ((event.getFlags() & KeyEvent.FLAG\_LONG\_PRESS) != 0) {
 powerLongPress();
 } else {
 Message msg = mHandler.obtainMessage(MSG\_POWER\_LONG\_PRESS);
 msg.setAsynchronous(true);
 mHandler.sendMessageDelayed(msg,
 ViewConfiguration.get(mContext).getDeviceGlobalActionKeyTimeout());

                        if (hasVeryLongPressOnPowerBehavior()) {
                            Message longMsg = mHandler.obtainMessage(MSG_POWER_VERY_LONG_PRESS);
                            longMsg.setAsynchronous(true);
                            mHandler.sendMessageDelayed(longMsg, mVeryLongPressTimeout);
                        }
                    }
                }
            } else {
                wakeUpFromPowerKey(event.getDownTime());

                if (mSupportLongPressPowerWhenNonInteractive && hasLongPressOnPowerBehavior()) {
                    if ((event.getFlags() & KeyEvent.FLAG\_LONG\_PRESS) != 0) {
 powerLongPress();
 } else {
 Message msg = mHandler.obtainMessage(MSG\_POWER\_LONG\_PRESS);
 msg.setAsynchronous(true);
 mHandler.sendMessageDelayed(msg,
 ViewConfiguration.get(mContext).getDeviceGlobalActionKeyTimeout());

                        if (hasVeryLongPressOnPowerBehavior()) {
                            Message longMsg = mHandler.obtainMessage(MSG_POWER_VERY_LONG_PRESS);
                            longMsg.setAsynchronous(true);
                            mHandler.sendMessageDelayed(longMsg, mVeryLongPressTimeout);
                        }
                    }

                    mBeganFromNonInteractive = true;
                } else {
                    final int maxCount = getMaxMultiPressPowerCount();

                    if (maxCount <= 1) {
                        mPowerKeyHandled = true;
                    } else {
                        mBeganFromNonInteractive = true;
                    }
                }
            }
        }
    }

```

而通过上述源码分析在这里的屏幕截图功能是在interceptScreenshotChord()处理的截图事件  
 截图功能:



```
  private void interceptScreenshotChord() {
        if (mScreenshotChordEnabled
                && mScreenshotChordVolumeDownKeyTriggered && mScreenshotChordPowerKeyTriggered
                && !mA11yShortcutChordVolumeUpKeyTriggered) {
            final long now = SystemClock.uptimeMillis();
            if (now <= mScreenshotChordVolumeDownKeyTime + SCREENSHOT_CHORD_DEBOUNCE_DELAY_MILLIS
                    && now <= mScreenshotChordPowerKeyTime
                            + SCREENSHOT_CHORD_DEBOUNCE_DELAY_MILLIS) {
                mScreenshotChordVolumeDownKeyConsumed = true;
                if(hasInPowerUtrlSavingMode()){
                    Slog.d(TAG,"In power ULTRA saving mode: Do not allow to take screen shot");
                    return;
                }
                cancelPendingPowerKeyAction();
                mScreenshotRunnable.setScreenshotType(TAKE_SCREENSHOT_FULLSCREEN);
                mHandler.postDelayed(mScreenshotRunnable, getScreenshotChordLongPressDelay());
            }
        }
    }

```

所以解决方案如下:  
 在power键和 音量键处理地方 去掉截图功能即可:  
 如下：



```
--- a/frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
+++ b/frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
@@ -1015,7 +1015,7 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
                 && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
             mScreenshotChordPowerKeyTriggered = true;
             mScreenshotChordPowerKeyTime = event.getDownTime();
-            interceptScreenshotChord();
+            //interceptScreenshotChord();
             interceptRingerToggleChord();
         }
 
@@ -4328,7 +4328,7 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
                     mScreenshotChordVolumeDownKeyTime = event.getDownTime();
                     mScreenshotChordVolumeDownKeyConsumed = false;
                     cancelPendingPowerKeyAction();
-                    interceptScreenshotChord();
+                    //interceptScreenshotChord();
                     interceptAccessibilityShortcutChord();
                 }
             } else {

```

通过对组合键处理的时候去掉interceptScreenshotChord();这个截图功能，就实现了去掉屏幕截图的功能





