






### 1.概述


在10.0的系统产品开发中，要实现负一屏功能，而在8.1以前的版本中，都带有负一屏功能，但是在9.0以后就被取消掉了，由于客户需要只能参考8.1来实现负一屏功能了  
 效果图：


![在这里插入图片描述](https://img-blog.csdnimg.cn/56e7041cee414d6f8a51f734f7d0398b.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_12,color_FFFFFF,t_70,g_se,x_16#pic_center)  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/96c53c28a84d423ab7166fa70545ba75.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_12,color_FFFFFF,t_70,g_se,x_16#pic_center)


### 2.Launcher3添加负一屏(左一屏)功能的核心类



```
/packages/apps/Launcher3/src/com/android/launcher3/Launcher.java

```

### 3.Launcher3添加负一屏(左一屏)功能的核心功能分析和实现


### 3.1 Launcher中负一屏主要功能的实现


首先在Launcher3相关源码中出发来实现功能，首先要在bindScreens(IntArray orderedScreenIds)中加载负一屏的相关源码



```
         /**
@@ -2064,13 +2078,42 @@ public class Launcher extends BaseDraggingActivity implements LauncherExterns,
             mWorkspace.addExtraEmptyScreen();
         }
         bindAddScreens(orderedScreenIds);
-
+        // Create the custom content page (this call updates mDefaultScreen which calls
+        // setCurrentPage() so ensure that all pages are added before calling this).
+        if (hasCustomContentToLeft()) {
+            mWorkspace.createCustomContentContainer();
+            populateCustomContentContainer();
+        }
         // After we have added all the screens, if the wallpaper was locked to the default state,
         // then notify to indicate that it can be released and a proper wallpaper offset can be
         // computed before the next layout
         mWorkspace.unlockWallpaperFromDefaultPageOnNextLayout();
     }
+    /** To be overridden by subclasses to hint to Launcher that we have custom content */
+    protected boolean hasCustomContentToLeft() {
+        if (mLauncherCallbacks != null) {
+            //return mLauncherCallbacks.hasCustomContentToLeft();
+                       return true;
+        }
+        return true;
+    }
+    /**
+     * To be overridden by subclasses to populate the custom content container and call
+     * {@link #addToCustomContentPage}. This will only be invoked if
+     * {@link #hasCustomContentToLeft()} is {@code true}.
+     */
+    protected void populateCustomContentContainer() {
+        if (mLauncherCallbacks != null) {
+            mLauncherCallbacks.populateCustomContentContainer();
+        }
+               mBoardModel.inflateCustomContent(Launcher.this);
+    }

```

在这里加载负一屏的相关功能实现，具体实现在Workspace中实现的


workspace.java 修改部分比较多修改如下:


### 3.2 workspace.java关于负一屏主要功能实现



```
@@ -153,7 +154,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
     @Thunk final IntSparseArrayMap<CellLayout> mWorkspaceScreens = new IntSparseArrayMap<>();
     @Thunk final IntArray mScreenOrder = new IntArray();
     @Thunk final IntArray mDropPendingScreens = new IntArray();
-
+    private String mCustomContentDescription = "";
     // Save runnable info when the workspace is loading.
     @Thunk PendingScreenResultInfo mPendingScreenResult;
 
@@ -185,7 +186,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
      * The CellLayout which will be dropped to
      */
     private CellLayout mDropToLayout = null;
-
+    CustomContentCallbacks mCustomContentCallbacks;
     @Thunk final Launcher mLauncher;
     @Thunk DragController mDragController;
 
@@ -196,6 +197,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
     private final float[] mTempTouchCoordinates = new float[2];
 
     private SpringLoadedDragController mSpringLoadedDragController;
+    private final float mOverviewModeShrinkFactor;
 
     private boolean mIsSwitchingState = false;
 
@@ -242,7 +244,9 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
     private int mDragMode = DRAG_MODE_NONE;
     @Thunk int mLastReorderX = -1;
     @Thunk int mLastReorderY = -1;
-
+    private final static int CUSTOM_CONTENT_SCREEN_ID = -301;
+    private static final long CUSTOM_CONTENT_GESTURE_DELAY = 200;
+    private float mLastCustomContentScrollProgress = -1f;
     private SparseArray<Parcelable> mSavedStates;
     private final IntArray mRestoredPages = new IntArray();
 
@@ -296,6 +300,8 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         mWallpaperManager = WallpaperManager.getInstance(context);
 
         mWallpaperOffset = new WallpaperOffsetInterpolator(this);
+        mOverviewModeShrinkFactor =
+                70 / 100f;
 
         setHapticFeedbackEnabled(false);
         initWorkspace();
@@ -499,6 +505,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         mCurrentPage = DEFAULT_PAGE;
         setClipToPadding(false);
 
+        setMinScale(mOverviewModeShrinkFactor);
         setupLayoutTransition();
 
         // Set the wallpaper dimensions when Launcher starts up
@@ -590,7 +597,9 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         if (qsb != null) {
             ((ViewGroup) qsb.getParent()).removeView(qsb);
         }
-
+        if (hasCustomContent()) {
+            removeCustomContentPage();
+        }
         // Remove the pages and clear the screen models
         removeFolderListeners();
         removeAllViews();
@@ -651,7 +660,26 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
 
         return newScreen;
     }
+    public void removeCustomContentPage() {
+        CellLayout customScreen = getScreenWithId(CUSTOM_CONTENT_SCREEN_ID);
+        if (customScreen == null) {
+            throw new RuntimeException("Expected custom content screen to exist");
+        }
+
+        mWorkspaceScreens.remove(CUSTOM_CONTENT_SCREEN_ID);
+        mScreenOrder.removeValue(CUSTOM_CONTENT_SCREEN_ID);
+        removeView(customScreen);
+
+        if (mCustomContentCallbacks != null) {
+            mCustomContentCallbacks.onScrollProgressChanged(0);
+            mCustomContentCallbacks.onHide();
+        }
 
+        mCustomContentCallbacks = null;
+
+        // Update the custom content hint
+        setCurrentPage(getCurrentPage() - 1);
+    }
     public void addExtraEmptyScreenOnDrag() {
         boolean lastChildOnScreen = false;
         boolean childOnFinalScreen = false;
@@ -695,6 +723,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         if (hasExtraEmptyScreen() || mScreenOrder.size() == 0) return;
         int finalScreenId = mScreenOrder.get(mScreenOrder.size() - 1);
 
+        if (finalScreenId == CUSTOM_CONTENT_SCREEN_ID) return;
         CellLayout finalScreen = mWorkspaceScreens.get(finalScreenId);
 
         // If the final screen is empty, convert it to the extra empty screen
@@ -808,7 +837,9 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
     }
 
     public boolean hasExtraEmptyScreen() {
-        return mWorkspaceScreens.containsKey(EXTRA_EMPTY_SCREEN_ID) && getChildCount() > 1;
+        int nScreens = getChildCount();
+        nScreens = nScreens - numCustomPages();
+        return mWorkspaceScreens.containsKey(EXTRA_EMPTY_SCREEN_ID) && nScreens > 1;
     }
 
     public int commitExtraEmptyScreen() {
@@ -970,6 +1001,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
             mXDown = ev.getX();
             mYDown = ev.getY();
+            mTouchDownTime = System.currentTimeMillis();
         }
         return super.onInterceptTouchEvent(ev);
     }
@@ -990,7 +1022,23 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         if (absDeltaX > mTouchSlop || absDeltaY > mTouchSlop) {
             cancelCurrentPageLongPress();
         }
+        boolean passRightSwipesToCustomContent =
+                (mTouchDownTime - mCustomContentShowTime) > CUSTOM_CONTENT_GESTURE_DELAY;
 
+        boolean swipeInIgnoreDirection = mIsRtl ? deltaX < 0 : deltaX > 0;
+        boolean onCustomContentScreen =
+                getScreenIdForPageIndex(getCurrentPage()) == CUSTOM_CONTENT_SCREEN_ID;
+        if (swipeInIgnoreDirection && onCustomContentScreen && passRightSwipesToCustomContent) {
+            // Pass swipes to the right to the custom content page.
+            return;
+        }
+
+        if (onCustomContentScreen && (mCustomContentCallbacks != null)
+                && !mCustomContentCallbacks.isScrollingAllowed()) {
+            // Don't allow workspace scrolling if the current custom content screen doesn't allow
+            // scrolling.
+            return;
+        }
         if (theta > MAX_SWIPE_ANGLE) {
             // Above MAX_SWIPE_ANGLE, we don't want to ever start scrolling the workspace
             return;
@@ -1089,6 +1137,7 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         }
 
         updatePageAlphaValues();
+        updateStateForCustomContent();
         enableHwLayersOnVisiblePages();
     }
 
@@ -1256,6 +1305,18 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
             mLauncher.getUserEventDispatcher().logActionOnContainer(Action.Touch.SWIPE,
                     swipeDirection, ContainerType.WORKSPACE, prevPage);
         }
+        if (hasCustomContent() && getNextPage() == 0 && !mCustomContentShowing) {
+            mCustomContentShowing = true;
+            if (mCustomContentCallbacks != null) {
+                mCustomContentCallbacks.onShow(false);
+                mCustomContentShowTime = System.currentTimeMillis();
+            }
+        } else if (hasCustomContent() && getNextPage() != 0 && mCustomContentShowing) {
+            mCustomContentShowing = false;
+            if (mCustomContentCallbacks != null) {
+                mCustomContentCallbacks.onHide();
+            }
+        }
     }
 
     protected void setWallpaperDimension() {
@@ -1329,7 +1390,60 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
             }
         }
     }
+    public boolean hasCustomContent() {
+        return (mScreenOrder.size() > 0 && mScreenOrder.get(0) == CUSTOM_CONTENT_SCREEN_ID);
+    }
+
+    public int numCustomPages() {
+        return hasCustomContent() ? 1 : 0;
+    }
+    private void updateStateForCustomContent() {
+        float translationX = 0;
+        float progress = 0;
+        if (hasCustomContent()) {
+            int index = mScreenOrder.indexOf(CUSTOM_CONTENT_SCREEN_ID);
+
+            int scrollDelta = getScrollX() - getScrollForPage(index) -
+                    getLayoutTransitionOffsetForPage(index);
+            float scrollRange = getScrollForPage(index + 1) - getScrollForPage(index);
+            translationX = scrollRange - scrollDelta;
+            progress = (scrollRange - scrollDelta) / scrollRange;
+
+            if (mIsRtl) {
+                translationX = Math.min(0, translationX);
+            } else {
+                translationX = Math.max(0, translationX);
+            }
+            progress = Math.max(0, progress);
+        }
+
+        if (Float.compare(progress, mLastCustomContentScrollProgress) == 0) return;
+
+        CellLayout cc = mWorkspaceScreens.get(CUSTOM_CONTENT_SCREEN_ID);
+        if (progress > 0 && cc.getVisibility() != VISIBLE && !workspaceInModalState()) {
+            cc.setVisibility(VISIBLE);
+        }
 
+        mLastCustomContentScrollProgress = progress;
+
+        // We should only update the drag layer background alpha if we are not in all apps or the
+        // widgets tray
+        /*if (mState == State.NORMAL) {
+            mLauncher.getDragLayer().setBackgroundAlpha(progress == 1 ? 0 : progress * 0.8f);
+        }*/
+
+        if (mLauncher.getHotseat() != null) {
+            mLauncher.getHotseat().setTranslationX(translationX);
+        }
+
+        if (mPageIndicator != null) {
+            mPageIndicator.setTranslationX(translationX);
+        }
+
+        if (mCustomContentCallbacks != null) {
+            mCustomContentCallbacks.onScrollProgressChanged(progress);
+        }
+    }  
     protected void onAttachedToWindow() {
         super.onAttachedToWindow();
         IBinder windowToken = getWindowToken();
@@ -1777,6 +1891,11 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
 
     boolean createUserFolderIfNecessary(View newView, int container, CellLayout target,
             int[] targetCell, float distance, boolean external, DragView dragView) {
+        //core begin
+        if (container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
+            return false;
+        }
+        //core end
         if (distance > mMaxDistanceForFolderCreation) return false;
         View v = target.getChildAt(targetCell[0], targetCell[1]);
 
@@ -1831,7 +1950,62 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
         }
         return false;
     }
+    float getOverviewModeShrinkFactor() {
+        return mOverviewModeShrinkFactor;
+    }
+    public void createCustomContentContainer() {
+        CellLayout customScreen = (CellLayout)
+                mLauncher.getLayoutInflater().inflate(R.layout.workspace_screen, this, false);
+        customScreen.disableDragTarget();
+        customScreen.disableJailContent();
+
+        mWorkspaceScreens.put(CUSTOM_CONTENT_SCREEN_ID, customScreen);
+        mScreenOrder.add(0, CUSTOM_CONTENT_SCREEN_ID);
+
+        // We want no padding on the custom content
+        customScreen.setPadding(0, 0, 0, 0);
+
+        addFullScreenPage(customScreen);
+
+        // Update the custom content hint
+        setCurrentPage(getCurrentPage() + 1);
+    }
+    protected CustomContentCallbacks getCustomContentCallbacks() {
+        return mCustomContentCallbacks;
+    }
+    public void addToCustomContentPage(View customContent, CustomContentCallbacks callbacks,
+            String description) {
+        if (getPageIndexForScreenId(CUSTOM_CONTENT_SCREEN_ID) < 0) {
+            //throw new RuntimeException("Expected custom content screen to exist");
+                       createCustomContentContainer();
+        }
 
+        // Add the custom content to the full screen custom page
+        CellLayout customScreen = getScreenWithId(CUSTOM_CONTENT_SCREEN_ID);
+        int spanX = customScreen.getCountX();
+        int spanY = customScreen.getCountY();
+        CellLayout.LayoutParams lp = new CellLayout.LayoutParams(0, 0, spanX, spanY);
+        lp.canReorder  = false;
+        lp.isFullscreen = true;
+        if (customContent instanceof Insettable) {
+            ((Insettable)customContent).setInsets(mInsets);
+ }
+
+ // Verify that the child is removed from any existing parent.
+ if (customContent.getParent() instanceof ViewGroup) {
+ ViewGroup parent = (ViewGroup) customContent.getParent();
+ parent.removeView(customContent);
+ }
+ customScreen.removeAllViews();
+ customContent.setFocusable(true);
+ customContent.setOnKeyListener(new FullscreenKeyEventListener());
+        customContent.setOnFocusChangeListener(mLauncher.mFocusHandler
+                .getHideIndicatorOnFocusListener());
+        customScreen.addViewToCellLayout(customContent, 0, 0, lp, true);
+        mCustomContentDescription = description;
+
+        mCustomContentCallbacks = callbacks;
+    }
     boolean addToExistingFolderIfNecessary(View newView, CellLayout target, int[] targetCell,
             float distance, DragObject d, boolean external) {
         if (distance > mMaxDistanceForFolderCreation) return false;
@@ -3513,12 +3687,16 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
 
     @Override
     protected String getCurrentPageDescription() {
+        if (hasCustomContent() && getNextPage() == 0) {
+            return mCustomContentDescription;
+        }
         int page = (mNextPage != INVALID_PAGE) ? mNextPage : mCurrentPage;
         return getPageDescription(page);
     }
 
     private String getPageDescription(int page) {
-        int nScreens = getChildCount();
+        int delta = numCustomPages();
+        int nScreens = getChildCount() - delta;
         int extraScreenId = mScreenOrder.indexOf(EXTRA_EMPTY_SCREEN_ID);
         if (extraScreenId >= 0 && nScreens > 1) {
             if (page == extraScreenId) {

```

在Workspace中，添加了对CellLayout中相关源码的调用来实现添加负一屏的数据，  
 在Workspace中绑定这些数据，或者左右滑动来加载这些数据，负一屏的主要工作就是在这里面完成的，所以这里也是非常重要的功能实现  
 CellLayout.java 和LauncherCallbacks.java,PagedView.java 等也做了部分修改


[具体请往这里看](https://download.csdn.net/download/baidu_41666295/20814285?spm=1001.2014.3001.5503):





