






### 1.概述


在10.0的系统产品开发中，在对ota升级中，由于要固定使用本机mac地址，所以不能让选择默认mac地址，这时就要修改默认设置，保证升级能够成功


### 2.Settings 中wifi详情页 隐私默认选中设备mac的核心类



```
packages\apps\Settings\src\com\android\settings\wifi\details\WifiNetworkDetailsFragment.java
packages\apps\Settings\src\com\android\settings\wifi\details\WifiPrivacyPreferenceController.java

```

### 3.Settings 中wifi详情页 隐私默认选中设备mac的核心功能分析和实现通过


在系统设置中，对于wifi详情页的通过adb shell命令发现wifi详情页的类


首选来看下wifi连接后的详情页源码 WifiNetworkDetailsFragment.java  
 路径: packages\apps\Settings\src\com\android\settings\wifi\details\WifiNetworkDetailsFragment.java



```
public class WifiNetworkDetailsFragment extends DashboardFragment implements
        WifiDialog.WifiDialogListener, DialogInterface.OnDismissListener {

    private static final String TAG = "WifiNetworkDetailsFrg";

    private AccessPoint mAccessPoint;
    private WifiDetailPreferenceController mWifiDetailPreferenceController;
    private List<WifiDialog.WifiDialogListener> mWifiDialogListeners = new ArrayList<>();

    private WifiDialog mDialog;
    private static final int REQUEST_CODE_WIFI_DPP_ENROLLEE_QR_CODE_SCANNER = 0;

    @Override
    public void onAttach(Context context) {
        mAccessPoint = new AccessPoint(context, getArguments());
        super.onAttach(context);
    }

    @Override
    public int getMetricsCategory() {
        return SettingsEnums.WIFI_NETWORK_DETAILS;
    }

    @Override
    protected String getLogTag() {
        return TAG;
    }

    @Override
    protected int getPreferenceScreenResId() {
        return R.xml.wifi_network_details_fragment;
    }
    @Override
     public Dialog onCreateDialog(int dialogId) {
         if (getActivity() == null || mWifiDetailPreferenceController == null
                 || mAccessPoint == null) {
             return null;
         }
         return WifiDialog.createModal(getActivity(), this, mAccessPoint,
                 WifiConfigUiBase.MODE_MODIFY);
     }
 
 
     @Override
      public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
          MenuItem item = menu.add(0, Menu.FIRST, 0, R.string.wifi_modify);
          item.setIcon(com.android.internal.R.drawable.ic_mode_edit);
          item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
          super.onCreateOptionsMenu(menu, inflater);
      }
  
      @Override
      protected List<AbstractPreferenceController> createPreferenceControllers(Context context) {
          final List<AbstractPreferenceController> controllers = new ArrayList<>();
          final ConnectivityManager cm = context.getSystemService(ConnectivityManager.class);
  
          mWifiDetailPreferenceController = WifiDetailPreferenceController.newInstance(
                  mAccessPoint,
                  cm,
                  context,
                  this,
                  new Handler(Looper.getMainLooper()),  // UI thread.
                  getSettingsLifecycle(),
                  context.getSystemService(WifiManager.class),
                  mMetricsFeatureProvider);
  
          controllers.add(mWifiDetailPreferenceController);
          controllers.add(new AddDevicePreferenceController(context).init(mAccessPoint));
  
          final WifiMeteredPreferenceController meteredPreferenceController =
                  new WifiMeteredPreferenceController(context, mAccessPoint.getConfig());
          controllers.add(meteredPreferenceController);
  
          final WifiPrivacyPreferenceController privacyController =
                  new WifiPrivacyPreferenceController(context);
          privacyController.setWifiConfiguration(mAccessPoint.getConfig());
          privacyController.setIsEphemeral(mAccessPoint.isEphemeral());
          privacyController.setIsPasspoint(
                  mAccessPoint.isPasspoint() || mAccessPoint.isPasspointConfig());
          controllers.add(privacyController);
  
          // Sets callback listener for wifi dialog.
          mWifiDialogListeners.add(mWifiDetailPreferenceController);
          mWifiDialogListeners.add(privacyController);
          mWifiDialogListeners.add(meteredPreferenceController);
  
          return controllers;
      }

```

从WifiNetworkDetailsFragment的源码发现  
 而他实际操作事件是在WifiPrivacyPreferenceController.java  
 路径: packages\apps\Settings\src\com\android\settings\wifi\details\WifiPrivacyPreferenceController.java


接下来看WifiPrivacyPreferenceController.java 源码



```
@Override
public void updateState(Preference preference) {
    final DropDownPreference dropDownPreference = (DropDownPreference) preference;
    final int randomizationLevel = getRandomizationValue();
    dropDownPreference.setValue(Integer.toString(randomizationLevel));
    updateSummary(dropDownPreference, randomizationLevel);

    // Makes preference not selectable, when this is a ephemeral network.
    if (mIsEphemeral || mIsPasspoint) {
        preference.setSelectable(false);
        dropDownPreference.setSummary(R.string.wifi_privacy_settings_ephemeral_summary);
    }
}

@Override
public boolean onPreferenceChange(Preference preference, Object newValue) {
	android.util.Log.e("privacy","newValue："+(String) newValue);
    if (mWifiConfiguration != null) {
        mWifiConfiguration.macRandomizationSetting = 1/*Integer.parseInt((String) newValue)*/;
        mWifiManager.updateNetwork(mWifiConfiguration);

        // To activate changing, we need to reconnect network. WiFi will auto connect to
        // current network after disconnect(). Only needed when this is connected network.
        final WifiInfo wifiInfo = mWifiManager.getConnectionInfo();
        if (wifiInfo != null && wifiInfo.getNetworkId() == mWifiConfiguration.networkId) {
            mWifiManager.disconnect();
        }
    }
    updateSummary((DropDownPreference) preference, 1/*Integer.parseInt((String) newValue)*/);
    return true;
}

```

onPreferenceChange负责当DropDownPreference 改变时设置WifiConfiguration的值，  
 在translateMacRandomizedValueToPrefValue设置mac的随机还是固定mac



```
/**
 * Returns preference index value.
 *
 * @param macRandomized is mac randomized value
 * @return index value of preference
 */
public static int translateMacRandomizedValueToPrefValue(int macRandomized) {
    return 1/*(macRandomized == WifiConfiguration.RANDOMIZATION_PERSISTENT)
        ? PREF_RANDOMIZATION_PERSISTENT : PREF_RANDOMIZATION_NONE*/;
}

```

修改translateMacRandomizedValueToPrefValue 返回值为1 就可





