






在SystemUI种下拉通知栏也是SystemUI重要的一个部分，对其进行定制化修改，也是常有的工作范围  
 接下来就来对其的ui进行定制 做背景圆角处理


在通知栏布局都是由NotificationStackScrollLayout.java 来负责显示的  
 而每一条消息是有status\_bar\_notification\_row.xml 来负责显示的  
 所以对通知的圆角修改如下:



```
diff --git a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml

old mode 100644 (file)

new mode 100755 (executable)

index 84b9e3d..45a2408

--- a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml

+++ b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml

@@ -39,12 +39,13 @@

     <com.android.systemui.statusbar.notification.row.NotificationContentView

         android:id="@+id/expanded"

        android:layout_width="match\_parent"

-       android:layout_height="wrap\_content" />

+       android:layout_height="wrap\_content"

+          android:background="@drawable/qs\_background\_primary"/>

 

     <com.android.systemui.statusbar.notification.row.NotificationContentView

         android:id="@+id/expandedPublic"

         android:layout_width="match\_parent"

-        android:layout_height="wrap\_content" />

+        android:layout_height="wrap\_content"           />

 

     <Button

         android:id="@+id/veto"

@@ -63,6 +64,7 @@

         android:inflatedId="@+id/notification\_children\_container"

         android:layout_width="match\_parent"

         android:layout_height="wrap\_content"

+               android:background="@drawable/qs\_background\_primary"

         />

 

     <ViewStub

diff --git a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml

old mode 100644 (file)

new mode 100755 (executable)

index 508619a..8ce904d

--- a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml

+++ b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml

@@ -21,6 +21,7 @@

     android:layout_height="@dimen/notification\_section\_header\_height"

     android:focusable="true"

     android:clickable="true"

+       android:background="@drawable/qs\_background\_primary"

     >

 

     <com.android.systemui.statusbar.notification.row.NotificationBackgroundView

@@ -38,6 +39,7 @@

         android:layout_height="match\_parent"

         android:gravity="center\_vertical"

         android:orientation="horizontal"

+               android:background="@drawable/qs\_background\_primary"

         >

         <include layout="@layout/status\_bar\_notification\_section\_header\_contents"/>

     </LinearLayout>

```

2.对于NotificationContentView的圆角处理是在父类ActivatableNotificationView.java种处理的  
 具体修改如下



```
+++ 
a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ActivatableNotificationView.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ActivatableNotificationView.java

@@ -233,8 +233,8 @@ public abstract class ActivatableNotificationView extends ExpandableOutlineView

      * be useful in a configuration change.

      */

     protected void initBackground() {

-        mBackgroundNormal.setCustomBackground(R.drawable.notification_material_bg);

-        mBackgroundDimmed.setCustomBackground(R.drawable.notification_material_bg_dim);

+        mBackgroundNormal.setCustomBackground(R.drawable.qs_background_primary);

+        mBackgroundDimmed.setCustomBackground(R.drawable.qs_background_primary);

     }

 

     private final Runnable mTapTimeoutRunnable = new Runnable() {

index 0bc1acd..de78bfd 100755 (executable)

```

3.对NotificationStackScrollLayout.java 种一些灰色背景的处理如下：  
 a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java



```
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java

@@ -100,6 +100,7 @@ import com.android.systemui.statusbar.AmbientPulseManager;

 import com.android.systemui.statusbar.CommandQueue;

 import com.android.systemui.statusbar.DragDownHelper.DragDownCallback;

 import com.android.systemui.statusbar.EmptyShadeView;

+import com.android.systemui.statusbar.NotificationTipView;

 import com.android.systemui.statusbar.NotificationLockscreenUserManager;

 import com.android.systemui.statusbar.NotificationRemoteInputManager;

 import com.android.systemui.statusbar.NotificationShelf;

@@ -153,7 +154,7 @@ import java.util.Comparator;

 import java.util.HashSet;

 import java.util.List;

 import java.util.function.BiConsumer;

-

+import android.widget.TextView;

 import javax.inject.Inject;

 import javax.inject.Named;

 

@@ -283,6 +284,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

     protected boolean mScrollingEnabled;

     protected FooterView mFooterView;

     protected EmptyShadeView mEmptyShadeView;

     private boolean mDismissAllInProgress;

     private boolean mFadeNotificationsOnDismiss;

 

@@ -608,6 +610,9 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

             }

         });

         dynamicPrivacyController.addListener(this);

     }

 

     private void updateDismissRtlSetting(boolean dismissRtl) {

@@ -624,7 +629,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)

     protected void onFinishInflate() {

         super.onFinishInflate();



         inflateEmptyShadeView();

         inflateFooterView();

         mVisualStabilityManager.setVisibilityLocationProvider(this::isInVisibleLocation);

@@ -651,6 +656,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

     }

 

     private void reinflateViews() {



         inflateFooterView();

         inflateEmptyShadeView();

         updateFooter();

@@ -834,11 +840,11 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

         int right = (int) MathUtils.lerp(darkLeft, lockScreenRight, xProgress);

         int top = (int) MathUtils.lerp(darkTop, lockScreenTop, yProgress);

         int bottom = (int) MathUtils.lerp(darkTop, lockScreenBottom, yProgress);

-        mBackgroundAnimationRect.set(

+        /*mBackgroundAnimationRect.set(

                 left,

                 top,

                 right,

-                bottom);

+                bottom);*/

 

         int backgroundTopAnimationOffset = top - lockScreenTop;

         // TODO(kprevas): this may not be necessary any more since we don't display the shelf in AOD

@@ -850,7 +856,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

             }

         }

         if (!mAmbientState.isDark() || anySectionHasVisibleChild) {

-            drawBackgroundRects(canvas, left, right, top, backgroundTopAnimationOffset);

+            //drawBackgroundRects(canvas, left, right, top, backgroundTopAnimationOffset);

         }

 

         updateClipping();

@@ -924,6 +930,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

             if (child.getVisibility() != View.GONE

                     && child instanceof ExpandableNotificationRow) {

                 ExpandableNotificationRow row = (ExpandableNotificationRow) child;

                 if ((row.isPinned() || row.isHeadsUpAnimatingAway()) && row.getTranslation() < 0

                         && row.getProvider().shouldShowGutsOnSnapOpen()) {

                     top = Math.min(top, row.getTranslationY());

@@ -4880,6 +4887,9 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

         }

         mFooterView = footerView;

         addView(mFooterView, index);



     }

 

     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)

@@ -4892,7 +4902,15 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

         mEmptyShadeView = emptyShadeView;

         addView(mEmptyShadeView, index);

     }



     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)

     public void updateEmptyShadeView(boolean visible) {

         mEmptyShadeView.setVisible(visible, mIsExpanded && mAnimationsEnabled);

@@ -5689,14 +5707,18 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd

         view.setText(R.string.empty_shade_text);

         setEmptyShadeView(view);

     }



     /**

      * Updates expanded, dimmed and locked states of notification rows.

      */

     @ShadeViewRefactor(RefactorComponent.STATE_RESOLVER)

     public void onUpdateRowStates() {

         changeViewPosition(mFooterView, -1);


         // The following views will be moved to the end of mStackScroller. This counter represents

         // the offset from the last child. Initialized to 1 for the very last position. It is post-

         // incremented in the following "changeViewPosition" calls so that its value is correct for

```

这就是通知栏每条通知圆角处理的整个过程





