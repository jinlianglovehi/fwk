






### 1.概述


在原生的android 系统中，默认的是全盘加密，但是后来google 把该选项的权限放给了各手机厂家，各手机厂家可以根据自己的要求是否要默认加密手机，如果手机加密了（即显示手机已加密）用户是不办法取消的


### 2.取消系统默认的全盘加密(fstab分区加密)的核心类



```
device/sprd/sharkl5Pro/ums512_1h10/rootdir/root/fstab.ums512_1h10
device/sprd/sharkl5Pro/ums512_1h10/rootdir/root/fstab.ums512_1h10.nosec

```

### 3.取消系统默认的全盘加密(fstab分区加密)的核心功能分析和实现


功能分析：  
 但是由于客户要求去掉默认的系统全盘加密模式 修改成不加密 这样就需要找到加密的相关源码  
 查阅好多博客 就是说在devices 下寻找相关源码 最终功夫不负有心人 寻找到了相关的源码


接下来看  
 device/sprd/sharkl5Pro/ums512\_1h10/rootdir/root/fstab.ums512\_1h10



```
# Android fstab file.
# The filesystem that contains the filesystem checker binary (typically /system) cannot
# specify MF\_CHECK, and must come before any filesystems that do specify MF\_CHECK
# <src> <mnt\_point> <type> <mnt\_flags and options> <fs\_mgr\_flags>

system /system ext4 ro,barrier=1 wait,logical,first_stage_mount,avb_keys=/avb/q-gsi.avbpubkey:/avb/r-gsi.avbpubkey:/avb/s-gsi.avbpubkey
vendor /vendor ext4 ro,barrier=1 wait,logical,first_stage_mount
product /product ext4 ro,barrier=1 wait,logical,first_stage_mount
#/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/socko /mnt/product/socko ext4 noatime,nosuid,nodev,nomblk\_io\_submit,noauto\_da\_alloc wait,check,first\_stage\_mount
#/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/odmko /mnt/product/odmko ext4 noatime,nosuid,nodev,nomblk\_io\_submit,noauto\_da\_alloc wait,check,first\_stage\_mount
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,fileencryption=aes-256-xts,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,forceencrypt=footer,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/cache    /cache       ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/metadata /metadata    ext4 nodev,noatime,nosuid,errors=panic wait,formattable,first_stage_mount
/devices/platform/soc/soc:aon/5fff0000.usb/musb-hdrc.*.auto/usb*      auto         vfat defaults voldmanaged=usbdisk:auto
/devices/platform/soc/soc:ap-apb/71100000.sdio/mmc_host/mmc1/mmc1:*/block/mmcblk1      auto         vfat defaults voldmanaged=sdcard0:auto,noemulatedsd,encryptable=footer
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/prodnv   /mnt/vendor ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,check
# Should after mount prodnv for prodnv wholly occupying /mnt/vendor
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/socko /mnt/vendor/socko ext4 ro,noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,avb=socko,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/odmko /mnt/vendor/odmko ext4 ro,noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,avb=odmko,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/misc     /misc        emmc    defaults    defaults
#/dev/block/memdisk.0 /system ext4 rw,barrier=1 wait
#/dev/block/memdisk.1 /data ext4 noatime,nosuid,nodev,noauto\_da\_alloc,journal\_async\_commit,errors=panic wait

```

在fstab.ums512\_1h10中定义了userdata /data 的关于加密方式如下的forceencrypt就是加密方式修改为取消加密



```
userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,forceencrypt=footer,check

```

加密方式修改为取消加密  
 将forceencrypt 修改为encryptable 即可  
 如下:



```
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,encryptable=footer,check

```

接下来再看  
 device/sprd/sharkl5Pro/ums512\_1h10/rootdir/root/fstab.ums512\_1h10.nosec  
 的关于加密方式的修改



```
# Android fstab file.
# The filesystem that contains the filesystem checker binary (typically /system) cannot
# specify MF\_CHECK, and must come before any filesystems that do specify MF\_CHECK
# <src> <mnt\_point> <type> <mnt\_flags and options> <fs\_mgr\_flags>

system /system ext4 ro,barrier=1 wait,logical,first_stage_mount
vendor /vendor ext4 ro,barrier=1 wait,logical,first_stage_mount
product /product ext4 ro,barrier=1 wait,logical,first_stage_mount
#/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/socko /mnt/product/socko ext4 noatime,nosuid,nodev,nomblk\_io\_submit,noauto\_da\_alloc wait,check,first\_stage\_mount
#/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/odmko /mnt/product/odmko ext4 noatime,nosuid,nodev,nomblk\_io\_submit,noauto\_da\_alloc wait,check,first\_stage\_mount
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,fileencryption=aes-256-xts,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,encryptable=footer,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/cache    /cache       ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/metadata /metadata    ext4 nodev,noatime,nosuid,errors=panic wait,formattable,first_stage_mount
/devices/platform/soc/soc:aon/5fff0000.usb/musb-hdrc.*.auto/usb*      auto         vfat defaults voldmanaged=usbdisk:auto
/devices/platform/soc/soc:ap-apb/71100000.sdio/mmc_host/mmc1/mmc1:*/block/mmcblk1      auto         vfat defaults voldmanaged=sdcard0:auto,noemulatedsd,encryptable=footer
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/prodnv   /mnt/vendor ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,check
# Should after mount prodnv for prodnv wholly occupying /mnt/vendor
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/socko /mnt/vendor/socko ext4 ro,noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/odmko /mnt/vendor/odmko ext4 ro,noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,check
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/misc     /misc        emmc    defaults    defaults
#/dev/block/memdisk.0 /system ext4 rw,barrier=1 wait
#/dev/block/memdisk.1 /data ext4 noatime,nosuid,nodev,noauto\_da\_alloc,journal\_async\_commit,errors=panic wait

```

在fstab.ums512\_1h10.nosec中对于文件的加密方式定义为:forceencrypt 就是默认的加密方式



```
userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,forceencrypt=footer,check

```

所以需要  
 将forceencrypt 修改为encryptable ，修改为无加密的方式 完成功能  
 如下:



```
/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/userdata /data        ext4 noatime,nosuid,nodev,nomblk_io_submit,noauto_da_alloc wait,encryptable=footer,check

```

经过上述两个地方的修改，对文件加密方式的修改 达到了功能要求





