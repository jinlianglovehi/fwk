



## 1.前言


在系统10.0的ROM定制化开发中，在开发mtk平台的时候，在系统默认浏览器Browser中发现在下载应用宝app的时候，结果显示的确实 bin文件，所以就需要从Browser的下载流程中出发分析相关源码来实现具体的功能


## 2.mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心类



```
/vendor/mediatek/proprietary/packages/apps/Browser/src/com/android/browser/util/MimeTypeMap.java
 /vendor/mediatek/proprietary/packages/apps/Browser/src/com/android/browser/DownloadHandler.java
 /vendor/mediatek/proprietary/packages/apps/Browser/src/com/android/browser/FetchUrlMimeType.java

```

## 3.mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能分析和实现


在10.0的mtk的默认浏览器Browser的下载浏览器的流程中，在DownloadHandler.java这个类中主要就是负责关于 对在浏览器中点击下载应用包的时候，来负责相关apk的下载工作，而在FetchUrlMimeType.java负责根据url的参数 来继续调用下载流程，最终在MimeTypeMap.java中判断当前现在的文件，然后保存到本地的存储设备中，接下来 分析下相关的流程


## 3.1 DownloadHandler.java关于下载apk的流程调用


在实现mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能中，通过上述的分析得知，在 DownloadHandler.java中负责开始接收浏览器页面传递过来的下载文件功能，接下来分析下相关下载源码



```
 public static void onDownloadStartNoStream(Activity activity,
            String url, String userAgent, String contentDisposition,
            String mimetype, String referer, boolean privateBrowsing, long contentLength) {

        String[] perm = { Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE };
        for (int i = 0; i < perm.length; i++) {
            if (activity.checkSelfPermission(perm[i]) != PackageManager.PERMISSION_GRANTED) {
                if (DEBUG) {
                    Log.d(XLOGTAG, "no permission: " + perm[i]);
                }
                return;
            }
        }

        /// M: ALPS02251196.Fix incorrect mimetype which surround by quotations @{
        if (null != mimetype && mimetype.startsWith("\"")
                && mimetype.endsWith("\"") && mimetype.length() > 2) {
            mimetype = mimetype.substring(1, mimetype.length() - 1);
        }
        /// @}

        String filename = URLUtil.guessFileName(url,
                contentDisposition, mimetype);
        if (DEBUG) {
            Log.d(XLOGTAG, "Guess file name is: " + filename +
                " mimetype is: " + mimetype);
        }
.......
        request.allowScanningByMediaScanner();
        request.setDescription(webAddress.getHost());
        // XXX: Have to use the old url since the cookies were stored using the
        // old percent-encoded url.
        String cookies = CookieManager.getInstance().getCookie(url, privateBrowsing);
        request.addRequestHeader("cookie", cookies);
        request.addRequestHeader("User-Agent", userAgent);
        request.addRequestHeader("Referer", referer);
        request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        //request.setUserAgent(userAgent);
        if (mimetype == null) {
            if (TextUtils.isEmpty(addressString)) {
                return;
            }

            /// M: fix BUG: ALPS00256340 @{
            try {
                URI.create(addressString);
            } catch (IllegalArgumentException e) {
                Toast.makeText(activity, R.string.cannot_download, Toast.LENGTH_SHORT).show();
                return;
            }
            /// @}

            // We must have long pressed on a link or image to download it. We
            // are not sure of the mimetype in this case, so do a head request
            new FetchUrlMimeType(activity, request, addressString, cookies,
                    userAgent).start();
        } else {
            final DownloadManager manager
                    = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            new Thread("Browser download") {
                public void run() {
                    manager.enqueue(request);
                }
            }.start();
        }

        /// M: Show toast with file size. @{
        sBrowserDownloadExt.showToastWithFileSize(activity, contentLength,
            activity.getResources().getString(R.string.download_pending));
        /// @}

        /// M: Add to start Download activity. @{
        Intent pageView = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);
        pageView.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        activity.startActivity(pageView);
        /// @}
    }
```

在实现mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能中，通过上述的分析得知，在 DownloadHandler.java中的相关源码中，主要还是通过onDownloadStartNoStream(Activity activity, String url, String userAgent, String contentDisposition, String mimetype, String referer, boolean privateBrowsing, long contentLength) 来负责下载相关的 apk功能，而在 new FetchUrlMimeType(activity, request, addressString, cookies, userAgent).start();负责通过启动线程来开始下载工作，接下来看下 FetchUrlMimeType 中的下载线程的相关源码分析


## 3.2 FetchUrlMimeType的相关下载线程功能分析


在实现mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能中，通过上述的分析得知，在 FetchUrlMimeType.java的相关源码中，主要是通过根据DownloadHandler.java中的相关参数启动线程进行 相关的apk下载功能，接下来分析下相关源码功能



```
   @Override
    public void run() {
        String mimeType = null;
        String contentDisposition = null;
        HttpURLConnection connection = null;
        try {
            URL url = new URL(mUri);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("HEAD");

            if (mUserAgent != null) {
                connection.addRequestProperty("User-Agent", mUserAgent);
            }

            if (mCookies != null && mCookies.length() > 0) {
                connection.addRequestProperty("Cookie", mCookies);
            }

            /// M: fix 452066. @{
            if (connection.getResponseCode() == 501 ||
                    connection.getResponseCode() == 400) {

                Log.d(XLOGTAG, "FetchUrlMimeType:  use Get method");
                connection.disconnect();

                url = new URL(mUri);
                connection = (HttpURLConnection) url.openConnection();
                if (mUserAgent != null) {
                    connection.addRequestProperty("User-Agent", mUserAgent);
                }
            }
            /// @}

            if (connection.getResponseCode() == 200) {
                mimeType = connection.getContentType();
                if (mimeType != null) {
                    final int semicolonIndex = mimeType.indexOf(';');
                    if (semicolonIndex != -1) {
                        mimeType = mimeType.substring(0, semicolonIndex);
                    }
                }

                contentDisposition = connection.getHeaderField("Content-Disposition");
            }
        } catch (IOException ioe) {
            Log.e(LOGTAG, "Download failed: " + ioe);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        if (mimeType != null) {
            if (mimeType.equalsIgnoreCase("text/plain") ||
                    mimeType.equalsIgnoreCase("application/octet-stream")) {
                String newMimeType =
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                                MimeTypeMap.getFileExtensionFromUrl(mUri));
                if (newMimeType != null) {
                    mimeType = newMimeType;
                    mRequest.setMimeType(newMimeType);
                }
            }
        }

        String filename = URLUtil.guessFileName(mUri, contentDisposition,
                mimeType);
        // mRequest.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
        Log.d(XLOGTAG, "FetchUrlMimeType: Guess file name is: " + filename +
              " mimeType is: " + mimeType);

        /// M: Set the request destination direction @{
        mBrowserDownloadExt = Extensions.getDownloadPlugin(mContext);
        mBrowserDownloadExt.setRequestDestinationDir(
            BrowserSettings.getInstance().getDownloadPath(),
            mRequest, filename, mimeType);
        /// @}

        // Start the download
        DownloadManager manager = (DownloadManager) mContext.getSystemService(
                Context.DOWNLOAD_SERVICE);
        manager.enqueue(mRequest);
    }
```

在实现mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能中，通过上述的分析得知，在 FetchUrlMimeType.java的相关源码中，在下载线程的run方法中，在MimeTypeMap.getFileExtensionFromUrl(mUri)); 来判断当前下载的是什么数据类型的文件，然后调用DownloadManager进行具体的下载功能，而在这里下载应用宝的时候 系统层那一套算法太老了不够完善，下面的算法更完善，能识别更多形式的文件，某些64位的应用无法识别转成apk，最后只能是bin文件 所以接下来需要具体分析下MimeTypeMap.getFileExtensionFromUrl来实现相关功能


## 3.3MimeTypeMap相关下载文件类型的分析


在实现mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能中，通过上述的分析得知，在 MimeTypeMap.java的核心功能就是区分当前下载文件的类型，接下来分析下相关源码看怎么实现功能



```
public static String getFileExtensionFromUrl(String url) {
        if (!TextUtils.isEmpty(url)) {
            int fragment = url.lastIndexOf('#');
            if (fragment > 0) {
                url = url.substring(0, fragment);
            }

            int query = url.lastIndexOf('?');
            if (query > 0) {
                url = url.substring(0, query);
            }

            int filenamePos = url.lastIndexOf('/');
            String filename =
                0 <= filenamePos ? url.substring(filenamePos + 1) : url;

            // if the filename contains special characters, we don't
            // consider it valid for our matching purposes:
            if (!filename.isEmpty() &&
-                Pattern.matches("[a-zA-Z_0-9\\.\\-\\(\\)\\%]+", filename)) {
+               Pattern.matches("[\u4e00-\u9fa5_a-zA-Z_0-9\\.\\-\\(\\)\\%]+", filename)) {
                int dotPos = filename.lastIndexOf('.');
                if (0 <= dotPos) {
                    return filename.substring(dotPos + 1);
                }
            }
        }

        return "";
    }
```

在实现mtk默认浏览器Browser下载应用宝app显示bin文件的解决办法的核心功能中，通过上述的分析得知，在 MimeTypeMap.java的核心源码中分析得知，在getFileExtensionFromUrl(String url)中对于一些像应用宝64位的apk识别为 bin文件，所以需要对正则表达式做部分修改Pattern.matches("[\u4e00-\u9fa5\_a-zA-Z\_0-9\\.\\-\\(\\)\\%]+", filename) 这样的修改 就可以识别到应用宝为apk了下载到本地就是apk了就实现了相关功能



