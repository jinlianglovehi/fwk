



## 1.前言


在10.0的系统定制化开发中，由于 Android对应用应用的系统库限制越来越严格，上层应用包括（apk、jar包）不能直接引用系统的一些so库了。如果需要使用，只能使用，系统申明的公共库。 如果使用非系统申明的公共库，apk运行后调用该so库时，app会直接挂掉，或者系统开发中，编译过程中出现is not accessible for the namespace "classloader-namespace"这个问题，所以需要添加系统so库到公共库配置的目录下然后实现功能，接下来 看下mtk平台的相关配置功能


## 2.mtk平台系统添加公共so库的配置方法的核心类



```
system\core\rootdir\etc\public.libraries.android.txt
out\target\product\ums512_1h10\vendor\etc\public.libraries.txt
```

## 3.mtk平台系统添加公共so库的配置方法的核心功能分析和实现


在app中引用系统so库的时候 在运行的时候 会崩溃，例如崩溃信息如下： 01-01 02:17:24.222 7475 7475 E linker : library "/system/lib/libhalloworld.so" ("/system/lib/libhalloworld.so") needed or dl opened by "/system/lib/libnativeloader.so" is not accessible for the namespace: [name="classloader-namespace", ld\_library\_paths ="", default\_library\_paths="/system/fake-libs:/data/app/com.example.halloworld-1/base.apk!/lib/", permitted\_paths="/dat a:/mnt/expand:/data/data/com.example.halloworld"] 01-01 02:17:24.223 7475 7475 E System : java.lang.UnsatisfiedLinkError: dlopen failed: library "/system/lib/libhalloworld.so" needed or dlopened by "/system/lib/libnativeloader.so" is not accessible for the namespace "classloader-namespace" 系统库如果想公开，那么就加入到/system/etc/public.librariy.txt 如果是芯片库，那么就加入到：/vendor/etc/public.librariy.txt 这样app 就可以正常加载该库。 这两个文件是不允许加目录的方式。 直接写入so 库即可。


对于system so上面的内容主要有三点：


1、需要添加的so库文件名格式要求：如 libhalloworld.google.so


2、public.libraries.txt文件命名：public.libraries-google.txt


3、public.libraries-google.txt文件内容必须是libhalloworld.google.so，且放在/system/etc下 以上三点有一点不对应，apk同样会奔溃。


下面从开机流程中分析下相关功能 1、正常开机日志，可以看到，资料加载完成后，马上会执行startSystemServer方法启动system\_server进程，相应的日志都有出现，当system\_server启动成功后，界面也就快显示出来了。



```
Line 1694: 01-03 22:23:11.820   361   361 D Zygote  : begin preload
    Line 1695: 01-03 22:23:11.820   361   361 I Zygote  : Installing ICU cache reference pinning...
    Line 1696: 01-03 22:23:11.820   361   361 I Zygote  : Preloading ICU data...
    Line 1867: 01-03 22:23:12.087   361   361 I Zygote  : Preloading classes...
    Line 1868: 01-03 22:23:12.094   361   361 W Zygote  : Class not found for preloading: [Landroid.view.Display$ColorTransform;
    Line 2304: 01-03 22:23:13.874   361   361 W Zygote  : Class not found for preloading: android.view.Display$ColorTransform
    Line 2305: 01-03 22:23:13.875   361   361 W Zygote  : Class not found for preloading: android.view.Display$ColorTransform$1
    Line 2347: 01-03 22:23:14.546   361   361 I Zygote  : ...preloaded 4158 classes in 2459ms.
    Line 2375: 01-03 22:23:14.734   361   361 I Zygote  : Preloading resources...
    Line 2423: 01-03 22:23:15.081   361   361 I Zygote  : ...preloaded 114 resources in 347ms.
    Line 2426: 01-03 22:23:15.097   361   361 I Zygote  : ...preloaded 41 resources in 17ms.
    Line 2439: 01-03 22:23:15.183   361   361 I Zygote  : Preloading shared libraries...
    Line 2444: 01-03 22:23:15.227   361   361 I Zygote  : Uninstalled ICU cache reference pinning...
    Line 2445: 01-03 22:23:15.239   361   361 I Zygote  : Installed AndroidKeyStoreProvider in 12ms.
    Line 2446: 01-03 22:23:15.264   361   361 I Zygote  : Warmed up JCA providers in 26ms.
    Line 2447: 01-03 22:23:15.265   361   361 D Zygote  : end preload
    Line 2462: 01-03 22:23:15.448   361   361 I Zygote  : System server process 2252 has been created
    Line 2463: 01-03 22:23:15.455   361   361 I Zygote  : Accepting command socket connections
    Line 10398: 01-03 22:25:40.307  2252  2574 I Zygote  : Process: zygote socket opened, supported ABIS: armeabi-v7a,armeabi
    
    
    2、异常开机日志，从日志中明显可以看到，Zygote进程在加载完资料后，根据没有成功启动system_server，导致无法开机。    
    Line 1743: 01-03 22:16:43.383   347   347 D Zygote  : begin preload
    Line 1744: 01-03 22:16:43.383   347   347 I Zygote  : Installing ICU cache reference pinning...
    Line 1745: 01-03 22:16:43.384   347   347 I Zygote  : Preloading ICU data...
    Line 1914: 01-03 22:16:43.600   347   347 I Zygote  : Preloading classes...
    Line 1915: 01-03 22:16:43.607   347   347 W Zygote  : Class not found for preloading: [Landroid.view.Display$ColorTransform;
    Line 2347: 01-03 22:16:45.403   347   347 W Zygote  : Class not found for preloading: android.view.Display$ColorTransform
    Line 2348: 01-03 22:16:45.404   347   347 W Zygote  : Class not found for preloading: android.view.Display$ColorTransform$1
    Line 2376: 01-03 22:16:46.015   347   347 I Zygote  : ...preloaded 4158 classes in 2414ms.
    Line 2396: 01-03 22:16:46.191   347   347 I Zygote  : Preloading resources...
    Line 2438: 01-03 22:16:46.567   347   347 I Zygote  : ...preloaded 114 resources in 375ms.
    Line 2441: 01-03 22:16:46.583   347   347 I Zygote  : ...preloaded 41 resources in 17ms.
    Line 2472: 01-03 22:16:46.682   347   347 I Zygote  : Preloading shared libraries...
    Line 2477: 01-03 22:16:46.740   347   347 I Zygote  : Uninstalled ICU cache reference pinning...
    Line 2478: 01-03 22:16:46.757   347   347 I Zygote  : Installed AndroidKeyStoreProvider in 16ms.
    Line 2479: 01-03 22:16:46.780   347   347 I Zygote  : Warmed up JCA providers in 24ms.
    Line 2480: 01-03 22:16:46.781   347   347 D Zygote  : end preload
```

启动system\_server的代码是从frameworks\base\cmds\app\_process\app\_main.cpp文件中的main方法开始的， 再往上就是init.rc角本了，main方法中组装启动参数，然后调用父类AndroidRuntime的start方法，代码如下：



```
 int main(int argc, char* const argv[])
    {
        if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) < 0) {
            if (errno != EINVAL) {
                LOG_ALWAYS_FATAL("PR_SET_NO_NEW_PRIVS failed: %s", strerror(errno));
                return 12;
            }
        }
     
        AppRuntime runtime(argv[0], computeArgBlockSize(argc, argv));
        argc--;
        argv++;
     
        int i;
        for (i = 0; i < argc; i++) {
            if (argv[i][0] != '-') {
                break;
            }
            if (argv[i][1] == '-' && argv[i][2] == 0) {
                ++i; // Skip --.
                break;
            }
            runtime.addOption(strdup(argv[i]));
        } 
    ......
    }
```

这里的runtime是一个AppRuntime类型的对象，它是AndroidRuntime的子类，start方法也是调用父类的， AndroidRuntime类的start方法代码如下：



```
  void AndroidRuntime::start(const char* className, const Vector<String8>& options, bool zygote)
    {
        ALOGD(">>>>>> START %s uid %d <<<<<<\n",
                className != NULL ? className : "(unknown)", getuid());
     
        static const String8 startSystemServer("start-system-server");

        for (size_t i = 0; i < options.size(); ++i) {
            if (options[i] == startSystemServer) {
               /* track our progress through the boot sequence */
               const int LOG_BOOT_PROGRESS_START = 3000;
               LOG_EVENT_LONG(LOG_BOOT_PROGRESS_START,  ns2ms(systemTime(SYSTEM_TIME_MONOTONIC)));
            }
        }
     
        const char* rootDir = getenv("ANDROID_ROOT");
        if (rootDir == NULL) {
            rootDir = "/system";
            if (!hasDir("/system")) {
                LOG_FATAL("No root directory specified, and /android does not exist.");
                return;
            }
            setenv("ANDROID_ROOT", rootDir, 1);
        }
     
        //const char* kernelHack = getenv("LD_ASSUME_KERNEL");
        //ALOGD("Found LD_ASSUME_KERNEL='%s'\n", kernelHack);
     
        /* start the virtual machine */
        JniInvocation jni_invocation;
        jni_invocation.Init(NULL);
        JNIEnv* env;
        if (startVm(&mJavaVM, &env, zygote) != 0) {
            return;
        }
        onVmCreated(env);
....
    }
```

这里就是组装参数，然后通过反射调用到frameworks\base\core\java\com\android\internal\os\ZygoteInit.java类的 main方法，这里和日志上对应的就是调用preload()方法，它会去加载所有的类、资源、动态库，日志也都有打印，加载完成后，因为在app\_main.cpp文件中有封装start-system-server参数，所以startSystemServer值为true， 继续调用startSystemServer(abiList, socketName)去启动system\_server，我的问题也就是在这里产生的， 于是，在这里加日志，发现这里的逻辑是正常的，于是继续往下查，到Zygote类中的forkSystemServer方法的调用也都是正常， 但是for的方法没有返回，fork真正的逻辑是在frameworks\base\core\jni\com\_android\_internal\_os\_Zygote.cpp文件中的 ForkAndSpecializeCommon方法中调用完成的功能


2. 关于系统公共so库的配置


在实现mtk平台系统添加公共so库的配置方法的核心功能中，在通过上述的分析得知，需要在/system/etc/public.librariy.txt和 /vendor/etc/public.librariy.txt下来配置系统公开库的名称，只需要配置名称就可以了不需要配置so库的路径，接下来就是来 寻找/system/etc/public.librariy.txt和/vendor/etc/public.librariy.txt的具体在源码中的路径，具体如下 关于/system/etc/public.librariy.txt的源码路径就是在system\core\rootdir\etc\public.libraries.android.txt的路径下，而 vendor下的公共库就是芯片厂家的公开库在mtk10.0的路径就是在device\mediatek\vendor\common\public.libraries.vendor.neuropilot.txt 或者device\mediatek\vendor\common\public.libraries.vendor.txt的目录下 具体看下芯片类型的路径，然后添加完so库后，全局编译以后可以在out\target\product\tb8788p1\_64\_wifi\vendor\etc\public.libraries.txt和 out\target\product\tb8788p1\_64\_wifi\system\etc\public.libraries.txt下看有没新增的系统so库，有的话就添加成功了，就可以 在app中引用系统so库了



