



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.settings禁止访问应用信息的核心代码](#2.settings%E7%A6%81%E6%AD%A2%E8%AE%BF%E9%97%AE%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.settings禁止访问应用信息的核心代码的功能分析](#3.settings%E7%A6%81%E6%AD%A2%E8%AE%BF%E9%97%AE%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E7%9A%84%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1AppInfoDashboardFragment.java 关于应用信息的代码分析](#%C2%A0%203.1AppInfoDashboardFragment.java%20%E5%85%B3%E4%BA%8E%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E7%9A%84%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 RecentAppsPreferenceController.java 关于最近打开应用的点击事件控制](#3.2%20RecentAppsPreferenceController.java%20%E5%85%B3%E4%BA%8E%E6%9C%80%E8%BF%91%E6%89%93%E5%BC%80%E5%BA%94%E7%94%A8%E7%9A%84%E7%82%B9%E5%87%BB%E4%BA%8B%E4%BB%B6%E6%8E%A7%E5%88%B6)


[3.3 AppInfoBase.java关于应用信息的相关代码](#3.3%20AppInfoBase.java%E5%85%B3%E4%BA%8E%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


  在系统Settings中，原生系统在进入一级菜单，在点击应用和通知后可以通过app的icon进入对应的应用信息页面查看应用信息和各种权限等信息，但对于权限的管控，就需要限制进入应用信息页面


## 2.settings禁止访问应用信息的核心代码



```
  packages/apps/Settings/src/com/android/settings/applications/AppInfoBase.java
  packages/apps/Settings/src/com/android/settings/applications/appinfo/AppInfoDashboardFragment.java
  packages/apps/Settings/src/com/android/settings/applications/RecentAppsPreferenceController.java
```

## 3.settings禁止访问应用信息的核心代码的功能分析


###   3.1AppInfoDashboardFragment.java 关于应用信息的代码分析



```
  public class AppInfoDashboardFragment extends DashboardFragment
        implements ApplicationsState.Callbacks,
        ButtonActionDialogFragment.AppButtonsDialogListener {

    private static final String TAG = "AppInfoDashboard";

    // Menu identifiers
    @VisibleForTesting
    static final int UNINSTALL_ALL_USERS_MENU = 1;
    @VisibleForTesting
    static final int UNINSTALL_UPDATES = 2;
    static final int INSTALL_INSTANT_APP_MENU = 3;

    // Result code identifiers
    @VisibleForTesting
    static final int REQUEST_UNINSTALL = 0;
    private static final int REQUEST_REMOVE_DEVICE_ADMIN = 5;

    static final int SUB_INFO_FRAGMENT = 1;

    static final int LOADER_CHART_DATA = 2;
    static final int LOADER_STORAGE = 3;
    static final int LOADER_BATTERY = 4;

    public static final String ARG_PACKAGE_NAME = "package";
    public static final String ARG_PACKAGE_UID = "uid";

    private static final boolean localLOGV = false;

    private EnforcedAdmin mAppsControlDisallowedAdmin;
    private boolean mAppsControlDisallowedBySystem;

    private ApplicationsState mState;
    private ApplicationsState.Session mSession;
    private ApplicationsState.AppEntry mAppEntry;
    private PackageInfo mPackageInfo;
    private int mUserId;
    private String mPackageName;

    private DevicePolicyManager mDpm;
    private UserManager mUserManager;
    private PackageManager mPm;

    @VisibleForTesting
    boolean mFinishing;
    private boolean mListeningToPackageRemove;


    private boolean mInitialized;
    private boolean mShowUninstalled;
    private boolean mUpdatedSysApp = false;

    private List<Callback> mCallbacks = new ArrayList<>();

    private InstantAppButtonsPreferenceController mInstantAppButtonPreferenceController;
    private AppButtonsPreferenceController mAppButtonsPreferenceController;

    /**
     * Callback to invoke when app info has been changed.
     */
    public interface Callback {
        void refreshUi();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        final String packageName = getPackageName();
        use(TimeSpentInAppPreferenceController.class).setPackageName(packageName);

        use(AppDataUsagePreferenceController.class).setParentFragment(this);
        final AppInstallerInfoPreferenceController installer =
                use(AppInstallerInfoPreferenceController.class);
        installer.setPackageName(packageName);
        installer.setParentFragment(this);
        use(AppInstallerPreferenceCategoryController.class).setChildren(Arrays.asList(installer));
        use(AppNotificationPreferenceController.class).setParentFragment(this);
        use(AppOpenByDefaultPreferenceController.class).setParentFragment(this);
        use(AppPermissionPreferenceController.class).setParentFragment(this);
        use(AppPermissionPreferenceController.class).setPackageName(packageName);
        use(AppSettingPreferenceController.class)
                .setPackageName(packageName)
                .setParentFragment(this);
        use(AppStoragePreferenceController.class).setParentFragment(this);
        use(AppVersionPreferenceController.class).setParentFragment(this);
        use(InstantAppDomainsPreferenceController.class).setParentFragment(this);

        final WriteSystemSettingsPreferenceController writeSystemSettings =
                use(WriteSystemSettingsPreferenceController.class);
        writeSystemSettings.setParentFragment(this);

        final DrawOverlayDetailPreferenceController drawOverlay =
                use(DrawOverlayDetailPreferenceController.class);
        drawOverlay.setParentFragment(this);

        final PictureInPictureDetailPreferenceController pip =
                use(PictureInPictureDetailPreferenceController.class);
        pip.setPackageName(packageName);
        pip.setParentFragment(this);
        final ExternalSourceDetailPreferenceController externalSource =
                use(ExternalSourceDetailPreferenceController.class);
        externalSource.setPackageName(packageName);
        externalSource.setParentFragment(this);

        use(AdvancedAppInfoPreferenceCategoryController.class).setChildren(Arrays.asList(
                writeSystemSettings, drawOverlay, pip, externalSource));
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        mFinishing = false;
        final Activity activity = getActivity();
        mDpm = (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
        mUserManager = (UserManager) activity.getSystemService(Context.USER_SERVICE);
        mPm = activity.getPackageManager();
        if (!ensurePackageInfoAvailable(activity)) {
            return;
        }
        if (!ensureDisplayableModule(activity)) {
            return;
        }
        startListeningToPackageRemove();

        setHasOptionsMenu(true);
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        if (!ensurePackageInfoAvailable(getActivity())) {
            return;
        }
        super.onCreatePreferences(savedInstanceState, rootKey);
    }

public static void startAppInfoFragment(Class<?> fragment, int title, Bundle args,
            SettingsPreferenceFragment caller, AppEntry appEntry) {
        // start new fragment to display extended information
        // add core start
        String name = fragment.getName();
        if(name!=null&&name.equals("com.android.settings.applications.appinfo.AppInfoDashboardFragment"))return;
        // add core end


        if (args == null) {
            args = new Bundle();
        }
        args.putString(ARG_PACKAGE_NAME, appEntry.info.packageName);
        args.putInt(ARG_PACKAGE_UID, appEntry.info.uid);
        new SubSettingLauncher(caller.getContext())
                .setDestination(fragment.getName())
                .setArguments(args)
                .setTitleRes(title)
                .setResultListener(caller, SUB_INFO_FRAGMENT)
                .setSourceMetricsCategory(caller.getMetricsCategory())
                .launch();
    }

    private void onPackageRemoved() {
        getActivity().finishActivity(SUB_INFO_FRAGMENT);
        getActivity().finishAndRemoveTask();
    }
```

startAppInfoFragment(Class<?> fragment, int title, Bundle args,  
             SettingsPreferenceFragment caller, AppEntry appEntry) {  
 负责根据传值来启动对应的Fragment


### 3.2 RecentAppsPreferenceController.java 关于最近打开应用的点击事件控制



```
      public class RecentAppsPreferenceController extends BasePreferenceController
        implements RecentAppStatsMixin.RecentAppStatsListener {

    @VisibleForTesting
    static final String KEY_DIVIDER = "recent_apps_divider";

    @VisibleForTesting
    AppEntitiesHeaderController mAppEntitiesController;
    @VisibleForTesting
    LayoutPreference mRecentAppsPreference;
    @VisibleForTesting
    Preference mDivider;

    private final ApplicationsState mApplicationsState;
    private final int mUserId;
    private final IconDrawableFactory mIconDrawableFactory;

    private Fragment mHost;
    private List<UsageStats> mRecentApps;

    public RecentAppsPreferenceController(Context context, String key) {
        super(context, key);
        mApplicationsState = ApplicationsState.getInstance(
                (Application) mContext.getApplicationContext());
        mUserId = UserHandle.myUserId();
        mIconDrawableFactory = IconDrawableFactory.newInstance(mContext);
    }

    public void setFragment(Fragment fragment) {
        mHost = fragment;
    }

    @Override
    public int getAvailabilityStatus() {
        return AVAILABLE_UNSEARCHABLE;
    }

    @Override
    public void displayPreference(PreferenceScreen screen) {
        super.displayPreference(screen);

        mDivider = screen.findPreference(KEY_DIVIDER);
        mRecentAppsPreference = screen.findPreference(getPreferenceKey());
        final View view = mRecentAppsPreference.findViewById(R.id.app_entities_header);
        mAppEntitiesController = AppEntitiesHeaderController.newInstance(mContext, view)
                .setHeaderTitleRes(R.string.recent_app_category_title)
                .setHeaderDetailsClickListener((View v) -> {
                    new SubSettingLauncher(mContext)
                            .setDestination(ManageApplications.class.getName())
                            .setArguments(null /* arguments */)
                            .setTitleRes(R.string.application_info_label)
                            .setSourceMetricsCategory(SettingsEnums.SETTINGS_APP_NOTIF_CATEGORY)
                            .launch();
                });
    }

    @Override
    public void onReloadDataCompleted(@NonNull List<UsageStats> recentApps) {
        mRecentApps = recentApps;
        refreshUi();
        // Show total number of installed apps as See all's summary.
        new InstalledAppCounter(mContext, InstalledAppCounter.IGNORE_INSTALL_REASON,
                mContext.getPackageManager()) {
            @Override
            protected void onCountComplete(int num) {
                mAppEntitiesController.setHeaderDetails(
                        mContext.getString(R.string.see_all_apps_title, num));
                mAppEntitiesController.apply();
            }
        }.execute();
    }

    private void refreshUi() {
        if (!mRecentApps.isEmpty()) {
            displayRecentApps();
            mRecentAppsPreference.setVisible(true);
            mDivider.setVisible(true);
        } else {
            mDivider.setVisible(false);
            mRecentAppsPreference.setVisible(false);
        }
    }

    private void displayRecentApps() {
        int showAppsCount = 0;

        for (UsageStats stat : mRecentApps) {
            final AppEntityInfo appEntityInfoInfo = createAppEntity(stat);
            if (appEntityInfoInfo != null) {
                mAppEntitiesController.setAppEntity(showAppsCount++, appEntityInfoInfo);
            }

            if (showAppsCount == AppEntitiesHeaderController.MAXIMUM_APPS) {
                break;
            }
        }
    }

    private AppEntityInfo createAppEntity(UsageStats stat) {
        final String pkgName = stat.getPackageName();
        final ApplicationsState.AppEntry appEntry =
                mApplicationsState.getEntry(pkgName, mUserId);
        if (appEntry == null) {
            return null;
        }

        return new AppEntityInfo.Builder()
                .setIcon(mIconDrawableFactory.getBadgedIcon(appEntry.info))
                .setTitle(appEntry.label)
                .setSummary(StringUtil.formatRelativeTime(mContext,
                        System.currentTimeMillis() - stat.getLastTimeUsed(), false,
                        RelativeDateTimeFormatter.Style.SHORT))
                .setOnClickListener(v ->
                        AppInfoBase.startAppInfoFragment(AppInfoDashboardFragment.class,
                                R.string.application_info_label, pkgName, appEntry.info.uid,
                                mHost, 1001 /*RequestCode*/,
                                SettingsEnums.SETTINGS_APP_NOTIF_CATEGORY))
                .build();
    }
}
```

在createAppEntity(UsageStats stat)构建最近打开app的应用信息中  
 setOnClickListener(v ->  
                         AppInfoBase.startAppInfoFragment(AppInfoDashboardFragment.class,  
                                 R.string.application\_info\_label, pkgName, appEntry.info.uid,  
                                 mHost, 1001 /\*RequestCode\*/,  
                                 SettingsEnums.SETTINGS\_APP\_NOTIF\_CATEGORY))  
 是通过AppInfoBase.startAppInfoFragment()跳转详情页  
 接下来看AppInfoBase的相关代码


### 3.3 AppInfoBase.java关于应用信息的相关代码



```
public abstract class AppInfoBase extends SettingsPreferenceFragment
        implements ApplicationsState.Callbacks {

    public static final String ARG_PACKAGE_NAME = "package";
    public static final String ARG_PACKAGE_UID = "uid";

    private static final String TAG = "AppInfoBase";

    protected EnforcedAdmin mAppsControlDisallowedAdmin;
    protected boolean mAppsControlDisallowedBySystem;

    protected ApplicationFeatureProvider mApplicationFeatureProvider;
    protected ApplicationsState mState;
    protected ApplicationsState.Session mSession;
    protected ApplicationsState.AppEntry mAppEntry;
    protected PackageInfo mPackageInfo;
    protected int mUserId;
    protected String mPackageName;

    protected IUsbManager mUsbManager;
    protected DevicePolicyManager mDpm;
    protected UserManager mUserManager;
    protected PackageManager mPm;

    // Dialog identifiers used in showDialog
    protected static final int DLG_BASE = 0;

    protected boolean mFinishing;
    protected boolean mListeningToPackageRemove;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFinishing = false;
        final Activity activity = getActivity();
        mApplicationFeatureProvider = FeatureFactory.getFactory(activity)
                .getApplicationFeatureProvider(activity);
        mState = ApplicationsState.getInstance(activity.getApplication());
        mSession = mState.newSession(this, getSettingsLifecycle());
        mDpm = (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
        mUserManager = (UserManager) activity.getSystemService(Context.USER_SERVICE);
        mPm = activity.getPackageManager();
        IBinder b = ServiceManager.getService(Context.USB_SERVICE);
        mUsbManager = IUsbManager.Stub.asInterface(b);

        retrieveAppEntry();
        startListeningToPackageRemove();
    }

    public static void startAppInfoFragment(Class<?> fragment, int titleRes,
            String pkg, int uid, Fragment source, int request, int sourceMetricsCategory) {
        final Bundle args = new Bundle();
        args.putString(AppInfoBase.ARG_PACKAGE_NAME, pkg);
        args.putInt(AppInfoBase.ARG_PACKAGE_UID, uid);
        
       // add core start
        String name = fragment.getName();
        if(name!=null&&name.equals("com.android.settings.applications.appinfo.AppInfoDashboardFragment"))return;
       //add core end

        new SubSettingLauncher(source.getContext())
                .setDestination(fragment.getName())
                .setSourceMetricsCategory(sourceMetricsCategory)
                .setTitleRes(titleRes)
                .setArguments(args)
                .setUserHandle(new UserHandle(UserHandle.getUserId(uid)))
                .setResultListener(source, request)
                .launch();
    }
```

通过startAppInfoFragment调整到对应的应用信息页面 所以在这里判断是否是AppInfoDashboardFragment是就return就可以了



