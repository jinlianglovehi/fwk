






### 1.概述


在10.0的系统产品定制化开发中，由于是wifi产品，产品需求在开机以后要连接指定wifi，那么涉及到在AMS开机完成后，进行连接指定的wifi


### 2.开机连接指定wifi的核心类



```
frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java

```

### 3.开机连接指定wifi的核心功能分析和实现


在系统开机完成后，AMS工作做完后会调用finishBooting() 等相关源码  
 首选看AMS 中 开机完成的源码



```
final void finishBooting() {
        Trace.traceBegin(Trace.TRACE_TAG_ACTIVITY_MANAGER, "FinishBooting");

        synchronized (this) {
            if (!mBootAnimationComplete) {
                mCallFinishBooting = true;
                return;
            }
            mCallFinishBooting = false;
        }

        ArraySet<String> completedIsas = new ArraySet<String>();
        for (String abi : Build.SUPPORTED_ABIS) {
            ZYGOTE_PROCESS.establishZygoteConnectionForAbi(abi);
            final String instructionSet = VMRuntime.getInstructionSet(abi);
            if (!completedIsas.contains(instructionSet)) {
                try {
                    mInstaller.markBootComplete(VMRuntime.getInstructionSet(abi));
                } catch (InstallerException e) {
                    if (!VMRuntime.didPruneDalvikCache()) {
                        // This is technically not the right filter, as different zygotes may
                        // have made different pruning decisions. But the log is best effort,
                        // anyways.
                        Slog.w(TAG, "Unable to mark boot complete for abi: " + abi + " (" +
                                e.getMessage() +")");
                    }
                }
                completedIsas.add(instructionSet);
            }
        }

        IntentFilter pkgFilter = new IntentFilter();
        pkgFilter.addAction(Intent.ACTION_QUERY_PACKAGE_RESTART);
        pkgFilter.addDataScheme("package");
        mContext.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String[] pkgs = intent.getStringArrayExtra(Intent.EXTRA_PACKAGES);
                if (pkgs != null) {
                    for (String pkg : pkgs) {
                        synchronized (ActivityManagerService.this) {
                            if (forceStopPackageLocked(pkg, -1, false, false, false, false, false,
                                    0, "query restart")) {
                                setResultCode(Activity.RESULT_OK);
                                return;
                            }
                        }
                    }
                }
            }
        }, pkgFilter);

        IntentFilter dumpheapFilter = new IntentFilter();
        dumpheapFilter.addAction(DumpHeapActivity.ACTION_DELETE_DUMPHEAP);
        mContext.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                final long delay = intent.getBooleanExtra(
                        DumpHeapActivity.EXTRA_DELAY_DELETE, false) ? 5 * 60 * 1000 : 0;
                mHandler.sendEmptyMessageDelayed(DELETE_DUMPHEAP_MSG, delay);
            }
        }, dumpheapFilter);

        // Inform checkpointing systems of success
        try {
            // This line is needed to CTS test for the correct exception handling
            // See b/138952436#comment36 for context
            Slog.i(TAG, "About to commit checkpoint");
            IStorageManager storageManager = PackageHelper.getStorageManager();
            storageManager.commitChanges();
        } catch (Exception e) {
            PowerManager pm = (PowerManager)
                     mContext.getSystemService(Context.POWER_SERVICE);
            pm.reboot("Checkpoint commit failed");
        }

        // Let system services know.
        mSystemServiceManager.startBootPhase(SystemService.PHASE_BOOT_COMPLETED);

   .....
    }

```

在AMS的finishBooting() 中调用了  
 SystemProperties.set(“sys.boot\_completed”, “1”); 系统属性标志开机完成


从源码中可以看出 这里开机完成后 肯定后执行这里


所以就在 这里添加 连接指定wifi 的代码如下 ：



```
private WifiManager mWifiManager = null;
final void finishBooting() {
    Trace.traceBegin(Trace.TRACE_TAG_ACTIVITY_MANAGER, "FinishBooting");

    synchronized (this) {
        if (!mBootAnimationComplete) {
            mCallFinishBooting = true;
            return;
        }
        mCallFinishBooting = false;
    }

    ArraySet<String> completedIsas = new ArraySet<String>();
    for (String abi : Build.SUPPORTED_ABIS) {
        ZYGOTE_PROCESS.establishZygoteConnectionForAbi(abi);
        final String instructionSet = VMRuntime.getInstructionSet(abi);
        if (!completedIsas.contains(instructionSet)) {
            try {
                mInstaller.markBootComplete(VMRuntime.getInstructionSet(abi));
            } catch (InstallerException e) {
                if (!VMRuntime.didPruneDalvikCache()) {
                    // This is technically not the right filter, as different zygotes may
                    // have made different pruning decisions. But the log is best effort,
                    // anyways.
                    Slog.w(TAG, "Unable to mark boot complete for abi: " + abi + " (" +
                            e.getMessage() +")");
                }
            }
            completedIsas.add(instructionSet);
        }
    }

    IntentFilter pkgFilter = new IntentFilter();
    pkgFilter.addAction(Intent.ACTION_QUERY_PACKAGE_RESTART);
    pkgFilter.addDataScheme("package");
    mContext.registerReceiver(new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String[] pkgs = intent.getStringArrayExtra(Intent.EXTRA_PACKAGES);
            if (pkgs != null) {
                for (String pkg : pkgs) {
                    synchronized (ActivityManagerService.this) {
                        if (forceStopPackageLocked(pkg, -1, false, false, false, false, false,
                                0, "query restart")) {
                            setResultCode(Activity.RESULT_OK);
                            return;
                        }
                    }
                }
            }
        }
    }, pkgFilter);

    IntentFilter dumpheapFilter = new IntentFilter();
    dumpheapFilter.addAction(DumpHeapActivity.ACTION_DELETE_DUMPHEAP);
    mContext.registerReceiver(new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final long delay = intent.getBooleanExtra(
                    DumpHeapActivity.EXTRA_DELAY_DELETE, false) ? 5 * 60 * 1000 : 0;
            mHandler.sendEmptyMessageDelayed(DELETE_DUMPHEAP_MSG, delay);
        }
    }, dumpheapFilter);

    // Inform checkpointing systems of success
    try {
        // This line is needed to CTS test for the correct exception handling
        // See b/138952436#comment36 for context
        Slog.i(TAG, "About to commit checkpoint");
        IStorageManager storageManager = PackageHelper.getStorageManager();
        storageManager.commitChanges();
    } catch (Exception e) {
        PowerManager pm = (PowerManager)
                 mContext.getSystemService(Context.POWER_SERVICE);
        pm.reboot("Checkpoint commit failed");
    }

    // Let system services know.
    mSystemServiceManager.startBootPhase(SystemService.PHASE_BOOT_COMPLETED);

    synchronized (this) {
        // Ensure that any processes we had put on hold are now started
        // up.
        final int NP = mProcessesOnHold.size();
        if (NP > 0) {
            ArrayList<ProcessRecord> procs =
                new ArrayList<ProcessRecord>(mProcessesOnHold);
            for (int ip=0; ip<NP; ip++) {
                if (DEBUG_PROCESSES) Slog.v(TAG_PROCESSES, "Starting process on hold: "
                        + procs.get(ip));
                mProcessList.startProcessLocked(procs.get(ip), new HostingRecord("on-hold"));
            }
        }
        if (mFactoryTest == FactoryTest.FACTORY_TEST_LOW_LEVEL) {
            return;
        }
        // Start looking for apps that are abusing wake locks.
        Message nmsg = mHandler.obtainMessage(CHECK_EXCESSIVE_POWER_USE_MSG);
        mHandler.sendMessageDelayed(nmsg, mConstants.POWER_CHECK_INTERVAL);
        // Tell anyone interested that we are done booting!
        SystemProperties.set("sys.boot\_completed", "1");
		
	// 添加指定连接wifi代码开始

       mWifiManager = (WifiManager) mContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!mWifiManager.isWifiEnabled()) mWifiManager.setWifiEnabled(true);
        mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
                                  addNetwork(createWifiInfo("test5","12345678",3));
			}
		},5000);
     // 添加指定连接wifi代码结束
           
       ....
}

```

通过上面的案例在finishBooting()启动完成后开始连接wifi 完成开机默认连接wifi功能实现  
 接下来添加wifi连接的代码



```
    public void addNetwork(WifiConfiguration wcg) {
        int wcgID = mWifiManager.addNetwork(wcg);
        boolean b = mWifiManager.enableNetwork(wcgID, true);
    }

    public WifiConfiguration createWifiInfo(String SSID, String Password, int Type) {
        WifiConfiguration config = new WifiConfiguration();
        config.allowedAuthAlgorithms.clear();
        config.allowedGroupCiphers.clear();
        config.allowedKeyManagement.clear();
        config.allowedPairwiseCiphers.clear();
        config.allowedProtocols.clear();
        config.SSID = "\"" + SSID + "\"";

        WifiConfiguration tempConfig = this.IsExsits(SSID);
        if (tempConfig != null) {

            mWifiManager.removeNetwork(tempConfig.networkId);

        }

        if (Type == 1) //WIFICIPHER_NOPASS
        {
//            config.wepKeys[0] = "";
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            config.wepTxKeyIndex = 0;
        }
        if (Type == 2) //WIFICIPHER_WEP
        {
            config.hiddenSSID = true;
            config.wepKeys[0] = "\"" + Password + "\"";
            config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            config.wepTxKeyIndex = 0;
        }
        if (Type == 3) //WIFICIPHER_WPA
        {
            config.preSharedKey = "\"" + Password + "\"";
            config.hiddenSSID = true;
            config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
            //config.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
            config.status = WifiConfiguration.Status.ENABLED;
        }
        return config;
    }
    private WifiConfiguration IsExsits(String SSID) {
        List<WifiConfiguration> existingConfigs = mWifiManager.getConfiguredNetworks();
        if (null == existingConfigs) {
            Log.i("xgr", "existingConfigs null ");
            return null;
        }
        for (WifiConfiguration existingConfig : existingConfigs) {
            if (existingConfig.SSID.equals("\"" + SSID + "\"")) {
                return existingConfig;
            }
        }
        return null;
    }

```

通过上述代码添加wifi连接的代码  
 实现了连接wifi的功能  
 就这样实现了 开机连接指定wifi的代码





