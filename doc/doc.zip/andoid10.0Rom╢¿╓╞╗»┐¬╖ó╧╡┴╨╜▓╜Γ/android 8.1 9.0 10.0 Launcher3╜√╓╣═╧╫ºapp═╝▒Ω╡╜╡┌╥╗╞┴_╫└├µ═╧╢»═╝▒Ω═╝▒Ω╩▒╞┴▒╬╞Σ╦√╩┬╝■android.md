






### 1.概述


在10.0的产品进行定制化开发Launcher3中，会对Launcher3 做些要求，比如现在的需求就是Launcher3第一屏的图标固定，不让其他屏的图标拖动到第一屏所以说这个需求和 禁止拖拽图标到Hotseat类似，也是从WorkSpace.java里面寻找解决方案


### 2.Launcher3禁止拖拽app图标到第一屏的核心类



```
/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java

```

### 3.Launcher3禁止拖拽app图标到第一屏的核心功能分析和实现


在Launcher3中对于app的拖拽功能都是在WorkSpace.java中处理的，所以  
 先来看下WorkSpace.java 的onDrop方法,可以从这里分析相关拖拽功能  
 从而实现对功能的实现



```
public class Workspace extends PagedView<WorkspacePageIndicator>
        implements DropTarget, DragSource, View.OnTouchListener,
        DragController.DragListener, Insettable, LauncherStateManager.StateHandler,
        WorkspaceLayoutManager {
        
 public void onDrop(final DragObject d, DragOptions options) {
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);
        CellLayout dropTargetLayout = mDropToLayout;

        // We want the point to be mapped to the dragTarget.
        if (dropTargetLayout != null) {
            mapPointFromDropLayout(dropTargetLayout, mDragViewVisualCenter);
        }

        boolean droppedOnOriginalCell = false;

        int snapScreen = -1;
        boolean resizeOnDrop = false;
        if (d.dragSource != this || mDragInfo == null) {
            final int[] touchXY = new int[] { (int) mDragViewVisualCenter[0],
                    (int) mDragViewVisualCenter[1] };
            onDropExternal(touchXY, dropTargetLayout, d);
        } else {
            AbstractFloatingView.closeOpenViews(mLauncher, false, AbstractFloatingView.TYPE_WIDGET_RESIZE_FRAME);
            final View cell = mDragInfo.cell;
            boolean droppedOnOriginalCellDuringTransition = false;
            Runnable onCompleteRunnable = null;



        
            if (dropTargetLayout != null && !d.cancelled ) {
                 // Move internally
                 boolean hasMovedLayouts = (getParentCellLayoutForView(cell) != dropTargetLayout);
                 boolean hasMovedIntoHotseat = mLauncher.isHotseatLayout(dropTargetLayout);
                  int container = hasMovedIntoHotseat ?
                        LauncherSettings.Favorites.CONTAINER_HOTSEAT :
                        LauncherSettings.Favorites.CONTAINER_DESKTOP;
                int screenId = (mTargetCell[0] < 0) ?
                        mDragInfo.screenId : getIdForScreen(dropTargetLayout);
                int spanX = mDragInfo != null ? mDragInfo.spanX : 1;
                int spanY = mDragInfo != null ? mDragInfo.spanY : 1;
                // First we find the cell nearest to point at which the item is
                // dropped, without any consideration to whether there is an item there.

                mTargetCell = findNearestArea((int) mDragViewVisualCenter[0], (int)
 mDragViewVisualCenter[1], spanX, spanY, dropTargetLayout, mTargetCell);
 float distance = dropTargetLayout.getDistanceFromCell(mDragViewVisualCenter[0],
 mDragViewVisualCenter[1], mTargetCell);

 // If the item being dropped is a shortcut and the nearest drop
 // cell also contains a shortcut, then create a folder with the two shortcuts.
 if (createUserFolderIfNecessary(cell, container,
 dropTargetLayout, mTargetCell, distance, false, d.dragView) ||
 addToExistingFolderIfNecessary(cell, dropTargetLayout, mTargetCell,
 distance, d, false)) {
                    mLauncher.getStateManager().goToState(NORMAL, SPRING_LOADED_EXIT_DELAY);
                    return;
                }

                // Aside from the special case where we're dropping a shortcut onto a shortcut,
                // we need to find the nearest cell location that is vacant
                ItemInfo item = d.dragInfo;
                int minSpanX = item.spanX;
                int minSpanY = item.spanY;
                if (item.minSpanX > 0 && item.minSpanY > 0) {
                    minSpanX = item.minSpanX;
                    minSpanY = item.minSpanY;
                }

                droppedOnOriginalCell = item.screenId == screenId && item.container == container
                        && item.cellX == mTargetCell[0] && item.cellY == mTargetCell[1];
                droppedOnOriginalCellDuringTransition = droppedOnOriginalCell && mIsSwitchingState;

                // When quickly moving an item, a user may accidentally rearrange their
                // workspace. So instead we move the icon back safely to its original position.
                boolean returnToOriginalCellToPreventShuffling = !isFinishedSwitchingState()
                        && !droppedOnOriginalCellDuringTransition && !dropTargetLayout
                        .isRegionVacant(mTargetCell[0], mTargetCell[1], spanX, spanY);
                int[] resultSpan = new int[2];
                if (returnToOriginalCellToPreventShuffling) {
                    mTargetCell[0] = mTargetCell[1] = -1;
                } else {
                    mTargetCell = dropTargetLayout.performReorder((int) mDragViewVisualCenter[0],
                            (int) mDragViewVisualCenter[1], minSpanX, minSpanY, spanX, spanY, cell,
                            mTargetCell, resultSpan, CellLayout.MODE_ON_DROP);
                }

.....

```

在Workspace.java中关于拖拽图标的onDrop的方法中通过源码发现，拖拽功能  
 同样的也是通过dropTargetLayout 来进行判断 拖动到哪个区域 而通过Workspace.java 源码我们知道，在上述源码中getIdForScreen(CellLayout layout)就是判断当前需要拖拽到哪一屏去，而getIdForScreen(dropTargetLayout)!=0 判断是否拖拽到第一屏  
 的拖拽图标  
 mTargetCell[1] 判断拖拽到哪一行 所以也是在这里修改，来解决问题



```
public int getIdForScreen(CellLayout layout) {
        int index = mWorkspaceScreens.indexOfValue(layout);
        if (index != -1) {
            return mWorkspaceScreens.keyAt(index);
        }
        return -1;
    }

```

通过在onDrop的方法中添加getIdForScreen(CellLayout layout)需要拖拽到哪一屏来判断，是否可以拖拽到那一屏，如果不能就需要返回，具体


修改如下:



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java
@@ -1876,8 +1876,9 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
     public void onDrop(final DragObject d, DragOptions options) {
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);
        CellLayout dropTargetLayout = mDropToLayout;

             //add core start
-            if (dropTargetLayout != null && !d.cancelled ) {
+            if (dropTargetLayout != null && !d.cancelled && getIdForScreen(dropTargetLayout)!=0 && mTargetCell[1]!=0) {
                 // Move internally
                 boolean hasMovedLayouts = (getParentCellLayoutForView(cell) != dropTargetLayout);
                 boolean hasMovedIntoHotseat = mLauncher.isHotseatLayout(dropTargetLayout);
                  int container = hasMovedIntoHotseat ?
                        LauncherSettings.Favorites.CONTAINER_HOTSEAT :
                        LauncherSettings.Favorites.CONTAINER_DESKTOP;

```

通过在onDrop中在拖拽到某一屏的时候增加判断当前的getIdForScreen(dropTargetLayout)不为0的条件即表示不拖拽到第一屏，从而实现禁止拖拽app到第一屏的功能





