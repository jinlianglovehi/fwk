



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.支持多个app同时录音的核心代码](#2.%E6%94%AF%E6%8C%81%E5%A4%9A%E4%B8%AAapp%E5%90%8C%E6%97%B6%E5%BD%95%E9%9F%B3%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.支持多个app同时录音的核心代码分析及功能实现](#3.%E6%94%AF%E6%8C%81%E5%A4%9A%E4%B8%AAapp%E5%90%8C%E6%97%B6%E5%BD%95%E9%9F%B3%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E5%8F%8A%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1支持多个app同时录音的代码分析](#3.1%E6%94%AF%E6%8C%81%E5%A4%9A%E4%B8%AAapp%E5%90%8C%E6%97%B6%E5%BD%95%E9%9F%B3%E7%9A%84%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2具体修改为](#3.2%E5%85%B7%E4%BD%93%E4%BF%AE%E6%94%B9%E4%B8%BA)




---



## 1.概述


在10.0的定制化开发中，由于有多个app的audio部分需要进行录音功能，所以要求系统framework需要同时支持多个app同时录音满足需求，这就需要跟相关代码来实现这个功能


## 2.支持多个app同时录音的核心代码



```
主要代码为:
frameworks/av/services/audiopolicy/service/AudioPolicyService.cpp
```

## 3.支持多个app同时录音的核心代码分析及功能实现


#### 3.1支持多个app同时录音的代码分析


通过查阅10.0相关代码发现默认支持多个app同时录音，但是经过测试发现还是有一部分问题的，


两个app虽然能同时使用 AudioRecord, 但是后一个应用调用后能正常拿到音频数据, 前一个应用就拿不到音频数据


查阅资料发现 具体处理是在AudioPolicyService.cpp中



```
void AudioPolicyService::updateUidStates_l()
{
//    Go over all active clients and allow capture (does not force silence) in the
//    following cases:
//    Another client in the same UID has already been allowed to capture
//    OR The client is the assistant
//        AND an accessibility service is on TOP or a RTT call is active
//               AND the source is VOICE_RECOGNITION or HOTWORD
//        OR uses VOICE_RECOGNITION AND is on TOP
//               OR uses HOTWORD
//            AND there is no active privacy sensitive capture or call
//                OR client has CAPTURE_AUDIO_OUTPUT privileged permission
//    OR The client is an accessibility service
//        AND is on TOP
//        AND the source is VOICE_RECOGNITION or HOTWORD
//    OR the client source is virtual (remote submix, call audio TX or RX...)
//    OR Any client
//        AND The assistant is not on TOP
//        AND is on TOP or latest started
//        AND there is no active privacy sensitive capture or call
//                OR client has CAPTURE_AUDIO_OUTPUT privileged permission
sp<AudioRecordClient> topActive;
sp<AudioRecordClient> latestActive;
sp<AudioRecordClient> latestSensitiveActive;

nsecs_t topStartNs = 0;
nsecs_t latestStartNs = 0;
nsecs_t latestSensitiveStartNs = 0;
bool isA11yOnTop = mUidPolicy->isA11yOnTop();
bool isAssistantOnTop = false;
bool isSensitiveActive = false;
bool isInCall = mPhoneState == AUDIO_MODE_IN_CALL;
bool rttCallActive =
        (mPhoneState == AUDIO_MODE_IN_CALL || mPhoneState == AUDIO_MODE_IN_COMMUNICATION)
        && mUidPolicy->isRttEnabled();

// if Sensor Privacy is enabled then all recordings should be silenced.
if (mSensorPrivacyPolicy->isSensorPrivacyEnabled()) {
    silenceAllRecordings_l();
    return;
}

for (size_t i =0; i < mAudioRecordClients.size(); i++) {
    sp<AudioRecordClient> current = mAudioRecordClients[i];
    if (!current->active) {
        continue;
    }

    app_state_t appState = apmStatFromAmState(mUidPolicy->getUidState(current->uid));
    // clients which app is in IDLE state are not eligible for top active or
    // latest active
    if (appState == APP_STATE_IDLE) {
        continue;
    }

    if (appState == APP_STATE_TOP) {
        if (current->startTimeNs > topStartNs) {
            topActive = current;
            topStartNs = current->startTimeNs;
        }
        if (mUidPolicy->isAssistantUid(current->uid)) {
            isAssistantOnTop = true;
        }
    }
    if (current->startTimeNs > latestStartNs) {
        latestActive = current;
        latestStartNs = current->startTimeNs;
    }
    if (isPrivacySensitiveSource(current->attributes.source)) {
        if (current->startTimeNs > latestSensitiveStartNs) {
            latestSensitiveActive = current;
            latestSensitiveStartNs = current->startTimeNs;
        }
        isSensitiveActive = true;
    }
}

// if no active client with UI on Top, consider latest active as top
if (topActive == nullptr) {
    topActive = latestActive;
}

std::vector<uid_t> enabledUids;

for (size_t i =0; i < mAudioRecordClients.size(); i++) {
    sp<AudioRecordClient> current = mAudioRecordClients[i];
    if (!current->active) {
        continue;
    }

    // keep capture allowed if another client with the same UID has already
    // been allowed to capture
    if (std::find(enabledUids.begin(), enabledUids.end(), current->uid)
            != enabledUids.end()) {
        continue;
    }

    audio_source_t source = current->attributes.source;
    bool isTopOrLatestActive = topActive == nullptr ? false : current->uid == topActive->uid;
    bool isLatestSensitive = latestSensitiveActive == nullptr ?
                             false : current->uid == latestSensitiveActive->uid;

    // By default allow capture if:
    //     The assistant is not on TOP
    //     AND is on TOP or latest started
    //     AND there is no active privacy sensitive capture or call
    //             OR client has CAPTURE_AUDIO_OUTPUT privileged permission
    bool allowCapture = !isAssistantOnTop
            && ((isTopOrLatestActive && !isLatestSensitive) || isLatestSensitive)
            && !(isSensitiveActive && !(isLatestSensitive || current->canCaptureOutput))
            && !(isInCall && !current->canCaptureOutput);

    if (isVirtualSource(source)) {
        // Allow capture for virtual (remote submix, call audio TX or RX...) sources
        allowCapture = true;
    } else if (mUidPolicy->isAssistantUid(current->uid)) {
        // For assistant allow capture if:
        //     An accessibility service is on TOP or a RTT call is active
        //            AND the source is VOICE_RECOGNITION or HOTWORD
        //     OR is on TOP AND uses VOICE_RECOGNITION
        //            OR uses HOTWORD
        //         AND there is no active privacy sensitive capture or call
        //             OR client has CAPTURE_AUDIO_OUTPUT privileged permission
        if (isA11yOnTop || rttCallActive) {
            if (source == AUDIO_SOURCE_HOTWORD || source == AUDIO_SOURCE_VOICE_RECOGNITION) {
                allowCapture = true;
            }
        } else {
            if (((isAssistantOnTop && source == AUDIO_SOURCE_VOICE_RECOGNITION) ||
                    source == AUDIO_SOURCE_HOTWORD) &&
                    (!(isSensitiveActive || isInCall) || current->canCaptureOutput)) {
                allowCapture = true;
            }
        }
    } else if (mUidPolicy->isA11yUid(current->uid)) {
        // For accessibility service allow capture if:
        //     Is on TOP
        //     AND the source is VOICE_RECOGNITION or HOTWORD
        if (isA11yOnTop &&
                (source == AUDIO_SOURCE_VOICE_RECOGNITION || source == AUDIO_SOURCE_HOTWORD)) {
            allowCapture = true;
        }
    }
    setAppState_l(current->uid,
                  allowCapture ? apmStatFromAmState(mUidPolicy->getUidState(current->uid)) :
                            APP_STATE_IDLE);
    if (allowCapture) {
        enabledUids.push_back(current->uid);
    }
}


}

```

从相关代码发现具体输入源为



```
if (isVirtualSource(source)) {
// Allow capture for virtual (remote submix, call audio TX or RX...) sources
allowCapture = true;
}
只要source 是在支持的范围之内就可以了
/* static */
bool AudioPolicyService::isVirtualSource(audio_source_t source)
{
switch (source) {
case AUDIO_SOURCE_VOICE_UPLINK:
case AUDIO_SOURCE_VOICE_DOWNLINK:
case AUDIO_SOURCE_VOICE_CALL:
case AUDIO_SOURCE_REMOTE_SUBMIX:
case AUDIO_SOURCE_FM_TUNER:
return true;
default:
break;
}
return false;
}
多个app同时录音 需要对这个 AUDIO_SOURCE_VOICE_RECOGNITION的source支持

```

#### 3.2具体修改为



```
bool AudioPolicyService::isVirtualSource(audio_source_t source)
{
switch (source) {
case AUDIO_SOURCE_VOICE_UPLINK:
case AUDIO_SOURCE_VOICE_DOWNLINK:
case AUDIO_SOURCE_VOICE_CALL:
case AUDIO_SOURCE_REMOTE_SUBMIX:
case AUDIO_SOURCE_FM_TUNER:
+ case AUDIO_SOURCE_VOICE_RECOGNITION:
return true;
default:
break;
}
return false;
}
```

支持多个app同时录音功能就修改到这里



