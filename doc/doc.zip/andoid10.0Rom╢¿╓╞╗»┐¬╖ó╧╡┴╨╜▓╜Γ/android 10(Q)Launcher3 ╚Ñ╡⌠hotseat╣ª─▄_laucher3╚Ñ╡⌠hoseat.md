






### 1.概述


在10.0的产品定制化开发过程中，需要对launcher3 进行定制，产品要求去掉 hotseat 五个图标，就是需要去掉hotseat功能


### 2.Launcher3 去掉hotseat功能的核心类



```
packages/apps/Launcher3/res/layout/launcher.xml
packages/apps/Launcher3/src/com/android/launcher3/DeviceProfile.java
packages/apps/Launcher3/src/com/android/launcher3/Workspace.java

```

### 3.Launcher3 去掉hotseat功能的核心功能分析和实现


实现思路：


1. 去掉hotseat布局显示  
 2.DeviceProfile 里面去掉关于hotseat的高度和 间距  
 3.屏蔽加载HotSeat的相关功能


实现步骤


### 3.1 去掉hotseat布局显示



```
diff --git a/packages/apps/Launcher3/res/layout/launcher.xml b/packages/apps/Launcher3/res/layout/launcher.xml
old mode 100644
new mode 100755
index 7d3f09adbc..e6fcbd9201
--- a/packages/apps/Launcher3/res/layout/launcher.xml
+++ b/packages/apps/Launcher3/res/layout/launcher.xml
@@ -43,7 +43,8 @@
         <!-- DO NOT CHANGE THE ID -->
         <include
             android:id="@+id/hotseat"
-            layout="@layout/hotseat" />
+            layout="@layout/hotseat"
+            android:visibility="gone" />
 
         <include
             android:id="@+id/overview\_panel"

```

在lancher.xml中去掉hotseat布局，hotseat布局隐藏就可以了


### 3.2 DeviceProfile 里面去掉关于hotseat的高度和 间距



```
diff --git a/packages/apps/Launcher3/src/com/android/launcher3/DeviceProfile.java b/packages/apps/Launcher3/src/com/android/launcher3/DeviceProfile.java
old mode 100644
new mode 100755
index ce32dc80e4..e18357c836
--- a/packages/apps/Launcher3/src/com/android/launcher3/DeviceProfile.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/DeviceProfile.java
@@ -106,13 +106,13 @@ public class DeviceProfile {
 
     // Hotseat
     public int hotseatCellHeightPx;
-    // In portrait: size = height, in landscape: size = width
+ // In portrait: size = height, in landscape: size = width
     public int hotseatBarSizePx;
-    public final int hotseatBarTopPaddingPx;
-    public int hotseatBarBottomPaddingPx;
+    public final int hotseatBarTopPaddingPx=0;
+    public int hotseatBarBottomPaddingPx=0;
     // Start is the side next to the nav bar, end is the side next to the workspace
-    public final int hotseatBarSidePaddingStartPx;
-    public final int hotseatBarSidePaddingEndPx;
+    public final int hotseatBarSidePaddingStartPx=0;
+    public final int hotseatBarSidePaddingEndPx=0;
 
     // All apps
     public int allAppsCellHeightPx;
@@ -205,19 +205,19 @@ public class DeviceProfile {
 
         workspaceCellPaddingXPx = res.getDimensionPixelSize(R.dimen.dynamic_grid_cell_padding_x);
 
-        hotseatBarTopPaddingPx =
-                res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_top_padding);
-        hotseatBarBottomPaddingPx = (isTallDevice ? 0
-                : res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_bottom_non_tall_padding))
-                + res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_bottom_padding);
-        hotseatBarSidePaddingEndPx =
-                res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_side_padding);
+        //hotseatBarTopPaddingPx =
+                //res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_top_padding);
+        //hotseatBarBottomPaddingPx = (isTallDevice ? 0
+               // : res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_bottom_non_tall_padding))
+                //+ res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_bottom_padding);
+        //hotseatBarSidePaddingEndPx =
+                //res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_side_padding);
         // Add a bit of space between nav bar and hotseat in vertical bar layout.
-        hotseatBarSidePaddingStartPx = isVerticalBarLayout() ? verticalDragHandleSizePx : 0;
-        hotseatBarSizePx = ResourceUtils.pxFromDp(inv.iconSize, dm) + (isVerticalBarLayout()
-                ? (hotseatBarSidePaddingStartPx + hotseatBarSidePaddingEndPx)
-                : (res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_extra_vertical_size)
-                        + hotseatBarTopPaddingPx + hotseatBarBottomPaddingPx));
+        //hotseatBarSidePaddingStartPx = isVerticalBarLayout() ? verticalDragHandleSizePx : 0;
+        //hotseatBarSizePx = ResourceUtils.pxFromDp(inv.iconSize, dm) + (isVerticalBarLayout()
+                //? (hotseatBarSidePaddingStartPx + hotseatBarSidePaddingEndPx)
+                //: (res.getDimensionPixelSize(R.dimen.dynamic_grid_hotseat_extra_vertical_size)
+                   //     + hotseatBarTopPaddingPx + hotseatBarBottomPaddingPx));
 
         // Calculate all of the remaining variables.
         updateAvailableDimensions(dm, res);
@@ -228,13 +228,13 @@ public class DeviceProfile {
             // ie. For a display with a large aspect ratio, we can keep the icons on the workspace
             // in portrait mode closer together by adding more height to the hotseat.
             // Note: This calculation was created after noticing a pattern in the design spec.
-            int extraSpace = getCellSize().y - iconSizePx - iconDrawablePaddingPx * 2
-                    - verticalDragHandleSizePx;
-            hotseatBarSizePx += extraSpace;
-            hotseatBarBottomPaddingPx += extraSpace;
+            //int extraSpace = getCellSize().y - iconSizePx - iconDrawablePaddingPx * 2
+                    //- verticalDragHandleSizePx;
+            //hotseatBarSizePx += extraSpace;
+            //hotseatBarBottomPaddingPx += extraSpace;
 
             // Recalculate the available dimensions using the new hotseat size.
-            updateAvailableDimensions(dm, res);
+            //updateAvailableDimensions(dm, res);
         }
         updateWorkspacePadding();
 
@@ -369,10 +369,11 @@ public class DeviceProfile {
 
         // Hotseat
         if (isVerticalLayout) {
-            hotseatBarSizePx = iconSizePx + hotseatBarSidePaddingStartPx
-                    + hotseatBarSidePaddingEndPx;
+//                     hotseatBarSizePx = iconSizePx + hotseatBarSidePaddingStartPx
+//                    + hotseatBarSidePaddingEndPx;
         }
-        hotseatCellHeightPx = iconSizePx;
+//        hotseatCellHeightPx = iconSizePx;
+               hotseatCellHeightPx = 0;
 
         if (!isVerticalLayout) {
             int expectedWorkspaceHeight = availableHeightPx - hotseatBarSizePx
@@ -472,7 +473,7 @@ public class DeviceProfile {
         Rect padding = workspacePadding;
         if (isVerticalBarLayout()) {
             padding.top = 0;
-            padding.bottom = edgeMarginPx;
+            //padding.bottom = edgeMarginPx;
 
             int offset = 0;
             if (isMultiWindowMode) {
@@ -485,11 +486,11 @@ public class DeviceProfile {
                 }
             }
             if (isSeascape()) {
-                padding.left = hotseatBarSizePx;
-                padding.right = verticalDragHandleSizePx + offset;
+                //padding.left = hotseatBarSizePx;
+                //padding.right = verticalDragHandleSizePx + offset;
             } else {
-                padding.left = verticalDragHandleSizePx + offset;
-                padding.right = hotseatBarSizePx;
+                //padding.left = verticalDragHandleSizePx + offset;
+                //padding.right = hotseatBarSizePx;
             }
         } else {
             int paddingBottom = hotseatBarSizePx + verticalDragHandleSizePx
@@ -498,21 +499,21 @@ public class DeviceProfile {
                 // Pad the left and right of the workspace to ensure consistent spacing
                 // between all icons
                 // The amount of screen space available for left/right padding.
-                int availablePaddingX = Math.max(0, widthPx - ((inv.numColumns \* cellWidthPx) +
- ((inv.numColumns - 1) \* cellWidthPx)));
-                availablePaddingX = (int) Math.min(availablePaddingX,
-                        widthPx * MAX_HORIZONTAL_PADDING_PERCENT);
-                int availablePaddingY = Math.max(0, heightPx - edgeMarginPx - paddingBottom
-                        - (2 * inv.numRows * cellHeightPx) - hotseatBarTopPaddingPx
-                        - hotseatBarBottomPaddingPx);
-                padding.set(availablePaddingX / 2, edgeMarginPx + availablePaddingY / 2,
-                        availablePaddingX / 2, paddingBottom + availablePaddingY / 2);
+                //int availablePaddingX = Math.max(0, widthPx - ((inv.numColumns \* cellWidthPx) +
+ //((inv.numColumns - 1) \* cellWidthPx)));
+                //availablePaddingX = (int) Math.min(availablePaddingX,
+                        //widthPx * MAX_HORIZONTAL_PADDING_PERCENT);
+                //int availablePaddingY = Math.max(0, heightPx - edgeMarginPx - paddingBottom
+                        //- (2 * inv.numRows * cellHeightPx) - hotseatBarTopPaddingPx
+                       // - hotseatBarBottomPaddingPx);
+                //padding.set(availablePaddingX / 2, edgeMarginPx + availablePaddingY / 2,
+                        //availablePaddingX / 2, paddingBottom + availablePaddingY / 2);
             } else {
                 // Pad the top and bottom of the workspace with search/hotseat bar sizes
-                padding.set(desiredWorkspaceLeftRightMarginPx,
-                        edgeMarginPx,
-                        desiredWorkspaceLeftRightMarginPx,
-                        paddingBottom);
+                //padding.set(desiredWorkspaceLeftRightMarginPx,
+                        //edgeMarginPx,
+                        //desiredWorkspaceLeftRightMarginPx,
+                        //paddingBottom);
             }
         }
     }
@@ -520,11 +521,11 @@ public class DeviceProfile {
     public Rect getHotseatLayoutPadding() {
         if (isVerticalBarLayout()) {
             if (isSeascape()) {
-                mHotseatPadding.set(mInsets.left + hotseatBarSidePaddingStartPx,
-                        mInsets.top, hotseatBarSidePaddingEndPx, mInsets.bottom);
+                //mHotseatPadding.set(mInsets.left + hotseatBarSidePaddingStartPx,
+                        //mInsets.top, hotseatBarSidePaddingEndPx, mInsets.bottom);
             } else {
-                mHotseatPadding.set(hotseatBarSidePaddingEndPx, mInsets.top,
-                        mInsets.right + hotseatBarSidePaddingStartPx, mInsets.bottom);
+                //mHotseatPadding.set(hotseatBarSidePaddingEndPx, mInsets.top,
+                        //mInsets.right + hotseatBarSidePaddingStartPx, mInsets.bottom);
             }
         } else {
 
@@ -532,14 +533,14 @@ public class DeviceProfile {
             // icons in the hotseat are a different size, and so don't line up perfectly. To account
             // for this, we pad the left and right of the hotseat with half of the difference of a
             // workspace cell vs a hotseat cell.
-            float workspaceCellWidth = (float) widthPx / inv.numColumns;
-            float hotseatCellWidth = (float) widthPx / inv.numHotseatIcons;
-            int hotseatAdjustment = Math.round((workspaceCellWidth - hotseatCellWidth) / 2);
-            mHotseatPadding.set(
-                    hotseatAdjustment + workspacePadding.left + cellLayoutPaddingLeftRightPx,
-                    hotseatBarTopPaddingPx,
-                    hotseatAdjustment + workspacePadding.right + cellLayoutPaddingLeftRightPx,
-                    hotseatBarBottomPaddingPx + mInsets.bottom + cellLayoutBottomPaddingPx);
+            //float workspaceCellWidth = (float) widthPx / inv.numColumns;
+            //float hotseatCellWidth = (float) widthPx / inv.numHotseatIcons;
+            //int hotseatAdjustment = Math.round((workspaceCellWidth - hotseatCellWidth) / 2);
+            //mHotseatPadding.set(
+                    //hotseatAdjustment + workspacePadding.left + cellLayoutPaddingLeftRightPx,
+                    //hotseatBarTopPaddingPx,
+                    //hotseatAdjustment + workspacePadding.right + cellLayoutPaddingLeftRightPx,
+                    //hotseatBarBottomPaddingPx + mInsets.bottom + cellLayoutBottomPaddingPx);
         }
         return mHotseatPadding;
     }
@@ -565,9 +566,11 @@ public class DeviceProfile {
     }
 
     public static int calculateCellWidth(int width, int countX) {
+               if(countX==0) return 0;
         return width / countX;
     }
     public static int calculateCellHeight(int height, int countY) {
+               if(countY==0) return 0;
         return height / countY;
     }
 
@@ -609,7 +612,7 @@ public class DeviceProfile {
             case CellLayout.FOLDER:
                 return folderCellHeightPx;
             case CellLayout.HOTSEAT:
-                return hotseatCellHeightPx;
+                return 0;
             default:
                 // ??
                 return 0;

```

在DeviceProfile.java中的构造方法中，设置最重要的hotseat的高度参数hotseatBarSizePx为0即可，其他的关于hotseat的padding参数可以不改，接下来修改Hotseat不让拖拽到hotseat里面的功能


### 3.3屏蔽加载HotSeat的相关功能



```
diff --git a/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java b/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java
index 924b821e00..c803d29328 100755
--- a/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java
@@ -1876,8 +1876,8 @@ public class Workspace extends CyclePagedView<WorkspaceBasePageIndicator>
    public void onDrop(final DragObject d, DragOptions options) {
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);
        CellLayout dropTargetLayout = mDropToLayout;

        // We want the point to be mapped to the dragTarget.
        if (dropTargetLayout != null) {
            mapPointFromDropLayout(dropTargetLayout, mDragViewVisualCenter);
        }

        boolean droppedOnOriginalCell = false;

        int snapScreen = -1;
        boolean resizeOnDrop = false;
        if (d.dragSource != this || mDragInfo == null) {
            final int[] touchXY = new int[] { (int) mDragViewVisualCenter[0],
                    (int) mDragViewVisualCenter[1] };
            onDropExternal(touchXY, dropTargetLayout, d);
        } else {
            AbstractFloatingView.closeOpenViews(mLauncher, false, AbstractFloatingView.TYPE_WIDGET_RESIZE_FRAME);
            final View cell = mDragInfo.cell;
            boolean droppedOnOriginalCellDuringTransition = false;
            Runnable onCompleteRunnable = null;
-
-            if (dropTargetLayout != null && !d.cancelled) {
+            //motify 2021.7.5
+            if (dropTargetLayout != null && !d.cancelled && !mLauncher.isHotseatLayout(dropTargetLayout)) {
                 // Move internally
                 boolean hasMovedLayouts = (getParentCellLayoutForView(cell) != dropTargetLayout);
                 boolean hasMovedIntoHotseat = mLauncher.isHotseatLayout(dropTargetLayout);
                 int container = hasMovedIntoHotseat ?
                        LauncherSettings.Favorites.CONTAINER_HOTSEAT :
                        LauncherSettings.Favorites.CONTAINER_DESKTOP;
                int screenId = (mTargetCell[0] < 0) ?
                        mDragInfo.screenId : getIdForScreen(dropTargetLayout);
                int spanX = mDragInfo != null ? mDragInfo.spanX : 1;
                int spanY = mDragInfo != null ? mDragInfo.spanY : 1;
                // First we find the cell nearest to point at which the item is
                // dropped, without any consideration to whether there is an item there.


```

通过在WorkSpace.java中的onDrop中判断当是往hotseat拖拽拖拽的都禁止，增加mLauncher.isHotseatLayout(dropTargetLayout)这个拖拽条件即可





