






### 1.概述


在10.0的产品开发中，产品开发定制需求，需要自定义系统服务来提供接口来给app调用系统的接口，实现功能的实现，根据需求自定义系统服务的实现


### 2.添加自定义系统服务接口给app调用的核心类



```
frameworks\base\core\java\android\os\ILgyManager.aidl
frameworks\base\Android.bp
frameworks\base\services\core\java\com\android\server\lgy\LgyManagerService.java
frameworks\base\services\java\com\android\server\SystemServer.java
frameworks\base\core\java\android\os\LgyManager.java
frameworks\base\core\java\android\content\Context.java
frameworks\base\core\java\android\app\SystemServiceRegistry.java


```

### 3.添加自定义系统服务接口给app调用的核心功能分析和实现


### 3.1 系统自定义服务添加AIDL系统接口


路径: frameworks\base\core\java\android\os\ILgyManager.aidl



```


package android.os;
/** @hide */
 
interface ILgyManager
{
	String getVal();
   
}

```

添加ILgyManager.aidl的文件来增加接口 getVal()的接口


### 3.2 在frameworks\base\Android.bp中添加我们的AIDL，让其编译进系统



```
"core/java/android/os/ILgyManager.aidl",

```

在Android.bp添加新增的aidl,让其参与编译


### 3.3 添加自定义服务service


在frameworks\base\services\core\java\com\android\server\下创建自己的文件夹lgy，并创建自己的service  
 lgy\LgyManagerService.java



```
package com.android.server.lgy;
 
import com.android.server.SystemService;
import android.content.Context;
import android.util.Log;
import java.util.HashMap;
import android.os.ILgyManager;
 
 
public final class LgyManagerService extends ILgyManager.Stub{
	
	private static final String TAG = "LgyManagerService";
	final Context mContext;
    public LgyManagerService(Context context) {
        mContext = context;				
 
    }	
    @Override
	public  String getVal(){
		
		try{
			Log.d("lgy\_bubug", "GetFromJni ");
			return "GetFromJni ";
		}catch(Exception e){
			Log.d("lgy\_bubug", "nativeReadPwd Exception msg = " + e.getMessage());
			return " read nothings!!!";
		}
	} 	
 
}

```

通过添加自定义系统服务来实现对自定义接口的相关方法的调用，提供给app来实现功能


### 3.4在frameworks\base\services\java\com\android\server\SystemServer.java中启动我们的服务


在SystemServer的startOtherServices()中把系统自定义的服务添加进系统让其在系统开机时，启动自定义服务，供上层调用自定义服务



```
 private void startOtherServices() {
           LgyManagerService lgyService = null;//lgy
            .......
            .......
            .......
            traceBeginAndSlog("StartVibratorService");
            vibrator = new VibratorService(context);
            ServiceManager.addService("vibrator", vibrator);
            traceEnd();
			
			//lgy
			traceBeginAndSlog("StartLgyManService");
			try {  
			if(lgyService==null){			 
			   lgyService = new LgyManagerService(context);
			}
            ServiceManager.addService("lgy", lgyService);
			 } catch (Throwable e) {
                     Slog.e(TAG, "Failure starting LgyManagerService ", e);
              }
			traceEnd();
			//lgy
 
}

```

在startOtherServices()调用ServiceManager.addService让自定义服务给ServiceManager管理


### 3.5 添加自定义管理类给app层调用的接口



```
frameworks\base\core\java\android\os\LgyManager.java
package android.os;
 
import android.annotation.SystemService;
import android.content.Context;
import android.util.Log;
import android.os.Handler;
import android.os.SystemProperties;
import java.io.IOException;
import java.io.DataInputStream;
//@SystemService(Context.LGY_SERVICE)
public final class LgyManager {
    private static final String TAG = "LgyManager";
	final Context mContext;
    final ILgyManager mService;
    /**
     * {@hide}
     */
    public LgyManager(Context context, ILgyManager service, Handler handler) {
        mContext = context;
        mService = service;
        mHandler = handler;
    }
	
	public String getVal() {
		Log.d(TAG,"lgy\_debug getVal ");
        try {
           return mService.getVal();
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }	
}

```

添加自定义服务的管理类在上层app中可以通过调用这个自定义服务管理类来调用系统的自定义接口实现其功能


### 3. 6 在frameworks\base\core\java\android\content\Context.java 添加服务标签



```
   +++  public static final String LGY_SERVICE = "lgy";
 
 
    /** @hide */
    @StringDef(suffix = { "\_SERVICE" }, value = {
            POWER_SERVICE,
            WINDOW_SERVICE,
            LAYOUT_INFLATER_SERVICE,
            ACCOUNT_SERVICE,
            ACTIVITY_SERVICE,
            ALARM_SERVICE,
            NOTIFICATION_SERVICE,
            ACCESSIBILITY_SERVICE,
            CAPTIONING_SERVICE,
            KEYGUARD_SERVICE,
            LOCATION_SERVICE,
            //@hide: COUNTRY_DETECTOR,
            SEARCH_SERVICE,
            SENSOR_SERVICE,
            STORAGE_SERVICE,
            STORAGE_STATS_SERVICE,
            WALLPAPER_SERVICE,
            TIME_ZONE_RULES_MANAGER_SERVICE,
            VIBRATOR_SERVICE,
      +++   LGY_SERVICE,

```

### 3.7在frameworks\base\core\java\android\app\SystemServiceRegistry.java注册系统自定义服务


在SystemServiceRegistry.java中通过registerService来注册自定义的服务来在  
 系统中方便binder通讯实现app和系统的通讯



```

    registerService(Context.LGY_SERVICE, LgyManager.class,
            new CachedServiceFetcher<LgyManager>() {
        @Override
        public LgyManager createService(ContextImpl ctx) throws ServiceNotFoundException {
            IBinder b = ServiceManager.getServiceOrThrow(Context.LGY_SERVICE);
            ILgyManager service = ILgyManager.Stub.asInterface(b);
            return new LgyManager(ctx.getOuterContext(),
                    service, ctx.mMainThread.getHandler());
        }});

```

### 3.8 在增加自定义类给app中调用api


增加自定义的类在生成jar 供上层通过这个类来调用系统自定义服务的相对应的接口



```
package android.mom;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.ILgyManager;
import java.util.List;

public class SuperPower {
    private Context mContext;
    private ILgyManager mdmApiManager;
    public SuperPower(){

    }
    /**
     *
     * @param context
     * @see
     */
    public SuperPower(Context context){
        this.mContext = context;
        mdmApiManager = (ILgyManager) mContext.getSystemService(Context.LGY_SERVICE);
    }
  
  public void getval(){
     mdmApiManager.getVal();
  }
 }

```

### 3.9 新增的service配置selinux策略



```
默认新增的 GetWifiMacService服务的seandroid类型为default_android_service。如果不配置第三方App访问不了。具体配置如下:

```


```
    在文件system\sepolicy\private\service_contexts中添加如下内容

    # ///ADD START
    lgy                                  u:object_r:lgy_service:s0
    # ///ADD END

    在文件system\sepolicy\prebuilts\api\29.0\private\service_contexts中添加如下内容

    # ///ADD START
    lgy                                  u:object_r:lgy_service:s0
    # ///ADD END
    ​​​​​​​

    在文件system\sepolicy\public\service.te中添加如下内容

    # ///ADD START
    type lgy_service, app_api_service, ephemeral_app_api_service, system_server_service, service_manager_type;
    # ///ADD END

    ​​​​​​​

    在文件system\sepolicy\prebuilts\api\29.0\public\service.te中添加如下内容

# ///ADD START
type lgy_service, app_api_service, ephemeral_app_api_service, system_server_service, service_manager_type;
# ///ADD END

diff --git a/system/sepolicy/prebuilts/api/26.0/public/service.te b/system/sepolicy/prebuilts/api/26.0/public/service.te
old mode 100644 (file)
new mode 100755 (executable)
index da540db..16a4221
--- a/system/sepolicy/prebuilts/api/26.0/public/service.te
+++ b/system/sepolicy/prebuilts/api/26.0/public/service.te
@@ -145,3 +145,4 @@ type wifi_service, app_api_service, system_server_service, service_manager_type;
 type wificond_service, service_manager_type;
 type wifiaware_service, app_api_service, system_server_service, service_manager_type;
 type window_service, system_api_service, system_server_service, service_manager_type;
+type lgy_service, system_api_service, system_server_service, service_manager_type;
diff --git a/system/sepolicy/prebuilts/api/27.0/public/service.te b/system/sepolicy/prebuilts/api/27.0/public/service.te
old mode 100644 (file)
new mode 100755 (executable)
index e97b864..32ca6a0
--- a/system/sepolicy/prebuilts/api/27.0/public/service.te
+++ b/system/sepolicy/prebuilts/api/27.0/public/service.te
@@ -148,3 +148,4 @@ type wifi_service, app_api_service, system_server_service, service_manager_type;
 type wificond_service, service_manager_type;
 type wifiaware_service, app_api_service, system_server_service, service_manager_type;
 type window_service, system_api_service, system_server_service, service_manager_type;
+type lgy_service, system_api_service, system_server_service, service_manager_type;
diff --git a/system/sepolicy/prebuilts/api/28.0/public/service.te b/system/sepolicy/prebuilts/api/28.0/public/service.te
old mode 100644 (file)
new mode 100755 (executable)
index 3526049..2505456
--- a/system/sepolicy/prebuilts/api/28.0/public/service.te
+++ b/system/sepolicy/prebuilts/api/28.0/public/service.te
@@ -159,3 +159,4 @@ type wificond_service, service_manager_type;
 type wifiaware_service, app_api_service, system_server_service, service_manager_type;
 type window_service, system_api_service, system_server_service, service_manager_type;
 type wpantund_service, system_api_service, service_manager_type;
+type lgy_service, system_api_service, system_server_service, service_manager_type;
diff --git a/system/sepolicy/prebuilts/api/29.0/private/service_contexts b/system/sepolicy/prebuilts/api/29.0/private/service_contexts
old mode 100644 (file)
new mode 100755 (executable)
index 96d553b..cf5af11
--- a/system/sepolicy/prebuilts/api/29.0/private/service_contexts
+++ b/system/sepolicy/prebuilts/api/29.0/private/service_contexts
@@ -219,4 +219,5 @@ wificond                                  u:object_r:wificond_service:s0
 wifiaware                                 u:object_r:wifiaware_service:s0
 wifirtt                                   u:object_r:rttmanager_service:s0
 window                                    u:object_r:window_service:s0
+lgy                                       u:object_r:lgy_service:s0
 *                                         u:object_r:default_android_service:s0
diff --git a/system/sepolicy/prebuilts/api/29.0/public/service.te b/system/sepolicy/prebuilts/api/29.0/public/service.te
old mode 100644 (file)
new mode 100755 (executable)
index 92f8a09..923b180
--- a/system/sepolicy/prebuilts/api/29.0/public/service.te
+++ b/system/sepolicy/prebuilts/api/29.0/public/service.te
@@ -187,6 +187,7 @@ type wifiaware_service, app_api_service, system_server_service, service_manager_
 type window_service, system_api_service, system_server_service, service_manager_type;
 type inputflinger_service, system_api_service, system_server_service, service_manager_type;
 type wpantund_service, system_api_service, service_manager_type;
+type lgy_service, app_api_service, ephemeral_app_api_service, system_server_service, service_manager_type;
 
 ###
 ### Neverallow rules
diff --git a/system/sepolicy/private/service_contexts b/system/sepolicy/private/service_contexts
old mode 100644 (file)
new mode 100755 (executable)
index 96d553b..cf5af11
--- a/system/sepolicy/private/service_contexts
+++ b/system/sepolicy/private/service_contexts
@@ -219,4 +219,5 @@ wificond                                  u:object_r:wificond_service:s0
 wifiaware                                 u:object_r:wifiaware_service:s0
 wifirtt                                   u:object_r:rttmanager_service:s0
 window                                    u:object_r:window_service:s0
+lgy                                       u:object_r:lgy_service:s0
 *                                         u:object_r:default_android_service:s0
diff --git a/system/sepolicy/public/service.te b/system/sepolicy/public/service.te
old mode 100644 (file)
new mode 100755 (executable)
index 92f8a09..923b180
--- a/system/sepolicy/public/service.te
+++ b/system/sepolicy/public/service.te
@@ -187,6 +187,7 @@ type wifiaware_service, app_api_service, system_server_service, service_manager_
 type window_service, system_api_service, system_server_service, service_manager_type;
 type inputflinger_service, system_api_service, system_server_service, service_manager_type;
 type wpantund_service, system_api_service, service_manager_type;
+type lgy_service, app_api_service, ephemeral_app_api_service, system_server_service, service_manager_type;
 
 ###
 ### Neverallow rules

```




