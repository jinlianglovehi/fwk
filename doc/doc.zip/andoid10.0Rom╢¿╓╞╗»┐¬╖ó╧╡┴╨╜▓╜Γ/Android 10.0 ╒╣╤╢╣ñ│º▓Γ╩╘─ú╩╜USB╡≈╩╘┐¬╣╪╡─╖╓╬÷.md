



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Android 10.0 工厂测试模式关于USB调试开关的核心代码](#2.Android%2010.0%20%E5%B7%A5%E5%8E%82%E6%B5%8B%E8%AF%95%E6%A8%A1%E5%BC%8F%E5%85%B3%E4%BA%8EUSB%E8%B0%83%E8%AF%95%E5%BC%80%E5%85%B3%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.Android 10.0 工厂测试模式关于USB调试开关的核心代码解析](#3.Android%2010.0%20%E5%B7%A5%E5%8E%82%E6%B5%8B%E8%AF%95%E6%A8%A1%E5%BC%8F%E5%85%B3%E4%BA%8EUSB%E8%B0%83%E8%AF%95%E5%BC%80%E5%85%B3%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E8%A7%A3%E6%9E%90)


[3.1 EngineerModeActivity.java关于工厂模式相关代码](#%C2%A03.1%20EngineerModeActivity.java%E5%85%B3%E4%BA%8E%E5%B7%A5%E5%8E%82%E6%A8%A1%E5%BC%8F%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.2 DebugLogFragment相关代码分析](#3.2%20DebugLogFragment%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)




---



## 1.概述


  在开发产品中，对于工厂测试模式里面的很多功能是为了方便测试硬件功能的，也是原厂提供的测试app,对于USB调试打开adb获取测试数据也很重要，所以要求增加USB调试开关，打开usb调试模式


## 2.Android 10.0 工厂测试模式关于USB调试开关的核心代码



```
vendor\sprd\platform\packages\apps\EngineerMode\src\com\sprd\engineermode\EngineerModeActivity.java
vendor\sprd\platform\packages\apps\EngineerMode\src\com\sprd\engineermode\debuglog\DebugLogFragment.java
```

## 3.Android 10.0 工厂测试模式关于USB调试开关的核心代码解析



在系统开发定制过程中，关于这个debug调试也是非常重要的功能，所以说在产品出现异常，拿到异常信息分析，  
 解决问题非常的关键的，在展讯的工厂模式中EngineerMode就是关于工厂测试模式的相关debug开关的  
 相关功能源码，所以可以通过EngineerMode中的相关源码分析 debug模式开关是怎么打开的，  
 经过Android studio开发工具的相关功能，发现主要功能是在EngineerModeActivity.java这个Activity类  
 里面来加载不同页面的，所以可以分析EngineerModeActivity.java的相关源码找到打开debug模式  
 开关的代码来实现功能，接下来分析下相关代码


###  3.1 EngineerModeActivity.java关于工厂模式相关代码



```
public class EngineerModeActivity extends AppCompatActivity {

    private static final String TAG = "EngineerModeActivity";

   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        if (Const.isGSIVersion()) {
            finish();
            return;
        }
        setToolbarTabLayout();
        initCoordinatorAndTabLayout();
        /* SPRD 815541 : Coulometer Power Test Mode @{ */
        preferences = this.getSharedPreferences("cc_status", this.MODE_PRIVATE);
        Log.d(TAG, "onCreate");
        editor = preferences.edit();
        editor.putBoolean("time1_stop", true);
        editor.putBoolean("time2_stop", true);
        editor.putBoolean("time3_stop", true);
        editor.commit();
        /* }@ */
        /* Sprd 910010: androidp Shutdown broadcast can just only registered by dynamic @{ */
        if (mReceiver == null) {
            mReceiver = new ShutDownReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SHUTDOWN);
            registerReceiver(mReceiver, filter);
        }
        /* }@ */
    }

    private void setToolbarTabLayout() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        }
    }


    /* }@ */

    private void initCoordinatorAndTabLayout() {
        setContentView(R.layout.activity_main);

        InitTextView();
        InitImageView();
        InitFragment();
        InitViewPager();

        mFragmentsList = new ArrayList<Fragment>();
        mViewPager = (ViewPager)findViewById(R.id.view_pager);
        FragmentManager fragmentManager = getFragmentManager();
        Fragment telephonyFragment = new TelephonyFragment();
        Fragment debugFragment = new DebugLogFragment();
        Fragment connectivityFragment = new ConnectivityFragment();
        Fragment hardwareFragment = new HardWareFragment();
        Fragment locationFragment = new LocationFragment();
        mFragmentsList.add(telephonyFragment);
        mFragmentsList.add(debugFragment);
        mFragmentsList.add(connectivityFragment);
        mFragmentsList.add(hardwareFragment);
        mFragmentsList.add(locationFragment);
        mViewPager.setAdapter(new TabFragmentPagerAdapter(fragmentManager,
                mFragmentsList, mTabTitle, mContext));
        TabLayout tabLayout = (TabLayout)findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText(this.getResources().getString(R.string.tab_telephony)));
        tabLayout.addTab(tabLayout.newTab().setText(this.getResources().getString(R.string.tab_debug)));
        tabLayout.addTab(tabLayout.newTab().setText(this.getResources().getString(R.string.tab_connectivity)));
        tabLayout.addTab(tabLayout.newTab().setText(this.getResources().getString(R.string.tab_hardwaretest)));
        tabLayout.addTab(tabLayout.newTab().setText(this.getResources().getString(R.string.tab_location)));
        tabLayout.setupWithViewPager(mViewPager);
    }
}
```

在上述的EngineerModeActivity.java的相关源码可以发现，主要是在onCreate(Bundle savedInstanceState)  
 负责加载页面数据的，在这里构建相关的布局，而在initCoordinatorAndTabLayout()中加载TAB的相关数据  
 用来选择进入哪个页面的，  
 而DebugLogFragment()就是相关deg相关功能页面，加载相关的Debug模式开关的设置信息，所以可以从  
 DebugLogFragment()中，具体分析相关功能


## 3.2 DebugLogFragment相关代码分析



```
public class DebugLogFragment extends PreferenceFragment implements
        Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener {
    private static final String TAG = "DebugLogFragment";
    
    private IDebugLogApi debugLogApi = CoreApi.getDebugLogApi();

    @SuppressLint("HandlerLeak")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.pref_debuglogtab);
       

        mUsbDebug = (TwoStatePreference) findPreference(KEY_USB_DEBUG_SWITCH);
        mUsbDebug.setOnPreferenceChangeListener(this);
        mUserMode = (TwoStatePreference) findPreference(KEY_USEER_MODE);

        mUserMode.setOnPreferenceChangeListener(this);
        mUserMode.setEnabled(false);
        mUserMode.setSummary(R.string.feature_not_support);

        mScreenOff = (TwoStatePreference) findPreference(KEY_SCREEN_OFF);
        mScreenOff.setOnPreferenceChangeListener(this);

        mWatchDog = (TwoStatePreference) findPreference(KEY_WATCH_DOG);
        mWatchDog.setOnPreferenceChangeListener(this);

        mSystemUpdate = (Preference) findPreference(KEY_SYSTEM_UPDATE);

        
        mPrefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        long screenTime = mPrefs.getLong(SCREEN_OFF_TIME, -1);
        mSettingsTimeout = Settings.System.getLong(getActivity().getContentResolver(),
                Settings.System.SCREEN_OFF_TIMEOUT, FALLBACK_SCREEN_TIMEOUT_VALUE);
        if (screenTime == -1 || (screenTime != -1 && mSettingsTimeout != screenTime)) {
            saveScreenTime();
        }
        /* SPRD: 922313 - lvds dump @{ */
        mLVDSDump = (Preference) findPreference(KEY_LVDS_DUMP);
        String mLVDSDumpStr = SystemPropertiesProxy.get(KEY_LVDS_DUMP_GROUP, "");
        if (!mLVDSDumpStr.equals("")) {
            mLVDSDump.setSummary(mLVDSDumpStr);
        } else {
            mLVDSDump.setSummary("Close LVDS DUMP");
        }
        mLVDSDump.setOnPreferenceClickListener(this);
        /* }@ */

        mJeitaControl = (TwoStatePreference) findPreference(KEY_JEITA_CONTROL);
        mJeitaControl.setOnPreferenceChangeListener(this);


        getPreferenceScreen().removePreference(findPreference("switch_user_mode"));
        getPreferenceScreen().removePreference(findPreference("avs_log"));
        getPreferenceScreen().removePreference(findPreference("gps_config"));
        getPreferenceScreen().removePreference(findPreference("agps_log"));
        getPreferenceScreen().removePreference(findPreference("log_level_switch"));
    }

@Override
    public boolean onPreferenceChange(Preference pref, Object objValue) {
        /* SPRD Bug 793108: Add kernel log level switch. @{ */
        if (pref == mWatchDog) {
            SharedPreferences.Editor editor = mPrefs.edit();
            if(mWatchDog.isChecked()) {
                editor.putBoolean(KEY_WATCH_DOG, false);
                editor.apply();
                ShellUtils.writeToFile(WATCH_DOG_PATH, "watchdog off");
            } else {
                editor.putBoolean(KEY_WATCH_DOG, true);
                editor.apply();
                ShellUtils.writeToFile(WATCH_DOG_PATH, "watchdog on");
            }
        } else if (pref == mRpsSwitch) {
            if (mRpsSwitch.isChecked()) {
                SystemPropertiesProxy.set("ctl.start","vendor.rps_off");
                mRpsSwitch.setSummary("Off");
                Log.d(TAG, "close rps now.");
            } else {
                SystemPropertiesProxy.set("ctl.start","vendor.rps_on");
                mRpsSwitch.setSummary("On");
                Log.d(TAG, "open rps now.");
            }
        } else if (pref == mUsbDebug) {
            if (!mUsbDebug.isChecked()) {
                openDebugMode();
            } else {
                closeDebugMode();
            }
            return true;
        } else if (pref == mJeitaControl) {
            Message setJeitaType = mDEGHandler.obtainMessage(SET_JEITA_TYPE, mJeitaControl.isChecked() ? "0" : "1");
            mDEGHandler.sendMessage(setJeitaType);
            return true;
        } else if (pref == mAtDiag) {
            if (mAtDiag.isChecked()) {
                try {
                    debugLogApi.atDiagApi().closeAtDiag();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    debugLogApi.atDiagApi().openAtDiag();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (pref == mCabcTestSwitch) {
            boolean enableCabc = !mCabcTestSwitch.isChecked();
            try {
                debugLogApi.cabcApi().set(enableCabc);
                mCabcTestSwitch.setChecked(enableCabc);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    private void openDebugMode() {
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 1);
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.ADB_ENABLED, 1);
    }

    private void closeDebugMode() {
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.ADB_ENABLED, 0);
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0);
    }

}
```

在上述的DebugLogFragment.java的相关源码可以发现，主要是在onCreate(Bundle savedInstanceState)  
 负责加载页面数据的，在这里构建相关的布局，而在onCreate(Bundle savedInstanceState) 中可以看出  
 mUsbDebug就是usb调试开关openDebugMode();就是打开usb调试模式  
 而closeDebugMode();就是关闭usb调试模式，所以说具体打开usb调试模式分析  
 openDebugMode()和closeDebugMode()相关代码就可以了



```
private void openDebugMode() {
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 1);
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.ADB_ENABLED, 1);
    }

    private void closeDebugMode() {
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.ADB_ENABLED, 0);
        Settings.Global.putInt(getActivity().getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0);
    }
```

在上述的DebugLogFragment.java的相关源码可以发现，打开usb调试模式分析  
 openDebugMode()和closeDebugMode()相关代码的源码分析得知  
 其实就是DEVELOPMENT\_SETTINGS\_ENABLED和ADB\_ENABLED属性值设置为0和1



