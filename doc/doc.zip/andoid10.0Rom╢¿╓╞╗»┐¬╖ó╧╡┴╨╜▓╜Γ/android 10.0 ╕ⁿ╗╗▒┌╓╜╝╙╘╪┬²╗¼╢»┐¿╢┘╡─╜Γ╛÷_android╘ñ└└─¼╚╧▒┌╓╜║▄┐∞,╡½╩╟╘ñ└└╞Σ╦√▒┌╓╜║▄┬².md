






### 1.概述


在10.0的系统产品开发中，在产品开发中对于更换壁纸的时候，如果不是标准的分辨率，会出现更换完壁纸后 壁纸被放大的情况，这样就会感觉到壁纸在更换后，Luancher3在滑动  
 切换WorkSpace界面时 会感觉到稍微卡顿,接下来就来分析更换壁纸的相关逻辑代码


### 2. 更换壁纸加载慢滑动卡顿的解决的核心类



```
frameworks/base/services/core/java/com/android/server/wallpaper/WallpaperManagerService.java

```

### 3. 更换壁纸加载慢滑动卡顿的解决核心功能分析和实现


在frameworks中关于壁纸的相关服务都是在WallpaperManagerService.java中  
 更换壁纸也是由WallpaperManagerService.java处理的，所以看下这方面的代码  
 路径:  
 frameworks/base/services/core/java/com/android/server/wallpaper/WallpaperManagerService.java



```
ParcelFileDescriptor updateWallpaperBitmapLocked(String name, WallpaperData wallpaper,
            Bundle extras) {
        if (name == null) name = "";
        try {
            File dir = getWallpaperDir(wallpaper.userId);
            if (!dir.exists()) {
                dir.mkdir();
                FileUtils.setPermissions(
                        dir.getPath(),
                        FileUtils.S_IRWXU|FileUtils.S_IRWXG|FileUtils.S_IXOTH,
                        -1, -1);
            }
            ParcelFileDescriptor fd = ParcelFileDescriptor.open(wallpaper.wallpaperFile,
                    MODE_CREATE|MODE_READ_WRITE|MODE_TRUNCATE);
            if (!SELinux.restorecon(wallpaper.wallpaperFile)) {
                return null;
            }
            wallpaper.name = name;
            wallpaper.wallpaperId = makeWallpaperIdLocked();
            if (extras != null) {
                extras.putInt(WallpaperManager.EXTRA_NEW_WALLPAPER_ID, wallpaper.wallpaperId);
            }
            // Nullify field to require new computation
            wallpaper.primaryColors = null;
            if (DEBUG) {
                Slog.v(TAG, "updateWallpaperBitmapLocked() : id=" + wallpaper.wallpaperId
                        + " name=" + name + " file=" + wallpaper.wallpaperFile.getName());
            }
            return fd;
        } catch (FileNotFoundException e) {
            Slog.w(TAG, "Error setting wallpaper", e);
        }
        return null;
    }

```

在app中设置壁纸时 会调用 setWallpaper(String name) 方法设置壁纸，这里  
 从而又会调用updateWallpaperBitmapLocked(name, mWallpaper, null);  
 最后在壁纸更换时回调到WallpaperObserver的public void onEvent(int event, String path)



```
/**
     * Observes the wallpaper for changes and notifies all IWallpaperServiceCallbacks
     * that the wallpaper has changed. The CREATE is triggered when there is no
     * wallpaper set and is created for the first time. The CLOSE_WRITE is triggered
     * every time the wallpaper is changed.
     */
    private class WallpaperObserver extends FileObserver {

        final int mUserId;
        final WallpaperData mWallpaper;
        final File mWallpaperDir;
        final File mWallpaperFile;
        final File mWallpaperLockFile;

        public WallpaperObserver(WallpaperData wallpaper) {
            super(getWallpaperDir(wallpaper.userId).getAbsolutePath(),
                    CLOSE_WRITE | MOVED_TO | DELETE | DELETE_SELF);
            mUserId = wallpaper.userId;
            mWallpaperDir = getWallpaperDir(wallpaper.userId);
            mWallpaper = wallpaper;
            mWallpaperFile = new File(mWallpaperDir, WALLPAPER);
            mWallpaperLockFile = new File(mWallpaperDir, WALLPAPER_LOCK_ORIG);
        }

        private WallpaperData dataForEvent(boolean sysChanged, boolean lockChanged) {
            WallpaperData wallpaper = null;
            synchronized (mLock) {
                if (lockChanged) {
                    wallpaper = mLockWallpaperMap.get(mUserId);
                }
                if (wallpaper == null) {
                    // no lock-specific wallpaper exists, or sys case, handled together
                    wallpaper = mWallpaperMap.get(mUserId);
                }
            }
            return (wallpaper != null) ? wallpaper : mWallpaper;
        }

        @Override
        public void onEvent(int event, String path) {
            if (path == null) {
                return;
            }
            final boolean moved = (event == MOVED_TO);
            final boolean written = (event == CLOSE_WRITE || moved);
            final File changedFile = new File(mWallpaperDir, path);

            // System and system+lock changes happen on the system wallpaper input file;
            // lock-only changes happen on the dedicated lock wallpaper input file
            final boolean sysWallpaperChanged = (mWallpaperFile.equals(changedFile));
            final boolean lockWallpaperChanged = (mWallpaperLockFile.equals(changedFile));
            int notifyColorsWhich = 0;
            WallpaperData wallpaper = dataForEvent(sysWallpaperChanged, lockWallpaperChanged);

            if (DEBUG) {
                Slog.v(TAG, "Wallpaper file change: evt=" + event
                        + " path=" + path
                        + " sys=" + sysWallpaperChanged
                        + " lock=" + lockWallpaperChanged
                        + " imagePending=" + wallpaper.imageWallpaperPending
                        + " whichPending=0x" + Integer.toHexString(wallpaper.whichPending)
                        + " written=" + written);
            }

            if (moved && lockWallpaperChanged) {
                // We just migrated sys -> lock to preserve imagery for an impending
                // new system-only wallpaper.  Tell keyguard about it and make sure it
                // has the right SELinux label.
                if (DEBUG) {
                    Slog.i(TAG, "Sys -> lock MOVED\_TO");
                }
                SELinux.restorecon(changedFile);
                notifyLockWallpaperChanged();
                notifyWallpaperColorsChanged(wallpaper, FLAG_LOCK);
                return;
            }

            synchronized (mLock) {
                if (sysWallpaperChanged || lockWallpaperChanged) {
                    notifyCallbacksLocked(wallpaper);
                    if (wallpaper.wallpaperComponent == null
                            || event != CLOSE_WRITE // includes the MOVED_TO case
                            || wallpaper.imageWallpaperPending) {
                        if (written) {
                            // The image source has finished writing the source image,
                            // so we now produce the crop rect (in the background), and
                            // only publish the new displayable (sub)image as a result
                            // of that work.
                            if (DEBUG) {
                                Slog.v(TAG, "Wallpaper written; generating crop");
                            }
                            SELinux.restorecon(changedFile);
                            if (moved) {
                                // This is a restore, so generate the crop using any just-restored new
                                // crop guidelines, making sure to preserve our local dimension hints.
                                // We also make sure to reapply the correct SELinux label.
                                if (DEBUG) {
                                    Slog.v(TAG, "moved-to, therefore restore; reloading metadata");
                                }
                                loadSettingsLocked(wallpaper.userId, true);
                            }
                            generateCrop(wallpaper);
                            if (DEBUG) {
                                Slog.v(TAG, "Crop done; invoking completion callback");
                            }
                            wallpaper.imageWallpaperPending = false;
                            if (sysWallpaperChanged) {
                                // If this was the system wallpaper, rebind...
                                bindWallpaperComponentLocked(mImageWallpaper, true,
                                        false, wallpaper, null);
                                notifyColorsWhich |= FLAG_SYSTEM;
                            }
                            if (lockWallpaperChanged
                                    || (wallpaper.whichPending & FLAG_LOCK) != 0) {
                                if (DEBUG) {
                                    Slog.i(TAG, "Lock-relevant wallpaper changed");
                                }
                                // either a lock-only wallpaper commit or a system+lock event.
                                // if it's system-plus-lock we need to wipe the lock bookkeeping;
 // we're falling back to displaying the system wallpaper there.
                                if (!lockWallpaperChanged) {
                                    mLockWallpaperMap.remove(wallpaper.userId);
                                }
                                // and in any case, tell keyguard about it
                                notifyLockWallpaperChanged();
                                notifyColorsWhich |= FLAG_LOCK;
                            }

                            saveSettingsLocked(wallpaper.userId);

                            // Publish completion *after* we've persisted the changes
 if (wallpaper.setComplete != null) {
 try {
 wallpaper.setComplete.onWallpaperChanged();
 } catch (RemoteException e) {
 // if this fails we don't really care; the setting app may just
                                    // have crashed and that sort of thing is a fact of life.
                                }
                            }
                        }
                    }
                }
            }

            // Outside of the lock since it will synchronize itself
            if (notifyColorsWhich != 0) {
                notifyWallpaperColorsChanged(wallpaper, notifyColorsWhich);
            }
        }
    }

```

在上述的代码中WallpaperObserver的分析可以看出  
 从代码可看出public void onEvent(int event, String path) 会调用  
 generateCrop(wallpaper);而他就是负责保存壁纸的 根据壁纸的大小来  
 裁剪或者放大



```
  /**
     * Once a new wallpaper has been written via setWallpaper(...), it needs to be cropped
     * for display.
     */
    private void generateCrop(WallpaperData wallpaper) {
        boolean success = false;

        // Only generate crop for default display.
        final DisplayData wpData = getDisplayDataOrCreate(DEFAULT_DISPLAY);
        final Rect cropHint = new Rect(wallpaper.cropHint);
        final DisplayInfo displayInfo = new DisplayInfo();
        mDisplayManager.getDisplay(DEFAULT_DISPLAY).getDisplayInfo(displayInfo);

        if (DEBUG) {
            Slog.v(TAG, "Generating crop for new wallpaper(s): 0x"
                    + Integer.toHexString(wallpaper.whichPending)
                    + " to " + wallpaper.cropFile.getName()
                    + " crop=(" + cropHint.width() + 'x' + cropHint.height()
                    + ") dim=(" + wpData.mWidth + 'x' + wpData.mHeight + ')');
        }

        // Analyse the source; needed in multiple cases
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(wallpaper.wallpaperFile.getAbsolutePath(), options);
        if (options.outWidth <= 0 || options.outHeight <= 0) {
            Slog.w(TAG, "Invalid wallpaper data");
            success = false;
        } else {
            boolean needCrop = false;
            boolean needScale = false;

            // Empty crop means use the full image
            if (cropHint.isEmpty()) {
                cropHint.left = cropHint.top = 0;
                cropHint.right = options.outWidth;
                cropHint.bottom = options.outHeight;
            } else {
                // force the crop rect to lie within the measured bounds
                cropHint.offset(
                        (cropHint.right > options.outWidth ? options.outWidth - cropHint.right : 0),
                        (cropHint.bottom > options.outHeight ? options.outHeight - cropHint.bottom : 0));

                // If the crop hint was larger than the image we just overshot. Patch things up.
                if (cropHint.left < 0) {
                    cropHint.left = 0;
                }
                if (cropHint.top < 0) {
                    cropHint.top = 0;
                }

                // Don't bother cropping if what we're left with is identity
                needCrop = (options.outHeight > cropHint.height()
                        || options.outWidth > cropHint.width());
            }

            // scale if the crop height winds up not matching the recommended metrics
            needScale = wpData.mHeight != cropHint.height()
                    || cropHint.height() > GLHelper.getMaxTextureSize()
                    || cropHint.width() > GLHelper.getMaxTextureSize();
    
            // 代码添加部分
             //add code start
             if (cropHint.width() >=1920 && cropHint.height() >= 1080) {
                         needScale = false;
              }
            //add code end


            //make sure screen aspect ratio is preserved if width is scaled under screen size
            if (needScale) {
                final float scaleByHeight = (float) wpData.mHeight / (float) cropHint.height();
                final int newWidth = (int) (cropHint.width() * scaleByHeight);
                if (newWidth < displayInfo.logicalWidth) {
                    final float screenAspectRatio =
                            (float) displayInfo.logicalHeight / (float) displayInfo.logicalWidth;
                    cropHint.bottom = (int) (cropHint.width() * screenAspectRatio);
                    needCrop = true;
                }
            }

            if (DEBUG) {
                Slog.v(TAG, "crop: w=" + cropHint.width() + " h=" + cropHint.height());
                Slog.v(TAG, "dims: w=" + wpData.mWidth + " h=" + wpData.mHeight);
                Slog.v(TAG, "meas: w=" + options.outWidth + " h=" + options.outHeight);
                Slog.v(TAG, "crop?=" + needCrop + " scale?=" + needScale);
            }

            if (!needCrop && !needScale) {
                // Simple case:  the nominal crop fits what we want, so we take
                // the whole thing and just copy the image file directly.

                // TODO: It is not accurate to estimate bitmap size without decoding it,
                //  may be we can try to remove this optimized way in the future,
                //  that means, we will always go into the 'else' block.

                // This is just a quick estimation, may be smaller than it is.
                long estimateSize = options.outWidth * options.outHeight * 4;

                // A bitmap over than MAX_BITMAP_SIZE will make drawBitmap() fail.
                // Please see: RecordingCanvas#throwIfCannotDraw.
                if (estimateSize < MAX_BITMAP_SIZE) {
                    success = FileUtils.copyFile(wallpaper.wallpaperFile, wallpaper.cropFile);
                }

                if (!success) {
                    wallpaper.cropFile.delete();
                    // TODO: fall back to default wallpaper in this case
                }

                if (DEBUG) {
                    Slog.v(TAG, "Null crop of new wallpaper, estimate size="
                            + estimateSize + ", success=" + success);
                }
            } else {
                // Fancy case: crop and scale.  First, we decode and scale down if appropriate.
                FileOutputStream f = null;
                BufferedOutputStream bos = null;
                try {
                    BitmapRegionDecoder decoder = BitmapRegionDecoder.newInstance(
                            wallpaper.wallpaperFile.getAbsolutePath(), false);

                    // This actually downsamples only by powers of two, but that's okay; we do
 // a proper scaling blit later. This is to minimize transient RAM use.
 // We calculate the largest power-of-two under the actual ratio rather than
 // just let the decode take care of it because we also want to remap where the
 // cropHint rectangle lies in the decoded [super]rect.
 final int actualScale = cropHint.height() / wpData.mHeight;
 int scale = 1;
 while (2 \* scale <= actualScale) {
 scale \*= 2;
 }
 options.inSampleSize = scale;
 options.inJustDecodeBounds = false;

 final Rect estimateCrop = new Rect(cropHint);
 estimateCrop.scale(1f / options.inSampleSize);
 final float hRatio = (float) wpData.mHeight / estimateCrop.height();
 final int destHeight = (int) (estimateCrop.height() \* hRatio);
 final int destWidth = (int) (estimateCrop.width() \* hRatio);

 // We estimated an invalid crop, try to adjust the cropHint to get a valid one.
 if (destWidth > GLHelper.getMaxTextureSize()) {
 int newHeight = (int) (wpData.mHeight / hRatio);
 int newWidth = (int) (wpData.mWidth / hRatio);

 if (DEBUG) {
 Slog.v(TAG, "Invalid crop dimensions, trying to adjust.");
 }

 estimateCrop.set(cropHint);
 estimateCrop.left += (cropHint.width() - newWidth) / 2;
 estimateCrop.top += (cropHint.height() - newHeight) / 2;
 estimateCrop.right = estimateCrop.left + newWidth;
 estimateCrop.bottom = estimateCrop.top + newHeight;
 cropHint.set(estimateCrop);
 estimateCrop.scale(1f / options.inSampleSize);
 }

 // We've got the safe cropHint; now we want to scale it properly to
                    // the desired rectangle.
                    // That's a height-biased operation: make it fit the hinted height.
 final int safeHeight = (int) (estimateCrop.height() \* hRatio);
 final int safeWidth = (int) (estimateCrop.width() \* hRatio);

 if (DEBUG) {
 Slog.v(TAG, "Decode parameters:");
 Slog.v(TAG, " cropHint=" + cropHint + ", estimateCrop=" + estimateCrop);
 Slog.v(TAG, " down sampling=" + options.inSampleSize
 + ", hRatio=" + hRatio);
 Slog.v(TAG, " dest=" + destWidth + "x" + destHeight);
 Slog.v(TAG, " safe=" + safeWidth + "x" + safeHeight);
 Slog.v(TAG, " maxTextureSize=" + GLHelper.getMaxTextureSize());
 }

 Bitmap cropped = decoder.decodeRegion(cropHint, options);
 decoder.recycle();

 if (cropped == null) {
 Slog.e(TAG, "Could not decode new wallpaper");
 } else {
 // We are safe to create final crop with safe dimensions now.
 final Bitmap finalCrop = Bitmap.createScaledBitmap(cropped,
 safeWidth, safeHeight, true);
 if (DEBUG) {
 Slog.v(TAG, "Final extract:");
 Slog.v(TAG, " dims: w=" + wpData.mWidth
 + " h=" + wpData.mHeight);
 Slog.v(TAG, " out: w=" + finalCrop.getWidth()
 + " h=" + finalCrop.getHeight());
 }

 // A bitmap over than MAX\_BITMAP\_SIZE will make drawBitmap() fail.
 // Please see: RecordingCanvas#throwIfCannotDraw.
 if (finalCrop.getByteCount() > MAX\_BITMAP\_SIZE) {
 throw new RuntimeException(
 "Too large bitmap, limit=" + MAX\_BITMAP\_SIZE);
 }

 f = new FileOutputStream(wallpaper.cropFile);
 bos = new BufferedOutputStream(f, 32\*1024);
 finalCrop.compress(Bitmap.CompressFormat.JPEG, 100, bos);
 bos.flush(); // don't rely on the implicit flush-at-close when noting success
                        success = true;
                    }
                } catch (Exception e) {
                    if (DEBUG) {
                        Slog.e(TAG, "Error decoding crop", e);
                    }
                } finally {
                    IoUtils.closeQuietly(bos);
                    IoUtils.closeQuietly(f);
                }
            }
        }

        if (!success) {
            Slog.e(TAG, "Unable to apply new wallpaper");
            wallpaper.cropFile.delete();
        }

        if (wallpaper.cropFile.exists()) {
            boolean didRestorecon = SELinux.restorecon(wallpaper.cropFile.getAbsoluteFile());
            if (DEBUG) {
                Slog.v(TAG, "restorecon() of crop file returned " + didRestorecon);
            }
        }
    }

```

在generateCrop(WallpaperData wallpaper)最终设置壁纸的时候，会通过缩放比例来适配是否需要放大还是缩小壁纸后然后设置为新的壁纸，  
 通过日志发现壁纸是被放大了 所以要在needScale赋值为false；  
 代码修改部分如下：



```
--- a/frameworks/base/services/core/java/com/android/server/wallpaper/WallpaperManagerService.java
+++ b/frameworks/base/services/core/java/com/android/server/wallpaper/WallpaperManagerService.java
@@ -630,6 +630,9 @@ public class WallpaperManagerService extends IWallpaperManager.Stub
                     || cropHint.height() > GLHelper.getMaxTextureSize()
                     || cropHint.width() > GLHelper.getMaxTextureSize();
 
+              if (cropHint.width() >=1920 && cropHint.height() >= 1080) {
+                         needScale = false;
+              }
             //make sure screen aspect ratio is preserved if width is scaled under screen size
             if (needScale) {
                 final float scaleByHeight = (float) wpData.mHeight / (float) cropHint.height();

```




