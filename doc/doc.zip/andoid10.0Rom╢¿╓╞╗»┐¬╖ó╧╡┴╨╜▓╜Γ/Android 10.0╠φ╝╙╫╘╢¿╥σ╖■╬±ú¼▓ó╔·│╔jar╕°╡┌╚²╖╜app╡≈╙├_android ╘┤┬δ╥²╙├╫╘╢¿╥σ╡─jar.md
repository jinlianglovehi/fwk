






在定制化开发中，由于需要新增加自定义的功能，所以要增加自定义服务，上层通过调用服务，来调用相应的功能，所以系统需要先生成jar,然后生成jar 给上层app调用  
 从而来实现所需要的功能


第一步：  
 添加自定义服务



```
1.创建aidl
2.在frameworks\base\Android.bp中添加我们的AIDL，让其编译进系统
3.在frameworks\base\services\core\java\com\android\server\下创建自己的文件夹lgy，并创建自己的service
4.在frameworks\base\services\java\com\android\server\SystemServer.java中启动我们的服务
5.添加给应用层调用的接口
6.frameworks\base\core\java\android\content\Context.java 添加
7.frameworks\base\core\java\android\app\SystemServiceRegistry.java  注册服务
8.新增自定义类 调用服务，然后提供给上层调用该类的接口(这一步也可以省略)
9.新增的service配置selinux策略

```

这几步就完成了自定义服务  
 具体实现 请看我的另一篇博客 ：https://blog.csdn.net/baidu\_41666295/article/details/117959553?spm=1001.2014.3001.5502


第二步就是生成jar 提供给app调用  
 添加完自定义service后 编译 编译完成后来生成jar包


导出我们需要的jar包



```
在out/target/common/obj/JAVA_LIBRARIES目录下找到framework-minus-apex_intermediates目录,11之前的好像是framework_intermediates目录 现在改成了这个framework-minus-apex_intermediates
使用下面的命令生成jar

```


```
/out/target/common/obj/JAVA_LIBRARIES/framework_intermediates$ jar -xvf classes.jar android/mam/MyPower.class
 inflated: android/mam/MyPower.class
/out/target/common/obj/JAVA_LIBRARIES/framework_intermediates$ jar -cvf mypower.jar android           
added manifest
adding: android/(in = 0) (out= 0)(stored 0%)
adding: android/mam/(in = 0) (out= 0)(stored 0%)
adding: android/mam/MyPower.class(in = 9093) (out= 2774)(deflated 69%)
/work/sprdroid10_trunk_19c/out/target/common/obj/JAVA_LIBRARIES/framework_intermediates$

```

首选cd 到 out/target/common/obj/JAVA\_LIBRARIES/framework\_intermediates 下  
 执行命令 jar -xvf classes.jar android/mam/MyPower.class MyPower.class 就是要提供给上层调用的类的classes文件  
 执行命令 jar -cvf mypower.jar android 把MyPower.class文件生成mypower.jar 的jar包给上层调用


生成完jar后 在out/target/common/obj/JAVA\_LIBRARIES/framework\_intermediates 目录下会看到生成的 jar文件  
 和android/mam/ 下的class 文件  
 然后 将jar 导入到app里面 调用相应的功能 发现已经能正常调用自定义的api接口





