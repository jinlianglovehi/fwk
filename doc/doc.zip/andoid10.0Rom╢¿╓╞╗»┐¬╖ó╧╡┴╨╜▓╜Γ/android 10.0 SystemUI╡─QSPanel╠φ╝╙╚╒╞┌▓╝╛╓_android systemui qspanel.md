






### 1.概述


在10.0的系统产品开发中，对于SystemUI下拉状态栏和通知栏也是定制化，  
 定制下拉状态栏UI的常见功能，由于产品需要在下滑展开状态栏的时候在QSPanel部分添加时间显示  
 功能，所以需要看QSPanel的相关布局源码，然后添加时间控件


### 2.SystemUI的QSPanel添加日期布局的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSPanel.java

```

### 3.SystemUI的QSPanel添加日期布局核心功能分析和实现


在SystemUI的二次下拉状态栏的布局中，它的源码就是QSPanel.java接下来就看下在QSPanel.java中  
 相关绘制布局的方法中如何添加亮度条布局，来完成功能  
 路径为：  
 frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSPanel.java



```
 /** View that represents the quick settings tile panel (when expanded/pulled down). **/
  public class QSPanel extends LinearLayout implements Tunable, Callback, BrightnessMirrorListener,
          Dumpable {
  public QSPanel(Context context) {
          this(context, null);
      }
  
      public QSPanel(Context context, AttributeSet attrs) {
          this(context, attrs, null);
      }
  
      @Inject
      public QSPanel(@Named(VIEW_CONTEXT) Context context, AttributeSet attrs,
              DumpController dumpController) {
          super(context, attrs);
          mContext = context;
  
          setOrientation(VERTICAL);
  
          mBrightnessView = LayoutInflater.from(mContext).inflate(
              R.layout.quick_settings_brightness_dialog, this, false);
          addView(mBrightnessView);
  
          mTileLayout = (QSTileLayout) LayoutInflater.from(mContext).inflate(
                  R.layout.qs_paged_tile_layout, this, false);
          mTileLayout.setListening(mListening);
          addView((View) mTileLayout);
 
 mQsTileRevealController = new QSTileRevealController(mContext, this,
 (PagedTileLayout) mTileLayout);
 
 addDivider();
 
 mFooter = new QSSecurityFooter(this, context);
 addView(mFooter.getView());
  
          updateResources();
  
          mBrightnessController = new BrightnessController(getContext(),
                  findViewById(R.id.brightness_slider));
          mDumpController = dumpController;
      }
  
      protected void addDivider() {
          mDivider = LayoutInflater.from(mContext).inflate(R.layout.qs_divider, this, false);
          mDivider.setBackgroundColor(Utils.applyAlpha(mDivider.getAlpha(),
                  getColorForState(mContext, Tile.STATE_ACTIVE)));
          addView(mDivider);
      }
  
      @Override
      protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
          // We want all the logic of LinearLayout#onMeasure, and for it to assign the excess space
          // not used by the other children to PagedTileLayout. However, in this case, LinearLayout
          // assumes that PagedTileLayout would use all the excess space. This is not the case as
          // PagedTileLayout height is quantized (because it shows a certain number of rows).
          // Therefore, after everything is measured, we need to make sure that we add up the correct
          // total height
          super.onMeasure(widthMeasureSpec, heightMeasureSpec);
          int height = getPaddingBottom() + getPaddingTop();
          int numChildren = getChildCount();
          for (int i = 0; i < numChildren; i++) {
              View child = getChildAt(i);
              if (child.getVisibility() != View.GONE) height += child.getMeasuredHeight();
          }
          setMeasuredDimension(getMeasuredWidth(), height);
      }
  
      public View getDivider() {
          return mDivider;
      }
  
      public QSTileRevealController getQsTileRevealController() {
          return mQsTileRevealController;
      }
  
      public boolean isShowingCustomize() {
          return mCustomizePanel != null && mCustomizePanel.isCustomizing();
      }
  
      @Override
      protected void onAttachedToWindow() {
          super.onAttachedToWindow();
          final TunerService tunerService = Dependency.get(TunerService.class);
          tunerService.addTunable(this, QS_SHOW_BRIGHTNESS);
  
          if (mHost != null) {
              setTiles(mHost.getTiles());
          }
          if (mBrightnessMirrorController != null) {
              mBrightnessMirrorController.addCallback(this);
          }
          if (mDumpController != null) mDumpController.addListener(this);
      }
  
      @Override
      protected void onDetachedFromWindow() {
          Dependency.get(TunerService.class).removeTunable(this);
          if (mHost != null) {
              mHost.removeCallback(this);
          }
          for (TileRecord record : mRecords) {
              record.tile.removeCallbacks();
          }
          if (mBrightnessMirrorController != null) {
              mBrightnessMirrorController.removeCallback(this);
          }
          if (mDumpController != null) mDumpController.removeListener(this);
          super.onDetachedFromWindow();
      }
  
      @Override
      public void onTilesChanged() {
          setTiles(mHost.getTiles());
      }
  
      @Override
      public void onTuningChanged(String key, String newValue) {
          if (QS_SHOW_BRIGHTNESS.equals(key)) {
              updateViewVisibilityForTuningValue(mBrightnessView, newValue);
          }
      }
  
      private void updateViewVisibilityForTuningValue(View view, @Nullable String newValue) {
          view.setVisibility(TunerService.parseIntegerSwitch(newValue, true) ? VISIBLE : GONE);
      }
  
      public void openDetails(String subPanel) {
          QSTile tile = getTile(subPanel);
          // If there's no tile with that name (as defined in QSFactoryImpl or other QSFactory),
          // QSFactory will not be able to create a tile and getTile will return null
          if (tile != null) {
              showDetailAdapter(true, tile.getDetailAdapter(), new int[]{getWidth() / 2, 0});
          }
      }
  
      private QSTile getTile(String subPanel) {
          for (int i = 0; i < mRecords.size(); i++) {
              if (subPanel.equals(mRecords.get(i).tile.getTileSpec())) {
                  return mRecords.get(i).tile;
              }
          }
          return mHost.createTile(subPanel);
      }
  
      public void setBrightnessMirror(BrightnessMirrorController c) {
          if (mBrightnessMirrorController != null) {
              mBrightnessMirrorController.removeCallback(this);
          }
          mBrightnessMirrorController = c;
          if (mBrightnessMirrorController != null) {
              mBrightnessMirrorController.addCallback(this);
          }
          updateBrightnessMirror();
      }
 

```

从QSPanel的构造方法的代码中可以看出mBrightnessView 就是亮度条布局可以在构造方法中通过添加布局  
 然后用addView(mBrightnessView);来添加布局到QSPanel中



```
mBrightnessView = LayoutInflater.from(mContext).inflate(
            R.layout.quick_settings_brightness_dialog, this, false);
		addView(mBrightnessView);

```

以上就是亮度条的布局添加到QSPanel的方法，  
 其实就像这样添加就可以了



```
+    private View mQsDateview;
+        mQsDateview = LayoutInflater.from(mContext).inflate(
+                R.layout.quick_qs_date, this, false);
+               addView(mQsDateview);

```

通过上述方法这样就可以 讲日期布局添加到QSPanel中去


quick\_qs\_date.xml布局



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2017 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:id="@+id/quick\_qs\_date"
    android:layout_width="match\_parent"
    android:layout_height="wrap\_content"
    android:visibility="invisible"
    android:theme="@style/QSHeaderTheme">
    <com.android.systemui.statusbar.policy.DateView
        android:id="@+id/qs\_date"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="start|center\_vertical"
		android:layout_marginLeft="@dimen/navigation\_bar\_deadzone\_size"
        android:gravity="left|center\_vertical"
        systemui:datePattern="@string/abbrev\_wday\_month\_day\_no\_year\_alarm" />
</LinearLayout>

```

这样就实现了这个功能





