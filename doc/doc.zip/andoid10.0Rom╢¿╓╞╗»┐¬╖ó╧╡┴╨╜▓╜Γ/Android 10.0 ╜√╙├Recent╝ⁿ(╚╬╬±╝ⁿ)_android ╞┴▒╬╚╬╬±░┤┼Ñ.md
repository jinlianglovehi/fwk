



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.禁用Recent键的相关核心代码](#%C2%A02.%E7%A6%81%E7%94%A8Recent%E9%94%AE%E7%9A%84%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.禁用Recent键的相关核心代码核心功能实现 3.1NavigationBarFragment.java关于虚拟导航键recent键的监听](#3.%E7%A6%81%E7%94%A8Recent%E9%94%AE%E7%9A%84%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%C2%A03.1NavigationBarFragment.java%E5%85%B3%E4%BA%8E%E8%99%9A%E6%8B%9F%E5%AF%BC%E8%88%AA%E9%94%AErecent%E9%94%AE%E7%9A%84%E7%9B%91%E5%90%AC)


[3.2 Recents.java关与CommandQueue的相关代码](#3.2%20Recents.java%E5%85%B3%E4%B8%8ECommandQueue%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[在toggleRecentApps()中执行的RecentsImplementation的toggleRecentApps();](#%E5%9C%A8toggleRecentApps%28%29%E4%B8%AD%E6%89%A7%E8%A1%8C%E7%9A%84RecentsImplementation%E7%9A%84toggleRecentApps%28%29%3B)


[3.3 RecentsImplementation的相关代码](#3.3%20RecentsImplementation%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


10.0定制化开发中，对于SystemUI的定制也是常用的功能，而导航栏三键中返回键 home键 和recent键是默认三键，点击recent键，弹出最近任务列表，由于要求去掉最近任务列表功能，所以就不需要Recent键了 所以有需求要求屏蔽掉禁用recent键功能.所以就要从recent流程来看怎么禁用


如图:


![](https://img-blog.csdnimg.cn/ec274e2537e8410db79e01747c694914.png)


##  2.禁用Recent键的相关核心代码



```
核心代码如下:
 frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NavigationBarFragment.java
  frameworks\base\packages\SystemUI\src\com\android\systemui\recents\Recents.java
  /frameworks/base/packages/SystemUI/src/com/android/systemui/recents/RecentsImplementation.java
```

#### 3.禁用Recent键的相关核心代码核心功能实现  3.1NavigationBarFragment.java关于虚拟导航键recent键的监听


NavigationBarFragment 中对 RecentsButton 注册监听回调 onRecentsClick



```

路径:frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NavigationBarFragment.java

public class NavigationBarFragment extends LifecycleFragment implements Callbacks,
NavigationModeController.ModeChangedListener {

public static final String TAG = "NavigationBar";
private static final boolean DEBUG = false;
private static final String EXTRA_DISABLE_STATE = "disabled_state";
private static final String EXTRA_DISABLE2_STATE = "disabled2_state";
private static final String EXTRA_SYSTEM_UI_VISIBILITY = "system_ui_visibility";

/** Allow some time inbetween the long press for back and recents. */
private static final int LOCK_TO_APP_GESTURE_TOLERENCE = 200;
private static final long AUTODIM_TIMEOUT_MS = 2250;

private final AccessibilityManagerWrapper mAccessibilityManagerWrapper;
protected final AssistManager mAssistManager;
private final MetricsLogger mMetricsLogger;
private final DeviceProvisionedController mDeviceProvisionedController;
private final StatusBarStateController mStatusBarStateController;

protected NavigationBarView mNavigationBarView = null;

private @WindowVisibleState int mNavigationBarWindowState = WINDOW_STATE_SHOWING;

private int mNavigationIconHints = 0;
private @TransitionMode int mNavigationBarMode;
private AccessibilityManager mAccessibilityManager;
private MagnificationContentObserver mMagnificationObserver;
private ContentResolver mContentResolver;
private boolean mAssistantAvailable;

private int mDisabledFlags1;
private int mDisabledFlags2;
private StatusBar mStatusBar;
private Recents mRecents;
private Divider mDivider;
private WindowManager mWindowManager;
private CommandQueue mCommandQueue;
private long mLastLockToAppLongPress;

private Locale mLocale;
private int mLayoutDirection;

private int mSystemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE;
private int mNavBarMode = NAV_BAR_MODE_3BUTTON;
private LightBarController mLightBarController;
private AutoHideController mAutoHideController;

private OverviewProxyService mOverviewProxyService;

@VisibleForTesting
public int mDisplayId;
private boolean mIsOnDefaultDisplay;
public boolean mHomeBlockedThisTouch;
private ScreenDecorations mScreenDecorations;
public NavigationBarFragment(AccessibilityManagerWrapper accessibilityManagerWrapper,
DeviceProvisionedController deviceProvisionedController, MetricsLogger metricsLogger,
AssistManager assistManager, OverviewProxyService overviewProxyService,
NavigationModeController navigationModeController,
StatusBarStateController statusBarStateController) {
mAccessibilityManagerWrapper = accessibilityManagerWrapper;
mDeviceProvisionedController = deviceProvisionedController;
mStatusBarStateController = statusBarStateController;
mMetricsLogger = metricsLogger;
mAssistManager = assistManager;
mAssistantAvailable = mAssistManager.getAssistInfoForUser(UserHandle.USER_CURRENT) != null;
mOverviewProxyService = overviewProxyService;
mNavBarMode = navigationModeController.addListener(this);
}

// ----- Fragment Lifecycle Callbacks -----

@Override
public void onCreate(@Nullable Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
mCommandQueue = SysUiServiceProvider.getComponent(getContext(), CommandQueue.class);
mCommandQueue.observe(getLifecycle(), this);
mStatusBar = SysUiServiceProvider.getComponent(getContext(), StatusBar.class);
mRecents = SysUiServiceProvider.getComponent(getContext(), Recents.class);
mDivider = SysUiServiceProvider.getComponent(getContext(), Divider.class);
mWindowManager = getContext().getSystemService(WindowManager.class);
mAccessibilityManager = getContext().getSystemService(AccessibilityManager.class);
mContentResolver = getContext().getContentResolver();
mMagnificationObserver = new MagnificationContentObserver(
getContext().getMainThreadHandler());
mContentResolver.registerContentObserver(Settings.Secure.getUriFor(
Settings.Secure.ACCESSIBILITY_DISPLAY_MAGNIFICATION_NAVBAR_ENABLED), false,
mMagnificationObserver, UserHandle.USER_ALL);
mContentResolver.registerContentObserver(
Settings.Secure.getUriFor(Settings.Secure.ASSISTANT),
false /* notifyForDescendants */, mAssistContentObserver, UserHandle.USER_ALL);

if (savedInstanceState != null) {
mDisabledFlags1 = savedInstanceState.getInt(EXTRA_DISABLE_STATE, 0);
mDisabledFlags2 = savedInstanceState.getInt(EXTRA_DISABLE2_STATE, 0);
mSystemUiVisibility = savedInstanceState.getInt(EXTRA_SYSTEM_UI_VISIBILITY, 0);
}
mAccessibilityManagerWrapper.addCallback(mAccessibilityListener);

// Respect the latest disabled-flags.
mCommandQueue.recomputeDisableFlags(mDisplayId, false);
}

 private void prepareNavigationBarView() {
        mNavigationBarView.reorient();

        ButtonDispatcher recentsButton = mNavigationBarView.getRecentsButton();
        recentsButton.setOnClickListener(this::onRecentsClick);
        recentsButton.setOnTouchListener(this::onRecentsTouch);
        recentsButton.setLongClickable(true);
        recentsButton.setOnLongClickListener(this::onLongPressBackRecents);

        ButtonDispatcher backButton = mNavigationBarView.getBackButton();
        backButton.setLongClickable(true);

        ButtonDispatcher homeButton = mNavigationBarView.getHomeButton();
        homeButton.setOnTouchListener(this::onHomeTouch);
        homeButton.setOnLongClickListener(this::onHomeLongClick);

        ButtonDispatcher accessibilityButton = mNavigationBarView.getAccessibilityButton();
        accessibilityButton.setOnClickListener(this::onAccessibilityClick);
        accessibilityButton.setOnLongClickListener(this::onAccessibilityLongClick);
        updateAccessibilityServicesState(mAccessibilityManager);

        updateScreenPinningGestures();
    }
recent键的
    private void onRecentsClick(View v) {
        if (LatencyTracker.isEnabled(getContext())) {
            LatencyTracker.getInstance(getContext()).onActionStart(
                    LatencyTracker.ACTION_TOGGLE_RECENTS);
        }
        /* UNISOC: Bug 1074234, 885650, Super power feature @{ */
        if (SprdPowerManagerUtil.isSuperPower()) {
            Log.d(TAG, "mRecentsClickListener SUPPORT_SUPER_POWER_SAVE ignore!");
            return;
        }
        /* @} */

        mStatusBar.awakenDreams();
        mCommandQueue.toggleRecentApps();
    }

```

点击虚拟导航栏的 RecentsButton 就执行 CommandQueue toggleRecentApps()


而在Recents.java中实现CommandQueue的接口


#### 3.2 Recents.java关与CommandQueue的相关代码



```
路径:frameworks\base\packages\SystemUI\src\com\android\systemui\recents\Recents.java
public class Recents extends SystemUI implements CommandQueue.Callbacks {

    private RecentsImplementation mImpl;

    @Override
    public void start() {
        getComponent(CommandQueue.class).addCallback(this);
        putComponent(Recents.class, this);
        mImpl = createRecentsImplementationFromConfig();
        mImpl.onStart(mContext, this);
    }

    @Override
    public void onBootCompleted() {
        mImpl.onBootCompleted();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        mImpl.onConfigurationChanged(newConfig);
    }

    @Override
    public void appTransitionFinished(int displayId) {
        if (mContext.getDisplayId() == displayId) {
            mImpl.onAppTransitionFinished();
        }
    }

    public void growRecents() {
        mImpl.growRecents();
    }

    @Override
    public void showRecentApps(boolean triggeredFromAltTab) {
        // Ensure the device has been provisioned before allowing the user to interact with
        // recents
        if (!isUserSetup()) {
            return;
        }

        mImpl.showRecentApps(triggeredFromAltTab);
    }

    @Override
    public void hideRecentApps(boolean triggeredFromAltTab, boolean triggeredFromHomeKey) {
        // Ensure the device has been provisioned before allowing the user to interact with
        // recents
        if (!isUserSetup()) {
            return;
        }

        mImpl.hideRecentApps(triggeredFromAltTab, triggeredFromHomeKey);
    }

    @Override
    public void toggleRecentApps() {
        // Ensure the device has been provisioned before allowing the user to interact with
        // recents
        if (!isUserSetup()) {
            return;
        }

        mImpl.toggleRecentApps();
    }
...}


```

#### 在toggleRecentApps()中执行的RecentsImplementation的toggleRecentApps();


#### 3.3 RecentsImplementation的相关代码



```
@Override
    public void toggleRecentApps() {
        // Ensure the device has been provisioned before allowing the user to interact with
        // recents
        if (!isUserSetup()) {
            return;
        }

      mImpl.toggleRecentApps();
    }
根据流程图可知道 只要在这里注释掉mImpl.toggleRecentApps(); 就可以了
修改流程如下:

    @Override
    public void toggleRecentApps() {
        // Ensure the device has been provisioned before allowing the user to interact with
        // recents
        if (!isUserSetup()) {
            return;
        }

      -  mImpl.toggleRecentApps();
      + //mImpl.toggleRecentApps();
    }
```



