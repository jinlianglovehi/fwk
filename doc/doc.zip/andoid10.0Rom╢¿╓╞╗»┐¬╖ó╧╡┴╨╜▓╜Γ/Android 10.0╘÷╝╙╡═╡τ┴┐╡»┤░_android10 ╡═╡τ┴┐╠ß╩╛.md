






在做定制化开发中，对于低电量提醒的功能，系统会在状态栏中弹出通知进行提示，但是如果隐藏了状态栏 就看不到提示了  
 所以客户要求增加个低电量弹窗功能  
 发现在SystemUI里面。发现SystemUI涵盖的内容还是很多了，这个之后有时间得仔细看看。


我们接着说今天的主题，过程不必赘述。定位到方法体，文件在framework/base/packages/SystemUI/syc/com/android/systemui/power/PowerUI.java 类


接下来分析源码部分:



```
final class Receiver extends BroadcastReceiver {

        public void init() {
            // Register for Intent broadcasts for...
            IntentFilter filter = new IntentFilter();
            filter.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
            filter.addAction(Intent.ACTION_BATTERY_CHANGED);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_SWITCHED);
            mContext.registerReceiver(this, filter, null, mHandler);
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (PowerManager.ACTION_POWER_SAVE_MODE_CHANGED.equals(action)) {
                ThreadUtils.postOnBackgroundThread(() -> {
 if (mPowerManager.isPowerSaveMode()) {
                        mWarnings.dismissLowBatteryWarning();
                    }
                });
            } else if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                final int oldBatteryLevel = mBatteryLevel;
                mBatteryLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100);
                final int oldBatteryStatus = mBatteryStatus;
                mBatteryStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS,
                        BatteryManager.BATTERY_STATUS_UNKNOWN);
                final int oldPlugType = mPlugType;
                mPlugType = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 1);
                final int oldInvalidCharger = mInvalidCharger;
                mInvalidCharger = intent.getIntExtra(BatteryManager.EXTRA_INVALID_CHARGER, 0);
                mLastBatteryStateSnapshot = mCurrentBatteryStateSnapshot;

                /* UNISOC: Modified for bug 1072088, add voltage high warning @{ */
                final int oldBatteryHealth = mBatteryHealth;
                mBatteryHealth = intent.getIntExtra(BatteryManager.EXTRA_HEALTH,
                    BatteryManager.BATTERY_HEALTH_UNKNOWN);
                /* @} */

                final boolean plugged = mPlugType != 0;
                final boolean oldPlugged = oldPlugType != 0;

                int oldBucket = findBatteryLevelBucket(oldBatteryLevel);
                int bucket = findBatteryLevelBucket(mBatteryLevel);

                if(mLastBatteryStateSnapshot == null) {
                    mLastBatteryStateSnapshot = new BatteryStateSnapshot(oldBatteryLevel, false, oldPlugged, oldBucket, oldBatteryStatus, mLowBatteryReminderLevels[1],
                                    mLowBatteryReminderLevels[0]);
                }

                if (DEBUG || SPRD_DEBUG) {
                    Slog.d(TAG, "buckets ....." + mLowBatteryAlertCloseLevel
                            + " .. " + mLowBatteryReminderLevels[0]
                            + " .. " + mLowBatteryReminderLevels[1]);
                    Slog.d(TAG, "level " + oldBatteryLevel + " --> " + mBatteryLevel);
                    Slog.d(TAG, "status " + oldBatteryStatus + " --> " + mBatteryStatus);
                    Slog.d(TAG, "plugType " + oldPlugType + " --> " + mPlugType);
                    Slog.d(TAG, "invalidCharger " + oldInvalidCharger + " --> " + mInvalidCharger);
                    Slog.d(TAG, "bucket " + oldBucket + " --> " + bucket);
                    Slog.d(TAG, "plugged " + oldPlugged + " --> " + plugged);
                    /* UNISOC: Modified for bug 1072088, add voltage high warning @{ */
                    Slog.d(TAG, "health " + oldBatteryHealth + " --> " + mBatteryHealth);
                }

                mWarnings.update(mBatteryLevel, bucket, mScreenOffTime);
                if (oldInvalidCharger == 0 && mInvalidCharger != 0) {
                    Slog.d(TAG, "showing invalid charger warning");
                    mWarnings.showInvalidChargerWarning();
                    return;
                } else if (oldInvalidCharger != 0 && mInvalidCharger == 0) {
                    mWarnings.dismissInvalidChargerWarning();
                } else if (mWarnings.isInvalidChargerWarningShowing()) {
                    // if invalid charger is showing, don't show low battery
                    if (DEBUG) {
                        Slog.d(TAG, "Bad Charger");
                    }
                    return;
                }

                // Show the correct version of low battery warning if needed
                if (mLastShowWarningTask != null) {
                    mLastShowWarningTask.cancel(true);
                    if (DEBUG) {
                        Slog.d(TAG, "cancelled task");
                    }
                }
                mLastShowWarningTask = ThreadUtils.postOnBackgroundThread(() -> {
 maybeShowBatteryWarningV2(
 plugged, bucket);
 });

 /\* UNISOC: Modified for bug 1072088, add voltage high warning @{ \*/
 if(mSprdPowerUI != null){
 mSprdPowerUI.checkBatteryHealth(plugged, oldPlugged, mBatteryHealth, oldBatteryHealth);
 }
 /\*@}\*/
 } else if (Intent.ACTION\_SCREEN\_OFF.equals(action)) {
                mScreenOffTime = SystemClock.elapsedRealtime();
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                mScreenOffTime = -1;
            } else if (Intent.ACTION_USER_SWITCHED.equals(action)) {
                mWarnings.userSwitched();
            } else {
                Slog.w(TAG, "unknown intent: " + intent);
            }
        }
    }

```

在Intent.ACTION\_BATTERY\_CHANGED 电量变化时会根据是否是电量不足的状态



```
mLastShowWarningTask = ThreadUtils.postOnBackgroundThread(() -> {
                    maybeShowBatteryWarningV2(
                            plugged, bucket);
                });

```

来判断电量的状态



```
 protected void maybeShowBatteryWarningV2(boolean plugged, int bucket) {
        final boolean hybridEnabled = mEnhancedEstimates.isHybridNotificationEnabled();
        final boolean isPowerSaverMode = mPowerManager.isPowerSaveMode();

        // Stick current battery state into an immutable container to determine if we should show
        // a warning.
        if (DEBUG) {
            Slog.d(TAG, "evaluating which notification to show");
        }
        if (hybridEnabled) {
            if (DEBUG) {
                Slog.d(TAG, "using hybrid");
            }
            Estimate estimate = refreshEstimateIfNeeded();
            mCurrentBatteryStateSnapshot = new BatteryStateSnapshot(mBatteryLevel, isPowerSaverMode,
                    plugged, bucket, mBatteryStatus, mLowBatteryReminderLevels[1],
                    mLowBatteryReminderLevels[0], estimate.getEstimateMillis(),
                    estimate.getAverageDischargeTime(),
                    mEnhancedEstimates.getSevereWarningThreshold(),
                    mEnhancedEstimates.getLowWarningThreshold(), estimate.isBasedOnUsage(),
                    mEnhancedEstimates.getLowWarningEnabled());
        } else {
            if (DEBUG) {
                Slog.d(TAG, "using standard");
            }

            mCurrentBatteryStateSnapshot = new BatteryStateSnapshot(mBatteryLevel, isPowerSaverMode,
                    plugged, bucket, mBatteryStatus, mLowBatteryReminderLevels[1],
                    mLowBatteryReminderLevels[0]);
        }

        if (DEBUG) {
            Slog.d(TAG, "mLastBatteryStateSnapshot:" + mLastBatteryStateSnapshot);
            Slog.d(TAG, "mCurrentBatteryStateSnapshot:" + mCurrentBatteryStateSnapshot);
        }

        mWarnings.updateSnapshot(mCurrentBatteryStateSnapshot);
        if (mCurrentBatteryStateSnapshot.isHybrid()) {
            maybeShowHybridWarning(mCurrentBatteryStateSnapshot, mLastBatteryStateSnapshot);
        } else {
            maybeShowBatteryWarning(mCurrentBatteryStateSnapshot, mLastBatteryStateSnapshot);
        }
    }

```

maybeShowBatteryWarning(mCurrentBatteryStateSnapshot, mLastBatteryStateSnapshot);  
 中判断具体的电量状态



```
protected void maybeShowBatteryWarning(
        BatteryStateSnapshot currentSnapshot,
        BatteryStateSnapshot lastSnapshot) {
    final boolean playSound = currentSnapshot.getBucket() != lastSnapshot.getBucket()
            || lastSnapshot.getPlugged();

    if (shouldShowLowBatteryWarning(currentSnapshot, lastSnapshot)) {
        mWarnings.showLowBatteryWarning(playSound);
    } else if (shouldDismissLowBatteryWarning(currentSnapshot, lastSnapshot)) {
        mWarnings.dismissLowBatteryWarning();
    } else {
        mWarnings.updateLowBatteryWarning();
    }
}

```

mWarnings.showLowBatteryWarning(playSound); 来具体实现低电量的提醒工作


而在PowerNotificationWarnings.java 中来具体实现该方法  
 路径位于:  
 framework/base/packages/SystemUI/syc/com/android/systemui/power/PowerNotificationWarnings.java



```
@Override
public void showLowBatteryWarning(boolean playSound) {
    Slog.i(TAG,
            "show low battery warning: level=" + mBatteryLevel
                    + " [" + mBucket + "] playSound=" + playSound);
    mPlaySound = playSound;
    mWarning = true;
    updateNotification();
+ mContext.sendBroadcast(new Intent("com.action.systemui.lowbattery"));;
}

```

所以具体方法就是在这里增加广播 然后在Launcher3 具体实现弹窗的方法


在packages\apps\Launcher3\src\com\android\launcher3\Launcher.java  
 实现功能


1. 注册广播：



```
registerReceiver(mLowBatteryReceiver, new IntentFilter("com.action.systemui.lowbattery"));

```

2. 



```
private final BroadcastReceiver mLowBatteryReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
		 Log.e("Launcher3","电压过低");
         showLowBatteryWarningDialog();
    }
};

```

3. 



```
public void showLowBatteryWarningDialog(){
	View v = View.inflate(this, R.layout.battery_low, null);
	AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setCancelable(true);
            b.setTitle(R.string.battery_low_title);
            b.setView(v);
            b.setIconAttribute(android.R.attr.alertDialogIcon);
            b.setPositiveButton(android.R.string.ok, null);
	AlertDialog d = b.create();
    d.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
    d.getWindow().getAttributes().privateFlags |=
                WindowManager.LayoutParams.PRIVATE_FLAG_SHOW_FOR_ALL_USERS;
    d.show();
}

```

4. 


packages\apps\Launcher3\quickstep\AndroidManifest.xml  
 添加权限:



```
<uses-permission android:name="android.permission.SYSTEM\_ALERT\_WINDOW"/>

```

5.battery\_low.xml



```
<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent">
    <TextView
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:textSize="16sp"
        android:textColor="@android:color/black"
        android:text="@string/battery\_low\_title"/>
</RelativeLayout>

```

具体功能就这么实现了 编译后验证功能即可





