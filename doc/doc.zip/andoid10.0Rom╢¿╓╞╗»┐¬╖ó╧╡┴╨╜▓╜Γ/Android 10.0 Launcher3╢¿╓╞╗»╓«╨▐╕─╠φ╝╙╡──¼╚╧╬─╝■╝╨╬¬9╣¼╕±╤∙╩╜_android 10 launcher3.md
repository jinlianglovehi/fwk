



## 1. 概述


在10.0的系统产品rom定制化开发中，对于Launcher3的定制功能也是不少的，比如在Launcher3中添加默认文件夹，把默认的app添加的文件夹里面，其他的app  
 然后按顺序排序。在文件夹布局就是默认的9宫格布局，接下来分析下相关源码来实现功能


## 2.Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心类



```
    packages\apps\Launcher3\src\com\android\launcher3\folder\ClippedFolderIconLayoutRule.java
    packages/apps/Launcher3/src/com/android/launcher3/folder/FolderGridOrganizer.java
    packages\apps\Launcher3\res\xml\default_workspace_5x5.xml

```

## 3.Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能分析和实现 3.1 默认添加文件夹功能实现


Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能实现中，通过上述源码分析，  
 在Launcher3中长按桌面图标会形成文件夹。打开的文件夹叫Folder  
 ，桌面上和图标一样的文件夹叫FolderIcon，文件夹的主要逻辑代码都在Launcher\src\com\android\launcher3\folder包下面  
 在Launcher3中添加默认文件夹就是通过添加folder，然后在解析的时候添加到database.db里面，在xml中下面有几种不同的default\_workspace.xml  
 布局，根据屏幕分辨率大小对应不同的xml文件


接下来添加默认文件夹如下:



```
    <favorites xmlns:launcher="http://schemas.android.com/apk/res-auto/com.android.launcher3">
        <appwidget
           launcher:packageName="com.android.deskclock"
           launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"
           launcher:screen="0"
           launcher:x="2"
           launcher:y="1"
           launcher:spanX="2"
           launcher:spanY="2" />
        <favorite
            launcher:container="-100"
            launcher:screen="1"
            launcher:x="3"
            launcher:y="0"
            launcher:packageName="com.qinlin.ahaschool"
            launcher:className="com.qinlin.ahaschool.view.activity.LaunchActivity"/>
        <favorite
            launcher:container="-100"
            launcher:screen="1"
            launcher:x="4"
            launcher:y="0"
            launcher:packageName="com.ximalayaos.pad.tingkid"
            launcher:className="com.ximalaya.ting.kid.WelcomeActivity"/>
        <folder
            launcher:screen="1"
            launcher:title="@string/folder_name"
            launcher:x="5"
            launcher:y="0">
            <favorite
              launcher:packageName="com.tencent.app"
              launcher:className="com.tencent.StartupActivity" />
            <favorite
              launcher:packageName="com.alibaba.android.rimet"
              launcher:className="com.alibaba.android.LaunchHomeActivity" />
            <favorite
              launcher:packageName="cn.eeo.classin"
              launcher:className="cn.eeo.startup.LogoSplashActivity" />

        </folder>
        <favorite
            launcher:container="-100"
            launcher:screen="1"
            launcher:x="0"
            launcher:y="1"
            launcher:packageName="com.tencent.android.qqdownloader"
            launcher:className="com.tencent.pangu.link.SplashActivity"/>
    </favorites>
```

在Launchcher3中的上述的源码中，在default\_workspace\_5x5.xml的相关代码中可以看到在添加默认文件夹，就是在文件夹根目录folder下添加favorite子元素就可以了  
 然后在解析default\_workspace\_5x5.xml的时候就会作为默认文件夹被创建，然后添加favorite子文件到文件夹，这些都是由Folder.java  
 文件负责构造布局，生成默认文件夹功能就介绍到这里，接下来看下默认文件夹9宫格功能的创建，在folder中添加favorite  
 这个元素，来构建默认的文件夹就可以了


## 3.2 ClippedFolderIconLayoutRule关于文件夹九宫格布局的修改


Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能实现中，通过上述源码分析，通过阅读源码发现在Launcher3中的folder包下面，发现src/com/android/launcher3/folder/ClippedFolderIconLayoutRule.java  
 这个类，可以看看，里面有三角函数，还有圆周率，因为原生的文件夹缩略图就是以圆形排列的，通过阅读源码发现和  
 文件夹内item的个数有关，接下来看具体的源码分析



```
    public class ClippedFolderIconLayoutRule {
    -    public static final int MAX_NUM_ITEMS_IN_PREVIEW = 2;
    +   public static final int MAX_NUM_ITEMS_IN_PREVIEW = 9;
        private static final int MIN_NUM_ITEMS_IN_PREVIEW = 2;
     
        private static final float MIN_SCALE = 0.48f;
        private static final float MAX_SCALE = 0.58f;
        private static final float MAX_RADIUS_DILATION = 0.15f;
        private static final float ITEM_RADIUS_SCALE_FACTOR = 1.33f;
     
        public void init(int availableSpace, float intrinsicIconSize, boolean rtl) {
            mAvailableSpace = availableSpace;
            mRadius = ITEM_RADIUS_SCALE_FACTOR * availableSpace / 2f;
            mIconSize = intrinsicIconSize;
            mIsRtl = rtl;
            mBaselineIconScale = availableSpace / (intrinsicIconSize * 1f);
        }
        private void getPosition(int index, int curNumItems, float[] result) {
            // The case of two items is homomorphic to the case of one.
            curNumItems = Math.max(curNumItems, 2);
     
            // We model the preview as a circle of items starting in the appropriate piece of the
            // upper left quadrant (to achieve horizontal and vertical symmetry).
            double theta0 = mIsRtl ? 0 : Math.PI;
     
            // In RTL we go counterclockwise
            int direction = mIsRtl ? 1 : -1;
     
            double thetaShift = 0;
            if (curNumItems == 3) {
                thetaShift = Math.PI / 6;
            } else if (curNumItems == 4) {
                thetaShift = Math.PI / 4;
            }
            theta0 += direction * thetaShift;
     
            // We want the items to appear in reading order. For the case of 1, 2 and 3 items, this
            // is natural for the circular model. With 4 items, however, we need to swap the 3rd and
            // 4th indices to achieve reading order.
            if (curNumItems == 4 && index == 3) {
                index = 2;
            } else if (curNumItems == 4 && index == 2) {
                index = 3;
            }
     
            // We bump the radius up between 0 and MAX_RADIUS_DILATION % as the number of items increase
            float radius = mRadius * (1 + MAX_RADIUS_DILATION * (curNumItems -
                    MIN_NUM_ITEMS_IN_PREVIEW) / (MAX_NUM_ITEMS_IN_PREVIEW - MIN_NUM_ITEMS_IN_PREVIEW));
            double theta = theta0 + index * (2 * Math.PI / curNumItems) * direction;
     
            float halfIconSize = (mIconSize * scaleForItem(curNumItems)) / 2;
     
            // Map the location along the circle, and offset the coordinates to represent the center
            // of the icon, and to be based from the top / left of the preview area. The y component
            // is inverted to match the coordinate system.
            result[0] = mAvailableSpace / 2 + (float) (radius * Math.cos(theta) / 2) - halfIconSize;
            result[1] = mAvailableSpace / 2 + (float) (- radius * Math.sin(theta) / 2) - halfIconSize;
     
        }
        public PreviewItemDrawingParams computePreviewItemDrawingParams(int index, int curNumItems,
                PreviewItemDrawingParams params) {
            totalScale = scaleForItem(curNumItems);
            float transX;
            float transY;
            float overlayAlpha = 0;
     
    // 注释掉原来的布局方式
            /*if (index == EXIT_INDEX) {
                // 0 1 * <-- Exit position (row 0, col 2)
                // 2 3
                getGridPosition(0, 2, mTmpPoint);
            } else if (index == ENTER_INDEX) {
                // 0 1
                // 2 3 * <-- Enter position (row 1, col 2)
                getGridPosition(1, 2, mTmpPoint);
            } else if (index >= MAX_NUM_ITEMS_IN_PREVIEW) {
                // Items beyond those displayed in the preview are animated to the center
                mTmpPoint[0] = mTmpPoint[1] = mAvailableSpace / 2 - (mIconSize * totalScale) / 2;
            } else {
                getPosition(index, curNumItems, mTmpPoint);
            }*/
    // 新建新的布局方式
            getPosition(index, mTmpPoint);
            transX = mTmpPoint[0];
            transY = mTmpPoint[1];
     
            if (params == null) {
                params = new PreviewItemDrawingParams(transX, transY, totalScale, overlayAlpha);
            } else {
                params.update(transX, transY, totalScale);
                params.overlayAlpha = overlayAlpha;
            }
            return params;
        }
```

Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能实现中，通过上述源码分析，在Launcher3中的上述的ClippedFolderIconLayoutRule.java方法中， computePreviewItemDrawingParams函数控制缩略图图标排序  
 在ClippedFolderIconLayoutRule.java中 computePreviewItemDrawingParams(int index, int curNumItems,  
 PreviewItemDrawingParams params)负责九宫格布局，所以说就需要从这里修改原来的2排2列的默认布局，修改为3行3  
 列布局，增加新的布局方式



```

        private void getGridPosition(int row, int col, float[] result) {
            // We use position 0 and 3 to calculate the x and y distances between items.
            getPosition(0, 4, result);
            float left = result[0];
            float top = result[1];
     
            getPosition(3, 4, result);
            float dx = result[0] - left;
            float dy = result[1] - top;
     
            result[0] = left + (col * dx);
            result[1] = top + (row * dy);
        }
           getPosition(index, mTmpPoint);来实现九宫格布局
        private void getPosition(int index, float[] result) {
            int sqrt = 3;
            int x = index % 3;
            int y = index / 3;
            float padding = 2;
            float x_iconsize = (mAvailableSpace - (sqrt + 1) * padding) / sqrt;
            float y_iconSize = (mAvailableSpace - sqrt * padding) / (sqrt-1);
            // 这个totalScale注意去掉finial，生成成员变量
            totalScale = x_iconsize / mIconSize;
            result[0] = (x_iconsize + padding / 2) * x + padding;
            result[1] = (x_iconsize + padding / 2) * y + padding;
        }

```

Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能实现中，通过上述源码分析，在Launcher3中的上述的ClippedFolderIconLayoutRule.java中的其他方法getGridPosition(int row, int col, float[] result)就是原来的布局方式，MAX\_NUM\_ITEMS\_IN\_PREVIEW就是每页的  
 最大数，而通过MAX\_NUM\_ITEMS\_IN\_PREVIEW的最大数字来做分页的排序和布局来实现  
 文件夹的九宫格布局功能 的实现


## 3.3 FolderGridOrganizer.java中的关于九宫格布局的相关修改


Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能实现中，通过上述源码分析，在Launcher3中的FolderGridOrganizer.java，它的主要功能就是在展开文件夹显示的计算逻辑类,文件夹图标呈现是网格 状,  
 此类主要给文件夹各应用图标制定显示规则,比如3\*4,4\*4，就是计算文件夹每一页显示多少行  
 多少列，显示角度等等，接下来分析下相关的源码



```
        public boolean isItemInPreview(int page, int rank) {
            // First page items are laid out such that the first 4 items are always in the upper
            // left quadrant. For all other pages, we need to check the row and col.
            /*if (page > 0 || mDisplayingUpperLeftQuadrant) {
                int col = rank % mCountX;
                int row = rank / mCountX;
                return col < 2 && row < 2;
            }*/
            return rank < MAX_NUM_ITEMS_IN_PREVIEW;
        }
```

Launcher3定制化之修改添加的默认文件夹为9宫格样式的核心功能实现中，通过上述源码分析，


在FolderGridOrganizer.java中的上述源码isItemInPreview(int page, int rank) 中可以看到，这里现在都是2行2列  
 所以要注释掉这些，然后修改返回rank < MAX\_NUM\_ITEMS\_IN\_PREVIEW;就这样就可以表示在每一页的item数量，来控制每一页显示的foldler的app图标的数量，就可以实现每一页值显示9个的功能了这样就实现了文件夹的九宫格功能了



