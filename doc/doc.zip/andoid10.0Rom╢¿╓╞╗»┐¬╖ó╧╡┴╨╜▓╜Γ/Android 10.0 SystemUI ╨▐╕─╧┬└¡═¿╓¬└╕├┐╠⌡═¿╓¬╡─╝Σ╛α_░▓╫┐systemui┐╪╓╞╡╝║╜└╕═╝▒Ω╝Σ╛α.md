






### 1.概述


在10.0的产品开发中，对于SystemUi下拉通知栏的定制功能，在原生SystemUI中下拉状态栏的每条通知  
 之间的间距是一条横线分开的，显得不太美观，所以要进行定制化改动，产品需求要求扩大每条通知的间距  
 如图:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/f9111d56c17d40ff90708a5398db1537.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBA5a6J5Y2T5YW86IGMZnJhbWV3b3Jr5bqU55So5bel56iL5biI,size_15,color_FFFFFF,t_70,g_se,x_16#pic_center)


### 2.SystemUI 修改下拉通知栏每条通知的间距的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationChildrenContainer.java

```

### 3.SystemUI 修改下拉通知栏每条通知的间距核心功能分析和实现


在对于SystemUI的通知栏部分，每条通知的管控都是由首选看源码 NotificationChildrenContainer.java来负责管理的  
 所以需要从 NotificationChildrenContainer.java看相关源码来找每条通知的间距来设置间距  
 首选看源码 NotificationChildrenContainer.java


路径为：frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationChildrenContainer.java



```
  public class NotificationChildrenContainer extends ViewGroup {
      public NotificationChildrenContainer(Context context) {
          this(context, null);
      }
  
      public NotificationChildrenContainer(Context context, AttributeSet attrs) {
          this(context, attrs, 0);
      }
  
      public NotificationChildrenContainer(Context context, AttributeSet attrs, int defStyleAttr) {
          this(context, attrs, defStyleAttr, 0);
      }
  
      public NotificationChildrenContainer(Context context, AttributeSet attrs, int defStyleAttr,
              int defStyleRes) {
          super(context, attrs, defStyleAttr, defStyleRes);
          mHybridGroupManager = new HybridGroupManager(getContext(), this);
          initDimens();
          setClipChildren(false);
      }
  
      private void initDimens() {
          Resources res = getResources();
          mChildPadding = res.getDimensionPixelSize(R.dimen.notification_children_padding);
          mDividerHeight = res.getDimensionPixelSize(
                  R.dimen.notification_children_container_divider_height);
          mDividerAlpha = res.getFloat(R.dimen.notification_divider_alpha);
          mNotificationHeaderMargin = res.getDimensionPixelSize(
                  R.dimen.notification_children_container_margin_top);
          mNotificatonTopPadding = res.getDimensionPixelSize(
                  R.dimen.notification_children_container_top_padding);
          mHeaderHeight = mNotificationHeaderMargin + mNotificatonTopPadding;
          mCollapsedBottompadding = res.getDimensionPixelSize(
                  com.android.internal.R.dimen.notification_content_margin);
          mEnableShadowOnChildNotifications =
                  res.getBoolean(R.bool.config_enableShadowOnChildNotifications);
          mShowDividersWhenExpanded =
                  res.getBoolean(R.bool.config_showDividersWhenGroupNotificationExpanded);
          mHideDividersDuringExpand =
                  res.getBoolean(R.bool.config_hideDividersDuringExpand);
          mTranslationForHeader = res.getDimensionPixelSize(
                  com.android.internal.R.dimen.notification_content_margin)
                  - mNotificationHeaderMargin;
          mHybridGroupManager.initDimens();
      }
  
      @Override
      protected void onLayout(boolean changed, int l, int t, int r, int b) {
          int childCount = Math.min(mChildren.size(), NUMBER_OF_CHILDREN_WHEN_CHILDREN_EXPANDED);
          for (int i = 0; i < childCount; i++) {
              View child = mChildren.get(i);
              // We need to layout all children even the GONE ones, such that the heights are
              // calculated correctly as they are used to calculate how many we can fit on the screen
              child.layout(0, 0, child.getMeasuredWidth(), child.getMeasuredHeight());
              mDividers.get(i).layout(0, 0, getWidth(), mDividerHeight);
          }
          if (mOverflowNumber != null) {
              boolean isRtl = getLayoutDirection() == LAYOUT_DIRECTION_RTL;
              int left = (isRtl ? 0 : getWidth() - mOverflowNumber.getMeasuredWidth());
              int right = left + mOverflowNumber.getMeasuredWidth();
              mOverflowNumber.layout(left, 0, right, mOverflowNumber.getMeasuredHeight());
          }
          if (mNotificationHeader != null) {
              mNotificationHeader.layout(0, 0, mNotificationHeader.getMeasuredWidth(),
                      mNotificationHeader.getMeasuredHeight());
          }
          if (mNotificationHeaderLowPriority != null) {
              mNotificationHeaderLowPriority.layout(0, 0,
                      mNotificationHeaderLowPriority.getMeasuredWidth(),
                      mNotificationHeaderLowPriority.getMeasuredHeight());
          }
      }
  
      @Override
      protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
          int heightMode = MeasureSpec.getMode(heightMeasureSpec);
          boolean hasFixedHeight = heightMode == MeasureSpec.EXACTLY;
          boolean isHeightLimited = heightMode == MeasureSpec.AT_MOST;
          int size = MeasureSpec.getSize(heightMeasureSpec);
          int newHeightSpec = heightMeasureSpec;
          if (hasFixedHeight || isHeightLimited) {
              newHeightSpec = MeasureSpec.makeMeasureSpec(size, MeasureSpec.AT_MOST);
          }
          int width = MeasureSpec.getSize(widthMeasureSpec);
          if (mOverflowNumber != null) {
              mOverflowNumber.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST),
                      newHeightSpec);
          }
          int dividerHeightSpec = MeasureSpec.makeMeasureSpec(mDividerHeight, MeasureSpec.EXACTLY);
          int height = mNotificationHeaderMargin + mNotificatonTopPadding;
          int childCount = Math.min(mChildren.size(), NUMBER_OF_CHILDREN_WHEN_CHILDREN_EXPANDED);
          int collapsedChildren = getMaxAllowedVisibleChildren(true /* likeCollapsed */);
          int overflowIndex = childCount > collapsedChildren ? collapsedChildren - 1 : -1;
          for (int i = 0; i < childCount; i++) {
              ExpandableNotificationRow child = mChildren.get(i);
              // We need to measure all children even the GONE ones, such that the heights are
              // calculated correctly as they are used to calculate how many we can fit on the screen.
              boolean isOverflow = i == overflowIndex;
              child.setSingleLineWidthIndention(isOverflow && mOverflowNumber != null
                      ? mOverflowNumber.getMeasuredWidth() : 0);
              child.measure(widthMeasureSpec, newHeightSpec);
              // layout the divider
              View divider = mDividers.get(i);
              divider.measure(widthMeasureSpec, dividerHeightSpec);
              if (child.getVisibility() != GONE) {
                  height += child.getMeasuredHeight() + mDividerHeight;
              }
          }
          mRealHeight = height;
          if (heightMode != MeasureSpec.UNSPECIFIED) {
              height = Math.min(height, size);
          }
  
          int headerHeightSpec = MeasureSpec.makeMeasureSpec(mHeaderHeight, MeasureSpec.EXACTLY);
          if (mNotificationHeader != null) {
              mNotificationHeader.measure(widthMeasureSpec, headerHeightSpec);
          }
          if (mNotificationHeaderLowPriority != null) {
              headerHeightSpec = MeasureSpec.makeMeasureSpec(mHeaderHeight, MeasureSpec.EXACTLY);
              mNotificationHeaderLowPriority.measure(widthMeasureSpec, headerHeightSpec);
          }
  
          setMeasuredDimension(width, height);
      }

  
      @Override
      public boolean pointInView(float localX, float localY, float slop) {
          return localX >= -slop && localY >= -slop && localX < ((mRight - mLeft) + slop) &&
 localY < (mRealHeight + slop);
 }
 
 /\*\*
 \* Add a child notification to this view.
 \*
 \* @param row the row to add
 \* @param childIndex the index to add it at, if -1 it will be added at the end
 \*/
 public void addNotification(ExpandableNotificationRow row, int childIndex) {
 int newIndex = childIndex < 0 ? mChildren.size() : childIndex;
 mChildren.add(newIndex, row);
 addView(row);
 row.setUserLocked(mUserLocked);
 
 View divider = inflateDivider();
 addView(divider);
 mDividers.add(newIndex, divider);
 
 updateGroupOverflow();
 row.setContentTransformationAmount(0, false /\* isLastChild \*/);
 // It doesn't make sense to keep old animations around, lets cancel them!
 ExpandableViewState viewState = row.getViewState();
 if (viewState != null) {
 viewState.cancelAnimations(row);
 row.cancelAppearDrawing();
 }
 }
 
 public void removeNotification(ExpandableNotificationRow row) {
 int childIndex = mChildren.indexOf(row);
 mChildren.remove(row);
 removeView(row);
 
 final View divider = mDividers.remove(childIndex);
 removeView(divider);
 getOverlay().add(divider);
 CrossFadeHelper.fadeOut(divider, new Runnable() {
 @Override
 public void run() {
 getOverlay().remove(divider);
 }
 });
 
 row.setSystemChildExpanded(false);
 row.setUserLocked(false);
 updateGroupOverflow();
 if (!row.isRemoved()) {
              mHeaderUtil.restoreNotificationHeader(row);
          }
      }
  
      /**
       * @return The number of notification children in the container.
       */
      public int getNotificationChildCount() {
          return mChildren.size();
      }
  
  
      @Override
      protected void onConfigurationChanged(Configuration newConfig) {
          super.onConfigurationChanged(newConfig);
          updateGroupOverflow();
      }
  
      private View inflateDivider() {
          return LayoutInflater.from(mContext).inflate(
                  R.layout.notification_children_divider, this, false);
      }
  
      public List<ExpandableNotificationRow> getNotificationChildren() {
          return mChildren;
      }

```

通过NotificationChildrenContainer的上述代码可知在addNotification(ExpandableNotificationRow row, int childIndex)中进行  
 每条通知的加载绘制，而在 View divider = inflateDivider();就是表示设置每条通知的间距横线  
 所以也就是在notification\_children\_divider.xml中布局就是每条通知的间距 所以可以修改这里  
 具体修改为:



```
--- a/frameworks/base/packages/SystemUI/res/layout/notification_children_divider.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/notification_children_divider.xml
@@ -19,5 +19,4 @@
     xmlns:android="http://schemas.android.com/apk/res/android"
     android:id="@+id/notification\_more\_divider"
     android:layout_width="match\_parent"
-    android:layout_height="@dimen/notification\_divider\_height"
-    android:background="@color/notification\_divider\_color" />
+    android:layout_height="@dimen/notification\_divider\_height"/>

```

其实修改notification\_divider\_height的高度值即可





