






在开发定制化平板时，如果使用不当的充电器，充电电源过高会对平板造成伤害，所以根据客户要求需要增加电源过高的提示  
 当底层检测到电源过高时，SystemUI弹出提示电压过高的提示框和警报声来提示客户电压过高  
 具体实现如下：


首选来看下SystemUI中哪里会时刻检测电压过高的问题  
 在SystemUI中 由PowerUI.java来负责监听电量变化的广播  
 framework/base/packages/SystemUI/src/com/android/systemui/power/PowerUI.java



```
 @VisibleForTesting
    final class Receiver extends BroadcastReceiver {

        public void init() {
            // Register for Intent broadcasts for...
            IntentFilter filter = new IntentFilter();
            filter.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
            filter.addAction(Intent.ACTION_BATTERY_CHANGED);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_SWITCHED);
            mContext.registerReceiver(this, filter, null, mHandler);
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (PowerManager.ACTION_POWER_SAVE_MODE_CHANGED.equals(action)) {
                ThreadUtils.postOnBackgroundThread(() -> {
 if (mPowerManager.isPowerSaveMode()) {
                        mWarnings.dismissLowBatteryWarning();
                    }
                });
            } else if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                final int oldBatteryLevel = mBatteryLevel;
                mBatteryLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100);
                final int oldBatteryStatus = mBatteryStatus;
                mBatteryStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS,
                        BatteryManager.BATTERY_STATUS_UNKNOWN);
                final int oldPlugType = mPlugType;
                mPlugType = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 1);
                final int oldInvalidCharger = mInvalidCharger;
                mInvalidCharger = intent.getIntExtra(BatteryManager.EXTRA_INVALID_CHARGER, 0);
                mLastBatteryStateSnapshot = mCurrentBatteryStateSnapshot;

                /* UNISOC: Modified for bug 1072088, add voltage high warning @{ */
                final int oldBatteryHealth = mBatteryHealth;
                mBatteryHealth = intent.getIntExtra(BatteryManager.EXTRA_HEALTH,
                    BatteryManager.BATTERY_HEALTH_UNKNOWN);
                /* @} */

                final boolean plugged = mPlugType != 0;
                final boolean oldPlugged = oldPlugType != 0;

                int oldBucket = findBatteryLevelBucket(oldBatteryLevel);
                int bucket = findBatteryLevelBucket(mBatteryLevel);

                if(mLastBatteryStateSnapshot == null) {
                    mLastBatteryStateSnapshot = new BatteryStateSnapshot(oldBatteryLevel, false, oldPlugged, oldBucket, oldBatteryStatus, mLowBatteryReminderLevels[1],
                                    mLowBatteryReminderLevels[0]);
                }

                if (DEBUG || SPRD_DEBUG) {
                    Slog.d(TAG, "buckets ....." + mLowBatteryAlertCloseLevel
                            + " .. " + mLowBatteryReminderLevels[0]
                            + " .. " + mLowBatteryReminderLevels[1]);
                    Slog.d(TAG, "level " + oldBatteryLevel + " --> " + mBatteryLevel);
                    Slog.d(TAG, "status " + oldBatteryStatus + " --> " + mBatteryStatus);
                    Slog.d(TAG, "plugType " + oldPlugType + " --> " + mPlugType);
                    Slog.d(TAG, "invalidCharger " + oldInvalidCharger + " --> " + mInvalidCharger);
                    Slog.d(TAG, "bucket " + oldBucket + " --> " + bucket);
                    Slog.d(TAG, "plugged " + oldPlugged + " --> " + plugged);
                    /* UNISOC: Modified for bug 1072088, add voltage high warning @{ */
                    Slog.d(TAG, "health " + oldBatteryHealth + " --> " + mBatteryHealth);
                }

                mWarnings.update(mBatteryLevel, bucket, mScreenOffTime);
                if (oldInvalidCharger == 0 && mInvalidCharger != 0) {
                    Slog.d(TAG, "showing invalid charger warning");
                    mWarnings.showInvalidChargerWarning();
                    return;
                } else if (oldInvalidCharger != 0 && mInvalidCharger == 0) {
                    mWarnings.dismissInvalidChargerWarning();
                } else if (mWarnings.isInvalidChargerWarningShowing()) {
                    // if invalid charger is showing, don't show low battery
                    if (DEBUG) {
                        Slog.d(TAG, "Bad Charger");
                    }
                    return;
                }

                // Show the correct version of low battery warning if needed
                if (mLastShowWarningTask != null) {
                    mLastShowWarningTask.cancel(true);
                    if (DEBUG) {
                        Slog.d(TAG, "cancelled task");
                    }
                }
                mLastShowWarningTask = ThreadUtils.postOnBackgroundThread(() -> {
 maybeShowBatteryWarningV2(
 plugged, bucket);
 });

 /\* UNISOC: Modified for bug 1072088, add voltage high warning @{ \*/
 if(mSprdPowerUI != null){
 mSprdPowerUI.checkBatteryHealth(plugged, oldPlugged, mBatteryHealth, oldBatteryHealth);
 }
 /\*@}\*/
 } else if (Intent.ACTION\_SCREEN\_OFF.equals(action)) {
                mScreenOffTime = SystemClock.elapsedRealtime();
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                mScreenOffTime = -1;
            } else if (Intent.ACTION_USER_SWITCHED.equals(action)) {
                mWarnings.userSwitched();
            } else {
                Slog.w(TAG, "unknown intent: " + intent);
            }
        }
    }

```

从代码中可以看到 当电量变化时会调用



```
 if(mSprdPowerUI != null){
                    mSprdPowerUI.checkBatteryHealth(plugged, oldPlugged, mBatteryHealth, oldBatteryHealth);
                }
来检测电量 而在checkBatteryHealth中来判断电源是否正常
    public void checkBatteryHealth(boolean plugged,boolean oldPlugged,int mBatteryHealth,int oldBatteryHealth){
        /* SPRD: Modified for bug 505221, add voltage high warning @{ */
        if (plugged) {
            if (oldBatteryHealth != mBatteryHealth && oldBatteryHealth != BatteryManager.BATTERY_HEALTH_UNKNOWN) {
        //changed by elink_wux for battery temperature <<<
                if (mBatteryHealth == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
                    Log.d(TAG, "showing BATTERY\_HEALTH\_OVER\_VOLTAGE warning");
                    showVoltageHighWarningDialog(BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE);
                } else if (oldBatteryHealth == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) {
                    Log.d(TAG, "dismiss BATTERY\_HEALTH\_OVER\_VOLTAGE warning");
                    dismissVoltageHighWarningDialog();
                } else if (mBatteryHealth == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
                    Log.d(TAG, "showing BATTERY\_HEALTH\_OVERHEAT warning");
                    showVoltageHighWarningDialog(BatteryManager.BATTERY_HEALTH_OVERHEAT);
                } else if (oldBatteryHealth == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
                    Log.d(TAG, "dismiss BATTERY\_HEALTH\_OVERHEAT warning");
                    dismissVoltageHighWarningDialog();
                }else if (mBatteryHealth == BatteryManager.BATTERY_HEALTH_COLD) {
                    Log.d(TAG, "showing BATTERY\_HEALTH\_HEALTH\_COLD warning");
                    showVoltageHighWarningDialog(BatteryManager.BATTERY_HEALTH_COLD);
                } else if (oldBatteryHealth == BatteryManager.BATTERY_HEALTH_COLD) {
                    Log.d(TAG, "dismiss BATTERY\_HEALTH\_HEALTH\_COLDwarning");
                    dismissVoltageHighWarningDialog();
                } else {
                     // do nothing
                }
            }
        } else {
            if (oldPlugged) {
                dismissVoltageHighWarningDialog();
            }
        }
        /* @} */
    }

```

showVoltageHighWarningDialog就是来处理相关电压过高的问题  
 所以就在这里添加处理方法就行


第一步 增加电源过高提示图标



```
diff --git a/frameworks/base/packages/SystemUI/res/drawable/ic_warning.xml b/frameworks/base/packages/SystemUI/res/drawable/ic_warning.xml
new file mode 100755 (executable)
index 0000000..c495599
--- /dev/null
+++ b/frameworks/base/packages/SystemUI/res/drawable/ic_warning.xml
@@ -0,0 +1,9 @@
+<vector xmlns:android="http://schemas.android.com/apk/res/android"
+        android:width="44dp"
+        android:height="44dp"
+        android:viewportWidth="24.0"
+        android:viewportHeight="24.0">
+    <path
+        android:fillColor="#666666"
+        android:pathData="M1,21h22L12,2 1,21zM13,18h-2v-2h2v2zM13,14h-2v-4h2v4z"/>
+</vector>

```

第二步怎么提示框 xml文件



```
diff --git a/frameworks/base/packages/SystemUI/res/layout/dialog_warning.xml b/frameworks/base/packages/SystemUI/res/layout/dialog_warning.xml
new file mode 100755 (executable)
index 0000000..a1fb1e7
--- /dev/null
+++ b/frameworks/base/packages/SystemUI/res/layout/dialog_warning.xml
@@ -0,0 +1,40 @@
+<?xml version="1.0" encoding="utf-8"?>
+<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
+    android:layout_width="match\_parent"
+    android:layout_height="match\_parent"
+    android:background="#ffff00"
+    android:gravity="center\_vertical"
+    android:orientation="vertical"
+    android:paddingLeft="35dp"
+    android:paddingTop="50dp"
+    android:paddingRight="20dp"
+    android:paddingBottom="50dp">
+
+    <TextView
+        android:id="@+id/tv\_title"
+        android:layout_width="match\_parent"
+        android:layout_height="wrap\_content"
+        android:drawableLeft="@drawable/ic\_warning"
+        android:drawablePadding="10dp"
+        android:gravity="center\_vertical"
+        android:textSize="46sp" />
+
+    <TextView
+        android:id="@+id/tv\_message"
+        android:layout_width="match\_parent"
+        android:layout_height="wrap\_content"
+        android:layout_marginTop="30dp"
+        android:textSize="34sp" />
+
+
+    <TextView
+           android:padding="5dp"
+        android:id="@+id/tv\_back"
+        android:layout_width="match\_parent"
+        android:layout_height="wrap\_content"
+        android:layout_marginTop="30dp"
+        android:gravity="right"
+        android:textSize="20sp" />
+
+
+</LinearLayout>

```

第三部 增加提示警报声


\ No newline at end of file  
 diff --git a/frameworks/base/packages/SystemUI/res/raw/warning.mp3 b/frameworks/base/packages/SystemUI/res/raw/warn.mp3  
 new file mode 100755 (executable)  
 index 0000000…de9d421  
 Binary files /dev/null and b/frameworks/base/packages/SystemUI/res/raw/warning.mp3 differ  
 第四步：  
 增加电压过高的相关处理



```
diff --git a/frameworks/base/packages/SystemUI/src/com/sprd/systemui/power/SprdPowerUI.java b/frameworks/base/packages/SystemUI/src/com/sprd/systemui/power/SprdPowerUI.java
index d62df89..50c59ac 100755 (executable)
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/PowerUI.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/PowerUI.java
@@ -6,8 +6,16 @@ import android.content.DialogInterface;
 import android.view.WindowManager;
 import android.os.BatteryManager;
 import android.util.Log;
-
+import android.view.LayoutInflater;
+import android.view.View;
+import android.widget.TextView;
+import android.graphics.Color;
 import com.android.systemui.R;
+import android.media.AudioManager;
+import android.media.MediaPlayer;
+import android.view.Display;
+import android.view.Gravity;
+import android.view.ViewGroup;

 public class SprdPowerUI {

@@ -57,37 +65,69 @@ public class SprdPowerUI {
     /* SPRD: Modified for bug 505221, add voltage high warning @{ */
     private void showVoltageHighWarningDialog(int warningType) {
         Log.d(TAG, "showing showVoltageHighWarningDialog dialog");
+               //add code start
+               View view = LayoutInflater.from(mContext).inflate(R.layout.dialog_warning, null);//add code
+               TextView tvTitle = view.findViewById(R.id.tv_title);
+        TextView tvMessage = view.findViewById(R.id.tv_message);
+               TextView tvBack = view.findViewById(R.id.tv_back);
+        tvTitle.setTextColor(Color.RED);
+        tvMessage.setTextColor(Color.RED);
+               tvTitle.setText(R.string.battery_overtage_title);
+               tvBack.setText(R.string.battery_overtage_back);
+               //add code end
         AlertDialog.Builder b = new AlertDialog.Builder(mContext);
         b.setCancelable(false);
-        b.setTitle(R.string.battery_overtage_title);
+        //b.setTitle(R.string.battery_overtage_title);
+               b.setView(view);
         switch (warningType) {
             case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
-                b.setMessage(R.string.battery_overtage_content);
+                //b.setMessage(R.string.battery_overtage_content);
+                               tvMessage.setText(R.string.battery_overtage_content);
             break;
             case BatteryManager.BATTERY_HEALTH_OVERHEAT:
-                b.setMessage(R.string.battery_overheat_content);
+                //b.setMessage(R.string.battery_overheat_content);
+                               tvMessage.setText(R.string.battery_overheat_content);
             break;
             case BatteryManager.BATTERY_HEALTH_COLD:
-                b.setMessage(R.string.battery_cold_content); 
+                //b.setMessage(R.string.battery_cold_content);
+                tvMessage.setText(R.string.battery_cold_content);
         }
     //changed end >>>\r
-        b.setIconAttribute(android.R.attr.alertDialogIcon);
+        /*b.setIconAttribute(android.R.attr.alertDialogIcon);
         b.setPositiveButton(R.string.battery_overtage_back,
         new DialogInterface.OnClickListener() {
             public void onClick(DialogInterface dialog, int id) {
                 dialog.cancel();
         }
-        });
+        });*/
 
-        AlertDialog d = b.create();
+        final AlertDialog d = b.create();
+               tvBack.setOnClickListener(new View.OnClickListener() {
+            @Override
+            public void onClick(View v) {
+                d.cancel();
+                stopVoice();
+            }\r
+        });\r
         d.setOnDismissListener(new DialogInterface.OnDismissListener() {
             public void onDismiss(DialogInterface dialog) {\r
                 mVoltageHighDialog = null;
+                               stopVoice();
             }
         });
 
         d.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ERROR);
         d.show();
+               //add code start
+               WindowManager m = (WindowManager)mContext.getSystemService(Context.WINDOW_SERVICE);
+        Display display = m.getDefaultDisplay();
+        android.view.WindowManager.LayoutParams p = d.getWindow().getAttributes();
+        p.height = ViewGroup.LayoutParams.WRAP_CONTENT;
+        p.width = (int) (display.getWidth() * 0.6);
+        p.gravity =Gravity.CENTER;
+        d.getWindow().setAttributes(p);
+               playVoice(mContext);
+               //add cod end\r
         mVoltageHighDialog = d;
     }
 
@@ -98,4 +138,33 @@ public class SprdPowerUI {
         }
     }
     /* @} */
+    private MediaPlayer mediaPlayer;
+
+    private void playVoice(Context context) {
+               Log.d(TAG, "playVoice=====");
+        try {
+            AudioManager audioMa = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
+            audioMa.setStreamVolume(AudioManager.STREAM_MUSIC, audioMa.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_PLAY_SOUND);
+                       if(mediaPlayer == null){
+                               Log.d(TAG, "playVoice=====----- create");
+                               mediaPlayer = MediaPlayer.create(context, R.raw.warn);
+                       }
+                       if(mediaPlayer!=null && !mediaPlayer.isPlaying()){
+                               Log.d(TAG, "playVoice=====-----");
+                               mediaPlayer.start();
+                           mediaPlayer.setLooping(true);
+                       }
+\r
+        } catch (Exception e) {
+            e.printStackTrace();
+        }
+    }
+
+    private void stopVoice() {
+        if (null != mediaPlayer) {
+            mediaPlayer.stop();
+            mediaPlayer.release();
+            mediaPlayer = null;
+        }
+    }
 }

```




