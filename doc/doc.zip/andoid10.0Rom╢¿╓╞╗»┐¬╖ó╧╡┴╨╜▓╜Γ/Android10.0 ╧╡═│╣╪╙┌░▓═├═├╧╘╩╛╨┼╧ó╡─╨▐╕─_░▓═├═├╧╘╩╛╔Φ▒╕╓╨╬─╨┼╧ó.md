



## 1.前言


在10.0的系统定制化开发中，在一些产品开发中，对于安兔兔等第三方检测工具，检测不出某些版本的内核信息等，显示0GB等问题的相关修改，由于不知道安兔兔的检测方式，所以就需要来修改  
 关于文本上的一些信息了


## 2.系统关于安兔兔显示信息的修改的核心类



```
frameworks/base/core/java/android/widget/TextView.java
```

## 3.系统关于安兔兔显示信息的修改的核心功能分析和实现


在Android应用中，我们通常使用TextView向用户展示文本信息，  
 并可设置文字的字体大小、颜色、背景色等基本样式，首先我们看看 TextView，它是 Android 中很常用的 View，用来展示文本信息。它通常会其他的 View 一起搭配使用，用来作为提示信息。  
 比如我们前面做过的登陆界面，就会搭配 EditText，显示输入的内容提示。  
 设置一个默认文本作为，当没有设置文本内容的时候会展示在 TextView 当中。很多时候我们的 TextView 会根据服务端的内容动态设置，此时就可以通过android:hint为 TextView  
  设置一个默认值，在没有拉到服务器数据的时候展示默认文本。  
 在进行安兔兔检测的时候，可以发现在检测信息里面其实都是通过TextView来展现的检测信息的，虽然不知道  
 安兔兔是怎么获取信息的，但是可以在系统中的TextView的文本中，来通过修改检测到的信息来显示真实的  
 内核信息的，接下来就具体分析下TextView中的显示信息部分来实现功能的开发



```
    @android.view.RemotableViewMethod
      public final void setText(CharSequence text) {
          setText(text, mBufferType);
      }
  public void setText(CharSequence text, BufferType type) {
          setText(text, type, true, 0);
  
          if (mCharWrapper != null) {
              mCharWrapper.mChars = null;
          }
      }
  
      @UnsupportedAppUsage
      private void setText(CharSequence text, BufferType type,
                           boolean notifyBefore, int oldlen) {
          mTextSetFromXmlOrResourceId = false;
          if (text == null) {
              text = "";
          }
  
          // If suggestions are not enabled, remove the suggestion spans from the text
          if (!isSuggestionsEnabled()) {
              text = removeSuggestionSpans(text);
          }
  
          if (!mUserSetTextScaleX) mTextPaint.setTextScaleX(1.0f);
  
          if (text instanceof Spanned
                  && ((Spanned) text).getSpanStart(TextUtils.TruncateAt.MARQUEE) >= 0) {
              if (ViewConfiguration.get(mContext).isFadingMarqueeEnabled()) {
                  setHorizontalFadingEdgeEnabled(true);
                  mMarqueeFadeMode = MARQUEE_FADE_NORMAL;
              } else {
                  setHorizontalFadingEdgeEnabled(false);
                  mMarqueeFadeMode = MARQUEE_FADE_SWITCH_SHOW_ELLIPSIS;
              }
              setEllipsize(TextUtils.TruncateAt.MARQUEE);
          }
  
          int n = mFilters.length;
          for (int i = 0; i < n; i++) {
              CharSequence out = mFilters[i].filter(text, 0, text.length(), EMPTY_SPANNED, 0, 0);
              if (out != null) {
                  text = out;
              }
          }
  
          if (notifyBefore) {
              if (mText != null) {
                  oldlen = mText.length();
                  sendBeforeTextChanged(mText, 0, oldlen, text.length());
              } else {
                  sendBeforeTextChanged("", 0, 0, text.length());
              }
          }
  
          boolean needEditableForNotification = false;
  
          if (mListeners != null && mListeners.size() != 0) {
              needEditableForNotification = true;
          }
  
          PrecomputedText precomputed =
                  (text instanceof PrecomputedText) ? (PrecomputedText) text : null;
          if (type == BufferType.EDITABLE || getKeyListener() != null
                  || needEditableForNotification) {
              createEditorIfNeeded();
              mEditor.forgetUndoRedo();
              Editable t = mEditableFactory.newEditable(text);
              text = t;
              setFilters(t, mFilters);
              InputMethodManager imm = getInputMethodManager();
              if (imm != null) imm.restartInput(this);
          } else if (precomputed != null) {
              if (mTextDir == null) {
                  mTextDir = getTextDirectionHeuristic();
              }
              final @PrecomputedText.Params.CheckResultUsableResult int checkResult =
                      precomputed.getParams().checkResultUsable(getPaint(), mTextDir, mBreakStrategy,
                              mHyphenationFrequency);
              switch (checkResult) {
                  case PrecomputedText.Params.UNUSABLE:
                      throw new IllegalArgumentException(
                          "PrecomputedText's Parameters don't match the parameters of this TextView."
                          + "Consider using setTextMetricsParams(precomputedText.getParams()) "
                          + "to override the settings of this TextView: "
                          + "PrecomputedText: " + precomputed.getParams()
                          + "TextView: " + getTextMetricsParams());
                  case PrecomputedText.Params.NEED_RECOMPUTE:
                      precomputed = PrecomputedText.create(precomputed, getTextMetricsParams());
                      break;
                  case PrecomputedText.Params.USABLE:
                      // pass through
              }
          } else if (type == BufferType.SPANNABLE || mMovement != null) {
              text = mSpannableFactory.newSpannable(text);
          } else if (!(text instanceof CharWrapper)) {
              text = TextUtils.stringOrSpannedString(text);
          }
  
  .....
  
          if (mLayout != null) {
              checkForRelayout();
          }
  
          sendOnTextChanged(text, 0, oldlen, textLength);
          onTextChanged(text, 0, oldlen, textLength);
  
          notifyViewAccessibilityStateChangedIfNeeded(AccessibilityEvent.CONTENT_CHANGE_TYPE_TEXT);
  
          if (needEditableForNotification) {
              sendAfterTextChanged((Editable) text);
          } else {
              notifyListeningManagersAfterTextChanged();
          }
  
          // SelectionModifierCursorController depends on textCanBeSelected, which depends on text
          if (mEditor != null) mEditor.prepareCursorControllers();
      }
```

在上述的TextView.java的相关源码分析得知，在这里setText(CharSequence text)，中设置显示信息，  
 而它调用setText(CharSequence text, BufferType type)，最终通过调用setText(CharSequence text, BufferType type,  
                            boolean notifyBefore, int oldlen) 来实现信息文字的赋值操作，  
 所以根据相关代码打印，发现文字信息是在append(CharSequence text, int start, int end)中  
 显示的，所以需要分析下append(CharSequence text, int start, int end)的相关源码



```
 /**
       * Convenience method to append the specified text to the TextView's
       * display buffer, upgrading it to {@link android.widget.TextView.BufferType#EDITABLE}
       * if it was not already editable.
       *
       * @param text text to be appended to the already displayed text
       */
      public final void append(CharSequence text) {
          append(text, 0, text.length());
      }
  
      /**
       * Convenience method to append the specified text slice to the TextView's
       * display buffer, upgrading it to {@link android.widget.TextView.BufferType#EDITABLE}
       * if it was not already editable.
       *
       * @param text text to be appended to the already displayed text
       * @param start the index of the first character in the {@code text}
       * @param end the index of the character following the last character in the {@code text}
       *
       * @see Appendable#append(CharSequence, int, int)
       */
      public void append(CharSequence text, int start, int end) {
          if (!(mText instanceof Editable)) {
              setText(mText, BufferType.EDITABLE);
          }
  
          ((Editable) mText).append(text, start, end);
  //add core start

  if (getContext() != null) {
        String packageName = getContext().getPackageName();
        if ("com.antutu.ABenchMark".equalsIgnoreCase(packageName)) {
    String tempText2 = mText.toString().trim();
    if( tempText2.contains("0GB") ){
                     ((Editable) mText).delete(0,mText.length());
                      ((Editable) mText).instert(0,"4.0GB");
                }
       }
}
//add core end
          if (mAutoLinkMask != 0) {
              boolean linksWereAdded = Linkify.addLinks(mSpannable, mAutoLinkMask);
              // Do not change the movement method for text that support text selection as it
              // would prevent an arbitrary cursor displacement.
              if (linksWereAdded && mLinksClickable && !textCanBeSelected()) {
                  setMovementMethod(LinkMovementMethod.getInstance());
              }
          }
      }
```

在上述的TextView.java的相关源码中，经过分析得知在TextView的append(CharSequence text)  
 为字符串尾部增加字符。append(CharSequence text, int start, int end)  
 为字符串尾部增加指定字符，start和end用于指定字符内容。所以说经过上述的分析得知，在打印  
 相关的日志得知，在安兔兔的信息里面显示的内核信息不完善，所以需要在这里更加相关的显示信息  
 来修改具体的内核相关的源码分析,通过上面增加的代码，就可以实现修改安兔兔中的显示内核  
 信息为0GB,来正确显示内核信息



