






### 1.概述


在10.0的系统产品中，在教育平板开发中，产品不需要锁屏,每次开机锁屏显得麻烦，所以需要禁用锁屏功能，而锁屏功能都是在SystemUI中处理的  
 解决方案 就是在SystemUI里面禁止开启锁屏功能


### 2.SystemUI禁用锁屏功能的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/keyguard/KeyguardViewMediator.java
/frameworks/base/packages/SystemUI/src/com/android/systemui/SystemUIApplication.java

```

### 3.SystemUI禁用锁屏功能的核心功能分析和实现


在系统SystemUI中默认的锁屏管理服务是在  
 KeyguardManager.KeyguardLock 关闭锁屏服务


如下：  
 SystemUI的SystemUIApplication里面添加关闭锁屏服务；



```
   /**
   * Application class for SystemUI.
   */
  public class SystemUIApplication extends Application implements SysUiServiceProvider {
     @Override
     public void onCreate() {
         super.onCreate();
         // Set the application theme that is inherited by all services. Note that setting the
         // application theme in the manifest does only work for activities. Keep this in sync with
         // the theme set there.
         setTheme(R.style.Theme_SystemUI);
 
         SystemUIFactory.createFromConfig(this);
 
         if (Process.myUserHandle().equals(UserHandle.SYSTEM)) {
             IntentFilter bootCompletedFilter = new IntentFilter(Intent.ACTION_BOOT_COMPLETED);
             bootCompletedFilter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
             registerReceiver(new BroadcastReceiver() {
                 @Override
                 public void onReceive(Context context, Intent intent) {
                     if (mBootCompleted) return;
 
                     if (DEBUG) Log.v(TAG, "BOOT\_COMPLETED received");
                     unregisterReceiver(this);
                     mBootCompleted = true;
                     if (mServicesStarted) {
                         final int N = mServices.length;
                         for (int i = 0; i < N; i++) {
                             mServices[i].onBootCompleted();
                         }
                     }
 
 
                 }
             }, bootCompletedFilter);
 
             IntentFilter localeChangedFilter = new IntentFilter(Intent.ACTION_LOCALE_CHANGED);
             registerReceiver(new BroadcastReceiver() {
                 @Override
                 public void onReceive(Context context, Intent intent) {
                     if (Intent.ACTION_LOCALE_CHANGED.equals(intent.getAction())) {
                          if (!mBootCompleted) return;
                          // Update names of SystemUi notification channels
                          NotificationChannels.createAll(context);
                      }
                  }
              }, localeChangedFilter);
          } else {
              // We don't need to startServices for sub-process that is doing some tasks.
              // (screenshots, sweetsweetdesserts or tuner ..)
              String processName = ActivityThread.currentProcessName();
              ApplicationInfo info = getApplicationInfo();
              if (processName != null && processName.startsWith(info.processName + ":")) {
                  return;
              }
              // For a secondary user, boot-completed will never be called because it has already
              // been broadcasted on startup for the primary SystemUI process.  Instead, for
              // components which require the SystemUI component to be initialized per-user, we
              // start those components now for the current non-system user.
              startSecondaryUserServicesIfNeeded();
          }
      }
  
      /**
       * Makes sure that all the SystemUI services are running. If they are already running, this is a
       * no-op. This is needed to conditinally start all the services, as we only need to have it in
       * the main process.
       * <p>This method must only be called from the main thread.</p>
       */
  
      public void startServicesIfNeeded() {
          String[] names = getResources().getStringArray(R.array.config_systemUIServiceComponents);
          startServicesIfNeeded(names);
      }
  

```

接下来在onCreate()中关闭锁屏服务



```
  @Override
    public void onCreate() {
        super.onCreate();
        new android.os.Handler().postDelayed(new Runnable() {
            @Override
              public void run() {
                    android.app.KeyguardManager km = (android.app.KeyguardManager) SystemUIApplication.this.getSystemService(Context.KEYGUARD_SERVICE); /* 获取KeyguardLock对象 */

                    android.app.KeyguardManager.KeyguardLock keyguardLock = km.newKeyguardLock(TAG);

                    // 关闭系统锁屏服务

                    keyguardLock.disableKeyguard();

                }

        },6000);

    }

```

在SystemUIApplication的onCreate()的中禁用锁屏功能  
 步骤2：  
 在KeyguardViewMediator.java 锁屏界面禁止锁屏启动  
 接下来看下关于KeyguardViewMediator.java 锁屏功能



```
frameworks/base/packages/SystemUI/src/com/android/systemui/keyguard/KeyguardViewMediator.java
/**
     * Let us know that the system is ready after startup.
     */
    public void onSystemReady() {
        mHandler.obtainMessage(SYSTEM_READY).sendToTarget();
    }

    private void handleSystemReady() {
        synchronized (this) {
            if (DEBUG) Log.d(TAG, "onSystemReady");
            mSystemReady = true;
            doKeyguardLocked(null);
            mUpdateMonitor.registerCallback(mUpdateCallback);
        }
        /* UNISOC: carrier datausage dialog warning feature for 644278 @{ */
        boolean isShowDialog = false;
        if (mContext.getResources().getBoolean(R.bool.config_show_datausage_dialog)) {
            isShowDialog = Settings.Global.getInt(
                    mContext.getContentResolver(), SHOW_TRAFFIC_TIPS, 1) == 1;
        } else {
            isShowDialog = false;
        }
        Log.d(TAG,
                "StartupReceiver value = "
                        + Settings.Global.getInt(mContext.getContentResolver(),
                        SHOW_TRAFFIC_TIPS, 1) + ", isShowDialog = "
                        + isShowDialog);
        if (isShowDialog) {
            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    showPackageDialogIfNeeded(mContext);
                }
            });
        }
        /* @} */
        // Most services aren't available until the system reaches the ready state, so we
        // send it here when the device first boots.
        maybeSendUserPresentBroadcast();
    }

```

从源码可以看出onSystemReady 开机完成后，调用doKeyguardLocked(null);启动锁屏功能 所以 在开机完成后去掉 启动锁屏  
 注释掉doKeyguardLocked(null); 即可


修改如下:



```
private void handleSystemReady() {
        synchronized (this) {
            if (DEBUG) Log.d(TAG, "onSystemReady");
            mSystemReady = true;
            - doKeyguardLocked(null);
            mUpdateMonitor.registerCallback(mUpdateCallback);
        }
        /* UNISOC: carrier datausage dialog warning feature for 644278 @{ */
        boolean isShowDialog = false;
        if (mContext.getResources().getBoolean(R.bool.config_show_datausage_dialog)) {
            isShowDialog = Settings.Global.getInt(
                    mContext.getContentResolver(), SHOW_TRAFFIC_TIPS, 1) == 1;
        } else {
            isShowDialog = false;
        }
        Log.d(TAG,
                "StartupReceiver value = "
                        + Settings.Global.getInt(mContext.getContentResolver(),
                        SHOW_TRAFFIC_TIPS, 1) + ", isShowDialog = "
                        + isShowDialog);
        if (isShowDialog) {
            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    showPackageDialogIfNeeded(mContext);
                }
            });
        }
        /* @} */
        // Most services aren't available until the system reaches the ready state, so we
        // send it here when the device first boots.
        maybeSendUserPresentBroadcast();
    }

```

通过上述两种方式就禁用了SystemUI的锁屏服务完成了去掉SystemUI的锁屏功能





