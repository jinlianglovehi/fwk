






### 1.概述


在10.0的产品定制化开发中，对SystemUI定制化各式各样的，而对于下拉通知栏每条通知的背景修改为圆角背景也是重要的功能，首先需要从相关布局中查看相关代码


### 2.SystemUI修改下拉通知栏每条通知的圆角背景的核心类



```
frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml
frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ActivatableNotificationView.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java

```

### 3.SystemUI修改下拉通知栏每条通知的圆角背景的核心功能分析和实现


在systemui的通知栏每条通知的就是通知的布局文件为status\_bar\_notification\_row.xml  
 所以具体分析通知的布局文件为status\_bar\_notification\_row.xml解决问题


### 3.1对布局文件添加圆角背景为


qs\_background\_primary.xml



```
<inset xmlns:android="http://schemas.android.com/apk/res/android">
    <shape>
        <solid android:color="#ffffff"/>
        <corners android:radius="20dp" />
    </shape>
</inset>

```

设置圆角和颜色为白色圆角背景


### 3.2每条通知的布局status\_bar\_notification\_row.xml分析



```
--- a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_row.xml
@@ -39,12 +39,13 @@
     <com.android.systemui.statusbar.notification.row.NotificationContentView
         android:id="@+id/expanded"
        android:layout_width="match\_parent"
-       android:layout_height="wrap\_content" />
+       android:layout_height="wrap\_content"
+          android:background="@drawable/qs\_background\_primary"/>
 
     <com.android.systemui.statusbar.notification.row.NotificationContentView
         android:id="@+id/expandedPublic"
         android:layout_width="match\_parent"
-        android:layout_height="wrap\_content" />
+        android:layout_height="wrap\_content"           />
 
     <Button
         android:id="@+id/veto"
@@ -63,6 +64,7 @@
         android:inflatedId="@+id/notification\_children\_container"
         android:layout_width="match\_parent"
         android:layout_height="wrap\_content"
+               android:background="@drawable/qs\_background\_primary"
         />
 
     <ViewStub

```

从上述源码可以看出com.android.systemui.statusbar.notification.row.NotificationContentView就是每条通知跟布局，可以在这里设置圆角布局


### 3.2 关于status\_bar\_notification\_section\_header.xml圆角背景的修改



```
--- a/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/status_bar_notification_section_header.xml
@@ -21,6 +21,7 @@
     android:layout_height="@dimen/notification\_section\_header\_height"
     android:focusable="true"
     android:clickable="true"
+       android:background="@drawable/qs\_background\_primary"
     >
 
     <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
@@ -38,6 +39,7 @@
         android:layout_height="match\_parent"
         android:gravity="center\_vertical"
         android:orientation="horizontal"
+               android:background="@drawable/qs\_background\_primary"
         >
         <include layout="@layout/status\_bar\_notification\_section\_header\_contents"/>
     </LinearLayout>

```

在status\_bar\_notification\_section\_header.xml的置顶布局中设置新建的圆角背景  
 qs\_background\_primary然后就可以变成圆角背景


### 3.3在ActivatableNotificationView.java中增加圆角背景的修改



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ActivatableNotificationView.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ActivatableNotificationView.java
@@ -233,8 +233,8 @@ public abstract class ActivatableNotificationView extends ExpandableOutlineView
      * be useful in a configuration change.
      */
     protected void initBackground() {
-        mBackgroundNormal.setCustomBackground(R.drawable.notification_material_bg);
-        mBackgroundDimmed.setCustomBackground(R.drawable.notification_material_bg_dim);
+        mBackgroundNormal.setCustomBackground(R.drawable.qs_background_primary);
+        mBackgroundDimmed.setCustomBackground(R.drawable.qs_background_primary);
     }
 
     private final Runnable mTapTimeoutRunnable = new Runnable() {

```

从ActivatableNotificationView.java中的initBackground()可以看出这里就是初始化背景的相关方法  
 所以可以在这里设置mBackgroundNormal和 mBackgroundDimmed为圆角背景qs\_background\_primary从而实现圆角背景


### 3.4 NotificationStackScrollLayout.java 圆角布局的修改



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java
@@ -100,6 +100,7 @@ import com.android.systemui.statusbar.AmbientPulseManager;
 import com.android.systemui.statusbar.CommandQueue;
 import com.android.systemui.statusbar.DragDownHelper.DragDownCallback;
 import com.android.systemui.statusbar.EmptyShadeView;

 import com.android.systemui.statusbar.NotificationLockscreenUserManager;
 import com.android.systemui.statusbar.NotificationRemoteInputManager;
 import com.android.systemui.statusbar.NotificationShelf;
@@ -153,7 +154,7 @@ import java.util.Comparator;
 import java.util.HashSet;
 import java.util.List;
 import java.util.function.BiConsumer;

 import javax.inject.Inject;
 import javax.inject.Named;
 
@@ -283,6 +284,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
     protected boolean mScrollingEnabled;
     protected FooterView mFooterView;
     protected EmptyShadeView mEmptyShadeView;
     private boolean mDismissAllInProgress;
     private boolean mFadeNotificationsOnDismiss;
 
@@ -608,6 +610,9 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
             }
         });
         dynamicPrivacyController.addListener(this);

     }
 
     private void updateDismissRtlSetting(boolean dismissRtl) {
@@ -624,7 +629,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
     protected void onFinishInflate() {
         super.onFinishInflate();

         inflateEmptyShadeView();
         inflateFooterView();
         mVisualStabilityManager.setVisibilityLocationProvider(this::isInVisibleLocation);
@@ -651,6 +656,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
     }
 
     private void reinflateViews() {

         inflateFooterView();
         inflateEmptyShadeView();
         updateFooter();
@@ -834,11 +840,11 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
         int right = (int) MathUtils.lerp(darkLeft, lockScreenRight, xProgress);
         int top = (int) MathUtils.lerp(darkTop, lockScreenTop, yProgress);
         int bottom = (int) MathUtils.lerp(darkTop, lockScreenBottom, yProgress);
-        mBackgroundAnimationRect.set(
+        /*mBackgroundAnimationRect.set(
                 left,
                 top,
                 right,
-                bottom);
+                bottom);*/
 
         int backgroundTopAnimationOffset = top - lockScreenTop;
         // TODO(kprevas): this may not be necessary any more since we don't display the shelf in AOD
@@ -850,7 +856,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
             }
         }
         if (!mAmbientState.isDark() || anySectionHasVisibleChild) {
-            drawBackgroundRects(canvas, left, right, top, backgroundTopAnimationOffset);
+            //drawBackgroundRects(canvas, left, right, top, backgroundTopAnimationOffset);
         }
 
         updateClipping();
@@ -924,6 +930,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
             if (child.getVisibility() != View.GONE
                     && child instanceof ExpandableNotificationRow) {
                 ExpandableNotificationRow row = (ExpandableNotificationRow) child;
                 if ((row.isPinned() || row.isHeadsUpAnimatingAway()) && row.getTranslation() < 0
                         && row.getProvider().shouldShowGutsOnSnapOpen()) {
                     top = Math.min(top, row.getTranslationY());

 
     @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
@@ -4892,7 +4902,15 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
         mEmptyShadeView = emptyShadeView;
         addView(mEmptyShadeView, index);
     }


     /**
      * Updates expanded, dimmed and locked states of notification rows.
      */
     @ShadeViewRefactor(RefactorComponent.STATE_RESOLVER)
     public void onUpdateRowStates() {
         changeViewPosition(mFooterView, -1);

```

在NotificationStackScrollLayout 的reinflateViews() 中为重新inflate布局，而在这里的mBackgroundAnimationRect为设置背景的四角参数不是圆角布局，所以需要注释掉，而  
 drawBackgroundRects也是绘制四角布局需要注释掉  
 通过上面的修改 通知的背景修改为圆角布局





