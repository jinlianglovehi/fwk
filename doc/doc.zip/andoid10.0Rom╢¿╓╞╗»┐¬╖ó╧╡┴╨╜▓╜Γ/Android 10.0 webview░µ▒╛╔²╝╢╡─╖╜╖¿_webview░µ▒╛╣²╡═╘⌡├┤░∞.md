



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.webview版本升级的步骤](#2.webview%E7%89%88%E6%9C%AC%E5%8D%87%E7%BA%A7%E7%9A%84%E6%AD%A5%E9%AA%A4)


[2.1 翻墙下载新版本](#%C2%A0%C2%A0%202.1%20%E7%BF%BB%E5%A2%99%E4%B8%8B%E8%BD%BD%E6%96%B0%E7%89%88%E6%9C%AC)


[2.2 找到系统源码webview.apk的位置](#%C2%A0%C2%A0%202.2%20%E6%89%BE%E5%88%B0%E7%B3%BB%E7%BB%9F%E6%BA%90%E7%A0%81webview.apk%E7%9A%84%E4%BD%8D%E7%BD%AE)


[2.4 frameworks/base/core/res/res/xml/config\_webview\_packages.xml下webview包名的修改](#2.4%20frameworks%2Fbase%2Fcore%2Fres%2Fres%2Fxml%2Fconfig_webview_packages.xml%E4%B8%8Bwebview%E5%8C%85%E5%90%8D%E7%9A%84%E4%BF%AE%E6%94%B9)



[2.5 额外注意事项](#2.5%20%E9%A2%9D%E5%A4%96%E6%B3%A8%E6%84%8F%E4%BA%8B%E9%A1%B9)


[2.6 编译烧录固件 验证webview版本](#2.6%20%E7%BC%96%E8%AF%91%E7%83%A7%E5%BD%95%E5%9B%BA%E4%BB%B6%20%E9%AA%8C%E8%AF%81webview%E7%89%88%E6%9C%AC)




---



## 1.概述


  在产品开发中，由于app大多数采用的h5页面有webview加载的方式显示出来，结果在加载一些页面显示不支持一些属性，经过测试发现由于webview的版本  
 有些低是80版本的 用谷歌官方101版本升级测试后发现webview页面正常，所以就来谈一下升级步骤


## 2.webview版本升级的步骤


##    2.1 翻墙下载新版本


    网址:https://www.apkmirror.com/apk/google-inc/android-system-webview/  
     根据需要下载对应的版本，高版本的webview兼容低版本的，根据实际使用情况来下载对应的webview.apk


##    2.2 找到系统源码webview.apk的位置


   方法是搜索find  -name "webview.apk",搜索发现源码路径位于external\chromium-webview\prebuilt\  
    这个目录同时有arm arm64 x86 x86\_64四个目录，其实大多数只需要用到arm 和arm64这两个架构的 ，用下载下来的webview.apk所以替换  
    arm和arm64的对应的webview.apk，通过解压下载下来的101版本的webview.apk和external\chromium-webview\prebuilt\目录下webview.apk  
    做对比发现 多了三个so库 所以要对Android.mk做修改  
    Android.mk文件 如下



```
#
#
# Copyright (C) 2014 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# Copyright (C) 2014 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Install the prebuilt webview apk.
ifeq ($(strip $(GMS_SUPPORT)), true)
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := webview
LOCAL_MODULE_CLASS := APPS
LOCAL_PRODUCT_MODULE := true
LOCAL_MULTILIB := both
LOCAL_CERTIFICATE := $(DEFAULT_SYSTEM_DEV_CERTIFICATE)
LOCAL_REQUIRED_MODULES := \
        libwebviewchromium_loader \
        libwebviewchromium_plat_support

LOCAL_MODULE_TARGET_ARCH := arm arm64 x86 x86_64
my_src_arch := $(call get-prebuilt-src-arch,$(LOCAL_MODULE_TARGET_ARCH))
LOCAL_SRC_FILES := prebuilt/$(my_src_arch)/webview.apk

LOCAL_PREBUILT_JNI_LIBS_arm := @lib/armeabi-v7a/libwebviewchromium.so
LOCAL_PREBUILT_JNI_LIBS_arm64 := @lib/arm64-v8a/libwebviewchromium.so
LOCAL_PREBUILT_JNI_LIBS_x86 := @lib/x86/libwebviewchromium.so
LOCAL_PREBUILT_JNI_LIBS_x86_64 := @lib/x86_64/libwebviewchromium.so

include $(BUILD_PREBUILT)
endif

```

具体修改为:



```
#
# Copyright (C) 2014 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Install the prebuilt webview apk.
#ifeq ($(strip $(GMS_SUPPORT)), true)
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := webview
LOCAL_MODULE_CLASS := APPS
LOCAL_PRODUCT_MODULE := true
LOCAL_MULTILIB := both
LOCAL_CERTIFICATE := $(DEFAULT_SYSTEM_DEV_CERTIFICATE)
LOCAL_REQUIRED_MODULES := \
        libwebviewchromium_loader \
        libwebviewchromium_plat_support
# 去掉x86和x86_64
LOCAL_MODULE_TARGET_ARCH := arm arm64
my_src_arch := $(call get-prebuilt-src-arch,$(LOCAL_MODULE_TARGET_ARCH))
LOCAL_SRC_FILES := prebuilt/$(my_src_arch)/webview.apk

LOCAL_PREBUILT_JNI_LIBS_arm := @lib/armeabi-v7a/libwebviewchromium.so \
                               @lib/armeabi-v7a/libcrashpad_handler_trampoline.so \
                               @lib/armeabi-v7a/libchromium_android_linker.so \
                               @lib/armeabi-v7a/libarcore_sdk_c.so
LOCAL_PREBUILT_JNI_LIBS_arm64 := @lib/arm64-v8a/libwebviewchromium.so \
                               @lib/arm64-v8a/libcrashpad_handler_trampoline.so \
                               @lib/arm64-v8a/libchromium_android_linker.so \
                               @lib/arm64-v8a/libarcore_sdk_c.so
#LOCAL_PREBUILT_JNI_LIBS_x86 := @lib/x86/libwebviewchromium.so
#LOCAL_PREBUILT_JNI_LIBS_x86_64 := @lib/x86_64/libwebviewchromium.so

include $(BUILD_PREBUILT)
#endif
```

## 2.4 frameworks/base/core/res/res/xml/config\_webview\_packages.xml下webview包名的修改



```
<webviewproviders>
    <!-- The default WebView implementation -->
    <webviewprovider description="Android WebView" packageName="com.android.webview" availableByDefault="true">
    </webviewprovider>
</webviewproviders>

修改为：
<webviewproviders>
    <!-- The default WebView implementation -->
    <webviewprovider description="Android WebView" packageName="com.google.android.webview" availableByDefault="true">
    </webviewprovider>
</webviewproviders>
```

## 


此时看到这个 xml 文件里，已经有一个 webviewprovider，里面包名就是系统内置的 webview，com.android.webview 是很旧的了，之后更新的 webview 已经改为 com.google.android.webview。  
 模仿现有的，增加以下代码  
 description：自己定义一个名称，会显示在开发者选项 - WebView 实现里面。  
 packageName：为新安装的 WebView 程序的包名，现在新版本的都是 com.google.android.webview。  
 availableByDefault：直接设置新 WebView 为 true，默认使用。不过，实测设置了也没用，还是要到开发者选项设置后才行。所以这里 true / false 都行，但所有 webviewprovider 应该只存在一个 true。


## 2.5 额外注意事项


在mtk和展讯平台 在vendor下面也会有webview.apk的存在，如果怕影响功能，可以在prebuilt\这个目录下  
 的Android.mk文件改个名字，然后就不会覆盖掉external\chromium-webview\prebuilt\下的webview.apk了  
 如果有更好的方法，也可以尝试，由于项目时间紧 没有找到好的方法


## 2.6 编译烧录固件 验证webview版本


可以在用adb shell命令查看webview版本 命令如下:adb shell am start -a android.intent.action.VIEW -d https://liulanmi.com/labs/core.html  
 也可以在设置-应用和通知里面查看系统应用-显示系统进程-点击Android System Webview来查看webview系统版本




