






### 1.概述


在10.0的系统产品开发中，产品有需求，需要状态栏不显示某个app的通知,根据SystemUI源码通知显示流程可以得知NoticationFilter.java中可以处理过滤通知


### 2.SystemUI屏蔽某个app的通知的核心类



```
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\notification\NoticationFilter.java
/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/collection/NotificationData.java

```

### 3.SystemUI屏蔽某个app的通知的核心功能分析和实现


在通知的发送过程中NotificationData.java中在filterAndSort()中调用是不是需要过滤通知的管理  
 接下来看下NotificationData.java相关通知的源码分析



```
/**
   * The list of currently displaying notifications.
   */
  public class NotificationData {
  
      // TODO: This should not be public. Instead the Environment should notify this class when
      // anything changed, and this class should call back the UI so it updates itself.
      public void filterAndSort() {
          mSortedAndFiltered.clear();
  
          synchronized (mEntries) {
              final int len = mEntries.size();
              for (int i = 0; i < len; i++) {
                  NotificationEntry entry = mEntries.valueAt(i);
  
                  if (mNotificationFilter.shouldFilterOut(entry)) {
                      continue;
                  }
  
                  mSortedAndFiltered.add(entry);
              }
          }
  
          Collections.sort(mSortedAndFiltered, mRankingComparator);
      }

```

在filterAndSort() 中通过调用mNotificationFilter.shouldFilterOut(entry)判断当前通知是否需要过滤  
 需要过滤就结束通知流程


通过上述分析可知，在SystemUI中NoticationFilter.java中可以处理过滤通知  
 路径:  
 frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\notification\NoticationFilter.java



```
/** Component which manages the various reasons a notification might be filtered out. */
  @Singleton
  public class NotificationFilter {
  
      private final NotificationGroupManager mGroupManager = Dependency.get(
              NotificationGroupManager.class);
  
      private NotificationData.KeyguardEnvironment mEnvironment;
      private ShadeController mShadeController;
      private ForegroundServiceController mFsc;
      private NotificationLockscreenUserManager mUserManager;
  
      @Inject
      public NotificationFilter() {}
  
      private NotificationData.KeyguardEnvironment getEnvironment() {
          if (mEnvironment == null) {
              mEnvironment = Dependency.get(NotificationData.KeyguardEnvironment.class);
          }
          return mEnvironment;
      }
  
      private ShadeController getShadeController() {
          if (mShadeController == null) {
              mShadeController = Dependency.get(ShadeController.class);
          }
          return mShadeController;
      }
  
      private ForegroundServiceController getFsc() {
          if (mFsc == null) {
              mFsc = Dependency.get(ForegroundServiceController.class);
          }
          return mFsc;
      }
  
      private NotificationLockscreenUserManager getUserManager() {
          if (mUserManager == null) {
              mUserManager = Dependency.get(NotificationLockscreenUserManager.class);
          }
          return mUserManager;
      }
  
    public boolean shouldFilterOut(NotificationEntry entry) {
        final StatusBarNotification sbn = entry.notification;
        if (!(getEnvironment().isDeviceProvisioned()
                || showNotificationEvenIfUnprovisioned(sbn))) {
            return true;
        }

        if (!getEnvironment().isNotificationForCurrentProfiles(sbn)) {
            return true;
        }

        if (getUserManager().isLockscreenPublicMode(sbn.getUserId())
                && (sbn.getNotification().visibility == Notification.VISIBILITY_SECRET
                        || getUserManager().shouldHideNotifications(sbn.getUserId())
                        || getUserManager().shouldHideNotifications(sbn.getKey()))) {
            return true;
        }

        if (getShadeController().isDozing() && entry.shouldSuppressAmbient()) {
            return true;
        }

        if (!getShadeController().isDozing() && entry.shouldSuppressNotificationList()) {
            return true;
        }

        if (entry.suspended) {
            return true;
        }

        if (!StatusBar.ENABLE_CHILD_NOTIFICATIONS
                && mGroupManager.isChildInGroupWithSummary(sbn)) {
            return true;
        }

        if (getFsc().isDisclosureNotification(sbn)
                && !getFsc().isDisclosureNeededForUser(sbn.getUserId())) {
            // this is a foreground-service disclosure for a user that does not need to show one
            return true;
        }
        if (getFsc().isSystemAlertNotification(sbn)) {
            final String[] apps = sbn.getNotification().extras.getStringArray(
                    Notification.EXTRA_FOREGROUND_APPS);
            if (apps != null && apps.length >= 1) {
                if (!getFsc().isSystemAlertWarningNeeded(sbn.getUserId(), apps[0])) {
                    return true;
                }
            }
        }
        return false;
    }

```

在NoticationFilter.java中发现主要是  
 根据shouldFilterOut返回值来实现是否过滤  
 所以就需要在此处添加包名返回true就可以了，在通知到来时就不会显示通知了



```
 /**
     * @return true if the provided notification should NOT be shown right now.
     */
    public boolean shouldFilterOut(NotificationEntry entry) {
        final StatusBarNotification sbn = entry.notification;
		// 添加需要屏蔽的app的包名 返回true就可以了
		try {
			if(sbn.getPackageName().equals("com.android.systemdemo")){
				Log.d(TAG,"block notification channel-USB of package-android.");
				return true;
			}
		}catch (Exception e){
			e.printStackTrace();
			//do nothing.
		}
        if (!(getEnvironment().isDeviceProvisioned()
                || showNotificationEvenIfUnprovisioned(sbn))) {
            return true;
        }

        if (!getEnvironment().isNotificationForCurrentProfiles(sbn)) {
            return true;
        }

        if (getUserManager().isLockscreenPublicMode(sbn.getUserId())
                && (sbn.getNotification().visibility == Notification.VISIBILITY_SECRET
                        || getUserManager().shouldHideNotifications(sbn.getUserId())
                        || getUserManager().shouldHideNotifications(sbn.getKey()))) {
            return true;
        }

        if (getShadeController().isDozing() && entry.shouldSuppressAmbient()) {
            return true;
        }

        if (!getShadeController().isDozing() && entry.shouldSuppressNotificationList()) {
            return true;
        }

        if (entry.suspended) {
            return true;
        }

        if (!StatusBar.ENABLE_CHILD_NOTIFICATIONS
                && mGroupManager.isChildInGroupWithSummary(sbn)) {
            return true;
        }

        if (getFsc().isDisclosureNotification(sbn)
                && !getFsc().isDisclosureNeededForUser(sbn.getUserId())) {
            // this is a foreground-service disclosure for a user that does not need to show one
            return true;
        }
        if (getFsc().isSystemAlertNotification(sbn)) {
            final String[] apps = sbn.getNotification().extras.getStringArray(
                    Notification.EXTRA_FOREGROUND_APPS);
            if (apps != null && apps.length >= 1) {
                if (!getFsc().isSystemAlertWarningNeeded(sbn.getUserId(), apps[0])) {
                    return true;
                }
            }
        }
        return false;
    }

```

在shouldFilterOut(根据包名判断看是否需要过滤，需要过滤就返回true就可以了，实现了拦截某个app的通知





