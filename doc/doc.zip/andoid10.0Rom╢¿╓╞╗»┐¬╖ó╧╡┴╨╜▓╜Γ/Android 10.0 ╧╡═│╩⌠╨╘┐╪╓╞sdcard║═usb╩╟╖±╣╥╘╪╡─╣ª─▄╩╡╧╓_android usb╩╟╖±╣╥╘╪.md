



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.系统属性控制sdcard和usb是否挂载的功能实现核心代码](#2.%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E6%8E%A7%E5%88%B6sdcard%E5%92%8Cusb%E6%98%AF%E5%90%A6%E6%8C%82%E8%BD%BD%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.系统属性控制sdcard和usb是否挂载的功能实现核心功能分析](#3.%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E6%8E%A7%E5%88%B6sdcard%E5%92%8Cusb%E6%98%AF%E5%90%A6%E6%8C%82%E8%BD%BD%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 DiskInfo.java关于sdcard和usb设备属性的分析](#%C2%A0%203.1%20DiskInfo.java%E5%85%B3%E4%BA%8Esdcard%E5%92%8Cusb%E8%AE%BE%E5%A4%87%E5%B1%9E%E6%80%A7%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 VolumeInfo.java挂载外设相关属性的分析](#3.2%20VolumeInfo.java%E6%8C%82%E8%BD%BD%E5%A4%96%E8%AE%BE%E7%9B%B8%E5%85%B3%E5%B1%9E%E6%80%A7%E7%9A%84%E5%88%86%E6%9E%90)


[3.3 StorageManagerService.java关于framework层挂载的相关方法](#3.3%20StorageManagerService.java%E5%85%B3%E4%BA%8Eframework%E5%B1%82%E6%8C%82%E8%BD%BD%E7%9A%84%E7%9B%B8%E5%85%B3%E6%96%B9%E6%B3%95)


[3.4 系统属性控制sdcard和usb是否挂载的功能实现](#3.4%20%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E6%8E%A7%E5%88%B6sdcard%E5%92%8Cusb%E6%98%AF%E5%90%A6%E6%8C%82%E8%BD%BD%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)




---



## 1.概述


  在定制化产品开发中，对于sdcard和usb这些外挂设备的操作功能也是经常开发的功能，但是这款产品要求根据系统属性来是否挂载外设sdcard和usb,所以就需要通过了解设备的挂载流程然后就可以实现功能了


## 2.系统属性控制sdcard和usb是否挂载的功能实现核心代码



```
  frameworks\base\core\java\android\os\storage\DiskInfo.java
  frameworks\base\core\java\android\os\storage\VolumeInfo.java
  frameworks/base/services/core/java/com/android/server/StorageManagerService.java
```

## 3.系统属性控制sdcard和usb是否挂载的功能实现核心功能分析



在android系统中，关于内部存储和外部存储的相关信息的描述都是在  
 VolumeInfo.java和DiskInfo.java,DiskInfo.java的主要功能就是通过  
 isSd()和isUsb()这两个核心方法来判断当前设备是sdcard还是usb设备，  
 isSd()为true就是判断是否是sdcard,而 isUsb()为true就是判断是否是usb设备  
 而VolumeInfo.java的核心功能就是public File getPath() 和 File getInternalPath()  
 这两个方法来获取当前设备的路径，然后结合DiskInfo.java的方法来  
 看当前挂载的设备是否是usb设备



##   3.1 DiskInfo.java关于sdcard和usb设备属性的分析



```
   public class DiskInfo implements Parcelable {
    public static final String ACTION_DISK_SCANNED =
            "android.os.storage.action.DISK_SCANNED";
    public static final String EXTRA_DISK_ID =
            "android.os.storage.extra.DISK_ID";
    public static final String EXTRA_VOLUME_COUNT =
            "android.os.storage.extra.VOLUME_COUNT";

    public static final int FLAG_ADOPTABLE = 1 << 0;
    public static final int FLAG_DEFAULT_PRIMARY = 1 << 1;
    public static final int FLAG_SD = 1 << 2;
    public static final int FLAG_USB = 1 << 3;

    public final String id;
    @UnsupportedAppUsage
    public final int flags;
    @UnsupportedAppUsage
    public long size;
    @UnsupportedAppUsage
    public String label;
    /** Hacky; don't rely on this count */
    public int volumeCount;
    public String sysPath;

    public DiskInfo(String id, int flags) {
        this.id = Preconditions.checkNotNull(id);
        this.flags = flags;
    }

    @UnsupportedAppUsage(maxTargetSdk = Build.VERSION_CODES.P, trackingBug = 115609023)
    public DiskInfo(Parcel parcel) {
        id = parcel.readString();
        flags = parcel.readInt();
        size = parcel.readLong();
        label = parcel.readString();
        volumeCount = parcel.readInt();
        sysPath = parcel.readString();
    }
 
    // 判断是否是sdcard卡
    @UnsupportedAppUsage
    public boolean isSd() {
        return (flags & FLAG_SD) != 0;
    }

   // 判断是否是usb设备
    @UnsupportedAppUsage
    public boolean isUsb() {
        return (flags & FLAG_USB) != 0;
    }
```

在DiskInfo.java的上述代码中可以看到在这个类中可以通过相关方法来判断是USB还是sdcard,从


上述的方法中看到isSd()就是判断是否是sdcard,而 isUsb()就是判断是否是usb设备


## 3.2 VolumeInfo.java挂载外设相关属性的分析



```
    public class VolumeInfo implements Parcelable {
public VolumeInfo(String id, int type, DiskInfo disk, String partGuid) {
        this.id = Preconditions.checkNotNull(id);
        this.type = type; //VolumeInfo.TYPE_PUBLIC,VolumeInfo.TYPE_PRIVATE,VolumeInfo.TYPE_STUB
        this.disk = disk;
        this.partGuid = partGuid;
        /* SPRD: add for storage manage */
        this.linkName = "unknown";
    }

    /* SPRD: add for storage manage @{ */
    public VolumeInfo(String id, int type, DiskInfo disk, String partGuid, String linkName) {
        this.id = Preconditions.checkNotNull(id);
        this.type = type;
        this.disk = disk;
        this.partGuid = partGuid;
        this.linkName = linkName;
    }
    /* @} */


    @UnsupportedAppUsage
    public VolumeInfo(Parcel parcel) {
        id = parcel.readString();
        type = parcel.readInt();
        if (parcel.readInt() != 0) {
            disk = DiskInfo.CREATOR.createFromParcel(parcel);
        } else {
            disk = null;
        }
        partGuid = parcel.readString();
        mountFlags = parcel.readInt();
        mountUserId = parcel.readInt();
        state = parcel.readInt();
        fsType = parcel.readString();
        fsUuid = parcel.readString();
        fsLabel = parcel.readString();
        path = parcel.readString();
        internalPath = parcel.readString();
        /* SPRD: add for storage manage */
        linkName = parcel.readString();
    }
    
   // 挂载设备的路径
    @UnsupportedAppUsage
    public File getPath() {
        return (path != null) ? new File(path) : null;
    }

    @UnsupportedAppUsage
    public File getInternalPath() {
        return (internalPath != null) ? new File(internalPath) : null;
    }

....
}
```

在VolumeInfo上述的代码可以分析看出，VoluemeInfo主要就是挂载外设的相关参数属性 通过这个对象来调用DiskInfo的属性。然后通过DiskInfo的isUSB()和isSd()来区分是sdcard和usb设备 等等


##  3.3 StorageManagerService.java关于framework层挂载的相关方法


StorageManager 为Client ，MountService 是Server ，通过AIDL 进⾏进程间通信。  
 MountService 是⼀个Android Service ，由systemserver 启动  
 Android的文件系统等通常都保存在Nand Flash 中。


通常使用的Micro-SD卡的管理则是由卷守护进程(Volume Daemon ,vold)去完成的，  
 包括SD卡的插拔事件检测、挂载、卸载、格式化等。  
 我们 可以通过这个服务获取Android设备上的所有存储设备。  
 系统提供了 StorageManager 类，它有一个方法叫getVolumeList()，  
 这个方法的返回值是一个StorageVolume数组，StorageVolume类中封装了挂载路径，  
 挂载状态，以及是否可以移除等信息。




```
  class StorageManagerServiceHandler extends Handler {
        public StorageManagerServiceHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
.....
                case H_VOLUME_MOUNT: {// 关于挂载的相关消息处理
                    final VolumeInfo vol = (VolumeInfo) msg.obj;
                    if (isMountDisallowed(vol)) {
                        Slog.i(TAG, "Ignoring mount " + vol.getId() + " due to policy");
                        break;
                    }
                    try {
                        slogi(TAG, "Cmd send volume mount from handler " + vol.id + " "
                                + vol.mountFlags + " " + vol.mountUserId);
                        mVold.mount(vol.id, vol.mountFlags, vol.mountUserId);
                        slogi(TAG, "Cmd send volume mount from handler end " + vol.id + " "
                                + vol.mountFlags + " " + vol.mountUserId);
                    } catch (Exception e) {
                        Slog.wtf(TAG, e);
                    }
                    break;
                }
                case H_VOLUME_UNMOUNT: {// 卸载外设相关消息
                    final VolumeInfo vol = (VolumeInfo) msg.obj;
                    /* SPRD: add for remove user to result android system-server reboot
                     *@orig
                        unmount(vol.getId());
                    * @{ */
                    try{
                        unmount(vol);
                    } catch(Exception e) {
                        Slog.i(TAG, "unmount failed: " , e);
                    }
                    /* @} */
                    break;
                }
......

            }
        }
    }
```

在收到vold发送的挂载和卸载消息后调动挂载和卸载相关方法来实现usb和sdcard设备的挂载和卸载功能，接下来看下vold的相关挂载方法



```

private final IVoldListener mListener = new IVoldListener.Stub() {
        @Override
        public void onDiskCreated(String diskId, int flags) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onDiskCreated " + diskId + " " + flags);
                final String value = SystemProperties.get(StorageManager.PROP_ADOPTABLE);
                switch (value) {
                    case "force_on":
                        flags |= DiskInfo.FLAG_ADOPTABLE;
                        break;
                    case "force_off":
                        flags &= ~DiskInfo.FLAG_ADOPTABLE;
                        break;
                }
                mDisks.put(diskId, new DiskInfo(diskId, flags));
            }
        }

        @Override
        public void onDiskScanned(String diskId) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onDiskScanned " + diskId);
                final DiskInfo disk = mDisks.get(diskId);
                if (disk != null) {
                    onDiskScannedLocked(disk);
                }
            }
        }

        @Override
        public void onDiskMetadataChanged(String diskId, long sizeBytes, String label,
                String sysPath) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onDiskMetadataChanged " + diskId + " " +
                        sizeBytes + " " + label + " " + sysPath);
                final DiskInfo disk = mDisks.get(diskId);
                if (disk != null) {
                    disk.size = sizeBytes;
                    disk.label = label;
                    disk.sysPath = sysPath;
                }
            }
        }

        @Override
        public void onDiskDestroyed(String diskId) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onDiskDestroyed " + diskId);
                final DiskInfo disk = mDisks.remove(diskId);
                if (disk != null) {
                    mCallbacks.notifyDiskDestroyed(disk);
                }
            }
        }

        @Override
        public void onVolumeCreated(String volId, int type, String diskId, String partGuid) {
            synchronized (mLock) {
                final DiskInfo disk = mDisks.get(diskId);
                final VolumeInfo vol = new VolumeInfo(volId, type, disk, partGuid);
                mVolumes.put(volId, vol);
               // 有设备需要挂载时处理消息
                onVolumeCreatedLocked(vol);
            }
        }

        @Override
        public void onSprdVolumeCreated(String volId, int type, String diskId, String partGuid, String linkName) {
            synchronized (mLock) {
                final DiskInfo disk = mDisks.get(diskId);
                final VolumeInfo vol = new VolumeInfo(volId, type, disk, partGuid, linkName);
                mVolumes.put(volId, vol);
                onVolumeCreatedLocked(vol);
            }
        }

        @Override
        public void onVolumeStateChanged(String volId, int state) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onVolumeStateChanged " + volId + " " + state);
                final VolumeInfo vol = mVolumes.get(volId);
                if (vol != null) {
                    final int oldState = vol.state;
                    final int newState = state;
                    vol.state = newState;
                    onVolumeStateChangedLocked(vol, oldState, newState);
                }
            }
        }

        @Override
        public void onVolumeMetadataChanged(String volId, String fsType, String fsUuid,
                String fsLabel) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onVolumeMetadataChanged " + volId + " " + fsType
                        + " " + fsUuid + " " + fsLabel);
                final VolumeInfo vol = mVolumes.get(volId);
                if (vol != null) {
                    vol.fsType = fsType;
                    vol.fsUuid = fsUuid;
                    vol.fsLabel = fsLabel;
                }
            }
        }

        @Override
        public void onVolumePathChanged(String volId, String path) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onVolumePathChanged " + volId + " " + path);
                final VolumeInfo vol = mVolumes.get(volId);
                if (vol != null) {
                    vol.path = path;
                }
            }
        }

        @Override
        public void onVolumeInternalPathChanged(String volId, String internalPath) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onVolumeInternalPathChanged " + volId + " " + internalPath);
                final VolumeInfo vol = mVolumes.get(volId);
                if (vol != null) {
                    vol.internalPath = internalPath;
                }
            }
        }

        @Override
        public void onVolumeDestroyed(String volId) {
            synchronized (mLock) {
                slogi(TAG, "Cmd recv onVolumeDestroyed " + volId);
                mVolumes.remove(volId);
            }
        }
    };

@GuardedBy("mLock")
    private void onVolumeCreatedLocked(VolumeInfo vol) {
        if (mPmInternal.isOnlyCoreApps()) {
            Slog.d(TAG, "System booted in core-only mode; ignoring volume " + vol.getId());
            return;
        }
        /* SPRD: add for storage debug @{ */
        Slog.v(TAG, "onVolumeCreatedLocked{"+vol+"} mPrimaryStorageUuid is " + mPrimaryStorageUuid);
        /* @} */
        if (vol.type == VolumeInfo.TYPE_EMULATED) {
            final StorageManager storage = mContext.getSystemService(StorageManager.class);
            final VolumeInfo privateVol = storage.findPrivateForEmulated(vol);

            if (Objects.equals(StorageManager.UUID_PRIVATE_INTERNAL, mPrimaryStorageUuid)
                    && VolumeInfo.ID_PRIVATE_INTERNAL.equals(privateVol.id)) {
                Slog.v(TAG, "Found primary storage at " + vol);
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_PRIMARY;
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_VISIBLE;
                mHandler.obtainMessage(H_VOLUME_MOUNT, vol).sendToTarget();

            } else if (Objects.equals(privateVol.fsUuid, mPrimaryStorageUuid)) {
                Slog.v(TAG, "Found primary storage at " + vol);
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_PRIMARY;
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_VISIBLE;
                mHandler.obtainMessage(H_VOLUME_MOUNT, vol).sendToTarget();
            }

        } else if (vol.type == VolumeInfo.TYPE_PUBLIC) {
            // TODO: only look at first public partition
            if (Objects.equals(StorageManager.UUID_PRIMARY_PHYSICAL, mPrimaryStorageUuid)
                    && vol.disk.isDefaultPrimary()) {
                Slog.v(TAG, "Found primary storage at " + vol);
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_PRIMARY;
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_VISIBLE;
            }

            // Adoptable public disks are visible to apps, since they meet
            // public API requirement of being in a stable location.
            //if (vol.disk.isAdoptable()) {
                vol.mountFlags |= VolumeInfo.MOUNT_FLAG_VISIBLE;
            //}

            vol.mountUserId = mCurrentUserId;
            mHandler.obtainMessage(H_VOLUME_MOUNT, vol).sendToTarget();

        } else if (vol.type == VolumeInfo.TYPE_PRIVATE) {
            mHandler.obtainMessage(H_VOLUME_MOUNT, vol).sendToTarget();

        } else if (vol.type == VolumeInfo.TYPE_STUB) {
            vol.mountUserId = mCurrentUserId;
            mHandler.obtainMessage(H_VOLUME_MOUNT, vol).sendToTarget();
        } else {
            Slog.d(TAG, "Skipping automatic mounting of " + vol);
        }
    }
```

在上述的代码中可以看出 IVoldListener通过binder通讯来获取挂载的相关信息


最终的挂载就是在 isMountDisallowed(VolumeInfo vol)中判断是否需要挂载外设设备



```
/**
     * Decide if volume is mountable per device policies.
     */
    private boolean isMountDisallowed(VolumeInfo vol) {
        UserManager userManager = mContext.getSystemService(UserManager.class);

        boolean isUsbRestricted = false;
        if (vol.disk != null && vol.disk.isUsb()) {
            isUsbRestricted = userManager.hasUserRestriction(UserManager.DISALLOW_USB_FILE_TRANSFER,
                    Binder.getCallingUserHandle());
        }

        boolean isTypeRestricted = false;
        if (vol.type == VolumeInfo.TYPE_PUBLIC || vol.type == VolumeInfo.TYPE_PRIVATE
                || vol.type == VolumeInfo.TYPE_STUB) {
            isTypeRestricted = userManager
                    .hasUserRestriction(UserManager.DISALLOW_MOUNT_PHYSICAL_MEDIA,
                    Binder.getCallingUserHandle());
        }

        return isUsbRestricted || isTypeRestricted;
    }

```

所以最终可以在这里实现功能 具体修改如下:


##  3.4 系统属性控制sdcard和usb是否挂载的功能实现



```
 /**
     * Decide if volume is mountable per device policies.
     */
    private boolean isMountDisallowed(VolumeInfo vol) {
     // add core start
		boolean otg=(Settings.Global.getInt(mContext.getContentResolver(),"roco_disable_otg", 0) == 0);
		android.util.Log.e("StorageManager","otg:"+otg+"--path:"+vol.getPath()+"--vol.type:"+vol.type+"--vol:"+vol);
		if(otg && vol.disk != null/*vol.type==0*/)return true;// 通过 vol.disk判断是否是usb还是sdcard 当不为空时，可以判断是外设设备
  //add core end


        UserManager userManager = mContext.getSystemService(UserManager.class);

        boolean isUsbRestricted = false;
        if (vol.disk != null && vol.disk.isUsb()) {
            isUsbRestricted = userManager.hasUserRestriction(UserManager.DISALLOW_USB_FILE_TRANSFER,
                    Binder.getCallingUserHandle());
        }

        boolean isTypeRestricted = false;
        if (vol.type == VolumeInfo.TYPE_PUBLIC || vol.type == VolumeInfo.TYPE_PRIVATE
                || vol.type == VolumeInfo.TYPE_STUB) {
            isTypeRestricted = userManager
                    .hasUserRestriction(UserManager.DISALLOW_MOUNT_PHYSICAL_MEDIA,
                    Binder.getCallingUserHandle());
        }

        return isUsbRestricted || isTypeRestricted;
    }
```



