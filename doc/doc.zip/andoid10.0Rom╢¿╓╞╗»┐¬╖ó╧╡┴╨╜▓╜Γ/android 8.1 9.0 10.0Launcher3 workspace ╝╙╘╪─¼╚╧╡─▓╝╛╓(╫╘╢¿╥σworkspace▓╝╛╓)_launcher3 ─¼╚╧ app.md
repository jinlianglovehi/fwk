






在Launcher3定制化开发中，对桌面布局进行调整修改也是常有的工作量，那么就首先要熟悉WorkSpace加载流程  
 下面就来分析下Launcher3加载默认布局的  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/9f23afdf6615430ebcaea7a6667df8bf.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70#pic_center)


本文主要分析Launcher3 如何加载默认的app icon,hotseat,folder文件夹等等


1、 launcher首先会初始化设备配置属性，比如加载哪些图标，hotseat, folder文件夹，图标布局n \* n等等，这些配置定义在device\_profiles.xml 中，device\_profiles.xml 会关联到default\_workspace\_n\*n.xml，  
 2、 在LoaderTask.java 的loadworkspace函数中会去load默认的布局，其实就是去加载xml中初始化后的配置


第一部分：InvariantDeviceProfile初始化


Launcher在oncreate的时候会通过单例初始化LauncherAppState类


LauncherAppState app = LauncherAppState.getInstance(this);


在LauncherAppState的构造中会初始化InvariantDeviceProfile，先看一下InvariantDeviceProfile构造函数，



```
public InvariantDeviceProfile(Context context) {
		......
        // This guarantees that width < height
        minWidthDps = Utilities.dpiFromPx(Math.min(smallestSize.x, smallestSize.y), dm);
        minHeightDps = Utilities.dpiFromPx(Math.min(largestSize.x, largestSize.y), dm);
        
        ArrayList<InvariantDeviceProfile> closestProfiles = findClosestDeviceProfiles(
                minWidthDps, minHeightDps, getPredefinedDeviceProfiles(context));
                
        InvariantDeviceProfile interpolatedDeviceProfileOut =
                invDistWeightedInterpolate(minWidthDps,  minHeightDps, closestProfiles);

        InvariantDeviceProfile closestProfile = closestProfiles.get(0);
        numRows = closestProfile.numRows;
        numColumns = closestProfile.numColumns;
        numHotseatIcons = closestProfile.numHotseatIcons;
        //这个布局就是后面load default favorites加载所需要的布局id
        defaultLayoutId = closestProfile.defaultLayoutId;
        Log.d("InvariantDeviceProfile", "InvariantDeviceProfile: defaultLayoutId: " + defaultLayoutId);
        demoModeLayoutId = closestProfile.demoModeLayoutId;
        numFolderRows = closestProfile.numFolderRows;
        numFolderColumns = closestProfile.numFolderColumns;
       ......

```

通过getPredefinedDeviceProfiles 去load device\_profiles.xml中定义的所有profile，放到List中，然后通过findClosestDeviceProfiles从 list中找出最接近的profile。



```
 /**
     * Returns the closest device profiles ordered by closeness to the specified width and height
     */
    // Package private visibility for testing.
    ArrayList<InvariantDeviceProfile> findClosestDeviceProfiles(
            final float width, final float height, ArrayList<InvariantDeviceProfile> points) {

        // Sort the profiles by their closeness to the dimensions
        ArrayList<InvariantDeviceProfile> pointsByNearness = points;
        Collections.sort(pointsByNearness, new Comparator<InvariantDeviceProfile>() {
            public int compare(InvariantDeviceProfile a, InvariantDeviceProfile b) {
                return Float.compare(dist(width, height, a.minWidthDps, a.minHeightDps),
                        dist(width, height, b.minWidthDps, b.minHeightDps));
            }
        });
        return pointsByNearness;
    }

```

2、LoadWorkspace 加载默认的favorites  
 从上图可以看出 在LauncheModer中bindWorkspace（）绑定数据时  
 会调用LauncherProvider. loadDefaultFavoritesIfNecessary();来加载默认的数据


通过ContentResolver的call方法调用到LauncherProvider去实现，看一下launcherprovider call实现,



```
 @Override
    public Bundle call(String method, final String arg, final Bundle extras) {

        createDbIfNotExists();

        switch (method) {
             ......
            case LauncherSettings.Settings.METHOD_LOAD_DEFAULT_FAVORITES: {
                loadDefaultFavoritesIfNecessary();
                return null;
            }
            ......
       

```

loadDefaultFavoritesIfNecessary()这个流程就是找到之前已经初始化好的device profile，


另外，loadDefaultFavoritesIfNecessary() 通过判断if (sp.getBoolean(EMPTY\_DATABASE\_CREATED, false)) 是否要加载默认的workspace，一般情况下，只会加载一次，除非删除launcher.db数据库，EMPTY\_DATABASE\_CREATED这个key在db创建的时候会设为true，一旦加载default workspace完成，则会remove EMPTY\_DATABASE\_CREATED key。



```
 /**
     * Loads the default workspace based on the following priority scheme:
     * 1) From the app restrictions
     * 2) From a package provided by play store
     * 3) From a partner configuration APK, already in the system image
     * 4) The default configuration for the particular device
     */
    synchronized private void loadDefaultFavoritesIfNecessary() {

        if (getFlagEmptyDbCreated(getContext(), mOpenHelper.getDatabaseName())) {
            Log.d(TAG, "loading default workspace");

            AppWidgetHost widgetHost = mOpenHelper.newLauncherWidgetHost();
            AutoInstallsLayout loader = createWorkspaceLoaderFromAppRestriction(widgetHost);
            if (loader == null) {
                loader = AutoInstallsLayout.get(getContext(), widgetHost, mOpenHelper);
            }
            if (loader == null) {
                final Partner partner = Partner.get(getContext().getPackageManager());
                if (partner != null && partner.hasDefaultLayout()) {
                    final Resources partnerRes = partner.getResources();
                    int workspaceResId = partnerRes.getIdentifier(Partner.RES_DEFAULT_LAYOUT,
                            "xml", partner.getPackageName());
                    if (workspaceResId != 0) {
                        loader = new DefaultLayoutParser(getContext(), widgetHost,
                                mOpenHelper, partnerRes, workspaceResId);
                    }
                }
            }

            final boolean usingExternallyProvidedLayout = loader != null;
            if (loader == null) {
                loader = getDefaultLayoutParser(widgetHost);
            }

            // There might be some partially restored DB items, due to buggy restore logic in
            // previous versions of launcher.
            mOpenHelper.createEmptyDB(mOpenHelper.getWritableDatabase());
            // Populate favorites table with initial favorites
            if ((mOpenHelper.loadFavorites(mOpenHelper.getWritableDatabase(), loader) <= 0)
 && usingExternallyProvidedLayout) {
 // Unable to load external layout. Cleanup and load the internal layout.
 mOpenHelper.createEmptyDB(mOpenHelper.getWritableDatabase());
                mOpenHelper.loadFavorites(mOpenHelper.getWritableDatabase(),
                        getDefaultLayoutParser(widgetHost));
            }
            clearFlagEmptyDbCreated(getContext(), mOpenHelper.getDatabaseName());
        }
    }

```

从 int workspaceResId = partnerRes.getIdentifier(Partner.RES\_DEFAULT\_LAYOUT,  
 “xml”, partner.getPackageName());  
 可以看出第一次先加载默认的布局 然后看Partner.RES\_DEFAULT\_LAYOUT 为partner\_default\_layout  
 所以默认的布局就为partner\_default\_layout.xml  
 在res/xml下找到partner\_default\_layout.xml  
 添加需要的控件就可以自定义默认桌面布局  
 然后编译就可以了  
 如下:



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2009 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<favorites xmlns:launcher="http://schemas.android.com/apk/res-auto/com.android.launcher3">

// 时钟小部件
    <appwidget
    launcher:packageName="com.android.deskclock"
    launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"
    launcher:screen="0"
    launcher:x="1"
    launcher:y="1"
    launcher:spanX="4"
    launcher:spanY="2" 
  />

    <!-- Hotseat (We use the screen as the position of the item in the hotseat) -->
    <!-- Dialer, Messaging, Browser, Camera -->

    <resolve
        launcher:container="-101"
        launcher:screen="0"
        launcher:x="0"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_MAPS;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_MUSIC;end" />
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="1"
        launcher:x="1"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_GALLERY;end" />
        <favorite launcher:uri="#Intent;type=images/\*;end" />
    </resolve>

    <favorite
        launcher:container="-101"
        launcher:screen="2"
        launcher:x="2"
        launcher:y="0" 
        launcher:packageName="com.android.documentsui"
        launcher:className="com.android.documentsui.LauncherActivity"/>


    <resolve
        launcher:container="-101"
        launcher:screen="3"
        launcher:x="3"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.media.action.STILL\_IMAGE\_CAMERA;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA\_BUTTON;end" />
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="4"
        launcher:x="4"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end"/>
    </resolve>

    <!-- <resolve
        launcher:container="-101"
        launcher:screen="3"
        launcher:x="3"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.media.action.STILL\_IMAGE\_CAMERA;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA\_BUTTON;end" />
    </resolve> -->

    <!-- Bottom row -->
    <!-- Email, Gallery, Music, Settings -->
    <!-- <resolve
        launcher:screen="0"
        launcher:x="0"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_EMAIL;end" />
        <favorite launcher:uri="mailto:" />
    </resolve>

    <resolve
        launcher:screen="0"
        launcher:x="1"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_GALLERY;end" />
        <favorite launcher:uri="#Intent;type=images/\*;end" />
    </resolve>

    <resolve
        launcher:screen="0"
        launcher:x="-2"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP\_MUSIC;end" />
    </resolve>

    <resolve
        launcher:screen="0"
        launcher:x="-1"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end" />
    </resolve> -->

    <favorite
        launcher:screen="1"
        launcher:x="0"
        launcher:y="0" 
        launcher:packageName="com.android.dialer"
        launcher:className="com.android.dialer.main.impl.MainActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="1"
        launcher:y="0" 
        launcher:packageName="com.android.messaging"
        launcher:className="com.android.messaging.ui.conversationlist.ConversationListActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="2"
        launcher:y="0" 
        launcher:packageName="com.android.contacts"
        launcher:className="com.android.contacts.activities.PeopleActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="3"
        launcher:y="0" 
        launcher:packageName="com.android.email"
        launcher:className="com.android.email.activity.Welcome"
        />
    <favorite
        launcher:screen="1"
        launcher:x="4"
        launcher:y="0" 
        launcher:packageName="com.android.chrome"
        launcher:className="com.google.android.apps.chrome.Main"
        />
    <favorite
        launcher:screen="1"
        launcher:x="5"
        launcher:y="0" 
        launcher:packageName="com.android.soundrecorder"
        launcher:className="com.sprd.soundrecorder.RecorderActivity"
        />

    <favorite
        launcher:screen="1"
        launcher:x="0"
        launcher:y="1" 
        launcher:packageName="com.android.calendar"
        launcher:className="com.android.calendar.AllInOneActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="1"
        launcher:y="1" 
        launcher:packageName="com.android.deskclock"
        launcher:className="com.android.deskclock.DeskClock"
        />
    <favorite
        launcher:screen="1"
        launcher:x="2"
        launcher:y="1" 
        launcher:packageName="com.android.calculator2"
        launcher:className="com.android.calculator2.Calculator"
        />
    <favorite
        launcher:screen="1"
        launcher:x="3"
        launcher:y="1" 
        launcher:packageName="com.android.fmradio"
        launcher:className="com.android.fmradio.FmMainActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="4"
        launcher:y="1" 
        launcher:packageName="com.android.quicksearchbox"
        launcher:className="com.android.quicksearchbox.SearchActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="5"
        launcher:y="1" 
        launcher:packageName="com.tencent.android.qqdownloader"
        launcher:className="com.tencent.pangu.link.SplashActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="0"
        launcher:y="2" 
        launcher:packageName="com.sprd.sprdnote"
        launcher:className="com.sprd.sprdnote.widget.NoteAppWidgetProvider"
        />
    <favorite
        launcher:screen="1"
        launcher:x="1"
        launcher:y="2" 
        launcher:packageName="com.android.gallery3d"
        launcher:className="com.sprd.gallery3d.app.NewVideoActivity"
        />
    <favorite
        launcher:screen="1"
        launcher:x="2"
        launcher:y="2" 
        launcher:packageName="com.android.dialer"
        launcher:className="com.android.dialer.app.calllog.CallLogActivity"
        />

</favorites>

```

布局讲解：



```
<appwidget　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　 //插件
    launcher:className="de.dnsproject.clock\_widget\_main.Clock1AppWidgetProvider"  //该应用的类
    launcher:packageName="de.dnsproject.clock\_widget\_main"   　　　　　　　　      //该应用的包名
    launcher:screen="1"             　　　　　　　　　　　　　　　　　　//第1屏,0-4屏共5屏
    launcher:x="2"                      　　　　　　　　　　　　　　　 //图标X位置,左上角第一个为0,向左递增,0-4共5个
    launcher:y="1"                                                 //图标Y位置,左上角第一个为0,向下递增,0-2共3个
    launcher:spanX="3"                                             //在x方向上所占格数
    launcher:spanY="2" />                                          //在y方向上所占格数




    快捷方式说明
    <favorite 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　  //程序快捷键属性标签
        launcher:className="com.apical.radio.radioMainActivity"    　//该应用的类，点击图标时，需要启动的类
        launcher:packageName="com.apical.radio"          　　　   　　//该应用的包名
        launcher:screen="1"           　　　　　　　　　　　　　　　　　 //第1屏,0-4屏共5屏
        launcher:x="0"                   　　　　　　　　　　　　　　　 //图标X位置,左上角第一个为0,向左递增,0-4共5个
        launcher:y="0"            　　　　　　　　　　　　　　　　　　　//图标Y位置,左上角第一个为0,向下递增,0-2共3个
    />
launcher:className="com.apical.radio.radioMainActivity"    　//该应用的类，点击图标时，需要启动的类
launcher:packageName="com.apical.radio"          　　　   　　//该应用的包名
launcher:screen="1"           　　　　　　　　　　　　　　　　　 //第1屏,0-4屏共5屏
launcher:x="0"                   　　　　　　　　　　　　　　　 //图标X位置,左上角第一个为0,向右递增,0-4共5个
l0auncher:y="0"            　　　　　　　　　　　　　　　　　　　//图标Y位置,左上角第一个为0,向下递增,0-2共3个
/>


//桌面Widget的标签
launcher:className="de.dnsproject.clock\_widget\_main.Clock1AppWidgetProvider"  //该应用的类
launcher:packageName="de.dnsproject.clock\_widget\_main"   　　　　　　　　      //该应用的包名
launcher:screen="1"             　　　　　　　　　　　　　　　　　　//第1屏,0-4屏共5屏
launcher:x="2"                      　　　　　　　　　　　　　　　 //图标X位置,左上角第一个为0,向左递增,0-4共5个
launcher:y="1"                                                 //图标Y位置,左上角第一个为0,向下递增,0-2共3个
launcher:spanX="3"                                             //在x方向上所占格数
launcher:spanY="2" />                                          //在y方向上所占格数

launcher:screen="1"            　  //第2屏
launcher:x="0"                    //图标X位置
launcher:y="1"/>                  //图标Y位置

        launcher:container="-100"
        launcher:screen="1"
        launcher:title="@string/accessibility\_all\_apps\_button"
        launcher:x="0"         launcher:y="3" >        
            launcher:container="1"
            launcher:className="com.android.settings.Settings"               launcher:packageName="com.android.settings"
            launcher:className="com.kylindev.henengptt.app.LoginActivity"
            launcher:screen="0"             launcher:x="0"             launcher:y="0" />        
       
            launcher:packageName="com.kylindev.henengptt"             launcher:screen="0"             launcher:x="1"             launcher:y="0" />
            launcher:x="2"
            launcher:className="com.android.deskclock.DeskClock"             launcher:container="1"             launcher:packageName="com.android.deskclock"             launcher:screen="0"
   
            launcher:y="0" />

//default_workspace.xml中，支持的标签有：
favorite:应用程序快捷方式。
shortcut:链接，如网址，本地磁盘路径等。
search:搜索框。
clock:桌面上的钟表Widget

//支持的属性有：
launcher:title:图标下面的文字，目前只支持引用，不能直接书写字符串;
launcher:icon:图标引用;
launcher:uri:链接地址,链接网址用的，使用shortcut标签就可以定义一个超链接，打开某个网址。
launcher:packageName:应用程序的包名;
launcher:className:应用程序的启动类名;
launcher:screen:图标所在的屏幕编号;
launcher:x:图标在横向排列上的序号;
launcher:y:图标在纵向排列上的序号;

```




