






在android 7.0以后引入了FallbackHome机制，在系统解锁之前会首选进入FallbackHome界面，等收到解锁广播以后在进入默认Launcher  
 这就是在进入launcher之前经常会看到 Android正在启动 的系统弹窗 客户需求去掉 Android 正在启动 提示文字 要求直接进入Launcher


FallbackHome  
 那FallbackHome是什么呢？ FallbackHome是原生setting的一个activity，且配置了DirectBoot mode。launcher启动的时候会先启动到这个界面，用户解锁后，才会调用finish，结束该界面，从而进入到真正的launcher界面。app  
 若未解锁就等待ACTION\_USER\_UNLOCKED广播后再去启动Launcher。非DirectBoot模式下的launcher耗时4s就是在等待finishBooting后的系统广播ACTION\_USER\_UNLOCKED。async  
 FallbackHome就是应DirectBoot功能而新增的一个页面


具体功能实现:  
 1.延长开机动画 在解锁后直接进去Launcher  
 在WindowManagerService.java中，延时开机动画  
 路径:frameworks/base/services/core/java/com/android/server/wm/WindowManagerService.java



```
private void performEnableScreen() {
synchronized (mGlobalLock) {
if (DEBUG_BOOT) Slog.i(TAG_WM, "performEnableScreen: mDisplayEnabled=" + mDisplayEnabled
+ " mForceDisplayEnabled=" + mForceDisplayEnabled
+ " mShowingBootMessages=" + mShowingBootMessages
+ " mSystemBooted=" + mSystemBooted
+ " mOnlyCore=" + mOnlyCore,
new RuntimeException("here").fillInStackTrace());
if (mDisplayEnabled) {
return;
}
if (!mSystemBooted && !mShowingBootMessages) {
return;
}
if (!mShowingBootMessages && !mPolicy.canDismissBootAnimation()) {
return;
}
// Don't enable the screen until all existing windows have been drawn.
if (!mForceDisplayEnabled
// TODO(multidisplay): Expand to all displays?
&& getDefaultDisplayContentLocked().checkWaitingForWindows()) {
return;
}

// add core start 判断是否有设置锁屏密码来看是否执行结束开机动画的操作
LockPatternUtils lockPatternUtils = new LockPatternUtils(mContext);
if(lockPatternUtils.isSecure(mCurrentUserId)){
if (!mBootAnimationStopped) {
Trace.asyncTraceBegin(TRACE_TAG_WINDOW_MANAGER, "Stop bootanim", 0);
// stop boot animation
// formerly we would just kill the process, but we now ask it to exit so it
// can choose where to stop the animation.
SystemProperties.set("service.bootanim.exit", "1");
mBootAnimationStopped = true;
}
if (!mForceDisplayEnabled && !checkBootAnimationCompleteLocked()) {
if (DEBUG_BOOT) Slog.i(TAG_WM, "performEnableScreen: Waiting for anim complete");
return;
}
try {
IBinder surfaceFlinger = ServiceManager.getService("SurfaceFlinger");
if (surfaceFlinger != null) {
Slog.i(TAG_WM, "\*\*\*\*\*\*\* TELLING SURFACE FLINGER WE ARE BOOTED!");
Parcel data = Parcel.obtain();
data.writeInterfaceToken("android.ui.ISurfaceComposer");
surfaceFlinger.transact(IBinder.FIRST_CALL_TRANSACTION, // BOOT_FINISHED
data, null, 0);
data.recycle();
}
} catch (RemoteException ex) {
Slog.e(TAG_WM, "Boot completed: SurfaceFlinger is dead!");
}
}
// add core end

EventLog.writeEvent(EventLogTags.WM_BOOT_ANIMATION_DONE, SystemClock.uptimeMillis());
Trace.asyncTraceEnd(TRACE_TAG_WINDOW_MANAGER, "Stop bootanim", 0);
mDisplayEnabled = true;
if (DEBUG_SCREEN_ON || DEBUG_BOOT) Slog.i(TAG_WM, "\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\* ENABLING SCREEN!");
// Enable input dispatch.
mInputManagerCallback.setEventDispatchingLw(mEventDispatchingEnabled);
}
try {
mActivityManager.bootAnimationComplete();
} catch (RemoteException e) {
}
mPolicy.enableScreenAfterBoot();
// Make sure the last requested orientation has been applied.
updateRotationUnchecked(false, false);
}


private boolean checkBootAnimationCompleteLocked() {
if (SystemService.isRunning(BOOT_ANIMATION_SERVICE)) {
mH.removeMessages(H.CHECK_IF_BOOT_ANIMATION_FINISHED);
mH.sendEmptyMessageDelayed(H.CHECK_IF_BOOT_ANIMATION_FINISHED,
BOOT_ANIMATION_POLL_INTERVAL);
if (DEBUG_BOOT) Slog.i(TAG_WM, "checkBootAnimationComplete: Waiting for anim complete");
return false;
}
if (DEBUG_BOOT) Slog.i(TAG_WM, "checkBootAnimationComplete: Animation complete!");
return true;
}

在这里处理播放完开机动画后是否退出开机动画
所以注释掉

if (!mBootAnimationStopped) {
Trace.asyncTraceBegin(TRACE_TAG_WINDOW_MANAGER, "Stop bootanim", 0);
// stop boot animation
// formerly we would just kill the process, but we now ask it to exit so it
// can choose where to stop the animation.
SystemProperties.set("service.bootanim.exit", "1");
mBootAnimationStopped = true;
}
if (!mForceDisplayEnabled && !checkBootAnimationCompleteLocked()) {
if (DEBUG_BOOT) Slog.i(TAG_WM, "performEnableScreen: Waiting for anim complete");
return;
}
try {
IBinder surfaceFlinger = ServiceManager.getService("SurfaceFlinger");
if (surfaceFlinger != null) {
Slog.i(TAG_WM, "\*\*\*\*\*\*\* TELLING SURFACE FLINGER WE ARE BOOTED!");
Parcel data = Parcel.obtain();
data.writeInterfaceToken("android.ui.ISurfaceComposer");
surfaceFlinger.transact(IBinder.FIRST_CALL_TRANSACTION, // BOOT_FINISHED
data, null, 0);
data.recycle();
}
} catch (RemoteException ex) {
Slog.e(TAG_WM, "Boot completed: SurfaceFlinger is dead!");
}

```

2. 解锁结束后退出开机动画  
 在ActivityRecord中onWindowsDrawn( 退出动画 开启系统手势触摸功能  
 路径:frameworks/base/services/core/java/com/android/server/wm/ActivityRecord.java



```
public void onWindowsDrawn(boolean drawn, long timestamp) {
     synchronized (mAtmService.mGlobalLock) {
         mDrawn = drawn;
         if (!drawn) {
             return;
         }
         final WindowingModeTransitionInfoSnapshot info = mStackSupervisor
                 .getActivityMetricsLogger().notifyWindowsDrawn(getWindowingMode(), timestamp);
         final int windowsDrawnDelayMs = info != null ? info.windowsDrawnDelayMs : INVALID_DELAY;
         final @LaunchState int launchState = info != null ? info.getLaunchState() : -1;
         mStackSupervisor.reportActivityLaunchedLocked(false /* timeout */, this,
                 windowsDrawnDelayMs, launchState);
         mStackSupervisor.stopWaitingForActivityVisible(this);
         finishLaunchTickingLocked();
         if (task != null) {
             task.hasBeenVisible = true;
         }
         //modify for performance begin
         Bundle b = new Bundle();
         b.putLong(ProcessInfo.KEY_LAUNCH_TIME, (long)windowsDrawnDelayMs);
         b.putBoolean(ProcessInfo.KEY_FULLSCREEN, (task != null && task.mFullscreen));
         mAtmService.notifyActivityStateChange(this.intent, ProcessInfo.ACTIVITY_STATE_LAUNCHDONE, b);
         //modify for performance end
     }
     
     // add core start
     if (isHomeIntent(intent) && shortComponentName != null && !shortComponentName.contains("FallbackHome")) {
         SystemProperties.set("service.bootanim.exit", "1");
         android.util.Log.e("ActivityRecord","real home....." + shortComponentName);
try {
             IBinder surfaceFlinger = ServiceManager.getService("SurfaceFlinger");
             if (surfaceFlinger != null) {
                 Slog.i(TAG_WM, "\*\*\*\*\*\*\* TELLING SURFACE FLINGER WE ARE BOOTED!");
                 Parcel data = Parcel.obtain();
                 data.writeInterfaceToken("android.ui.ISurfaceComposer");
                 surfaceFlinger.transact(IBinder.FIRST_CALL_TRANSACTION, // BOOT_FINISHED
                         data, null, 0);
                 data.recycle();
             }
         } catch (RemoteException ex) {
             Slog.e(TAG, "Boot completed: SurfaceFlinger is dead!");
         }
     }
     // add code end
 }

```

在这里判断不是FallbackHome时 退出动画 增加SufaceFilnger功能  
 然后编译验证就可以直接进入默认Launcher了





