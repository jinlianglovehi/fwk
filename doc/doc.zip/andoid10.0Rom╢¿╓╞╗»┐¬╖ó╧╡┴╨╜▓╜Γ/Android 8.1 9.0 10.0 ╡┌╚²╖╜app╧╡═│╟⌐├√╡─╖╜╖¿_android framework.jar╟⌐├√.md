






在进行系统开发过程中，跟客户的app进行系统签名，也是常有的一项工作，改怎么签名呢


第一步: app 添加系统UID属性  
 AndroidManifest.xml 中添加android:sharedUserId=“android.uid.system”



```
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:sharedUserId="android.uid.system"
    package="com.pne.funcation">

```

第二步：在编译系统源码的目录下 添加编译文件夹signal放系统签名所需要的jar和apk  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/9c3e15e720f747c3aefb8856235632d2.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_7,color_FFFFFF,t_70,g_se,x_16#pic_center)


1、在Android系统源码中的\build\target\product\security目录下找到 platform.x509.pem 和platform.pk8两个文件；


2、在out/host/Linux-x86/framework目录下找到signapk.jar文件


把platform.x509.pem platform.pk8 signapk.jar 和 要签名的app 拷贝到signal 文件夹下


然后cd 到signal 下  
 java -Djava.library.path=. -jar signapk.jar platform.x509.pem platform.pk8 Function.apk Function\_sign.apk


Function.apk 为要签名的apk Function\_sign.apk 是签名后的apk


执行此命令后 发现抛异常



```
Exception in thread "main" java.lang.UnsatisfiedLinkError: no conscrypt_openjdk_jni-linux-x86_64 in java.library.path
        at java.base/java.lang.ClassLoader.loadLibrary(ClassLoader.java:2541)
        at java.base/java.lang.Runtime.loadLibrary0(Runtime.java:873)
        at java.base/java.lang.System.loadLibrary(System.java:1857)
        at org.conscrypt.NativeLibraryUtil.loadLibrary(NativeLibraryUtil.java:54)
        at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
        at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
        at java.base/java.lang.reflect.Method.invoke(Method.java:564)
        at org.conscrypt.NativeLibraryLoader$1.run(NativeLibraryLoader.java:297)
        at org.conscrypt.NativeLibraryLoader$1.run(NativeLibraryLoader.java:289)
        at java.base/java.security.AccessController.doPrivileged(Native Method)
        at org.conscrypt.NativeLibraryLoader.loadLibraryFromHelperClassloader(NativeLibraryLoader.java:289)
        at org.conscrypt.NativeLibraryLoader.loadLibrary(NativeLibraryLoader.java:262)
        at org.conscrypt.NativeLibraryLoader.load(NativeLibraryLoader.java:162)
        at org.conscrypt.NativeLibraryLoader.loadFirstAvailable(NativeLibraryLoader.java:106)
        at org.conscrypt.NativeCryptoJni.init(NativeCryptoJni.java:50)
        at org.conscrypt.NativeCrypto.<clinit>(NativeCrypto.java:63)
        at org.conscrypt.OpenSSLProvider.<init>(OpenSSLProvider.java:58)
        at org.conscrypt.OpenSSLProvider.<init>(OpenSSLProvider.java:51)
        at org.conscrypt.OpenSSLProvider.<init>(OpenSSLProvider.java:47)
        at com.android.signapk.SignApk.main(SignApk.java:1008)
        Suppressed: java.lang.UnsatisfiedLinkError: no conscrypt_openjdk_jni-linux-x86_64 in java.library.path
                at java.base/java.lang.ClassLoader.loadLibrary(ClassLoader.java:2541)
                at java.base/java.lang.Runtime.loadLibrary0(Runtime.java:873)
                at java.base/java.lang.System.loadLibrary(System.java:1857)
                at org.conscrypt.NativeLibraryUtil.loadLibrary(NativeLibraryUtil.java:54)
                at org.conscrypt.NativeLibraryLoader.loadLibraryFromCurrentClassloader(NativeLibraryLoader.java:318)
                at org.conscrypt.NativeLibraryLoader.loadLibrary(NativeLibraryLoader.java:273)
                ... 8 more
        Suppressed: java.lang.UnsatisfiedLinkError: no conscrypt_openjdk_jni in java.library.path
                ... 21 more
        Suppressed: java.lang.UnsatisfiedLinkError: no conscrypt_openjdk_jni in java.library.path
                at java.base/java.lang.ClassLoader.loadLibrary(ClassLoader.java:2541)
                at java.base/java.lang.Runtime.loadLibrary0(Runtime.java:873)
                at java.base/java.lang.System.loadLibrary(System.java:1857)
                at org.conscrypt.NativeLibraryUtil.loadLibrary(NativeLibraryUtil.java:54)
                at org.conscrypt.NativeLibraryLoader.loadLibraryFromCurrentClassloader(NativeLibraryLoader.java:318)
                at org.conscrypt.NativeLibraryLoader.loadLibrary(NativeLibraryLoader.java:273)
                ... 8 more
        Suppressed: java.lang.UnsatisfiedLinkError: no conscrypt in java.library.path
                ... 21 more
        Suppressed: java.lang.UnsatisfiedLinkError: no conscrypt in java.library.path
                at java.base/java.lang.ClassLoader.loadLibrary(ClassLoader.java:2541)
                at java.base/java.lang.Runtime.loadLibrary0(Runtime.java:873)
                at java.base/java.lang.System.loadLibrary(System.java:1857)
                at org.conscrypt.NativeLibraryUtil.loadLibrary(NativeLibraryUtil.java:54)
                at org.conscrypt.NativeLibraryLoader.loadLibraryFromCurrentClassloader(NativeLibraryLoader.java:318)
                at org.conscrypt.NativeLibraryLoader.loadLibrary(NativeLibraryLoader.java:273)
                ... 8 more

```

原来是由于 缺少libconscrypt\_openjdk\_jni.so 导致抛异常


解决办法 ：  
 把 out/soong/host/Linux-x86/lib64/libconscrypt\_openjdk\_jni.so  
 下的/libconscrypt\_openjdk\_jni.so 拷贝到 signal 目录下


然后在执行 java -Djava.library.path=. -jar signapk.jar platform.x509.pem platform.pk8 Function.apk Function\_sign.apk  
 执行完后 在signal 目录下生成了Function\_sign.apk  
 如图:


![在这里插入图片描述](https://img-blog.csdnimg.cn/033967c7dce94becb71c5ec4e591a67e.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_8,color_FFFFFF,t_70,g_se,x_16#pic_center)


生成了apk就代表签名成功了





