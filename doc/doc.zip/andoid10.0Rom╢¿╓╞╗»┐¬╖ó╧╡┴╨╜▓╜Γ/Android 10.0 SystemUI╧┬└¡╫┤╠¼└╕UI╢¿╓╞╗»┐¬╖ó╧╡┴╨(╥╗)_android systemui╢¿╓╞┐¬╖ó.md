






### 1.概述


10.0定制化开发中，由于客户需求要求对整个SystemUI下拉状态栏和下拉通知栏部分的UI做定制，所以需要修改整个下拉状态栏的  
 UI布局页面，这要求对整个NotificationPanelView了解，定制UI才可以顺利完成  
 类似效果图:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/d4c25d1af6dc4a8f8ee52d706a6f3f4c.png#pic_center)


### 2.SystemUI下拉状态栏UI定制化核心代码



```
frameworks\base\packages\SystemUI\res\layout\status_bar_expanded.xml


```

### 3.SystemUI下拉状态栏UI定制化功能实现讲解


定制化开发系列(一) 下拉状态栏布局的讲解  
 首选看下下拉状态栏的布局文件  
 status\_bar\_expanded.xml  
 路径:frameworks\base\packages\SystemUI\res\layout\status\_bar\_expanded.xml



```
<com.android.systemui.statusbar.phone.NotificationPanelView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:id="@+id/notification\_panel"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:background="@android:color/transparent" >

    <FrameLayout
        android:id="@+id/big\_clock\_container"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:visibility="gone" />

    <include
        layout="@layout/keyguard\_status\_view"
        android:visibility="gone" />

    <com.android.systemui.statusbar.phone.NotificationsQuickSettingsContainer
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
        android:id="@+id/notification\_container\_parent"
        android:clipToPadding="false"
        android:clipChildren="false">

        <include layout="@layout/dock\_info\_overlay" />

        <FrameLayout
            android:id="@+id/qs\_frame"
            android:layout="@layout/qs\_panel"
            android:layout_width="@dimen/qs\_panel\_width"
            android:layout_height="match\_parent"
            android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
            android:clipToPadding="false"
            android:clipChildren="false"
            systemui:viewType="com.android.systemui.plugins.qs.QS" />

        <com.android.systemui.statusbar.notification.stack.NotificationStackScrollLayout
            android:id="@+id/notification\_stack\_scroller"
            android:layout_marginTop="@dimen/notification\_panel\_margin\_top"
            android:layout_width="@dimen/notification\_panel\_width"
            android:layout_height="match\_parent"
            android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
            android:layout_marginBottom="@dimen/close\_handle\_underlap" />

        <include layout="@layout/ambient\_indication"
            android:id="@+id/ambient\_indication\_container" />

        <ViewStub
            android:id="@+id/keyguard\_user\_switcher"
            android:layout="@layout/keyguard\_user\_switcher"
            android:layout_height="match\_parent"
            android:layout_width="match\_parent" />

        <include
            layout="@layout/keyguard\_status\_bar"
            android:visibility="invisible" />

        <Button
            android:id="@+id/report\_rejected\_touch"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:layout_marginTop="@dimen/status\_bar\_header\_height\_keyguard"
            android:text="@string/report\_rejected\_touch"
            android:visibility="gone" />

    </com.android.systemui.statusbar.phone.NotificationsQuickSettingsContainer>

    <include
        layout="@layout/keyguard\_bottom\_area"
        android:visibility="gone" />

    <com.android.systemui.statusbar.AlphaOptimizedView
        android:id="@+id/qs\_navbar\_scrim"
        android:layout_height="96dp"
        android:layout_width="match\_parent"
        android:layout_gravity="bottom"
        android:visibility="invisible"
        android:background="@drawable/qs\_navbar\_scrim" />

</com.android.systemui.statusbar.phone.NotificationPanelView>

```

从布局中可以看出



```
<FrameLayout
            android:id="@+id/qs\_frame"
            android:layout="@layout/qs\_panel"
            android:layout_width="@dimen/qs\_panel\_width"
            android:layout_height="match\_parent"
            android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
            android:clipToPadding="false"
            android:clipChildren="false"
            systemui:viewType="com.android.systemui.plugins.qs.QS" />

```

qs\_panel.xml 就是下拉快捷键布局



```
<com.android.systemui.statusbar.notification.stack.NotificationStackScrollLayout
            android:id="@+id/notification\_stack\_scroller"
            android:layout_marginTop="@dimen/notification\_panel\_margin\_top"
            android:layout_width="@dimen/notification\_panel\_width"
            android:layout_height="match\_parent"
            android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
            android:layout_marginBottom="@dimen/close\_handle\_underlap" />

```

NotificationStackScrollLayout 就是下拉状态栏中的通知栏的布局


qs\_panel.xml



```
<com.android.systemui.qs.QSContainerImpl
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/quick\_settings\_container"
    android:layout_width="match\_parent"
    android:layout_height="wrap\_content"
    android:clipToPadding="false"
    android:clipChildren="false" >

    <!-- Main QS background -->
    <View
        android:id="@+id/quick\_settings\_background"
        android:layout_width="match\_parent"
        android:layout_height="0dp"
        android:elevation="4dp"
        android:background="@drawable/qs\_background\_primary" />

    <!-- Black part behind the status bar -->
    <View
        android:id="@+id/quick\_settings\_status\_bar\_background"
        android:layout_width="match\_parent"
        android:layout_height="@\*android:dimen/quick\_qs\_offset\_height"
        android:clipToPadding="false"
        android:clipChildren="false"
        android:background="#ff000000" />

    <!-- Gradient view behind QS -->
    <View
        android:id="@+id/quick\_settings\_gradient\_view"
        android:layout_width="match\_parent"
        android:layout_height="126dp"
        android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
        android:clipToPadding="false"
        android:clipChildren="false"
        android:background="@drawable/qs\_bg\_gradient" />


    <com.android.systemui.qs.QSPanel
        android:id="@+id/quick\_settings\_panel"
        android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_marginBottom="@dimen/qs\_footer\_height"
        android:elevation="4dp"
        android:background="@android:color/transparent"
        android:focusable="true"
        android:accessibilityTraversalBefore="@android:id/edit"
    />

    <include layout="@layout/quick\_status\_bar\_expanded\_header" />

    <include layout="@layout/qs\_footer\_impl" />

    <include android:id="@+id/qs\_detail" layout="@layout/qs\_detail" />

    <include android:id="@+id/qs\_customize" layout="@layout/qs\_customize\_panel"
        android:visibility="gone" />

</com.android.systemui.qs.QSContainerImpl>

quick_status_bar_expanded_header.xml 就是首次下拉状态栏的UI布局文件

<!-- Extends RelativeLayout -->
<com.android.systemui.qs.QuickStatusBarHeader
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/header"
    android:layout_width="match\_parent"
    android:layout_height="@\*android:dimen/quick\_qs\_total\_height"
    android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
    android:background="@android:color/transparent"
    android:baselineAligned="false"
    android:clickable="false"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:paddingTop="0dp"
    android:paddingEnd="0dp"
    android:paddingStart="0dp"
    android:elevation="4dp" >

    <include layout="@layout/quick\_status\_bar\_header\_system\_icons" />

    <!-- Status icons within the panel itself (and not in the top-most status bar) -->
    <include layout="@layout/quick\_qs\_status\_icons" />

    <!-- Layout containing tooltips, alarm text, etc. -->
    <include layout="@layout/quick\_settings\_header\_info" />

    <com.android.systemui.qs.QuickQSPanel
        android:id="@+id/quick\_qs\_panel"
        android:layout_width="match\_parent"
        android:layout_height="48dp"
        android:layout_below="@id/quick\_qs\_status\_icons"
        android:layout_marginStart="@dimen/qs\_header\_tile\_margin\_horizontal"
        android:layout_marginEnd="@dimen/qs\_header\_tile\_margin\_horizontal"
        android:accessibilityTraversalAfter="@+id/date\_time\_group"
        android:accessibilityTraversalBefore="@id/expand\_indicator"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:focusable="true"
        android:importantForAccessibility="yes" />

    <com.android.systemui.statusbar.AlphaOptimizedImageView
        android:id="@+id/qs\_detail\_header\_progress"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_alignParentBottom="true"
        android:alpha="0"
        android:background="@color/qs\_detail\_progress\_track"
        android:src="@drawable/indeterminate\_anim"/>

    <TextView
        android:id="@+id/header\_debug\_info"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_vertical"
        android:fontFamily="sans-serif-condensed"
        android:padding="2dp"
        android:textColor="#00A040"
        android:textSize="11dp"
        android:textStyle="bold"
        android:visibility="invisible"/>

</com.android.systemui.qs.QuickStatusBarHeader>

```

布局中quick\_status\_bar\_header\_system\_icons.xml为下拉状态栏时间Clock的布局  
 而quick\_qs\_status\_icons.xml为下拉状态栏日期 和各种图标的布局  
 com.android.systemui.qs.QuickQSPanel 为首次下拉快捷功能图标的布局





