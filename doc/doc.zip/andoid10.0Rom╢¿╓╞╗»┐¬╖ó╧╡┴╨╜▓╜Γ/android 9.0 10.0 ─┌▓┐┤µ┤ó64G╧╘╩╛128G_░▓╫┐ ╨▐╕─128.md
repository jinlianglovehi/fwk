






在定制化开发中，有客户需求要求改内部存储为128G 首选看Settings存储页面跟进代码 发现  
 StorageStatsService磁盘存储的服务提供了相关应用程序、用户以及外部/共享存储如何计算磁盘空间  
 StorageStatsManager


权限声明


当为您自己的程序包或UID调用StorageStatsManager API时，不需要声明权限。  
 请求其他任何软件包的详细信息都需要android.Manifest.permission＃PACKAGE\_USAGE\_STATS权限，这是系统级权限，不会授予普通应用程序。声明权限表示您打算使用此API，最终用户可以选择通过“设置”应用程序授予


frameworks/base/services/usage/java/com/android/server/usage/StorageStatsService.java



```
//计算某个文件的大小
@Override
    public long getTotalBytes(String volumeUuid, String callingPackage) {
        // NOTE: No permissions required
       //内部存储的大小
        if (volumeUuid == StorageManager.UUID_PRIVATE_INTERNAL) {
           // 修改部分如下:
            return FileUtils.roundStorageSize(mStorage.getPrimaryStorageSize())*2;
        } else {
            final VolumeInfo vol = mStorage.findVolumeByUuid(volumeUuid);
            if (vol == null) {
                throw new ParcelableException(
                        new IOException("Failed to find storage device for UUID " + volumeUuid));
            }
            return FileUtils.roundStorageSize(vol.disk.size);
        }
    }
   //空余
    @Override
    public long getFreeBytes(String volumeUuid, String callingPackage) {
        // NOTE: No permissions required

        final long token = Binder.clearCallingIdentity();
        try {
            final File path;
            try {
                path = mStorage.findPathForUuid(volumeUuid);
            } catch (FileNotFoundException e) {
                throw new ParcelableException(e);
            }

            // Free space is usable bytes plus any cached data that we're
            // willing to automatically clear. To avoid user confusion, this
            // logic should be kept in sync with getAllocatableBytes().
            if (isQuotaSupported(volumeUuid, PLATFORM_PACKAGE_NAME)) {
                final long cacheTotal = getCacheBytes(volumeUuid, PLATFORM_PACKAGE_NAME);
                final long cacheReserved = mStorage.getStorageCacheBytes(path, 0);
                final long cacheClearable = Math.max(0, cacheTotal - cacheReserved);
               //内部存储 // 修改部分如下:
               + if(volumeUuid == StorageManager.UUID_PRIVATE_INTERNAL) {
		+	return path.getUsableSpace() + cacheClearable+(getTotalBytes(volumeUuid,"")/2);
		+}
                return path.getUsableSpace() + cacheClearable;
            } else {
                  //内部存储 // 修改部分如下:
				+if(volumeUuid == StorageManager.UUID_PRIVATE_INTERNAL) {
				+	return path.getUsableSpace() +(getTotalBytes(volumeUuid,"")/2);
				+}
                return path.getUsableSpace();
            }
        } finally {
            Binder.restoreCallingIdentity(token);
        }
    }

```

StatFs 一个模拟linux的df命令的一个类,获得SD卡和手机内存的使用情况  
 getAvailableBlocks()  
 返回 Int ，获取当前可用的存储空间  
 getBlockCount()  
 返回 Int ，获取该区域可用的文件系统数  
 getBlockSize()  
 返回 Int ，大小，以字节为单位，一个文件系统  
 getFreeBlocks()  
 返回 Int ，该块区域剩余的空间  
 restat(String path)  
 执行一个由该对象所引用的文件系统


2.计算内部存储的大小的修改



```
frameworks/base/core/java/android/os/StatFs.java
      */
     @Deprecated
     public int getBlockSize() {
-        return (int) mStat.f_frsize;
+        return (int) mStat.f_frsize*2;
     }

```




