



## 1.前言


在10.0的系统产品开发中，在对于sim卡这个功能模块中，在系统默认系统语言不随sim卡的语言变化，产品开发的需要要求系统语言 需要随着识别到sim卡的语言后，设置为系统默认语言，接下来就实现这个功能


## 2.系统语言随sim卡语言自适应变化功能实现的核心类



```
frameworks\opt\telephony\src\java\com\android\internal\telephony\MccTable.java
```

## 3.系统语言随sim卡语言自适应变化功能实现的核心功能分析和实现


在系统开机重启的过程中，如果未插sim卡，系统语言为预置的语言； 在系统检测到插入SIM卡过后，系统语言根据 SIM 卡来改变， 默认会把开机后第一次插的 SIM 卡的语言设置为默认语言；(如果sim的mcc可以在内置的mcc表中找到)； 如果用户没有手动在 Settings 里面设置语言，以后系统语言一直是默认语言（第一次插的 SIM 卡的语言），即使是插入其它国家的卡，系统语言也不会变； 如果用户在 Settings 里面手动设置了语言，以后系统语言会为设置后的语言，无论插入什么卡，系统语言不会变，一直为用户手动设置后的语言。 而实现监听SIM卡更新系统默认语言的类就是在MccTable.java中实现的，接下来具体分析下相关源码


## 3.1 MccTable.java相关更新sim卡语言的相关功能实现


在实现系统语言随sim卡语言自适应变化功能实现的核心功能中，在通过上述的分析以后得知， 实现监听SIM卡更新系统默认语言的类就是在MccTable.java中实现的， MccTable.java的静态代码块中创建了有个ArrayList sTable，记录MCC和国家码的对应关系。 所以我们可以可根据MCC或PLMN找到对应国家码.



```
   static {
        sTable = new ArrayList<MccEntry>(240);

 ....
        sTable.add(new MccEntry(410,"pk",2));    //Pakistan (Islamic Republic of)
        sTable.add(new MccEntry(412,"af",2));    //Afghanistan
        sTable.add(new MccEntry(413,"lk",2));    //Sri Lanka (Democratic Socialist Republic of)
        sTable.add(new MccEntry(414,"mm",2));    //Myanmar (Union of)
        sTable.add(new MccEntry(415,"lb",2));    //Lebanon
        sTable.add(new MccEntry(416,"jo",2));    //Jordan (Hashemite Kingdom of)
        sTable.add(new MccEntry(417,"sy",2));    //Syrian Arab Republic
        sTable.add(new MccEntry(418,"iq",2));    //Iraq (Republic of)
        sTable.add(new MccEntry(419,"kw",2));    //Kuwait (State of)
        sTable.add(new MccEntry(420,"sa",2));    //Saudi Arabia (Kingdom of)
        sTable.add(new MccEntry(421,"ye",2));    //Yemen (Republic of)
        sTable.add(new MccEntry(422,"om",2));    //Oman (Sultanate of)
                sTable.add(new MccEntry(423,"ps",2));    //Palestine
        sTable.add(new MccEntry(424,"ae",2));    //United Arab Emirates
        sTable.add(new MccEntry(425,"il",2));    //Israel (State of)
        sTable.add(new MccEntry(426,"bh",2));    //Bahrain (Kingdom of)
        sTable.add(new MccEntry(427,"qa",2));    //Qatar (State of)
        sTable.add(new MccEntry(428,"mn",2));    //Mongolia
        sTable.add(new MccEntry(429,"np",2));    //Nepal
        sTable.add(new MccEntry(430,"ae",2));    //United Arab Emirates
        sTable.add(new MccEntry(431,"ae",2));    //United Arab Emirates
        sTable.add(new MccEntry(432,"ir",2));    //Iran (Islamic Republic of)
        sTable.add(new MccEntry(434,"uz",2));    //Uzbekistan (Republic of)
        sTable.add(new MccEntry(436,"tj",2));    //Tajikistan (Republic of)
        sTable.add(new MccEntry(437,"kg",2));    //Kyrgyz Republic
        sTable.add(new MccEntry(438,"tm",2));    //Turkmenistan
        sTable.add(new MccEntry(440,"jp",2));    //Japan
        sTable.add(new MccEntry(441,"jp",2));    //Japan
        sTable.add(new MccEntry(450,"kr",2));    //Korea (Republic of)
        sTable.add(new MccEntry(452,"vn",2));    //Viet Nam (Socialist Republic of)
        sTable.add(new MccEntry(454,"hk",2));    //"Hong Kong, China"
        sTable.add(new MccEntry(455,"mo",2));    //"Macao, China"
        sTable.add(new MccEntry(456,"kh",2));    //Cambodia (Kingdom of)
        sTable.add(new MccEntry(457,"la",2));    //Lao People's Democratic Republic
        sTable.add(new MccEntry(460,"cn",2));    //China (People's Republic of)
        sTable.add(new MccEntry(461,"cn",2));    //China (People's Republic of)
        sTable.add(new MccEntry(466,"tw",2));   
        sTable.add(new MccEntry(467,"kp",2));    //Democratic People's Republic of Korea
        sTable.add(new MccEntry(470,"bd",2));    //Bangladesh (People's Republic of)
        sTable.add(new MccEntry(472,"mv",2));    //Maldives (Republic of)
        //table.add(new MccEntry(901,"",2));    //"International Mobile, shared code"

        Collections.sort(sTable);
    }


```

在实现系统语言随sim卡语言自适应变化功能实现的核心功能中，在通过上述的分析以后得知，  
 在上述的MccTable.java中的相关源码中分析得知，在通过sTable添加每个国家的mnc 和mcc  
 这样通过加载sim卡的时候，通过读取sim卡的mnc mcc就可以获取是哪个国家，然后就可以  
 通过调用更新系统语言的方法，来实现更新系统语言来实现功能



```
  public static void updateMccMncConfiguration(Context context, String mccmnc) {
        Slog.d(LOG_TAG, "updateMccMncConfiguration mccmnc='" + mccmnc);

        if (Build.IS_DEBUGGABLE) {
            String overrideMcc = SystemProperties.get("persist.sys.override_mcc");
            if (!TextUtils.isEmpty(overrideMcc)) {
                mccmnc = overrideMcc;
                Slog.d(LOG_TAG, "updateMccMncConfiguration overriding mccmnc='" + mccmnc + "'");
            }
        }

        if (!TextUtils.isEmpty(mccmnc)) {
            int mcc, mnc;

            try {
                mcc = Integer.parseInt(mccmnc.substring(0, 3));
                mnc = Integer.parseInt(mccmnc.substring(3));
            } catch (NumberFormatException | StringIndexOutOfBoundsException ex) {
                Slog.e(LOG_TAG, "Error parsing IMSI: " + mccmnc + ". ex=" + ex);
                return;
            }
 //Add code BEGIN           Locale mccLocale = null; //Add code end
            Slog.d(LOG_TAG, "updateMccMncConfiguration: mcc=" + mcc + ", mnc=" + mnc);
            if (mcc != 0) {
                setTimezoneFromMccIfNeeded(context, mcc);

//Add code BEGIN
                mccLocale = getLocaleFromMcc(context, mcc,null);//添加这句读取SIM语言
//Add code end

            }

            try {
                Configuration config = new Configuration();
                boolean updateConfig = false;
                if (mcc != 0) {
                    config.mcc = mcc;
                    config.mnc = mnc == 0 ? Configuration.MNC_ZERO : mnc;
                    updateConfig = true;
                }

               //Add code BEGIN
                if(true) {

                    if (mccLocale != null) {
                        Configuration sysConfig = new Configuration();
                        sysConfig = ActivityManager.getService().getConfiguration();;
                        LocaleList currentLocales = sysConfig.getLocales();
                        LocaleList newUserLocales = new LocaleList(mccLocale, currentLocales);
                        config.setLocales(newUserLocales);
            config.fontScale = 1.0f;
            config.userSetLocale=true;
                        updateConfig = true;
                        //LocalePicker.updateLocales(newUserLocales);
                        Settings.System.putConfiguration(context.getContentResolver(), config);
                    }
                }
               //Add code END

                if (updateConfig) {
                    Slog.d(LOG_TAG, "updateMccMncConfiguration updateConfig config=" + config);
                    ActivityManager.getService().updateConfiguration(config);
                } else {
                    Slog.d(LOG_TAG, "updateMccMncConfiguration nothing to update");
                }
            } catch (RemoteException e) {
                Slog.e(LOG_TAG, "Can't update configuration", e);
            }
        }
    }

```

在实现系统语言随sim卡语言自适应变化功能实现的核心功能中，在通过上述的分析以后得知， 在上述的MccTable.java中的相关源码中分析得知，在通过系统的通讯模块分析得知，在sim 卡插入卡槽的时候，当检测到有sim卡的时候，就会调用updateMccMncConfiguration(Context context, String mccmnc ）来通过解析sim卡获取mcc mnc更新系统的Configuration等相关信息，所以可以在这里 通过mcc mcc来获取当前sim的语言，然后通过构建Configuration sysConfig这个对象 然后添加 config.setLocales(newUserLocales);config.fontScale = 1.0f;config.userSetLocale=true; 这三个核心属性，最后通过调用ActivityManager.getService().updateConfiguration(config);来负责 更新系统的Configuration信息，这样就可以在检测到sim卡的情况下更新sim的语言为系统默认语言 这样就实现了系统语言随sim卡语言变化的功能



