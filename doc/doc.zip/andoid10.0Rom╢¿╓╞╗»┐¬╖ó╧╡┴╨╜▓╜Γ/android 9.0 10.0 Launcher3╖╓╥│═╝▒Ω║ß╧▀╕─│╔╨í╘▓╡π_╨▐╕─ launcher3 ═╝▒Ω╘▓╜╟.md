






在Launcher3中，双层页面中滑动workspace时，分页线是一条横线 看起来不太美观，而单层页面分页线却是个小圆点  
 所以改成小圆点还是比较好看点


先看Launcher3布局的xml  
 res/layout/launcher.xml



```
...

        <!-- The workspace contains 5 screens of cells -->
        <!-- DO NOT CHANGE THE ID -->
        <com.android.launcher3.Workspace
            android:id="@+id/workspace"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent"
            android:layout_gravity="center"
            android:theme="@style/HomeScreenElementTheme"
            launcher:pageIndicator="@+id/page\_indicator" />

        <include
            android:id="@+id/overview\_panel\_container"
            layout="@layout/overview\_panel"
            android:visibility="gone" />

        <!-- Keep these behind the workspace so that they are not visible when
         we go into AllApps -->
        <com.android.launcher3.pageindicators.WorkspacePageIndicator
            android:id="@+id/page\_indicator"
            android:layout_width="match\_parent"
            android:layout_height="4dp"
            android:layout_gravity="bottom|center\_horizontal"
            android:theme="@style/HomeScreenElementTheme" />

   ...
</com.android.launcher3.LauncherRootView>

```

从xml 可以看出这个WorkspacePageIndicator 分页线  
 而在com.android.launcher3.pageindicators下发现还有个PageIndicatorDots 这个就是单层时的小圆点 分页线


第一步 ： 替换圆点分页线  
 所以把WorkspacePageIndicator给替换成PageIndicatorDots



```
<!-- Keep these behind the workspace so that they are not visible when
 we go into AllApps -->
<com.android.launcher3.pageindicators.PageIndicatorDots
    android:id="@+id/page\_indicator"
    android:layout_width="match\_parent"
    android:layout_height="4dp"
    android:layout_gravity="bottom|center\_horizontal"
    android:theme="@style/HomeScreenElementTheme" />

```

第二步：修改workspace 中 PagedView的相关代码


PagedView



```
/**
 * The workspace is a wide area with a wallpaper and a finite number of pages.
 * Each page contains a number of icons, folders or widgets the user can
 * interact with. A workspace is meant to be used with a fixed width only.
 */
public class Workspace extends PagedView<PageIndicatorDots>
        implements DropTarget, DragSource, View.OnTouchListener,
        DragController.DragListener, Insettable, LauncherStateManager.StateHandler {
    private static final String TAG = "Launcher.Workspace";

```

注释报错的地方 就是圆点类 没有的方法注释掉



```
com.android.launcher3.states.SpringLoadedState报错了 直接注释掉

    @Override
    public void onStateEnabled(Launcher launcher) {
        Workspace ws = launcher.getWorkspace();
        ws.showPageIndicatorAtCurrentScroll();
            //报错点  设置自动隐藏的 直接注释掉
//        ws.getPageIndicator().setShouldAutoHide(false);



        // Prevent any Un/InstallShortcutReceivers from updating the db while we are
        // in spring loaded mode
        InstallShortcutReceiver.enableInstallQueue(InstallShortcutReceiver.FLAG_DRAG_AND_DROP);
        launcher.getRotationHelper().setCurrentStateRequest(REQUEST_LOCK);
    }

    @Override
    public float getWorkspaceScrimAlpha(Launcher launcher) {
        return 0.3f;
    }

    @Override
    public void onStateDisabled(final Launcher launcher) {
    //报错点  设置自动隐藏的 直接注释掉
//        launcher.getWorkspace().getPageIndicator().setShouldAutoHide(true);

        // Re-enable any Un/InstallShortcutReceiver and now process any queued items
        InstallShortcutReceiver.disableAndFlushInstallQueue(
                InstallShortcutReceiver.FLAG_DRAG_AND_DROP, launcher);
    }

```

4.修改  
 PageIndicatorDots 的 setInset方法


public class PageIndicatorDots extends View implements Insettable, PageIndicator {


然后直接把WorkspacePageIndicator 的setInsets copy过来


@Override  
 public void setInsets(Rect insets) {  
 DeviceProfile grid = mLauncher.getDeviceProfile();  
 FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();



```
if (grid.isVerticalBarLayout()) {
    Rect padding = grid.workspacePadding;
    lp.leftMargin = padding.left + grid.workspaceCellPaddingXPx;
    lp.rightMargin = padding.right + grid.workspaceCellPaddingXPx;
    lp.bottomMargin = padding.bottom;
} else {
    lp.leftMargin = lp.rightMargin = 0;
    lp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
    lp.bottomMargin = grid.hotseatBarSizePx + insets.bottom;
}
setLayoutParams(lp);

```

}


最后在构造方法初始化mLauncher


public PageIndicatorDots(Context context, AttributeSet attrs, int defStyleAttr) {  
 super(context, attrs, defStyleAttr);  
 mLauncher = Launcher.getLauncher(context);  
 mCirclePaint = new Paint(Paint.ANTI\_ALIAS\_FLAG);


在设置里将Launcher3的缓存清掉后,有时会发生奔溃问题  
 检查发现PageIndicatorDots setScroll 的totalScroll有时会为0导致scrollPerPage会有分母为0的情况



```
  @Override
    public void setScroll(int currentScroll, int totalScroll) {
        if (mNumPages > 1) {
            if (mIsRtl) {
                currentScroll = totalScroll - currentScroll;
            }
            int scrollPerPage = totalScroll / (mNumPages - 1);
            //add core
            if(scrollPerPage == 0)
                return;
            //end core
            int pageToLeft = currentScroll / scrollPerPage;
            int pageToLeftScroll = pageToLeft * scrollPerPage;
            int pageToRightScroll = pageToLeftScroll + scrollPerPage;

            float scrollThreshold = SHIFT_THRESHOLD * scrollPerPage;
            if (currentScroll < pageToLeftScroll + scrollThreshold) {
                // scroll is within the left page's threshold
                animateToPosition(pageToLeft);
            } else if (currentScroll > pageToRightScroll - scrollThreshold) {

```




