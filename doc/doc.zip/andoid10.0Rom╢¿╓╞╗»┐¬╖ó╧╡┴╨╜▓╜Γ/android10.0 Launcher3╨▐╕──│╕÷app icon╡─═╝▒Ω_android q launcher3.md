






### 1.概述


在10.0的系统产品开发中，在laucher3中，所有的app icon和名称 以及Hotseat 文件夹都是用BubbleTextView类来构造的，所以要修改图标就要从这个类来分析源码


### 2.Launcher3修改某个app icon的图标的核心类



```
/package/app/Launcher3/src/com/android/launcher3/BubbleTextView.java

```

### 3.Launcher3修改某个app icon的图标的核心功能分析和实现


通过上面的分析，需要看BubbleTextView.java是如果绘制app的图标的  
 路径:  
 /package/app/Launcher3/src/com/android/launcher3/BubbleTextView.java



```
/**
  * TextView that draws a bubble behind the text. We cannot use a LineBackgroundSpan
  * because we want to make the bubble taller than the text and TextView's clip is
 \* too aggressive.
 \*/
 public class BubbleTextView extends TextView implements ItemInfoUpdateReceiver, OnResumeCallback {
 public BubbleTextView(Context context, AttributeSet attrs, int defStyle) {
 super(context, attrs, defStyle);
 mActivity = ActivityContext.lookupContext(context);
 mSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
 
 TypedArray a = context.obtainStyledAttributes(attrs,
 R.styleable.BubbleTextView, defStyle, 0);
 mLayoutHorizontal = a.getBoolean(R.styleable.BubbleTextView\_layoutHorizontal, false);
 
 int display = a.getInteger(R.styleable.BubbleTextView\_iconDisplay, DISPLAY\_WORKSPACE);
 final int defaultIconSize;
 if (display == DISPLAY\_WORKSPACE) {
 DeviceProfile grid = mActivity.getWallpaperDeviceProfile();
 setTextSize(TypedValue.COMPLEX\_UNIT\_PX, grid.iconTextSizePx);
 setCompoundDrawablePadding(grid.iconDrawablePaddingPx);
 defaultIconSize = grid.iconSizePx;
 } else if (display == DISPLAY\_ALL\_APPS) {
 DeviceProfile grid = mActivity.getDeviceProfile();
 setTextSize(TypedValue.COMPLEX\_UNIT\_PX, grid.allAppsIconTextSizePx);
 setCompoundDrawablePadding(grid.allAppsIconDrawablePaddingPx);
 defaultIconSize = grid.allAppsIconSizePx;
 } else if (display == DISPLAY\_FOLDER) {
 DeviceProfile grid = mActivity.getDeviceProfile();
 setTextSize(TypedValue.COMPLEX\_UNIT\_PX, grid.folderChildTextSizePx);
 setCompoundDrawablePadding(grid.folderChildDrawablePaddingPx);
 defaultIconSize = grid.folderChildIconSizePx;
 } else {
 defaultIconSize = mActivity.getDeviceProfile().iconSizePx;
 }
 mCenterVertically = a.getBoolean(R.styleable.BubbleTextView\_centerVertically, false);
 
 mIconSize = a.getDimensionPixelSize(R.styleable.BubbleTextView\_iconSizeOverride,
 defaultIconSize);
 a.recycle();
 
 mLongPressHelper = new CheckLongPressHelper(this);
 mStylusEventHelper = new StylusEventHelper(new SimpleOnStylusPressListener(this), this);
 
 mDotParams = new DotRenderer.DrawParams();
 
 setEllipsize(TruncateAt.END);
 setAccessibilityDelegate(mActivity.getAccessibilityDelegate());
 setTextAlpha(1f);
 }
 public void applyFromWorkspaceItem(WorkspaceItemInfo info, boolean promiseStateChanged) {
 applyIconAndLabel(info);
 setTag(info);
 if (promiseStateChanged || (info.hasPromiseIconUi())) {
 applyPromiseState(promiseStateChanged);
 }
 
 applyDotState(info, false /\* animate \*/);
 }
 
 public void applyFromApplicationInfo(AppInfo info) {
 applyIconAndLabel(info);
 
 // We don't need to check the info since it's not a WorkspaceItemInfo
 super.setTag(info);
 
 // Verify high res immediately
 verifyHighRes();
 
 if (info instanceof PromiseAppInfo) {
 PromiseAppInfo promiseAppInfo = (PromiseAppInfo) info;
 applyProgressLevel(promiseAppInfo.level);
 }
 applyDotState(info, false /\* animate \*/);
 }
 
 public void applyFromPackageItemInfo(PackageItemInfo info) {
 applyIconAndLabel(info);
 // We don't need to check the info since it's not a WorkspaceItemInfo
          super.setTag(info);
  
          // Verify high res immediately
          verifyHighRes();
      }
  
      private void applyIconAndLabel(ItemInfoWithIcon info) {
          FastBitmapDrawable iconDrawable = DrawableFactory.INSTANCE.get(getContext())
                  .newIcon(getContext(), info);
          mDotParams.color = IconPalette.getMutedColor(info.iconColor, 0.54f);
  
          setIcon(iconDrawable);
          setText(info.title);
          if (info.contentDescription != null) {
              setContentDescription(info.isDisabled()
                      ? getContext().getString(R.string.disabled_app_label, info.contentDescription)
                      : info.contentDescription);
          }
      }

```

通过BubbleTextView.java的相关源码得知 在applyFromApplicationInfo(AppInfo info) 中构建  
 app的icon图标，而又调用 applyIconAndLabel(ItemInfoWithIcon info)负责具体每个app的icon的设置  
 通过读取以上方法可以得知保存workspace 的item的图标和文字相关信息  
 而都调用了 applyIconAndLabel(info);


具体看下 applyIconAndLabel(ItemInfoWithIcon info)的相关源码



```
 private void applyIconAndLabel(ItemInfoWithIcon info) {
        FastBitmapDrawable iconDrawable = DrawableFactory.INSTANCE.get(getContext())
                .newIcon(getContext(), info);
        mDotParams.color = IconPalette.getMutedColor(info.iconColor, 0.54f);
		setIcon(iconDrawable);
        setText(info.title);
        if (info.contentDescription != null) {
            setContentDescription(info.isDisabled()
                    ? getContext().getString(R.string.disabled_app_label, info.contentDescription)
                    : info.contentDescription);
        }
    }

```

通过上面的源码发现  
 这个applyIconAndLabel 就是保存icon 信息到Icon缓存中


所以修改如下:



```
 private void applyIconAndLabel(ItemInfoWithIcon info) {
              // 修改某个app的icon start
		if (info.getIntent() != null && info.getIntent().getComponent() != null) {
		  String pkg = info.getIntent().getComponent().getPackageName();
		  if ("com.android.deskclock".equals(pkg) || info.itemType == LauncherSettings.Favorites.ITEM_TYPE_DEEP_SHORTCUT) {
                    //设置bitmap图标
		    info.iconBitmap = IconUtil.getDeskClockIcon(getContext());
		  }
		}
       // 修改某个app的icon end
        FastBitmapDrawable iconDrawable = DrawableFactory.INSTANCE.get(getContext())
                .newIcon(getContext(), info);
        mDotParams.color = IconPalette.getMutedColor(info.iconColor, 0.54f);
		setIcon(iconDrawable);
        setText(info.title);
        if (info.contentDescription != null) {
            setContentDescription(info.isDisabled()
                    ? getContext().getString(R.string.disabled_app_label, info.contentDescription)
                    : info.contentDescription);
        }
    }

```

编译验证 可以看到时钟图标已经更换了





