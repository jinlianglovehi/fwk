






### 1.概述


在Android Q(10.0)以后，系统支持动态分区（dynamic partition），它将多个系统只读分区（包括system、product、vendor、odm或者其他厂商自定义分区）合并为一个super分区。物理分区只有super分区的概念，而没有system等分区  
 在进行定制化开发中，如果内置太多的资源和app时 发现分区不够用了 这时就需要给super分区扩容了


### 2.10.0 扩大super分区的容量的核心代码



```
build/make/core/Makefile
device/sprd/pike2/common/BoardCommon.mk
device/sprd/pike2/sp7731e_1h10/sp7731e_1h10.xml

```

### 3.10.0 扩大super分区的容量的核心功能分析和实现


### 3.1 Makefile关于super分区的相关代码


路径：  
 build/make/core/Makefile



```
# -----------------------------------------------------------------
# super partition image (dist)

ifeq (true,$(PRODUCT\_BUILD\_SUPER\_PARTITION))

# BOARD\_SUPER\_PARTITION\_SIZE must be defined to build super image.
ifneq ($(BOARD\_SUPER\_PARTITION\_SIZE),)

# Dump variables used by build\_super\_image.py.
define dump-super-image-info
  $(call dump-dynamic-partitions-info,$(1))
  $(if $(filter true,$(AB\_OTA\_UPDATER)), \
    echo "ab\_update=true" >> $(1))
endef

ifneq (true,$(PRODUCT\_RETROFIT\_DYNAMIC\_PARTITIONS))

# For real devices and for dist builds, build super image from target files to an intermediate directory.
INTERNAL_SUPERIMAGE_DIST_TARGET := $(call intermediates-dir-for,PACKAGING,super.img)/super.img
$(INTERNAL\_SUPERIMAGE\_DIST\_TARGET): extracted_input_target_files := $(patsubst %.zip,%,$(BUILT\_TARGET\_FILES\_PACKAGE))
$(INTERNAL\_SUPERIMAGE\_DIST\_TARGET): $(LPMAKE) $(BUILT\_TARGET\_FILES\_PACKAGE) $(BUILD\_SUPER\_IMAGE)
	$(call pretty,"Target super fs image from target files: $@")
	PATH=$(dir $(LPMAKE)):$$PATH \
	    $(BUILD\_SUPER\_IMAGE) -v $(extracted\_input\_target\_files) $@

# Skip packing it in dist package because it is in update package.
ifneq (true,$(BOARD\_SUPER\_IMAGE\_IN\_UPDATE\_PACKAGE))
$(call dist-for-goals,dist\_files,$(INTERNAL\_SUPERIMAGE\_DIST\_TARGET))
endif

.PHONY: superimage_dist
superimage_dist: $(INTERNAL\_SUPERIMAGE\_DIST\_TARGET)

endif # PRODUCT\_RETROFIT\_DYNAMIC\_PARTITIONS != "true"
endif # BOARD\_SUPER\_PARTITION\_SIZE != ""
endif # PRODUCT\_BUILD\_SUPER\_PARTITION == "true"

# -----------------------------------------------------------------
# super partition image for development

ifeq (true,$(PRODUCT\_BUILD\_SUPER\_PARTITION))
ifneq ($(BOARD\_SUPER\_PARTITION\_SIZE),)
ifneq (true,$(PRODUCT\_RETROFIT\_DYNAMIC\_PARTITIONS))

# Build super.img by using $(INSTALLED\_\*IMAGE\_TARGET) to $(1)
# $(1): built image path
# $(2): misc\_info.txt path; its contents should match expectation of build\_super\_image.py
define build-superimage-target
  mkdir -p $(dir $(2))
  rm -rf $(2)
  $(call dump-super-image-info,$(2))
  $(foreach p,$(BOARD\_SUPER\_PARTITION\_PARTITION\_LIST), \
 echo "$(p)\_image=$(INSTALLED\_$(call to-upper,$(p))IMAGE_TARGET)" >> $(2);)
  mkdir -p $(dir $(1))
  PATH=$(dir $(LPMAKE)):$$PATH \
    $(BUILD\_SUPER\_IMAGE) -v $(2) $(1)
endef

```

在Makefile 中可以看出BOARD\_SUPER\_PARTITION\_SIZE 即为super分区大小


### 3.2BoardCommon.mk中关于super分区的定义



```
# default value is 512M, using resize to adapter real size
BOARD_USERDATAIMAGE_PARTITION_SIZE := 536870912

BOARD_RESERVED_SPACE_ON := true

# SPRD: add for whale idh version {
#BOARD\_IS\_WHALE := true
# }

#SPRD：AVIExtractorEx
#USE\_AVIExtractorEx :=true

#SPRD：WAVExtractorEx
#USE\_WAVExtractorEx :=true

#SPRD：SUPPORT IMAADPCM
#SUPPORT\_IMAADPCM :=true

#SPRD：SUPPORT FLVExtractor
#SUPPORT\_FLVExtractor :=true

#SPRD：SUPPORT PSXSTRExtractor
#SUPPORT\_PSXSTRExtractor :=true

#SPRD: support wcnd eng mode
USE_SPRD_ENG :=true

#SPRD: Use High Quality Dyn SRC
USE_HIGH_QUALITY_DYN_SRC :=true

TARGET_GPU_PLATFORM := midgard
GPU_GRALLOC_INCLUDES := $(TOP)/vendor/sprd/external/drivers/gpu/$(TARGET\_GPU\_PLATFORM)/include


#ifeq ($(strip $(TARGET\_GPU\_PLATFORM)),midgard)
# PRODUCT\_DEFAULT\_PROPERTY\_OVERRIDES += \
# ro.hwui.use\_offline\_shader=1
#endif

#vsp config
TARGET_VSP_PLATFORM := pike2
SUPPORT_RGB_ENC := true
#SPRD: streaming extention, AOSP should be false.
USE_SPRD_STREAMING_EX := true

# set property overrides split
BOARD_PROPERTY_OVERRIDES_SPLIT_ENABLED := true

#Supprot camera filter mode. 0:Sprd 1:Arcsoft
TARGET_BOARD_CAMERA_FILTER_VERSION := 0

#vendor apps are restricted to use these versions
#Camera Power and Performence optimization
CONFIG_CAMERA_DFS_FIXED_MAXLEVEL := 2
CONFIG_HAS_CAMERA_HINTS_VERSION := 901

#GPU interface
TARGET_BOARD_CAMERA_3DNR_CAPTURE_GPU := true

#sprd jpeg hardware codec support
TARGET_BOARD_SPRD_JPEG_CODEC_SUPPORT := true

#for dynamic partitions feature
BOARD_BUILD_SUPER_IMAGE_BY_DEFAULT := true
BOARD_SUPER_PARTITION_SIZE :=4404019200
BOARD_SUPER_PARTITION_GROUPS := group_unisoc
BOARD_GROUP_UNISOC_SIZE := 4404019200
BOARD_GROUP_UNISOC_PARTITION_LIST := system vendor product

# bsp uapi path
TARGET_BSP_UAPI_PATH := $(TOP)/bsp/out/$(TARGET\_BOARD)/headers
TARGET_BSP_KERNEL_PATH := $(TOP)/bsp/kernel/$(KERNEL\_PATH)

#boark NAME
BOARD_NAME := pike2

#for cali mode use boot.img
BOARD_CALIMODE_USE_BOOTIMG := true

```

第一步修改为:  
 BOARD\_SUPER\_PARTITION\_SIZE就是定义super分区的大小  
 将原来大小4100M修改为5120M  
 修改如下:  
 — a/device/sprd/pike2/common/BoardCommon.mk  
 +++ b/device/sprd/pike2/common/BoardCommon.mk



```

@@ -155,9 +155,9 @@ TARGET_BOARD_SPRD_JPEG_CODEC_SUPPORT := true
 
 #for dynamic partitions feature
 BOARD_BUILD_SUPER_IMAGE_BY_DEFAULT := true
-BOARD_SUPER_PARTITION_SIZE := 4299161600
+BOARD_SUPER_PARTITION_SIZE := 5368709120
 BOARD_SUPER_PARTITION_GROUPS := group_unisoc
-BOARD_GROUP_UNISOC_SIZE := 4299161600
+BOARD_GROUP_UNISOC_SIZE := 5368709120
 BOARD_GROUP_UNISOC_PARTITION_LIST := system vendor product

```

### 3.3 sp7731e\_1h10.xml关于super分区的修改


第二步对sp7731e\_1h10.xml关于super分区的修改:  
 就是定义的super分区所以修改为



```
--- a/device/sprd/pike2/sp7731e_1h10/sp7731e_1h10.xml
+++ b/device/sprd/pike2/sp7731e_1h10/sp7731e_1h10.xml
@@ -330,7 +330,7 @@
                 <Partition id="teecfg\_bak" size="1"/>
                 <Partition id="boot" size="35"/>
                 <Partition id="dtbo" size="8"/>
-                <Partition id="super" size="4100"/>
+                <Partition id="super" size="5120"/>
                 <Partition id="cache" size="150"/>
                 <Partition id="socko" size="75"/>
                 <Partition id="odmko" size="25"/>

```

经过这两处修改 就可以实现super分区扩容了





