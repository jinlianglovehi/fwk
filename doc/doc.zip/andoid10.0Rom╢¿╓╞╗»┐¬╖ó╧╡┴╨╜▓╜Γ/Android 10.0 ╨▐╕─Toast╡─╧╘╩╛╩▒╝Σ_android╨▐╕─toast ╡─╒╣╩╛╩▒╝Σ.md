






### 1.概述


在app开发中 使用Toast 提示消息很常见的功能，但是由于Toast显示的时间过短 要延迟Toast的显示时间 所以就要从源码着手 看显示时间的定义的然后修改Toast显示时间来实现功能


### 2.修改Toast的显示时间核心代码



```
frameworks/base/core/java/android/widget/Toast.java
framework/base/services/core/java/com/android/server/notification/NotificationManagerService.java

```

### 3.修改Toast的显示时间核心代码功能分析


### 3.1首选看Toast.java的源码


路径:frameworks/base/core/java/android/widget/Toast.java  
 查看关于show的相关代码



```
    /** @hide */
    @IntDef(prefix = { "LENGTH\_" }, value = {
            LENGTH_SHORT,
            LENGTH_LONG
    })
    @Retention(RetentionPolicy.SOURCE)
    public @interface Duration {}

    /**
     * Show the view or text notification for a short period of time.  This time
     * could be user-definable.  This is the default.
     * @see #setDuration
     */
    public static final int LENGTH_SHORT = 0;

    /**
     * Show the view or text notification for a long period of time.  This time
     * could be user-definable.
     * @see #setDuration
     */
    public static final int LENGTH_LONG = 1;

/**
 * Show the view for the specified duration.
 */
public void show() {
    if (mNextView == null) {
        throw new RuntimeException("setView must have been called");
    }
    INotificationManager service = getService();
    String pkg = mContext.getOpPackageName();
    TN tn = mTN;
    tn.mNextView = mNextView;
    final int displayId = mContext.getDisplayId();
    try {
        if (localLOGV) Log.v(TAG, "Toast SHOW: " + this + " view = " + mNextView
	+ " caller: " + android.os.Debug.getCallers(1));
        service.enqueueToast(pkg, tn, mDuration, displayId);
    } catch (RemoteException e) {
        // Empty
    }
}

```

从show 可以看出是调用INotificationManager的enqueueToast 方法来继续显示Toast 说明也是在NMS中处理的  
 这个Toast弹窗功能  
 接下来看NotificationManagerService.java的源码


### 3.2 NotificationManagerService.java中关于Toast的相关源码


NMS的相关  
 路径:framework/base/services/core/java/com/android/server/notification/NotificationManagerService.java  
 接下来看下enqueueToast的关于toast的相关源码



```
@VisibleForTesting
final IBinder mService = new INotificationManager.Stub() {
// Toasts
// ============================================================================
@Override
public void enqueueToast(String pkg, ITransientNotification callback, int duration,
int displayId)
{
if (DBG) {
Slog.i(TAG, "enqueueToast pkg=" + pkg + " callback=" + callback
+ " duration=" + duration + " displayId=" + displayId);
}
if (pkg == null || callback == null) {
Slog.e(TAG, "Not enqueuing toast. pkg=" + pkg + " callback=" + callback);
return ;
}
final int callingUid = Binder.getCallingUid();
final boolean isSystemToast = isCallerSystemOrPhone()
|| PackageManagerService.PLATFORM_PACKAGE_NAME.equals(pkg);
final boolean isPackageSuspended = isPackageSuspendedForUser(pkg, callingUid);
final boolean notificationsDisabledForPackage = !areNotificationsEnabledForPackage(pkg,
callingUid);
long callingIdentity = Binder.clearCallingIdentity();
try {
final boolean appIsForeground = mActivityManager.getUidImportance(callingUid)
== IMPORTANCE_FOREGROUND;
if (ENABLE_BLOCKED_TOASTS && !isSystemToast && ((notificationsDisabledForPackage
&& !appIsForeground) || isPackageSuspended)) {
Slog.e(TAG, "Suppressing toast from package " + pkg
+ (isPackageSuspended ? " due to package suspended."
: " by user request."));
return;
}
} finally {
Binder.restoreCallingIdentity(callingIdentity);
}
synchronized (mToastQueue) {
int callingPid = Binder.getCallingPid();
long callingId = Binder.clearCallingIdentity();
try {
ToastRecord record;
int index = indexOfToastLocked(pkg, callback);
// If it's already in the queue, we update it in place, we don't
// move it to the end of the queue.
if (index >= 0) {
record = mToastQueue.get(index);
record.update(duration);
} else {
// Limit the number of toasts that any given package except the android
// package can enqueue.  Prevents DOS attacks and deals with leaks.
if (!isSystemToast) {
int count = 0;
final int N = mToastQueue.size();
for (int i=0; i<N; i++) {
final ToastRecord r = mToastQueue.get(i);
if (r.pkg.equals(pkg)) {
count++;
if (count >= MAX_PACKAGE_NOTIFICATIONS) {
Slog.e(TAG, "Package has already posted " + count
+ " toasts. Not showing more. Package=" + pkg);
return;
}
}
}
}
Binder token = new Binder();
mWindowManagerInternal.addWindowToken(token, TYPE_TOAST, displayId);
record = new ToastRecord(callingPid, pkg, callback, duration, token,
displayId);
mToastQueue.add(record);
index = mToastQueue.size() - 1;
keepProcessAliveIfNeededLocked(callingPid);
}
// If it's at index 0, it's the current toast.  It doesn't matter if it's
// new or just been updated.  Call back and tell it to show itself.
// If the callback fails, this will remove it from the list, so don't
// assume that it's valid after this.
if (index == 0) {
showNextToastLocked();
}
} finally {
Binder.restoreCallingIdentity(callingId);
}
}
}


@GuardedBy("mToastQueue")
void showNextToastLocked() {
    ToastRecord record = mToastQueue.get(0);
    while (record != null) {
        if (DBG) Slog.d(TAG, "Show pkg=" + record.pkg + " callback=" + record.callback);
        try {
            record.callback.show(record.token);
            scheduleDurationReachedLocked(record);
            return;
        } catch (RemoteException e) {
            Slog.w(TAG, "Object died trying to show notification " + record.callback
                    + " in package " + record.pkg);
            // remove it from the list and let the process die
            int index = mToastQueue.indexOf(record);
            if (index >= 0) {
                mToastQueue.remove(index);
            }
            keepProcessAliveIfNeededLocked(record.pid);
            if (mToastQueue.size() > 0) {
                record = mToastQueue.get(0);
            } else {
                record = null;
            }
        }
    }
}

@GuardedBy("mToastQueue")
private void scheduleDurationReachedLocked(ToastRecord r)
{
mHandler.removeCallbacksAndMessages(r);
Message m = Message.obtain(mHandler, MESSAGE_DURATION_REACHED, r);
int delay = r.duration == Toast.LENGTH_LONG ? LONG_DELAY : SHORT_DELAY;
// Accessibility users may need longer timeout duration. This api compares original delay
// with user's preference and return longer one. It returns original delay if there's no
// preference.
delay = mAccessibilityManager.getRecommendedTimeoutMillis(delay,
AccessibilityManager.FLAG_CONTENT_TEXT);
mHandler.sendMessageDelayed(m, delay);
}

```

从代码中可以看出enqueueToast调用showNextToastLocked()来实现弹窗而最终是在scheduleDurationReachedLocked中  
 判断延迟多长时间就是显示多久，然后移除窗口中显示的toast最终事件是由delay 来决定的  
 可以看出int delay = r.duration == Toast.LENGTH\_LONG ? LONG\_DELAY : SHORT\_DELAY;  
 时间都是由LONG\_DELAY : SHORT\_DELAY来获取的



```
static final int LONG_DELAY = PhoneWindowManager.TOAST_WINDOW_TIMEOUT;
static final int SHORT_DELAY = 2000; // 2 seconds

```

SHORT\_DELAY 为2秒 LONG\_DELAY为3.5秒  
 所以延迟时间 就改为



```
static final int LONG_DELAY = 5000;//5seconds
static final int SHORT_DELAY = 3500; // 3.5seconds

```

就这样修改完毕





