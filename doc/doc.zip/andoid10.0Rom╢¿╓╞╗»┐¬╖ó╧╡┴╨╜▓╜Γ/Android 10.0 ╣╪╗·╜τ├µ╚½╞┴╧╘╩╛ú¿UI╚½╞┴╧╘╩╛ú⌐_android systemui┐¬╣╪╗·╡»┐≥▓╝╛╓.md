






### 1.概述


在10.0的系统产品开发中，对于长按电源键弹窗的原生关机界面 UI是靠右边显示的，但是产品  
 需求要求全屏显示 重启和关机功能键居中显示，所以就涉及到调整UI 然后全屏显示  
 首选实现全屏功能


### 2. 关机界面全屏显示（UI全屏显示）核心类



```
frameworks / base / packages / SystemUI / src / com / android / systemui / globalactions / GlobalActionsDialog.java

```

### 3. 关机界面全屏显示（UI全屏显示）核心功能分析和实现


在系统中通过长按电源键，然后弹出关机UI对话框页面，对于这个布局分析，可以用adb shell dumpsys window w |findstr / |findstr name=  
 来获取置顶的布局，而从命令中可以看到GlobalActionsDialog.java就是长按power弹出的关机界面  
 路径：  
 frameworks / base / packages / SystemUI / src / com / android / systemui / globalactions / GlobalActionsDialog.java  
 接下来分析GlobalActionsDialog.java从而实现全屏功能



```

        ActionsDialog(Context context, MyAdapter adapter,
                GlobalActionsPanelPlugin.PanelViewController plugin) {
            super(context, com.android.systemui.R.style.Theme_SystemUI_Dialog_GlobalActions);
            mContext = context;
            mAdapter = adapter;
            mColorExtractor = Dependency.get(SysuiColorExtractor.class);
            mStatusBarService = Dependency.get(IStatusBarService.class);

            // Window initialization
            Window window = getWindow();
            window.requestFeature(Window.FEATURE_NO_TITLE);
            // Inflate the decor view, so the attributes below are not overwritten by the theme.
            window.getDecorView();
            window.getAttributes().systemUiVisibility |= View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.setLayout(MATCH_PARENT, MATCH_PARENT);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
					| WindowManager.LayoutParams.FLAG_FULLSCREEN
                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
            window.setType(WindowManager.LayoutParams.TYPE_VOLUME_OVERLAY);

            setTitle(R.string.global_actions);

            mPanelController = plugin;
            initializeLayout();
        }

```

从ActionsDialog构造方法源码中可以看出  
 window.getAttributes().systemUiVisibility 等Window的相关属性方法来设置关于弹窗窗口的属性，而这里 就是设置window窗口的属性  
 所以增加全屏属性 修改为：



```
window.getAttributes().systemUiVisibility |= View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

                     | View.SYSTEM_UI_FLAG_LAYOUT_STABLE

+                                       | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION

+                                       | View.SYSTEM_UI_FLAG_FULLSCREEN

+                                       | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

                     | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;

```

### 3.2 关机 重启功能键居中功能修改


从 initializeLayout();布局的相关源码发现  
 global\_actions\_column.xml  
 就是布局界面 增加居中属性修改为：



```
--- a/frameworks/base/packages/SystemUI/res/layout-land/global_actions_column.xml

+++ b/frameworks/base/packages/SystemUI/res/layout-land/global_actions_column.xml

@@ -19,18 +19,18 @@

     xmlns:android="http://schemas.android.com/apk/res/android"

     android:id="@id/global\_actions\_view"

     android:layout_width="match\_parent"

-    android:layout_height="match\_parent"

+    android:layout_height="1200px"

     android:orientation="horizontal"

     android:clipToPadding="false"

     android:theme="@style/qs\_theme"

-    android:gravity="center\_horizontal | top"

+    android:gravity="center"

     android:clipChildren="false"

+       android:background="@drawable/bg\_action"

 >

-    <LinearLayout

-        android:layout_height="wrap\_content"

-        android:layout_width="wrap\_content"

+    <RelativeLayout

+        android:layout_height="match\_parent"

+        android:layout_width="match\_parent"

         android:padding="0dp"

-        android:orientation="horizontal"

         android:clipChildren="false"

         android:clipToPadding="false"

     >

@@ -40,13 +40,8 @@

             android:layout_width="wrap\_content"

             android:layout_height="wrap\_content"

             android:orientation="horizontal"

-            android:layout_marginTop="@dimen/global\_actions\_grid\_side\_margin"

+                       android:layout_centerInParent="true"

             android:translationZ="@dimen/global\_actions\_translate"

-            android:paddingLeft="@dimen/global\_actions\_grid\_vertical\_padding"

-            android:paddingRight="@dimen/global\_actions\_grid\_vertical\_padding"

-            android:paddingTop="@dimen/global\_actions\_grid\_horizontal\_padding"

-            android:paddingBottom="@dimen/global\_actions\_grid\_horizontal\_padding"

-            android:background="?android:attr/colorBackgroundFloating"

         />

         <!-- For separated items-->

         <LinearLayout

@@ -60,9 +55,10 @@

             android:paddingTop="@dimen/global\_actions\_grid\_horizontal\_padding"

             android:paddingBottom="@dimen/global\_actions\_grid\_horizontal\_padding"

             android:orientation="horizontal"

+                       android:visibility="gone"

             android:background="?android:attr/colorBackgroundFloating"

             android:translationZ="@dimen/global\_actions\_translate"

         />

-    </LinearLayout>

+    </RelativeLayout>

```

从global\_actions\_column.xml的相关布局中发现，在重启关机的布局就是在


</com.android.systemui.globalactions.GlobalActionsColumnLayout>  
 中布局的，所以需要看com.android.systemui.globalactions.GlobalActionsColumnLayout中的相关源码分析


### 3.3去掉关机重启按键的白色的背景色



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsLayout.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsLayout.java

@@ -50,7 +50,7 @@ public abstract class GlobalActionsLayout extends MultiListLayout {

         HardwareBgDrawable separatedBackground = new HardwareBgDrawable(true, true, getContext());

         listBackground.setTint(gridBackgroundColor);

         separatedBackground.setTint(separatedBackgroundColor);

-        getListView().setBackground(listBackground);

+        //getListView().setBackground(listBackground);

         getSeparatedView().setBackground(separatedBackground);

     }

```

在globalactions/GlobalActionsLayout.java中的setBackgrounds()  
 发现getListView().setBackground(listBackground)就是设置白色背景的相关代码 注释 掉就可以了





