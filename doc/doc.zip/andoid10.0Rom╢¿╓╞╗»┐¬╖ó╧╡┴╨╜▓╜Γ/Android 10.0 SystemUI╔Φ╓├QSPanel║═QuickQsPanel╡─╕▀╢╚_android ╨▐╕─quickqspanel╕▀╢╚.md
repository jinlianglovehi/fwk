






### 1.概述


在10.0的定制SystemUI下拉状态栏UI的时候，要求下拉展开QuickQsPanel,和展开通知栏  
 就是说一次下拉就要展开QuickQsPanel 不需要二次展开QsPanel 所以就需要认真了解第二次展开  
 QsPanel的机制


在10.0的原生下拉状态栏中 第一次下拉会展示QuickQsPanel 第二次下拉会展开QSPanel的界面  
 同时会收缩通知栏 因为QSPanel的高度会比QuickQsPanel的高度高出许多，所以会第二次展开  
 QsPanel的时候 会同时收缩通知栏


而在StatusBar.java 中第一次创建状态栏的时候 会有QSFragment.java负责管理


### 2.SystemUI设置QSPanel和QuickQsPanel的高度的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSFragment.java

```

### 3.SystemUI设置QSPanel和QuickQsPanel的高度的核心功能和分析



```
  protected void setUpQuickSettingsTilePanel() {
        View container = mStatusBarWindow.findViewById(R.id.qs_frame);
        if (container != null) {
            FragmentHostManager fragmentHostManager = FragmentHostManager.get(container);
            ExtensionFragmentListener.attachExtensonToFragment(container, QS.TAG, R.id.qs_frame,
                    Dependency.get(ExtensionController.class)
                            .newExtension(QS.class)
                            .withPlugin(QS.class)
                            .withDefault(this::createDefaultQSFragment)
                            .build());
            mBrightnessMirrorController = new BrightnessMirrorController(mStatusBarWindow,
                    (visible) -> {
                        mBrightnessMirrorVisible = visible;
                        updateScrimController();
                    });
            fragmentHostManager.addTagListener(QS.TAG, (tag, f) -> {
                QS qs = (QS) f;
                if (qs instanceof QSFragment) {
                    mQSPanel = ((QSFragment) qs).getQsPanel();
                    mQSPanel.setBrightnessMirror(mBrightnessMirrorController);
                }
            });
        }
    }

```

通过上述代码可以来设置QsFragement.java来管理下拉状态栏部分功能而  
 对于获取当前QuickQsPanel 和Qspanel.java的高度可以从QsFragement.java中查看  
 接下来就来看QsFragement.java 如何获取高度值



```
    protected QuickStatusBarHeader mHeader;
    protected QSPanel mQSPanel;
@Inject
     public QSFragment(RemoteInputQuickSettingsDisabler remoteInputQsDisabler,
             InjectionInflationController injectionInflater,
             Context context,
             QSTileHost qsTileHost) {
         mRemoteInputQuickSettingsDisabler = remoteInputQsDisabler;
         mInjectionInflater = injectionInflater;
         SysUiServiceProvider.getComponent(context, CommandQueue.class)
                 .observe(getLifecycle(), this);
         mHost = qsTileHost;
     }
 
     @Override
     public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
             Bundle savedInstanceState) {
         inflater = mInjectionInflater.injectable(
                  inflater.cloneInContext(new ContextThemeWrapper(getContext(), R.style.qs_theme)));
          return inflater.inflate(R.layout.qs_panel, container, false);
      }
  
      @Override
      public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
          super.onViewCreated(view, savedInstanceState);
          mQSPanel = view.findViewById(R.id.quick_settings_panel);
          mQSDetail = view.findViewById(R.id.qs_detail);
          mHeader = view.findViewById(R.id.header);
          mFooter = view.findViewById(R.id.qs_footer);
          mContainer = view.findViewById(id.quick_settings_container);
  
          mQSDetail.setQsPanel(mQSPanel, mHeader, (View) mFooter);
          mQSAnimator = new QSAnimator(this,
                  mHeader.findViewById(R.id.quick_qs_panel), mQSPanel);
  
          mQSCustomizer = view.findViewById(R.id.qs_customize);
          mQSCustomizer.setQs(this);
          if (savedInstanceState != null) {
              setExpanded(savedInstanceState.getBoolean(EXTRA_EXPANDED));
              setListening(savedInstanceState.getBoolean(EXTRA_LISTENING));
              setEditLocation(view);
              mQSCustomizer.restoreInstanceState(savedInstanceState);
              if (mQsExpanded) {
                  mQSPanel.getTileLayout().restoreInstanceState(savedInstanceState);
              }
          }
          setHost(mHost);
      }
  
      @Override
      public void onDestroy() {
          super.onDestroy();
          if (mListening) {
              setListening(false);
          }
      }
  
      @Override
      public void onSaveInstanceState(Bundle outState) {
          super.onSaveInstanceState(outState);
          outState.putBoolean(EXTRA_EXPANDED, mQsExpanded);
          outState.putBoolean(EXTRA_LISTENING, mListening);
          mQSCustomizer.saveInstanceState(outState);
          if (mQsExpanded) {
              mQSPanel.getTileLayout().saveInstanceState(outState);
          }
      }
  
      @VisibleForTesting
      boolean isListening() {
          return mListening;
      }
  
      @VisibleForTesting
      boolean isExpanded() {
          return mQsExpanded;
      }
  
      @Override
      public View getHeader() {
          return mHeader;
      }
      @Override
     public int getDesiredHeight() {
         if (mQSCustomizer.isCustomizing()) {
             return getView().getHeight();
         }
         if (mQSDetail.isClosingDetail()) {
             LayoutParams layoutParams = (LayoutParams) mQSPanel.getLayoutParams();
             int panelHeight = layoutParams.topMargin + layoutParams.bottomMargin +
                     + mQSPanel.getMeasuredHeight();
             return panelHeight + getView().getPaddingBottom();
         } else {
             return getView().getMeasuredHeight();
         }
     }
      @Override
      public void hideImmediately() {
          getView().animate().cancel();
          getView().setY(-mHeader.getHeight());
      }
  
      private final ViewTreeObserver.OnPreDrawListener mStartHeaderSlidingIn
              = new ViewTreeObserver.OnPreDrawListener() {
          @Override
          public boolean onPreDraw() {
              getView().getViewTreeObserver().removeOnPreDrawListener(this);
              getView().animate()
                      .translationY(0f)
                      .setStartDelay(mDelay)
                      .setDuration(StackStateAnimator.ANIMATION_DURATION_GO_TO_FULL_SHADE)
                      .setInterpolator(Interpolators.FAST_OUT_SLOW_IN)
                      .setListener(mAnimateHeaderSlidingInListener)
                      .start();
              getView().setY(-mHeader.getHeight());
              return true;
          }
      };
  
      private final Animator.AnimatorListener mAnimateHeaderSlidingInListener
              = new AnimatorListenerAdapter() {
          @Override
          public void onAnimationEnd(Animator animation) {
              mHeaderAnimating = false;
              updateQsState();
          }
      };
  }

```

在 QSFragment.java的 getDesiredHeight(）中的方法,是用来测量下拉状态栏布局高度的，完全可以通过打印日志的方法来获取当前的高度



```
  @Override
    public int getDesiredHeight() {
        if (mQSCustomizer.isCustomizing()) {
            return getView().getHeight();
        }
        if (mQSDetail.isClosingDetail()) {
            LayoutParams layoutParams = (LayoutParams) mQSPanel.getLayoutParams();
            int panelHeight = layoutParams.topMargin + layoutParams.bottomMargin +
                    + mQSPanel.getMeasuredHeight();
            return panelHeight + getView().getPaddingBottom();
        } else {
           android.util.Log.e("QsFragment","mQSPanel:"+mQSPanel.getMeasuredHeight()+"---mHeader:"+mHeader.getMeasuredHeight());
            return getView().getMeasuredHeight();
        }
    }

```

这样就通过设置两次布局高度的方式来让第一次和第二次下拉状态栏高度设置为一样  
 这样只要能设置mQSPanel和mHeader的高度一样 就不会在第二次展开时会展开QSPanel





