



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.系统禁用深色主题背景功能相关核心代码](#2.%E7%B3%BB%E7%BB%9F%E7%A6%81%E7%94%A8%E6%B7%B1%E8%89%B2%E4%B8%BB%E9%A2%98%E8%83%8C%E6%99%AF%E5%8A%9F%E8%83%BD%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.系统禁用深色主题背景功能相关核心代码功能分析](#3.%E7%B3%BB%E7%BB%9F%E7%A6%81%E7%94%A8%E6%B7%B1%E8%89%B2%E4%B8%BB%E9%A2%98%E8%83%8C%E6%99%AF%E5%8A%9F%E8%83%BD%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 DarkUIPreferenceController.java关于深色主题背景相关代码分析](#%C2%A03.1%20DarkUIPreferenceController.java%E5%85%B3%E4%BA%8E%E6%B7%B1%E8%89%B2%E4%B8%BB%E9%A2%98%E8%83%8C%E6%99%AF%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 UiModeManager.java关于深色主题背景的相关代码](#3.2%20UiModeManager.java%E5%85%B3%E4%BA%8E%E6%B7%B1%E8%89%B2%E4%B8%BB%E9%A2%98%E8%83%8C%E6%99%AF%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.3 UiModeManagerService.java设置深色主题背景的相关代码分析](#3.3%20UiModeManagerService.java%E8%AE%BE%E7%BD%AE%E6%B7%B1%E8%89%B2%E4%B8%BB%E9%A2%98%E8%83%8C%E6%99%AF%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)




---



## 1.概述


  在原生系统中，默认有正常背景和深色主题背景，当设置深色主题背景和进入超级省电模式情况下会进入深色主题背景模式这样系统页面都是黑色的显得很不美观，所以功能开发需要要求禁用深色主题功能，这就要从系统设置深色主题功能入手


## 2.系统禁用深色主题背景功能相关核心代码



```
  package/apps/Settings/src/com/android/settings/display/DarkUIPreferenceController.java
  frameworks/base/services/core/java/com/android/server/UiModeManagerService.java
  /frameworks/base/core/java/android/app/UiModeManager.java
```

## 3.系统禁用深色主题背景功能相关核心代码功能分析


##  3.1 DarkUIPreferenceController.java关于深色主题背景相关代码分析



```
 public class DarkUIPreferenceController extends TogglePreferenceController implements
        LifecycleObserver, OnStart, OnStop {

    public static final String DARK_MODE_PREFS = "dark_mode_prefs";
    public static final String PREF_DARK_MODE_DIALOG_SEEN = "dark_mode_dialog_seen";
    public static final int DIALOG_SEEN = 1;
    //bug 1113470: modify summary of dark theme when Power saving mode is turned on
    private final boolean isSupportSprdPowerManager = (1 == SystemProperties.getInt("persist.sys.pwctl.enable", 1));

    @VisibleForTesting
    SwitchPreference mPreference;

    private UiModeManager mUiModeManager;
    private PowerManager mPowerManager;
    private Context mContext;

    private Fragment mFragment;

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateEnabledStateIfNeeded();
        }
    };

    public DarkUIPreferenceController(Context context, String key) {
        super(context, key);
        mContext = context;
        mUiModeManager = context.getSystemService(UiModeManager.class);
        mPowerManager = context.getSystemService(PowerManager.class);
    }

    @Override
    public boolean isChecked() {
        return mUiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES;
    }

    @Override
    public void displayPreference(PreferenceScreen screen) {
        super.displayPreference(screen);
        mPreference = screen.findPreference(getPreferenceKey());
    }

    @Override
    public void updateState(Preference preference) {
        super.updateState(preference);
        updateEnabledStateIfNeeded();
    }

    @Override
    public boolean setChecked(boolean isChecked) {
        final boolean dialogSeen =
                Settings.Secure.getInt(mContext.getContentResolver(),
                        Settings.Secure.DARK_MODE_DIALOG_SEEN, 0) == DIALOG_SEEN;
        if (!dialogSeen && isChecked) {
            showDarkModeDialog();
            return false;
        }
        mUiModeManager.setNightMode(isChecked
                ? UiModeManager.MODE_NIGHT_YES
                : UiModeManager.MODE_NIGHT_NO);
        return true;
    }

    private void showDarkModeDialog() {
        final DarkUIInfoDialogFragment frag = new DarkUIInfoDialogFragment();
        if (mFragment.getFragmentManager() != null) {
            frag.show(mFragment.getFragmentManager(), getClass().getName());
        }
    }


    @VisibleForTesting
    void setUiModeManager(UiModeManager uiModeManager) {
        mUiModeManager = uiModeManager;
    }

    public void setParentFragment(Fragment fragment) {
        mFragment = fragment;
    }

    @Override
    public void onStart() {
        mContext.registerReceiver(mReceiver,
                new IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED));
    }

    @Override
    public void onStop() {
        mContext.unregisterReceiver(mReceiver);
    }


}
```

深色主题开关代码如下:  
 @Override  
     public boolean setChecked(boolean isChecked) {  
         final boolean dialogSeen =  
                 Settings.Secure.getInt(mContext.getContentResolver(),  
                         Settings.Secure.DARK\_MODE\_DIALOG\_SEEN, 0) == DIALOG\_SEEN;  
         if (!dialogSeen && isChecked) {  
             showDarkModeDialog();  
             return false;  
         }  
         mUiModeManager.setNightMode(isChecked  
                 ? UiModeManager.MODE\_NIGHT\_YES  
                 : UiModeManager.MODE\_NIGHT\_NO);  
         return true;  
     }  
 在DarkUIPreferenceController.java的setChecked(boolean isChecked)的相关代码中发现最终是通过UiModeManager.setNightMode(）来控制是否打开深色主题背景的,所以接下来看下UiModeManager的相关设置深色主题的相关代码


## 3.2 UiModeManager.java关于深色主题背景的相关代码



```
      
    public void setNightMode(@NightMode int mode) {
        if (mService != null) {
            try {
                mService.setNightMode(mode);
            } catch (RemoteException e) {
                throw e.rethrowFromSystemServer();
            }
        }
    }

    public @NightMode int getNightMode() {
        if (mService != null) {
            try {
                return mService.getNightMode();
            } catch (RemoteException e) {
                throw e.rethrowFromSystemServer();
            }
        }
        return -1;
    }





```

通过上述代码发现，在setNightMode(@NightMode int mode)要获取和设置深色主题背景 最终是通过UiModeManagerService.java来设置深色主题背景，接下来看下UiModeManagerService.java中关于设置深色主题的相关源码


## 3.3 UiModeManagerService.java设置深色主题背景的相关代码分析


UiModeManagerService.java 在系统中主要是管理UI模式，汽车模式、电视模式、手表模式、黑夜模式等，  
 TwilightService 指出用户当前所在位置是否为晚上,被UiModeManager等用来调整夜间模式  
 这些服务允许应用程序控制设备的UI模式。 它提供了禁用汽车模式的功能，并可以访问夜间模式设置。


系统改变ui模式是建立在底层的ACTION\_DOCK\_EVENT广播之上，当用户物理地将设备放入和移出扩展坞时发送ACTION\_DOCK\_EVENT广播。 当发生这种情况时，  
 UiModeManager系统切换Configuration到适当的用户界面模式，将关于模式切换广播




```

             @Override
        public void setNightMode(int mode) {
            if (isNightModeLocked() && (getContext().checkCallingOrSelfPermission(
                    android.Manifest.permission.MODIFY_DAY_NIGHT_MODE)
                    != PackageManager.PERMISSION_GRANTED)) {
                Slog.e(TAG, "Night mode locked, requires MODIFY_DAY_NIGHT_MODE permission");
                return;
            }
            if (!mSetupWizardComplete) {
                Slog.d(TAG, "Night mode cannot be changed before setup wizard completes.");
                return;
            }
            switch (mode) {
                case UiModeManager.MODE_NIGHT_NO:
                case UiModeManager.MODE_NIGHT_YES:
                case UiModeManager.MODE_NIGHT_AUTO:
                    break;
                default:
                    throw new IllegalArgumentException("Unknown mode: " + mode);
            }

            final int user = UserHandle.getCallingUserId();
            final long ident = Binder.clearCallingIdentity();
            try {
                synchronized (mLock) {
                    if (mNightMode != mode) {
                        // Only persist setting if not in car mode
                        if (!mCarModeEnabled) {
                            Secure.putIntForUser(getContext().getContentResolver(),
                                    Secure.UI_NIGHT_MODE, mode, user);

                            if (UserManager.get(getContext()).isPrimaryUser()) {
                                SystemProperties.set(SYSTEM_PROPERTY_DEVICE_THEME,
                                        Integer.toString(mode));
                            }
                        }

                        mNightMode = mode;
                        updateLocked(0, 0);
                    }
                }
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }

        @Override
        public int getNightMode() {
            synchronized (mLock) {
                return mNightMode;
            }
        }
```

通过UiModeManagerService.java中的上述源码发现在setNightMode(int mode)就是最终设置深色主题的代码


所以最终修改为:



```
          @Override
        public void setNightMode(int mode) {
            //add core start
            if(true)return;
           //add core end

            if (isNightModeLocked() && (getContext().checkCallingOrSelfPermission(
                    android.Manifest.permission.MODIFY_DAY_NIGHT_MODE)
                    != PackageManager.PERMISSION_GRANTED)) {
                Slog.e(TAG, "Night mode locked, requires MODIFY_DAY_NIGHT_MODE permission");
                return;
            }
            if (!mSetupWizardComplete) {
                Slog.d(TAG, "Night mode cannot be changed before setup wizard completes.");
                return;
            }
            switch (mode) {
                case UiModeManager.MODE_NIGHT_NO:
                case UiModeManager.MODE_NIGHT_YES:
                case UiModeManager.MODE_NIGHT_AUTO:
                    break;
                default:
                    throw new IllegalArgumentException("Unknown mode: " + mode);
            }

            final int user = UserHandle.getCallingUserId();
            final long ident = Binder.clearCallingIdentity();
            try {
                synchronized (mLock) {
                    if (mNightMode != mode) {
                        // Only persist setting if not in car mode
                        if (!mCarModeEnabled) {
                            Secure.putIntForUser(getContext().getContentResolver(),
                                    Secure.UI_NIGHT_MODE, mode, user);

                            if (UserManager.get(getContext()).isPrimaryUser()) {
                                SystemProperties.set(SYSTEM_PROPERTY_DEVICE_THEME,
                                        Integer.toString(mode));
                            }
                        }

                        mNightMode = mode;
                        updateLocked(0, 0);
                    }
                }
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }
```



