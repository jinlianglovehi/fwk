



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.app进程保活白名单的核心功能代码](#2.app%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E7%99%BD%E5%90%8D%E5%8D%95%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81)


[3.app进程保活白名单的核心功能代码分析](#3.app%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E7%99%BD%E5%90%8D%E5%8D%95%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 IActivityManager.aidl增加app进程保活白名单接口](#3.1%20IActivityManager.aidl%E5%A2%9E%E5%8A%A0app%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E7%99%BD%E5%90%8D%E5%8D%95%E6%8E%A5%E5%8F%A3)


[3.2 ActivityManager.java实现app进程保活白名单接口](#%C2%A0%203.2%20ActivityManager.java%E5%AE%9E%E7%8E%B0app%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E7%99%BD%E5%90%8D%E5%8D%95%E6%8E%A5%E5%8F%A3)


[3.3 ActivityManagerService.java增加app进程保活白名单接口](#%C2%A0%C2%A0%203.3%20ActivityManagerService.java%E5%A2%9E%E5%8A%A0app%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E7%99%BD%E5%90%8D%E5%8D%95%E6%8E%A5%E5%8F%A3)


[3.4 ActivityStackSupervisor.java关于app进程保活的相关代码分析](#3.4%20ActivityStackSupervisor.java%E5%85%B3%E4%BA%8Eapp%E8%BF%9B%E7%A8%8B%E4%BF%9D%E6%B4%BB%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)




---



## 1.概述


  在10.0的系统定制化开发中，有项需求功能要求设置app进程保活白名单 用于控制进程是否常驻，进程优化等。白名单应用避免被系统杀掉，保持常驻,这就涉及到如何保证进程不被杀掉了


## 2.app进程保活白名单的核心功能代码



```
 frameworks/base/core/java/android/app/IActivityManager.aidl
  frameworks/base/core/java/android/app/ActivityManager.java
  frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
  frameworks/base/services/core/java/com/android/server/wm/ActivityStackSupervisor.java
```

## 3.app进程保活白名单的核心功能代码分析


#### 3.1 IActivityManager.aidl增加app进程保活白名单接口



```
  List<String> getWhiteAppList();
  void setWhiteAppList(in List<String> whiteAppList);
```

####   3.2 ActivityManager.java实现app进程保活白名单接口



```
frameworks/base/core/java/android/app/ActivityManager.java
    public List<String> getWhiteAppList() {
        try {
            return getService().getWhiteAppList();
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }
    public void setWhiteAppList(List<String> whiteAppList) {
        try {
            getService().setWhiteAppList(whiteAppList);
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }
```

####    3.3 ActivityManagerService.java增加app进程保活白名单接口



```
frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
    private List<String> mWhiteAppList = new ArrayList<String>();

    @Override
    public List<String> getWhiteAppList() {
        return mWhiteAppList;
    }
    @Override
    public void setWhiteAppList(List<String> whiteAppList) {
        this.mWhiteAppList = whiteAppList;
    }

   分析实现app进程相关的接口
   
/**
     * Main function for removing an existing process from the activity manager
     * as a result of that process going away.  Clears out all connections
     * to the process.
     */
    @GuardedBy("this")
    final void handleAppDiedLocked(ProcessRecord app,
            boolean restarting, boolean allowRestart) {
        int pid = app.pid;
        boolean kept = cleanUpApplicationRecordLocked(app, restarting, allowRestart, -1,
                false /*replacingPid*/);
        if (!kept && !restarting) {
            removeLruProcessLocked(app);
            if (pid > 0) {
                ProcessList.remove(pid);
            }
        }

        if (mProfileData.getProfileProc() == app) {
            clearProfilerLocked();
        }

        mAtmInternal.handleAppDied(app.getWindowProcessController(), restarting, () -> {
            Slog.w(TAG, "Crash of app " + app.processName
                    + " running instrumentation " + app.getActiveInstrumentation().mClass);
            Bundle info = new Bundle();
            info.putString("shortMsg", "Process crashed.");
            finishInstrumentationLocked(app, Activity.RESULT_CANCELED, info);
        });
    }
    从注释可以看出是移除当前的app进程 主要是在cleanUpApplicationRecordLocked(app, restarting, allowRestart, -1,
                false /*replacingPid*/);中实现 
   **
     * Main code for cleaning up a process when it has gone away.  This is
     * called both as a result of the process dying, or directly when stopping
     * a process when running in single process mode.
     *
     * @return Returns true if the given process has been restarted, so the
     * app that was passed in must remain on the process lists.
     */
    @GuardedBy("this")
    final boolean cleanUpApplicationRecordLocked(ProcessRecord app,
            boolean restarting, boolean allowRestart, int index, boolean replacingPid) {
        if (true || DEBUG_CLEANUP) {
            Slog.v(TAG_CLEANUP, "Clean up application record for " + app + " restarting="
                    + restarting + " allowRestart=" + allowRestart + " index=" + index
                    + " replacingPid=" + replacingPid);
        }

        if (index >= 0) {
            removeLruProcessLocked(app);
            ProcessList.remove(app.pid);
        }

        mProcessesToGc.remove(app);
        mPendingPssProcesses.remove(app);
        ProcessList.abortNextPssTime(app.procStateMemTracker);

        // Dismiss any open dialogs.
        if (app.crashDialog != null && !app.forceCrashReport) {
            app.crashDialog.dismiss();
            app.crashDialog = null;
        }
        if (app.anrDialog != null) {
            app.anrDialog.dismiss();
            app.anrDialog = null;
        }
        if (app.waitDialog != null) {
            app.waitDialog.dismiss();
            app.waitDialog = null;
        }

        app.setCrashing(false);
        app.setNotResponding(false);

        app.resetPackageList(mProcessStats);
        app.unlinkDeathRecipient();
        app.makeInactive(mProcessStats);
        app.waitingToKill = null;
        app.forcingToImportant = null;
        updateProcessForegroundLocked(app, false, 0, false);
        app.setHasForegroundActivities(false);
        app.hasShownUi = false;
        app.treatLikeActivity = false;
        app.hasAboveClient = false;
        app.setHasClientActivities(false);

        mServices.killServicesLocked(app, allowRestart);

        boolean restart = false;

        // Remove published content providers.
        for (int i = app.pubProviders.size() - 1; i >= 0; i--) {
            ContentProviderRecord cpr = app.pubProviders.valueAt(i);
            final boolean always = app.bad || !allowRestart;
            boolean inLaunching = removeDyingProviderLocked(app, cpr, always);
            if ((inLaunching || always) && cpr.hasConnectionOrHandle()) {
                // We left the provider in the launching list, need to
                // restart it.
                restart = true;
            }

            cpr.provider = null;
            cpr.setProcess(null);
        }
        app.pubProviders.clear();

        // Take care of any launching providers waiting for this process.
        if (cleanupAppInLaunchingProvidersLocked(app, false)) {
            restart = true;
        }

        // Unregister from connected content providers.
        if (!app.conProviders.isEmpty()) {
            for (int i = app.conProviders.size() - 1; i >= 0; i--) {
                ContentProviderConnection conn = app.conProviders.get(i);
                conn.provider.connections.remove(conn);
                stopAssociationLocked(app.uid, app.processName, conn.provider.uid,
                        conn.provider.appInfo.longVersionCode, conn.provider.name,
                        conn.provider.info.processName);
            }
            app.conProviders.clear();
        }

        // At this point there may be remaining entries in mLaunchingProviders
        // where we were the only one waiting, so they are no longer of use.
        // Look for these and clean up if found.
        // XXX Commented out for now.  Trying to figure out a way to reproduce
        // the actual situation to identify what is actually going on.
        if (false) {
            for (int i = mLaunchingProviders.size() - 1; i >= 0; i--) {
                ContentProviderRecord cpr = mLaunchingProviders.get(i);
                if (cpr.connections.size() <= 0 && !cpr.hasExternalProcessHandles()) {
                    synchronized (cpr) {
                        cpr.launchingApp = null;
                        cpr.notifyAll();
                    }
                }
            }
        }

        skipCurrentReceiverLocked(app);

        // Unregister any receivers.
        for (int i = app.receivers.size() - 1; i >= 0; i--) {
            removeReceiverLocked(app.receivers.valueAt(i));
        }
        app.receivers.clear();

        // If the app is undergoing backup, tell the backup manager about it
        final BackupRecord backupTarget = mBackupTargets.get(app.userId);
        if (backupTarget != null && app.pid == backupTarget.app.pid) {
            if (DEBUG_BACKUP || DEBUG_CLEANUP) Slog.d(TAG_CLEANUP, "App "
                    + backupTarget.appInfo + " died during backup");
            mHandler.post(new Runnable() {
                @Override
                public void run(){
                    try {
                        IBackupManager bm = IBackupManager.Stub.asInterface(
                                ServiceManager.getService(Context.BACKUP_SERVICE));
                        bm.agentDisconnectedForUser(app.userId, app.info.packageName);
                    } catch (RemoteException e) {
                        // can't happen; backup manager is local
                    }
                }
            });
        }

        for (int i = mPendingProcessChanges.size() - 1; i >= 0; i--) {
            ProcessChangeItem item = mPendingProcessChanges.get(i);
            if (app.pid > 0 && item.pid == app.pid) {
                mPendingProcessChanges.remove(i);
                mAvailProcessChanges.add(item);
            }
        }
        mUiHandler.obtainMessage(DISPATCH_PROCESS_DIED_UI_MSG, app.pid, app.info.uid,
                null).sendToTarget();

        // If the caller is restarting this app, then leave it in its
        // current lists and let the caller take care of it.
        if (restarting) {
            return false;
        }

        if (!app.isPersistent() || app.isolated) {
            if (DEBUG_PROCESSES || DEBUG_CLEANUP) Slog.v(TAG_CLEANUP,
                    "Removing non-persistent process during cleanup: " + app);
            if (!replacingPid) {
                mProcessList.removeProcessNameLocked(app.processName, app.uid, app);
            }
            mAtmInternal.clearHeavyWeightProcessIfEquals(app.getWindowProcessController());
            //modify for performance begin
            if(app.pid > 0 && app.info != null && !app.removed && keepImpAppAlive(app.info.packageName)
                    && mUserController.hasStartedUserState(UserHandle.getUserId(app.uid))){
                restart = true;
            }
            //modify for performance end
        } else if (!app.removed) {
            // This app is persistent, so we need to keep its record around.
            // If it is not already on the pending app list, add it there
            // and start a new process for it.
            if (mPersistentStartingProcesses.indexOf(app) < 0) {
                mPersistentStartingProcesses.add(app);
                restart = true;
            }
        }
        if ((DEBUG_PROCESSES || DEBUG_CLEANUP) && mProcessesOnHold.contains(app)) Slog.v(
                TAG_CLEANUP, "Clean-up removing on hold: " + app);
        mProcessesOnHold.remove(app);

        mAtmInternal.onCleanUpApplicationRecord(app.getWindowProcessController());

        if (restart && !app.isolated) {
            // We have components that still need to be running in the
            // process, so re-launch it.
            if (index < 0) {
                ProcessList.remove(app.pid);
            }
            mProcessList.addProcessNameLocked(app);
            app.pendingStart = false;
            mProcessList.startProcessLocked(app,
                    new HostingRecord("restart", app.processName));
            return true;
        } else if (app.pid > 0 && app.pid != MY_PID) {
            // Goodbye!
            mPidsSelfLocked.remove(app);
            mHandler.removeMessages(PROC_START_TIMEOUT_MSG, app);
            mBatteryStatsService.noteProcessFinish(app.processName, app.info.uid);
            if (app.isolated) {
                mBatteryStatsService.removeIsolatedUid(app.uid, app.info.uid);
            }
            app.setPid(0);
        }
        return false;
    }

所以具体修改为:
--- a/frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
+++ b/frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
@@ -14079,8 +14079,13 @@ public class ActivityManagerService extends IActivityManager.Stub
         if (restarting) {
             return false;
         }
-
-        if (!app.isPersistent() || app.isolated) {
+                List<String> lists=    this.mWhiteAppList;
+                boolean iskeepAlive=false;
+                if(lists!=null && lists.contains(app.processName)){
+                        iskeepAlive=true;
+                }
+        if ((!app.isPersistent() || app.isolated) && !iskeepAlive) {
             if (DEBUG_PROCESSES || DEBUG_CLEANUP) Slog.v(TAG_CLEANUP,
                     "Removing non-persistent process during cleanup: " + app);
             if (!replacingPid) {
@@ -14097,6 +14102,7 @@ public class ActivityManagerService extends IActivityManager.Stub
             // This app is persistent, so we need to keep its record around.
             // If it is not already on the pending app list, add it there
             // and start a new process for it.
+                       android.util.Log.d("dong","processName11:"+iskeepAlive+","+app.processName);
             if (mPersistentStartingProcesses.indexOf(app) < 0) {
                 mPersistentStartingProcesses.add(app);
                 restart = true;
```

#### 3.4 ActivityStackSupervisor.java关于app进程保活的相关代码分析



```
@Override
    public void onRecentTaskRemoved(TaskRecord task, boolean wasTrimmed, boolean killProcess) {
        if (wasTrimmed) {
            // Task was trimmed from the recent tasks list -- remove the active task record as well
            // since the user won't really be able to go back to it
            removeTaskByIdLocked(task.taskId, killProcess, false /* removeFromRecents */,
                    !PAUSE_IMMEDIATELY, "recent-task-trimmed");
        }
        task.removedFromRecents();
    }
   这里就是点击Recent键移除app进程的相关方法
  主要是removeTaskByIdLocked(task.taskId, killProcess, false /* removeFromRecents */,
                    !PAUSE_IMMEDIATELY, "recent-task-trimmed");中实现
  /**
     * See {@link #removeTaskByIdLocked(int, boolean, boolean, boolean)}
     */
    boolean removeTaskByIdLocked(int taskId, boolean killProcess, boolean removeFromRecents,
            String reason) {
        return removeTaskByIdLocked(taskId, killProcess, removeFromRecents, !PAUSE_IMMEDIATELY,
                reason);
    }

    /**
     * Removes the task with the specified task id.
     *
     * @param taskId Identifier of the task to be removed.
     * @param killProcess Kill any process associated with the task if possible.
     * @param removeFromRecents Whether to also remove the task from recents.
     * @param pauseImmediately Pauses all task activities immediately without waiting for the
     *                         pause-complete callback from the activity.
     * @return Returns true if the given task was found and removed.
     */
    boolean removeTaskByIdLocked(int taskId, boolean killProcess, boolean removeFromRecents,
            boolean pauseImmediately, String reason) {
        final TaskRecord tr =
                mRootActivityContainer.anyTaskForId(taskId, MATCH_TASK_IN_STACKS_OR_RECENT_TASKS);
        if (tr != null) {
            if (tr.mActivities.size() > 0) {
                tr.removeTaskActivitiesLocked(pauseImmediately, reason);
            } else {
                // When the task is empty (retstored from restoreRecentTask),
                // it will never trigger removeTask (last token), force remove it.
                ActivityStack stack = tr.getStack();
                if (stack != null) {
                    stack.removeTask(tr, reason + " force-remove-empty-task",
                                     REMOVE_TASK_MODE_DESTROYING);
                }
            }
            cleanUpRemovedTaskLocked(tr, killProcess, removeFromRecents);
            mService.getLockTaskController().clearLockedTask(tr);
            if (tr.isPersistable) {
                mService.notifyTaskPersisterLocked(null, true);
            }
            return true;
        }
        Slog.w(TAG, "Request to remove task ignored for non-existent task " + taskId);
        return false;
    }

具体修改为:
frameworks/base/services/core/java/com/android/server/wm/ActivityStackSupervisor.java
/**
     * Removes the task with the specified task id.
     *
     * @param taskId Identifier of the task to be removed.
     * @param killProcess Kill any process associated with the task if possible.
     * @param removeFromRecents Whether to also remove the task from recents.
     * @param pauseImmediately Pauses all task activities immediately without waiting for the
     *                         pause-complete callback from the activity.
     * @return Returns true if the given task was found and removed.
     */
    boolean removeTaskByIdLocked(int taskId, boolean killProcess, boolean removeFromRecents,
            boolean pauseImmediately, String reason) {
        final TaskRecord tr =
                mRootActivityContainer.anyTaskForId(taskId, MATCH_TASK_IN_STACKS_OR_RECENT_TASKS);
        if (tr != null) {

                       //add code start
			ComponentName component = tr.getBaseIntent().getComponent();
			if(component!=null){
				String pkg=component.getPackageName();
				        ActivityManager am = (ActivityManager) mService.mContext.getSystemService(
                Context.ACTIVITY_SERVICE);
				List<String> list=am.getWhiteAppList();
				if(list!=null && list.contains(pkg)){
					return false;
				}
			}
           //add code end

            if (tr.mActivities.size() > 0) {
                tr.removeTaskActivitiesLocked(pauseImmediately, reason);
            } else {
                // When the task is empty (retstored from restoreRecentTask),
                // it will never trigger removeTask (last token), force remove it.
                ActivityStack stack = tr.getStack();
                if (stack != null) {
                    stack.removeTask(tr, reason + " force-remove-empty-task",
                                     REMOVE_TASK_MODE_DESTROYING);
                }
            }
            cleanUpRemovedTaskLocked(tr, killProcess, removeFromRecents);
            mService.getLockTaskController().clearLockedTask(tr);
            if (tr.isPersistable) {
                mService.notifyTaskPersisterLocked(null, true);
            }
            return true;
        }
        Slog.w(TAG, "Request to remove task ignored for non-existent task " + taskId);
        return false;
    }
```



