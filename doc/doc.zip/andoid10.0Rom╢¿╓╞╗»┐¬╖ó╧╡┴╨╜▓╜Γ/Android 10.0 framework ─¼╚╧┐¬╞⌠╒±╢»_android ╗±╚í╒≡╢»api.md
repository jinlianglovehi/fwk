






### 1.概述


在10.0的系统产品开发中，系统settings 的声音菜单下 有一个开启震动的 功能开关，默认是关闭的，由于项目的需要要求开启震动功能，所以就要看源码震动开关是怎么打开的


Android 开启振动主要运用了 Vibrator（振动器），系统中有一个 Vibrator 抽象类，我们可以通过获取 Vibrator实例调用里面的方法来完成振动功能。  
 app关于振动的相关api如下



```
Vibrator vibrator = (Vibrator) getSystemServic(Service.VIBRATOR_SERVICE);
vibrator.vibrate(1000);  //设置手机振动
vibrator.hasVibrator();  //判断手机硬件是否有振动器
vibrator.cancel();//关闭振动

```

### 2.framework 默认开启振动的核心类



```
framework/base/services/core/java/com/android/server/VibratorService.java
device/sprd/sharkl5Pro/ums512_2h10/system.prop

```

### 3.framework 默认开启振动的核心功能分析和实现


VibratorService是Android系统中的一个振动服务，它的作用就是设置手机震动。Vibrator，即震动器，或者称之为马达，  
 在开发的产品中，硬件主板上是有一个小马达，是安装在产品里的硬件设备，用来启动震动的作用  
 通过上面app的例子发现 设置震动功能 首选在系统服务中要判断硬件是否支持震动功能 就是VibratorServices.java中的hasVibrator()是否为true  
 接下来看下VibratorServices.java的源码  
 路径为：framework/base/services/core/java/com/android/server/VibratorService.java



```
public class VibratorService extends IVibratorService.Stub
         implements InputManager.InputDeviceListener {
     private static final String TAG = "VibratorService";
     private static final boolean DEBUG = false;
     static native boolean vibratorExists();
      static native void vibratorInit();
      static native void vibratorOn(long milliseconds);
      static native void vibratorOff();
  
      private final IUidObserver mUidObserver = new IUidObserver.Stub() {
          @Override public void onUidStateChanged(int uid, int procState, long procStateSeq) {
              mProcStatesCache.put(uid, procState);
          }
  
          @Override public void onUidGone(int uid, boolean disabled) {
              mProcStatesCache.delete(uid);
          }
  
          @Override public void onUidActive(int uid) {
          }
  
          @Override public void onUidIdle(int uid, boolean disabled) {
          }
  
          @Override public void onUidCachedChanged(int uid, boolean cached) {
          }
      };
  
       VibratorService(Context context) {
          vibratorInit();
          // Reset the hardware to a default state, in case this is a runtime
          // restart instead of a fresh boot.
          vibratorOff();
  
          mSupportsAmplitudeControl = vibratorSupportsAmplitudeControl();
          mSupportsExternalControl = vibratorSupportsExternalControl();
  
          mContext = context;
          PowerManager pm = (PowerManager)context.getSystemService(Context.POWER_SERVICE);
          mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "\*vibrator\*");
          mWakeLock.setReferenceCounted(true);
  
          mAppOps = mContext.getSystemService(AppOpsManager.class);
          mBatteryStatsService = IBatteryStats.Stub.asInterface(ServiceManager.getService(
                  BatteryStats.SERVICE_NAME));
  
          mPreviousVibrationsLimit = mContext.getResources().getInteger(
                  com.android.internal.R.integer.config_previousVibrationsDumpLimit);
  
          mDefaultVibrationAmplitude = mContext.getResources().getInteger(
                  com.android.internal.R.integer.config_defaultVibrationAmplitude);
  
          mAllowPriorityVibrationsInLowPowerMode = mContext.getResources().getBoolean(
                  com.android.internal.R.bool.config_allowPriorityVibrationsInLowPowerMode);
  
          mPreviousRingVibrations = new LinkedList<>();
          mPreviousNotificationVibrations = new LinkedList<>();
          mPreviousAlarmVibrations = new LinkedList<>();
          mPreviousVibrations = new LinkedList<>();
          mPreviousExternalVibrations = new LinkedList<>();
  
          IntentFilter filter = new IntentFilter();
          filter.addAction(Intent.ACTION_SCREEN_OFF);
          context.registerReceiver(mIntentReceiver, filter);
  
          VibrationEffect clickEffect = createEffectFromResource(
                  com.android.internal.R.array.config_virtualKeyVibePattern);
          VibrationEffect doubleClickEffect = VibrationEffect.createWaveform(
                  DOUBLE_CLICK_EFFECT_FALLBACK_TIMINGS, -1 /*repeatIndex*/);
          VibrationEffect heavyClickEffect = createEffectFromResource(
                  com.android.internal.R.array.config_longPressVibePattern);
          VibrationEffect tickEffect = createEffectFromResource(
                  com.android.internal.R.array.config_clockTickVibePattern);
  
          mFallbackEffects = new SparseArray<>();
          mFallbackEffects.put(VibrationEffect.EFFECT_CLICK, clickEffect);
          mFallbackEffects.put(VibrationEffect.EFFECT_DOUBLE_CLICK, doubleClickEffect);
          mFallbackEffects.put(VibrationEffect.EFFECT_TICK, tickEffect);
          mFallbackEffects.put(VibrationEffect.EFFECT_HEAVY_CLICK, heavyClickEffect);
  
          mFallbackEffects.put(VibrationEffect.EFFECT_TEXTURE_TICK,
                  VibrationEffect.get(VibrationEffect.EFFECT_TICK, false));
  
          mScaleLevels = new SparseArray<>();
          mScaleLevels.put(SCALE_VERY_LOW,
                  new ScaleLevel(SCALE_VERY_LOW_GAMMA, SCALE_VERY_LOW_MAX_AMPLITUDE));
          mScaleLevels.put(SCALE_LOW, new ScaleLevel(SCALE_LOW_GAMMA, SCALE_LOW_MAX_AMPLITUDE));
          mScaleLevels.put(SCALE_NONE, new ScaleLevel(SCALE_NONE_GAMMA));
          mScaleLevels.put(SCALE_HIGH, new ScaleLevel(SCALE_HIGH_GAMMA));
          mScaleLevels.put(SCALE_VERY_HIGH, new ScaleLevel(SCALE_VERY_HIGH_GAMMA));
  
          ServiceManager.addService(EXTERNAL_VIBRATOR_SERVICE, new ExternalVibratorService());
      }
  
      public void systemReady() {
          Trace.traceBegin(Trace.TRACE_TAG_VIBRATOR, "VibratorService#systemReady");
          try {
              mIm = mContext.getSystemService(InputManager.class);
              mVibrator = mContext.getSystemService(Vibrator.class);
              mSettingObserver = new SettingsObserver(mH);
  
              mPowerManagerInternal = LocalServices.getService(PowerManagerInternal.class);
              mPowerManagerInternal.registerLowPowerModeObserver(
                      new PowerManagerInternal.LowPowerModeListener() {
                          @Override
                          public int getServiceType() {
                              return ServiceType.VIBRATION;
                          }
  
                          @Override
                          public void onLowPowerModeChanged(PowerSaveState result) {
                              updateVibrators();
                          }
              });
  
              mContext.getContentResolver().registerContentObserver(
                      Settings.System.getUriFor(Settings.System.VIBRATE_INPUT_DEVICES),
                      true, mSettingObserver, UserHandle.USER_ALL);
  
              mContext.getContentResolver().registerContentObserver(
                      Settings.System.getUriFor(Settings.System.HAPTIC_FEEDBACK_INTENSITY),
                      true, mSettingObserver, UserHandle.USER_ALL);
  
              mContext.getContentResolver().registerContentObserver(
                      Settings.System.getUriFor(Settings.System.NOTIFICATION_VIBRATION_INTENSITY),
                      true, mSettingObserver, UserHandle.USER_ALL);
  
              mContext.getContentResolver().registerContentObserver(
                      Settings.System.getUriFor(Settings.System.RING_VIBRATION_INTENSITY),
                      true, mSettingObserver, UserHandle.USER_ALL);
  
              mContext.registerReceiver(new BroadcastReceiver() {
                  @Override
                  public void onReceive(Context context, Intent intent) {
                      updateVibrators();
                  }
              }, new IntentFilter(Intent.ACTION_USER_SWITCHED), null, mH);
  
              try {
                  ActivityManager.getService().registerUidObserver(mUidObserver,
                          ActivityManager.UID_OBSERVER_PROCSTATE | ActivityManager.UID_OBSERVER_GONE,
                          ActivityManager.PROCESS_STATE_UNKNOWN, null);
              } catch (RemoteException e) {
                  // ignored; both services live in system_server
              }
  
              updateVibrators();
          } finally {
              Trace.traceEnd(Trace.TRACE_TAG_VIBRATOR);
          }
      }
  
@Override // Binder call
public boolean hasVibrator() {
    return doVibratorExists();
}
private boolean doVibratorExists() {
   - //return vibratorExists();
   + return vibratorExists() && SystemProperties.get("persist.sys.support.vibration", "false").equals("true");
}

```

在10.0的系统中的VibratorService.java中的 hasVibrator()方法中doVibratorExists()的判断是否有振动模式，所以可以在doVibratorExists() 增加自己的 系统属性定义  
 增加设置属性persist.sys.support.vibration的值，根据他的值来判断是否开启振动模式  
 设置属性如下:



```
diff --git a/device/sprd/sharkl5Pro/ums512_2h10/system.prop b/device/sprd/sharkl5Pro/ums512_2h10/system.prop

old mode 100644 (file)

new mode 100755 (executable)

index aa6fba5..0d8c10f

--- a/device/sprd/sharkl5Pro/ums512_1h10/system.prop

+++ b/device/sprd/sharkl5Pro/ums512_1h10/system.prop

@@ -69,3 +69,4 @@ ro.audio.offload_wakelock=0

 

 #add for lowpower vowifi

 persist.dbg.lowpower_vowifi=0

+persist.sys.support.vibration=true

```




