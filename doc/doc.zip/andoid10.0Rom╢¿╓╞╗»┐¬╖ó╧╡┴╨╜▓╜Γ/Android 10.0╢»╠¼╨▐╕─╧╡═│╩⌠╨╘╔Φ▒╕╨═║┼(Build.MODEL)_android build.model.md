






定制化开发中设备型号(ro.product.model)的修改，可以在\build\tools\buildinfo.sh中修改，不过这种方式只能写死了，  
 所以需要根据不同情况动态修改设备型号 就得修改ro.product.model的值即可:


在系统api中  
 Build.java 来获取系统型号 版本号 等属性值


现在来看Build.java的源码



```
 /** Either a changelist number, or a label like "M4-rc20". */
    public static final String ID = getString("ro.build.id");

    /** A build ID string meant for displaying to the user */
    public static final String DISPLAY = getString("ro.build.display.id");

    /** The name of the overall product. */
    public static final String PRODUCT = getString("ro.product.name");

    /** The name of the industrial design. */
    public static final String DEVICE = getString("ro.product.device");

    /** The name of the underlying board, like "goldfish". */
    public static final String BOARD = getString("ro.product.board");

    /**
     * The name of the instruction set (CPU type + ABI convention) of native code.
     *
     * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
     */
    @Deprecated
    public static final String CPU_ABI;

    /**
     * The name of the second instruction set (CPU type + ABI convention) of native code.
     *
     * @deprecated Use {@link #SUPPORTED\_ABIS} instead.
     */
    @Deprecated
    public static final String CPU_ABI2;

    /** The manufacturer of the product/hardware. */
    public static final String MANUFACTURER = getString("ro.product.manufacturer");

    /** The consumer-visible brand with which the product/hardware will be associated, if any. */
    public static final String BRAND = getString("ro.product.brand");

    public static final String MODEL = getString("ro.product.model");


    /** The system bootloader version number. */
    public static final String BOOTLOADER = getString("ro.bootloader");

```

最终发现Build.MODEL 就是系统型号  
 public static final String MODEL = getString(“ro.product.model”);  
 而MODEL 通过ro.product.model 来获取系统型号的属性


所以就在系统启动的时候来修改这个值 获取点击进入Settings 系统设置的时候来修改这个值即可:


1.进入Settings时修改:  
 在进入每个app时都会调用StartActivity方法  
 在Activity.java中的startActivity(Intent intent, @Nullable Bundle options) 方法  
 路径:framework/base/core/java/android/app/Activity.java  
 接下来看这个方法如下:



```
@Override
    public void startActivity(Intent intent, @Nullable Bundle options) {
        if (options != null) {
            startActivityForResult(intent, -1, options);
        } else {
            // Note we want to go through this call for compatibility with
            // applications that may have overridden the method.
            startActivityForResult(intent, -1);
        }
    }

```

所以就在这个方法里面  
 根据intent来获取当前app的包名 然后设置Build.MODEL 型号的值  
 修改如下:


Build.java 中修改如下:



```
/**
*@see
*/
public static String MODEL = getString("persist.sys.product.model");
/**
*@see
*/
public static void setModel(String newModel){
       MODEL = newModel;
       SystemProperties.set("persist.sys.product.model", newModel);
}
/**
*@see
*/
public static String getModel(){
     return  SystemProperties.get("persist.sys.product.model", "unkown");
}

```

通过修改MODEL的值来修改



```
 @Override
    public void startActivity(Intent intent, @Nullable Bundle options) {
	+	 ComponentName cmp = intent.getComponent ();
         +   if(cmp != null){
	+		  Log.d("Activity","Build Model packagename:"+ cmp.getPackageName());
        +      if(cmp.getPackageName().equals("com.android.settings") ){
         +       if(!Build.getModel().equals("UP12")){
         +          Build.setModel("UP12");
          +      }
          +    }
           +   Log.d("Activity","Build Model is set2 to "+ Build.MODEL);
          +  }   
        if (options != null) {
            startActivityForResult(intent, -1, options);
        } else {
            // Note we want to go through this call for compatibility with
            // applications that may have overridden the method.
            startActivityForResult(intent, -1);
        }
    }

```

如果出现修改失败 请移步这里 继续这步修改  
 [Android 10.0 动态修改ro开头系统属性的值](https://blog.csdn.net/baidu_41666295/article/details/125712032)


2.第二种方法 就是在开机启动完成后  
 来设置系统属性型号的值


在系统开机完成后 PMS 都会调用  
 public void systemBooted()  
 所以可以在这里添加  
 路径为:frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java



```
/** {@inheritDoc} */
@Override
public void systemBooted() {
    bindKeyguard();
    synchronized (mLock) {
        mSystemBooted = true;
        if (mSystemReady) {
            mKeyguardDelegate.onBootCompleted();
        }
    }
    startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
    finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
    screenTurningOn(null);
    screenTurnedOn();
   // 添加代码
           +       if(!Build.getModel().equals("UP12")){
     +          Build.setModel("UP12");
      +      }
}

```




