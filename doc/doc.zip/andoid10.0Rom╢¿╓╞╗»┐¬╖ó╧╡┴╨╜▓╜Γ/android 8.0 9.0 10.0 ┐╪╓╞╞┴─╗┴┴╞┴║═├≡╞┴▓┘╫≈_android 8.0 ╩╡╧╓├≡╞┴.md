






在8.0以后系统对于屏幕亮灭屏做了限制，直接调用亮屏和灭屏的方法就调不到了，  
 接下来就来看PowerManage.java类 这个是一个电源管理的服务类


PowerManager的几个实用方法



```
boolean PowerManager::isScreenOn ()

```

判断屏幕是否亮着（不管是暗的dimed还是正常亮度），在API20被弃用，推荐boolean PowerManager::isInteractive ()



```
void PowerManager::goToSleep(long time)

```

time是时间戳，一般是System.currentTimeMillis()+timeDelay。强制系统立刻休眠，需要Manifest中添加权限"android.permission.DEVICE\_POWER"。按下电源键锁屏时调用的就是这个方法。



```
void PowerManager::wakeUp(long time)

```

与上面对应。参数含义，所需权限与上同。按下电源键解锁屏幕时调用的就是这个方法。



```
void PowerManager::reboot()

```

重启手机，reason是要传给linux内核的参数，比如“recovery”重启进recovery模式，“fastboot”重启进fastboot模式。需要权限"android.permission.REBOOT"。


通过上面的方法可以看到还是可以亮屏和灭屏的 但是现在方法被隐藏了 直接调用调不到了，  
 但是通过powerManager反射还是可以实现亮灭屏操作的 goToSleep实现灭屏 通过 wakeup实现亮屏


1.灭屏



```
 /**
     * @see
     */
    public void turnOffScreen(){
        //WindowManagerGlobal.getWindowManagerService().lockNow(null /* options */);
        PowerManager powerManager= (PowerManager)mContext.getSystemService(Context.POWER_SERVICE);
        try {
            powerManager.getClass().getMethod("goToSleep", new Class[]{long.class}).invoke(powerManager, SystemClock.uptimeMillis());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

```

2.亮屏:



```
  /**
     * @see
     */
    public void turnOnScreen(){
        try {
//            //屏锁管理器
//            KeyguardManager km = (KeyguardManager) mContext.getSystemService(Context.KEYGUARD_SERVICE);
//            KeyguardManager.KeyguardLock kl = km.newKeyguardLock("unLock");
//            //解锁
//            kl.disableKeyguard();
//            //获取电源管理器对象
//            PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
//            //获取PowerManager.WakeLock对象,后面的参数|表示同时传入两个值,最后的是LogCat里用的Tag
//            PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.SCREEN_DIM_WAKE_LOCK, SuperPower.class.getSimpleName());
//            //点亮屏幕
//            wl.acquire();
//            //释放
//            wl.release();
            PowerManager powerManager= (PowerManager)mContext.getSystemService(Context.POWER_SERVICE);
            try {
                powerManager.getClass().getMethod("wakeUp", new Class[]{long.class}).invoke(powerManager, SystemClock.uptimeMillis());
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

```




