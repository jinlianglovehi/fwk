






### 1.概述


状态栏系统时间默认显示在左边和通知显示在一起，但是客户想修改显示位置，想显示在中间，所以就要修改SystemUI  
 的Clock.java 文件这个就是管理显示时间的,居中显示的话就得修改布局文件了  
 效果图如下:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/1bda4ca031db4a9fb5e2d1688aae2935.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_20,color_FFFFFF,t_70,g_se,x_16#pic_center)


### 2.状态栏居中显示时间和修改时间显示样式核心类



```
frameworks/base/packages/SystemUI/res/layout/status_bar.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/Clock.java

```

### 3.状态栏居中显示时间和修改时间显示样式核心功能分析和实现


关于SystemUI的状态栏布局就是在status\_bar.xml中，接下来  
 就来看status\_bar.xml中关于时钟的布局，然后修改居中布局  
 frameworks/base/packages/SystemUI/res/layout/status\_bar.xml


### 3.1status\_bar.xml关于时钟布局分析



```
<com.android.systemui.statusbar.phone.PhoneStatusBarView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res/com.android.systemui"
    android:layout_width="match\_parent"
    android:layout_height="@dimen/status\_bar\_height"
    android:id="@+id/status\_bar"
    android:background="@drawable/system\_bar\_background"
    android:orientation="vertical"
    android:focusable="false"
    android:descendantFocusability="afterDescendants"
    android:accessibilityPaneTitle="@string/status\_bar"
    >

    <ImageView
        android:id="@+id/notification\_lights\_out"
        android:layout_width="@dimen/status\_bar\_icon\_size"
        android:layout_height="match\_parent"
        android:paddingStart="@dimen/status\_bar\_padding\_start"
        android:paddingBottom="2dip"
        android:src="@drawable/ic\_sysbar\_lights\_out\_dot\_small"
        android:scaleType="center"
        android:visibility="gone"
        />

    <LinearLayout android:id="@+id/status\_bar\_contents"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:paddingStart="@dimen/status\_bar\_padding\_start"
        android:paddingEnd="@dimen/status\_bar\_padding\_end"
        android:paddingTop="@dimen/status\_bar\_padding\_top"
        android:orientation="horizontal"
        >
        // 放大比重 原来的由1修改为2
        <FrameLayout
            android:layout_height="match\_parent"
            android:layout_width="0dp"
            android:layout_weight="2">

            <include layout="@layout/heads\_up\_status\_bar\_layout" />

            <!-- The alpha of the left side is controlled by PhoneStatusBarTransitions, and the
             individual views are controlled by StatusBarManager disable flags DISABLE_CLOCK and
             DISABLE_NOTIFICATION_ICONS, respectively -->
            <LinearLayout
                android:id="@+id/status\_bar\_left\_side"
                android:layout_height="match\_parent"
                android:layout_width="match\_parent"
                android:clipChildren="false"
            >
                <ViewStub
                    android:id="@+id/operator\_name"
                    android:layout_width="wrap\_content"
                    android:layout_height="match\_parent"
                    android:layout="@layout/operator\_name" />
                //调整原来的布局位置 所以要注释掉
                <!--com.android.systemui.statusbar.policy.Clock
                    android:id="@+id/clock"
                    android:layout_width="wrap\_content"
                    android:layout_height="match\_parent"
                    android:textAppearance="@style/TextAppearance.StatusBar.Clock"
                    android:singleLine="true"
                    android:paddingStart="@dimen/status\_bar\_left\_clock\_starting\_padding"
                    android:paddingEnd="@dimen/status\_bar\_left\_clock\_end\_padding"
                    android:gravity="center\_vertical|start"
                /-->

                <com.android.systemui.statusbar.AlphaOptimizedFrameLayout
                    android:id="@+id/notification\_icon\_area"
                    android:layout_width="0dp"
                    android:layout_height="match\_parent"
                    android:layout_weight="1"
                    android:orientation="horizontal"
                    android:clipChildren="false"/>

            </LinearLayout>
            
            // Clock位置的调整 放在通知栏的后面，然后属性居中显示
            // add code start 
		<com.android.systemui.statusbar.policy.Clock
			android:id="@+id/clock"
			android:layout_width="wrap\_content"
			android:layout_height="match\_parent"
			android:textAppearance="@style/TextAppearance.StatusBar.Clock"
			android:singleLine="true"
			android:maxEms="50"
			android:gravity="center\_horizontal"/>
        // add code end 
            
        </FrameLayout>

        <!-- Space should cover the notch (if it exists) and let other views lay out around it -->
        <android.widget.Space
            android:id="@+id/cutout\_space\_view"
            android:layout_width="0dp"
            android:layout_height="match\_parent"
            android:gravity="center\_horizontal|center\_vertical"
        />

        <com.android.systemui.statusbar.AlphaOptimizedFrameLayout
            android:id="@+id/centered\_icon\_area"
            android:layout_width="wrap\_content"
            android:layout_height="match\_parent"
            android:orientation="horizontal"
            android:clipChildren="false"
            android:gravity="center\_horizontal|center\_vertical"/>

        <com.android.keyguard.AlphaOptimizedLinearLayout android:id="@+id/system\_icon\_area"
            android:layout_width="0dp"
            android:layout_height="match\_parent"
            android:layout_weight="1"
            android:orientation="horizontal"
            android:gravity="center\_vertical|end"
            >

            <include layout="@layout/system\_icons" />
        </com.android.keyguard.AlphaOptimizedLinearLayout>
    </LinearLayout>

    <ViewStub
        android:id="@+id/emergency\_cryptkeeper\_text"
        android:layout_width="wrap\_content"
        android:layout_height="match\_parent"
        android:layout="@layout/emergency\_cryptkeeper\_text"
    />

</com.android.systemui.statusbar.phone.PhoneStatusBarView>

```

在status.xml中，com.android.systemui.statusbar.policy.Clock就是关于时钟的布局，首选要修改时钟和通知图标区域的所占比例  
 主要就是修改Clock布局的位置，然后居中显示，设置clock布局居中增加属性


### 3.2Clock.java 关于时间样式的修改


SystemUI中状态栏的Clock的时钟就是  
 路径:frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/Clock.java  
 接下来来看源码部分



```
@Override
public void onDensityOrFontScaleChanged() {
    FontSizeUtils.updateFontSize(this, R.dimen.status_bar_clock_size);
    setPaddingRelative(
            mContext.getResources().getDimensionPixelSize(
                    R.dimen.status_bar_clock_starting_padding),
            0,
            mContext.getResources().getDimensionPixelSize(
                    R.dimen.status_bar_clock_end_padding),
            0);
}

```

在Clock.java中onDensityOrFontScaleChanged()就是设置关于时钟字体和padding的布局参数的、  
 所以在代码中关于布局显示



```
setPaddingRelative(
                mContext.getResources().getDimensionPixelSize(
                        R.dimen.status_bar_clock_starting_padding),
                0,
                mContext.getResources().getDimensionPixelSize(
                        R.dimen.status_bar_clock_end_padding),
                0);

```

时钟布局显示不居中，修改为:



```
 @Override
    public void onDensityOrFontScaleChanged() {
        FontSizeUtils.updateFontSize(this, R.dimen.status_bar_clock_size);
        /*setPaddingRelative(
                mContext.getResources().getDimensionPixelSize(
                        R.dimen.status_bar_clock_starting_padding),
                0,
                mContext.getResources().getDimensionPixelSize(
                        R.dimen.status_bar_clock_end_padding),
                0);*/
		setPaddingRelative(750,0,0,0);
    }

    @Override
    public void dispatchDemoCommand(String command, Bundle args) {
        if (!mDemoMode && command.equals(COMMAND_ENTER)) {
            mDemoMode = true;
        } else if (mDemoMode && command.equals(COMMAND_EXIT)) {
            mDemoMode = false;
            updateClock();
        } else if (mDemoMode && command.equals(COMMAND_CLOCK)) {
            String millis = args.getString("millis");
            String hhmm = args.getString("hhmm");
            if (millis != null) {
                mCalendar.setTimeInMillis(Long.parseLong(millis));
            } else if (hhmm != null && hhmm.length() == 4) {
                int hh = Integer.parseInt(hhmm.substring(0, 2));
                int mm = Integer.parseInt(hhmm.substring(2));
                boolean is24 = DateFormat.is24HourFormat(getContext(), mCurrentUserId);
                if (is24) {
                    mCalendar.set(Calendar.HOUR_OF_DAY, hh);
                } else {
                    mCalendar.set(Calendar.HOUR, hh);
                }
                mCalendar.set(Calendar.MINUTE, mm);
            }
            setText(getSmallTime());
            setContentDescription(mContentDescriptionFormat.format(mCalendar.getTime()));
        }
    }

```

在dispatchDemoCommand(String command, Bundle args)方法  
 代码中 setText();来显示时间 而时间又是由getSmallTime()来计算的  
 接下来 看getSmallTime();



```
private final CharSequence getSmallTime() {
        Context context = getContext();
        boolean is24 = DateFormat.is24HourFormat(context, mCurrentUserId);
        LocaleData d = LocaleData.get(context.getResources().getConfiguration().locale);

        final char MAGIC1 = '\uEF00';
        final char MAGIC2 = '\uEF01';

        SimpleDateFormat sdf;
        String format = mShowSeconds
                ? is24 ? d.timeFormat_Hms : d.timeFormat_hms
                : is24 ? d.timeFormat_Hm : d.timeFormat_hm;
        if (!format.equals(mClockFormatString)) {
            mContentDescriptionFormat = new SimpleDateFormat(format);
            /*
             * Search for an unquoted "a" in the format string, so we can
             * add dummy characters around it to let us find it again after
             * formatting and change its size.
             */
            if (mAmPmStyle != AM_PM_STYLE_NORMAL) {
                int a = -1;
                boolean quoted = false;
                for (int i = 0; i < format.length(); i++) {
                    char c = format.charAt(i);

                    if (c == '\'') {
                        quoted = !quoted;
                    }
                    if (!quoted && c == 'a') {
                        a = i;
                        break;
                    }
                }

                if (a >= 0) {
                    // Move a back so any whitespace before AM/PM is also in the alternate size.
                    final int b = a;
                    while (a > 0 && Character.isWhitespace(format.charAt(a-1))) {
                        a--;
                    }
                    format = format.substring(0, a) + MAGIC1 + format.substring(a, b)
                        + "a" + MAGIC2 + format.substring(b + 1);
                }
            }
            mClockFormat = sdf = new SimpleDateFormat(format);
            mClockFormatString = format;
        } else {
            sdf = mClockFormat;
        }
        String result = sdf.format(mCalendar.getTime());

        /* UNISOC: 1072085 clock add am/pm @{ */
        if(KeyguardSupportAmPm.getInstance(mContext).isEnabled()) {
            mAmPmStyle = AM_PM_STYLE_SMALL;
        }
        /* @} */

        if (mAmPmStyle != AM_PM_STYLE_NORMAL) {
            int magic1 = result.indexOf(MAGIC1);
            int magic2 = result.indexOf(MAGIC2);
            if (magic1 >= 0 && magic2 > magic1) {
                SpannableStringBuilder formatted = new SpannableStringBuilder(result);
                if (mAmPmStyle == AM_PM_STYLE_GONE) {
                    formatted.delete(magic1, magic2+1);
                } else {
                    if (mAmPmStyle == AM_PM_STYLE_SMALL) {
                        CharacterStyle style = new RelativeSizeSpan(0.7f);
                        formatted.setSpan(style, magic1, magic2,
                                          Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                    }
                    formatted.delete(magic2, magic2 + 1);
                    formatted.delete(magic1, magic1 + 1);
                }
                return formatted;
            }
        }

        return result;

    }

```

在getSmallTime()设置当前时间的样式，所以要修改成自己需要的时间样式比如年月日星期这样的日期格式就需要将  
 时间样式修改为:



```
    private final CharSequence getSmallTime() {
        Context context = getContext();
        boolean is24 = DateFormat.is24HourFormat(context, mCurrentUserId);
        LocaleData d = LocaleData.get(context.getResources().getConfiguration().locale);
    +    onDensityOrFontScaleChanged();
        final char MAGIC1 = '\uEF00';
        final char MAGIC2 = '\uEF01';

        SimpleDateFormat sdf;
        String format = mShowSeconds
                ? is24 ? d.timeFormat_Hms : d.timeFormat_hms
                : is24 ? d.timeFormat_Hm : d.timeFormat_hm;
        if (!format.equals(mClockFormatString)) {
            mContentDescriptionFormat = new SimpleDateFormat(format);
            /*
             * Search for an unquoted "a" in the format string, so we can
             * add dummy characters around it to let us find it again after
             * formatting and change its size.
             */
            if (mAmPmStyle != AM_PM_STYLE_NORMAL) {
                int a = -1;
                boolean quoted = false;
                for (int i = 0; i < format.length(); i++) {
                    char c = format.charAt(i);

                    if (c == '\'') {
                        quoted = !quoted;
                    }
                    if (!quoted && c == 'a') {
                        a = i;
                        break;
                    }
                }

                if (a >= 0) {
                    // Move a back so any whitespace before AM/PM is also in the alternate size.
                    final int b = a;
                    while (a > 0 && Character.isWhitespace(format.charAt(a-1))) {
                        a--;
                    }
-                    format = format.substring(0, a) + MAGIC1 + format.substring(a, b)
-                        + "a" + MAGIC2 + format.substring(b + 1);
+                    format = format.substring(0, a) + format.substring(a, b)
+                        + "a" + format.substring(b + 1);
                }
            }
            mClockFormat = sdf = new SimpleDateFormat(format);
            mClockFormatString = format;
        } else {
            sdf = mClockFormat;
        }
        String result = sdf.format(mCalendar.getTime());
   +     String str=null;
        /* UNISOC: 1072085 clock add am/pm @{ */
        if(KeyguardSupportAmPm.getInstance(mContext).isEnabled()) {
            -            mAmPmStyle = AM_PM_STYLE_SMALL;
            +            mAmPmStyle = AM_PM_STYLE_NORMAL;
        }
        /* @} */
        +     long time=System.currentTimeMillis();
        +    Date date=new Date(time);
        +    SimpleDateFormat format2=new SimpleDateFormat("yyyy年MM月dd日 EEEE");

            int magic1 = result.indexOf(MAGIC1);
            int magic2 = result.indexOf(MAGIC2);
            if (magic1 >= 0 && magic2 > magic1) {
                SpannableStringBuilder formatted = new SpannableStringBuilder(result);
                if (mAmPmStyle == AM_PM_STYLE_GONE) {
                    formatted.delete(magic1, magic2+1);
                } else {
                    if (mAmPmStyle == AM_PM_STYLE_SMALL) {
                        CharacterStyle style = new RelativeSizeSpan(0.7f);
                        formatted.setSpan(style, magic1, magic2,
                                          Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                    }
                    formatted.delete(magic2, magic2 + 1);
                    formatted.delete(magic1, magic1 + 1);
                }
                //return formatted;
              // add code start
		str = formatted+"";
                if(str.contains("上午")){
                    str=str.substring(2)+" AM";
                }else if(str.contains("下午")){
                    str=str.substring(2)+" PM";
                }              
                return format2.format(date)+" "+str;
               // add code end
            }
        // add code start
     +       str = result;
     +       if(str.contains("上午")){
     +           str=str.substring(2)+" AM";
     +       }else if(str.contains("下午")){
    +            str=str.substring(2)+" PM";
      +      }
      +      return format2.format(date)+" "+str;
 // add code end
//        return result;

    }

```

通过上面的时间格式的修改和时间布局的居中就实现了功能需求  
 修改git记录:



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/Clock.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/Clock.java
@@ -37,7 +37,7 @@ import android.util.AttributeSet;
 import android.view.Display;
 import android.view.View;
 import android.widget.TextView;
-
+import java.util.Date;
 import com.android.settingslib.Utils;
 import com.android.systemui.DemoMode;
 import com.android.systemui.Dependency;
@@ -330,13 +330,14 @@ public class Clock extends TextView implements DemoMode, Tunable, CommandQueue.C
     @Override
     public void onDensityOrFontScaleChanged() {
         FontSizeUtils.updateFontSize(this, R.dimen.status_bar_clock_size);
-        setPaddingRelative(
+        /*setPaddingRelative(
                 mContext.getResources().getDimensionPixelSize(
                         R.dimen.status_bar_clock_starting_padding),
                 0,
                 mContext.getResources().getDimensionPixelSize(
                         R.dimen.status_bar_clock_end_padding),
-                0);
+                0);*/
+               setPaddingRelative(750,0,0,0);
     }
 
     /**
@@ -385,7 +386,7 @@ public class Clock extends TextView implements DemoMode, Tunable, CommandQueue.C
         Context context = getContext();
         boolean is24 = DateFormat.is24HourFormat(context, mCurrentUserId);
         LocaleData d = LocaleData.get(context.getResources().getConfiguration().locale);
-
+        onDensityOrFontScaleChanged();
         final char MAGIC1 = '\uEF00';
         final char MAGIC2 = '\uEF01';
 
@@ -421,8 +422,8 @@ public class Clock extends TextView implements DemoMode, Tunable, CommandQueue.C
                     while (a > 0 && Character.isWhitespace(format.charAt(a-1))) {
                         a--;
                     }
-                    format = format.substring(0, a) + MAGIC1 + format.substring(a, b)
-                        + "a" + MAGIC2 + format.substring(b + 1);
+                    format = format.substring(0, a) + format.substring(a, b)
+                        + "a" + format.substring(b + 1);
                 }
             }
             mClockFormat = sdf = new SimpleDateFormat(format);
@@ -431,14 +432,16 @@ public class Clock extends TextView implements DemoMode, Tunable, CommandQueue.C
             sdf = mClockFormat;
         }
         String result = sdf.format(mCalendar.getTime());
-
+        String str=null;
         /* UNISOC: 1072085 clock add am/pm @{ */
         if(KeyguardSupportAmPm.getInstance(mContext).isEnabled()) {
-            mAmPmStyle = AM_PM_STYLE_SMALL;
+            mAmPmStyle = AM_PM_STYLE_NORMAL;
         }
         /* @} */
+            long time=System.currentTimeMillis();
+            Date date=new Date(time);
+            SimpleDateFormat format2=new SimpleDateFormat("yyyy年MM月dd日 EEEE");
 
-        if (mAmPmStyle != AM_PM_STYLE_NORMAL) {
             int magic1 = result.indexOf(MAGIC1);
             int magic2 = result.indexOf(MAGIC2);
             if (magic1 >= 0 && magic2 > magic1) {
@@ -454,11 +457,25 @@ public class Clock extends TextView implements DemoMode, Tunable, CommandQueue.C
                     formatted.delete(magic2, magic2 + 1);
                     formatted.delete(magic1, magic1 + 1);
                 }
-                return formatted;
+                //return formatted;
+                               str = formatted+"";
+                if(str.contains("上午")){
+                    str=str.substring(2)+" AM";
+                }else if(str.contains("下午")){
+                    str=str.substring(2)+" PM";
+                }              
+                return format2.format(date)+" "+str;
             }
-        }
+        
+            str = result;
+            if(str.contains("上午")){
+                str=str.substring(2)+" AM";
+            }else if(str.contains("下午")){
+                str=str.substring(2)+" PM";
+            }
+            return format2.format(date)+" "+str;
 
-        return result;
+//        return result;
 
     }

```

编译SystemUI 发现时间已经居中显示了





