






### 1.概述


在10.0的系统产品开发中，在定制化银行设备时，需要设备开机后打开热点，然后监听顾客连接设备和断开设备  
 那么SoftApManager.java 就主要负责热点连接的管理，就需要分析它的相关热点的管理源码了


如图所示：  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/5606642d8d984cf1bfa739e952f12966.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_20,color_FFFFFF,t_70,g_se,x_16#pic_center)


### 2. 监听Soft Ap热点连接与断开的核心类



```
/frameworks/opt/net/wifi/service/java/com/android/server/wifi/SoftApManager.java
/packages/modules/NetworkStack/src/com/android/server/NetworkStackService.java

```

### 3. 监听Soft Ap热点连接与断开核心功能分析和实现


通过上文分析得知 SoftApManager.java负责管理系统热点  
 路径：  
 /frameworks/opt/net/wifi/service/java/com/android/server/wifi/SoftApManager.java


### 3.1SoftApManager.java热点管理分析



```
  /**
     * Listener for soft AP events.
     */
    private final SoftApListener mSoftApListener = new SoftApListener() {

        @Override
        public void onFailure() {
            mStateMachine.sendMessage(SoftApStateMachine.CMD_FAILURE);
        }

        @Override
        public void onNumAssociatedStationsChanged(int numStations) {
            mStateMachine.sendMessage(
                    SoftApStateMachine.CMD_NUM_ASSOCIATED_STATIONS_CHANGED, numStations);
        }

        @Override
        public void onSoftApChannelSwitched(int frequency, int bandwidth) {
            mStateMachine.sendMessage(
                    SoftApStateMachine.CMD_SOFT_AP_CHANNEL_SWITCHED, frequency, bandwidth);
        }

        @Override
        public void onSoftApConnectionEvent(String mac) {
            //当有设备连接热点时，发送连接事件,然后由processMessage进行处理
            mStateMachine.sendMessage(
                    SoftApStateMachine.SOFTAP_STA_CONNECTED_EVENT, mac);
        }

        @Override
        public void onSoftApDisconnectionEvent(String mac) {
           //当有设备连接热点时，发送断开事件，然后由processMessage进行处理
            mStateMachine.sendMessage(
                    SoftApStateMachine.SOFTAP_STA_DISCONNECTED_EVENT, mac);
        }
    };

```

在SoftApManager.java中的mSoftApListener 中  
 mSoftApListener 即为热点连接设备的事件回调  
 所以需要分析回调事件中对热点的管理



```
  /**
     * Start a soft AP instance with the given configuration.
     * @param config AP configuration
     * @return integer result code
     */
    private int startSoftAp(WifiConfiguration config) {
        if (config == null || config.SSID == null) {
            Log.e(TAG, "Unable to start soft AP without valid configuration");
            return ERROR_GENERIC;
        }
        if (mWifiApClientStats != null && mWifiApClientStats.isWhiteListEnabled()) {
             config.macAddrAcl = 1;
        } else {
             config.macAddrAcl = 0;
        }

        // UNISOC: Try to get saved countrycode if current country code empty
        if (TextUtils.isEmpty(mCountryCode)) {
            mCountryCode = mFrameworkFacade.getStringSetting(mContext,
                Settings.Global.WIFI_COUNTRY_CODE);
        }

        // Setup country code
        if (TextUtils.isEmpty(mCountryCode)) {
            if (config.apBand == WifiConfiguration.AP_BAND_5GHZ) {
                // Country code is mandatory for 5GHz band.
                Log.e(TAG, "Invalid country code, required for setting up "
                        + "soft ap in 5GHz");
                return ERROR_GENERIC;
            }
            // Absence of country code is not fatal for 2Ghz & Any band options.
        } else if (!mWifiNative.setCountryCodeHal(
                mApInterfaceName, mCountryCode.toUpperCase(Locale.ROOT))) {
            if (config.apBand == WifiConfiguration.AP_BAND_5GHZ) {
                // Return an error if failed to set country code when AP is configured for
                // 5GHz band.
                Log.e(TAG, "Failed to set country code, required for setting up "
                        + "soft ap in 5GHz");
                return ERROR_GENERIC;
            }
            // Failure to set country code is not fatal for 2Ghz & Any band options.
        }

        // Make a copy of configuration for updating AP band and channel.
        WifiConfiguration localConfig = new WifiConfiguration(config);

        int result = ApConfigUtil.updateApChannelConfig(
                mWifiNative, mCountryCode,
                mWifiApConfigStore.getAllowed2GChannel(), localConfig);

        if (result != SUCCESS) {
            Log.e(TAG, "Failed to update AP band and channel");
            return result;
        } else {
            if (localConfig.apBand == WifiConfiguration.AP_BAND_5GHZ && mCountryCode != null) {
                getSoftApSupportChannels();
            }
        }

        if (localConfig.hiddenSSID) {
            Log.d(TAG, "SoftAP is a hidden network");
        }
        if (!mWifiNative.startSoftAp(mApInterfaceName, localConfig, mSoftApListener)) {
            Log.e(TAG, "Soft AP start failed");
            return ERROR_GENERIC;
        }
        mStartTimestamp = SystemClock.elapsedRealtime();
        Log.d(TAG, "Soft AP is started");

        return SUCCESS;
    }

```

在startSoftAp(WifiConfiguration config)中  
 在打开热点的时候注册回调函数


SOFTAP\_STA\_CONNECTED\_EVENT android设备连接热点  
 SOFTAP\_STA\_DISCONNECTED\_EVENT: android 设备断开热点



```
@Override
            public boolean processMessage(Message message) {
                String macStr = "";
                switch (message.what) {
                    case CMD_NUM_ASSOCIATED_STATIONS_CHANGED:
                        if (message.arg1 < 0) {
                            Log.e(TAG, "Invalid number of associated stations: " + message.arg1);
                            break;
                        }
                        //Log.d(TAG, "Setting num stations on CMD\_NUM\_ASSOCIATED\_STATIONS\_CHANGED");
                        //setNumAssociatedStations(message.arg1);
                        break;
                    case CMD_SOFT_AP_CHANNEL_SWITCHED:
                        mReportedFrequency = message.arg1;
                        mReportedBandwidth = message.arg2;
                        Log.d(TAG, "Channel switched. Frequency: " + mReportedFrequency
                                + " Bandwidth: " + mReportedBandwidth);
                        mWifiMetrics.addSoftApChannelSwitchedEvent(mReportedFrequency,
                                mReportedBandwidth, mMode);
                        updateUserBandPreferenceViolationMetricsIfNeeded();
                        break;
                    case CMD_TIMEOUT_TOGGLE_CHANGED:
                        boolean isEnabled = (message.arg1 == 1);
                        if (mTimeoutEnabled == isEnabled) {
                            break;
                        }
                        mTimeoutEnabled = isEnabled;
                        if (!mTimeoutEnabled) {
                            cancelTimeoutMessage();
                        }
                        if (mTimeoutEnabled && mNumAssociatedStations == 0) {
                            scheduleTimeoutMessage();
                        }
                        break;
                    case CMD_INTERFACE_STATUS_CHANGED:
                        boolean isUp = message.arg1 == 1;
                        onUpChanged(isUp);
                        break;
                    case CMD_START:
                        // Already started, ignore this command.
                        break;
                    case CMD_NO_ASSOCIATED_STATIONS_TIMEOUT:
                        if (!mTimeoutEnabled) {
                            Log.wtf(TAG, "Timeout message received while timeout is disabled."
                                    + " Dropping.");
                            break;
                        }
                        if (mNumAssociatedStations != 0) {
                            Log.wtf(TAG, "Timeout message received but has clients. Dropping.");
                            break;
                        }
                        Log.i(TAG, "Timeout message received. Stopping soft AP.");
                        updateApState(WifiManager.WIFI_AP_STATE_DISABLING,
                                WifiManager.WIFI_AP_STATE_ENABLED, 0);
                        transitionTo(mIdleState);
                        break;
                    case CMD_INTERFACE_DESTROYED:
                        Log.d(TAG, "Interface was cleanly destroyed.");
                        updateApState(WifiManager.WIFI_AP_STATE_DISABLING,
                                WifiManager.WIFI_AP_STATE_ENABLED, 0);
                        mIfaceIsDestroyed = true;
                        transitionTo(mIdleState);
                        break;
                    case CMD_FAILURE:
                        Log.w(TAG, "hostapd failure, stop and report failure");
                        /* fall through */
                    case CMD_INTERFACE_DOWN:
                        Log.w(TAG, "interface error, stop and report failure");
                        updateApState(WifiManager.WIFI_AP_STATE_FAILED,
                                WifiManager.WIFI_AP_STATE_ENABLED,
                                WifiManager.SAP_START_FAILURE_GENERAL);
                        updateApState(WifiManager.WIFI_AP_STATE_DISABLING,
                                WifiManager.WIFI_AP_STATE_FAILED, 0);
                        mWifiInjector.getWifiController().sendMessage(CMD_RESTART_AP);
                        transitionTo(mIdleState);
                        break;
                   case SOFTAP_STA_CONNECTED_EVENT:
                        macStr = (String)message.obj;
                        //showToast("Station: " + macStr + " now is connected!");
                        if (DBG) log("Soft AP Connected Station: " + macStr);
                        if(mConnectedStations.equals("") ) {
                            mConnectedStations = macStr;
                        } else {
                            if (mConnectedStations.contains(macStr)) {
                                loge("Soft AP Connected Station: " + macStr + " already saved!");
                            } else {
                                mConnectedStations += (" " + macStr);
                            }
                        }
                        if (mWifiApClientStats != null) {
                            mWifiApClientStats.addOrUpdateClientInfoList(mConnectedStations);
                        }
                        List<String> mConnectedStationsDetail = mWifiApClientStats.getStaClientInfoList();
                        setNumAssociatedStations(mConnectedStationsDetail.size());
                        sendSoftApConnectionChangedBroadcast();
                        break;
                    case SOFTAP_STA_DISCONNECTED_EVENT:
                        macStr = (String)message.obj;
                        //showToast("Station: " + macStr + " now is disconnected!");
                        if (DBG) log("Soft AP Disconnected Station: "+ macStr);
                        if (mConnectedStations.contains(macStr) ) {
                            String[] dataTokens = mConnectedStations.split(" ");
                            mConnectedStations = "";
                            for (String token : dataTokens) {
                                if (token.equals(macStr)) {
                                    continue;
                                }
                                if(mConnectedStations.equals("") ) {
                                    mConnectedStations = token;
                                } else {
                                    mConnectedStations +=  (" " + token);
                                }
                            }
                        }
                        if (mWifiApClientStats != null) {
                            mWifiApClientStats.addOrUpdateClientInfoList(mConnectedStations);
                        }
                        List<String> mConnectedStationsDetailList = mWifiApClientStats.getStaClientInfoList();
                        setNumAssociatedStations(mConnectedStationsDetailList.size());
                        sendSoftApConnectionChangedBroadcast();
                        break;
                    default:
                        return NOT_HANDLED;
                }
                return HANDLED;
            }
        }

```

### 3.2 NetworkStackService.java关于热点的监听


中回调获取连接热点设备的详细信息


![在这里插入图片描述](https://img-blog.csdnimg.cn/1c7bf991cc8b4785b52ada6e1d95e3ad.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_20,color_FFFFFF,t_70,g_se,x_16#pic_center)



```
  private DhcpServer.ClientInfoCallback mClientInfoCallback = new ClientInfoCallback() {
         @Override
            public void onClientAcked(String hostName, String macAddr, String ipAddr) {
                Log.d(TAG, "onClientAcked: hostName is " + hostName + ", mac is "
                          + macAddr + ", ip is " + ipAddr);
                Intent intent = new Intent(ACTION_SOFTAP_CLIENT_CONNECT);
                intent.putExtra(EXTRA_HOST_NAME, hostName);
                intent.putExtra(EXTRA_MAC_ADDR, macAddr);
                intent.putExtra(EXTRA_IP_ADDR, ipAddr);
                mContext.sendBroadcastAsUser(intent, UserHandle.ALL);
           }

```


```
     };

```

//当检测到有设备连接热点时,打印出设备的详细信息 mac ip hostName等信息，如果要记录详细信息就在此处添加处理函数即可



```
  @Override
    public void makeDhcpServer(@NonNull String ifName, @NonNull DhcpServingParamsParcel params,
            @NonNull IDhcpServerCallbacks cb) throws RemoteException {
        checkNetworkStackCallingPermission();
        updateSystemAidlVersion(cb.getInterfaceVersion());
        final DhcpServer server;
        try {
            server = new DhcpServer(
                    ifName,
                    DhcpServingParams.fromParcelableObject(params),
                    mLog.forSubComponent(ifName + ".DHCP"));
        } catch (DhcpServingParams.InvalidParameterException e) {
            mLog.e("Invalid DhcpServingParams", e);
            cb.onDhcpServerCreated(STATUS_INVALID_ARGUMENT, null);
            return;
        } catch (Exception e) {
            mLog.e("Unknown error starting DhcpServer", e);
            cb.onDhcpServerCreated(STATUS_UNKNOWN_ERROR, null);
            return;
        }
        cb.onDhcpServerCreated(STATUS_SUCCESS, server);

       if (ifName != null && ifName.contains("wlan") && server != null) {
            Log.d(TAG, "makeDhcpServer: call registerClientInfoCallback ");
            server.registerClientInfoCallback(mClientInfoCallback);
        }
    }

```


```
 在 makeDhcpServer中的源码中  注册mClientInfoCallback 回调事件，所以在这里就可以监听到热点的连接和断开事件

```




