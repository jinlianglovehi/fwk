



## 1.概述


  
    在10.0的系统产品开发中,在Launcher3中系统默认是上滑抽屉模式，而产品需求要求修改为单层模式，而在前面两篇文章中已经  
 修改了第一部分第二部分第三部分，接下来要继续修改Launcher3去掉抽屉模式，修改双层为单层系列的第四讲


## 2.Launcher3去掉抽屉模式 双层改成单层系列四的核心类



```
packages/apps/Launcher3/quickstep/src/com/android/launcher3/uioverrides/touchcontrollers/PortraitStatesTouchController.java
packages/apps/Launcher3/src/com/android/launcher3/allapps/AllAppsTransitionController.java
```

## 3.Launcher3去掉抽屉模式 双层改成单层系列四的核心功能分析和实现


## 


在Launcher3中的上滑处理事件中，在通过源码分析得知，在处理手势滑动事件中，像在  
 Hotseat.java里面有onTouchEvent相关的逻辑处理，但是Hotseat.java里面基本没有相关的事件处理逻辑，  
 而在系统中由事件分发的机制我们知道，如果子view不拦截处理事件，则它就会向下传递给父容器处理，  
 Hotseat的父容器就是DragLayer。DragLayer不仅有拖拽事件的处理，还把Hotseat的滑动事件传递给  
 AllAppsTransitionController.java处理，所以说上滑事件也需要在AllAppsTransitionController.java中查看相关  
 的手势事件的处理，接下来分析下相关的源码


##    3.1 AllAppsTransitionController.java关于去掉上滑显示app动画的相关代码分析



```
public class AllAppsTransitionController implements StateHandler, OnDeviceProfileChangeListener {
  
      private static final float SPRING_DAMPING_RATIO = 0.9f;
      private static final float SPRING_STIFFNESS = 600f;
  
      public static final FloatProperty<AllAppsTransitionController> ALL_APPS_PROGRESS =
              new FloatProperty<AllAppsTransitionController>("allAppsProgress") {
  
          @Override
          public Float get(AllAppsTransitionController controller) {
              return controller.mProgress;
          }
  
          @Override
          public void setValue(AllAppsTransitionController controller, float progress) {
              controller.setProgress(progress);
          }
      };
      public AllAppsTransitionController(Launcher l) {
          mLauncher = l;
          mShiftRange = mLauncher.getDeviceProfile().heightPx;
          mProgress = 1f;
  
          mIsDarkTheme = Themes.getAttrBoolean(mLauncher, R.attr.isMainColorDark);
          mIsVerticalLayout = mLauncher.getDeviceProfile().isVerticalBarLayout();
          mLauncher.addOnDeviceProfileChangeListener(this);
      }
         /**
       * Creates an animation which updates the vertical transition progress and updates all the
       * dependent UI using various animation events
       */
      @Override
      public void setStateWithAnimation(LauncherState toState,
              AnimatorSetBuilder builder, AnimationConfig config) {
+        if(BaseFlags.IS_SINGLE_MODEL){
+           return;
+        }
          if (TestProtocol.sDebugTracing) {
              Log.d(TestProtocol.NO_ALLAPPS_EVENT_TAG,
                      "setStateWithAnimation " + toState.getClass().getSimpleName());
          }
          float targetProgress = toState.getVerticalProgress(mLauncher);
          if (Float.compare(mProgress, targetProgress) == 0) {
              setAlphas(toState, config, builder);
              // Fail fast
              onProgressAnimationEnd();
              return;
          }
  
  
  
          setAlphas(toState, config, builder);
      }
```

在AllAppsTransitionController.java中的setStateWithAnimation(LauncherState toState,  
               AnimatorSetBuilder builder, AnimationConfig config)方法中，这里主要是在上层的时候  
 当上滑开始的时候，这里会伴随上滑动作开始有app列表慢慢显示出来，而单层是不需要上滑显示app的动画的  
 所以需要注释掉这些动画就好了


第二部分的修改，关于注释掉设置透明度的相关方法



```
    public void setAlphas(int visibleElements, AnimationConfig config, AnimatorSetBuilder builder) {
          PropertySetter setter = config == null ? NO_ANIM_PROPERTY_SETTER
                  : config.getPropertySetter(builder);
          boolean hasHeaderExtra = (visibleElements & ALL_APPS_HEADER_EXTRA) != 0;
          boolean hasContent = (visibleElements & ALL_APPS_CONTENT) != 0;
  
          Interpolator allAppsFade = builder.getInterpolator(ANIM_ALL_APPS_FADE, LINEAR);
          setter.setViewAlpha(mAppsView.getContentView(), hasContent ? 1 : 0, allAppsFade);
          setter.setViewAlpha(mAppsView.getScrollBar(), hasContent ? 1 : 0, allAppsFade);
          mAppsView.getFloatingHeaderView().setContentVisibility(hasHeaderExtra, hasContent, setter,
                  allAppsFade);
-          mAppsView.getSearchUiManager().setContentVisibility(visibleElements, setter, allAppsFade);
+          //mAppsView.getSearchUiManager().setContentVisibility(visibleElements, setter, allAppsFade);  
          setter.setInt(mScrimView, ScrimView.DRAG_HANDLE_ALPHA,
                  (visibleElements & VERTICAL_SWIPE_INDICATOR) != 0 ? 255 : 0, allAppsFade);
      }
```

在AllAppsTransitionController.java中的setAlphas(int visibleElements, AnimationConfig config, AnimatorSetBuilder builder)中  
 去掉关于设置app上滑时，显示的搜索框相关部分功能


## 3.2 PortraitStatesTouchController.java中关于去掉双层上滑显示app列表的功能



```
  public class PortraitStatesTouchController extends AbstractStateChangeTouchController {
   
      public PortraitStatesTouchController(Launcher l, boolean allowDragToOverview) {
          super(l, SwipeDetector.VERTICAL);
          mOverviewPortraitStateTouchHelper = new PortraitOverviewStateTouchHelper(l);
          mAllowDragToOverview = allowDragToOverview;
      }
    
         @Override
     protected boolean canInterceptTouch(MotionEvent ev) {
         if (mCurrentAnimation != null) {
             if (mFinishFastOnSecondTouch) {
                 // TODO: Animate to finish instead.
                 mCurrentAnimation.skipToEnd();
             }
 
             AllAppsTransitionController allAppsController = mLauncher.getAllAppsController();
             if (ev.getY() >= allAppsController.getShiftRange() * allAppsController.getProgress()) {
                 // If we are already animating from a previous state, we can intercept as long as
                 // the touch is below the current all apps progress (to allow for double swipe).
                  return true;
              }
              // Otherwise, make sure everything is settled and don't intercept so they can scroll
              // recents, dismiss a task, etc.
              if (mAtomicAnim != null) {
                  mAtomicAnim.end();
              }
              return false;
          }
         
          if (AbstractFloatingView.getTopOpenViewWithType(mLauncher, TYPE_ACCESSIBLE) != null) {
              return false;
          }
          return true;
      }
  
      @Override
      protected LauncherState getTargetState(LauncherState fromState, boolean isDragTowardPositive) {
          if (fromState == ALL_APPS && !isDragTowardPositive) {
              // Should swipe down go to OVERVIEW instead?
              return TouchInteractionService.isConnected() ?
                      mLauncher.getStateManager().getLastState() : NORMAL;
          } else if (fromState == OVERVIEW) {
              return isDragTowardPositive ? ALL_APPS : NORMAL;
          } else if (fromState == NORMAL && isDragTowardPositive) {
              int stateFlags = OverviewInteractionState.INSTANCE.get(mLauncher)
                      .getSystemUiStateFlags();
-            return mAllowDragToOverview && TouchInteractionService.isConnected()
+            if(BaseFlags.IS_SINGLE_MODEL){
+                           return mAllowDragToOverview && TouchInteractionService.isConnected()
+                    && (stateFlags & SYSUI_STATE_OVERVIEW_DISABLED) == 0
+                    ? OVERVIEW : NORMAL;
+                       }else{
+                               return mAllowDragToOverview && TouchInteractionService.isConnected()
                     && (stateFlags & SYSUI_STATE_OVERVIEW_DISABLED) == 0
                     ? OVERVIEW : ALL_APPS;
+                       }
          }
          return fromState;
      }
```

在PortraitStatesTouchController.java中的上述代码中可以看出 在canInterceptTouch(MotionEvent ev) 中处理  
 手势触摸上滑事件，而在getTargetState(LauncherState fromState, boolean isDragTowardPositive)中处理  
 上滑是返回ALL\_APPS还是返回NORMAL，返回NORMAL就是不返回数据，所以单层就是返回NORMAL就可以了



