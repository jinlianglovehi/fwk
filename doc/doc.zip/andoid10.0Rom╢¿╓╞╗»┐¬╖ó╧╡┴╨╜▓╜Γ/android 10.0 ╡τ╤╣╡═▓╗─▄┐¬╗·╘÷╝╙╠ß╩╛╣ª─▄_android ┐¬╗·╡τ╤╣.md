






最近客户要求在电压过低不能开机时，要增加个提示，告诉用户电压过低，那么在开机所需要做大多数事情 都是在  
 bsp\bootloader\u-boot下处理的，所以增加功能就需要在这里  
 U-boot在上电后被SPL从NAND中拷贝至SDRAM,然后执行board\_init\_f 跳转到board\_init\_r  
 接下来看下board.c的board\_init\_r



```
bsp\bootloader\u-boot15\arch\arm\lib\board.c
void board_init_r(gd_t *id, ulong dest_addr)
{
	ulong malloc_start;
#if !defined(CONFIG\_SYS\_NO\_FLASH)
	ulong flash_size;
#endif

#if defined(CONFIG\_SPRD\_LOG) && defined(CONFIG\_DTS\_MEM\_LAYOUT)
	get_log_buffer();
#endif

	uboot_start_time = SCI_GetTickCount();

	gd->flags |= GD_FLG_RELOC;	/* tell others: relocation done */
	bootstage_mark_name(BOOTSTAGE_ID_START_UBOOT_R, "board\_init\_r");

	monitor_flash_len = (ulong)&__rel_dyn_end - (ulong)_start;

	/* Enable caches */
	enable_caches();

	debug("monitor flash len: %08lX\n", monitor_flash_len);
	board_init();	/* Setup chipselects */
	/*
	 * TODO: printing of the clock inforamtion of the board is now
	 * implemented as part of bdinfo command. Currently only support for
	 * davinci SOC's is added. Remove this check once all the board
 \* implement this.
 \*/
#ifdef CONFIG\_CLOCKS
 set\_cpu\_clk\_info(); /\* Setup clock information \*/
#endif
 serial\_initialize();

 debug("Now running in RAM - U-Boot at: %08lx\n", dest\_addr);

#ifdef CONFIG\_LOGBUFFER
 logbuff\_init\_ptrs();
#endif
#ifdef CONFIG\_POST
 post\_output\_backlog();
#endif

 /\* The Malloc area is immediately below the monitor copy in DRAM \*/
#ifndef CONFIG\_NO\_RELOCATION
 malloc\_start = dest\_addr - TOTAL\_MALLOC\_LEN;
#else
 malloc\_start = gd->no\_relloc\_malloc\_addr;
#endif
 mem\_malloc\_init (malloc\_start, TOTAL\_MALLOC\_LEN);

#ifdef CONFIG\_ARCH\_EARLY\_INIT\_R
 arch\_early\_init\_r();
#endif
 power\_init\_board();

#if !defined(CONFIG\_SYS\_NO\_FLASH)
 puts("Flash: ");

 flash\_size = flash\_init();
 if (flash\_size > 0) {
# ifdef CONFIG\_SYS\_FLASH\_CHECKSUM
 print\_size(flash\_size, "");
 /\*
 \* Compute and print flash CRC if flashchecksum is set to 'y'
 \*
 \* NOTE: Maybe we should add some WATCHDOG\_RESET()? XXX
 \*/
 if (getenv\_yesno("flashchecksum") == 1) {
 printf(" CRC: %08X", crc32(0,
 (const unsigned char \*) CONFIG\_SYS\_FLASH\_BASE,
 flash\_size));
 }
 putc('\n');
# else /\* !CONFIG\_SYS\_FLASH\_CHECKSUM \*/
		print_size(flash_size, "\n");
# endif /\* CONFIG\_SYS\_FLASH\_CHECKSUM \*/
	} else {
		puts(failed);
		hang();
	}
#endif

```

进入cmd\_cboot.c 的do\_cboot(cmd\_tbl\_t \*cmdtp, int flag, int argc, char \*const argv[]); // 进入启动函数



```
int do_cboot(cmd_tbl_t *cmdtp, int flag, int argc, char *const argv[])
{
	volatile int i;
	boot_mode_enum_type bootmode = CMD_UNDEFINED_MODE;
	CBOOT_MODE_ENTRY boot_mode_array[CMD_MAX_MODE] ={0};

	if(argc > 2)
		return CMD_RET_USAGE;
#ifdef CONFIG\_AUTOLOAD\_MODE
	autoload_mode();
#endif
#if defined CONFIG\_AUTOBOOT
	if (reboot_mode_check() == CMD_AUTODLOADER_REBOOT)
	{
		autodloader_mode();
	}
	else    {
	#if defined CONFIG\_X86
		write_sysdump_before_boot_extend();//if autoboot kernel is crash and reboot,the uboot go to sysdump in x86;
	#endif
		normal_mode();
	}
#endif

#if defined CONFIG\_ZEBU || defined CONFIG\_FPGA
	normal_mode();
#endif
	boot_pwr_check();
	if (2 == argc) {
		/*argument has the highest priority to determine the boot mode*/
		bootmode = get_mode_from_arg(argv[1]);
	} else {
		for (i = 0;  i < CHECK_BOOTMODE_FUN_NUM; i++) {
			if (0 == s_boot_func_array[i]) {
				bootmode = CMD_POWER_DOWN_DEVICE;
				break;
			}
			bootmode = s_boot_func_array[i]();
			if (CMD_UNDEFINED_MODE == bootmode) {

				continue;
			} else {
				debugf("get boot mode in boot func array[%d]\n",i);
				break;
			}
		}
	}

	board_boot_mode_regist(boot_mode_array);

	printf("enter boot mode %d\n", bootmode);

    // modified by elink_wufj start <<<
    g_bootmode = bootmode;
    // modified end >>>

	if ((bootmode > CMD\_POWER\_DOWN\_DEVICE) &&(bootmode < CMD\_MAX\_MODE)&& (0 != boot\_mode\_array[bootmode])) {
		write_log();

		boot_mode_array[bootmode]();
	} else {
#ifdef CONFIG\_FPGA
		/*FPGA has no power button ,if hasn't detect any mode ,use normal mode*/
		debugf("FPGA use normal mode instead of power down.\n");
		normal_mode();
#else
		debugf("power down device\n");
		write_log();
		power_down_devices(0);
#endif
		while(1);
	}

	  return 0;
}

```


```
boot_mode_enum_type get_mode_from_bat_low(void)
{
#ifndef CONFIG\_FPGA //jump loop
	while(is_bat_low()) {
#ifdef CONFIG\_TARGET\_SP9853I\_10C10
	  if(1) {
#else
	  if(charger_connected()) {
#endif
		  debugf("cboot:low battery,charging...\n");
		  sprdbat_show_chglogo();
		  sprdbat_lowbat_chg();
		  mdelay(SPRDBAT_CHG_POLLING_T);
	  }else{
		  debugf("cboot:low battery and shutdown\n");
		  return CMD_POWER_DOWN_DEVICE;
	  }
	}
#endif
	sprdbat_chg_led(0);
	return CMD_UNDEFINED_MODE;
}

```

而通过get\_mode\_from\_bat\_low(void) 来不断循环来判断是不是低电压  
 所以修改就在此方法  
 diff --git a/bsp/bootloader/u-boot15/common/cmd\_cboot.c b/bsp/bootloader/u-boot15/common/cmd\_cboot.c  
 index e00b418…80ce7fc 100755 (executable)



```
--- a/bsp/bootloader/u-boot15/common/cmd_cboot.c
+++ b/bsp/bootloader/u-boot15/common/cmd_cboot.c
@@ -125,6 +125,8 @@
 boot_mode_enum_type get_mode_from_bat_low(void)
{
#ifndef CONFIG\_FPGA //jump loop
	while(is_bat_low()) {
#ifdef CONFIG\_TARGET\_SP9853I\_10C10
	  if(1) {
#else
	  if(charger_connected()) {
#endif

                  mdelay(SPRDBAT_CHG_POLLING_T);
          }else{
                  debugf("cboot:low battery and shutdown\n");
+                  sprdbat_show_lowlogo(); 
+                  mdelay(3000);
                  return CMD_POWER_DOWN_DEVICE;
          }
        }

```


```
/* 4 get mode from charger*/
boot_mode_enum_type  get_mode_from_charger(void)
{
	if (charger_connected()) {
		debugf("get mode from charger\n");
		return CMD_CHARGE_MODE;
	} else {
		return CMD_UNDEFINED_MODE;
	}
}

```

当电压为低电压时类型也会修改成CMD\_CHARGE\_MODE  
 所以该方法修改为:



```
@@ -227,6 +229,7 @@ boot_mode_enum_type  get_mode_from_charger(void)
 {
        if (charger_connected()) {
                debugf("get mode from charger\n");
+               sprdbat_show_chglogo();
                return CMD_CHARGE_MODE;
        } else {
                return CMD_UNDEFINED_MODE;
       }
}

```

接下来在/bsp/bootloader/u-boot15/include/sprd\_battery.h 添加新加入的方法sprdbat\_show\_chglogo();



```
#ifndef \_SPRD\_BATTERY\_H\_
#define \_SPRD\_BATTERY\_H\_

#define SPRDBAT\_CHG\_POLLING\_T 200

enum sprd_adapter_type {
	ADP_TYPE_UNKNOW = 0,	//unknow adapter type
	ADP_TYPE_CDP = 1,	//Charging Downstream Port,USB&standard charger
	ADP_TYPE_DCP = 2,	//Dedicated Charging Port, standard charger
	ADP_TYPE_SDP = 4,	//Standard Downstream Port,USB and nonstandard charge
};

int sprdchg_charger_is_adapter(void);
uint16_t sprdbat_auxadc2vbatvol(uint16_t adcvalue);
uint32_t sprdbat_get_vbatauxadc_caltype(void);
void sprdbat_get_vbatauxadc_caldata(void);
int charger_connected(void);
int get_mode_from_gpio(void);
void sprdbat_init(void);
void sprdbat_lowbat_chg(void);
int sprdbat_is_battery_connected(void);
void sprdbat_show_chglogo(void);
void sprdbat_chg_led(int on);
uint32_t sprdbat_get_aux_vbatvol(void);
void sprdchg_common_cfg(void);
uint32_t sprdfgu_read_vbat_vol(void);

/* ext chg ic init function*/
void sprdchg_fan54015_init(void);
void sprdchg_bq25896_init(void);
void sprdchg_bq2560x_init(void);
void sprdchg_2700_init(void);
void sprdchg_2701_init(void);
void sprdchg_2705_init(void);
void sprdchg_2703_init(void);
void sprdchg_2731_init(void);
void sprdchg_2721_init(void);
void sprdchg_2723_init(void);
void sprdchg_2720_init(void);

+void sprdbat_show_lowlogo();
#endif

```

具体实现sprdbat\_show\_chglogo() 在bsp/bootloader/u-boot15/drivers/power/battery/sprd\_chg\_logo.c 中


diff --git a/bsp/bootloader/u-boot15/drivers/power/battery/sprd\_chg\_logo.c b/bsp/bootloader/u-boot15/drivers/power/battery/sprd\_chg\_logo.c  
 old mode 100644 (file)  
 new mode 100755 (executable)  
 index 6df8598…ec9768a  
 — a/bsp/bootloader/u-boot15/drivers/power/battery/sprd\_chg\_logo.c  
 +++ b/bsp/bootloader/u-boot15/drivers/power/battery/sprd\_chg\_logo.c  
 @@ -2,6 +2,20 @@



```
 #include <boot\_mode.h>
 #include <sprd\_led.h>
 
+void sprdbat_show_lowlogo()
+ {
+               extern void lcd_enable(void);
+               debug("[LCD] Drawing the logo...\n");
+               drv_lcd_init();
+               lcd_splash("fbootlogo");
+               lcd_enable();
+ 
+
+       set_backlight(25);
+
+
+ }
+
 #ifdef CONFIG\_CHG\_LED
 void sprdbat_chg_led(int on)
 {

```




