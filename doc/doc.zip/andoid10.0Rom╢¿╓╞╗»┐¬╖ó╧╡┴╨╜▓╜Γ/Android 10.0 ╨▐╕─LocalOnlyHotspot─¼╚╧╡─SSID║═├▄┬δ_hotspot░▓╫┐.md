



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.修改LocalOnlyHotspot默认的SSID和密码的核心代码](#2.%E4%BF%AE%E6%94%B9LocalOnlyHotspot%E9%BB%98%E8%AE%A4%E7%9A%84SSID%E5%92%8C%E5%AF%86%E7%A0%81%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.修改LocalOnlyHotspot默认的SSID和密码的代码功能分析和功能实现](#3.%E4%BF%AE%E6%94%B9LocalOnlyHotspot%E9%BB%98%E8%AE%A4%E7%9A%84SSID%E5%92%8C%E5%AF%86%E7%A0%81%E7%9A%84%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 WifiManager.java相关代码分析](#%C2%A0%203.1%20WifiManager.java%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 WifiServiceImpl.java 相关启用本地热点的相关方法](#3.2%20WifiServiceImpl.java%20%E7%9B%B8%E5%85%B3%E5%90%AF%E7%94%A8%E6%9C%AC%E5%9C%B0%E7%83%AD%E7%82%B9%E7%9A%84%E7%9B%B8%E5%85%B3%E6%96%B9%E6%B3%95)


[3.3 WifiApConfigStore相关启用本地热点的方法](#3.3%20WifiApConfigStore%E7%9B%B8%E5%85%B3%E5%90%AF%E7%94%A8%E6%9C%AC%E5%9C%B0%E7%83%AD%E7%82%B9%E7%9A%84%E6%96%B9%E6%B3%95)




---



## 1.概述


  在产品开发中，由于功能需要开启本地热点LocalOnlyHotspot，而且由于LocalOnlyHotspot默认的SSID和密码随机生成的，不符合需求，所以需要修改  
 默认的SSID和密码。  
 核心代码:



```
         mWifiManager.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
                                               @Override
                                               public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                                                   super.onStarted(reservation);
                                                   String ssid = reservation.getWifiConfiguration().SSID;
                                                   String pwd = reservation.getWifiConfiguration().preSharedKey;
                                                   //ipConfiguration = reservation.getWifiConfiguration().getIpConfiguration();
                                                   Log.e("SetLocalOnlyHotSpotController", "ssid and pwd is" + ssid + "and:" + pwd);
                                               }
```

## 2.修改LocalOnlyHotspot默认的SSID和密码的核心代码



```
  frameworks/base/wifi/java/android/net/wifi/WifiManager.java
  frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java
  frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiApConfigStore.java

```

## 3.修改LocalOnlyHotspot默认的SSID和密码的代码功能分析和功能实现



WifiManager这个类, 是 Android 暴露给开发者使用的一个系统服务管理类, 其中包含对WiFi的响应的操作函数; 其隐藏掉的系统服务类为IWifiService, 为Android私有的, 其具体实现, 未暴露给用户; 只需要使用WifiManager进行函数操作完成UI, 监听对应的广播消息, 就可完成功能了. 换言之, WifiManager会调用service简介地和framework层, 驱动层进行函数调用, 然后驱动层会回调至上层, 以广播的形式实现通知;



##   3.1 WifiManager.java相关代码分析



```
@SystemService(Context.WIFI_SERVICE)
public class WifiManager {

    private static final String TAG = "WifiManager";
    private Context mContext;
    @UnsupportedAppUsage
    IWifiManager mService;

    public void startLocalOnlyHotspot(LocalOnlyHotspotCallback callback,
            @Nullable Handler handler) {
        synchronized (mLock) {
            Looper looper = (handler == null) ? mContext.getMainLooper() : handler.getLooper();
            LocalOnlyHotspotCallbackProxy proxy =
                    new LocalOnlyHotspotCallbackProxy(this, looper, callback);
            try {
                String packageName = mContext.getOpPackageName();
                int returnCode = mService.startLocalOnlyHotspot(
                        proxy.getMessenger(), new Binder(), packageName);
                if (returnCode != LocalOnlyHotspotCallback.REQUEST_REGISTERED) {
                    // Send message to the proxy to make sure we call back on the correct thread
                    proxy.notifyFailed(returnCode);
                    return;
                }
                mLOHSCallbackProxy = proxy;
            } catch (RemoteException e) {
                throw e.rethrowFromSystemServer();
            }
        }
    }
....
}
```

在上述代码中可以看到，WifiManager.java中startLocalOnlyHotspot(LocalOnlyHotspotCallback callback, @Nullable Handler handler)负责启动本地热点，具体实现在WifiServiceImpl.java的相对应的方法中，接下来看WifiServiceImpl.java中的相关源码


## 3.2 WifiServiceImpl.java 相关启用本地热点的相关方法



WiFiService继承SystemService，系统起来时，SystemService创建ConnectivityService,


然后由ConnectivityService创建WifiService.


WifiService创建又new WifiServiceImpl。


WiFiService又重写了SystemService的接口



```
public class WifiServiceImpl extends BaseWifiService {
    
    ...
    @Override
    public int startLocalOnlyHotspot(Messenger messenger, IBinder binder, String packageName) {
        // first check if the caller has permission to start a local only hotspot
        // need to check for WIFI_STATE_CHANGE and location permission
        final int uid = Binder.getCallingUid();
        final int pid = Binder.getCallingPid();

        if (enforceChangePermission(packageName) != MODE_ALLOWED) {
            return LocalOnlyHotspotCallback.ERROR_GENERIC;
        }
        enforceLocationPermission(packageName, uid);
        long ident = Binder.clearCallingIdentity();
        try {
            // also need to verify that Locations services are enabled.
            if (!mWifiPermissionsUtil.isLocationModeEnabled()) {
                throw new SecurityException("Location mode is not enabled.");
            }
        } finally {
            Binder.restoreCallingIdentity(ident);
        }

        // verify that tethering is not disabled
        if (mUserManager.hasUserRestriction(UserManager.DISALLOW_CONFIG_TETHERING)) {
            return LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED;
        }

      ...
    }
```

mLocalOnlyHotspotConfig = WifiApConfigStore.generateLocalOnlyHotspotConfig(mContext,  
                         is5Ghz ? WifiConfiguration.AP\_BAND\_5GHZ : WifiConfiguration.AP\_BAND\_2GHZ);  
 这里负责启动本地热点 最终调用的是WifiApConfigStore.generateLocalOnlyHotspotConfig(）来启用本地热点


## 3.3 WifiApConfigStore相关启用本地热点的方法


打开WifiAp，初始的wifiAp的名称是一定的，但是wifiAp的密码是随机，这个可以自行测试，实现代码位于一个叫做 WifiApConfigStore.java的文件中，文件路径为/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiApConfigStore.java,所以可以根据WifiApConfigStore.java的相关


设置默认ssid和密码的地方，根据源码修改相关的设置，接下来具体分析下源码




```
  public class WifiApConfigStore {

...

/**
     * Generate a default WPA2 based configuration with a random password.
     * We are changing the Wifi Ap configuration storage from secure settings to a
     * flat file accessible only by the system. A WPA2 based default configuration
     * will keep the device secure after the update.
     */
    private WifiConfiguration getDefaultApConfiguration() {
        WifiConfiguration config = new WifiConfiguration();
        config.apBand = WifiConfiguration.AP_BAND_2GHZ;
        String ssid = WifiFeaturesUtils.FeatureProperty.SUPPORT_SPRD_SOFTAP_CUSTOMIZED_NAME;
        if (ssid != null && ssid.isEmpty()) {
            config.SSID = mContext.getResources().getString(
                R.string.wifi_tether_configure_ssid_default) + "_" + getRandomIntForDefaultSsid();
        } else {
            config.SSID = ssid;
        }
        config.allowedKeyManagement.set(KeyMgmt.WPA2_PSK);
        String randomUUID = UUID.randomUUID().toString();
        //first 12 chars from xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
        config.preSharedKey = randomUUID.substring(0, 8) + randomUUID.substring(9, 13);
        return config;
    }

    private static int getRandomIntForDefaultSsid() {
        Random random = new Random();
        return random.nextInt((RAND_SSID_INT_MAX - RAND_SSID_INT_MIN) + 1) + RAND_SSID_INT_MIN;
    }

    /**
     * Generate a temporary WPA2 based configuration for use by the local only hotspot.
     * This config is not persisted and will not be stored by the WifiApConfigStore.
     */
    public static WifiConfiguration generateLocalOnlyHotspotConfig(Context context, int apBand) {
        WifiConfiguration config = new WifiConfiguration();
        // 设置默认的ssid
        config.SSID = context.getResources().getString(
              R.string.wifi_localhotspot_configure_ssid_default) + "_"
                      + getRandomIntForDefaultSsid();
        config.apBand = apBand;
        config.allowedKeyManagement.set(KeyMgmt.WPA2_PSK);
        config.networkId = WifiConfiguration.LOCAL_ONLY_NETWORK_ID;
        String randomUUID = UUID.randomUUID().toString();
        // first 12 chars from xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
       // 随机生成密码
        config.preSharedKey = randomUUID.substring(0, 8) + randomUUID.substring(9, 13);
        return config;
    }
```

在上述的方法中，在WifiApConfigStore.java中，可以发现在generateLocalOnlyHotspotConfig(Context context, int apBand)中主要是生成随机的本地热点的密码和ssid，


所以可以具体修改为:



```
  public static WifiConfiguration generateLocalOnlyHotspotConfig(Context context, int apBand) {
        WifiConfiguration config = new WifiConfiguration();
        // 设置默认的ssid
      - config.SSID = context.getResources().getString(R.string.wifi_localhotspot_configure_ssid_default) + "_" + getRandomIntForDefaultSsid();
       + config.SSID = context.getResources().getString(R.string.wifi_localhotspot_configure_ssid_default) /*+ "_" + getRandomIntForDefaultSsid()*/;
        config.apBand = apBand;
        config.allowedKeyManagement.set(KeyMgmt.WPA2_PSK);
        config.networkId = WifiConfiguration.LOCAL_ONLY_NETWORK_ID;
        String randomUUID = UUID.randomUUID().toString();
        // first 12 chars from xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
       // 随机生成密码
      - config.preSharedKey = randomUUID.substring(0, 8) + randomUUID.substring(9, 13);
       + config.preSharedKey = "12345678"/*randomUUID.substring(0, 8) + randomUUID.substring(9, 13)*/;
        return config;
    }
```



