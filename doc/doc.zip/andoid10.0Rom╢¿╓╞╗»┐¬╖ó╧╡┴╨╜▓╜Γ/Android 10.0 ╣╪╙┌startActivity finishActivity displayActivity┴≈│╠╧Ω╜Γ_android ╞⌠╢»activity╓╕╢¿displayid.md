



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.关于startActivity finishActivity displayActivity的相关流程的核心代码](#2.%E5%85%B3%E4%BA%8EstartActivity%20finishActivity%20displayActivity%E7%9A%84%E7%9B%B8%E5%85%B3%E6%B5%81%E7%A8%8B%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.关于startActivity finishActivity displayActivity的相关流程的核心代码分析](#3.%E5%85%B3%E4%BA%8EstartActivity%20finishActivity%20displayActivity%E7%9A%84%E7%9B%B8%E5%85%B3%E6%B5%81%E7%A8%8B%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 启动activity的信息分析](#3.1%20%E5%90%AF%E5%8A%A8activity%E7%9A%84%E4%BF%A1%E6%81%AF%E5%88%86%E6%9E%90)


[3.2 ATMS的finishActivity方法](#3.2%20ATMS%E7%9A%84finishActivity%E6%96%B9%E6%B3%95)


[3.3 获取当前显示的Activity](#3.3%20%E8%8E%B7%E5%8F%96%E5%BD%93%E5%89%8D%E6%98%BE%E7%A4%BA%E7%9A%84Activity)


[4.总结](#4.%E6%80%BB%E7%BB%93)




---



## 1.概述


在10.0进行os定制化开发中，对AMS中监听app中的Activity的startActivity finishActivity displayActivity的相关流程分析也是非常重要的，便于在定制化的过程中对第三方app的一些定制方便的找到问题的解决方法


## 2.关于startActivity finishActivity displayActivity的相关流程的核心代码



```
核心代码如下:
frameworks/base/services/core/java/com/android/server/wm/ActivityTaskManagerService.java
frameworks/base/services/core/java/com/android/server/wm/ActivityStarter.java
frameworks/base/services/core/java/com/android/server/wm/ActivityMetricsLogger.java

```

## 3.关于startActivity finishActivity displayActivity的相关流程的核心代码分析


#### 3.1 启动activity的信息分析



```
在10.0 ATMS负责管理Activity的启动和销毁等事件
路径为:frameworks/base/services/core/java/com/android/server/wm/ActivityTaskManagerService.java
1.启动activity的信息
@Override
public final int startActivity(IApplicationThread caller, String callingPackage,
Intent intent, String resolvedType, IBinder resultTo, String resultWho, int requestCode,
int startFlags, ProfilerInfo profilerInfo, Bundle bOptions) {
return startActivityAsUser(caller, callingPackage, intent, resolvedType, resultTo,
resultWho, requestCode, startFlags, profilerInfo, bOptions,
UserHandle.getCallingUserId());
}
@Override
public int startActivityAsUser(IApplicationThread caller, String callingPackage,
Intent intent, String resolvedType, IBinder resultTo, String resultWho, int requestCode,
int startFlags, ProfilerInfo profilerInfo, Bundle bOptions, int userId) {
return startActivityAsUser(caller, callingPackage, intent, resolvedType, resultTo,
resultWho, requestCode, startFlags, profilerInfo, bOptions, userId,
true /validateIncomingUser/);
}
int startActivityAsUser(IApplicationThread caller, String callingPackage,
        Intent intent, String resolvedType, IBinder resultTo, String resultWho, int requestCode,
        int startFlags, ProfilerInfo profilerInfo, Bundle bOptions, int userId,
        boolean validateIncomingUser) {
    enforceNotIsolatedCaller("startActivityAsUser");

    userId = getActivityStartController().checkTargetUser(userId, validateIncomingUser,
            Binder.getCallingPid(), Binder.getCallingUid(), "startActivityAsUser");

    // TODO: Switch to user app stacks here.
    return getActivityStartController().obtainStarter(intent, "startActivityAsUser")
            .setCaller(caller)
            .setCallingPackage(callingPackage)
            .setResolvedType(resolvedType)
            .setResultTo(resultTo)
            .setResultWho(resultWho)
            .setRequestCode(requestCode)
            .setStartFlags(startFlags)
            .setProfilerInfo(profilerInfo)
            .setActivityOptions(bOptions)
            .setMayWait(userId)
            .execute();

}

最终会调到ActivityStarter.java 中的startActivty方法
路径为:frameworks/base/services/core/java/com/android/server/wm/ActivityStarter.java
private int startActivity(IApplicationThread caller, Intent intent, Intent ephemeralIntent,
String resolvedType, ActivityInfo aInfo, ResolveInfo rInfo,
IVoiceInteractionSession voiceSession, IVoiceInteractor voiceInteractor,
IBinder resultTo, String resultWho, int requestCode, int callingPid, int callingUid,
String callingPackage, int realCallingPid, int realCallingUid, int startFlags,
SafeActivityOptions options,
boolean ignoreTargetSecurity, boolean componentSpecified, ActivityRecord[] outActivity,
TaskRecord inTask, boolean allowPendingRemoteAnimationRegistryLookup,
PendingIntentRecord originatingPendingIntent, boolean allowBackgroundActivityStart) {
mSupervisor.getActivityMetricsLogger().notifyActivityLaunching(intent);
int err = ActivityManager.START_SUCCESS;
// Pull the optional Ephemeral Installer-only bundle out of the options early.
final Bundle verificationBundle
= options != null ? options.popAppVerificationBundle() : null;
    WindowProcessController callerApp = null;
    if (caller != null) {
        callerApp = mService.getProcessController(caller);
        if (callerApp != null) {
            callingPid = callerApp.getPid();
            callingUid = callerApp.mInfo.uid;
        } else {
            Slog.w(TAG, "Unable to find app for caller " + caller
                    + " (pid=" + callingPid + ") when starting: "
                    + intent.toString());
            err = ActivityManager.START_PERMISSION_DENIED;
        }
    }

    final int userId = aInfo != null && aInfo.applicationInfo != null
            ? UserHandle.getUserId(aInfo.applicationInfo.uid) : 0;

    if (err == ActivityManager.START_SUCCESS) {
        Slog.i(TAG, "START u" + userId + " {" + intent.toShortString(true, true, true, false)
                + "} from uid " + callingUid + ", pid " + callingPid);
    }

    // NOTE: Bug #627645 low power Feature BEG-->
    String targetPkg = null;
    ActivityManagerService am = (ActivityManagerService)ActivityManager.getService();
    int targetUid = aInfo != null && aInfo.applicationInfo != null ? aInfo.applicationInfo.uid : 0;
    if (intent.getComponent() != null) targetPkg = intent.getComponent().getPackageName();
    if(!am.judgeStartAllowLocked(intent, targetPkg, targetUid, callingUid, callingPackage, "start-activity")){
        return ActivityManager.START_INTENT_NOT_RESOLVED;
    }
    // <-- NOTE: Bug #627645 low power Feature END

	//add code start
    ComponentName component = intent.getComponent();
    if (component != null) {
		String activityEnabled = Settings.System.getString(mService.mContext.getContentResolver(), "activity_enabled");
        Slog.i(TAG, "activityEnabled :" + activityEnabled + " component.getClassName():" + component.getClassName());
		if (!TextUtils.isEmpty(activityEnabled) && activityEnabled.contains(component.getClassName())) {
            return START_ABORTED;
        }
    }
	//add code end

    ActivityRecord sourceRecord = null;
    ActivityRecord resultRecord = null;
    if (resultTo != null) {
        sourceRecord = mRootActivityContainer.isInAnyStack(resultTo);
        if (DEBUG_RESULTS) Slog.v(TAG_RESULTS,
                "Will send result to " + resultTo + " " + sourceRecord);
        if (sourceRecord != null) {
            if (requestCode >= 0 && !sourceRecord.finishing) {
                resultRecord = sourceRecord;
            }
        }
    }

    final int launchFlags = intent.getFlags();

    if ((launchFlags & Intent.FLAG_ACTIVITY_FORWARD_RESULT) != 0 && sourceRecord != null) {
        // Transfer the result target from the source activity to the new
        // one being started, including any failures.
        if (requestCode >= 0) {
            SafeActivityOptions.abort(options);
            Slog.i(TAG,"->startActivity for " + intent
                    + ", return START_FORWARD_AND_REQUEST_CONFLICT");
            return ActivityManager.START_FORWARD_AND_REQUEST_CONFLICT;
        }
        resultRecord = sourceRecord.resultTo;
        if (resultRecord != null && !resultRecord.isInStackLocked()) {
            resultRecord = null;
        }
        resultWho = sourceRecord.resultWho;
        requestCode = sourceRecord.requestCode;
        sourceRecord.resultTo = null;
        if (resultRecord != null) {
            resultRecord.removeResultsLocked(sourceRecord, resultWho, requestCode);
        }
        if (sourceRecord.launchedFromUid == callingUid) {
            // The new activity is being launched from the same uid as the previous
            // activity in the flow, and asking to forward its result back to the
            // previous.  In this case the activity is serving as a trampoline between
            // the two, so we also want to update its launchedFromPackage to be the
            // same as the previous activity.  Note that this is safe, since we know
            // these two packages come from the same uid; the caller could just as
            // well have supplied that same package name itself.  This specifially
            // deals with the case of an intent picker/chooser being launched in the app
            // flow to redirect to an activity picked by the user, where we want the final
            // activity to consider it to have been launched by the previous app activity.
            callingPackage = sourceRecord.launchedFromPackage;
        }
    }

    if (err == ActivityManager.START_SUCCESS && intent.getComponent() == null) {
        // We couldn't find a class that can handle the given Intent.
        // That's the end of that!
        err = ActivityManager.START_INTENT_NOT_RESOLVED;
    }

    if (err == ActivityManager.START_SUCCESS && aInfo == null) {
        // We couldn't find the specific class specified in the Intent.
        // Also the end of the line.
        err = ActivityManager.START_CLASS_NOT_FOUND;
    }

    if (err == ActivityManager.START_SUCCESS && sourceRecord != null
            && sourceRecord.getTaskRecord().voiceSession != null) {
        // If this activity is being launched as part of a voice session, we need
        // to ensure that it is safe to do so.  If the upcoming activity will also
        // be part of the voice session, we can only launch it if it has explicitly
        // said it supports the VOICE category, or it is a part of the calling app.
        if ((launchFlags & FLAG_ACTIVITY_NEW_TASK) == 0
                && sourceRecord.info.applicationInfo.uid != aInfo.applicationInfo.uid) {
            try {
                intent.addCategory(Intent.CATEGORY_VOICE);
                if (!mService.getPackageManager().activitySupportsIntent(
                        intent.getComponent(), intent, resolvedType)) {
                    Slog.w(TAG,
                            "Activity being started in current voice task does not support voice: "
                                    + intent);
                    err = ActivityManager.START_NOT_VOICE_COMPATIBLE;
                }
            } catch (RemoteException e) {
                Slog.w(TAG, "Failure checking voice capabilities", e);
                err = ActivityManager.START_NOT_VOICE_COMPATIBLE;
            }
        }
    }

    if (err == ActivityManager.START_SUCCESS && voiceSession != null) {
        // If the caller is starting a new voice session, just make sure the target
        // is actually allowing it to run this way.
        try {
            if (!mService.getPackageManager().activitySupportsIntent(intent.getComponent(),
                    intent, resolvedType)) {
                Slog.w(TAG,
                        "Activity being started in new voice task does not support: "
                                + intent);
                err = ActivityManager.START_NOT_VOICE_COMPATIBLE;
            }
        } catch (RemoteException e) {
            Slog.w(TAG, "Failure checking voice capabilities", e);
            err = ActivityManager.START_NOT_VOICE_COMPATIBLE;
        }
    }

    final ActivityStack resultStack = resultRecord == null
            ? null : resultRecord.getActivityStack();

    if (err != START_SUCCESS) {
        if (resultRecord != null) {
            resultStack.sendActivityResultLocked(
                    -1, resultRecord, resultWho, requestCode, RESULT_CANCELED, null);
        }
        SafeActivityOptions.abort(options);
        Slog.i(TAG, "->startActivity for " + intent + " result:" +
                startActivityResultCodeToString(err));
        return err;
    }

    boolean abort = !mSupervisor.checkStartAnyActivityPermission(intent, aInfo, resultWho,
            requestCode, callingPid, callingUid, callingPackage, ignoreTargetSecurity,
            inTask != null, callerApp, resultRecord, resultStack);
    if (abort) Slog.i(TAG,"->startActivity for " + intent
            + " checkStartAnyActivityPermission result:false");
    boolean firewallCheck = !mService.getPermissionPolicyInternal().checkStartActivity(intent,
                    callingUid, callingPackage);
    if (firewallCheck) Slog.i(TAG,"->startActivity for " + intent
            + " mIntentFirewall.checkStartActivity result:false");
    abort |= firewallCheck;

    boolean restrictedBgActivity = false;
    if (!abort) {
        try {
            Trace.traceBegin(Trace.TRACE_TAG_ACTIVITY_MANAGER,
                    "shouldAbortBackgroundActivityStart");
            restrictedBgActivity = shouldAbortBackgroundActivityStart(callingUid,
                    callingPid, callingPackage, realCallingUid, realCallingPid, callerApp,
                    originatingPendingIntent, allowBackgroundActivityStart, intent);
        } finally {
            Trace.traceEnd(Trace.TRACE_TAG_ACTIVITY_MANAGER);
        }
    }

    // Merge the two options bundles, while realCallerOptions takes precedence.
    ActivityOptions checkedOptions = options != null
            ? options.getOptions(intent, aInfo, callerApp, mSupervisor) : null;
    if (allowPendingRemoteAnimationRegistryLookup) {
        checkedOptions = mService.getActivityStartController()
                .getPendingRemoteAnimationRegistry()
                .overrideOptionsIfNeeded(callingPackage, checkedOptions);
    }
    if (mService.mController != null) {
        try {
            // The Intent we give to the watcher has the extra data
            // stripped off, since it can contain private information.
            Intent watchIntent = intent.cloneFilter();
            abort |= !mService.mController.activityStarting(watchIntent,
                    aInfo.applicationInfo.packageName);
        } catch (RemoteException e) {
            mService.mController = null;
        }
    }

    mInterceptor.setStates(userId, realCallingPid, realCallingUid, startFlags, callingPackage);
    if (mInterceptor.intercept(intent, rInfo, aInfo, resolvedType, inTask, callingPid,
            callingUid, checkedOptions)) {
        // activity start was intercepted, e.g. because the target user is currently in quiet
        // mode (turn off work) or the target application is suspended
        intent = mInterceptor.mIntent;
        rInfo = mInterceptor.mRInfo;
        aInfo = mInterceptor.mAInfo;
        resolvedType = mInterceptor.mResolvedType;
        inTask = mInterceptor.mInTask;
        callingPid = mInterceptor.mCallingPid;
        callingUid = mInterceptor.mCallingUid;
        checkedOptions = mInterceptor.mActivityOptions;
    }

    if (abort) {
        if (resultRecord != null) {
            resultStack.sendActivityResultLocked(-1, resultRecord, resultWho, requestCode,
                    RESULT_CANCELED, null);
        }
        // We pretend to the caller that it was really started, but
        // they will just get a cancel result.
        ActivityOptions.abort(checkedOptions);
        Slog.i(TAG, "->startActivity for " + intent + " abort, return START_ABORTED");
        return START_ABORTED;
    }

    // If permissions need a review before any of the app components can run, we
    // launch the review activity and pass a pending intent to start the activity
    // we are to launching now after the review is completed.
    if (aInfo != null) {
        if (mService.getPackageManagerInternalLocked().isPermissionsReviewRequired(
                aInfo.packageName, userId)) {
            IIntentSender target = mService.getIntentSenderLocked(
                    ActivityManager.INTENT_SENDER_ACTIVITY, callingPackage,
                    callingUid, userId, null, null, 0, new Intent[]{intent},
                    new String[]{resolvedType}, PendingIntent.FLAG_CANCEL_CURRENT
                            | PendingIntent.FLAG_ONE_SHOT, null);

            Intent newIntent = new Intent(Intent.ACTION_REVIEW_PERMISSIONS);

            int flags = intent.getFlags();
            flags |= Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS;

            /*
             * Prevent reuse of review activity: Each app needs their own review activity. By
             * default activities launched with NEW_TASK or NEW_DOCUMENT try to reuse activities
             * with the same launch parameters (extras are ignored). Hence to avoid possible
             * reuse force a new activity via the MULTIPLE_TASK flag.
             *
             * Activities that are not launched with NEW_TASK or NEW_DOCUMENT are not re-used,
             * hence no need to add the flag in this case.
             */
            if ((flags & (FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_NEW_DOCUMENT)) != 0) {
                flags |= Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
            }
            newIntent.setFlags(flags);

            newIntent.putExtra(Intent.EXTRA_PACKAGE_NAME, aInfo.packageName);
            newIntent.putExtra(Intent.EXTRA_INTENT, new IntentSender(target));
            if (resultRecord != null) {
                newIntent.putExtra(Intent.EXTRA_RESULT_NEEDED, true);
            }
            intent = newIntent;

            resolvedType = null;
            callingUid = realCallingUid;
            callingPid = realCallingPid;

            rInfo = mSupervisor.resolveIntent(intent, resolvedType, userId, 0,
                    computeResolveFilterUid(
                            callingUid, realCallingUid, mRequest.filterCallingUid));
            aInfo = mSupervisor.resolveActivity(intent, rInfo, startFlags,
                    null /*profilerInfo*/);

            if (DEBUG_PERMISSIONS_REVIEW) {
                final ActivityStack focusedStack =
                        mRootActivityContainer.getTopDisplayFocusedStack();
                Slog.i(TAG, "START u" + userId + " {" + intent.toShortString(true, true,
                        true, false) + "} from uid " + callingUid + " on display "
                        + (focusedStack == null ? DEFAULT_DISPLAY : focusedStack.mDisplayId));
            }
        }
    }

    // If we have an ephemeral app, abort the process of launching the resolved intent.
    // Instead, launch the ephemeral installer. Once the installer is finished, it
    // starts either the intent we resolved here [on install error] or the ephemeral
    // app [on install success].
    if (rInfo != null && rInfo.auxiliaryInfo != null) {
        intent = createLaunchIntent(rInfo.auxiliaryInfo, ephemeralIntent,
                callingPackage, verificationBundle, resolvedType, userId);
        resolvedType = null;
        callingUid = realCallingUid;
        callingPid = realCallingPid;

        aInfo = mSupervisor.resolveActivity(intent, rInfo, startFlags, null /*profilerInfo*/);
    }

    ActivityRecord r = new ActivityRecord(mService, callerApp, callingPid, callingUid,
            callingPackage, intent, resolvedType, aInfo, mService.getGlobalConfiguration(),
            resultRecord, resultWho, requestCode, componentSpecified, voiceSession != null,
            mSupervisor, checkedOptions, sourceRecord);
    if (outActivity != null) {
        outActivity[0] = r;
    }

    if (r.appTimeTracker == null && sourceRecord != null) {
        // If the caller didn't specify an explicit time tracker, we want to continue
        // tracking under any it has.
        r.appTimeTracker = sourceRecord.appTimeTracker;
    }
    mService.notifyActivityStateChange(r.intent, ProcessInfo.ACTIVITY_STATE_START, null);

    final ActivityStack stack = mRootActivityContainer.getTopDisplayFocusedStack();

    // If we are starting an activity that is not from the same uid as the currently resumed
    // one, check whether app switches are allowed.
    if (voiceSession == null && (stack.getResumedActivity() == null
            || stack.getResumedActivity().info.applicationInfo.uid != realCallingUid)) {
        if (!mService.checkAppSwitchAllowedLocked(callingPid, callingUid,
                realCallingPid, realCallingUid, "Activity start")) {
            if (!(restrictedBgActivity && handleBackgroundActivityAbort(r))) {
                mController.addPendingActivityLaunch(new PendingActivityLaunch(r,
                        sourceRecord, startFlags, stack, callerApp));
            }
            ActivityOptions.abort(checkedOptions);
            Slog.i(TAG, "->startActivity for " + intent + ", return START_SWITCHES_CANCELED");
            return ActivityManager.START_SWITCHES_CANCELED;
        }
    }

    mService.onStartActivitySetDidAppSwitch();
    mController.doPendingActivityLaunches(false);

    final int res = startActivity(r, sourceRecord, voiceSession, voiceInteractor, startFlags,
            true /* doResume */, checkedOptions, inTask, outActivity, restrictedBgActivity);
    mSupervisor.getActivityMetricsLogger().notifyActivityLaunched(res, outActivity[0]);
    return res;
}


```

#### 3.2 ATMS的finishActivity方法



```
  @Override
public final boolean finishActivity(IBinder token, int resultCode, Intent resultData,
int finishTask) {
// Refuse possible leaked file descriptors
if (resultData != null && resultData.hasFileDescriptors()) {
throw new IllegalArgumentException("File descriptors passed in Intent");
}
    synchronized (mGlobalLock) {
        ActivityRecord r = ActivityRecord.isInStackLocked(token);
       // 这里可以获取到当前销毁的是哪个Activity
       if (r == null) {
            return true;
        }
        // Keep track of the root activity of the task before we finish it
        final TaskRecord tr = r.getTaskRecord();
        ActivityRecord rootR = tr.getRootActivity();
        if (rootR == null) {
            Slog.w(TAG, "Finishing task with all activities already finished");
        }
        // Do not allow task to finish if last task in lockTask mode. Launchable priv-apps can
        // finish.
        if (getLockTaskController().activityBlockedFromFinish(r)) {
            return false;
        }

        // TODO: There is a dup. of this block of code in ActivityStack.navigateUpToLocked
        // We should consolidate.
        if (mController != null) {
            // Find the first activity that is not finishing.
            ActivityRecord next = r.getActivityStack().topRunningActivityLocked(token, 0);

            // SPRD:bug778642, widen the finish request check area.
            ActivityStack homeStack = mRootActivityContainer.getDefaultDisplay().getHomeStack();
            if (next == null && homeStack != null && r.isActivityTypeHome()) {
                next = homeStack.topRunningActivityLocked();
                Slog.i(TAG, "Adjust the next resume activity check to " + next + " for "
                        + r + " finish request.");
                // The home stack top running activity is null, we need to check the home
                // activity package for monkey test. Ensure that not finish the last activity
                // of the monkey white list packages, so that we can avoid the refuse of start
                // home acivity which may make ANR happen.
                if (next == null) {
                    boolean resumeOK = true;
                    ActivityInfo aInfo = null;
                    try {
                        aInfo = AppGlobals.getPackageManager().getActivityInfo(
                                getHomeIntent().getComponent(), STOCK_PM_FLAGS, UserHandle.getCallingUserId());
                    } catch (RemoteException e) {
                        //ignore
                    }
                    if (aInfo != null) {
                        try {
                            resumeOK = mController.activityResuming(aInfo.packageName);
                        } catch (RemoteException e) {
                            mController = null;
                            Watchdog.getInstance().setActivityController(null);
                        }

                        if (!resumeOK) {
                            Slog.i(TAG, "Not finishing activity because controller resumed,"
                                    + " check packageName:" + aInfo.packageName);
                            return false;
                        }
                    }
                }
            }

            if (next != null) {
                // ask watcher if this is allowed
                boolean resumeOK = true;
                try {
                    resumeOK = mController.activityResuming(next.packageName);
                } catch (RemoteException e) {
                    mController = null;
                    Watchdog.getInstance().setActivityController(null);
                }

                if (!resumeOK) {
                    Slog.i(TAG, "Not finishing activity because controller resumed");
                    return false;
                }
            }
        }

        // note down that the process has finished an activity and is in background activity
        // starts grace period
        if (r.app != null) {
            r.app.setLastActivityFinishTimeIfNeeded(SystemClock.uptimeMillis());
        }

        final long origId = Binder.clearCallingIdentity();
        try {
            boolean res;
            final boolean finishWithRootActivity =
                    finishTask == Activity.FINISH_TASK_WITH_ROOT_ACTIVITY;
            if (finishTask == Activity.FINISH_TASK_WITH_ACTIVITY
                    || (finishWithRootActivity && r == rootR)) {
                // If requested, remove the task that is associated to this activity only if it
                // was the root activity in the task. The result code and data is ignored
                // because we don't support returning them across task boundaries. Also, to
                // keep backwards compatibility we remove the task from recents when finishing
                // task with root activity.
                res = mStackSupervisor.removeTaskByIdLocked(tr.taskId, false,
                        finishWithRootActivity, "finish-activity");
                if (!res) {
                    Slog.i(TAG, "Removing task failed to finish activity");
                }
                // Explicitly dismissing the activity so reset its relaunch flag.
                r.mRelaunchReason = RELAUNCH_REASON_NONE;
            } else {
                res = tr.getStack().requestFinishActivityLocked(token, resultCode,
                        resultData, "app-request", true);
                if (!res) {
                    Slog.i(TAG, "Failed to finish by app-request");
                }
            }
            return res;
        } finally {
            Binder.restoreCallingIdentity(origId);
        }
    }
}


```

#### 3.3 获取当前显示的Activity



```
在ActivityMetricsLogger.java中
路径:frameworks/base/services/core/java/com/android/server/wm/ActivityMetricsLogger.java

 /**
* Notifies the tracker that all windows of the app have been drawn.
*/
WindowingModeTransitionInfoSnapshot notifyWindowsDrawn(@WindowingMode int windowingMode,
long timestamp) {
if (DEBUG_METRICS) Slog.i(TAG, "notifyWindowsDrawn windowingMode=" + windowingMode);  
     final WindowingModeTransitionInfo info = mWindowingModeTransitionInfo.get(windowingMode);
    if (info == null || info.loggedWindowsDrawn) {
        return null;
    }
    info.windowsDrawnDelayMs = calculateDelay(timestamp);
    info.loggedWindowsDrawn = true;
    final WindowingModeTransitionInfoSnapshot infoSnapshot =
            new WindowingModeTransitionInfoSnapshot(info);
    if (allWindowsDrawn() && mLoggedTransitionStarting) {
        reset(false /* abort */, info, "notifyWindowsDrawn - all windows drawn");
    }
    return infoSnapshot;
}
private void reset(boolean abort, WindowingModeTransitionInfo info, String cause) {
    if (DEBUG_METRICS) Slog.i(TAG, "reset abort=" + abort + ",cause=" + cause);
    if (!abort && isAnyTransitionActive()) {
        logAppTransitionMultiEvents();
    }
    stopLaunchTrace(info);

    // Ignore reset-after reset.
    if (isAnyTransitionActive()) {
        // LaunchObserver callbacks.
        if (abort) {
            launchObserverNotifyActivityLaunchCancelled(info);
        } else {
            launchObserverNotifyActivityLaunchFinished(info);
        }
    } else {
        launchObserverNotifyIntentFailed();
    }

    mCurrentTransitionStartTime = INVALID_START_TIME;
    mCurrentTransitionDelayMs = INVALID_DELAY;
    mLoggedTransitionStarting = false;
    mWindowingModeTransitionInfo.clear();
}


private void logAppTransitionMultiEvents() {
if (DEBUG_METRICS) Slog.i(TAG, "logging transition events");
for (int index = mWindowingModeTransitionInfo.size() - 1; index >= 0; index--) {
final WindowingModeTransitionInfo info = mWindowingModeTransitionInfo.valueAt(index);
final int type = getTransitionType(info);
if (type == INVALID_TRANSITION_TYPE) {
if (DEBUG_METRICS) {
Slog.i(TAG, "invalid transition type"
+ " processRunning=" + info.currentTransitionProcessRunning
+ " startResult=" + info.startResult);
}
return;
}
        // Take a snapshot of the transition info before sending it to the handler for logging.
        // This will avoid any races with other operations that modify the ActivityRecord.
        final WindowingModeTransitionInfoSnapshot infoSnapshot =
                new WindowingModeTransitionInfoSnapshot(info);
        final int currentTransitionDeviceUptime = mCurrentTransitionDeviceUptime;
        final int currentTransitionDelayMs = mCurrentTransitionDelayMs;
        BackgroundThread.getHandler().post(() -> logAppTransition(
                currentTransitionDeviceUptime, currentTransitionDelayMs, infoSnapshot));
        BackgroundThread.getHandler().post(() -> logAppDisplayed(infoSnapshot));

        info.launchedActivity.info.launchToken = null;
    }
}


private void logAppDisplayed(WindowingModeTransitionInfoSnapshot info) {
  if (info.type != TYPE_TRANSITION_WARM_LAUNCH && info.type != TYPE_TRANSITION_COLD_LAUNCH) {
   return;
   }EventLog.writeEvent(AM_ACTIVITY_LAUNCH_TIME,
            info.userId, info.activityRecordIdHashCode, info.launchedActivityShortComponentName,
            info.windowsDrawnDelayMs);
    StringBuilder sb = mStringBuilder;
    sb.setLength(0);
    sb.append("Displayed ");
    sb.append(info.launchedActivityShortComponentName);
    sb.append(": ");
    TimeUtils.formatDuration(info.windowsDrawnDelayMs, sb);
    Log.i(TAG, sb.toString());//打印当前activity的名称
}
```

## 4.总结


关于AMS中startActivity finishActivity 和获取当前显示Activity都是在这里简单讲解了一下，相关代码都有标注，在开发中可以多加日志来满足定制的功能




