






这篇文章我们来学习如何下载AOSP 源码，如果你还没有Linux 环境，请查看Android AOSP基础（一）VirtualBox 安装 Ubuntu这篇文章，另外如果你不需要编译源码，或者不需要最新的源码，可以直接从百度网盘：https://pan.baidu.com/s/1ngsZs 将源码下载下来。  
 1.关于AOSP


AOSP(Android Open Source Project)是Google开放的Android 开源项目，中文官网为：https://source.android.google.cn/。  
 AOSP通俗来讲就是一个Android系统源码项目，通过它可以定制 Android 操作系统，国内手机厂商都是在此基础上开发的定制系统。因为墙的缘故，如果无法连接谷歌服务器获取AOSP源码，可以从 清华大学镜像站或者 中科大镜像。本篇文章以清华大学镜像站为例。  
 2. 下载 repo工具


Android源码包含数百个git库，光是下载这么多的git库就是一项繁重的任务，所以Google开发了repo，它是用于管理Android版本库的一个工具，使用了Python对git进行了一定的封装，简化了对多个Git版本库的管理。  
 安装 Git，在Ubuntu输入如下命令：


sudo apt-get install git


可能会报如下的错误：  
 ![VZRddU.pngVZRddU.png](https://img-blog.csdnimg.cn/20191130161918708.png)


这个问题是有另外一个程序正在运行，导致资源被锁不可用，输入如下命令进行解决：


sudo rm /var/cache/apt/archives/lock  
 sudo rm /var/lib/dpkg/lock


接下来创建bin，并加入到PATH中。


mkdir ~/bin  
 PATH=~/bin:$PATH


安装curl库：


sudo apt-get install curl


下载repo并设置权限：


curl https://mirrors.tuna.tsinghua.edu.cn/git/git-repo > ~/bin/repo  
 chmod a+x ~/bin/repo


最后安装python，repo初始化时会用到：


sudo apt-get install python


重启虚拟机后，开始下载源码。  
 3. 下载源码


建立工作目录 ：


mkdir aosp  
 cd aosp


repo的运行过程中会尝试访问官方的git源更新自己，如果想使用tuna的镜像源进行更新，可以将如下内容复制到你的~/.bashrc里：


export REPO\_URL=‘https://mirrors.tuna.tsinghua.edu.cn/git/git-repo/’


设置身份，添加自己的邮箱和姓名：


git config --global user.email “piratemorgen@gmail.com”  
 git config --global user.name “piratemorgen”


初始化仓库：


repo init -u https://aosp.tuna.tsinghua.edu.cn/platform/manifest


初始化并指定版本：


repo init -u https://aosp.tuna.tsinghua.edu.cn/platform/manifest -b android-9.0.0\_r8


同步源码:


repo sync


源码下载完成后，看到下面的信息可以说明下载成功。整个源码的大小为36.5 g


![在这里插入图片描述](https://img-blog.csdnimg.cn/20191130161843701.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)  
 4. 下载内核源码


AOSP源码中并不包括内核源码，需要单独下载，内核源码有很多版本，比如common是通用的Linux内核，msm是用于使用高通MSM芯片的Android设备，goldfish是用于Android模拟器的内核源码，这里以goldfish为例。


和下载AOSP源码一样，我们需要先建立工作目录 ：


mkdir kernel  
 cd kernel


使用清华的镜像：


git clone https://aosp.tuna.tsinghua.edu.cn/kernel/goldfish.git


![MEY5uD.md.pngMEY5uD.md.png](https://img-blog.csdnimg.cn/20191130161949344.png)  
 这时kernel目录中会生成一个goldfish文件夹，进入goldfish目录并使用git命令。


cd goldfish  
 git branch -a


这时会列出有哪些内核的版本分支可以下载。  
 ![MEYoHH.pngMEYoHH.png](https://img-blog.csdnimg.cn/20191130161801110.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)  
 这里选择下载goldfish 3.4版本。


git checkout remotes/origin/android-goldfish-3.4





