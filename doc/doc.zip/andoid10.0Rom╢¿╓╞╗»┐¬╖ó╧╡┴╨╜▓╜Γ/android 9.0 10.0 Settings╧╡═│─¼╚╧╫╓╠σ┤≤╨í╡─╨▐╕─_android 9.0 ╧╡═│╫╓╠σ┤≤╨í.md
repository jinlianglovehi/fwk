






### 1.概述


在10.0的系统产品开发中，在一些产品中，由于有些产品屏幕较小，对于系统默认字体显得太小的，产品需要默认把字体默认调大，系统字体的大小修改主要是修改数据库的默认字体大小


### 2.Settings系统默认字体大小的修改的核心类



```
frameworks/base/core/java/android/content/res/Configuration.java
packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
packages/SettingsProvider/src/com/android/providers/settings/SettingsHelper.java


```

### 3.Settings系统默认字体大小的修改的核心功能分析和实现


### 3.1在Configuration.java的设置系统默认字体的修改


当Configuration发生变化后，Activity方法onConfigurationChange会被调用  
 Configuration包含一个应用对手机配置的感知，比如窗口大小、重力方向、手机模式



```
--- a/core/java/android/content/res/Configuration.java
+++ b/core/java/android/content/res/Configuration.java
@@ -1356,7 +1356,7 @@ public final class Configuration implements Parcelable, Comparable<Configuration
      * Set this object to the system defaults.
      */
        /**
   * This class describes all device configuration information that can
   * impact the resources the application retrieves.  This includes both
   * user-specified configuration options (locale list and scaling) as well
   * as device configurations (such as input modes, screen size and screen orientation).
   * <p>You can acquire this object from {@link Resources}, using {@link
   * Resources#getConfiguration}. Thus, from an activity, you can get it by chaining the request
   * with {@link android.app.Activity#getResources}:</p>
   * <pre>Configuration config = getResources().getConfiguration();</pre>
   */
  public final class Configuration implements Parcelable, Comparable<Configuration> {
      /** @hide */
      public static final Configuration EMPTY = new Configuration();
  
      private static final String TAG = "Configuration";
    public Configuration() {
         unset();
     }
 
     /**
      * Makes a deep copy suitable for modification.
      */
     public Configuration(Configuration o) {
         setTo(o);
     }
 /**
       * Convert the UI mode to a human readable format.
       * @hide
       */
      public static String uiModeToString(int uiMode) {
          switch (uiMode) {
              case UI_MODE_TYPE_UNDEFINED:
                  return "UI\_MODE\_TYPE\_UNDEFINED";
              case UI_MODE_TYPE_NORMAL:
                  return "UI\_MODE\_TYPE\_NORMAL";
              case UI_MODE_TYPE_DESK:
                  return "UI\_MODE\_TYPE\_DESK";
              case UI_MODE_TYPE_CAR:
                  return "UI\_MODE\_TYPE\_CAR";
              case UI_MODE_TYPE_TELEVISION:
                  return "UI\_MODE\_TYPE\_TELEVISION";
              case UI_MODE_TYPE_APPLIANCE:
                  return "UI\_MODE\_TYPE\_APPLIANCE";
              case UI_MODE_TYPE_WATCH:
                  return "UI\_MODE\_TYPE\_WATCH";
              case UI_MODE_TYPE_VR_HEADSET:
                  return "UI\_MODE\_TYPE\_VR\_HEADSET";
              default:
                  return Integer.toString(uiMode);
          }
      }
  
      /**
       * Set this object to the system defaults.
       */
     public void setToDefaults() {
-        fontScale = 1.0f; //默认为1.of
+        fontScale = 1.3f;
         mcc = mnc = 0;
         mLocaleList = LocaleList.getEmptyLocaleList();
         locale = null;
          userSetLocale = false;
          touchscreen = TOUCHSCREEN_UNDEFINED;
          keyboard = KEYBOARD_UNDEFINED;
          keyboardHidden = KEYBOARDHIDDEN_UNDEFINED;
          hardKeyboardHidden = HARDKEYBOARDHIDDEN_UNDEFINED;
          navigation = NAVIGATION_UNDEFINED;
          navigationHidden = NAVIGATIONHIDDEN_UNDEFINED;
          orientation = ORIENTATION_UNDEFINED;
          screenLayout = SCREENLAYOUT_UNDEFINED;
          colorMode = COLOR_MODE_UNDEFINED;
          uiMode = UI_MODE_TYPE_UNDEFINED;
          screenWidthDp = compatScreenWidthDp = SCREEN_WIDTH_DP_UNDEFINED;
          screenHeightDp = compatScreenHeightDp = SCREEN_HEIGHT_DP_UNDEFINED;
          smallestScreenWidthDp = compatSmallestScreenWidthDp = SMALLEST_SCREEN_WIDTH_DP_UNDEFINED;
          densityDpi = DENSITY_DPI_UNDEFINED;
          assetsSeq = ASSETS_SEQ_UNDEFINED;
          seq = 0;
          windowConfiguration.setToDefaults();
      }

```

在Configuration中关于系统各种ｃｏｎｆｉｇ参数的设置中，在setToDefaults()设置系统默认的  
 ｃｏｎｆｉｇ参数，所以在这里可以修改默认参数fontScale 设置大点的默认字体大小


### ３.2 DatabaseHelper.java 数据库修改默认字体的方法


在DatabaseHelper.java默认添加系统的字体属性，来设置默认字体的大小



```
diff --git a/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java b/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
index 4743137..26ee0b8 100755
--- a/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
+++ b/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
@@ -2275,7 +2275,7 @@ class DatabaseHelper extends SQLiteOpenHelper {
 
             // Set default tty mode
             loadSetting(stmt, Settings.System.TTY_MODE, 0);
-
+            loadSetting(stmt, Settings.System.FONT_SCALE, 1.3f);
             loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                     R.integer.def_screen_brightness);

```

在系统加载默认数据的方法中　loadSystemSettings(SQLiteDatabase db)设置  
 默认字体loadSetting(stmt, Settings.System.FONT\_SCALE, 1.3f);即可设置大的默认字体


### 3.３SettingsHelper.java 加载默认字体大小


在SettingsHelper.java关于加载大字体的方法调用



```
        private boolean isAlreadyConfiguredCriticalAccessibilitySetting(String name) {
          switch (name) {
              case Settings.Secure.ACCESSIBILITY_ENABLED:
              case Settings.Secure.TOUCH_EXPLORATION_ENABLED:
              case Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER_ENABLED:
              case Settings.Secure.ACCESSIBILITY_DISPLAY_MAGNIFICATION_ENABLED:
              case Settings.Secure.ACCESSIBILITY_DISPLAY_MAGNIFICATION_NAVBAR_ENABLED:
                  return Settings.Secure.getInt(mContext.getContentResolver(), name, 0) != 0;
              case Settings.Secure.TOUCH_EXPLORATION_GRANTED_ACCESSIBILITY_SERVICES:
              case Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES:
              case Settings.Secure.ACCESSIBILITY_DISPLAY_DALTONIZER:
                  return !TextUtils.isEmpty(Settings.Secure.getString(
                          mContext.getContentResolver(), name));
              case Settings.Secure.ACCESSIBILITY_DISPLAY_MAGNIFICATION_SCALE:
                  float defaultScale = mContext.getResources().getFraction(
                          R.fraction.def_accessibility_display_magnification_scale, 1, 1);
                  float currentScale = Settings.Secure.getFloat(
                          mContext.getContentResolver(), name, defaultScale);
                  return Math.abs(currentScale - defaultScale) >= FLOAT_TOLERANCE;
              case Settings.System.FONT_SCALE:
                  return Settings.System.getFloat(mContext.getContentResolver(), name, 1.0f) != 1.0f;
              default:
                  return false;
          }
      }

```

在isAlreadyConfiguredCriticalAccessibilitySetting(String name)中获取当前系统的默认字体大小  
 在Settings.System.FONT\_SCALE就是返回的默认字体　修改这里即可



```
diff --git a/packages/SettingsProvider/src/com/android/providers/settings/SettingsHelper.java b/packages/SettingsProvider/src/com/android/providers/settings/SettingsHelper.java
old mode 100644
new mode 100755
index 36bb8ef..9f4d138
--- a/packages/SettingsProvider/src/com/android/providers/settings/SettingsHelper.java
+++ b/packages/SettingsProvider/src/com/android/providers/settings/SettingsHelper.java
@@ -274,7 +274,7 @@ public class SettingsHelper {

                         mContext.getContentResolver(), name, defaultScale);
                 return Math.abs(currentScale - defaultScale) >= FLOAT_TOLERANCE;
             case Settings.System.FONT_SCALE:
-                return Settings.System.getFloat(mContext.getContentResolver(), name, 1.0f) != 1.0f;
+                return Settings.System.getFloat(mContext.getContentResolver(), name, 1.3f) != 1.3f;
             default:
                 return false;
         }

```

通过修改Settings.System.getFloat(mContext.getContentResolver(), name, 1.3f) != 1.3f;调整它的默认字体大小达到设置大点的默认字体的目的





