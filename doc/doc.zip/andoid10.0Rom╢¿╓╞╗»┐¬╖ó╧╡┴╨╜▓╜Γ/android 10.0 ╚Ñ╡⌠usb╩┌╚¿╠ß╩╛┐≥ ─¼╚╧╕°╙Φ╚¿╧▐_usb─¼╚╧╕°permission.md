






### 1.概述


在10.0的系统产品开发中，在产品中进行iot开发过程中,在插入usb设备时会弹出usb授权提示框，也带来一些不便，怎么默认授予权限呢 ，实现不弹出usb授权窗口的功能


### 2.去掉usb授权提示框 默认给予权限的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java
frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java

```

### 3.去掉usb授权提示框 默认给予权限的核心功能实现和分析


### 3.1 在UsbPermissionActivity.java 去掉usb授权提示框


在系统插入usb，默认会弹出usb授权窗口，然后开始挂载usb的流程，所以要从授予  
 usb权限的UsbPermissionActivity看弹窗流程，接下来看其源码



```
public class UsbPermissionActivity extends AlertActivity
          implements DialogInterface.OnClickListener, CheckBox.OnCheckedChangeListener {
@Override
     public void onCreate(Bundle icicle) {
         super.onCreate(icicle);
 
         Intent intent = getIntent();
         mDevice = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
         mAccessory = (UsbAccessory)intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
         mPendingIntent = (PendingIntent)intent.getParcelableExtra(Intent.EXTRA_INTENT);
         mUid = intent.getIntExtra(Intent.EXTRA_UID, -1);
         mPackageName = intent.getStringExtra(UsbManager.EXTRA_PACKAGE);
         boolean canBeDefault = intent.getBooleanExtra(UsbManager.EXTRA_CAN_BE_DEFAULT, false);
 
         PackageManager packageManager = getPackageManager();
         ApplicationInfo aInfo;
         try {
             aInfo = packageManager.getApplicationInfo(mPackageName, 0);
         } catch (PackageManager.NameNotFoundException e) {
             Log.e(TAG, "unable to look up package name", e);
             finish();
             return;
         }
         String appName = aInfo.loadLabel(packageManager).toString();
 
         final AlertController.AlertParams ap = mAlertParams;
         ap.mTitle = appName;
         if (mDevice == null) {
             ap.mMessage = getString(R.string.usb_accessory_permission_prompt, appName,
                     mAccessory.getDescription());
             mDisconnectedReceiver = new UsbDisconnectedReceiver(this, mAccessory);
         } else {
             ap.mMessage = getString(R.string.usb_device_permission_prompt, appName,
                     mDevice.getProductName());
             mDisconnectedReceiver = new UsbDisconnectedReceiver(this, mDevice);
         }
         ap.mPositiveButtonText = getString(android.R.string.ok);
         ap.mNegativeButtonText = getString(android.R.string.cancel);
         ap.mPositiveButtonListener = this;
         ap.mNegativeButtonListener = this;
 
          if (canBeDefault && (mDevice != null || mAccessory != null)) {
              // add "open when" checkbox
              LayoutInflater inflater = (LayoutInflater) getSystemService(
                      Context.LAYOUT_INFLATER_SERVICE);
              ap.mView = inflater.inflate(com.android.internal.R.layout.always_use_checkbox, null);
              mAlwaysUse = (CheckBox) ap.mView.findViewById(com.android.internal.R.id.alwaysUse);
              if (mDevice == null) {
                  mAlwaysUse.setText(getString(R.string.always_use_accessory, appName,
                          mAccessory.getDescription()));
              } else {
                  mAlwaysUse.setText(getString(R.string.always_use_device, appName,
                          mDevice.getProductName()));
              }
              mAlwaysUse.setOnCheckedChangeListener(this);
  
              mClearDefaultHint = (TextView)ap.mView.findViewById(
                      com.android.internal.R.id.clearDefaultHint);
              mClearDefaultHint.setVisibility(View.GONE);
          }
  
          setupAlert();
      }

```

在进入UsbPermissionActivity 的onCreate()中的setupAlert();就是弹出需要usb授权的窗口，然后如果需要默认授权就需要注释掉，然后finish掉窗口 修改如下:



```
diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java
index 238407a..afeddd4 100644
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbPermissionActivity.java
@@ -134,6 +134,9 @@ public class UsbPermissionActivity extends AlertActivity
         }
 
-         setupAlert();
+   //setupAlert();
+		Log.d(TAG, "grant usb permission automatically");
+		mPermissionGranted = true;
+    	finish();
 
     }

```

### 3.2 usb授权后，挂载usb的功能分析


在UsbDebuggingActivity中实现对usb debug权限的开放，所以需要在这里分析具体是怎么  
 实现授权usb挂载，然后可以使用usb的分析



```
 @Override
      public void onCreate(Bundle icicle) {
          Window window = getWindow();
          window.addSystemFlags(WindowManager.LayoutParams.SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS);
          window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG);
  
          super.onCreate(icicle);
  
          if (SystemProperties.getInt("service.adb.tcp.port", 0) == 0) {
              mDisconnectedReceiver = new UsbDisconnectedReceiver(this);
          }
  
private class UsbDisconnectedReceiver extends BroadcastReceiver {
          private final Activity mActivity;
          public UsbDisconnectedReceiver(Activity activity) {
              mActivity = activity;
          }
  
          @Override
          public void onReceive(Context content, Intent intent) {
              String action = intent.getAction();
              if (!UsbManager.ACTION_USB_STATE.equals(action)) {
                  return;
              }
              boolean connected = intent.getBooleanExtra(UsbManager.USB_CONNECTED, false);
              if (!connected) {
                  mActivity.finish();
              }
          }
      }

```

在UsbDebuggingActivity的onCreate中UsbDisconnectedReceiver 来监听usb的挂载情况，在没链接的情况下，实现usb的挂载，所以这里需要默认实现usb的挂载，具体修改为：



```
diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java
index 66d5ee1..05cc9a2 100644
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/usb/UsbDebuggingActivity.java
@@ -126,10 +126,20 @@ public class UsbDebuggingActivity extends AlertActivity
             if (!UsbManager.ACTION_USB_STATE.equals(action)) {
                 return;
             }
-            boolean connected = intent.getBooleanExtra(UsbManager.USB_CONNECTED, false);
-            if (!connected) {
+            //boolean connected = intent.getBooleanExtra(UsbManager.USB_CONNECTED, false);
+            boolean connected = false;
+			if (!connected) {
                 mActivity.finish();
             }
             //usb授权
+
+			try {
+				 IBinder b = ServiceManager.getService(ADB_SERVICE); 
+				 IAdbManager service = IAdbManager.Stub.asInterface(b);
+				 service.allowDebugging(true, mKey);
+				 } catch (Exception e) {
+				 	Log.e(TAG, "Unable to notify Usb service", e); 
+				 }
+		
         }
     }

```

通过以上两步去掉usb授权弹窗和默认usb的挂载，实现了功能需求





