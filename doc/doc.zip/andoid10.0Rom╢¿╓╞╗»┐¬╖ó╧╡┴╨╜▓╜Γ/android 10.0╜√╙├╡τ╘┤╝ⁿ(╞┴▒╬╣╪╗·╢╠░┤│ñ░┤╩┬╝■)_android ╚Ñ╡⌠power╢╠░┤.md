






### 1.概述


在10.0的系统产品开发中，教育平板定制化中,有需求是用开关按钮控制电源键是否可操作，电源按键事件是通过驱动事件上报到PhoneWindowManager中来处理的


### 2.禁用电源键(屏蔽关机短按长按事件)的核心类



```
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java

```

### 3.禁用电源键(屏蔽关机短按长按事件)的核心功能分析和实现


对于系统中电源键的长短按事件的处理分析如下:



```
private class PolicyHandler extends Handler {
          @Override
          public void handleMessage(Message msg) {
              switch (msg.what) {
                  case MSG_DISPATCH_MEDIA_KEY_WITH_WAKE_LOCK:
                      dispatchMediaKeyWithWakeLock((KeyEvent)msg.obj);
 break;
 case MSG\_DISPATCH\_MEDIA\_KEY\_REPEAT\_WITH\_WAKE\_LOCK:
 dispatchMediaKeyRepeatWithWakeLock((KeyEvent)msg.obj);
 break;
 case MSG\_DISPATCH\_SHOW\_RECENTS:
 showRecentApps(false);
 break;
 case MSG\_DISPATCH\_SHOW\_GLOBAL\_ACTIONS:
 showGlobalActionsInternal();
 break;
 case MSG\_KEYGUARD\_DRAWN\_COMPLETE:
 if (DEBUG\_WAKEUP) Slog.w(TAG, "Setting mKeyguardDrawComplete");
 finishKeyguardDrawn();
 break;
 case MSG\_KEYGUARD\_DRAWN\_TIMEOUT:
 Slog.w(TAG, "Keyguard drawn timeout. Setting mKeyguardDrawComplete");
 finishKeyguardDrawn();
 break;
 case MSG\_WINDOW\_MANAGER\_DRAWN\_COMPLETE:
 if (DEBUG\_WAKEUP) Slog.w(TAG, "Setting mWindowManagerDrawComplete");
 finishWindowsDrawn();
 break;
 case MSG\_HIDE\_BOOT\_MESSAGE:
 handleHideBootMessage();
 break;
 case MSG\_LAUNCH\_ASSIST:
 final int deviceId = msg.arg1;
 final String hint = (String) msg.obj;
 launchAssistAction(hint, deviceId);
 break;
 case MSG\_LAUNCH\_ASSIST\_LONG\_PRESS:
 launchAssistLongPressAction();
 break;
 case MSG\_LAUNCH\_VOICE\_ASSIST\_WITH\_WAKE\_LOCK:
 launchVoiceAssistWithWakeLock();
 break;
 case MSG\_POWER\_DELAYED\_PRESS:
 powerPress((Long) msg.obj, msg.arg1 != 0, msg.arg2);
 finishPowerKeyPress();
 break;
 case MSG\_POWER\_LONG\_PRESS:
 powerLongPress();
 break;
 case MSG\_POWER\_VERY\_LONG\_PRESS:
 powerVeryLongPress();
 break;
 case MSG\_SHOW\_PICTURE\_IN\_PICTURE\_MENU:
 showPictureInPictureMenuInternal();
 break;
 case MSG\_BACK\_LONG\_PRESS:
 backLongPress();
 break;
 case MSG\_ACCESSIBILITY\_SHORTCUT:
 accessibilityShortcutActivated();
 break;
 case MSG\_BUGREPORT\_TV:
 requestFullBugreport();
 break;
 case MSG\_ACCESSIBILITY\_TV:
 if (mAccessibilityShortcutController.isAccessibilityShortcutAvailable(false)) {
                          accessibilityShortcutActivated();
                      }
                      break;
                  case MSG_DISPATCH_BACK_KEY_TO_AUTOFILL:
                      mAutofillManagerInternal.onBackKeyPressed();
                      break;
                  case MSG_SYSTEM_KEY_PRESS:
                      sendSystemKeyToStatusBar(msg.arg1);
                      break;
                  case MSG_HANDLE_ALL_APPS:
                      launchAllAppsAction();
                      break;
                  case MSG_NOTIFY_USER_ACTIVITY:
                      removeMessages(MSG_NOTIFY_USER_ACTIVITY);
                      Intent intent = new Intent(ACTION_USER_ACTIVITY_NOTIFICATION);
                      intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY);
                      mContext.sendBroadcastAsUser(intent, UserHandle.ALL,
                              android.Manifest.permission.USER_ACTIVITY);
                      break;
                  case MSG_RINGER_TOGGLE_CHORD:
                      handleRingerChordGesture();
                      break;
                  case MSG_MOVE_DISPLAY_TO_TOP:
                      mWindowManagerFuncs.moveDisplayToTop(msg.arg1);
                      mMovingDisplayToTopKeyTriggered = false;
                      break;
              }
          }
      }

```

在PhoneWindowManager的系统按键事件管理类中，从PolicyHandler的handler的事件处理中可以看到powerLongPress();是电源长按事件的处理,而powerPress((Long) msg.obj, msg.arg1 != 0, msg.arg2);是电源短按事件的处理  
 1.短按事件的处理分析  
 有powerPress(long eventTime, boolean interactive, int count)来处理



```
private void powerPress(long eventTime, boolean interactive, int count) {
        if (mDefaultDisplayPolicy.isScreenOnEarly() && !mDefaultDisplayPolicy.isScreenOnFully()) {
            Slog.i(TAG, "Suppressed redundant power key press while "
                    + "already in the process of turning the screen on.");
            return;
        }
        Slog.d(TAG, "powerPress: eventTime=" + eventTime + " interactive=" + interactive
                + " count=" + count + " beganFromNonInteractive=" + mBeganFromNonInteractive +
                " mShortPressOnPowerBehavior=" + mShortPressOnPowerBehavior);
                
	   //添加标志位 当为false时返回
	   String aTrue = SystemProperties.get("persist.sys.power.enable", "true");
       if(!"true".equals(aTrue)){
        return;
       }

        if (count == 2) {
            powerMultiPressAction(eventTime, interactive, mDoublePressOnPowerBehavior);
        } else if (count == 3) {
            powerMultiPressAction(eventTime, interactive, mTriplePressOnPowerBehavior);
        } else if (interactive && !mBeganFromNonInteractive) {
            switch (mShortPressOnPowerBehavior) {
                case SHORT_PRESS_POWER_NOTHING:
                    break;
                case SHORT_PRESS_POWER_GO_TO_SLEEP:
                    goToSleepFromPowerButton(eventTime, 0);
                    break;
                case SHORT_PRESS_POWER_REALLY_GO_TO_SLEEP:
                    goToSleepFromPowerButton(eventTime, PowerManager.GO_TO_SLEEP_FLAG_NO_DOZE);
                    break;
                case SHORT_PRESS_POWER_REALLY_GO_TO_SLEEP_AND_GO_HOME:
                    if (goToSleepFromPowerButton(eventTime,
                            PowerManager.GO_TO_SLEEP_FLAG_NO_DOZE)) {
                        launchHomeFromHotKey(DEFAULT_DISPLAY);
                    }
                    break;
                case SHORT_PRESS_POWER_GO_HOME:
                    shortPressPowerGoHome();
                    break;
                case SHORT_PRESS_POWER_CLOSE_IME_OR_GO_HOME: {
                    if (mDismissImeOnBackKeyPressed) {
                        if (mInputMethodManagerInternal == null) {
                            mInputMethodManagerInternal =
                                    LocalServices.getService(InputMethodManagerInternal.class);
                        }
                        if (mInputMethodManagerInternal != null) {
                            mInputMethodManagerInternal.hideCurrentInputMethod();
                        }
                    } else {
                        shortPressPowerGoHome();
                    }
                    break;
                }
            }
        }
    }

```

在powerPress(long eventTime, boolean interactive, int count)中电源键短按事件的处理  
 增加persist.sys.power.enable系统属性来判断是否响应电源短按事件来控制是否禁用电源键


2.电源键长按事件的处理



```
 private void powerLongPress() {
 		 //添加标志位 当为false时返回
		String aTrue = SystemProperties.get("persist.sys.power.enable", "true");
		if(!"true".equals(aTrue)){
			return;
		}
       
        final int behavior = getResolvedLongPressOnPowerBehavior();
        switch (behavior) {
            case LONG_PRESS_POWER_NOTHING:
                break;
            case LONG_PRESS_POWER_GLOBAL_ACTIONS:
                mPowerKeyHandled = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS, false,
                        "Power - Long Press - Global Actions");
                showGlobalActionsInternal();
                break;
            case LONG_PRESS_POWER_SHUT_OFF:
            case LONG_PRESS_POWER_SHUT_OFF_NO_CONFIRM:
                mPowerKeyHandled = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS, false,
                        "Power - Long Press - Shut Off");
                sendCloseSystemWindows(SYSTEM_DIALOG_REASON_GLOBAL_ACTIONS);
                mWindowManagerFuncs.shutdown(behavior == LONG_PRESS_POWER_SHUT_OFF);
                break;
            case LONG_PRESS_POWER_GO_TO_VOICE_ASSIST:
                mPowerKeyHandled = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS, false,
                        "Power - Long Press - Go To Voice Assist");
                // Some devices allow the voice assistant intent during setup (and use that intent
                // to launch something else, like Settings). So we explicitly allow that via the
                // config_allowStartActivityForLongPressOnPowerInSetup resource in config.xml.
                launchVoiceAssist(mAllowStartActivityForLongPressOnPowerDuringSetup);
                break;
            case LONG_PRESS_POWER_ASSISTANT:
                mPowerKeyHandled = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS, false,
                        "Power - Long Press - Go To Assistant");
                final int powerKeyDeviceId = Integer.MIN_VALUE;
                launchAssistAction(null, powerKeyDeviceId);
                break;
        }
    }

```

在powerLongPress()中增加persist.sys.power.enable，根据系统属性的值来判断当前是否响应电源长按键，来决定是否禁用电源键功能





