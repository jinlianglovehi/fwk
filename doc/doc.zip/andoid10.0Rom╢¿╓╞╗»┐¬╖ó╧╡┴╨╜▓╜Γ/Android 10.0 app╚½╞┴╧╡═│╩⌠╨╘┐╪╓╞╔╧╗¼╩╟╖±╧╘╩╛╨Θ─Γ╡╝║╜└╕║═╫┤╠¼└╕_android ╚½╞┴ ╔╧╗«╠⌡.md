



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.app全屏系统属性控制上滑是否显示虚拟导航栏和状态栏核心代码](#2.app%E5%85%A8%E5%B1%8F%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E6%8E%A7%E5%88%B6%E4%B8%8A%E6%BB%91%E6%98%AF%E5%90%A6%E6%98%BE%E7%A4%BA%E8%99%9A%E6%8B%9F%E5%AF%BC%E8%88%AA%E6%A0%8F%E5%92%8C%E7%8A%B6%E6%80%81%E6%A0%8F%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.app全屏系统属性控制上滑是否显示虚拟导航栏和状态栏核心代码功能分析](#3.app%E5%85%A8%E5%B1%8F%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E6%8E%A7%E5%88%B6%E4%B8%8A%E6%BB%91%E6%98%AF%E5%90%A6%E6%98%BE%E7%A4%BA%E8%99%9A%E6%8B%9F%E5%AF%BC%E8%88%AA%E6%A0%8F%E5%92%8C%E7%8A%B6%E6%80%81%E6%A0%8F%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 DisplayPolicy.java关于全局手势相关功能分析](#3.1%20DisplayPolicy.java%E5%85%B3%E4%BA%8E%E5%85%A8%E5%B1%80%E6%89%8B%E5%8A%BF%E7%9B%B8%E5%85%B3%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.2 StatusBarController.java关于状态栏的相关代码](#3.2%20StatusBarController.java%E5%85%B3%E4%BA%8E%E7%8A%B6%E6%80%81%E6%A0%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.3 BarController的相关方法](#3.3%20BarController%E7%9A%84%E7%9B%B8%E5%85%B3%E6%96%B9%E6%B3%95)


[4. 根据上述分析实现功能](#4.%20%E6%A0%B9%E6%8D%AE%E4%B8%8A%E8%BF%B0%E5%88%86%E6%9E%90%E5%AE%9E%E7%8E%B0%E5%8A%9F%E8%83%BD)




---



## 1.概述


  在定制化os开发中，在app设置全屏后，会隐藏导航栏和状态栏，页面全屏显示，然后底部上滑会显示虚拟状态栏和导航栏显示几秒钟后会自动消失，由于项目开发需要要求通过api来控制全屏时上滑是否显示虚拟导航栏和状态栏，这就要从上滑事件分析看如何显示虚拟导航栏和状态栏的流程来控制是否显示


![](https://img-blog.csdnimg.cn/868416f1f2864a9c9151e8790a6a766a.png)



## 2.app全屏系统属性控制上滑是否显示虚拟导航栏和状态栏核心代码



```
  frameworks\base\services\core\java\com\android\server\wm\DisplayPolicy.java
  frameworks\base\services\core\java\com\android\server\wm\StatusBarController.java
  frameworks\base\services\core\java\com\android\server\wm\BarController.java
```

## 3.app全屏系统属性控制上滑是否显示虚拟导航栏和状态栏核心代码功能分析


在系统中SystemUI的核心布局导航栏和状态栏，  
 NavigationBar 和 StatusBar 都属于 SystemBar的子类，继承和完善SystemBar的一些基本特效，  
 而系统的window的是在 DisplayPolicy的layoutWindowLw方法中布局的，  
 而导航栏和状态栏分别是在DisplayPolicy的layoutNavigationBar和layoutStatusBar方法中布局的。  
 Statusbar包含导航栏(NavigationBar, 位于左侧、右侧或者底部)和状态栏(StatusBar, 位于顶部, 可下拉)两个部分  
 所以说关于系统SystemUI的导航栏状态栏的布局就需要主要分析DisplayPolicy.java的相关源码


在DisplayPolicy.java中的SystemGesturesPointerEventListener这个手势监听回调内部类中，关于  
 类似onSwipeFromBottom()这个方法里面主要控件导航栏的就是StatusBarController.java，而从这里面  
 阅读相关源码发现，最终控制导航栏状态栏是在BarController.java中处理的，所以接下来  
 主要分析DisplayPolicy.java和BarController.java中的相关核心代码



## 3.1 DisplayPolicy.java关于全局手势相关功能分析



```
 public class DisplayPolicy extends AbsDisplayPolicy {

....
  mSystemGestures = new SystemGesturesPointerEventListener(mContext, mHandler,
                new SystemGesturesPointerEventListener.Callbacks() {
                    @Override
                    public void onSwipeFromTop() {
                        if (mStatusBar != null) {
                            requestTransientBars(mStatusBar);
                        }
                    }

                    @Override
                    public void onSwipeFromBottom() {
                        if (mNavigationBar != null && mNavigationBarPosition == NAV_BAR_BOTTOM) {
                            requestTransientBars(mNavigationBar);
                            /**
                             * unisoc bug 1074912: add for dynamic navigationbar
                             * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                             * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                             */
                            if (mDynamicNavigationBar&&!mService.isKeyguardShowingAndNotOccluded()&&!isNavigationBarShowing()) {
                                Slog.d(TAG," onSwipeFromBottom show = true");
                                updateShowHideNavSettings(true);
                            }
                        }
                    }

                    @Override
                    public void onSwipeFromRight() {
                        final Region excludedRegion;
                        synchronized (mLock) {
                            excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
                        }
                        final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
                                || mNavigationBarPosition == NAV_BAR_RIGHT;
                        if (mNavigationBar != null && sideAllowed
                                && !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
                            requestTransientBars(mNavigationBar);
                        }
                        /**
                         * unisoc bug 1074912/1145137: add for dynamic navigationbar
                         * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                         * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                         */
                        if ((mNavigationBarPosition == NAV_BAR_RIGHT)&&mDynamicNavigationBar
                                &&!mService.isKeyguardShowingAndNotOccluded()
                                &&!isNavigationBarShowing()) {
                            Slog.d(TAG," onSwipeFromRight show = true");
                            updateShowHideNavSettings(true);
                         }
                    }

                    @Override
                    public void onSwipeFromLeft() {
                        final Region excludedRegion;
                        synchronized (mLock) {
                            excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
                        }
                        final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
                                || mNavigationBarPosition == NAV_BAR_LEFT;
                        if (mNavigationBar != null && sideAllowed
                                && !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
                            requestTransientBars(mNavigationBar);
                        }
                        /**
                         * unisoc bug 1074912/1145137: add for dynamic navigationbar
                         * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                         * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                         */
                        if ((mNavigationBarPosition == NAV_BAR_LEFT)&&mDynamicNavigationBar
                                &&!mService.isKeyguardShowingAndNotOccluded()
                                &&!isNavigationBarShowing()) {
                            Slog.d(TAG," onSwipeFromLeft show = true");
                            updateShowHideNavSettings(true);
                        }
                    }

             
                });
```

// 通过DisplayPolicy.java上述代码可以看出在SystemGesturesPointerEventListener上滑手势事件 然后掉requestTransientBars(mNavigationBar);执行相关功能



```
           @Override
                    public void onSwipeFromBottom() {
                        if (mNavigationBar != null && mNavigationBarPosition == NAV_BAR_BOTTOM) {
                            requestTransientBars(mNavigationBar);
                            /**
                             * unisoc bug 1074912: add for dynamic navigationbar
                             * dont need to layout when is keyguard(who is hide navidationbar) & navigationbar showing.
                             * showNavigationbar can layout&change provider.then mShowHideNavObserver also can layout.so just modify provider here.
                             */
                            if (mDynamicNavigationBar&&!mService.isKeyguardShowingAndNotOccluded()&&!isNavigationBarShowing()) {
                                Slog.d(TAG," onSwipeFromBottom show = true");
                                updateShowHideNavSettings(true);
                            }
                        }
                    }

private void requestTransientBars(WindowState swipeTarget) {
        synchronized (mLock) {
            if (!mService.mPolicy.isUserSetupComplete()) {
                // Swipe-up for navigation bar is disabled during setup
                return;
            }
            // 判断导航栏状态栏是否隐藏
            boolean sb = mStatusBarController.checkShowTransientBarLw();
            boolean nb = mNavigationBarController.checkShowTransientBarLw()
                    && !isNavBarEmpty(mLastSystemUiFlags);
            if (sb || nb) {
                // Don't show status bar when swiping on already visible navigation bar
                if (!nb && swipeTarget == mNavigationBar) {
                    if (DEBUG) Slog.d(TAG, "Not showing transient bar, wrong swipe target");
                    return;
                }
               // 显示虚拟导航栏和状态栏
                if (sb) mStatusBarController.showTransient();
                if (nb) mNavigationBarController.showTransient();
                mImmersiveModeConfirmation.confirmCurrentPrompt();
                updateSystemUiVisibilityLw();
            }
        }
    }
```

## 3.2 StatusBarController.java关于状态栏的相关代码



```
    public class StatusBarController extends BarController {

    private final AppTransitionListener mAppTransitionListener = new AppTransitionListener() {

        private Runnable mAppTransitionPending = () -> {
            StatusBarManagerInternal statusBar = getStatusBarInternal();
            if (statusBar != null) {
                statusBar.appTransitionPending(mDisplayId);
            }
        };

        private Runnable mAppTransitionCancelled = () -> {
            StatusBarManagerInternal statusBar = getStatusBarInternal();
            if (statusBar != null) {
                statusBar.appTransitionCancelled(mDisplayId);
            }
        };

        private Runnable mAppTransitionFinished = () -> {
            StatusBarManagerInternal statusBar = getStatusBarInternal();
            if (statusBar != null) {
                statusBar.appTransitionFinished(mDisplayId);
            }
        };

        
    };}
```

从StatusBarController.java的上述相关代码中发现StatusBarController继承BarController实现相关方法，核心方法就是在BarController.java中实现的


## 3.3 BarController的相关方法



```
public class BarController {
   ...

    BarController(String tag, int displayId, int transientFlag, int unhideFlag, int translucentFlag,
            int statusBarManagerId, int translucentWmFlag, int transparentFlag) {
        mTag = "BarController." + tag;
        mDisplayId = displayId;
        mTransientFlag = transientFlag;
        mUnhideFlag = unhideFlag;
        mTranslucentFlag = translucentFlag;
        mStatusBarManagerId = statusBarManagerId;
        mTranslucentWmFlag = translucentWmFlag;
        mTransparentFlag = transparentFlag;
        mHandler = new BarHandler();
    }
void setShowTransparent(boolean transparent) {
        if (transparent != mShowTransparent) {
            mShowTransparent = transparent;
            mSetUnHideFlagWhenNextTransparent = transparent;
            mNoAnimationOnNextShow = true;
        }
    }

    void showTransient() {
        if (mWin != null) {
            setTransientBarState(TRANSIENT_BAR_SHOW_REQUESTED);
        }
    }

boolean checkShowTransientBarLw() {
        if (mTransientBarState == TRANSIENT_BAR_SHOWING) {
            if (DEBUG) Slog.d(mTag, "Not showing transient bar, already shown");
            return false;
        } else if (mTransientBarState == TRANSIENT_BAR_SHOW_REQUESTED) {
            if (DEBUG) Slog.d(mTag, "Not showing transient bar, already requested");
            return false;
        } else if (mWin == null) {
            if (DEBUG) Slog.d(mTag, "Not showing transient bar, bar doesn't exist");
            return false;
        } else if (mWin.isDisplayedLw()) {
            if (DEBUG) Slog.d(mTag, "Not showing transient bar, bar already visible");
            return false;
        } else {
            return true;
        }
    }
.....
}
```

从BarController.java的上述代码可以看出，在checkShowTransientBarLw() 判断导航栏状态栏是否隐藏，然后showTransient()负责显示导航栏和状态栏


## 4. 根据上述分析实现功能


 在DisplayPolicy.java修改如下：



```
  private void requestTransientBars(WindowState swipeTarget) {
        synchronized (mLock) {
            if (!mService.mPolicy.isUserSetupComplete()) {
                // Swipe-up for navigation bar is disabled during setup
                return;
            }
            boolean sb = mStatusBarController.checkShowTransientBarLw();
            boolean nb = mNavigationBarController.checkShowTransientBarLw()
                    && !isNavBarEmpty(mLastSystemUiFlags);
            if (sb || nb) {
                // Don't show status bar when swiping on already visible navigation bar
                if (!nb && swipeTarget == mNavigationBar) {
                    if (DEBUG) Slog.d(TAG, "Not showing transient bar, wrong swipe target");
                    return;
                }
               // add core start 
              int settings_custom = Settings.Global.getInt(getContext().getContentResolver(),"settings_custom",0);
              if (settings_custom ==1){
                 if (sb) mStatusBarController.showTransient();
                 if (nb) mNavigationBarController.showTransient();
              }
              // add core end
                mImmersiveModeConfirmation.confirmCurrentPrompt();
                updateSystemUiVisibilityLw();
            }
        }
    }
```

通过设置settings\_custom上滑显示和隐藏虚拟状态栏和导航栏。最终实现了功能的开发，完成了项目需求



