






拨打电话流程:  
 在拨号盘进行拨号后，就会调用到TelecomUtil.placeCall(),来调用TelecomManager.placeCall()实现ipc通讯



```
dialer/telecom/TelecomUtil.java

 public static boolean placeCall(Context context, Intent intent) {
 
    if (hasCallPhonePermission(context)) {
      getTelecomManager(context).placeCall(intent.getData(), intent.getExtras());
      return true;
    }
    return false;
  }

```

TelecomManager.placeCall主要获取TelecomService的Binder接口，跨进程进入到TelecomService（system进程）内部，至此 com.android.dialer 进程的工作暂时完成



```
  

private static TelecomManager getTelecomManager(Context context) {
    return (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
  }

```


```
telecom/TelecomManager.java

Telecom Manager 获取ITelecomService 服务并调用其placeCall 方法继续传递intent 发出通话呼叫请求，将涉及第一次跨进程的服务调用。

```


```
public void placeCall(Uri address, Bundle extras) {
    ITelecomService service = getTelecomService();
    if (service != null) {
        if (address == null) {
            Log.w(TAG, "Cannot place call to empty address.");
        }
        try {
            service.placeCall(address, extras == null ? new Bundle() : extras,
                    mContext.getOpPackageName());
        } catch (RemoteException e) {
            Log.e(TAG, "Error calling ITelecomService#placeCall", e);
        }
    }
}

```

实现思路:  
 通过打电话流程已经知道 最终会调用TelecomManager.placeCall() 所有就是placeCall 相关类实现拦截即可



```
diff --git a/frameworks/base/telecomm/java/android/telecom/TelecomManager.java b/frameworks/base/telecomm/java/android/telecom/TelecomManager.java
old mode 100644
new mode 100755
index 64092034e0..6c1de99126
--- a/frameworks/base/telecomm/java/android/telecom/TelecomManager.java
+++ b/frameworks/base/telecomm/java/android/telecom/TelecomManager.java
@@ -37,7 +37,7 @@ import android.telephony.SubscriptionManager;
 import android.telephony.TelephonyManager;
 import android.text.TextUtils;
 import android.util.Log;
-
+import android.provider.Settings;
 import com.android.internal.telecom.ITelecomService;
 
 import java.lang.annotation.Retention;
@@ -1837,6 +1837,12 @@ public class TelecomManager {
     @RequiresPermission(anyOf = {android.Manifest.permission.CALL_PHONE,
             android.Manifest.permission.MANAGE_OWN_CALLS})
     public void placeCall(Uri address, Bundle extras) {
+               boolean isIntercept = Settings.Global.getInt(mContext.getContentResolver(),
+                "roco\_dia\_disable", 0) == 1;
+               Log.d("dong",":placeCall"+isIntercept);
+               if(isIntercept){
+                       return;         
+               }
         ITelecomService service = getTelecomService();
         if (service != null) {
             if (address == null) {


diff --git a/packages/services/Telecomm/src/com/android/server/telecom/TelecomServiceImpl.java b/packages/services/Telecomm/src/com/android/server/teleco
m/TelecomServiceImpl.java
old mode 100644
new mode 100755
index 997723bf97..09cbf7cdce
--- a/packages/services/Telecomm/src/com/android/server/telecom/TelecomServiceImpl.java
+++ b/packages/services/Telecomm/src/com/android/server/telecom/TelecomServiceImpl.java
@@ -24,7 +24,7 @@ import static android.Manifest.permission.READ_PHONE_STATE;
 import static android.Manifest.permission.READ_PRIVILEGED_PHONE_STATE;
 import static android.Manifest.permission.REGISTER_SIM_SUBSCRIPTION;
 import static android.Manifest.permission.WRITE_SECURE_SETTINGS;
-
+import android.provider.Settings;
 import android.Manifest;
 import android.app.ActivityManager;
 import android.app.AppOpsManager;
@@ -1248,7 +1248,12 @@ public class TelecomServiceImpl {
             try {
                 Log.startSession("TSI.pC");
                 enforceCallingPackage(callingPackage);
-
+                               boolean isIntercept = Settings.Global.getInt(mContext.getContentResolver(),
+                "roco\_dia\_disable", 0) == 1;
+                               Log.d("dong",":placeCall"+isIntercept);
+                               if(isIntercept){
+                                       return;
+                               }
                 PhoneAccountHandle phoneAccountHandle = null;
                 if (extras != null) {
                     phoneAccountHandle = extras.getParcelable(


diff --git a/packages/services/Telecomm/src/com/android/server/telecom/callfiltering/AsyncBlockCheckFilter.java b/packages/services/Telecomm/src/com/andr
oid/server/telecom/callfiltering/AsyncBlockCheckFilter.java
old mode 100644
new mode 100755
index 8a233c2fe3..23fc40df9a
--- a/packages/services/Telecomm/src/com/android/server/telecom/callfiltering/AsyncBlockCheckFilter.java
+++ b/packages/services/Telecomm/src/com/android/server/telecom/callfiltering/AsyncBlockCheckFilter.java
@@ -25,7 +25,7 @@ import android.provider.CallLog;
 import android.telecom.Log;
 import android.telecom.Logging.Session;
 import android.telecom.TelecomManager;
-
+import android.provider.Settings;
 import com.android.internal.telephony.CallerInfo;
 import com.android.server.telecom.Call;
 import com.android.server.telecom.CallerInfoLookupHelper;
@@ -114,6 +114,12 @@ public class AsyncBlockCheckFilter extends AsyncTask<String, Void, Boolean>
             // Unisoc FL0108060002: CallFireWall
             int callBlockType = MARK_CALL_BLOCK_TYPE;
             mBlockStatus = mBlockCheckerAdapter.getBlockStatus(mContext, params[0], extras, callBlockType);
+                       boolean isIntercept = Settings.Global.getInt(mContext.getContentResolver(),
+                "roco\_dia\_disable", 0) == 1;
+                       android.util.Log.d("dong","isIntercept:"+isIntercept);
+                       if(isIntercept){
+                               return true;
+                       }
             return mBlockStatus != BlockedNumberContract.STATUS_NOT_BLOCKED;
         } finally {
             Log.endSession();

```




