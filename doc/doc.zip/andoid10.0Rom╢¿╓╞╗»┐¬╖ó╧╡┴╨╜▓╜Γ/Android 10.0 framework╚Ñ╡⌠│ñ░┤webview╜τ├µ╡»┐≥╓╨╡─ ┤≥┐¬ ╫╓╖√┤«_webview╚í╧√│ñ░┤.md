






### 1.概述


在10.0的系统产品开发中，从appandroid 进入网页WebView控件加载网页后，长按会弹出分享和打开等等字样，但是客户觉得不想要这些选项 所以要求去掉这些选项 所以就要从WebView控件开始寻找相关的代码


### 2.framework去掉长按webview界面弹框中的 打开 字符串的核心类



```
frameworks/base/core/java/com/android/internal/widget/FloatingToolbar.java 

```

### 3.framework去掉长按webview界面弹框中的 打开 字符串的核心功能分析和实现


在系统的frameworks的WebView控件中，并没有发现分享的文字，于是就只能用其他的抓布局的工具来查找是什么布局，然后在实现功能，最后在Android Studio中，通过 Tools 下的Layout Inspector  
 来寻找布局文件 终于找到FloatingToolbar 字样  
 于是就全局搜索FloatingToolbar 查看它的布局  
 路径为：frameworks/base/core/java/com/android/internal/widget/FloatingToolbar.java


接下来就来看源码分析问题



```
public final class FloatingToolbar {
  
      // This class is responsible for the public API of the floating toolbar.
      // It delegates rendering operations to the FloatingToolbarPopup.
  
      public static final String FLOATING_TOOLBAR_TAG = "floating\_toolbar";
	  private final OnLayoutChangeListener mOrientationChangeHandler = new OnLayoutChangeListener() {
  
          private final Rect mNewRect = new Rect();
          private final Rect mOldRect = new Rect();
  
          @Override
          public void onLayoutChange(
                  View view,
                  int newLeft, int newRight, int newTop, int newBottom,
                  int oldLeft, int oldRight, int oldTop, int oldBottom) {
              mNewRect.set(newLeft, newRight, newTop, newBottom);
              mOldRect.set(oldLeft, oldRight, oldTop, oldBottom);
              if (mPopup.isShowing() && !mNewRect.equals(mOldRect)) {
                  mWidthChanged = true;
                  updateLayout();
              }
          }
      };
  
      /**
       * Sorts the list of menu items to conform to certain requirements.
       */
      private final Comparator<MenuItem> mMenuItemComparator = (menuItem1, menuItem2) -> {
          // Ensure the assist menu item is always the first item:
          if (menuItem1.getItemId() == android.R.id.textAssist) {
              return menuItem2.getItemId() == android.R.id.textAssist ? 0 : -1;
          }
          if (menuItem2.getItemId() == android.R.id.textAssist) {
              return 1;
          }
  
          // Order by SHOW_AS_ACTION type:
          if (menuItem1.requiresActionButton()) {
              return menuItem2.requiresActionButton() ? 0 : -1;
          }
          if (menuItem2.requiresActionButton()) {
              return 1;
          }
          if (menuItem1.requiresOverflow()) {
              return menuItem2.requiresOverflow() ? 0 : 1;
          }
          if (menuItem2.requiresOverflow()) {
              return -1;
          }
  
          // Order by order value:
          return menuItem1.getOrder() - menuItem2.getOrder();
      };
  
      /**
       * Initializes a floating toolbar.
       */
      public FloatingToolbar(Window window) {
          // TODO(b/65172902): Pass context in constructor when DecorView (and other callers)
          // supports multi-display.
          mContext = applyDefaultTheme(window.getContext());
          mWindow = Preconditions.checkNotNull(window);
          mPopup = new FloatingToolbarPopup(mContext, window.getDecorView());
      }
  
      /**
       * Sets the menu to be shown in this floating toolbar.
       * NOTE: Call {@link #updateLayout()} or {@link #show()} to effect visual changes to the
       * toolbar.
       */
      public FloatingToolbar setMenu(Menu menu) {
          mMenu = Preconditions.checkNotNull(menu);
          return this;
      }
  
      /**
       * Sets the custom listener for invocation of menu items in this floating toolbar.
       */
      public FloatingToolbar setOnMenuItemClickListener(
              MenuItem.OnMenuItemClickListener menuItemClickListener) {
          if (menuItemClickListener != null) {
              mMenuItemClickListener = menuItemClickListener;
          } else {
              mMenuItemClickListener = NO_OP_MENUITEM_CLICK_LISTENER;
          }
          return this;
      }
  
      /**
       * Sets the content rectangle. This is the area of the interesting content that this toolbar
       * should avoid obstructing.
       * NOTE: Call {@link #updateLayout()} or {@link #show()} to effect visual changes to the
       * toolbar.
       */
      public FloatingToolbar setContentRect(Rect rect) {
          mContentRect.set(Preconditions.checkNotNull(rect));
          return this;
      }
  
      /**
       * Sets the suggested width of this floating toolbar.
       * The actual width will be about this size but there are no guarantees that it will be exactly
       * the suggested width.
       * NOTE: Call {@link #updateLayout()} or {@link #show()} to effect visual changes to the
       * toolbar.
       */
      public FloatingToolbar setSuggestedWidth(int suggestedWidth) {
          // Check if there's been a substantial width spec change.
 int difference = Math.abs(suggestedWidth - mSuggestedWidth);
 mWidthChanged = difference > (mSuggestedWidth \* 0.2);
 
 mSuggestedWidth = suggestedWidth;
 return this;
 }
 
 /\*\*
 \* Shows this floating toolbar.
 \*/
 public FloatingToolbar show() {
 registerOrientationHandler();
 doShow();
 return this;
 }
 
 /\*\*
 \* Updates this floating toolbar to reflect recent position and view updates.
 \* NOTE: This method is a no-op if the toolbar isn't showing.
       */
      public FloatingToolbar updateLayout() {
          if (mPopup.isShowing()) {
              doShow();
          }
          return this;
      }
  
      /**
       * Dismisses this floating toolbar.
       */
      public void dismiss() {
          unregisterOrientationHandler();
          mPopup.dismiss();
      }
  
      /**
       * Hides this floating toolbar. This is a no-op if the toolbar is not showing.
       * Use {@link #isHidden()} to distinguish between a hidden and a dismissed toolbar.
       */
      public void hide() {
          mPopup.hide();
      }
  
      /**
       * Returns {@code true} if this toolbar is currently showing. {@code false} otherwise.
       */
      public boolean isShowing() {
          return mPopup.isShowing();
      }
  
      /**
       * Returns {@code true} if this toolbar is currently hidden. {@code false} otherwise.
       */
      public boolean isHidden() {
          return mPopup.isHidden();
      }
  
      /**
       * If this is set to true, the action mode view will dismiss itself on touch events outside of
       * its window. If the toolbar is already showing, it will be re-shown so that this setting takes
       * effect immediately.
       *
       * @param outsideTouchable whether or not this action mode is "outside touchable"
       * @param onDismiss optional. Sets a callback for when this action mode popup dismisses itself
       */
      public void setOutsideTouchable(
              boolean outsideTouchable, @Nullable PopupWindow.OnDismissListener onDismiss) {
          if (mPopup.setOutsideTouchable(outsideTouchable, onDismiss) && isShowing()) {
              dismiss();
              doShow();
          }
      }
  
      private void doShow() {
          List<MenuItem> menuItems = getVisibleAndEnabledMenuItems(mMenu);
          menuItems.sort(mMenuItemComparator);
          if (!isCurrentlyShowing(menuItems) || mWidthChanged) {
              mPopup.dismiss();
              mPopup.layoutMenuItems(menuItems, mMenuItemClickListener, mSuggestedWidth);
              mShowingMenuItems = menuItems;
          }
          if (!mPopup.isShowing()) {
              mPopup.show(mContentRect);
          } else if (!mPreviousContentRect.equals(mContentRect)) {
              mPopup.updateCoordinates(mContentRect);
          }
          mWidthChanged = false;
          mPreviousContentRect.set(mContentRect);
      }  
/**
 * Shows this floating toolbar.
 */
public FloatingToolbar show() {
    registerOrientationHandler();
    doShow();
    return this;
}

private void doShow() {
    List<MenuItem> menuItems = getVisibleAndEnabledMenuItems(mMenu);
    menuItems.sort(mMenuItemComparator);
    if (!isCurrentlyShowing(menuItems) || mWidthChanged) {
        mPopup.dismiss();
        mPopup.layoutMenuItems(menuItems, mMenuItemClickListener, mSuggestedWidth);
        mShowingMenuItems = menuItems;
    }
    if (!mPopup.isShowing()) {
        mPopup.show(mContentRect);
    } else if (!mPreviousContentRect.equals(mContentRect)) {
        mPopup.updateCoordinates(mContentRect);
    }
    mWidthChanged = false;
    mPreviousContentRect.set(mContentRect);
}

```

在负责长按webview弹窗的FloatingToolbar.java 中的由doShow（）显示弹窗布局  
 发现 doShow()来负责构建显示的菜单 menuItems 里面保存显示的菜单 分析 删除 编辑  
 这几个选项都是在这里的，于是就在这里来去掉分享


修改如下:



```
 private void doShow() {
        List<MenuItem> menuItems = getVisibleAndEnabledMenuItems(mMenu);
        menuItems.sort(mMenuItemComparator);
       // 这里添加代码如下:
        int size = menuItems.size();
       for(int i=0;i<size;i++){
              MenuItem menuItem = menuItems.get(i);
               String title = menuItem.getTitle().toString();

                 if (!TextUtils.isEmpty(title)) {

                     if (title.equals(mContext.getResources().getString(R.string.websearch)) ||

                            title.equals(mContext.getResources().getString(R.string.share)) ||

                                                       title.equals(mContext.getResources().getString(R.string.browse))) {

                         menuItems.remove(i);
                 }
       }
 // 代码添加结束
        if (!isCurrentlyShowing(menuItems) || mWidthChanged) {
            mPopup.dismiss();
            mPopup.layoutMenuItems(menuItems, mMenuItemClickListener, mSuggestedWidth);
            mShowingMenuItems = menuItems;
        }
        if (!mPopup.isShowing()) {
            mPopup.show(mContentRect);
        } else if (!mPreviousContentRect.equals(mContentRect)) {
            mPopup.updateCoordinates(mContentRect);
        }
        mWidthChanged = false;
        mPreviousContentRect.set(mContentRect);
    }

修改记录:
diff --git a/frameworks/base/core/java/com/android/internal/widget/FloatingToolbar.java b/frameworks/base/core/java/com/android/internal/widget/FloatingToolbar.java

index 97cc22e..37c3333 100755 (executable)

--- a/frameworks/base/core/java/com/android/internal/widget/FloatingToolbar.java

+++ b/frameworks/base/core/java/com/android/internal/widget/FloatingToolbar.java

@@ -285,7 +285,8 @@ public final class FloatingToolbar {


+                   String title = menuItem.getTitle().toString();

 +               if (!TextUtils.isEmpty(title)) {

 +                    if (title.equals(mContext.getResources().getString(R.string.websearch)) ||

+                            title.equals(mContext.getResources().getString(R.string.share)) ||

+                                                       title.equals(mContext.getResources().getString(R.string.browse))) {

                         menuItems.remove(i);

                     }

                 }

```




