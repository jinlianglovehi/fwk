






现在的android手机平板基本上都支持双卡双待，而一般用户都默认sim1卡来使用流量和发送短信打电话  
 下面我们就来看源码来分析下怎么设置默认sim1卡为默认卡


在package/apps/Settings app的AndroidMainfest.xml中



```
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:androidprv="http://schemas.android.com/apk/prv/res/android"
        package="com.android.settings"
        coreApp="true"
        android:sharedUserId="android.uid.system">
        <receiver android:name=".sim.SimSelectNotification">
      .....
            <intent-filter>
                <action android:name="android.telephony.action.PRIMARY\_SUBSCRIPTION\_LIST\_CHANGED"/>
                <action android:name="android.settings.ENABLE\_MMS\_DATA\_REQUEST"/>
            </intent-filter>
        </receiver>
</mainfest>

```

可以看到android.settings.ENABLE\_MMS\_DATA\_REQUEST这个是属于设置数据流量的广播  
 在framework/base/core/java/android/provider/Settings.java 中定义为:



```
@SdkConstant(SdkConstantType.BROADCAST_INTENT_ACTION)
    public static final String ACTION_ENABLE_MMS_DATA_REQUEST =
            "android.settings.ENABLE\_MMS\_DATA\_REQUEST";

```

接下来再看 SimSelectNotification.java  
 路径为：packages\apps\Settings\src\com\android\settings\sim\SimSelectNotification.java



```
public class SimSelectNotification extends BroadcastReceiver {
    private static final String TAG = "SimSelectNotification";
    @VisibleForTesting
    public static final int SIM_SELECT_NOTIFICATION_ID = 1;
    @VisibleForTesting
    public static final int ENABLE_MMS_NOTIFICATION_ID = 2;
    @VisibleForTesting
    public static final int SIM_WARNING_NOTIFICATION_ID = 3;

    @VisibleForTesting
    public static final String SIM_SELECT_NOTIFICATION_CHANNEL =
            "sim\_select\_notification\_channel";

    @VisibleForTesting
    public static final String ENABLE_MMS_NOTIFICATION_CHANNEL =
            "enable\_mms\_notification\_channel";

    @VisibleForTesting
    public static final String SIM_WARNING_NOTIFICATION_CHANNEL =
            "sim\_warning\_notification\_channel";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (action == null) {
            Log.w(TAG, "Received unexpected intent with null action.");
            return;
        }

        switch (action) {
            case TelephonyManager.ACTION_PRIMARY_SUBSCRIPTION_LIST_CHANGED:
                onPrimarySubscriptionListChanged(context, intent);
                break;
            case Settings.ACTION_ENABLE_MMS_DATA_REQUEST:
                onEnableMmsDataRequest(context, intent);
                break;
            default:
                Log.w(TAG, "Received unexpected intent " + intent.getAction());
        }
    }

    private void onEnableMmsDataRequest(Context context, Intent intent) {
        // Getting subId from extra.
        int subId = intent.getIntExtra(EXTRA_SUB_ID, SubscriptionManager.INVALID_SUBSCRIPTION_ID);
        if (subId == SubscriptionManager.DEFAULT_SUBSCRIPTION_ID) {
            subId = SubscriptionManager.getDefaultSmsSubscriptionId();
        }

        SubscriptionManager subscriptionManager = ((SubscriptionManager) context.getSystemService(
 Context.TELEPHONY\_SUBSCRIPTION\_SERVICE));
        if (!subscriptionManager.isActiveSubId(subId)) {
            Log.w(TAG, "onEnableMmsDataRequest invalid sub ID " + subId);
            return;
        }
        final SubscriptionInfo info = subscriptionManager.getActiveSubscriptionInfo(subId);
        if (info == null) {
            Log.w(TAG, "onEnableMmsDataRequest null SubscriptionInfo for sub ID " + subId);
            return;
        }

        // Getting request reason from extra, which will determine the notification title.
        CharSequence notificationTitle = null;
        int requestReason = intent.getIntExtra(EXTRA_ENABLE_MMS_DATA_REQUEST_REASON, -1);
        if (requestReason == ENABLE_MMS_DATA_REQUEST_REASON_INCOMING_MMS) {
            notificationTitle = context.getResources().getText(
                    R.string.enable_receiving_mms_notification_title);
        } else if (requestReason == ENABLE_MMS_DATA_REQUEST_REASON_OUTGOING_MMS) {
            notificationTitle = context.getResources().getText(
                    R.string.enable_sending_mms_notification_title);
        } else {
            Log.w(TAG, "onEnableMmsDataRequest invalid request reason " + requestReason);
            return;
        }

        TelephonyManager tm = ((TelephonyManager) context.getSystemService(
 Context.TELEPHONY\_SERVICE)).createForSubscriptionId(subId);

        if (tm.isDataEnabledForApn(TYPE_MMS)) {
            Log.w(TAG, "onEnableMmsDataRequest MMS data already enabled on sub ID " + subId);
            return;
        }

        CharSequence notificationSummary = context.getResources().getString(
                R.string.enable_mms_notification_summary, SubscriptionUtil.getDisplayName(info));

        cancelEnableMmsNotification(context);

        createEnableMmsNotification(context, notificationTitle, notificationSummary, subId);
    }
}

```

从上面代码可以看出当收到Settings.ACTION\_ENABLE\_MMS\_DATA\_REQUEST的广播时  
 调用onEnableMmsDataRequest(context, intent);  
 所以实际处理代码就是在这里  
 修改为：



```
private void onEnableMmsDataRequest(Context context, Intent intent) {
        // Getting subId from extra.
        int subId = intent.getIntExtra(EXTRA_SUB_ID, SubscriptionManager.INVALID_SUBSCRIPTION_ID);
        if (subId == SubscriptionManager.DEFAULT_SUBSCRIPTION_ID) {
            subId = SubscriptionManager.getDefaultSmsSubscriptionId();
        }

        SubscriptionManager subscriptionManager = ((SubscriptionManager) context.getSystemService(
 Context.TELEPHONY\_SUBSCRIPTION\_SERVICE));
        if (!subscriptionManager.isActiveSubId(subId)) {
            Log.w(TAG, "onEnableMmsDataRequest invalid sub ID " + subId);
            return;
        }

       // add core start

        //获取sim卡的列表
         List<SubscriptionInfo> sil = subscriptionManager.getActiveSubscriptionInfoList();
          if (sil == null || sil.size() < 1) {
              Log.d(TAG, "Subscription list is empty");
              return;
          }
          //判断是否设置数据流量卡
          boolean dataSelected = SubscriptionManager.isUsableSubIdValue(
                  SubscriptionManager.getDefaultDataSubscriptionId());
          boolean smsSelected = SubscriptionManager.isUsableSubIdValue(
                  SubscriptionManager.getDefaultSmsSubscriptionId());
         Log.d(TAG, "dataSelected=" + dataSelected + ", smsSelected=" + smsSelected);
         if(!dataSelected){

            Log.d(TAG, "data smsSelected = " + smsSelected + " choose a sim for sms !");

                       SubscriptionInfo subInfo = subscriptionManager.getActiveSubscriptionInfoForSimSlotIndex(0);
                       if(null != subInfo){
                               int firstSubId = subInfo.getSubscriptionId();

                               Log.d(TAG, "data firstSubId = " + firstSubId);
                               
                               subscriptionManager.setDefaultDataSubId(firstSubId);
                       }

                       dataSelected = SubscriptionManager.isUsableSubIdValue(
                SubscriptionManager.getDefaultDataSubscriptionId());
        }
// add core end 

        final SubscriptionInfo info = subscriptionManager.getActiveSubscriptionInfo(subId);
        if (info == null) {
            Log.w(TAG, "onEnableMmsDataRequest null SubscriptionInfo for sub ID " + subId);
            return;
        }

        // Getting request reason from extra, which will determine the notification title.
        CharSequence notificationTitle = null;
        int requestReason = intent.getIntExtra(EXTRA_ENABLE_MMS_DATA_REQUEST_REASON, -1);
        if (requestReason == ENABLE_MMS_DATA_REQUEST_REASON_INCOMING_MMS) {
            notificationTitle = context.getResources().getText(
                    R.string.enable_receiving_mms_notification_title);
        } else if (requestReason == ENABLE_MMS_DATA_REQUEST_REASON_OUTGOING_MMS) {
            notificationTitle = context.getResources().getText(
                    R.string.enable_sending_mms_notification_title);
        } else {
            Log.w(TAG, "onEnableMmsDataRequest invalid request reason " + requestReason);
            return;
        }

        TelephonyManager tm = ((TelephonyManager) context.getSystemService(
 Context.TELEPHONY\_SERVICE)).createForSubscriptionId(subId);

        if (tm.isDataEnabledForApn(TYPE_MMS)) {
            Log.w(TAG, "onEnableMmsDataRequest MMS data already enabled on sub ID " + subId);
            return;
        }

        CharSequence notificationSummary = context.getResources().getString(
                R.string.enable_mms_notification_summary, SubscriptionUtil.getDisplayName(info));

        cancelEnableMmsNotification(context);

        createEnableMmsNotification(context, notificationTitle, notificationSummary, subId);
    }

```

编译验证 发现问题完美解决





