






### 1.概述


在10.0定制化产品开发中，需求要求对SystemUI通知栏ui进行定制,在状态栏展开布局中的通知栏增加通知头文字


### 2.下拉通知栏 通知列表 添加通知头的核心类



```
/frameworks/base/packages/SystemUI/res/layout/status_bar_expanded.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java

```

### 3.下拉通知栏 通知列表 添加通知头的核心功能实现和分析


在SystemUI的下拉通知栏中，首先看下拉状态栏布局就是  
 status\_bar\_expanded.xml中然后可以看通知栏的布局  
 然后对通知栏布局做修改


### 3.1status\_bar\_expanded.xml相关布局的分析



```
<com.android.systemui.statusbar.phone.NotificationPanelView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:id="@+id/notification\_panel"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:background="@android:color/transparent" >

    <FrameLayout
        android:id="@+id/big\_clock\_container"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:visibility="gone" />

    <include
        layout="@layout/keyguard\_status\_view"
        android:visibility="gone" />

    <com.android.systemui.statusbar.phone.NotificationsQuickSettingsContainer
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
        android:id="@+id/notification\_container\_parent"
        android:clipToPadding="false"
        android:clipChildren="false">

        <include layout="@layout/dock\_info\_overlay" />

        <FrameLayout
            android:id="@+id/qs\_frame"
            android:layout="@layout/qs\_panel"
            android:layout_width="@dimen/qs\_panel\_width"
            android:layout_height="match\_parent"
            android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
            android:clipToPadding="false"
            android:clipChildren="false"
            systemui:viewType="com.android.systemui.plugins.qs.QS" />

        <com.android.systemui.statusbar.notification.stack.NotificationStackScrollLayout
            android:id="@+id/notification\_stack\_scroller"
            android:layout_marginTop="@dimen/notification\_panel\_margin\_top"
            android:layout_width="@dimen/notification\_panel\_width"
            android:layout_height="match\_parent"
            android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
            android:layout_marginBottom="@dimen/close\_handle\_underlap" />

        <include layout="@layout/ambient\_indication"
            android:id="@+id/ambient\_indication\_container" />

        <ViewStub
            android:id="@+id/keyguard\_user\_switcher"
            android:layout="@layout/keyguard\_user\_switcher"
            android:layout_height="match\_parent"
            android:layout_width="match\_parent" />

        <include
            layout="@layout/keyguard\_status\_bar"
            android:visibility="invisible" />

        <Button
            android:id="@+id/report\_rejected\_touch"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:layout_marginTop="@dimen/status\_bar\_header\_height\_keyguard"
            android:text="@string/report\_rejected\_touch"
            android:visibility="gone" />

    </com.android.systemui.statusbar.phone.NotificationsQuickSettingsContainer>

    <include
        layout="@layout/keyguard\_bottom\_area"
        android:visibility="gone" />

    <com.android.systemui.statusbar.AlphaOptimizedView
        android:id="@+id/qs\_navbar\_scrim"
        android:layout_height="96dp"
        android:layout_width="match\_parent"
        android:layout_gravity="bottom"
        android:visibility="invisible"
        android:background="@drawable/qs\_navbar\_scrim" />

</com.android.systemui.statusbar.phone.NotificationPanelView>

```

从上述的status\_bar\_expanded.xml布局可以看出在com.android.systemui.statusbar.notification.stack.NotificationStackScrollLayout中的  
 NotificationStackScrollLayout.java就是通知栏的布局，所以要从中进行添加布局  
 首选参考FooterView的布局


### 3.2 NotificationStackScrollLayout有关布局的分析



```
    protected void inflateFooterView() {
        FooterView footerView = (FooterView) LayoutInflater.from(mContext).inflate(
                R.layout.status_bar_notification_footer, this, false);
        footerView.setDismissButtonClickListener(v -> {
            mMetricsLogger.action(MetricsEvent.ACTION_DISMISS_ALL_NOTES);
            clearNotifications(ROWS_ALL, true /* closeShade */);
        });
        footerView.setManageButtonClickListener(this::manageNotifications);
        setFooterView(footerView);
    }
    @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
    public void setFooterView(@NonNull FooterView footerView) {
        int index = -1;
        if (mFooterView != null) {
            index = indexOfChild(mFooterView);
            removeView(mFooterView);
        }
        mFooterView = footerView;
        addView(mFooterView, index);
    }
     public void updateEmptyShadeView(boolean visible) {
@@ -4930,6 +4919,7 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
         }
         boolean animate = mIsExpanded && mAnimationsEnabled;
         mFooterView.setVisible(visible, animate);
+        mNotificationTipView.setVisible(visible,animate);
         mFooterView.setSecondaryVisible(showDismissView, animate);
     }

```

在inflateFooterView()中的inflateFooterView()增加通知尾部文件布局，inflateFooterView()就是设置尾部布局文件而在updateEmptyShadeView()来负责footview显示和隐藏


所以接下来增加通知布局文件  
 notifications\_tip.xml



```
<com.android.systemui.statusbar.NotificationTipView
        xmlns:android="http://schemas.android.com/apk/res/android"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:visibility="gone"
        >
    <TextView
            android:id="@+id/notifications\_tip"
            android:layout_width="match\_parent"
            android:layout_height="wrap\_content"
			android:textSize="16sp"
            android:textAppearance="?android:attr/textAppearanceButton"
            android:gravity="left|center\_vertical"
            android:textColor="?attr/wallpaperTextColor"
            android:text="@string/notification\_message\_text"/>
</com.android.systemui.statusbar.NotificationTipView>

```

notifications\_tip.xml就是增加的自定义的标题文件接下来  
 自定义NotificationTipView.java  
 然后在NotificationStackScrollLayout的inflateFooterView()中的inflateFooterView()增加通知尾部文件布局，而在updateEmptyShadeView()来负责footview显示和隐藏



```
package com.android.systemui.statusbar;

import android.annotation.ColorInt;
import android.annotation.StringRes;
import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.android.systemui.R;
import com.android.systemui.statusbar.notification.row.StackScrollerDecorView;
import com.android.systemui.statusbar.notification.stack.ExpandableViewState;

public class NotificationTipView extends StackScrollerDecorView {

    private TextView mEmptyText;
    private @StringRes int mText = R.string.notification_message_text;

    public NotificationTipView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mEmptyText.setText(mText);
    }

    @Override
    protected View findContentView() {
        return findViewById(R.id.notifications_tip);
    }

    @Override
    protected View findSecondaryView() {
        return null;
    }

    public void setTextColor(@ColorInt int color) {
        mEmptyText.setTextColor(color);
    }

    public void setText(@StringRes int text) {
        mText = text;
        mEmptyText.setText(mText);
    }

    public int getTextResource() {
        return mText;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mEmptyText = (TextView) findContentView();
    }

    @Override
    public ExpandableViewState createExpandableViewState() {
        return new EmptyShadeViewState();
    }

    public class EmptyShadeViewState extends ExpandableViewState {
        @Override
        public void applyToView(View view) {
            super.applyToView(view);
            if (view instanceof NotificationTipView) {
                NotificationTipView emptyShadeView = (NotificationTipView) view;
                boolean visible = this.clipTopAmount <= mEmptyText.getPaddingTop() * 0.6f;
                emptyShadeView.setContentVisible(visible && emptyShadeView.isVisible());
            }
        }
    }
}

接下来在NotificationStackScrollLayout.java添加通知头布局
    public void setNotificationView(NotificationTipView noticationTipView) {
		if (mNotificationTipView != null) {
            removeView(mNotificationTipView);
        }
		mNotificationTipView = noticationTipView;
        addView(noticationTipView, 0);
    }
    private void inflateNotificationTipView() {
        NotificationTipView view = (NotificationTipView) LayoutInflater.from(mContext).inflate(
                R.layout.notifications_tip, this, false);
        view.setText(R.string.notification_message_text);
        setNotificationView(view);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        +inflateNotificationTipView();
        inflateEmptyShadeView();
        inflateFooterView();
        mVisualStabilityManager.setVisibilityLocationProvider(this::isInVisibleLocation);
        if (mAllowLongPress) {
            setLongPressListener(mNotificationGutsManager::openGuts);
        }
    }
    @ShadeViewRefactor(RefactorComponent.SHADE_VIEW)
    public void updateFooterView(boolean visible, boolean showDismissView) {
        if (mFooterView == null) {
            return;
        }
        boolean animate = mIsExpanded && mAnimationsEnabled;
        mFooterView.setVisible(visible, animate);
     +   mNotificationTipView.setVisible(visible,animate);
        mFooterView.setSecondaryVisible(showDismissView, animate);
    }

```

Status中修改记录



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
@@ -1968,7 +1968,7 @@ public class StatusBar extends SystemUI implements DemoMode,
         // Expand the window to encompass the full screen in anticipation of the drag.
         // This is only possible to do atomically because the status bar is at the top of the screen!
         mStatusBarWindowController.setPanelVisible(true);
-
+        mNotificationPanel.onStatusExpand();
         visibilityChanged(true);
         mCommandQueue.recomputeDisableFlags(mDisplayId, !force /* animate */);
         setInteracting(StatusBarManager.WINDOW_STATUS_BAR, true);
@@ -2148,7 +2148,6 @@ public class StatusBar extends SystemUI implements DemoMode,
         // Ensure the panel is fully collapsed (just in case; bug 6765842, 7260868)
         mStatusBarView.collapsePanel(/*animate=*/ false, false /* delayed*/,
                 1.0f /* speedUpFactor */);
-
         mNotificationPanel.closeQs();
 
         mExpandedVisible = false;

```

NotificationPanelView.java 修改记录



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NotificationPanelView.java
@@ -119,7 +119,7 @@ import android.animation.ValueAnimator;
 import com.android.systemui.util.BitmapUtils;
 import com.android.systemui.util.BlurUtil;
 import android.graphics.BitmapFactory;
-
+import android.os.Handler;
 public class NotificationPanelView extends PanelView implements
         ExpandableView.OnHeightChangedListener,
         View.OnClickListener, NotificationStackScrollLayout.OnOverscrollTopChangedListener,
@@ -149,7 +149,6 @@ public class NotificationPanelView extends PanelView implements
     // changed.
     private static final int CAP_HEIGHT = 1456;
     private static final int FONT_HEIGHT = 2163;
-
     static final String COUNTER_PANEL_OPEN = "panel\_open";
     static final String COUNTER_PANEL_OPEN_QS = "panel\_open\_qs";
     private static final String COUNTER_PANEL_OPEN_PEEK = "panel\_open\_peek";
@@ -186,7 +185,7 @@ public class NotificationPanelView extends PanelView implements
     private int mTrackingPointer;
     private VelocityTracker mQsVelocityTracker;
     private boolean mQsTracking;
-
+    private Handler mHandler = new Handler();
     /**
      * If set, the ongoing touch gesture might both trigger the expansion in {@link PanelView} and
      * the expansion for quick settings.
@@ -230,7 +229,7 @@ public class NotificationPanelView extends PanelView implements
             new KeyguardClockPositionAlgorithm();
     private final KeyguardClockPositionAlgorithm.Result mClockPositionResult =
             new KeyguardClockPositionAlgorithm.Result();
-    private boolean mIsExpanding;
+    private boolean mIsExpanding,mIsExpand=false;
 
     private boolean mBlockTouches;
     // Used for two finger gesture as well as accessibility shortcut to QS.
@@ -826,6 +825,7 @@ public class NotificationPanelView extends PanelView implements
     }
 
     public void closeQs() {
+        mIsExpand=false;
                mNotificationStackScroller.removeNotificationTipView();
         cancelQsAnimation();
         setQsExpansion(mQsMinExpansionHeight);
@@ -1636,10 +1636,10 @@ public class NotificationPanelView extends PanelView implements
     }
 
     private void updateQsState() {
-        /*mNotificationStackScroller.setQsExpanded(mQsExpanded);
+        mNotificationStackScroller.setQsExpanded(mQsExpanded);
         mNotificationStackScroller.setScrollingEnabled(
                 mBarState != StatusBarState.KEYGUARD && (!mQsExpanded
-                        || mQsExpansionFromOverscroll));*/
+                        || mQsExpansionFromOverscroll));
         updateEmptyShadeView();
         mQsNavbarScrim.setVisibility(mBarState == StatusBarState.SHADE && mQsExpanded
                 && !mStackScrollerOverscrolling && mQsScrimEnabled
@@ -2128,11 +2128,20 @@ public class NotificationPanelView extends PanelView implements
         }
         return mNotificationStackScroller.getNotificationsTopY();
     }
-
+    public void onStatusExpand(){
+               mHandler.postDelayed(new Runnable() {
+            @Override
+            public void run() {
+                if(mIsExpand)mNotificationStackScroller.onExpansionExpand(mEntryManager.getNotificationData().getActiveNotifications().size() == 0);
+            }
+        },100);
+       }
     @Override
     protected void onExpandingStarted() {
         super.onExpandingStarted();
-        mNotificationStackScroller.onExpansionStarted(mEntryManager.getNotificationData().getActiveNotifications().size() == 0);
+               mIsExpand=true;
+               android.util.Log.e("Notification","onExpandingStarted");
+        mNotificationStackScroller.onExpansionStarted();
         mIsExpanding = true;
         mQsExpandedWhenExpandingStarted = mQsFullyExpanded;
         if (mQsExpanded) {

```

NotificationStackScrollLayout.java 修改记录



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java
@@ -4313,13 +4313,14 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
     public void resetCheckSnoozeLeavebehind() {
         mCheckForLeavebehind = true;
     }
-
-    @ShadeViewRefactor(RefactorComponent.STATE_RESOLVER)
-    public void onExpansionStarted(boolean isShow) {
+    public void onExpansionExpand(boolean isShow) {
                if(mNotificationTipView == null&&!isShow){
            inflateNotificationTipView();
            mNotificationTipView.setVisible(true,false);
                }
+       }
+    @ShadeViewRefactor(RefactorComponent.STATE_RESOLVER)
+    public void onExpansionStarted() {
         mIsExpansionChanging = true;
         mAmbientState.setExpansionChanging(true);
         checkSnoozeLeavebehind();
         
    public void removeNotificationTipView(){
        if (mNotificationTipView != null) {
            removeView(mNotificationTipView);
			mNotificationTipView = null;
        }
    }

```

这样布局文件添加完毕，编译验证即可





