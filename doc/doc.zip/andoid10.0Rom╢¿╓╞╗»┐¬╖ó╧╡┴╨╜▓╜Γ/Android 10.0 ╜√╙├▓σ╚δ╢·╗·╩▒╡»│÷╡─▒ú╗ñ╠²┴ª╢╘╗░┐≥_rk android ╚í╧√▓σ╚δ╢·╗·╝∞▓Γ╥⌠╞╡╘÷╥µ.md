



## 1.前言


 在10.0的系统开发中，在某些产品中会对耳机音量调节过高限制，在调高到最大音量的70%的时候，会弹出音量过高弹出警告，所以产品  
 开发的需要要求去掉这个音量弹窗警告功能


![](https://img-blog.csdnimg.cn/fbf948b482db4b08a8e29277aeeac481.png)


## 2.禁用插入耳机时弹出的保护听力对话框的核心类



```
frameworks\base\packages\SystemUI\src\com\android\systemui\volume\SafetyWarningDialog.java
frameworks\base\packages\SystemUI\src\com\android\systemui\volume\VolumeDialogImpl.java
frameworks\base\services\core\java\com\android\server\audio\AudioService.java
```

## 3.禁用插入耳机时弹出的保护听力对话框的核心功能分析和实现


禁用插入耳机时弹出的保护听力对话框的实现功能中，正如之前想的那样，它确实只是一个普通的`Dialog`，但是继承自`SystemUIDialog`，它只是对`AlertDialog`做了一些封装,


通过对于系统中的音量弹窗警告的布局分析，通过搜索发现是在frameworks\base\core下的资源文字的引用，  
 safe\_media\_volume\_warning这个资源的引用，通过搜索发现就是SafetyWarningDialog.java，所以  
 接下来需要对SafetyWarningDialog.java进行详细的分析


## 3.1 SafetyWarningDialog.java中关于音量弹窗警告代码分析


禁用插入耳机时弹出的保护听力对话框的实现功能中，通过上述的分析得知，在关于插入耳机


的时候相关的弹窗就是SafetyWarningDialog.java，接下来进行详细的分析相关的源码



```
abstract public class SafetyWarningDialog extends SystemUIDialog
        implements DialogInterface.OnDismissListener, DialogInterface.OnClickListener {
    public SafetyWarningDialog(Context context, AudioManager audioManager) {
        super(context);
        mContext = context;
        mAudioManager = audioManager;
        try {
            mDisableOnVolumeUp = mContext.getResources().getBoolean(
                  com.android.internal.R.bool.config_safe_media_disable_on_volume_up);
        } catch (NotFoundException e) {
            mDisableOnVolumeUp = true;
        }
        getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ERROR);
        setShowForAllUsers(true);
        setMessage(mContext.getString(com.android.internal.R.string.safe_media_volume_warning));
        setButton(DialogInterface.BUTTON_POSITIVE,
                mContext.getString(com.android.internal.R.string.yes), this);
        setButton(DialogInterface.BUTTON_NEGATIVE,
                mContext.getString(com.android.internal.R.string.no), (OnClickListener) null);
        setOnDismissListener(this);

        final IntentFilter filter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        context.registerReceiver(mReceiver, filter);
    }

    abstract protected void cleanUp();

```

禁用插入耳机时弹出的保护听力对话框的实现功能中，在SafetyWarningDialog.java中的上述源码分析得知，在 SafetyWarningDialog(Context context, AudioManager audioManager)  
 的构造方法中，在setMessage(mContext.getString(com.android.internal.R.string.safe\_media\_volume\_warning));构造弹窗的文字说明  
 然后通过setButton(DialogInterface.BUTTON\_POSITIVE和 setButton(DialogInterface.BUTTON\_NEGATIVE,  
 来构建确定和取消弹窗警告的相关功能流程执行



```
   @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (mDisableOnVolumeUp && keyCode == KeyEvent.KEYCODE_VOLUME_UP
            && event.getRepeatCount() == 0) {
            mNewVolumeUp = true;
        }

        /* UNISOC: Bug 1121684 response volume down event to dismiss dialog @{ */
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.getRepeatCount() == 0) {
            mNewVolumeDown = true;
        }
        /* @} */

        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP && mNewVolumeUp
                && (System.currentTimeMillis() - mShowTime) > KEY_CONFIRM_ALLOWED_AFTER) {
            if (D.BUG) Log.d(TAG, "Confirmed warning via VOLUME_UP");
            // UNISOC: bug 1121684 SafetyWarningDialog dissmiss after click volume up key.
            //mAudioManager.disableSafeMediaVolume();
            //dismiss();
        }

        /* UNISOC: Bug 1121684 response volume down event to dismiss dialog @{ */
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && mNewVolumeDown) {
            dismiss();
            mNewVolumeDown = false;
        }
        /* @} */

        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        mAudioManager.disableSafeMediaVolume();
    }

    @Override
    public void onDismiss(DialogInterface unused) {
        mContext.unregisterReceiver(mReceiver);
        cleanUp();
    }
```

禁用插入耳机时弹出的保护听力对话框的实现功能中，在SafetyWarningDialog.java中的上述源码分析得知，onClick(DialogInterface dialog, int which)就是执行  
 setButton(DialogInterface.BUTTON\_POSITIVE按钮的功能，而在onDismiss(DialogInterface unused)中  
 就是执行setButton(DialogInterface.BUTTON\_NEGATIVE按钮的相关功能


## 3.2 VolumeDialogImpl.java中相关音量警告弹窗的相关源码分析


禁用插入耳机时弹出的保护听力对话框的实现功能中，在SystemUI中*VolumeDialogImpl*.*java*就是进行管理音量调节弹窗的，所以说在对音量的相关弹窗源码中，就需要分析下SystemUI中*VolumeDialogImpl*.*java的相关源码，接下来具体分析下*


SystemUI中*VolumeDialogImpl*.*java的源码*



```
public class VolumeDialogImpl implements VolumeDialog,
        ConfigurationController.ConfigurationListener {
    private static final String TAG = Util.logTag(VolumeDialogImpl.class);
....
    private SafetyWarningDialog mSafetyWarning;

    private final VolumeDialogController.Callbacks mControllerCallbackH
            = new VolumeDialogController.Callbacks() {
        @Override
        public void onShowRequested(int reason) {
            showH(reason);
        }

        @Override
        public void onDismissRequested(int reason) {
            dismissH(reason);
        }

        @Override
        public void onScreenOff() {
            dismissH(Events.DISMISS_REASON_SCREEN_OFF);
        }

        @Override
        public void onStateChanged(State state) {
            onStateChangedH(state);
        }

        @Override
        public void onLayoutDirectionChanged(int layoutDirection) {
            mDialogView.setLayoutDirection(layoutDirection);
        }

        @Override
        public void onConfigurationChanged() {
            mDialog.dismiss();
            mConfigChanged = true;
        }

        @Override
        public void onShowVibrateHint() {
            if (mSilentMode) {
                mController.setRingerMode(AudioManager.RINGER_MODE_SILENT, false);
            }
        }

        @Override
        public void onShowSilentHint() {
            if (mSilentMode) {
                mController.setRingerMode(AudioManager.RINGER_MODE_NORMAL, false);
            }
        }

        @Override
        public void onShowSafetyWarning(int flags) {
           // showSafetyWarningH(flags);
        }

        @Override
        public void onAccessibilityModeChanged(Boolean showA11yStream) {
            mShowA11yStream = showA11yStream == null ? false : showA11yStream;
            VolumeRow activeRow = getActiveRow();
            if (!mShowA11yStream && STREAM_ACCESSIBILITY == activeRow.stream) {
                dismissH(Events.DISMISS_STREAM_GONE);
            } else {
                updateRowsH(activeRow);
            }

        }

        @Override
        public void onCaptionComponentStateChanged(
                Boolean isComponentEnabled, Boolean fromTooltip) {
            updateODICaptionsH(isComponentEnabled, fromTooltip);
        }
    };

    private void showSafetyWarningH(int flags) {
        if ((flags & (AudioManager.FLAG_SHOW_UI | AudioManager.FLAG_SHOW_UI_WARNINGS)) != 0
                || mShowing) {
            synchronized (mSafetyWarningLock) {
                if (mSafetyWarning != null) {
                    return;
                }
                mSafetyWarning = new SafetyWarningDialog(mContext, mController.getAudioManager()) {
                    @Override
                    protected void cleanUp() {
                        synchronized (mSafetyWarningLock) {
                            mSafetyWarning = null;
                        }
                        recheckH(null);
                    }
                };
                mSafetyWarning.show();
            }
            recheckH(null);
        }
        rescheduleTimeoutH();
    }
```

禁用插入耳机时弹出的保护听力对话框的实现功能中，在 VolumeDialogImpl.java中的上述方法中，可以看出，在VolumeDialogImpl.java的内部类VolumeDialogController中负责对音量逻辑的处理  
 所以在onShowSafetyWarning(int flags) 这个音量警告弹窗的回调方法中，弹出SafetyWarningDialog，所以可以  
 注释掉相关的耳机音量弹窗警告的相关功能，所以就需要在onShowSafetyWarning(int flags) 中  
 // showSafetyWarningH(flags); 来禁用音量警告弹窗功能


## 3.3 AudioService.java中相关音量弹窗代码分析


禁用插入耳机时弹出的保护听力对话框的实现功能中，VolumeDialogImpl.java中的上述分析中，需要在onShowSafetyWarning(int flags) 中  
 // showSafetyWarningH(flags); 来禁用音量警告弹窗功能，接下来就具体分析下


AudioService.java中的相关原来来具体实现功能



```
  private boolean checkSafeMediaVolume(int streamType, int index, int device) {
        synchronized (mSafeMediaVolumeStateLock) {
            if ((mSafeMediaVolumeState == SAFE_MEDIA_VOLUME_ACTIVE) &&
                    (mStreamVolumeAlias[streamType] == AudioSystem.STREAM_MUSIC) &&
                    ((device & mSafeMediaVolumeDevices) != 0) &&
                    (index > safeMediaVolumeIndex(device))) {
                return false;
            }
            return true;
        }
    }
```

禁用插入耳机时弹出的保护听力对话框的实现功能中，在AudioService.java中以上代码可以看出，其安全音量弹框警告的触发地方就在checkSafeMediaVolume方法附近处，  
 并且都是通过mVolumeController这个远程服务去调用UI显示安全音量弹框警告，  
 而config\_safe\_media\_volume\_enabled是安全音量功能的总开关，所以可以将config\_safe\_media\_volume\_enabled改为false  
 不启动安全音量功能，在checkSafeMediaVolume(int streamType, int index, int device) 中的修改  
 如下:



```
   private boolean checkSafeMediaVolume(int streamType, int index, int device) {
        synchronized (mSafeMediaVolumeStateLock) {
            if ((mSafeMediaVolumeState == SAFE_MEDIA_VOLUME_ACTIVE) &&
                    (mStreamVolumeAlias[streamType] == AudioSystem.STREAM_MUSIC) &&
                    ((device & mSafeMediaVolumeDevices) != 0) &&
                    (index > safeMediaVolumeIndex(device))) {
             -  return false;
             + return true;
            }
            return true;
        }
    }

```

禁用插入耳机时弹出的保护听力对话框的实现功能中，framework/base/core下的config.xml里面，可以直接修改或者overlay配置修改其默认值。  
 <!-- Whether safe headphone volume is enabled or not (country specific). -->  
 -<bool name="config\_safe\_media\_volume\_enabled">true</bool>  
 +<bool name="config\_safe\_media\_volume\_enabled">false</bool>  
 通过上述的修改就可以确保禁用了系统的安全音量弹窗警告的功能，在插入耳机增加音量的实现，就不会有  
 限制了



