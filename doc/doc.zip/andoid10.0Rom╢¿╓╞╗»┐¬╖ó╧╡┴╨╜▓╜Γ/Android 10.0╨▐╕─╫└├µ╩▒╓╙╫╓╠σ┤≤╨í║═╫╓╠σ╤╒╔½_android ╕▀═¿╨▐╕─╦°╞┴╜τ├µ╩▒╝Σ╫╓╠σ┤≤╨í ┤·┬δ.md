






在Launcher3的桌面首页就是时钟控件 这个时钟其实就是时钟小部件  
 就是DeskClock这个app 所以要修改字体颜色和大小 就要从这个app修改源码就可以了


在展讯平台源码路径为:  
 vendor/sprd/platform/packages/apps/SprdDeskClock  
 接下来看  
 sprd/vendor/sprd/platform/packages/apps/SprdDeskClock/res/layout/digital\_widget.xml  
 这个资源文件



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2016 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/digital\_widget"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:gravity="top|center\_horizontal"
    android:orientation="vertical">

    <TextClock
        android:id="@+id/clock"
        style="@style/widget\_big\_thin"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_horizontal|top"
        android:ellipsize="none"
        android:format12Hour="@string/lock\_screen\_12\_hour\_format"
        android:format24Hour="@string/lock\_screen\_24\_hour\_format"
        android:includeFontPadding="false"
        android:singleLine="true"
        android:textColor="@color/red" />

    <LinearLayout
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_horizontal|top">

        <TextClock
            android:id="@+id/date"
            style="@style/widget\_label"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:layout_gravity="center"
            android:ellipsize="none"
            android:includeFontPadding="false"
            android:singleLine="true"
            android:textAllCaps="true"
            android:textColor="@color/red" />

        <ImageView
            android:id="@+id/nextAlarmIcon"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:layout_gravity="center"
            android:contentDescription="@null"
            android:scaleType="center" />

        <TextView
            android:id="@+id/nextAlarm"
            style="@style/widget\_label"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:layout_gravity="center"
            android:ellipsize="none"
            android:includeFontPadding="false"
            android:singleLine="true"
            android:textAllCaps="true"
            android:textColor="@color/white" />

    </LinearLayout>

    <ListView
        android:id="@+id/world\_city\_list"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_horizontal|top"
        android:layout_marginTop="20dp"
        android:divider="@null" />

</LinearLayout>

```

从上面的xml文件可以看出 TextClock 就表示时间和日期的 android:textColor的就是设置字体颜色的  
 可以改成自己需要的字体颜色


第二步字体大小的修改  
 这就需要修改DigitalAppWidgetProvider.java这个文件了  
 路径为:  
 vendor/sprd/platform/packages/apps/SprdDeskClock/src/com/android/alarmclock/DigitalAppWidgetProvider.java



```
 @Override
    public void onReceive(@NonNull Context context, @NonNull Intent intent) {
        LOGGER.i("onReceive: " + intent);
        /* UNISOC: Modify for bug 1164486 {@ */
        if ( null == intent || null == intent.getAction()) {
            return;
        }
        /* @} */
        super.onReceive(context, intent);

        final AppWidgetManager wm = AppWidgetManager.getInstance(context);
        if (wm == null) {
            return;
        }

        final ComponentName provider = new ComponentName(context, getClass());
        final int[] widgetIds = wm.getAppWidgetIds(provider);

        final String action = intent.getAction();
        switch (action) {
            case ACTION_NEXT_ALARM_CLOCK_CHANGED:
            case ACTION_DATE_CHANGED:
            case ACTION_LOCALE_CHANGED:
            case ACTION_SCREEN_ON:
            case ACTION_TIME_CHANGED:
            case ACTION_TIMEZONE_CHANGED:
            case ACTION_ALARM_CHANGED:
            case ACTION_ON_DAY_CHANGE:
            case ACTION_WORLD_CITIES_CHANGED:
                for (int widgetId : widgetIds) {
                    relayoutWidget(context, wm, widgetId, wm.getAppWidgetOptions(widgetId));
                }
        }

        final DataModel dm = DataModel.getDataModel();
        dm.updateWidgetCount(getClass(), widgetIds.length, R.string.category_digital_widget);

        if (widgetIds.length > 0) {
            updateDayChangeCallback(context);
        }
    }

```

当日期和时间发生改变的时候就会调用这里  
 relayoutWidget(context, wm, widgetId, wm.getAppWidgetOptions(widgetId));  
 由relayoutWidget 方法来负责绘制日期和时间



```
  /**
     * Compute optimal font and icon sizes offscreen for the given orientation.
     */
    private static RemoteViews relayoutWidget(Context context, AppWidgetManager wm, int widgetId,
            Bundle options, boolean portrait) {
        // Create a remote view for the digital clock.
        final String packageName = context.getPackageName();
        final RemoteViews rv = new RemoteViews(packageName, R.layout.digital_widget);
        rv.setCharSequence(R.id.clock, "setFormat12Hour", Utils.get12ModeFormat(0.4f, false));
        rv.setCharSequence(R.id.clock, "setFormat24Hour", Utils.get24ModeFormat(false));
        // Tapping on the widget opens the app (if not on the lock screen).
        if (Utils.isWidgetClickable(wm, widgetId)) {
            final Intent openApp = new Intent(context, DeskClock.class);
            final PendingIntent pi = PendingIntent.getActivity(context, 0, openApp, 0);
            rv.setOnClickPendingIntent(R.id.digital_widget, pi);
        }

        // Configure child views of the remote view.
        final CharSequence dateFormat = getDateFormat(context);
        rv.setCharSequence(R.id.date, "setFormat12Hour", dateFormat);
        rv.setCharSequence(R.id.date, "setFormat24Hour", dateFormat);

        final String nextAlarmTime = Utils.getNextAlarm(context);
        if (TextUtils.isEmpty(nextAlarmTime)) {
            rv.setViewVisibility(R.id.nextAlarm, GONE);
            rv.setViewVisibility(R.id.nextAlarmIcon, GONE);
        } else  {
            rv.setTextViewText(R.id.nextAlarm, nextAlarmTime);
            rv.setViewVisibility(R.id.nextAlarm, VISIBLE);
            rv.setViewVisibility(R.id.nextAlarmIcon, VISIBLE);
        }

        if (options == null) {
            options = wm.getAppWidgetOptions(widgetId);
        }

        // Fetch the widget size selected by the user.
        final Resources resources = context.getResources();
        final float density = resources.getDisplayMetrics().density;
        final int minWidthPx = (int) (density * options.getInt(OPTION_APPWIDGET_MIN_WIDTH));
        final int minHeightPx = (int) (density * options.getInt(OPTION_APPWIDGET_MIN_HEIGHT));
        final int maxWidthPx = (int) (density * options.getInt(OPTION_APPWIDGET_MAX_WIDTH));
        final int maxHeightPx = (int) (density * options.getInt(OPTION_APPWIDGET_MAX_HEIGHT));
        final int targetWidthPx = portrait ? minWidthPx : maxWidthPx;
        final int targetHeightPx = portrait ? maxHeightPx : minHeightPx;
        final int largestClockFontSizePx =
                resources.getDimensionPixelSize(R.dimen.widget_max_clock_font_size);

        // Create a size template that describes the widget bounds.
        final Sizes template = new Sizes(targetWidthPx, targetHeightPx, largestClockFontSizePx);

        // Compute optimal font sizes and icon sizes to fit within the widget bounds.
        final Sizes sizes = optimizeSizes(context, template, nextAlarmTime);
        if (LOGGER.isVerboseLoggable()) {
            LOGGER.v(sizes.toString());
        }

        // Apply the computed sizes to the remote views.
        rv.setImageViewBitmap(R.id.nextAlarmIcon, sizes.mIconBitmap);
        rv.setTextViewTextSize(R.id.date, COMPLEX_UNIT_PX, sizes.mFontSizePx);
        rv.setTextViewTextSize(R.id.nextAlarm, COMPLEX_UNIT_PX, sizes.mFontSizePx);
        rv.setTextViewTextSize(R.id.clock, COMPLEX_UNIT_PX, sizes.mClockFontSizePx);

        final int smallestWorldCityListSizePx =
                resources.getDimensionPixelSize(R.dimen.widget_min_world_city_list_size);
        if (sizes.getListHeight() <= smallestWorldCityListSizePx) {
            // Insufficient space; hide the world city list.
            rv.setViewVisibility(R.id.world_city_list, GONE);
        } else {
            // Set an adapter on the world city list. That adapter connects to a Service via intent.
            final Intent intent = new Intent(context, DigitalAppWidgetCityService.class);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            intent.setData(Uri.parse(intent.toUri(Intent.URI_INTENT_SCHEME)));
            rv.setRemoteAdapter(R.id.world_city_list, intent);
            rv.setViewVisibility(R.id.world_city_list, VISIBLE);

            // Tapping on the widget opens the city selection activity (if not on the lock screen).
            if (Utils.isWidgetClickable(wm, widgetId)) {
                final Intent selectCity = new Intent(context, CitySelectionActivity.class);
                final PendingIntent pi = PendingIntent.getActivity(context, 0, selectCity, 0);
                rv.setPendingIntentTemplate(R.id.world_city_list, pi);
            }
        }

        return rv;
    }

```

从源码中可以看出



```
rv.setImageViewBitmap(R.id.nextAlarmIcon, sizes.mIconBitmap);
        rv.setTextViewTextSize(R.id.date, COMPLEX_UNIT_PX, sizes.mFontSizePx);
        rv.setTextViewTextSize(R.id.nextAlarm, COMPLEX_UNIT_PX, sizes.mFontSizePx);
        rv.setTextViewTextSize(R.id.clock, COMPLEX_UNIT_PX, sizes.mClockFontSizePx);

```

这里设置字体大小  
 修改日期和时间大小就修改:



```
 rv.setTextViewTextSize(R.id.date, COMPLEX_UNIT_PX, sizes.mFontSizePx*2);//日期
rv.setTextViewTextSize(R.id.clock, COMPLEX_UNIT_PX, sizes.mClockFontSizePx*2);//时间

```

日期和字体的大小放大2倍


修改完编译发现字体大小和字体颜色都改变了





