



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.媒体音乐,铃声,闹钟,通知等设置默认音量为最大音量80%的核心代码](#2.%E5%AA%92%E4%BD%93%E9%9F%B3%E4%B9%90%2C%E9%93%83%E5%A3%B0%2C%E9%97%B9%E9%92%9F%2C%E9%80%9A%E7%9F%A5%E7%AD%89%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E9%9F%B3%E9%87%8F%E4%B8%BA%E6%9C%80%E5%A4%A7%E9%9F%B3%E9%87%8F80%25%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.媒体音乐,铃声,闹钟,通知等设置默认音量为最大音量80%的核心代码功能实现](#3.%E5%AA%92%E4%BD%93%E9%9F%B3%E4%B9%90%2C%E9%93%83%E5%A3%B0%2C%E9%97%B9%E9%92%9F%2C%E9%80%9A%E7%9F%A5%E7%AD%89%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E9%9F%B3%E9%87%8F%E4%B8%BA%E6%9C%80%E5%A4%A7%E9%9F%B3%E9%87%8F80%25%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 AudioSystem.java关于媒体音乐,铃声,闹钟,通知等设置默认音量相关代码](#%C2%A03.1%20AudioSystem.java%E5%85%B3%E4%BA%8E%E5%AA%92%E4%BD%93%E9%9F%B3%E4%B9%90%2C%E9%93%83%E5%A3%B0%2C%E9%97%B9%E9%92%9F%2C%E9%80%9A%E7%9F%A5%E7%AD%89%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E9%9F%B3%E9%87%8F%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[2. AudioService.java关于媒体音乐,铃声,闹钟,通知等设置默认音量相关代码](#2.%20AudioService.java%E5%85%B3%E4%BA%8E%E5%AA%92%E4%BD%93%E9%9F%B3%E4%B9%90%2C%E9%93%83%E5%A3%B0%2C%E9%97%B9%E9%92%9F%2C%E9%80%9A%E7%9F%A5%E7%AD%89%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E9%9F%B3%E9%87%8F%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


  在10.0产品定制开发中，对于媒体音乐，铃声 闹钟 通知的音量调节也是常有的功能，在系统中也会给一个默认值来作为初始音量值  
 现在要求初始默认值音量设置为80%的音量，这就要需要了解系统媒体音乐，铃声 闹钟 通知的最大音量和在哪里设置默认音量值


## 2.媒体音乐,铃声,闹钟,通知等设置默认音量为最大音量80%的核心代码



```
  /frameworks/base/media/java/android/media/AudioSystem.java
  /frameworks/base/services/core/java/com/android/server/audio/AudioService.java
```

## 3.媒体音乐,铃声,闹钟,通知等设置默认音量为最大音量80%的核心代码功能实现


AudioService服务由SystemServer创建，并且拥有一个自己的线程，这个线程一直利用mAudioHandler处理收到的消息。所以不耗时的事情是SystemServer做的，而耗时的事情是AudioService线程做的。


AudioService通过对AudioSystem.java进行函数调用与Native 系统进行通信


在Android中， AudioService是Android上层音频的核心。AudioService在SystemServer中启动，为所有音频相关设置提供服务。AudioManager和AudioService是通过Binder机制进行通讯的。AudioManager拥有AudioService的Bp端，是AudioService在客户的一个代理。几乎所有的对AudioManager进行的请求，最终都会交给AudioService去处理。而AudioService的实现主要依赖于AudioSystem。AudioSystem是java层到native层的代理


在系统中，在AudioSystem.java和AudioService.java为系统主要设置音量的核心类，所以可以从


这两个类里面分析相关的方法来实现功能



###  3.1 AudioSystem.java关于媒体音乐,铃声,闹钟,通知等设置默认音量相关代码



```
 public class AudioSystem
{
    private static final boolean DEBUG_VOLUME = false;

    
    @UnsupportedAppUsage
    public static final int getNumStreamTypes() { return NUM_STREAM_TYPES; }

    public static final String[] STREAM_NAMES = new String[] {
        "STREAM_VOICE_CALL",
        "STREAM_SYSTEM",
        "STREAM_RING",
        "STREAM_MUSIC",
        "STREAM_ALARM",
        "STREAM_NOTIFICATION",
        "STREAM_BLUETOOTH_SCO",
        "STREAM_SYSTEM_ENFORCED",
        "STREAM_DTMF",
        "STREAM_TTS",
        "STREAM_ACCESSIBILITY"
    };


    public static int getDefaultStreamVolume(int streamType) {
        return DEFAULT_STREAM_VOLUME[streamType];
    }

    public static int[] DEFAULT_STREAM_VOLUME = new int[] {
        4,  // STREAM_VOICE_CALL
        7,  // STREAM_SYSTEM
        5,  // STREAM_RING
        7, // STREAM_MUSIC
        6,  // STREAM_ALARM
        5,  // STREAM_NOTIFICATION
        7,  // STREAM_BLUETOOTH_SCO
        7,  // STREAM_SYSTEM_ENFORCED
        5, // STREAM_DTMF
        5, // STREAM_TTS
        5, // STREAM_ACCESSIBILITY
    };
```

DEFAULT\_STREAM\_VOLUME 就是系统各种音量的默认值


所以修改为  
     public static int[] DEFAULT\_STREAM\_VOLUME = new int[] {  
         4,  // STREAM\_VOICE\_CALL  
         7,  // STREAM\_SYSTEM  
       -  5,  // STREAM\_RING  
       +  6,  // STREAM\_RING  
       -  7, // STREAM\_MUSIC  
       +  12, // STREAM\_MUSIC  
         6,  // STREAM\_ALARM  
       -  5,  // STREAM\_NOTIFICATION  
       +  6,  // STREAM\_NOTIFICATION  
         7,  // STREAM\_BLUETOOTH\_SCO  
         7,  // STREAM\_SYSTEM\_ENFORCED  
         5, // STREAM\_DTMF  
         5, // STREAM\_TTS  
         5, // STREAM\_ACCESSIBILITY  
     };


### 2. AudioService.java关于媒体音乐,铃声,闹钟,通知等设置默认音量相关代码



```
   public class AudioService extends IAudioService.Stub
        implements AccessibilityManager.TouchExplorationStateChangeListener,
            AccessibilityManager.AccessibilityServicesStateChangeListener {

    private static final String TAG = "AS.AudioService";

  

/** Maximum volume index values for audio streams */
    protected static int[] MAX_STREAM_VOLUME = new int[] {
        5,  // STREAM_VOICE_CALL
        7,  // STREAM_SYSTEM
        7,  // STREAM_RING
        15, // STREAM_MUSIC
        7,  // STREAM_ALARM
        7,  // STREAM_NOTIFICATION
        15, // STREAM_BLUETOOTH_SCO
        7,  // STREAM_SYSTEM_ENFORCED
        15, // STREAM_DTMF
        15, // STREAM_TTS
        15  // STREAM_ACCESSIBILITY
    };

    /** Minimum volume index values for audio streams */
    protected static int[] MIN_STREAM_VOLUME = new int[] {
        1,  // STREAM_VOICE_CALL
        0,  // STREAM_SYSTEM
        0,  // STREAM_RING
        0,  // STREAM_MUSIC
        1,  // STREAM_ALARM
        0,  // STREAM_NOTIFICATION
        0,  // STREAM_BLUETOOTH_SCO
        0,  // STREAM_SYSTEM_ENFORCED
        0,  // STREAM_DTMF
        0,  // STREAM_TTS
        1   // STREAM_ACCESSIBILITY
    };

MAX_STREAM_VOLUME 就是系统最大音量值 MIN_STREAM_VOLUME就是系统最小音量值

public AudioService(Context context) {
        ....

      
        int maxCallVolume = SystemProperties.getInt("ro.config.vc_call_vol_steps", -1);
        if (maxCallVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] = maxCallVolume;
        }
 // 从系统属性中获取默认电话音量
        int defaultCallVolume = SystemProperties.getInt("ro.config.vc_call_vol_default", -1);
        if (defaultCallVolume != -1 &&
                defaultCallVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] &&
                defaultCallVolume >= MIN_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] = defaultCallVolume;
        } else {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] =
                    (MAX_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] * 3) / 4;
        }

        int maxMusicVolume = SystemProperties.getInt("ro.config.media_vol_steps", -1);
        if (maxMusicVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] = maxMusicVolume;
        }
 // 从系统属性中获取默认媒体音量
        int defaultMusicVolume = SystemProperties.getInt("ro.config.media_vol_default", -1);
        if (defaultMusicVolume != -1 &&
                defaultMusicVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] &&
                defaultMusicVolume >= MIN_STREAM_VOLUME[AudioSystem.STREAM_MUSIC]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] = defaultMusicVolume;
        } else {
            if (isPlatformTelevision()) {
                AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] =
                        MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] / 4;
            } else {
                AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] =
                        MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] / 3;
            }
        }
 // 从系统属性中获取默认通知音量
        int maxAlarmVolume = SystemProperties.getInt("ro.config.alarm_vol_steps", -1);
        if (maxAlarmVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_ALARM] = maxAlarmVolume;
        }

        int defaultAlarmVolume = SystemProperties.getInt("ro.config.alarm_vol_default", -1);
        if (defaultAlarmVolume != -1 &&
                defaultAlarmVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_ALARM]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_ALARM] = defaultAlarmVolume;
        } else {
            // Default is 6 out of 7 (default maximum), so scale accordingly.
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_ALARM] =
                        6 * MAX_STREAM_VOLUME[AudioSystem.STREAM_ALARM] / 7;
        }

        int maxSystemVolume = SystemProperties.getInt("ro.config.system_vol_steps", -1);
        if (maxSystemVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM] = maxSystemVolume;
        }
 // 从系统属性中获取默认系统音量
        int defaultSystemVolume = SystemProperties.getInt("ro.config.system_vol_default", -1);
        if (defaultSystemVolume != -1 &&
                defaultSystemVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM] = defaultSystemVolume;
        } else {
            // Default is to use maximum.
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM] =
                        MAX_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM];
        }
 // 从系统属性中获取默认响铃音量
        //UNISOC:bug992603 custom default volume for alarm ring and notification stream.
        int defaultRingVolume = SystemProperties.getInt("ro.config.ring_vol_default", -1);
        if (defaultRingVolume != -1 &&
                defaultRingVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_RING]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_RING] = defaultRingVolume;
        }
 // 从系统属性中获取默认通知音量
        int defaultNotificationVolume = SystemProperties.getInt("ro.config.notification_vol_default", -1);
        if (defaultNotificationVolume != -1 &&
                defaultNotificationVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_NOTIFICATION]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_NOTIFICATION] = defaultNotificationVolume;
        }

        sSoundEffectVolumeDb = context.getResources().getInteger(
                com.android.internal.R.integer.config_soundEffectVolumeDb);

        createAudioSystemThread();

        AudioSystem.setErrorCallback(mAudioSystemCallback);

        boolean cameraSoundForced = readCameraSoundForced();
        mCameraSoundForced = new Boolean(cameraSoundForced);
        sendMsg(mAudioHandler,
                MSG_SET_FORCE_USE,
                SENDMSG_QUEUE,
                AudioSystem.FOR_SYSTEM,
                cameraSoundForced ?
                        AudioSystem.FORCE_SYSTEM_ENFORCED : AudioSystem.FORCE_NONE,
                new String("AudioService ctor"),
                0);

       ....
    }
```

这里根据是否有系统音量的属性设置默认音量 可能会音量设置的默认音量所以需要注释掉


具体修改为:



```
public AudioService(Context context) {
        mContext = context;
        mContentResolver = context.getContentResolver();
        mAppOps = (AppOpsManager)context.getSystemService(Context.APP_OPS_SERVICE);

        mPlatformType = AudioSystem.getPlatformType(context);

        mIsSingleVolume = AudioSystem.isSingleVolume(context);

        mUserManagerInternal = LocalServices.getService(UserManagerInternal.class);
        mActivityManagerInternal = LocalServices.getService(ActivityManagerInternal.class);

        PowerManager pm = (PowerManager)context.getSystemService(Context.POWER_SERVICE);
        mAudioEventWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "handleAudioEvent");

        mVibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        mHasVibrator = mVibrator == null ? false : mVibrator.hasVibrator();

        // Initialize volume
        // Priority 1 - Android Property
        // Priority 2 - Audio Policy Service
        // Priority 3 - Default Value
        if (AudioProductStrategy.getAudioProductStrategies().size() > 0) {
            int numStreamTypes = AudioSystem.getNumStreamTypes();

            for (int streamType = numStreamTypes - 1; streamType >= 0; streamType--) {
                AudioAttributes attr =
                        AudioProductStrategy.getAudioAttributesForStrategyWithLegacyStreamType(
                                streamType);
                int maxVolume = AudioSystem.getMaxVolumeIndexForAttributes(attr);
                if (maxVolume != -1) {
                    MAX_STREAM_VOLUME[streamType] = maxVolume;
                }
                int minVolume = AudioSystem.getMinVolumeIndexForAttributes(attr);
                if (minVolume != -1) {
                    MIN_STREAM_VOLUME[streamType] = minVolume;
                }
            }
        }

       注释开始
       /* int maxCallVolume = SystemProperties.getInt("ro.config.vc_call_vol_steps", -1);
        if (maxCallVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] = maxCallVolume;
        }
 // 从系统属性中获取默认电话音量
        int defaultCallVolume = SystemProperties.getInt("ro.config.vc_call_vol_default", -1);
        if (defaultCallVolume != -1 &&
                defaultCallVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] &&
                defaultCallVolume >= MIN_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] = defaultCallVolume;
        } else {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] =
                    (MAX_STREAM_VOLUME[AudioSystem.STREAM_VOICE_CALL] * 3) / 4;
        }

        int maxMusicVolume = SystemProperties.getInt("ro.config.media_vol_steps", -1);
        if (maxMusicVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] = maxMusicVolume;
        }
 // 从系统属性中获取默认媒体音量
        int defaultMusicVolume = SystemProperties.getInt("ro.config.media_vol_default", -1);
        if (defaultMusicVolume != -1 &&
                defaultMusicVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] &&
                defaultMusicVolume >= MIN_STREAM_VOLUME[AudioSystem.STREAM_MUSIC]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] = defaultMusicVolume;
        } else {
            if (isPlatformTelevision()) {
                AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] =
                        MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] / 4;
            } else {
                AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] =
                        MAX_STREAM_VOLUME[AudioSystem.STREAM_MUSIC] / 3;
            }
        }
 // 从系统属性中获取默认通知音量
        int maxAlarmVolume = SystemProperties.getInt("ro.config.alarm_vol_steps", -1);
        if (maxAlarmVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_ALARM] = maxAlarmVolume;
        }

        int defaultAlarmVolume = SystemProperties.getInt("ro.config.alarm_vol_default", -1);
        if (defaultAlarmVolume != -1 &&
                defaultAlarmVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_ALARM]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_ALARM] = defaultAlarmVolume;
        } else {
            // Default is 6 out of 7 (default maximum), so scale accordingly.
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_ALARM] =
                        6 * MAX_STREAM_VOLUME[AudioSystem.STREAM_ALARM] / 7;
        }

        int maxSystemVolume = SystemProperties.getInt("ro.config.system_vol_steps", -1);
        if (maxSystemVolume != -1) {
            MAX_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM] = maxSystemVolume;
        }
 // 从系统属性中获取默认系统音量
        int defaultSystemVolume = SystemProperties.getInt("ro.config.system_vol_default", -1);
        if (defaultSystemVolume != -1 &&
                defaultSystemVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM] = defaultSystemVolume;
        } else {
            // Default is to use maximum.
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM] =
                        MAX_STREAM_VOLUME[AudioSystem.STREAM_SYSTEM];
        }
 // 从系统属性中获取默认响铃音量
        //UNISOC:bug992603 custom default volume for alarm ring and notification stream.
        int defaultRingVolume = SystemProperties.getInt("ro.config.ring_vol_default", -1);
        if (defaultRingVolume != -1 &&
                defaultRingVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_RING]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_RING] = defaultRingVolume;
        }
 // 从系统属性中获取默认通知音量
        int defaultNotificationVolume = SystemProperties.getInt("ro.config.notification_vol_default", -1);
        if (defaultNotificationVolume != -1 &&
                defaultNotificationVolume <= MAX_STREAM_VOLUME[AudioSystem.STREAM_NOTIFICATION]) {
            AudioSystem.DEFAULT_STREAM_VOLUME[AudioSystem.STREAM_NOTIFICATION] = defaultNotificationVolume;
        }*/
// 注释结束


     
     .....

    }
```

通过对上述AudioSystem.java和AudioService.java相关类的默认音量设置的修改，实现功能，但是同时也需要在AudioService.java的AudioService(Context context)构造方法中，去掉通过获取系统属性的音量值设置音量的相关方法，最终实现了对音量的设置功能



