






### 1.概述


在10.0的系统产品开发中，对于系统默认的电池电量是不显示的，所以产品需求要求显示电池电量，方便知道当前电量，方便显示在电量不足的情况下可以及时充电，所以来实现这个功能


### 2.状态栏显示电量百分比的核心类



```
frameworks/base/packages/SettingsProvider/res/values/defaults.xml
frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

```

### 3.状态栏显示电量百分比的核心功能分析和实现


在系统关于系统电量的常量在Settings类中其实由定义的，默认系统中没有初始化而已，产品可以根据需要来添加这个参数，而SHOW\_BATTERY\_PERCENT就是电池电量的常量，是否显示需要  
 在SettingsProvider中定义显示这个属性


### 3.1defaults.xml添加显示电池电量参数


具体修改如下:



```
diff --git a/frameworks/base/packages/SettingsProvider/res/values/defaults.xml b/frameworks/base/packages/SettingsProvider/res/values/defaults.xml

index 6af365b914..98c2e66159 100755

--- a/frameworks/base/packages/SettingsProvider/res/values/defaults.xml

+++ b/frameworks/base/packages/SettingsProvider/res/values/defaults.xml

@@ -249,5 +249,6 @@
    <bool name="def\_dim\_screen">true</bool>
     <integer name="def\_screen\_off\_timeout">60000</integer>
     <integer name="def\_sleep\_timeout">-1</integer>
     <bool name="def\_airplane\_mode\_on">false</bool>
     <bool name="def\_theater\_mode\_on">false</bool>
     <!-- Comma-separated list of bluetooth, wifi, and cell. -->
     <string name="def\_airplane\_mode\_radios" translatable="false">cell,bluetooth,wifi,nfc,wimax</string>
     <string name="airplane\_mode\_toggleable\_radios" translatable="false">bluetooth,wifi,nfc</string>
     <string name="def\_bluetooth\_disabled\_profiles" translatable="false">0</string>
     <bool name="def\_auto\_time">true</bool>
     <bool name="def\_auto\_time\_zone">true</bool>
     <bool name="def\_accelerometer\_rotation">false</bool>
     <!-- Default screen brightness, from 0 to 255.  102 is 40%. -->
     <integer name="def\_screen\_brightness">102</integer>
     <bool name="def\_screen\_brightness\_automatic\_mode">false</bool>
     <fraction name="def\_window\_animation\_scale">100%</fraction>
     <fraction name="def\_window\_transition\_scale">100%</fraction>
     <bool name="def\_haptic\_feedback">true</bool>
     <!-- Default for Settings.System.NAVIGATION_BAR_CONFIG -->

     <integer name="def\_navigation\_bar\_config">0</integer>

     <!-- Default for Settings.System.NAVIGATION_BAR_SHOW -->

-    <integer name="def\_navigation\_bar\_show">1</integer>

+       <integer name="def\_navigation\_bar\_show">1</integer>

+       <integer name="def\_show\_battery\_percent">1</integer>

 </resources>

```

通过在defaults.xml的xml文件中，添加def\_show\_battery\_percent来设置是否显示电池电量，设置为1代表显示电量，接下来在DatabaseHelper.java中初始化这个变量


### 3.2 DatabaseHelper.java中添加默认的显示电量的参数


接下来分析DatabaseHelper.java关于添加系统默认参数的方法



```
 @Deprecated
  class DatabaseHelper extends SQLiteOpenHelper {
    private void loadSettings(SQLiteDatabase db) {
          loadSystemSettings(db);
          loadSecureSettings(db);
          // The global table only exists for the 'owner/system' user
          if (mUserHandle == UserHandle.USER_SYSTEM) {
              loadGlobalSettings(db);
          }
      }

```

在onCreate(SQLiteDatabase db)创建数据库的时候调用loadSettings(SQLiteDatabase db)来加载系统的默认参数



```
private void loadSystemSettings(SQLiteDatabase db) {
          SQLiteStatement stmt = null;
          try {
              stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                      + " VALUES(?,?);");
  
              loadBooleanSetting(stmt, Settings.System.DIM_SCREEN,
                      R.bool.def_dim_screen);
              loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                      R.integer.def_screen_off_timeout);
  
              // Set default cdma DTMF type
              loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);
  
              // Set default hearing aid
              loadSetting(stmt, Settings.System.HEARING_AID, 0);
  
              // Set default tty mode
              loadSetting(stmt, Settings.System.TTY_MODE, 0);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                      R.integer.def_screen_brightness);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_FOR_VR,
                      com.android.internal.R.integer.config_screenBrightnessForVrSettingDefault);
  
              loadBooleanSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_MODE,
                      R.bool.def_screen_brightness_automatic_mode);
  
              loadBooleanSetting(stmt, Settings.System.ACCELEROMETER_ROTATION,
                      R.bool.def_accelerometer_rotation);
  
              loadDefaultHapticSettings(stmt);
  
              loadBooleanSetting(stmt, Settings.System.NOTIFICATION_LIGHT_PULSE,
                      R.bool.def_notification_pulse);
  
              loadUISoundEffectsSettings(stmt);
  
              loadIntegerSetting(stmt, Settings.System.POINTER_SPEED,
                      R.integer.def_pointer_speed);
          } finally {
              if (stmt != null) stmt.close();
          }
      }

```

在loadSystemSettings(SQLiteDatabase db)中的默认system类型的系统属性的默认加载，供系统调用所以可以在这里加载显示电池电量的属性


具体如下:



```
diff --git a/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java b/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

index e27af86862..62996cbdcc 100755

--- a/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

+++ b/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

@@ -2305,6 +2305,8 @@ class DatabaseHelper extends SQLiteOpenHelper {

       loadBooleanSetting(stmt, Settings.System.DIM_SCREEN,
                      R.bool.def_dim_screen);
              loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                      R.integer.def_screen_off_timeout);
  
              // Set default cdma DTMF type
              loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);
  
              // Set default hearing aid
              loadSetting(stmt, Settings.System.HEARING_AID, 0);
  
              // Set default tty mode
              loadSetting(stmt, Settings.System.TTY_MODE, 0);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                      R.integer.def_screen_brightness);
  
              loadBooleanSetting(stmt, Settings.System.NOTIFICATION_LIGHT_PULSE,
                      R.bool.def_notification_pulse);
  

             loadIntegerSetting(stmt, Settings.System.NAVIGATION_BAR_SHOW,

                     R.integer.def_navigation_bar_show);

+

+                       loadIntegerSetting(stmt, Settings.System.SHOW_BATTERY_PERCENT, R.integer.def_show_battery_percent);

```

通过在loadSystemSettings(SQLiteDatabase db)中添加  
 loadIntegerSetting(stmt, Settings.System.SHOW\_BATTERY\_PERCENT, R.integer.def\_show\_battery\_percent)  
 来实现了对默认显示电池电量的修改





