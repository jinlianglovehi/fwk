






### 1.概述


在10.0的系统产品开发中，产品需要对wifi模块进行管控，通过系统属性来控制wifi模块是否启用，所以需要在打开wifi的地方来通过系统属性来控制是否可以打开wifi


### 2.wifi开关控制的核心类



```
frameworks/base/wifi/java/android/net/wifi/WifiManager.java
packages/apps/Settings/src/com/android/settings/wifi/WifiEnabler.java
packages/apps/Settings/src/com/android/settings/wifi/WifiSettings.java

```

### 3.wifi开关控制的核心功能分析和实现


### 3.1 在wifi管理类中的WifiManager中打开关闭wifi


在系统中wifi的管理是由WifiManager负责管理的，接下来就来看怎么通过系统属性来实现  
 对wifi的控制管理



```
--- a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
+++ b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
@@ -19,7 +19,7 @@ package android.net.wifi;
 import static android.Manifest.permission.ACCESS_FINE_LOCATION;
 import static android.Manifest.permission.ACCESS_WIFI_STATE;
 import static android.Manifest.permission.READ_WIFI_CREDENTIAL;
-
+import android.os.SystemProperties;
 import android.annotation.CallbackExecutor;
 import android.annotation.IntDef;
 import android.annotation.NonNull;
@SystemService(Context.WIFI_SERVICE)
  public class WifiManager {
      */
     @Deprecated
     public boolean setWifiEnabled(boolean enabled) {
+               String flag = SystemProperties.get("persist.sys.enableWIFI", "true");
+               if(!"true".equals(flag)){
+                       return false;
+               }
         try {
             return mService.setWifiEnabled(mContext.getOpPackageName(), enabled);
         } catch (RemoteException e) {
         }
/**
       * Gets the Wi-Fi enabled state.
       * @return One of {@link #WIFI\_STATE\_DISABLED},
       *         {@link #WIFI\_STATE\_DISABLING}, {@link #WIFI\_STATE\_ENABLED},
       *         {@link #WIFI\_STATE\_ENABLING}, {@link #WIFI\_STATE\_UNKNOWN}
       * @see #isWifiEnabled()
       */
      public int getWifiState() {
          try {
              return mService.getWifiEnabledState();
          } catch (RemoteException e) {
              throw e.rethrowFromSystemServer();
          }
      }
  
      /**
       * Return whether Wi-Fi is enabled or disabled.
       * @return {@code true} if Wi-Fi is enabled
       * @see #getWifiState()
       */
      public boolean isWifiEnabled() {
          return getWifiState() == WIFI_STATE_ENABLED;
      }

```

在WifiManager.java中的setWifiEnabled(boolean enabled) 打开wifi的时候，需要通过系统属性  
 persist.sys.enableWIFI来判断当前是否需要开启wifi功能，实现对wifi的管控


### 3.2 WifiEnabler 控制wifi开关修改


接下来在系统Settings中的wifi页面判断是否通过wifi开关来打开wifi功能



```
--- a/packages/apps/Settings/src/com/android/settings/wifi/WifiEnabler.java
+++ b/packages/apps/Settings/src/com/android/settings/wifi/WifiEnabler.java
@@ -30,9 +30,9 @@ import android.os.UserHandle;
 import android.os.UserManager;
 import android.provider.Settings;
 import android.widget.Toast;
-
+import android.os.SystemProperties;
 import androidx.annotation.VisibleForTesting;
-
+import android.util.Log;
 import com.android.settings.R;
 import com.android.settings.widget.SwitchWidgetController;
 import com.android.settingslib.RestrictedLockUtils.EnforcedAdmin;
@@ -141,6 +141,11 @@ public class WifiEnabler implements SwitchWidgetController.OnSwitchChangeListene
     }
 public WifiEnabler(Context context, SwitchWidgetController switchWidget,
         MetricsFeatureProvider metricsFeatureProvider) {
         this(context, switchWidget, metricsFeatureProvider,
             (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE));
     }
 
     @VisibleForTesting
     WifiEnabler(Context context, SwitchWidgetController switchWidget,
             MetricsFeatureProvider metricsFeatureProvider,
             ConnectivityManager connectivityManager) {
         mContext = context;
         mSwitchWidget = switchWidget;
         mSwitchWidget.setListener(this);
         mMetricsFeatureProvider = metricsFeatureProvider;
         mWifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
         mConnectivityManager = connectivityManager;
 
         mIntentFilter = new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);
          // The order matters! We really should not depend on this. :(
          mIntentFilter.addAction(WifiManager.SUPPLICANT_STATE_CHANGED_ACTION);
          mIntentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
  
          setupSwitchController();
      }
      
     private void handleWifiStateChanged(int state) {
+               String flag = SystemProperties.get("persist.sys.enableWIFI", "false");
+               Log.d("dong","setSwitchBarChecked enableWIFI:"+flag);
+               if(!"true".equals(flag)){
+                       return ;
+               }
         // Clear any previous state
         mSwitchWidget.setDisabledByAdmin(null);
 
@@ -196,6 +201,11 @@ public class WifiEnabler implements SwitchWidgetController.OnSwitchChangeListene
 
     @Override
     public boolean onSwitchToggled(boolean isChecked) {
+               String flag = SystemProperties.get("persist.sys.enableWIFI", "true");
+               if(!"true".equals(flag)){
+                       return false;
+               }
         //Do nothing if called as a result of a state machine event
         if (mStateMachineEvent) {
             return true;

```

在系统Settings中的WifiEnabler.java通过onSwitchToggled和handleWifiStateChanged(int state)通过系统属性来判断当前wifi是否可以打开，来实现对wifi功能的管控


### 3.3系统Settings中的WifiSettings.java对wifi 开关按钮的管控


接下来看WifiSettings.java中对wifi的管控  
 接下来看相关源码



```
 public class WifiSettings extends RestrictedSettingsFragment
          implements Indexable, WifiTracker.WifiListener, AccessPointListener,
          WifiDialog.WifiDialogListener, DialogInterface.OnDismissListener {
		   @Override
      public void onViewCreated(View view, Bundle savedInstanceState) {
          super.onViewCreated(view, savedInstanceState);
          final Activity activity = getActivity();
          if (activity != null) {
              mProgressHeader = setPinnedHeaderView(R.layout.progress_header)
                      .findViewById(R.id.progress_bar_animation);
              setProgressBarVisible(false);
          }
          ((SettingsActivity) activity).getSwitchBar().setSwitchBarText(
                  R.string.wifi_settings_master_switch_title,
                  R.string.wifi_settings_master_switch_title);
      }

```

在onViewCreated(View view, Bundle savedInstanceState)中判断是否需要通过打开wifi的  
 SwitchBar来设置相关的标题，所以需要在这里做判断是否打开wifi  
 修改如下:



```
--- a/packages/apps/Settings/src/com/android/settings/wifi/WifiSettings.java
+++ b/packages/apps/Settings/src/com/android/settings/wifi/WifiSettings.java
@@ -50,7 +50,7 @@ import android.view.Menu;
 import android.view.MenuItem;
 import android.view.View;
 import android.widget.Toast;
-
+import android.os.SystemProperties;
 import androidx.annotation.VisibleForTesting;
 import androidx.preference.Preference;
 import androidx.preference.PreferenceCategory;
@SearchIndexable

         ((SettingsActivity) activity).getSwitchBar().setSwitchBarText(
 R.string.wifi\_settings\_master\_switch\_title,
 R.string.wifi\_settings\_master\_switch\_title);
+ String flag = SystemProperties.get("persist.sys.enableWIFI", "true");
+ if(!"true".equals(flag)){
+                        ((SettingsActivity) activity).getSwitchBar().setEnabled(false);
+               }               
     }

```

通过增加persist.sys.enableWIFI判断是否打开wifi的SwitchBar按钮，控制wifi的打开





