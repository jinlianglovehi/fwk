






### 1.概述


在android 9.0 10.0由于系统对安全要求越来越严格,所以不允许app往系统节点/sys/class写入数据，即使是系统应用也没这个权限了，所以用普通的方法是行不通了


### 2.sys/class系统节点写不进去的解决方案(正确往系统节点写数据)的核心类



```
system/core/rootdir/init.rc

```

### 3.sys/class系统节点写不进去的解决方案(正确往系统节点写数据)的核心功能分析和实现


例如:  
 8.1以前的方式  
 第一种



```
public void writetoLed(){
    try {
        BufferedWriter bw = new BufferedWriter(new FileWriter("/sys/class/leds/brightness"));
        bw.write("0");
        bw.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

```

第二种方式



```
public void cmdLed() {
    String cmd = "/system/bin/busybox " + "echo 0 >/sys/class/leds/brightness " + "\n";
    try {
        Process exeEcho = Runtime.getRuntime().exec("sh");
        exeEcho.getOutputStream().write(cmd.getBytes());
        exeEcho.getOutputStream().flush();
        Log.d(TAG, " " + cmd);
    } catch (Exception e) {
        Log.d(TAG, "cmdRelayOpen faild");
    }
}

```

在9.0以后这两种方式都不行了  
 9.0以后系统出于安全的考虑，认为这样读写系统节点会不安全，所以会操作不成功，那么怎么正确的往系统节点写数据呢，


实现思路：  
 1.在系统开机脚本init.rc里面 用write命令往节点写属性，这里权限也是最大的  
 2.用on property添加执行条件，根据SystemProperties系统属性值的变化来执行相应的写数据操作


具体实现方案如下：  
 init.rc相关源码分析



```


# Cgroups are mounted right before early-init using list from /etc/cgroups.json
on early-init
    # Disable sysrq from keyboard
    write /proc/sys/kernel/sysrq 0

    # Set the security context of /adb\_keys if present.
    restorecon /adb_keys

    # Set the security context of /postinstall if present.
    restorecon /postinstall

    mkdir /acct/uid

    # memory.pressure\_level used by lmkd
    chown root system /dev/memcg/memory.pressure_level
    chmod 0040 /dev/memcg/memory.pressure_level
    # app mem cgroups, used by activity manager, lmkd and zygote
    mkdir /dev/memcg/apps/ 0755 system system
    # cgroup for system\_server and surfaceflinger
    mkdir /dev/memcg/system 0550 system system

    start ueventd

    # Run apexd-bootstrap so that APEXes that provide critical libraries
    # become available. Note that this is executed as exec\_start to ensure that
    # the libraries are available to the processes started after this statement.
    exec_start apexd-bootstrap

on init
    sysclktz 0

    # Mix device-specific information into the entropy pool

     mount configfs none /config nodev noexec nosuid
     chmod 0770 /config/sdcardfs
     chown system package_info /config/sdcardfs
 
     mkdir /mnt/secure 0700 root root
     mkdir /mnt/secure/asec 0700 root root
     mkdir /mnt/asec 0755 root system
     mkdir /mnt/obb 0755 root system
     mkdir /mnt/media_rw 0750 root media_rw
     mkdir /mnt/user 0755 root root
     mkdir /mnt/user/0 0755 root root
     mkdir /mnt/expand 0771 system system
     mkdir /mnt/appfuse 0711 root root
 
     # /proc/net/fib\_trie leaks interface IP addresses
     chmod 0400 /proc/net/fib_trie
 
     # Create cgroup mount points for process groups
     chown system system /dev/cpuctl
     chown system system /dev/cpuctl/tasks
     chmod 0666 /dev/cpuctl/tasks
     write /dev/cpuctl/cpu.rt_period_us 1000000
     write /dev/cpuctl/cpu.rt_runtime_us 950000
 
     # Create location for fs\_mgr to store abbreviated output from filesystem
     # checker programs.
     mkdir /dev/fscklogs 0770 root system
 
     # pstore/ramoops previous console log
     mount pstore pstore /sys/fs/pstore nodev noexec nosuid
     chown system log /sys/fs/pstore
     chmod 0550 /sys/fs/pstore
     chown system log /sys/fs/pstore/console-ramoops
     chmod 0440 /sys/fs/pstore/console-ramoops
     chown system log /sys/fs/pstore/console-ramoops-0
     chmod 0440 /sys/fs/pstore/console-ramoops-0
     chown system log /sys/fs/pstore/pmsg-ramoops-0
     chmod 0440 /sys/fs/pstore/pmsg-ramoops-0
 
     # enable armv8\_deprecated instruction hooks
     write /proc/sys/abi/swp 1
 
     # Linux's execveat() syscall may construct paths containing /dev/fd
     # expecting it to point to /proc/self/fd
     symlink /proc/self/fd /dev/fd
 
     export DOWNLOAD_CACHE /data/cache
 
     # set RLIMIT\_NICE to allow priorities from 19 to -20
     setrlimit nice 40 40
 
     # Allow up to 32K FDs per process
     setrlimit nofile 32768 32768
 
     # This allows the ledtrig-transient properties to be created here so
     # that they can be chown'd to system:system later on boot
     write /sys/class/leds/vibrator/trigger "transient"
 
     # Allow system processes to read / write power state.
     chown system system /sys/power/state
     chown system system /sys/power/wakeup_count
     chmod 0660 /sys/power/state
 
     # Start logd before any other services run to ensure we capture all of their logs.
     start logd
 
     # Start essential services.
     start servicemanager
     start hwservicemanager
     start vndservicemanager
 
 # Healthd can trigger a full boot from charger mode by signaling this
 # property when the power button is held.
 on property:sys.boot_from_charger_mode=1
     class_stop charger
     trigger late-init
 
 on load_persist_props_action
     load_persist_props
     start logd
     start logd-reinit
 
 # Indicate to fw loaders that the relevant mounts are up.
 on firmware_mounts_complete
     rm /dev/.booting
 
 # Mount filesystems and start core system services.
 on late-init
     trigger early-fs
 
     # Mount fstab in init.{$device}.rc by mount\_all command. Optional parameter
     # '--early' can be specified to skip entries with 'latemount'.
     # /system and /vendor must be mounted by the end of the fs stage,
     # while /data is optional.
     trigger fs
     trigger post-fs
 
     # Mount fstab in init.{$device}.rc by mount\_all with '--late' parameter
     # to only mount entries with 'latemount'. This is needed if '--early' is
     # specified in the previous mount\_all command on the fs stage.
     # With /system mounted and properties form /system + /factory available,
     # some services can be started.
     trigger late-fs
 
     # Now we can mount /data. File encryption requires keymaster to decrypt
     # /data, which in turn can only be loaded when system properties are present.
     trigger post-fs-data
 
     # Load persist properties and override properties (if enabled) from /data.
     trigger load_persist_props_action
 
     # Now we can start zygote for devices with file based encryption
     trigger zygote-start
 
     # Remove a file to wake up anything waiting for firmware.
     trigger firmware_mounts_complete
 
     trigger early-boot
     trigger boot
 
 on early-fs
     # Once metadata has been mounted, we'll need vold to deal with userdata checkpointing
     start vold
 

```

案例一:  
 在开机完成时节点写数据:  
 系统开机完成后，会将sys.boot\_completed 赋值为1



```
on property:sys.boot_completed=1    

   setprop persist.service.enable 0

   write /sys/bus/platform/drivers/usb20_otg/force_usb_mode 1

   start adbd

```

init.rc是Android系统/init程序读取的初始化配置文件，用于启动Android中的各种服务，以及配置系统。  
 而在write 
 
 [ ]\* 
   
 向 
 
 指定的文件写入一个或多个字符串。 
   
 通过write命令向某个path写值 
   
 案例二: 
   
 在app中，Systemproperties.set(“persist.sys.enable”, “0”)可以对persist.sys.enable 写入数据 
   
 当属性值变化时执行相应动作 
 




```
on property:persist.sys.enable=0        

   write /sys/class/gpio/gpio107/value 0                     

   start adbd

on property:persist.sys.enable=1

   write /sys/class/gpio/gpio107/value 1

   start adbd

```

所以可以在init.rc中通过设置监听属性值的变化，然后往节点里面写数据，完成功能





