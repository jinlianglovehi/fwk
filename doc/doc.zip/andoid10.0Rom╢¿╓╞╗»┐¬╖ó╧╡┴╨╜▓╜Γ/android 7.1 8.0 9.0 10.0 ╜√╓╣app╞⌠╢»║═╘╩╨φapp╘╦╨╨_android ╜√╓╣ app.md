






android 定制化开发中,可以有需求要实现禁止app启动和允许app运行的接口，禁用后app后已安装的应用从桌面消失，只存在于系统设置内的应用列表里，无法调用。启用后，恢复正常使用，在桌面显示。对于app管理的都是由PackageManager来负责的，PackageManger的主要职责是管理应用程序包，通过它可以获取应用程序信息 所以就查看PackManager的相关源码看  
 能不能实现需求:  
 一、PackageManager的功能：


1、安装，卸载应用  
 2、查询permission相关信息  
 3、查询Application相关信息(application，activity，receiver，service，provider及相应属性等）  
 4、查询已安装应用  
 5、增加，删除permission  
 6、清除用户数据、缓存，代码段等


二、PackageManager相关类和方法介绍：


1、PackageManager类


说明： 获得已安装的应用程序信息 。可以通过getPackageManager()方法获得。


常用方法：



```
public abstract PackageManager getPackageManager()  

```

功能：获得一个PackageManger对象



```
public abstract Drawable getApplicationIcon(String packageName)

```

参数： packageName 包名  
 功能：返回给定包名的图标，否则返回null



```
public abstract ApplicationInfo getApplicationInfo(String packageName, int flags)

```

参数：  
 　　packagename 包名  
 　　flags 该ApplicationInfo是此flags标记，通常可以直接赋予常数0即可  
 功能：返回该ApplicationInfo对象



```
public abstract List<ApplicationInfo> getInstalledApplications(int flags)

```

参数：  
 　　flag为一般为GET\_UNINSTALLED\_PACKAGES，那么此时会返回所有ApplicationInfo。我们可以对ApplicationInfo  
 　　的flags过滤,得到我们需要的。  
 功能：返回给定条件的所有PackageInfo



```
public abstract List<PackageInfo> getInstalledPackages(int flags) 

```

参数如上  
 功能：返回给定条件的所有PackageInfo



```
public abstract ResolveInfo resolveActivity(Intent intent, int flags)

```

参数：  
 　　intent 查寻条件，Activity所配置的action和category  
 　　flags： MATCH\_DEFAULT\_ONLY ：Category必须带有CATEGORY\_DEFAULT的Activity，才匹配  
 　　　　　　 GET\_INTENT\_FILTERS ：匹配Intent条件即可  
 　　　　　　 GET\_RESOLVED\_FILTER ：匹配Intent条件即可  
 功能 ：返回给定条件的ResolveInfo对象(本质上是Activity)


public abstract List queryIntentActivities(Intent intent, int flags)  
 参数同上  
 功能 ：返回给定条件的所有ResolveInfo对象(本质上是Activity)，集合对象


public abstract ResolveInfo resolveService(Intent intent, int flags)  
 参数同上  
 功能 ：返回给定条件的ResolveInfo对象(本质上是Service)


public abstract List queryIntentServices(Intent intent, int flags)  
 参数同上  
 功能 ：返回给定条件的所有ResolveInfo对象(本质上是Service)，集合对象


2、PackageItemInfo类


说明： AndroidManifest.xml文件中所有节点的基类，提供了这些节点的基本信息：label、icon、 meta-data。它并不直接使用，而是由子类继承然后调用相应方法。


3、ApplicationInfo类 继承自 PackageItemInfo类


说明：获取一个特定引用程序中节点的信息。


字段说明：  
 flags字段： FLAG\_SYSTEM　系统应用程序  
 FLAG\_EXTERNAL\_STORAGE　表示该应用安装在sdcard中


常用方法继承至PackageItemInfo类中的loadIcon()和loadLabel()


4、ActivityInfo类 继承自 PackageItemInfo类


说明： 获得应用程序中或者 节点的信息 。我们可以通过它来获取我们设置的任何属性，包括theme 、launchMode、launchmode等


常用方法继承至PackageItemInfo类中的loadIcon()和loadLabel()


5、ServiceInfo类 继承自 PackageItemInfo类


说明：与ActivityInfo类似，代表节点信息


6、ResolveInfo类


说明：根据节点来获取其上一层目录的信息，通常是、、节点信息。  
 常用方法有`loadIcon(PackageManager pm)和loadLabel(PackageManager pm)`


PackageManager类中一些变量和方法的介绍：



```
int COMPONENT_ENABLED_STATE_DEFAULT：

可以在方法setApplicationEnabledSetting(String,int,int)和setComponentEnabledSetting(ComponentName,int,int)中使用，该组件或应用程序处于默认开启状态（其在清单指定）。

```

int COMPONENT\_ENABLED\_STATE\_DISABLED：



```
可以在方法setApplicationEnabledSetting(String,int,int)和setComponentEnabledSetting(ComponentName,int,int)中使用，该组件或者应用程序被禁用，不管你是否在清单文件中指定。

```

int COMPONENT\_ENABLED\_STATE\_DISABLED\_UNTIL\_USED：



```
只在方法setApplicationEnabledSetting(String,int,int)中使用，用户实际上使用它，这个应用程序才会被启动。

```

int COMPONENT\_ENABLED\_STATE\_DISABLED\_USER：



```
只在方法setApplicationEnabledSetting(String,int,int)中使用，用户禁止启动该应用程序，不管是否在清单文件中指定。

```

int COMPONENT\_ENABLED\_STATE\_ENABLED：



```
可以在方法setApplicationEnabledSetting(String,int,int)和setComponentEnabledSetting(ComponentName,int,int)中使用，该组件或者应用程序启动，不管你是否在清单文件中指定。

```

int DONT\_KILL\_APP：



```
setComponentEnabledSetting(ComponentName,int,int)方法中的标志参数，表明您不想杀死包含该组件的应用程序。

```

通过上面的源码可以看出 通过setApplicationEnabledSetting的包名和变量值可以实现禁止或运行app运行  
 解决思路:  
 调用PackageManager的setApplicationEnabledSetting 来实现  
 1.禁止app运行  
 pm.setApplicationEnabledSetting(pkg, PackageManager.COMPONENT\_ENABLED\_STATE\_DISABLED, 0);  
 2.允许app运行  
 pm.setApplicationEnabledSetting(str\_packagename, PackageManager.COMPONENT\_ENABLED\_STATE\_ENABLED, 0);


实现案例如下:



```
PackageManager pm = mContext.getPackageManager();
        if (packageNames==null || packageNames.size()==0){
            Log.d(TAG,"DisallowedRunningApp is null");
			String disableRunapps = Settings.System.getString(mContext.getContentResolver(), "DisallowedRunningApp");
            if(!TextUtils.isEmpty(disableRunapps)){
               String [] applist = disableRunapps.split(",");
				if(applist!=null&&applist.length>0){
					for(String str_packagename:applist){
    // 运行app运行
						pm.setApplicationEnabledSetting(str_packagename, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, 0);
					}
				}
            }
            Settings.System.putString(mContext.getContentResolver(), "DisallowedRunningApp", "");
            return;
        }
        String s="";
        for (String str:packageNames){
            s=s+str+",";
        }
        Settings.System.putString(mContext.getContentResolver(), "DisallowedRunningApp", s);
        try {
            disable_packageNames = packageNames;
            if (disable_packageNames != null && disable_packageNames.size() > 0) {
                for (String pkg : disable_packageNames) {

                    ApplicationInfo applicationInfo = pm.getApplicationInfo(pkg, 0);
                    if (applicationInfo == null) {
                        continue;
                    }
                    if (!applicationInfo.enabled) {
                        continue;
                    }
                    if ("com.android.settings".equals(applicationInfo.packageName)) {
                        continue;
                    }
                   //禁止app运行
                    pm.setApplicationEnabledSetting(pkg, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, 0);
                }
            } else {
                List<ApplicationInfo> installedApplications = pm.getInstalledApplications(PackageManager.MATCH_ALL);
                for (ApplicationInfo info : installedApplications) {
                    if (!info.enabled) {
						if ("com.android.settings".equals(info.packageName)) {
                            continue;
                        }
                        pm.setApplicationEnabledSetting(info.packageName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, 0);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

```




