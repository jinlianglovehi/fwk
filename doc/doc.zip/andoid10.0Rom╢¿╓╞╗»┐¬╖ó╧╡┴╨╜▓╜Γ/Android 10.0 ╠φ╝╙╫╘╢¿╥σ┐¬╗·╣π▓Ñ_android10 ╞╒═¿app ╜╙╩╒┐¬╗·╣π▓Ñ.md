






### 1.概述


由于系统开机广播接收受限，普通app接收不到这个广播，如果接收这个广播很多应用 感觉要好久收到这个广播，所以需要自定义开机广播来使用自定义广播开启某些应用，实现自己的功能


### 2.添加自定义广播的核心代码



```
frameworks\base\services\core\java\com\android\server\am\UserController.java

```

### 3.添加自定义广播的核心代码功能分析和实现功能


### 3.1首先来找到开机广播发送的地方


发送开机广播为Intent.ACTION\_BOOT\_COMPLETED.在开机完成以后系统会发送这个广播。来通知广播已经完成系统启动了，可以做其他的事情了，所以经过相关代码分析发现是在UserController.java中实现开机广播，所以分析UserController.java的相关代码



```
frameworks\base\services\core\java\com\android\server\am\UserController.java
finishUserUnlockedCompleted方法里：
void finishUserUnlockedCompleted(UserState uss) {
final int userId = uss.mHandle.getIdentifier();
synchronized (mLock) {
// Bail if we ended up with a stale user
if (mStartedUsers.get(uss.mHandle.getIdentifier()) != uss) return;
}
UserInfo userInfo = getUserInfo(userId);
if (userInfo == null) {
return;
}
// Only keep marching forward if user is actually unlocked
if (!StorageManager.isUserKeyUnlocked(userId)) return;
    // Remember that we logged in
    mInjector.getUserManager().onUserLoggedIn(userId);

    if (!userInfo.isInitialized()) {
        if (userId != UserHandle.USER_SYSTEM) {
            Slog.d(TAG, "Initializing user #" + userId);
            Intent intent = new Intent(Intent.ACTION_USER_INITIALIZE);
            intent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND
                    | Intent.FLAG_RECEIVER_INCLUDE_BACKGROUND);
            mInjector.broadcastIntent(intent, null,
                    new IIntentReceiver.Stub() {
                        @Override
                        public void performReceive(Intent intent, int resultCode,
                                String data, Bundle extras, boolean ordered,
                                boolean sticky, int sendingUser) {
                            // Note: performReceive is called with mService lock held
                            mInjector.getUserManager().makeInitialized(userInfo.id);
                        }
                    }, 0, null, null, null, AppOpsManager.OP_NONE,
                    null, true, false, MY_PID, SYSTEM_UID, Binder.getCallingUid(),
                    Binder.getCallingPid(), userId);
        }
    }

    // Spin up app widgets prior to boot-complete, so they can be ready promptly
    mInjector.startUserWidgets(userId);

    Slog.i(TAG, "Posting BOOT\_COMPLETED user #" + userId);
    // Do not report secondary users, runtime restarts or first boot/upgrade
    if (userId == UserHandle.USER_SYSTEM
            && !mInjector.isRuntimeRestarted() && !mInjector.isFirstBootOrUpgrade()) {
        int uptimeSeconds = (int) (SystemClock.elapsedRealtime() / 1000);
        MetricsLogger.histogram(mInjector.getContext(), "framework\_boot\_completed",
                uptimeSeconds);
    }
    final Intent bootIntent = new Intent(Intent.ACTION_BOOT_COMPLETED, null);
    bootIntent.putExtra(Intent.EXTRA_USER_HANDLE, userId);
    bootIntent.addFlags(Intent.FLAG_RECEIVER_NO_ABORT
            | Intent.FLAG_RECEIVER_INCLUDE_BACKGROUND
            | Intent.FLAG_RECEIVER_OFFLOAD);
    // Widget broadcasts are outbound via FgThread, so to guarantee sequencing
    // we also send the boot_completed broadcast from that thread.
    final int callingUid = Binder.getCallingUid();
    final int callingPid = Binder.getCallingPid();
    FgThread.getHandler().post(() -> {
        mInjector.broadcastIntent(bootIntent, null,
                new IIntentReceiver.Stub() {
                    @Override
                    public void performReceive(Intent intent, int resultCode, String data,
                            Bundle extras, boolean ordered, boolean sticky, int sendingUser)
                                    throws RemoteException {
                        Slog.i(UserController.TAG, "Finished processing BOOT\_COMPLETED for u"
                                + userId);
                        mBootCompleted = true;
                    }
                }, 0, null, null,
                new String[]{android.Manifest.permission.RECEIVE_BOOT_COMPLETED},
                AppOpsManager.OP_NONE, null, true, false, MY_PID, SYSTEM_UID,
                callingUid, callingPid, userId);
    });
}

```

在发送开机广播时会定向发送优先级高的可以先接收到广播，所以由于发送的广播多造成  
 开机广播耗时比较久，所以在开机广播之前添加自定义广播。需要在系统开机广播之前发送自定义开机广播，自定义开机广播添加如下：



```
void finishUserUnlockedCompleted(UserState uss) {
final int userId = uss.mHandle.getIdentifier();
synchronized (mLock) {
// Bail if we ended up with a stale user
if (mStartedUsers.get(uss.mHandle.getIdentifier()) != uss) return;
}
UserInfo userInfo = getUserInfo(userId);
if (userInfo == null) {
return;
}
// Only keep marching forward if user is actually unlocked
if (!StorageManager.isUserKeyUnlocked(userId)) return;
    // Remember that we logged in
    mInjector.getUserManager().onUserLoggedIn(userId);

    if (!userInfo.isInitialized()) {
        if (userId != UserHandle.USER_SYSTEM) {
            Slog.d(TAG, "Initializing user #" + userId);
            Intent intent = new Intent(Intent.ACTION_USER_INITIALIZE);
            intent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND
                    | Intent.FLAG_RECEIVER_INCLUDE_BACKGROUND);
            mInjector.broadcastIntent(intent, null,
                    new IIntentReceiver.Stub() {
                        @Override
                        public void performReceive(Intent intent, int resultCode,
                                String data, Bundle extras, boolean ordered,
                                boolean sticky, int sendingUser) {
                            // Note: performReceive is called with mService lock held
                            mInjector.getUserManager().makeInitialized(userInfo.id);
                        }
                    }, 0, null, null, null, AppOpsManager.OP_NONE,
                    null, true, false, MY_PID, SYSTEM_UID, Binder.getCallingUid(),
                    Binder.getCallingPid(), userId);
        }
    }

    // Spin up app widgets prior to boot-complete, so they can be ready promptly
    mInjector.startUserWidgets(userId);

    Slog.i(TAG, "Posting BOOT\_COMPLETED user #" + userId);
    // Do not report secondary users, runtime restarts or first boot/upgrade
    if (userId == UserHandle.USER_SYSTEM
            && !mInjector.isRuntimeRestarted() && !mInjector.isFirstBootOrUpgrade()) {
        int uptimeSeconds = (int) (SystemClock.elapsedRealtime() / 1000);
        MetricsLogger.histogram(mInjector.getContext(), "framework\_boot\_completed",
                uptimeSeconds);
    }
   
    //add cord start 
  final Intent custombootIntent = new Intent("com.pnr.intent.action.BOOT\_COMPLETED", null);
  custombootIntent.putExtra(Intent.EXTRA_USER_HANDLE, userId);
  custombootIntent.addFlags(Intent.FLAG_RECEIVER_NO_ABORT
              | Intent.FLAG_RECEIVER_INCLUDE_BACKGROUND
              | Intent.FLAG_RECEIVER_OFFLOAD);
    final int callinguid = Binder.getCallingUid();
    final int callingpid = Binder.getCallingPid();
    FgThread.getHandler().post(() -> {
        mInjector.broadcastIntentcustombootIntent,null,null, 0, null, null,
                null,
                AppOpsManager.OP_NONE, null, true, false, MY_PID, SYSTEM_UID,
                callinguid, callingpid, userId);
    }); 
   //add code end

    final Intent bootIntent = new Intent(Intent.ACTION_BOOT_COMPLETED, null);
    bootIntent.putExtra(Intent.EXTRA_USER_HANDLE, userId);
    bootIntent.addFlags(Intent.FLAG_RECEIVER_NO_ABORT
            | Intent.FLAG_RECEIVER_INCLUDE_BACKGROUND
            | Intent.FLAG_RECEIVER_OFFLOAD);
    // Widget broadcasts are outbound via FgThread, so to guarantee sequencing
    // we also send the boot_completed broadcast from that thread.
    final int callingUid = Binder.getCallingUid();
    final int callingPid = Binder.getCallingPid();
    FgThread.getHandler().post(() -> {
        mInjector.broadcastIntent(bootIntent, null,
                new IIntentReceiver.Stub() {
                    @Override
                    public void performReceive(Intent intent, int resultCode, String data,
                            Bundle extras, boolean ordered, boolean sticky, int sendingUser)
                                    throws RemoteException {
                        Slog.i(UserController.TAG, "Finished processing BOOT\_COMPLETED for u"
                                + userId);
                        mBootCompleted = true;
                    }
                }, 0, null, null,
                new String[]{android.Manifest.permission.RECEIVE_BOOT_COMPLETED},
                AppOpsManager.OP_NONE, null, true, false, MY_PID, SYSTEM_UID,
                callingUid, callingPid, userId);
    });
}

```

通过添加上面的com.pnr.intent.action.BOOT\_COMPLETED为自定义广播，app端接收这个广播就额可以了注意Intent.FLAG\_RECEIVER\_NO\_ABORT的Flag，让这个有序广播不能被abort掉


### 3.2去掉自定义广播的Sending non-protected broadcast的异常日志打印


虽然这样可以发送自定义广播，但是不符合系统设计会抛出不安全异常 所以要不检查自定义广播  
 frameworks\base\services\core\java\com\android\server\am\ActivityManagerService.java  
 要想消除掉这个log，可以去checkBroadcastFromSystem里面修改



```
private void checkBroadcastFromSystem(Intent intent, ProcessRecord callerApp,
String callerPackage, int callingUid, boolean isProtectedBroadcast, List receivers) {
if ((intent.getFlags() & Intent.FLAG\_RECEIVER\_FROM\_SHELL) != 0) {
// Don't yell about broadcasts sent via shell
return;
}
 final String action = intent.getAction();
 if (isProtectedBroadcast
 || Intent.ACTION\_CLOSE\_SYSTEM\_DIALOGS.equals(action)
 || Intent.ACTION\_DISMISS\_KEYBOARD\_SHORTCUTS.equals(action)
 || Intent.ACTION\_MEDIA\_BUTTON.equals(action)
 || Intent.ACTION\_MEDIA\_SCANNER\_SCAN\_FILE.equals(action)
 || Intent.ACTION\_SHOW\_KEYBOARD\_SHORTCUTS.equals(action)
 || Intent.ACTION\_MASTER\_CLEAR.equals(action)
 || Intent.ACTION\_FACTORY\_RESET.equals(action)
 || AppWidgetManager.ACTION\_APPWIDGET\_CONFIGURE.equals(action)
 || AppWidgetManager.ACTION\_APPWIDGET\_UPDATE.equals(action)
 || LocationManager.HIGH\_POWER\_REQUEST\_CHANGE\_ACTION.equals(action)
 || TelephonyIntents.ACTION\_REQUEST\_OMADM\_CONFIGURATION\_UPDATE.equals(action)
 || SuggestionSpan.ACTION\_SUGGESTION\_PICKED.equals(action)
 || AudioEffect.ACTION\_OPEN\_AUDIO\_EFFECT\_CONTROL\_SESSION.equals(action)
 || AudioEffect.ACTION\_CLOSE\_AUDIO\_EFFECT\_CONTROL\_SESSION.equals(action)) {
        // Broadcast is either protected, or it's a public action that
 // we've relaxed, so it's fine for system internals to send.
 return;
 }

 // This broadcast may be a problem... but there are often system components that
 // want to send an internal broadcast to themselves, which is annoying to have to
 // explicitly list each action as a protected broadcast, so we will check for that
 // one safe case and allow it: an explicit broadcast, only being received by something
 // that has protected itself.
 if (intent.getPackage() != null || intent.getComponent() != null) {
 if (receivers == null || receivers.size() == 0) {
 // Intent is explicit and there's no receivers.
            // This happens, e.g. , when a system component sends a broadcast to
            // its own runtime receiver, and there's no manifest receivers for it,
            // because this method is called twice for each broadcast,
            // for runtime receivers and manifest receivers and the later check would find
            // no receivers.
            return;
        }
        boolean allProtected = true;
        for (int i = receivers.size()-1; i >= 0; i--) {
            Object target = receivers.get(i);
            if (target instanceof ResolveInfo) {
                ResolveInfo ri = (ResolveInfo)target;
                if (ri.activityInfo.exported && ri.activityInfo.permission == null) {
                    allProtected = false;
                    break;
                }
            } else {
                BroadcastFilter bf = (BroadcastFilter)target;
                if (bf.requiredPermission == null) {
                    allProtected = false;
                    break;
                }
            }
        }
        if (allProtected) {
            // All safe!
            return;
        }
    }

    // The vast majority of broadcasts sent from system internals
    // should be protected to avoid security holes, so yell loudly
    // to ensure we examine these cases.
    /*if (callerApp != null) {
        Log.wtf(TAG, "Sending non-protected broadcast " + action
                        + " from system " + callerApp.toShortString() + " pkg " + callerPackage,
                new Throwable());
    } else {
        Log.wtf(TAG, "Sending non-protected broadcast " + action
                        + " from system uid " + UserHandle.formatUid(callingUid)
                        + " pkg " + callerPackage,
                new Throwable());
    }*/
}

```

修改如下:



```
private void checkBroadcastFromSystem(Intent intent, ProcessRecord callerApp,
String callerPackage, int callingUid, boolean isProtectedBroadcast, List receivers) {
if ((intent.getFlags() & Intent.FLAG\_RECEIVER\_FROM\_SHELL) != 0) {
// Don't yell about broadcasts sent via shell
return;
}
 final String action = intent.getAction();

 // 此处修改 action添加到这里
 if (isProtectedBroadcast
 || Intent.ACTION\_CLOSE\_SYSTEM\_DIALOGS.equals(action)
 || Intent.ACTION\_DISMISS\_KEYBOARD\_SHORTCUTS.equals(action)
 || Intent.ACTION\_MEDIA\_BUTTON.equals(action)
 || Intent.ACTION\_MEDIA\_SCANNER\_SCAN\_FILE.equals(action)
 || Intent.ACTION\_SHOW\_KEYBOARD\_SHORTCUTS.equals(action)
 || Intent.ACTION\_MASTER\_CLEAR.equals(action)
 || Intent.ACTION\_FACTORY\_RESET.equals(action)
 || AppWidgetManager.ACTION\_APPWIDGET\_CONFIGURE.equals(action)
 || AppWidgetManager.ACTION\_APPWIDGET\_UPDATE.equals(action)
 || LocationManager.HIGH\_POWER\_REQUEST\_CHANGE\_ACTION.equals(action)
 || TelephonyIntents.ACTION\_REQUEST\_OMADM\_CONFIGURATION\_UPDATE.equals(action)
 || SuggestionSpan.ACTION\_SUGGESTION\_PICKED.equals(action)
 || AudioEffect.ACTION\_OPEN\_AUDIO\_EFFECT\_CONTROL\_SESSION.equals(action)
 + || "com.pnr.intent.action.BOOT\_COMPLETED".equals(action)
 || AudioEffect.ACTION\_CLOSE\_AUDIO\_EFFECT\_CONTROL\_SESSION.equals(action)) {
        // Broadcast is either protected, or it's a public action that
 // we've relaxed, so it's fine for system internals to send.
 return;
 }

 // This broadcast may be a problem... but there are often system components that
 // want to send an internal broadcast to themselves, which is annoying to have to
 // explicitly list each action as a protected broadcast, so we will check for that
 // one safe case and allow it: an explicit broadcast, only being received by something
 // that has protected itself.
 if (intent.getPackage() != null || intent.getComponent() != null) {
 if (receivers == null || receivers.size() == 0) {
 // Intent is explicit and there's no receivers.
            // This happens, e.g. , when a system component sends a broadcast to
            // its own runtime receiver, and there's no manifest receivers for it,
            // because this method is called twice for each broadcast,
            // for runtime receivers and manifest receivers and the later check would find
            // no receivers.
            return;
        }
        boolean allProtected = true;
        for (int i = receivers.size()-1; i >= 0; i--) {
            Object target = receivers.get(i);
            if (target instanceof ResolveInfo) {
                ResolveInfo ri = (ResolveInfo)target;
                if (ri.activityInfo.exported && ri.activityInfo.permission == null) {
                    allProtected = false;
                    break;
                }
            } else {
                BroadcastFilter bf = (BroadcastFilter)target;
                if (bf.requiredPermission == null) {
                    allProtected = false;
                    break;
                }
            }
        }
        if (allProtected) {
            // All safe!
            return;
        }
    }

    // The vast majority of broadcasts sent from system internals
    // should be protected to avoid security holes, so yell loudly
    // to ensure we examine these cases.
    /*if (callerApp != null) {
        Log.wtf(TAG, "Sending non-protected broadcast " + action
                        + " from system " + callerApp.toShortString() + " pkg " + callerPackage,
                new Throwable());
    } else {
        Log.wtf(TAG, "Sending non-protected broadcast " + action
                        + " from system uid " + UserHandle.formatUid(callingUid)
                        + " pkg " + callerPackage,
                new Throwable());
    }*/
}

```




