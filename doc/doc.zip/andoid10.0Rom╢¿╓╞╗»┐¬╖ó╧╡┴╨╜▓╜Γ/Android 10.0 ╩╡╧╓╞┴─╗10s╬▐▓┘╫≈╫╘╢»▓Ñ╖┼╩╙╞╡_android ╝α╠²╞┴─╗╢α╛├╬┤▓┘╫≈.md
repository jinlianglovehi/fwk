






1.概述  
 在定制化广告机项目中，需要不间断的播放视频，当对屏幕没有操作时继续播放视频，对于这个功能，  
 在app中，可以通过onTouch事件来判断手势抬起后倒计时10s无操作时然后播放视频，但是对于系统而言就难判断屏幕是否操作了  
 查阅资料得知，在PowerManagerService.java中有对操作屏幕做了记录时间


### 2.实现屏幕10s无操作自动播放视频的核心类



```
frameworks/base/services/core/java/com/android/server/power/PowerManagerService.java

```

### 3.实现屏幕10s无操作自动播放视频的核心功能分析和实现



```
      /**
       * Updates the global power state based on dirty bits recorded in mDirty.
       *
       * This is the main function that performs power state transitions.
       * We centralize them here so that we can recompute the power state completely
       * each time something important changes, and ensure that we do it the same
       * way each time.  The point is to gather all of the transition logic here.
       */
      private void updatePowerStateLocked() {
          if (!mSystemReady || mDirty == 0) {
              return;
          }
          if (!Thread.holdsLock(mLock)) {
              Slog.wtf(TAG, "Power manager lock was not held when calling updatePowerStateLocked");
          }
  
          Trace.traceBegin(Trace.TRACE_TAG_POWER, "updatePowerState");
          try {
              // Phase 0: Basic state updates.
              updateIsPoweredLocked(mDirty);
              updateStayOnLocked(mDirty);
              updateScreenBrightnessBoostLocked(mDirty);
  
              // Phase 1: Update wakefulness.
              // Loop because the wake lock and user activity computations are influenced
              // by changes in wakefulness.
              final long now = SystemClock.uptimeMillis();
              int dirtyPhase2 = 0;
              for (;;) {
                  int dirtyPhase1 = mDirty;
                  dirtyPhase2 |= dirtyPhase1;
                  mDirty = 0;
  
                  updateWakeLockSummaryLocked(dirtyPhase1);
                  updateUserActivitySummaryLocked(now, dirtyPhase1);
                  if (!updateWakefulnessLocked(dirtyPhase1)) {
                      break;
                  }
              }
  
              // Phase 2: Lock profiles that became inactive/not kept awake.
              updateProfilesLocked(now);
  
              // Phase 3: Update display power state.
              final boolean displayBecameReady = updateDisplayPowerStateLocked(dirtyPhase2);
  
              // Phase 4: Update dream state (depends on display ready signal).
              updateDreamLocked(dirtyPhase2, displayBecameReady);
  
              // Phase 5: Send notifications, if needed.
              finishWakefulnessChangeIfNeededLocked();
  
              // Phase 6: Update suspend blocker.
              // Because we might release the last suspend blocker here, we need to make sure
              // we finished everything else first!
              updateSuspendBlockerLocked();
          } finally {
              Trace.traceEnd(Trace.TRACE_TAG_POWER);
          }
      }
/**
 * Updates the value of mUserActivitySummary to summarize the user requested
 * state of the system such as whether the screen should be bright or dim.
 * Note that user activity is ignored when the system is asleep.
 *
 * This function must have no other side-effects.
 */
private void updateUserActivitySummaryLocked(long now, int dirty) {
    // Update the status of the user activity timeout timer.
    if ((dirty & (DIRTY\_WAKE\_LOCKS | DIRTY\_USER\_ACTIVITY
 | DIRTY\_WAKEFULNESS | DIRTY\_SETTINGS)) != 0) {
        mHandler.removeMessages(MSG_USER_ACTIVITY_TIMEOUT);

        long nextTimeout = 0;
        if (mWakefulness == WAKEFULNESS_AWAKE
                || mWakefulness == WAKEFULNESS_DREAMING
                || mWakefulness == WAKEFULNESS_DOZING) {
            final long sleepTimeout = getSleepTimeoutLocked();
            final long screenOffTimeout = getScreenOffTimeoutLocked(sleepTimeout);
            final long screenDimDuration = getScreenDimDurationLocked(screenOffTimeout);
            final boolean userInactiveOverride = mUserInactiveOverrideFromWindowManager;
            final long nextProfileTimeout = getNextProfileTimeoutLocked(now);

            mUserActivitySummary = 0;
            if (mLastUserActivityTime >= mLastWakeTime) {
                nextTimeout = mLastUserActivityTime
                        + screenOffTimeout - screenDimDuration;
                if (now < nextTimeout) {
                    mUserActivitySummary = USER_ACTIVITY_SCREEN_BRIGHT;
                } else {
                    nextTimeout = mLastUserActivityTime + screenOffTimeout;
                    if (now < nextTimeout) {
                        mUserActivitySummary = USER_ACTIVITY_SCREEN_DIM;
                    }
                }
            }
            if (mUserActivitySummary == 0
                    && mLastUserActivityTimeNoChangeLights >= mLastWakeTime) {
                nextTimeout = mLastUserActivityTimeNoChangeLights + screenOffTimeout;
                if (now < nextTimeout) {
                    if (mDisplayPowerRequest.policy == DisplayPowerRequest.POLICY_BRIGHT
                            || mDisplayPowerRequest.policy == DisplayPowerRequest.POLICY_VR) {
                        mUserActivitySummary = USER_ACTIVITY_SCREEN_BRIGHT;
                    } else if (mDisplayPowerRequest.policy == DisplayPowerRequest.POLICY_DIM) {
                        mUserActivitySummary = USER_ACTIVITY_SCREEN_DIM;
                    }
                }
            }

            if (mUserActivitySummary == 0) {
                if (sleepTimeout >= 0) {
                    final long anyUserActivity = Math.max(mLastUserActivityTime,
                            mLastUserActivityTimeNoChangeLights);
                    if (anyUserActivity >= mLastWakeTime) {
                        nextTimeout = anyUserActivity + sleepTimeout;
                        if (now < nextTimeout) {
                            mUserActivitySummary = USER_ACTIVITY_SCREEN_DREAM;
                        }
                    }
                } else {
                    mUserActivitySummary = USER_ACTIVITY_SCREEN_DREAM;
                    nextTimeout = -1;
                }
            }

            if (mUserActivitySummary != USER_ACTIVITY_SCREEN_DREAM && userInactiveOverride) {
                if ((mUserActivitySummary &
 (USER\_ACTIVITY\_SCREEN\_BRIGHT | USER\_ACTIVITY\_SCREEN\_DIM)) != 0) {
                    // Device is being kept awake by recent user activity
                    if (nextTimeout >= now && mOverriddenTimeout == -1) {
                        // Save when the next timeout would have occurred
                        mOverriddenTimeout = nextTimeout;
                    }
                }
                mUserActivitySummary = USER_ACTIVITY_SCREEN_DREAM;
                nextTimeout = -1;
            }

            if ((mUserActivitySummary & USER\_ACTIVITY\_SCREEN\_BRIGHT) != 0
 && (mWakeLockSummary & WAKE\_LOCK\_STAY\_AWAKE) == 0) {
 nextTimeout = mAttentionDetector.updateUserActivity(nextTimeout);
 }

 if (nextProfileTimeout > 0) {
 nextTimeout = Math.min(nextTimeout, nextProfileTimeout);
 }

 if (mUserActivitySummary != 0 && nextTimeout >= 0) {
 scheduleUserInactivityTimeout(nextTimeout);
 }
 } else {
 mUserActivitySummary = 0;
 }

 if (DEBUG\_SPEW) {
 Slog.d(TAG, "updateUserActivitySummaryLocked: mWakefulness="
 + PowerManagerInternal.wakefulnessToString(mWakefulness)
 + ", mUserActivitySummary=0x" + Integer.toHexString(mUserActivitySummary)
 + ", nextTimeout=" + TimeUtils.formatUptime(nextTimeout));
        }
    }
}

```

在PowerManagerService.java中的updatePowerStateLocked()负责更新电源的相关状态  
 在无操作的时候，会通过这里调用updateUserActivitySummaryLocked（）来判断当前时间是否到  
 息屏时间，如果是到了息屏时间那么就息屏，  
 通过源码发现 updateUserActivitySummaryLocked(）会对每次比较mLastUserActivityTime的值  
 来做相应的操作


所以就在这里添加判断无操作时间是否操作10秒如下



```
if(now-mLastUserActivityTime>=10000 && mBootCompleted && mSystemReady){

 Message msg = mHandler.obtainMessage(MSG_USER_NOT_ACTION);

 msg.setAsynchronous(true);

 mHandler.sendMessage(msg);

}

```

在开机完成开始判断，以免会有其他bug出现  
 now为开机启动到现在的时间，只需要计算开机启动后到现在的时间与最后一次用户操作的时间之差即可满足一段时间内用户无操作的需求。而用户每一次操作系统，mLastUserActivityTime都会更新，因此只需这个条件即可，发送msg消息来播放视频





