






### 1.概述


在10.0的系统产品开发中，对于在系统中使用jni也是很常见的，但在开发自己需要的功能时，还是需要增加jni来实现必要的功能


### 2.framework系统api添加jni方法的核心类



```
frameworks/base/core/jni/android_mdm_SystemUtils.cpp
frameworks/base/core/android/mdm/SystemUtils.java
frameworks/base/core/jni/Android.bp
frameworks/base/core/jni/AndroidRuntime.cpp

```

### 3.framework系统api添加jni方法的核心功能分析和实现


### 3.1 添加自定义类供上层app调用jni方法


android下新添加mdm文件夹  
 建立SystemUtils.java类



```
package android.mdm;
import android.util.Log;

public class SystemUtils {
    private native void native_setValue(int vlaue);
    private native int native_getValue();
    public int getValue() {
        Log.e("SystemUtils","read Begin");
        int value = native_getValue();
        Log.e("SystemUtils","value:"+value);
        return value;
    }
	
	public void setValue(int value){
		native_setValue(value);
	}
}

```

通过在SystemUtils 方便调用jni 也给上层提供调用jni的接口


### 3.2 在frameworks/base/core/jni下添加对应的cpp文件


新建android\_mdm\_SystemUtils.cpp文件  
 来将新增加的jni的方法参与系统的编译工作，然后便于调用



```
#define LOG\_TAG "SystemUtilsJNI"
 
 #include "jni.h"
 #include "android\_runtime/AndroidRuntime.h"
 
 #include <utils/misc.h>
 #include <utils/Log.h>
 #include <stdio.h>
 
namespace android
{
	static int jniData = 1;
	
	static void systemUtils_setVal(JNIEnv* env, jobject clazz, jint val)
	{
		jniData = val;
		ALOGI("mdmManager\_setVal......jniData=%d\n",jniData);
	}
	
	static jint systemUtils_getVal(JNIEnv* env, jobject clazz)
	{
		ALOGI("mdmManager\_getVal......jniData=%d\n",jniData);
		return jniData+50;
	}
	static const char* const kClassPathName = "android/mdm/SystemUtils";
	/*Java本地接口方法表*/
     static const JNINativeMethod method_table[] = {
		{"native\_setValue", "(I)V",(void*)systemUtils_setVal},
		{"native\_getValue", "()I",(void*)systemUtils_getVal},
	};
	 //注册java navive方法到AndroidRuntime中
	int register_android_mdm_SystemUtils(JNIEnv* env)
	{
		// Get the VendorUtilsClass class
		jclass vendorUtilsClass = env->FindClass(kClassPathName);
		if (vendorUtilsClass == NULL) {
			ALOGE("Can't find %s", kClassPathName);
			return -1;
		}
		int status = AndroidRuntime::registerNativeMethods(env,
					   kClassPathName, method_table, NELEM(method_table));
		return status;
	}
}

```

在上述方法中完成对在SystemUtils 类中的jni方法注册和管理方便系统jni功能实现


### 3.3 AndroidRuntime.cpp中注册JNI



```
static const RegJNIRec gRegJNI[] = {
+    REG_JNI(register_android_mdm_SystemUtils),
}
namespace android {
+extern int register_android_mdm_SystemUtils(JNIEnv *env);
}

```

在RegJNIRec注册新增的jni 来实现系统jni方法注册编译功能


3.4 frameworks/base/core/jni目录下Android.bp文件中添加需要编译的本地文件



```
 srcs: [
        "AndroidRuntime.cpp",
        "com\_android\_internal\_content\_NativeLibraryHelper.cpp",
        "com\_google\_android\_gles\_jni\_EGLImpl.cpp",
        "com\_google\_android\_gles\_jni\_GLImpl.cpp", // TODO: .arm
        "android\_app\_Activity.cpp",
        "android\_app\_ActivityThread.cpp",
        "android\_app\_NativeActivity.cpp",
        "android\_app\_admin\_SecurityLog.cpp",
        "android\_opengl\_EGL14.cpp",
        "android\_opengl\_EGL15.cpp",
        "android\_opengl\_EGLExt.cpp",
        "android\_opengl\_GLES10.cpp",
        "android\_opengl\_GLES10Ext.cpp",
        "android\_opengl\_GLES11.cpp",
        "android\_opengl\_GLES11Ext.cpp",
        "android\_opengl\_GLES20.cpp",
        "android\_opengl\_GLES30.cpp",
        "android\_opengl\_GLES31.cpp",
        "android\_opengl\_GLES31Ext.cpp",
        "android\_opengl\_GLES32.cpp",
        "android\_database\_CursorWindow.cpp",
        "android\_database\_SQLiteCommon.cpp",
        "android\_database\_SQLiteConnection.cpp",
        "android\_database\_SQLiteGlobal.cpp",
        "android\_database\_SQLiteDebug.cpp",
        "android\_graphics\_Canvas.cpp",
        "android\_graphics\_ColorSpace.cpp",
        "android\_graphics\_drawable\_AnimatedVectorDrawable.cpp",
        "android\_graphics\_drawable\_VectorDrawable.cpp",
        "android\_graphics\_Picture.cpp",
        "android\_view\_CompositionSamplingListener.cpp",
        "android\_view\_DisplayEventReceiver.cpp",
        "android\_view\_DisplayListCanvas.cpp",
        "android\_view\_TextureLayer.cpp",
        "android\_view\_InputChannel.cpp",
        "android\_view\_InputDevice.cpp",
        "android\_view\_InputEventReceiver.cpp",
        "android\_view\_InputEventSender.cpp",
        "android\_view\_InputQueue.cpp",
        "android\_view\_KeyCharacterMap.cpp",
        "android\_view\_KeyEvent.cpp",
        "android\_view\_MotionEvent.cpp",
        "android\_view\_PointerIcon.cpp",
        "android\_view\_RenderNode.cpp",
        "android\_view\_RenderNodeAnimator.cpp",
        "android\_view\_Surface.cpp",
        "android\_view\_SurfaceControl.cpp",
        "android\_view\_SurfaceSession.cpp",
        "android\_view\_TextureView.cpp",
        "android\_view\_ThreadedRenderer.cpp",
        "android\_view\_VelocityTracker.cpp",
        "android\_text\_AndroidCharacter.cpp",
        "android\_text\_Hyphenator.cpp",
        "android\_os\_Debug.cpp",
        "android\_os\_GraphicsEnvironment.cpp",
        "android\_os\_HidlSupport.cpp",
        "android\_os\_HwBinder.cpp",
        "android\_os\_HwBlob.cpp",
        "android\_os\_HwParcel.cpp",
        "android\_os\_HwRemoteBinder.cpp",
        "android\_os\_NativeHandle.cpp",
        "android\_os\_MemoryFile.cpp",
        "android\_os\_MessageQueue.cpp",
        "android\_os\_Parcel.cpp",
        "android\_os\_SELinux.cpp",
        "android\_os\_SharedMemory.cpp",
        "android\_os\_SystemClock.cpp",
        "android\_os\_SystemProperties.cpp",
        "android\_os\_Trace.cpp",
        "android\_os\_UEventObserver.cpp",
        "android\_os\_VintfObject.cpp",
        "android\_os\_VintfRuntimeInfo.cpp",
        "android\_net\_LocalSocketImpl.cpp",
        "android\_net\_NetUtils.cpp",
        "android\_nio\_utils.cpp",
        "android\_util\_AssetManager.cpp",
        "android\_util\_Binder.cpp",
        "android\_util\_EventLog.cpp",
        "android\_util\_Log.cpp",
        "android\_util\_StatsLog.cpp",
        "android\_util\_MemoryIntArray.cpp",
        "android\_util\_PathParser.cpp",
        "android\_util\_Process.cpp",
        "android\_util\_StringBlock.cpp",
        "android\_util\_XmlBlock.cpp",
        "android\_util\_jar\_StrictJarFile.cpp",
        "android/graphics/AnimatedImageDrawable.cpp",
        "android/graphics/Bitmap.cpp",
        "android/graphics/BitmapFactory.cpp",
        "android/graphics/BitmapFactoryEx.cpp",
        "android/graphics/ByteBufferStreamAdaptor.cpp",
        "android/graphics/Camera.cpp",
        "android/graphics/CanvasProperty.cpp",
        "android/graphics/ColorFilter.cpp",
        "android/graphics/FontFamily.cpp",
        "android/graphics/FontUtils.cpp",
        "android/graphics/CreateJavaOutputStreamAdaptor.cpp",
        "android/graphics/GIFMovie.cpp",
        "android/graphics/GraphicBuffer.cpp",
        "android/graphics/Graphics.cpp",
        "android/graphics/ImageDecoder.cpp",
        "android/graphics/Interpolator.cpp",
        "android/graphics/MaskFilter.cpp",
        "android/graphics/Matrix.cpp",
        "android/graphics/Movie.cpp",
        "android/graphics/MovieImpl.cpp",
        "android/graphics/NinePatch.cpp",
        "android/graphics/NinePatchPeeker.cpp",
        "android/graphics/Paint.cpp",
        "android/graphics/PaintFilter.cpp",
        "android/graphics/Path.cpp",
        "android/graphics/PathMeasure.cpp",
        "android/graphics/PathEffect.cpp",
        "android/graphics/Picture.cpp",
        "android/graphics/BitmapRegionDecoder.cpp",
        "android/graphics/Region.cpp",
        "android/graphics/Shader.cpp",
        "android/graphics/SkDrmStream.cpp",
        "android/graphics/SurfaceTexture.cpp",
        "android/graphics/Typeface.cpp",
        "android/graphics/Utils.cpp",
        "android/graphics/YuvToJpegEncoder.cpp",
        "android/graphics/fonts/Font.cpp",
        "android/graphics/fonts/FontFamily.cpp",
        "android/graphics/pdf/PdfDocument.cpp",
        "android/graphics/pdf/PdfEditor.cpp",
        "android/graphics/pdf/PdfRenderer.cpp",
        "android/graphics/pdf/PdfUtils.cpp",
        "android/graphics/text/LineBreaker.cpp",
        "android/graphics/text/MeasuredText.cpp",
        "android\_media\_AudioEffectDescriptor.cpp",
        "android\_media\_AudioRecord.cpp",
        "android\_media\_AudioSystem.cpp",
        "android\_media\_AudioTrack.cpp",
        "android\_media\_AudioAttributes.cpp",
        "android\_media\_AudioProductStrategies.cpp",
        "android\_media\_AudioVolumeGroups.cpp",
        "android\_media\_AudioVolumeGroupCallback.cpp",
        "android\_media\_DeviceCallback.cpp",
        "android\_media\_JetPlayer.cpp",
        "android\_media\_MediaMetricsJNI.cpp",
        "android\_media\_MicrophoneInfo.cpp",
        "android\_media\_midi.cpp",
        "android\_media\_RemoteDisplay.cpp",
        "android\_media\_ToneGenerator.cpp",
        "android\_hardware\_Camera.cpp",
        "android\_hardware\_camera2\_CameraMetadata.cpp",
        "android\_hardware\_camera2\_legacy\_LegacyCameraDevice.cpp",
        "android\_hardware\_camera2\_legacy\_PerfMeasurement.cpp",
        "android\_hardware\_camera2\_DngCreator.cpp",
        "android\_hardware\_display\_DisplayViewport.cpp",
        "android\_hardware\_HardwareBuffer.cpp",
        "android\_hardware\_SensorManager.cpp",
        "android\_hardware\_SerialPort.cpp",
        "android\_hardware\_SoundTrigger.cpp",
        "android\_hardware\_UsbDevice.cpp",
        "android\_hardware\_UsbDeviceConnection.cpp",
        "android\_hardware\_UsbRequest.cpp",
        "android\_hardware\_location\_ActivityRecognitionHardware.cpp",
        "android\_util\_FileObserver.cpp",
        "android/opengl/poly\_clip.cpp", // TODO: .arm
        "android/opengl/util.cpp",
        "android\_server\_NetworkManagementSocketTagger.cpp",
        "android\_ddm\_DdmHandleNativeHeap.cpp",
        "android\_backup\_BackupDataInput.cpp",
        "android\_backup\_BackupDataOutput.cpp",
        "android\_backup\_FileBackupHelperBase.cpp",
        "android\_backup\_BackupHelperDispatcher.cpp",
        "android\_app\_backup\_FullBackup.cpp",
        "android\_content\_res\_ApkAssets.cpp",
        "android\_content\_res\_ObbScanner.cpp",
        "android\_content\_res\_Configuration.cpp",
        "android\_animation\_PropertyValuesHolder.cpp",
        "android\_security\_Scrypt.cpp",
        "com\_android\_internal\_os\_AtomicDirectory.cpp",
        "com\_android\_internal\_os\_ClassLoaderFactory.cpp",
        "com\_android\_internal\_os\_FuseAppLoop.cpp",
        "com\_android\_internal\_os\_Zygote.cpp",
        "com\_android\_internal\_os\_ZygoteInit.cpp",
        "com\_android\_internal\_util\_VirtualRefBasePtr.cpp",
        "com\_android\_internal\_view\_animation\_NativeInterpolatorFactoryHelper.cpp",
        "hwbinder/EphemeralStorage.cpp",
        "fd\_utils.cpp",
        "android\_hardware\_input\_InputWindowHandle.cpp",
        "android\_hardware\_input\_InputApplicationHandle.cpp",
    +    "android\_mdm\_SystemUtils.cpp",
    ],

```

通过吧新增的cpp类添加到Android.bp中，让新增的cpp类参与到系统的编译中，在调用jni方法的时候  
 可以很方便的找到接口调用


3.5 我们修改的代码位于libandroid\_runtime.so和framework.jar，接下来到android 源码根目录下，执行 make  
 libandroid\_runtime 和 make framework 进行重新编译。将得到的libandroid\_runtime.so  
 和framework.jar push到对应目录，重启验证； 调用SystemUtils.java中的方法验证





