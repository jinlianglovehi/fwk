



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.开机过滤通知声音的核心代码](#2.%E5%BC%80%E6%9C%BA%E8%BF%87%E6%BB%A4%E9%80%9A%E7%9F%A5%E5%A3%B0%E9%9F%B3%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.开机过滤通知声音的核心代码分析和功能解决](#3.%E5%BC%80%E6%9C%BA%E8%BF%87%E6%BB%A4%E9%80%9A%E7%9F%A5%E5%A3%B0%E9%9F%B3%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E5%92%8C%E5%8A%9F%E8%83%BD%E8%A7%A3%E5%86%B3)


[3.1跟踪通知的具体流程](#3.1%E8%B7%9F%E8%B8%AA%E9%80%9A%E7%9F%A5%E7%9A%84%E5%85%B7%E4%BD%93%E6%B5%81%E7%A8%8B)


[3.2 NotificationManagerService核心代码](#3.2%20NotificationManagerService%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.3 buzzBeepBlinkLocked(NotificationRecord record)源码分析](#3.3%20buzzBeepBlinkLocked%28NotificationRecord%20record%29%E6%BA%90%E7%A0%81%E5%88%86%E6%9E%90)


[4.根据以上分析 开机过滤部分通知声音(屏蔽一些杂乱通知声音) 主要修改为:](#4.%E6%A0%B9%E6%8D%AE%E4%BB%A5%E4%B8%8A%E5%88%86%E6%9E%90%20%E5%BC%80%E6%9C%BA%E8%BF%87%E6%BB%A4%E9%83%A8%E5%88%86%E9%80%9A%E7%9F%A5%E5%A3%B0%E9%9F%B3%28%E5%B1%8F%E8%94%BD%E4%B8%80%E4%BA%9B%E6%9D%82%E4%B9%B1%E9%80%9A%E7%9F%A5%E5%A3%B0%E9%9F%B3%29%20%E4%B8%BB%E8%A6%81%E4%BF%AE%E6%94%B9%E4%B8%BA%3A)




---



## 1.概述


 在定制9.0和10.0的产品上，有时候在开机后会莫名其妙的会有一些通知的声音，感觉到很不爽，客户觉得影响产品体验，所以要求去掉这些杂乱的通知声音，所以要做的就是寻找这些声音是哪里发出来的，去掉就好了


## 2.开机过滤通知声音的核心代码



```
核心代码如下:
frameworks/base/core/java/android/app/NotificationManager.java
frameworks/base/services/java/com/android/server/NotificationManagerService.java

```

## 3.开机过滤通知声音的核心代码分析和功能解决


#### 3.1跟踪通知的具体流程


NotificationManager负责管理发送通知


在Notification构造完成后，会调用NotificationManager的notify方法来发送通知，我们就来看看该方法



```
frameworks/base/core/java/android/app/NotificationManager.java
public void notify(String tag, int id, Notification notification)
{
...
INotificationManager service = getService();
...
service.enqueueNotificationWithTag(pkg, mContext.getOpPackageName(), tag, id,
stripped, idOut, UserHandle.myUserId());
...
}
可以看出NotificationManager没有做什么实际上的事情，只是把notify的动作交给了service来做。
直接调用enqueueNotificationWithTag的实现在NotificationManagerService中
```

#### 3.2 NotificationManagerService核心代码



```
frameworks/base/services/java/com/android/server/NotificationManagerService.java
public void enqueueNotificationWithTag(String pkg, String opPkg, String tag, int id,
Notification notification, int[] idOut, int userId) throws RemoteException {
enqueueNotificationInternal(pkg, opPkg, Binder.getCallingUid(),
Binder.getCallingPid(), tag, id, notification, idOut, userId);
}
void enqueueNotificationInternal(final String pkg, final String opPkg, final int callingUid,
final int callingPid, final String tag, final int id, final Notification notification,
int incomingUserId) {
if (DBG) {
Slog.v(TAG, "enqueueNotificationInternal: pkg=" + pkg + " id=" + id
+ " notification=" + notification);
}
checkCallerIsSystemOrSameApp(pkg);
    final int userId = ActivityManager.handleIncomingUser(callingPid,
            callingUid, incomingUserId, true, false, "enqueueNotification", pkg);
    final UserHandle user = new UserHandle(userId);

    if (pkg == null || notification == null) {
        throw new IllegalArgumentException("null not allowed: pkg=" + pkg
                + " id=" + id + " notification=" + notification);
    }

    // The system can post notifications for any package, let us resolve that.
    final int notificationUid = resolveNotificationUid(opPkg, callingUid, userId);

    // Fix the notification as best we can.
    try {
        final ApplicationInfo ai = mPackageManagerClient.getApplicationInfoAsUser(
                pkg, PackageManager.MATCH_DEBUG_TRIAGED_MISSING,
                (userId == UserHandle.USER_ALL) ? USER_SYSTEM : userId);
        Notification.addFieldsFromContext(ai, notification);

        int canColorize = mPackageManagerClient.checkPermission(
                android.Manifest.permission.USE_COLORIZED_NOTIFICATIONS, pkg);
        if (canColorize == PERMISSION_GRANTED) {
            notification.flags |= Notification.FLAG_CAN_COLORIZE;
        } else {
            notification.flags &= ~Notification.FLAG_CAN_COLORIZE;
        }

    } catch (NameNotFoundException e) {
        Slog.e(TAG, "Cannot create a context for sending app", e);
        return;
    }

    mUsageStats.registerEnqueuedByApp(pkg);

    // setup local book-keeping
    String channelId = notification.getChannelId();
    if (mIsTelevision && (new Notification.TvExtender(notification)).getChannelId() != null) {
        channelId = (new Notification.TvExtender(notification)).getChannelId();
    }
    final NotificationChannel channel = mRankingHelper.getNotificationChannel(pkg,
            notificationUid, channelId, false /* includeDeleted */);
    if (channel == null) {
        final String noChannelStr = "No Channel found for "
                + "pkg=" + pkg
                + ", channelId=" + channelId
                + ", id=" + id
                + ", tag=" + tag
                + ", opPkg=" + opPkg
                + ", callingUid=" + callingUid
                + ", userId=" + userId
                + ", incomingUserId=" + incomingUserId
                + ", notificationUid=" + notificationUid
                + ", notification=" + notification;
        Log.e(TAG, noChannelStr);
        boolean appNotificationsOff = mRankingHelper.getImportance(pkg, notificationUid)
                == NotificationManager.IMPORTANCE_NONE;

        if (!appNotificationsOff) {
            doChannelWarningToast("Developer warning for package \"" + pkg + "\"\n" +
                    "Failed to post notification on channel \"" + channelId + "\"\n" +
                    "See log for more details");
        }
        return;
    }

    final StatusBarNotification n = new StatusBarNotification(
            pkg, opPkg, id, tag, notificationUid, callingPid, notification,
            user, null, System.currentTimeMillis());
    final NotificationRecord r = new NotificationRecord(getContext(), n, channel);
    r.setIsAppImportanceLocked(mRankingHelper.getIsAppImportanceLocked(pkg, callingUid));

    if ((notification.flags & Notification.FLAG_FOREGROUND_SERVICE) != 0) {
        final boolean fgServiceShown = channel.isFgServiceShown();
        if (((channel.getUserLockedFields() & NotificationChannel.USER_LOCKED_IMPORTANCE) == 0
                    || !fgServiceShown)
                && (r.getImportance() == IMPORTANCE_MIN
                        || r.getImportance() == IMPORTANCE_NONE)) {
            // Increase the importance of foreground service notifications unless the user had
            // an opinion otherwise (and the channel hasn't yet shown a fg service).
            if (TextUtils.isEmpty(channelId)
                    || NotificationChannel.DEFAULT_CHANNEL_ID.equals(channelId)) {
                r.setImportance(IMPORTANCE_LOW, "Bumped for foreground service");
            } else {
                channel.setImportance(IMPORTANCE_LOW);
                if (!fgServiceShown) {
                    channel.unlockFields(NotificationChannel.USER_LOCKED_IMPORTANCE);
                    channel.setFgServiceShown(true);
                }
                mRankingHelper.updateNotificationChannel(pkg, notificationUid, channel, false);
                r.updateNotificationChannel(channel);
            }
        } else if (!fgServiceShown && !TextUtils.isEmpty(channelId)
                && !NotificationChannel.DEFAULT_CHANNEL_ID.equals(channelId)) {
            channel.setFgServiceShown(true);
            r.updateNotificationChannel(channel);
        }
    }

    if (!checkDisqualifyingFeatures(userId, notificationUid, id, tag, r,
            r.sbn.getOverrideGroupKey() != null)) {
        return;
    }

    // Whitelist pending intents.
    if (notification.allPendingIntents != null) {
        final int intentCount = notification.allPendingIntents.size();
        if (intentCount > 0) {
            final ActivityManagerInternal am = LocalServices
                    .getService(ActivityManagerInternal.class);
            final long duration = LocalServices.getService(
                    DeviceIdleController.LocalService.class).getNotificationWhitelistDuration();
            for (int i = 0; i < intentCount; i++) {
                PendingIntent pendingIntent = notification.allPendingIntents.valueAt(i);
                if (pendingIntent != null) {
                    am.setPendingIntentWhitelistDuration(pendingIntent.getTarget(),
                            WHITELIST_TOKEN, duration);
                }
            }
        }
    }

    mHandler.post(new EnqueueNotificationRunnable(userId, r));
}

主要发送通知功能在 EnqueueNotificationRunnable中
protected class EnqueueNotificationRunnable implements Runnable {
private final NotificationRecord r;
private final int userId;
    EnqueueNotificationRunnable(int userId, NotificationRecord r) {
        this.userId = userId;
        this.r = r;
    };

    @Override
    public void run() {
        synchronized (mNotificationLock) {
            mEnqueuedNotifications.add(r);
            scheduleTimeoutLocked(r);

            final StatusBarNotification n = r.sbn;
            if (DBG) Slog.d(TAG, "EnqueueNotificationRunnable.run for: " + n.getKey());
            NotificationRecord old = mNotificationsByKey.get(n.getKey());
            if (old != null) {
                // Retain ranking information from previous record
                r.copyRankingInformation(old);
            }

            final int callingUid = n.getUid();
            final int callingPid = n.getInitialPid();
            final Notification notification = n.getNotification();
            final String pkg = n.getPackageName();
            final int id = n.getId();
            final String tag = n.getTag();

            // Handle grouped notifications and bail out early if we
            // can to avoid extracting signals.
            handleGroupedNotificationLocked(r, old, callingUid, callingPid);

            // if this is a group child, unsnooze parent summary
            if (n.isGroup() && notification.isGroupChild()) {
                mSnoozeHelper.repostGroupSummary(pkg, r.getUserId(), n.getGroupKey());
            }

            // This conditional is a dirty hack to limit the logging done on
            //     behalf of the download manager without affecting other apps.
            if (!pkg.equals("com.android.providers.downloads")
                    || Log.isLoggable("DownloadManager", Log.VERBOSE)) {
                int enqueueStatus = EVENTLOG_ENQUEUE_STATUS_NEW;
                if (old != null) {
                    enqueueStatus = EVENTLOG_ENQUEUE_STATUS_UPDATE;
                }
                EventLogTags.writeNotificationEnqueue(callingUid, callingPid,
                        pkg, id, tag, userId, notification.toString(),
                        enqueueStatus);
            }

            mRankingHelper.extractSignals(r);

            // tell the assistant service about the notification
            if (mAssistants.isEnabled()) {
                mAssistants.onNotificationEnqueued(r);
                mHandler.postDelayed(new PostNotificationRunnable(r.getKey()),
                        DELAY_FOR_ASSISTANT_TIME);
            } else {
                mHandler.post(new PostNotificationRunnable(r.getKey()));
            }
        }
    }
}

@GuardedBy("mNotificationLock")
private boolean isPackageSuspendedLocked(NotificationRecord r) {
    final String pkg = r.sbn.getPackageName();
    final int callingUid = r.sbn.getUid();

    return isPackageSuspendedForUser(pkg, callingUid);
}

protected class PostNotificationRunnable implements Runnable {
    private final String key;

    PostNotificationRunnable(String key) {
        this.key = key;
    }

    @Override
    public void run() {
        synchronized (mNotificationLock) {
            try {
                NotificationRecord r = null;
                int N = mEnqueuedNotifications.size();
                for (int i = 0; i < N; i++) {
                    final NotificationRecord enqueued = mEnqueuedNotifications.get(i);
                    if (Objects.equals(key, enqueued.getKey())) {
                        r = enqueued;
                        break;
                    }
                }
                if (r == null) {
                    Slog.i(TAG, "Cannot find enqueued record for key: " + key);
                    return;
                }

                r.setHidden(isPackageSuspendedLocked(r));
                NotificationRecord old = mNotificationsByKey.get(key);
                final StatusBarNotification n = r.sbn;
                final Notification notification = n.getNotification();
                int index = indexOfNotificationLocked(n.getKey());
                if (index < 0) {
                    mNotificationList.add(r);
                    mUsageStats.registerPostedByApp(r);
                    r.setInterruptive(isVisuallyInterruptive(null, r));
                } else {
                    old = mNotificationList.get(index);
                    mNotificationList.set(index, r);
                    mUsageStats.registerUpdatedByApp(r, old);
                    // Make sure we don't lose the foreground service state.
                    notification.flags |=
                            old.getNotification().flags & FLAG_FOREGROUND_SERVICE;
                    r.isUpdate = true;
                    r.setTextChanged(isVisuallyInterruptive(old, r));
                }

                mNotificationsByKey.put(n.getKey(), r);

                // Ensure if this is a foreground service that the proper additional
                // flags are set.
                if ((notification.flags & FLAG_FOREGROUND_SERVICE) != 0) {
                    notification.flags |= Notification.FLAG_ONGOING_EVENT
                            | Notification.FLAG_NO_CLEAR;
                }

                applyZenModeLocked(r);
                mRankingHelper.sort(mNotificationList);

                if (notification.getSmallIcon() != null) {
                    StatusBarNotification oldSbn = (old != null) ? old.sbn : null;
                    mListeners.notifyPostedLocked(r, old);
                    if (oldSbn == null || !Objects.equals(oldSbn.getGroup(), n.getGroup())) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                mGroupHelper.onNotificationPosted(
                                        n, hasAutoGroupSummaryLocked(n));
                            }
                        });
                    }
                } else {
                    Slog.e(TAG, "Not posting notification without small icon: " + notification);
                    if (old != null && !old.isCanceled) {
                        mListeners.notifyRemovedLocked(r,
                                NotificationListenerService.REASON_ERROR, null);
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                mGroupHelper.onNotificationRemoved(n);
                            }
                        });
                    }
                    // ATTENTION: in a future release we will bail out here
                    // so that we do not play sounds, show lights, etc. for invalid
                    // notifications
                    Slog.e(TAG, "WARNING: In a future release this will crash the app: "
                            + n.getPackageName());
                }

                if (!r.isHidden()) {
                    buzzBeepBlinkLocked(r);
                }
                maybeRecordInterruptionLocked(r);
            } finally {
                int N = mEnqueuedNotifications.size();
                for (int i = 0; i < N; i++) {
                    final NotificationRecord enqueued = mEnqueuedNotifications.get(i);
                    if (Objects.equals(key, enqueued.getKey())) {
                        mEnqueuedNotifications.remove(i);
                        break;
                    }
                }
            }
        }
    }
}

buzzBeepBlinkLocked(r);//声音，震动，闪光灯的控制

```

#### 3.3 buzzBeepBlinkLocked(NotificationRecord record)源码分析



```
void buzzBeepBlinkLocked(NotificationRecord record) {
boolean buzz = false;
boolean beep = false;
boolean blink = false;
    final Notification notification = record.sbn.getNotification();
    final String key = record.getKey();

    // Should this notification make noise, vibe, or use the LED?
    final boolean aboveThreshold =
            record.getImportance() >= NotificationManager.IMPORTANCE_DEFAULT;

    // Remember if this notification already owns the notification channels.
    boolean wasBeep = key != null && key.equals(mSoundNotificationKey);
    boolean wasBuzz = key != null && key.equals(mVibrateNotificationKey);
    // These are set inside the conditional if the notification is allowed to make noise.
    boolean hasValidVibrate = false;
    boolean hasValidSound = false;
    boolean sentAccessibilityEvent = false;
    // If the notification will appear in the status bar, it should send an accessibility
    // event
    if (!record.isUpdate && record.getImportance() > IMPORTANCE_MIN) {
        sendAccessibilityEvent(notification, record.sbn.getPackageName());
        sentAccessibilityEvent = true;
    }

    if (aboveThreshold && isNotificationForCurrentUser(record)) {

        if (mSystemReady && mAudioManager != null) {
            Uri soundUri = record.getSound();
            hasValidSound = soundUri != null && !Uri.EMPTY.equals(soundUri);
            long[] vibration = record.getVibration();
            // Demote sound to vibration if vibration missing & phone in vibration mode.
            if (vibration == null
                    && hasValidSound
                    && (mAudioManager.getRingerModeInternal()
                    == AudioManager.RINGER_MODE_VIBRATE)
                    && mAudioManager.getStreamVolume(
                    AudioAttributes.toLegacyStreamType(record.getAudioAttributes())) == 0) {
                vibration = mFallbackVibrationPattern;
            }
            hasValidVibrate = vibration != null;

            boolean hasAudibleAlert = hasValidSound || hasValidVibrate;
            if (hasAudibleAlert && !shouldMuteNotificationLocked(record)) {
                if (!sentAccessibilityEvent) {
                    sendAccessibilityEvent(notification, record.sbn.getPackageName());
                    sentAccessibilityEvent = true;
                }
                if (DBG) Slog.v(TAG, "Interrupting!");
                if (hasValidSound) {
                    mSoundNotificationKey = key;
                    if (mInCall) {
                        playInCallNotification();
                        beep = true;
                    } else {
                        beep = playSound(record, soundUri);
                    }
                }

                final boolean ringerModeSilent =
                        mAudioManager.getRingerModeInternal()
                                == AudioManager.RINGER_MODE_SILENT;
                if (!mInCall && hasValidVibrate && !ringerModeSilent) {
                    mVibrateNotificationKey = key;

                    buzz = playVibration(record, vibration, hasValidSound);
                }
            }
        }
    }
    // If a notification is updated to remove the actively playing sound or vibrate,
    // cancel that feedback now
    if (wasBeep && !hasValidSound) {
        clearSoundLocked();
    }
    if (wasBuzz && !hasValidVibrate) {
        clearVibrateLocked();
    }

    // light
    // release the light
    boolean wasShowLights = mLights.remove(key);
    if (record.getLight() != null && aboveThreshold
            && ((record.getSuppressedVisualEffects() & SUPPRESSED_EFFECT_LIGHTS) == 0)) {
        mLights.add(key);
        updateLightsLocked();
        if (mUseAttentionLight) {
            mAttentionLight.pulse();
        }
        blink = true;
    } else if (wasShowLights) {
        updateLightsLocked();
    }
    if (buzz || beep || blink) {
        record.setInterruptive(true);
        MetricsLogger.action(record.getLogMaker()
                .setCategory(MetricsEvent.NOTIFICATION_ALERT)
                .setType(MetricsEvent.TYPE_OPEN)
                .setSubtype((buzz ? 1 : 0) | (beep ? 2 : 0) | (blink ? 4 : 0)));
        EventLogTags.writeNotificationAlert(key, buzz ? 1 : 0, beep ? 1 : 0, blink ? 1 : 0);
    }
}

源码中重点播放通知声音的部分
if (hasValidSound) {
mSoundNotificationKey = key;
if (mInCall) {
playInCallNotification();
beep = true;
} else {
// 根据soundUri 的路径来播放通知声音
if(soundUri!=null && !soundUri.getPath().equal("通知声音对应路径")){
beep = playSound(record, soundUri);
}
}
}
```

## 4.根据以上分析 开机过滤部分通知声音(屏蔽一些杂乱通知声音) 主要修改为:



```
void buzzBeepBlinkLocked(NotificationRecord record) {
boolean buzz = false;
boolean beep = false;
boolean blink = false;
    final Notification notification = record.sbn.getNotification();
    final String key = record.getKey();

    // Should this notification make noise, vibe, or use the LED?
    final boolean aboveThreshold =
            record.getImportance() >= NotificationManager.IMPORTANCE_DEFAULT;

    // Remember if this notification already owns the notification channels.
    boolean wasBeep = key != null && key.equals(mSoundNotificationKey);
    boolean wasBuzz = key != null && key.equals(mVibrateNotificationKey);
    // These are set inside the conditional if the notification is allowed to make noise.
    boolean hasValidVibrate = false;
    boolean hasValidSound = false;
    boolean sentAccessibilityEvent = false;
    // If the notification will appear in the status bar, it should send an accessibility
    // event
    if (!record.isUpdate && record.getImportance() > IMPORTANCE_MIN) {
        sendAccessibilityEvent(notification, record.sbn.getPackageName());
        sentAccessibilityEvent = true;
    }

    if (aboveThreshold && isNotificationForCurrentUser(record)) {

        if (mSystemReady && mAudioManager != null) {
            Uri soundUri = record.getSound();
            hasValidSound = soundUri != null && !Uri.EMPTY.equals(soundUri);
            long[] vibration = record.getVibration();
            // Demote sound to vibration if vibration missing & phone in vibration mode.
            if (vibration == null
                    && hasValidSound
                    && (mAudioManager.getRingerModeInternal()
                    == AudioManager.RINGER_MODE_VIBRATE)
                    && mAudioManager.getStreamVolume(
                    AudioAttributes.toLegacyStreamType(record.getAudioAttributes())) == 0) {
                vibration = mFallbackVibrationPattern;
            }
            hasValidVibrate = vibration != null;

            boolean hasAudibleAlert = hasValidSound || hasValidVibrate;
            if (hasAudibleAlert && !shouldMuteNotificationLocked(record)) {
                if (!sentAccessibilityEvent) {
                    sendAccessibilityEvent(notification, record.sbn.getPackageName());
                    sentAccessibilityEvent = true;
                }
                if (DBG) Slog.v(TAG, "Interrupting!");
                if (hasValidSound) {
                    mSoundNotificationKey = key;
                    if (mInCall) {
                        playInCallNotification();
                        beep = true;
                    } else {

                        //重点修改部分
                       - beep = playSound(record, soundUri);
                       // 根据soundUri 的路径来播放通知声音
+                       if(soundUri!=null && !soundUri.getPath().equal("通知声音对应路径"))                     +{
+                        beep = playSound(record, soundUri);
+}



                    }
                }

                final boolean ringerModeSilent =
                        mAudioManager.getRingerModeInternal()
                                == AudioManager.RINGER_MODE_SILENT;
                if (!mInCall && hasValidVibrate && !ringerModeSilent) {
                    mVibrateNotificationKey = key;

                    buzz = playVibration(record, vibration, hasValidSound);
                }
            }
        }
    }
    // If a notification is updated to remove the actively playing sound or vibrate,
    // cancel that feedback now
    if (wasBeep && !hasValidSound) {
        clearSoundLocked();
    }
    if (wasBuzz && !hasValidVibrate) {
        clearVibrateLocked();
    }

    // light
    // release the light
    boolean wasShowLights = mLights.remove(key);
    if (record.getLight() != null && aboveThreshold
            && ((record.getSuppressedVisualEffects() & SUPPRESSED_EFFECT_LIGHTS) == 0)) {
        mLights.add(key);
        updateLightsLocked();
        if (mUseAttentionLight) {
            mAttentionLight.pulse();
        }
        blink = true;
    } else if (wasShowLights) {
        updateLightsLocked();
    }
    if (buzz || beep || blink) {
        record.setInterruptive(true);
        MetricsLogger.action(record.getLogMaker()
                .setCategory(MetricsEvent.NOTIFICATION_ALERT)
                .setType(MetricsEvent.TYPE_OPEN)
                .setSubtype((buzz ? 1 : 0) | (beep ? 2 : 0) | (blink ? 4 : 0)));
        EventLogTags.writeNotificationAlert(key, buzz ? 1 : 0, beep ? 1 : 0, blink ? 1 : 0);
    }
}
```



