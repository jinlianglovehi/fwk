



##  1.概述


在10.0的定制化开发中，需要对关机对话框的UI界面进行定制化开发，需要对话框全屏，去掉多余项保留关机 重启 飞行模式 静音模式等选项  
 现在开始定制化二的开发 实现关机 重启 飞行模式 静音模式居中显示 增加飞行模式 和 静音模式的ui布局


## 2.关机对话框UI定制开发(二）功能开发核心步骤


*Android*开机的流程,今天简单看下*关机*的流程。 在长按power键时系统会弹出*对话框*,让用户选择关机, 重启或者其他模式,关机就从这里开始。 长按Power键调用shutdown()方法


在长按电源开关后会出现一个对话框：静音模式，数据网络模式(数据流开关)，飞行模式，关机


等关键对话框，显示在右边居中的位置，在这个页面中，由于利用Android studio的开发工具等


查询布局的相关java的源码的就是在SystemUI的GlobalActionsDialog.java，在初始化的时候，


首先创建GlobalActions， 然后在showDialog出来，主要的功能实在showDialog中完成的，


关机对话框就是GlobalActionsDialog.java  
 路径:frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java



```
private int getGlobalActionsLayoutId(Context context) {
            int rotation = RotationUtils.getRotation(context);
            boolean useGridLayout = isForceGridEnabled(context)
                    || (shouldUsePanel() && rotation == RotationUtils.ROTATION_NONE);
            if (rotation == RotationUtils.ROTATION_SEASCAPE) {
                if (useGridLayout) {
                    return com.android.systemui.R.layout.global_actions_grid_seascape;
                } else {
                    return com.android.systemui.R.layout.global_actions_column_seascape;
                }
            } else {
                if (useGridLayout) {
                    return com.android.systemui.R.layout.global_actions_grid;
                } else {
                    return com.android.systemui.R.layout.global_actions_column;
                }
            }
        }
```

在GlobalActionsDialog.java中可以看出通过getGlobalActionsLayoutId(Context context)获取Layout布局 而根据rotation和useGridLayout来具体判断使用哪个布局文件 最终发现global\_actions\_column.xml就是布局文件


接下来看下global\_actions\_column.xml 的布局文件  
 ui 布局修改如下:



```
<com.android.systemui.globalactions.GlobalActionsColumnLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@id/global_actions_view"
    android:layout_width="match_parent"
    android:layout_height="1080px"
    android:orientation="vertical"
    android:clipToPadding="false"
    android:theme="@style/qs_theme"
    android:gravity="center"
    android:clipChildren="false"
>
    <RelativeLayout
        android:layout_height="match_parent"
        android:layout_width="match_parent"
        android:gravity="center"
        android:padding="0dp"
        android:layout_marginTop="0dp"
        android:layout_marginBottom="0dp"
    >
		<RelativeLayout
            android:layout_height="wrap_content"
            android:layout_width="wrap_content"
			android:layout_centerInParent="true">
        <!-- Global actions is right-aligned to be physically near power button -->
        <LinearLayout
            android:id="@android:id/list"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:layout_alignParentTop="true"
            android:layout_centerHorizontal="true"
            android:translationZ="@dimen/global_actions_translate"
        />
    <RelativeLayout
        android:id="@+id/airphone_area"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@android:id/list"
		android:layout_marginTop="10dp"
		android:layout_marginLeft="15dp"
        android:layout_alignLeft="@android:id/list">
        <ImageView
		    android:id="@+id/airphone_img"
            android:layout_width="30dp"
            android:layout_height="30dp"
            android:scaleType="fitCenter"
            android:layout_centerHorizontal="true"
            android:layout_alignParentTop="true"
            android:background="@drawable/airphone"/>
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
			android:layout_below="@id/airphone_img"
            android:textColor="#ffffff"
            android:textSize="12sp"
            android:text="飞行模式"/>
    </RelativeLayout>
	    <RelativeLayout
        android:id="@+id/ring_area"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@android:id/list"
		android:layout_marginTop="10dp"
		android:layout_marginRight="15dp"
        android:layout_alignRight="@android:id/list">
        <ImageView
		    android:id="@+id/ring_img"
            android:layout_width="30dp"
            android:layout_height="30dp"
            android:scaleType="fitCenter"
            android:layout_centerHorizontal="true"
            android:layout_alignParentTop="true"
            android:background="@drawable/ring"/>
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
			android:layout_below="@id/ring_img"
            android:textColor="#ffffff"
            android:textSize="12sp"
            android:text="静音模式"/>
    </RelativeLayout>
       
		</RelativeLayout>
    </RelativeLayout>

</com.android.systemui.globalactions.GlobalActionsColumnLayout>


```

### 



### 


在上述的global\_actions\_column.xml 的布局文件中，经过上述的分析，所以可以在这里添加静音模式和飞行模式布局，在关机和重启的布局控件中，添加相关的布局控件


最终git记录：



```
--- a/frameworks/base/packages/SystemUI/res/layout-land/global_actions_column.xml
+++ b/frameworks/base/packages/SystemUI/res/layout-land/global_actions_column.xml
@@ -19,35 +19,83 @@
     xmlns:android="http://schemas.android.com/apk/res/android"
     android:id="@id/global_actions_view"
     android:layout_width="match_parent"
-    android:layout_height="match_parent"
+    android:layout_height="match_parent"
     android:orientation="horizontal"
     android:clipToPadding="false"
     android:theme="@style/qs_theme"
-    android:gravity="center_horizontal | top"
+    android:gravity="center"
     android:clipChildren="false"
 >
-    <LinearLayout
-        android:layout_height="wrap_content"
-        android:layout_width="wrap_content"
+    <RelativeLayout
+           android:id="@+id/main_area"
+        android:layout_height="match_parent"
+        android:layout_width="match_parent"
         android:padding="0dp"
-        android:orientation="horizontal"
         android:clipChildren="false"
         android:clipToPadding="false"
     >
         <!-- Grid of action items -->
+               <RelativeLayout
+            android:layout_height="wrap_content"
+            android:layout_width="wrap_content"
+                       android:layout_centerInParent="true">
         <LinearLayout
             android:id="@android:id/list"
             android:layout_width="wrap_content"
             android:layout_height="wrap_content"
             android:orientation="horizontal"
-            android:layout_marginTop="@dimen/global_actions_grid_side_margin"
+            android:layout_alignParentTop="true"
+            android:layout_centerHorizontal="true"
             android:translationZ="@dimen/global_actions_translate"
-            android:paddingLeft="@dimen/global_actions_grid_vertical_padding"
-            android:paddingRight="@dimen/global_actions_grid_vertical_padding"
-            android:paddingTop="@dimen/global_actions_grid_horizontal_padding"
-            android:paddingBottom="@dimen/global_actions_grid_horizontal_padding"
-            android:background="?android:attr/colorBackgroundFloating"
         />
+<RelativeLayout
+        android:id="@+id/airphone_area"
+        android:layout_width="wrap_content"
+        android:layout_height="wrap_content"
+        android:layout_below="@android:id/list"
+               android:layout_marginTop="10dp"
+               android:layout_marginLeft="15dp"
+        android:layout_alignLeft="@android:id/list">
+        <ImageView
+                   android:id="@+id/airphone_img"
+            android:layout_width="30dp"
+            android:layout_height="30dp"
+            android:scaleType="fitCenter"
+            android:layout_centerHorizontal="true"
+            android:layout_alignParentTop="true"
+            android:background="@drawable/airphone"/>
+        <TextView
+            android:layout_width="wrap_content"
+            android:layout_height="wrap_content"
+                       android:layout_below="@id/airphone_img"
+            android:textColor="#ffffff"
+            android:textSize="12sp"
+            android:text="飞行模式"/>
+    </RelativeLayout>
+           <RelativeLayout
+        android:id="@+id/ring_area"
+        android:layout_width="wrap_content"
+        android:layout_height="wrap_content"
+        android:layout_below="@android:id/list"
+               android:layout_marginTop="10dp"
+               android:layout_marginRight="15dp"
+        android:layout_alignRight="@android:id/list">
+        <ImageView
+                   android:id="@+id/ring_img"
+            android:layout_width="30dp"
+            android:layout_height="30dp"
+            android:scaleType="fitCenter"
+            android:layout_centerHorizontal="true"
+            android:layout_alignParentTop="true"
+            android:background="@drawable/ring"/>
+        <TextView
+            android:layout_width="wrap_content"
+            android:layout_height="wrap_content"
+                       android:layout_below="@id/ring_img"
+            android:textColor="#ffffff"
+            android:textSize="12sp"
+            android:text="静音模式"/>
+    </RelativeLayout>
         <!-- For separated items-->
         <LinearLayout
             android:id="@+id/separated_button"
@@ -60,9 +108,11 @@
             android:paddingTop="@dimen/global_actions_grid_horizontal_padding"
             android:paddingBottom="@dimen/global_actions_grid_horizontal_padding"
             android:orientation="horizontal"
+                       android:visibility="gone"
             android:background="?android:attr/colorBackgroundFloating"
             android:translationZ="@dimen/global_actions_translate"
         />
-    </LinearLayout>
+               </RelativeLayout>
+    </RelativeLayout>
 
 </com.android.systemui.globalactions.GlobalActionsColumnLayout>

```

### 


### 



### 2.2 去掉关机 和重启的 白色背景


在GlobalActionsDialog.java中的上述源码中，经过上述的源码分析得知，在



```
[initializeLayout](http://aospxref.com/android-10.0.0_r47/s?defs=initializeLayout&project=frameworks "initializeLayout")()中的
```


```
[setContentView](http://aospxref.com/android-10.0.0_r47/s?defs=setContentView&project=frameworks "setContentView")([getGlobalActionsLayoutId](http://aospxref.com/android-10.0.0_r47/s?defs=getGlobalActionsLayoutId&project=frameworks "getGlobalActionsLayoutId")([mContext](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java#mContext "mContext")));通过上述的分析得知，
```

在这里关机重启的列表中，核心的布局就是GlobalActionsLayout.java，


关机和重启的背景文件就是GlobalActionsLayout.java接下来看下GlobalActionsLayout.java的相关代码




```

路径:frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsLayout.java

    private void setBackgrounds() {
        int gridBackgroundColor = getResources().getColor(
                R.color.global_actions_grid_background, null);
        int separatedBackgroundColor = getResources().getColor(
                R.color.global_actions_separated_background, null);
        HardwareBgDrawable listBackground  = new HardwareBgDrawable(true, true, getContext());
        HardwareBgDrawable separatedBackground = new HardwareBgDrawable(true, true, getContext());
        listBackground.setTint(gridBackgroundColor);
        separatedBackground.setTint(separatedBackgroundColor);
        //getListView().setBackground(listBackground);
        getSeparatedView().setBackground(separatedBackground);
    }




```

发现getListView().setBackground(listBackground);就是设置白色背景


注释掉//getListView().setBackground(listBackground);就可以了


接下来在initializeLayout()中添加飞行模式和静音模式功能



```
private void initializeLayout() {
            setContentView(getGlobalActionsLayoutId(mContext));
            fixNavBarClipping();
            mGlobalActionsLayout = findViewById(com.android.systemui.R.id.global_actions_view);
            mGlobalActionsLayout.setOutsideTouchListener(view -> dismiss());
            ((View) mGlobalActionsLayout.getParent()).setOnClickListener(view -> dismiss());
            mGlobalActionsLayout.setListViewAccessibilityDelegate(new View.AccessibilityDelegate() {
                @Override
                public boolean dispatchPopulateAccessibilityEvent(
                        View host, AccessibilityEvent event) {
                    // Populate the title here, just as Activity does
                    event.getText().add(mContext.getString(R.string.global_actions));
                    return true;
                }
            });
            mGlobalActionsLayout.setRotationListener(this::onRotate);
            mGlobalActionsLayout.setAdapter(mAdapter);

             //add core start 
            //飞行模式功能
            RelativeLayout airphone_area = findViewById(com.android.systemui.R.id.airphone_area);
			airphone_area.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View view) {
					int mode = Settings.Global.getInt(mContext.getContentResolver(),Settings.System.AIRPLANE_MODE_ON,-1);
					if(mode == 0){
					     Settings.Global.putInt(mContext.getContentResolver(),Settings.System.AIRPLANE_MODE_ON,1);
					}else{
						 Settings.Global.putInt(mContext.getContentResolver(),Settings.System.AIRPLANE_MODE_ON,0);
					}
					Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
					intent.putExtra("state", mode==0?false:true);
					mContext.sendBroadcast(intent);
					dismiss();
				}
			});
            //静音模式功能
            RelativeLayout ring_area = findViewById(com.android.systemui.R.id.ring_area);
			ring_area.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View view) {
					AudioManager audioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
					int ringerMode = audioManager.getRingerMode();
					if(ringerMode==AudioManager.RINGER_MODE_SILENT){
						audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
					}else if(ringerMode==AudioManager.RINGER_MODE_NORMAL){
						audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
					}
					dismiss();
				}
			});

           //add code end 


            if (shouldUsePanel()) {
                initializePanel();
            }
            if (mBackgroundDrawable == null) {
                mBackgroundDrawable = new ScrimDrawable();
                mScrimAlpha = ScrimController.GRADIENT_SCRIM_ALPHA;
            }
            //getWindow().setBackgroundDrawable(mBackgroundDrawable);
        }

```



