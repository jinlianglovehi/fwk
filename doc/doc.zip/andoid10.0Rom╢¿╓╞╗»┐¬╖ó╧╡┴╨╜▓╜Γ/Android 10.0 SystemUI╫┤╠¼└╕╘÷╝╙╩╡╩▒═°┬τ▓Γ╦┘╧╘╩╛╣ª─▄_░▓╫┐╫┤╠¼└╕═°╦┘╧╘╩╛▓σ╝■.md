



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.SystemUI状态栏增加实时网络测速显示功能的核心代码](#2.SystemUI%E7%8A%B6%E6%80%81%E6%A0%8F%E5%A2%9E%E5%8A%A0%E5%AE%9E%E6%97%B6%E7%BD%91%E7%BB%9C%E6%B5%8B%E9%80%9F%E6%98%BE%E7%A4%BA%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.SystemUI状态栏增加实时网络测速显示功能的核心代码和功能分析](#3.SystemUI%E7%8A%B6%E6%80%81%E6%A0%8F%E5%A2%9E%E5%8A%A0%E5%AE%9E%E6%97%B6%E7%BD%91%E7%BB%9C%E6%B5%8B%E9%80%9F%E6%98%BE%E7%A4%BA%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%92%8C%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 SystemUI状态栏增加自定义实时网络检测布局文件](#%C2%A0%203.1%20SystemUI%E7%8A%B6%E6%80%81%E6%A0%8F%E5%A2%9E%E5%8A%A0%E8%87%AA%E5%AE%9A%E4%B9%89%E5%AE%9E%E6%97%B6%E7%BD%91%E7%BB%9C%E6%A3%80%E6%B5%8B%E5%B8%83%E5%B1%80%E6%96%87%E4%BB%B6)


[3.2 增加服务来定时更新网络测速](#3.2%20%E5%A2%9E%E5%8A%A0%E6%9C%8D%E5%8A%A1%E6%9D%A5%E5%AE%9A%E6%97%B6%E6%9B%B4%E6%96%B0%E7%BD%91%E7%BB%9C%E6%B5%8B%E9%80%9F)


[3.3 在状态栏添加实时网络测速布局](#3.3%20%E5%9C%A8%E7%8A%B6%E6%80%81%E6%A0%8F%E6%B7%BB%E5%8A%A0%E5%AE%9E%E6%97%B6%E7%BD%91%E7%BB%9C%E6%B5%8B%E9%80%9F%E5%B8%83%E5%B1%80)


[3.4 注册实时测速服务](#3.4%20%E6%B3%A8%E5%86%8C%E5%AE%9E%E6%97%B6%E6%B5%8B%E9%80%9F%E6%9C%8D%E5%8A%A1)




---


如图:


![](https://img-blog.csdnimg.cn/88b16bfdafc94df98f19c7c3eaa82246.png)



## 1.概述


  在产品开发中，由于客户提出要对网络实时监控网速，所以要求在状态栏增加功能 显示当前网速的功能，然后如果网络有问题，可以随时监控到，这就需要计算当前网速，然后在状态栏显示出来就可以了


## 2.SystemUI状态栏增加实时网络测速显示功能的核心代码



```
  frameworks/base/packages/SystemUI/res/layout/system_icons.xml
  frameworks/base/packages/SystemUI/AndroidManifest.xml
```

## 3.SystemUI状态栏增加实时网络测速显示功能的核心代码和功能分析


在系统启动的过程中，在SystemServer.java类中，在启动SystemUIService这个服务以后，这个SystemUIService服务会  
 调用SystemUI类的Start()方法;SystemUI类又是被BaseStatusBar类实现的；PhoneStatusBar类又继承了  
 BaseStatusBar类，重写了start()方法，因此实际调用的是PhoneStatusBar的start()方法来完成状态栏的启动。  
 StatusBar由三部分组成：  
   1、最左边的一部分显示运营商，时间，通知图标。  
   2、最右边的一部分显示系统图标，它由状态图标(例如 wifi ,bt)和电池图标组成。  
   3、中间还有一块区域。


在系统状态栏StatusBar.java中，super\_status\_bar，之后会走两个分支status\_bar\_container和status\_bar\_expanded，status\_bar\_container这个分支主要呈现的是状态栏界面，状态栏细分左边和右边，左边是通知栏，右边是系统功能的状态图标显示




###   3.1 SystemUI状态栏增加自定义实时网络检测布局文件



```
   package com.android.systemui.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.TrafficStats;
import android.os.Handler;
import android.provider.Settings;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;


public class NetRealShowView extends TextView {
    private String TAG = "NetRealShowView";
    private long mLastTotalRxBytes = 0;//上一次获取的总消耗流量
    private long mLastTimeStamp = 0;//记录上一次时间
    private String mNetSpeed ="";
    private Paint mNetPaint;
    private Rect mNetBound;
    private Context mContext;
    private NetShowChangeObserver mContentOb;//监控数据库，是否打开网速显示
    private NetworkConnectReceiver mNetConnectReceiver;
    private boolean mIsConn=false,mIsStart=false;//判断当前是否有网络连接

    public NetRealShowView(Context context) {
        super(context);
    }

    public NetRealShowView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setNetDisplayPaint(context);
    }

    public NetRealShowView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setNetDisplayPaint(context);
    }

    private void setNetDisplayPaint(Context context){
        mContext=context;
        mNetPaint =new Paint();
        mNetPaint.setAntiAlias(true);
        mNetPaint.setColor(this.getCurrentTextColor());
        mNetPaint.setTextSize(getTextSize());
        mNetBound = new Rect();
        netConnectInit();
    }
    private void netConnectInit() {
        if (mContentOb == null) {
            mContentOb = new NetShowChangeObserver();
            mContext.getContentResolver().registerContentObserver(Settings.Global.getUriFor("network_speed"), true, mContentOb);
        }
        if (mNetConnectReceiver == null) {
            mNetConnectReceiver = new NetworkConnectReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
            filter.addAction(NetSpeedService.SEND_ACTION);
            mContext.registerReceiver(mNetConnectReceiver, filter);
        }
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mNetPaint.getTextBounds(mNetSpeed, 0, mNetSpeed.length(), mNetBound);
        canvas.drawText(mNetSpeed, getWidth() - mNetBound.width()-10, getHeight() / 2 + mNetBound.height() / 2, mNetPaint);
    }

    class NetShowChangeObserver extends ContentObserver {

        public NetShowChangeObserver() {
            super(new Handler());
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            if(mIsConn){
                int state=Settings.Global.getInt(mContext.getContentResolver(), "network_speed",0);
                if(state==1){
                    startShowSpeed();//开始显示网速
                }else{
                    stopShowSpeed();//停止显示网速
                }
            }
        }
    }

    class NetworkConnectReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction())) {
                NetworkInfo info = intent
                        .getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
                if (info != null) {
                    if (NetworkInfo.State.CONNECTED == info.getState()) {
                        mIsConn = true;
                        boolean isOpen = Settings.Global.getInt(
                                context.getContentResolver(),
                                "network_speed", 0) == 1;
                        if (isOpen) {
                            if(!mIsStart){
                                mIsStart=true;
                                stopShowSpeed();
                                startShowSpeed();
                                mIsConn = true;
                            }
                        } else {
                            if(mIsStart){
                                mIsStart=false;
                                mIsConn = false;
                                stopShowSpeed();
                            }
                        }
                    } else {
                        mIsConn = false;
                        stopShowSpeed();
                    }
                }
            }
            if (intent.getAction().equals(NetSpeedService.SEND_ACTION)) {
                showNetSpeed();
            }
        }
    }

    private void startShowSpeed(){
        mLastTotalRxBytes = TrafficStats.getTotalRxBytes();
        mLastTimeStamp = System.currentTimeMillis();
        mContext.startService(new Intent(mContext, NetSpeedService.class));
        setVisibility(View.VISIBLE);
    }
    private void stopShowSpeed(){
        mContext.stopService(new Intent(mContext, NetSpeedService.class));
        setVisibility(View.GONE);
    }
    private void showNetSpeed() {
        long nowTotalRxBytes = TrafficStats.getTotalRxBytes();
        long nowTimeStamp = System.currentTimeMillis();
        //modify by wxc on 20180111
        long difTime=nowTimeStamp - mLastTimeStamp;
        if(difTime<=0){
            mNetSpeed ="0B/s";
        }else{
            String endTotal;
            long speedTotal=(nowTotalRxBytes- mLastTotalRxBytes)*1000/difTime;
            if(speedTotal==0)return;
            if(speedTotal<1000){
                mNetSpeed =speedTotal+"B/s";
            }else if(speedTotal<1000*1024){
                endTotal=String.valueOf(speedTotal % 1024);
                speedTotal=speedTotal/1024;
                if(endTotal.length()>1){
                    endTotal=endTotal.substring(0, 1);
                }
                mNetSpeed =speedTotal+"."+endTotal+"KB/s";
            }else{
                endTotal=String.valueOf(speedTotal% (1024*1024));
                speedTotal=speedTotal/1024/1024;
                if(endTotal.length()>1){
                    endTotal=endTotal.substring(0, 1);
                }
                mNetSpeed =speedTotal+"."+endTotal+"MB/s";
            }
            mLastTotalRxBytes = nowTotalRxBytes;
        }
        mLastTimeStamp = nowTimeStamp;
        invalidate();
    }
```

在上述的StatusBar.java状态栏模式中的上述方法中，在通过自定义检测网络的控制，


自定义TextView来显示当前网速，根据网络流量来计算当前网速，并且根据系统属性值来显示和隐藏网速值，通过在根据当前网络速度在状态栏中显示速率来实现功能


### **3.2 增加服务来定时更新网络测速**



```
 package com.android.systemui.util;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import java.util.Timer;
import java.util.TimerTask;

public class NetSpeedService extends Service {
    public static final String SEND_ACTION="SEND_ACTION";
    private Timer mGetSpeedTimer;
    @Override
    public void onCreate() {
        super.onCreate();
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
		stopSpeedTimer();
        startSpeedTimer();
        return START_STICKY;
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
 
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopSpeedTimer();
    }
    private void startSpeedTimer() {
        if(mGetSpeedTimer==null){
            mGetSpeedTimer = new Timer();
            TimerTask mTimerTask = new TimerTask() {
                @Override
                public void run() {
                    Intent sendIntent = new Intent(SEND_ACTION);
                    getApplicationContext().sendBroadcast(sendIntent);
                }
            };
            mGetSpeedTimer.scheduleAtFixedRate(mTimerTask,0,1000);
        }
    }
    
    private void stopSpeedTimer() {
        if (mGetSpeedTimer != null) {
            mGetSpeedTimer.cancel();
            mGetSpeedTimer = null;
        }
    }
}
```

### 


在上述的NetSpeedService.java中上述的方法中，通过增加提供开启网速的检测和停止开启网速的检测来实现功能，通过每秒不断计算当前网速来计算当前网络速度来实现功能


### 


### 3.3 在状态栏添加实时网络测速布局



```
 frameworks/base/packages/SystemUI/res/layout/system_icons.xml
   <?xml version="1.0" encoding="utf-8"?><!--
  ~ Copyright (C) 2014 The Android Open Source Project
  ~
  ~ Licensed under the Apache License, Version 2.0 (the "License");
  ~ you may not use this file except in compliance with the License.
  ~ You may obtain a copy of the License at
  ~
  ~      http://www.apache.org/licenses/LICENSE-2.0
  ~
  ~ Unless required by applicable law or agreed to in writing, software
  ~ distributed under the License is distributed on an "AS IS" BASIS,
  ~ WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  ~ See the License for the specific language governing permissions and
  ~ limitations under the License
  -->

<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
              xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:id="@+id/system_icons"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center_vertical">
    <com.android.systemui.util.NetRealShowView
             android:id="@+id/net_show_text"
             android:layout_width="50dp"
             android:layout_height="match_parent"
             android:textColor="#ffffff"
             android:textSize="12sp"/>
    <com.android.systemui.statusbar.phone.StatusIconContainer android:id="@+id/statusIcons"
        android:layout_width="0dp"
        android:layout_weight="1"
        android:layout_height="match_parent"
        android:paddingEnd="@dimen/signal_cluster_battery_padding"
        android:gravity="center_vertical"
        android:orientation="horizontal"/>
    <com.android.systemui.BatteryMeterView android:id="@+id/battery"
        android:layout_height="match_parent"
        android:layout_width="wrap_content"
        android:clipToPadding="false"
        android:clipChildren="false"
        systemui:textAppearance="@style/TextAppearance.StatusBar.Clock" />
</LinearLayout>
```

### 3.4 注册实时测速服务



```
  frameworks/base/packages/SystemUI/AndroidManifest.xml中增加服务
  --- a/frameworks/base/packages/SystemUI/AndroidManifest.xml
+++ b/frameworks/base/packages/SystemUI/AndroidManifest.xml
@@ -273,7 +273,9 @@
         <service android:name="SystemUIService"
             android:exported="true"
         />
-
+        <service android:name="com.android.systemui.util.NetSpeedService"
+            android:exported="true"
+        />
         <!-- On user switch, this service is started to ensure that the associated SystemUI
              process for the current user is started. See the resource
              "config_systemUIServiceComponentsPerUser".
```

通过上述自定义view和自定义服务来计算当前网络速度，然后在状态栏中的布局中，添加


控件，然后通过开启和关闭网络检测功能，就可以做到时刻检测网速的功能



