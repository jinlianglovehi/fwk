






在app开发中 会需要发送通知，但在8.0以后增加了通知权限，必须先开启通知权限才能发送通知  
 像这样申请开启通知权限 打开通知开关


app中开启通知权限如下  
 1.判断是否有通知权限



```
@SuppressLint("NewApi")
public static boolean isNotificationEnabled(Context context) {

    AppOpsManager mAppOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
    ApplicationInfo appInfo = context.getApplicationInfo();
    String pkg = context.getApplicationContext().getPackageName();
    int uid = appInfo.uid;

    Class opsClass = null;

    try {
        opsClass = Class.forName(AppOpsManager.class.getName());
        Method checkOpNoThrowMethod = opsClass.getMethod(CHECK_OP_NO_THROW, Integer.TYPE, Integer.TYPE,
                String.class);
        Field opNotificationValue = opsClass.getDeclaredField(OP_POST_NOTIFICATION);
        int value = (Integer) opNotificationValue.get(Integer.class);
        return ((Integer) checkOpNoThrowMethod.invoke(mAppOps, value, uid, pkg) == AppOpsManager.MODE_ALLOWED);
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    } catch (NoSuchMethodException e) {
        e.printStackTrace();
    } catch (NoSuchFieldException e) {
        e.printStackTrace();
    } catch (InvocationTargetException e) {
        e.printStackTrace();
    } catch (IllegalAccessException e) {
        e.printStackTrace();
    }
    return false;
}

```

2. 在onCreate()中判断 然后开启权限



```
private void getNotification(){
 if (NotificationsUtils.isNotificationEnabled(this)){
 AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this)
 .setCancelable(true)
 .setTitle(“检测到通知权限未开启!”)
 .setMessage(“是否开启通知权限”)
 .setNegativeButton(“取消”, new DialogInterface.OnClickListener() {
 @Override
 public void onClick(DialogInterface dialog, int which) {
 dialog.cancel();
 }
 })
 .setPositiveButton(“去开启”, new DialogInterface.OnClickListener() {
 @Override
 public void onClick(DialogInterface dialog, int which) {
 dialog.cancel();
 Intent intent = new Intent();
 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
 intent.setAction(“android.settings.APP_NOTIFICATION_SETTINGS”);
 intent.putExtra(“android.provider.extra.APP_PACKAGE”, MainActivity.this.getPackageName());
 } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { //5.0
 intent.setAction(“android.settings.APP_NOTIFICATION_SETTINGS”);
 intent.putExtra(“app_package”, MainActivity.this.getPackageName());
 intent.putExtra(“app_uid”, MainActivity.this.getApplicationInfo().uid);
 startActivity(intent);
 } else if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) { //4.4
 intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
 intent.addCategory(Intent.CATEGORY_DEFAULT);
 intent.setData(Uri.parse(“package:” + MainActivity.this.getPackageName()));
 } else if (Build.VERSION.SDK_INT >= 15) {
 intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
 intent.setAction(“android.settings.APPLICATION_DETAILS_SETTINGS”);
 intent.setData(Uri.fromParts(“package”, MainActivity.this.getPackageName(), null));
 }
 startActivity(intent);
 }
 });
 builder.create().show()；
 }
 }

```

但是这样显得有点麻烦，所以在系统中默认开启通知 就要先查看怎么判断是否有通知权限


接下来我们看下系统通知管理类的相关源码  
 路径:frameworks/base/services/java/com/android/server/nitification/NotificationManagerService.java


从源码中 可以看到是从config\_defaultListenerAccessPackages 中获取app包名来  
 给app授予通知权限  
 protected static final String ENABLED\_SERVICES\_SEPARATOR = “:”;  
 ：分开包名


framework/base/core/res/res/values/config.xml



```
<!-- Colon separated list of package names that should be granted Notification Listener access -->  
 <string name="config\_defaultListenerAccessPackages" translatable="false"></string>

```

所以就添加包名即可 以：分割开包名





