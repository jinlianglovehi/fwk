



## 1.前言


在10.0的系统产品定制化开发中，在原生系统Settings的主菜单蓝牙 wifi进入二级菜单中的页面中，最上面都有一个ActionBar的返回键，在 某种情况下进行产品定制的时候，不需要这个返回键，所以接下来分析下这个返回键布局，来实现功能


## 2.系统Settings主菜单蓝牙wifi二级菜单去掉返回acitonbar功能的核心类



```
packages/apps/Settings/src/com/android/settings/wifi/WifiSettings2.java
packages/apps/Settings/src/com/android/settings/network/NetworkDashboardFragment.java
packages/apps/Settings/src/com/android/settings/connecteddevice/ConnectedDeviceDashboardFragment.java

```

## 3.系统Settings主菜单蓝牙wifi二级菜单去掉返回acitonbar功能的核心功能分析和实现


Action Bar也是一个非常重要的交互元素，Action Bar取代了传统的tittle bar和menu，在程序运行中一直置于顶部，对于Android平板设备来说屏幕 更大它的标题使用Action Bar来设计可以展示更多丰富的内容，方便操控。 ActionBar的功能 1.ActionBar的图标，可显示软件图标，也可用其他图标代替。当软件不在最高级页面时，图标左侧会显示一个左箭头，用户可以通过这个箭头向上导航； 2. 如果你的应用要在不同的View中显示数据，这部分允许用户来切换视图。一般的作法是用一个下拉菜单或者是Tab选项卡。如果只有一个界面，那这里可以显示应用程序的标题或者是更长一点的商标信息； 3.两个action按钮，这里放重要的按钮功能，为用户进行某项操作提供直接的访问； 4.overflow按钮，放不下的按钮会被置于“更多...”菜单项中，“更多...”菜单项是以下拉形式实现的。 Settings，包括手机各项属性的基本调整和功能的开关，是用户根据个人喜好对手机进行定制的最方便的入口，也是用户在日常生活中使用频率最高的模块之一。因此，它的稳定性、修改定制，对于开发者来说尤为重要。 在目前的移动设备中，Settings界面除过主题定制的颜色图标等差别外，存在两种形式：单页形式和分页形式。单页形式为主要形式，而在平板等大屏设备中，则会采用分页形式


## 3.1 WifiSettings2.java关于wifi去掉的actionbar返回键的核心功能分析


在实现系统Settings主菜单wifi二级菜单去掉返回acitonbar功能中，在关于wifi的核心页面就是在系统菜单主页面中发现，关于 wifi主菜单的核心类就是WifiSettings2.java中，接下来看下怎么样去掉这个返回actionbar功能



```
   @Override
      public void onActivityCreated(Bundle savedInstanceState) {
       final Context context = getContext();
        mWorkerThread = new HandlerThread(TAG +
                "{" + Integer.toHexString(System.identityHashCode(this)) + "}",
                Process.THREAD_PRIORITY_BACKGROUND);
        mWorkerThread.start();
        final Clock elapsedRealtimeClock = new SimpleClock(ZoneOffset.UTC) {
            @Override
            public long millis() {
                return SystemClock.elapsedRealtime();
            }
        };
        mWifiPickerTracker = new WifiPickerTracker(getSettingsLifecycle(), context,
                context.getSystemService(WifiManager.class),
                context.getSystemService(ConnectivityManager.class),
                context.getSystemService(NetworkScoreManager.class),
                new Handler(Looper.getMainLooper()),
                mWorkerThread.getThreadHandler(),
                elapsedRealtimeClock,
                MAX_SCAN_AGE_MILLIS,
                SCAN_INTERVAL_MILLIS,
                this);

        final Activity activity = getActivity();
  
          final Activity activity = getActivity();
  
          if (activity != null) {
              mWifiManager = getActivity().getSystemService(WifiManager.class);
+        if(activity instanceof PreferenceActivity)
+        {
+            activity.getActionBar().setDisplayHomeAsUpEnabled(false);
+            activity.getActionBar().setHomeButtonEnabled(false);
+        }
          }
  
    .....
      }
```

在实现系统Settings主菜单蓝牙wifi二级菜单去掉返回acitonbar功能中，在上述的分析中得知，在 WifiSettings2.java中的上述相关源码中分析得知，在onActivityCreated(Bundle savedInstanceState)这个构建wifi的相关菜单等相关 功能中，可以通过activity不为空的相关判断，来调用 activity.getActionBar().setDisplayHomeAsUpEnabled(false); 和activity.getActionBar().setHomeButtonEnabled(false);的相关代码，来设置actionbar的返回键来设置隐藏返回键功能， 来实现相关功能


## 3.2 ConnectedDeviceDashboardFragment.java.java关于蓝牙二级菜单去掉的actionbar返回键的核心功能分析


在实现系统Settings主菜单wifi二级菜单去掉返回acitonbar功能中，在关于蓝牙二级菜单的核心页面就是在系统菜单主页面中发现，关于 蓝牙二级菜单主菜单相关热点的核心类就是ConnectedDeviceDashboardFragment.java.java中，接下来看下怎么样去掉这个返回actionbar功能



```
//add core start
     @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final Activity activity = getActivity();
        android.util.Log.e("activity","activity33:"+activity);
        if(activity != null){
            activity.getActionBar().setDisplayHomeAsUpEnabled(false);
            activity.getActionBar().setHomeButtonEnabled(false);
           activity.getActionBar().setDisplayShowTitleEnabled(false);
        }
    }
//add core end
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        final boolean nearbyEnabled = DeviceConfig.getBoolean(DeviceConfig.NAMESPACE_SETTINGS_UI,
                SettingsUIDeviceConfig.BT_NEAR_BY_SUGGESTION_ENABLED, true);
        String callingAppPackageName = PasswordUtils.getCallingAppPackageName(
                getActivity().getActivityToken());
        String action = getIntent() != null ? getIntent().getAction() : "";
        if (DEBUG) {
            Log.d(TAG, "onAttach() calling package name is : " + callingAppPackageName
                    + ", action : " + action);
        }
        use(AvailableMediaDeviceGroupController.class).init(this);
        use(ConnectedDeviceGroupController.class).init(this);
        use(PreviouslyConnectedDevicePreferenceController.class).init(this);
        use(SlicePreferenceController.class).setSliceUri(nearbyEnabled
                ? Uri.parse(getString(R.string.config_nearby_devices_slice_uri))
                : null);
        use(DiscoverableFooterPreferenceController.class)
                .setAlwaysDiscoverable(isAlwaysDiscoverable(callingAppPackageName, action));
    }
```

在实现系统Settings主菜单蓝牙wifi二级菜单去掉返回acitonbar功能中，在上述的分析中得知，在 ConnectedDeviceDashboardFragment.java.java中的上述相关源码中分析得知，在新增onActivityCreated(Bundle savedInstanceState) 这个构建蓝牙二级菜单的相关菜单等相关 功能中，可以通过activity不为空的相关判断，来调用 activity.getActionBar().setDisplayHomeAsUpEnabled(false); 和activity.getActionBar().setHomeButtonEnabled(false);的相关代码，来设置actionbar的返回键来设置隐藏返回键功能， 来实现相关功能


## 3.3NetworkDashboardFragment.java关于网络二级菜单去掉的actionbar返回键的核心功能分析


在实现系统Settings主菜单蓝牙wifi二级菜单去掉返回acitonbar功能中，在关于网络二级菜单的核心页面就是在系统菜单主页面中发现，关于 网络二级菜单主菜单相关热点的核心类就是NetworkDashboardFragment.java中，接下来看下怎么样去掉这个返回actionbar功能



```
//add core start
     @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final Activity activity = getActivity();
        android.util.Log.e("activity","activity33:"+activity);
        if(activity != null){
            activity.getActionBar().setDisplayHomeAsUpEnabled(false);
            activity.getActionBar().setHomeButtonEnabled(false);
           activity.getActionBar().setDisplayShowTitleEnabled(false);
        }
    }
//add core end
   private static List<AbstractPreferenceController> buildPreferenceControllers(Context context,
            Lifecycle lifecycle, MetricsFeatureProvider metricsFeatureProvider, Fragment fragment,
            MobilePlanPreferenceHost mobilePlanHost) {
        final MobilePlanPreferenceController mobilePlanPreferenceController =
                new MobilePlanPreferenceController(context, mobilePlanHost);
        final WifiMasterSwitchPreferenceController wifiPreferenceController =
                new WifiMasterSwitchPreferenceController(context, metricsFeatureProvider);

        final VpnPreferenceController vpnPreferenceController =
                new VpnPreferenceController(context);
        final PrivateDnsPreferenceController privateDnsPreferenceController =
                new PrivateDnsPreferenceController(context);

        /// M: new controller for network data cotroller
        final NetworkDataControllerPreferenceController NetworkDataControllerPreferenceController =
                new NetworkDataControllerPreferenceController(context);

        if (lifecycle != null) {
            lifecycle.addObserver(mobilePlanPreferenceController);
            lifecycle.addObserver(wifiPreferenceController);
            lifecycle.addObserver(vpnPreferenceController);
            lifecycle.addObserver(privateDnsPreferenceController);
        }

        final List<AbstractPreferenceController> controllers = new ArrayList<>();

        controllers.add(new MobileNetworkSummaryController(context, lifecycle));
        controllers.add(new TetherPreferenceController(context, lifecycle));
        controllers.add(vpnPreferenceController);
        controllers.add(new ProxyPreferenceController(context));
        controllers.add(mobilePlanPreferenceController);
        controllers.add(wifiPreferenceController);
        controllers.add(privateDnsPreferenceController);
        /// M: add network data cotroller
        controllers.add(NetworkDataControllerPreferenceController);
        return controllers;
    }
```

在实现系统Settings主菜单蓝牙wifi二级菜单去掉返回acitonbar功能中，在上述的分析中得知，在 NetworkDashboardFragment.java中的上述相关源码中分析得知，在新增onActivityCreated(Bundle savedInstanceState) 这个构建网络二级菜单的相关菜单等相关 功能中，可以通过activity 不为空的相关判断，来调用 activity.getActionBar().setDisplayHomeAsUpEnabled(false); 和activity.getActionBar().setHomeButtonEnabled(false);的相关代码，来设置actionbar的返回键来设置隐藏返回键功能， 来实现相关功能



