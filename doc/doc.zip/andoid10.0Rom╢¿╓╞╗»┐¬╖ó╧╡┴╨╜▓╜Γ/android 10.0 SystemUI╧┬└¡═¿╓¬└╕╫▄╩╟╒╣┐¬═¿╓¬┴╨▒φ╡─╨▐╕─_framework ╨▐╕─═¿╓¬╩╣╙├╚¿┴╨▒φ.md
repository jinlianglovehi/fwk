






在定制SystemUI的下拉通知UI后，对整个下拉状态栏做了调整和修改，这就涉及到要全部展开  
 QSPanel 画面，但是展开以后就相当于第二次下拉状态栏的界面效果，这时系统会默认收缩  
 通知栏，不会全部展示通知栏，这个时候 就要实现一个功能 就是改收缩通知栏为展开通知栏  
 所以就要阅读NotificationPanelView.java的源码 来看怎么做到收缩通知栏的


路径：frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NotificationPanelView.java


在NotificationPanelView.java中，会对下拉QsPanel判断是否展开状态的判断的  
 首次下拉默认是不展开的 第二次下拉状态栏的时候 就会确定是展开的  
 private boolean mQsFullyExpanded; 就是用来判断QsPanel是否是展开的  
 当为true 时就代表现在已经是展开的状态了



```
private void setQsExpansion(float height) {
    height = Math.min(Math.max(height, mQsMinExpansionHeight), mQsMaxExpansionHeight);
    mQsFullyExpanded = height == mQsMaxExpansionHeight && mQsMaxExpansionHeight != 0;
    if (height > mQsMinExpansionHeight && !mQsExpanded && !mStackScrollerOverscrolling
            && !mDozing) {
        setQsExpanded(true);
    } else if (height <= mQsMinExpansionHeight && mQsExpanded) {
        setQsExpanded(false);
    }
    mQsExpansionHeight = height;
    updateQsExpansion();
    requestScrollerTopPaddingUpdate(false /* animate */);
    updateHeaderKeyguardAlpha();
    if (mBarState == StatusBarState.SHADE_LOCKED
            || mBarState == StatusBarState.KEYGUARD) {
        updateKeyguardBottomAreaAlpha();
        updateBigClockAlpha();
    }
    if (mBarState == StatusBarState.SHADE && mQsExpanded
            && !mStackScrollerOverscrolling && mQsScrimEnabled) {
        mQsNavbarScrim.setAlpha(getQsExpansionFraction());
    }

    if (mAccessibilityManager.isEnabled()) {
        setAccessibilityPaneTitle(determineAccessibilityPaneTitle());
    }

    if (!mFalsingManager.isUnlockingDisabled() && mQsFullyExpanded
            && mFalsingManager.shouldEnforceBouncer()) {
        mStatusBar.executeRunnableDismissingKeyguard(null, null /* cancelAction */,
                false /* dismissShade */, true /* afterKeyguardGone */, false /* deferred */);
    }
    for (int i = 0; i < mExpansionListeners.size(); i++) {
        mExpansionListeners.get(i).onQsExpansionChanged(mQsMaxExpansionHeight != 0
                ? mQsExpansionHeight / mQsMaxExpansionHeight : 0);
    }
    if (DEBUG) {
        invalidate();
    }
}

```

在手势滑动的时候 会判断 mQsFullyExpanded = height == mQsMaxExpansionHeight && mQsMaxExpansionHeight != 0; QSPanel的高度是最大高度后 就认为是展开的状态了


而在



```
@Override
protected void onTrackingStarted() {
    mFalsingManager.onTrackingStarted(mStatusBar.isKeyguardCurrentlySecure());
    super.onTrackingStarted();
    if (mQsFullyExpanded) {
        mQsExpandImmediate = true;
        mNotificationStackScroller.setShouldShowShelfOnly(true);
    }
    if (mBarState == StatusBarState.KEYGUARD
            || mBarState == StatusBarState.SHADE_LOCKED) {
        mAffordanceHelper.animateHideLeftRightIcon();
    }
    mNotificationStackScroller.onPanelTrackingStarted();
}

```

onTrackingStarted() 中会根据这个参数设置mNotificationStackScroller.setShouldShowShelfOnly(true);  
 就是通知栏是否收缩  
 setShouldShowShelfOnly 就是设置通知栏是否收缩的  
 所以具体修改如下：



```
@Override
    protected void onTrackingStarted() {
        mFalsingManager.onTrackingStarted(mStatusBar.isKeyguardCurrentlySecure());
        super.onTrackingStarted();
        if (mQsFullyExpanded) {
            mQsExpandImmediate = true;
           -  mNotificationStackScroller.setShouldShowShelfOnly(true);
           + mNotificationStackScroller.setShouldShowShelfOnly(false);
        }
        if (mBarState == StatusBarState.KEYGUARD
                || mBarState == StatusBarState.SHADE_LOCKED) {
            mAffordanceHelper.animateHideLeftRightIcon();
        }
        mNotificationStackScroller.onPanelTrackingStarted();
    }

```

就这样就可以了





