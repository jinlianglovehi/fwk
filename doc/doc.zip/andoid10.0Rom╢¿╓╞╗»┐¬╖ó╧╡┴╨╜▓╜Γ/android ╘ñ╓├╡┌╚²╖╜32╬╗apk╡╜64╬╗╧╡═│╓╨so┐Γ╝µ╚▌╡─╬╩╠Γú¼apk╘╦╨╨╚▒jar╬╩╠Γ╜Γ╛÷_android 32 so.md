






1.预置第三方apk到系统中Android.mk, 关于32/64位so库兼容的问题


在使用android 64位的系统时预置第三方apk，而apk中使用的so库为32位，预置到系统中当使用到相应的32位库时报错：java.lang.UnsatisfiedLinkError: dalvik.system.PathClassLoader[DexPathList[[zip file “/system/app/xxxxx/xxxxx.apk”],nativeLibraryDirectories=[/vendor/lib64, /system/lib64]]] couldn’t find “libxxxx.so”


解决方案：


Android.mk配置



```
LOCAL_PATH := $(call my-dir)

    include $(CLEAR\_VARS)

    LOCAL_MODULE := xxxx

    LOCAL_MODULE_TAGS := optional

    LOCAL_SRC_FILES := xxxx.apk

    LOCAL_MODULE_CLASS := APPS

    LOCAL_MODULE_SUFFIX := $(COMMON\_ANDROID\_PACKAGE\_SUFFIX)

    LOCAL_PREBUILT_JNI_LIBS:= \

    @lib/armeabi/xxxx_Jni.so

    LOCAL_CERTIFICATE := PRESIGNED

    LOCAL_MULTILIB :=32

    LOCAL_MODULE_PATH := $(TARGET\_OUT)/app

    LOCAL_SDK_VERSION := current
    LOCAL_DEX_PREOPT :=false
    LOCAL_PROGUARD_ENABLED:=disabled
   

    include $(BUILD\_PREBUILT)

```

2. 缺少jar的解决  
 2.Android.mk添加第三方apk的jar  
 在内置第三方apk时，点击运行会抛java.long.ClassNotFindException异常  
 如图:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/9c9345efb3904ef3a80168c66e779161.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_20,color_FFFFFF,t_70,g_se,x_16#pic_center)


那就需要把org.apache.http.legacy.boot.jar 拷贝到 apk同层目录下  
 如下图:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/0a9eb4924cc940dbb43c290467331277.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_14,color_FFFFFF,t_70,g_se,x_16#pic_center)


Android.mk的编写  
 LOCAL\_PATH:= $(call my-dir)  
 include $(CLEAR\_VARS)  
 LOCAL\_STATIC\_JAVA\_LIBRARIES := boot  
 LOCAL\_MODULE\_TAGS := optional  
 LOCAL\_SRC\_FILES := $(call all-subdir-java-files)  
 LOCAL\_PACKAGE\_NAME := test  
 LOCAL\_CERTIFICATE := platform  
 include $(BUILD\_PACKAGE)  
 include $(CLEAR\_VARS)  
 LOCAL\_PREBUILT\_STATIC\_JAVA\_LIBRARIES := boot:lib/org.apache.http.legacy.boot.jar  
 include $(BUILD\_MULTI\_PREBUILT)  
 include  
 
 
 
 
 ( 
 
 
 c 
 
 
 a 
 
 
 l 
 
 
 l 
 
 
 a 
 
 
 l 
 
 
 l 
 
 
 − 
 
 
 m 
 
 
 a 
 
 
 k 
 
 
 e 
 
 
 f 
 
 
 i 
 
 
 l 
 
 
 e 
 
 
 s 
 
 
 − 
 
 
 u 
 
 
 n 
 
 
 d 
 
 
 e 
 
 
 r 
 
 
 , 
 
 
 
 (call all-makefiles-under, 
 
 
 (callall−makefiles−under,(LOCAL\_PATH))


编译apk 这样就可以从jar包中,找到需要调用的class了





