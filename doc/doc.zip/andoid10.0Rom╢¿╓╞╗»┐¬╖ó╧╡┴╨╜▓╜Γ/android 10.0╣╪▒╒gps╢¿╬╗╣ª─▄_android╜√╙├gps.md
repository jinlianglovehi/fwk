






### 1.概述


在10.0的产品定制化开发中，有些是不需要gps定位功能的，所以就需要屏蔽掉gps上报定位数据的功能，而在framework层中是通过/frameworks/base/location/java/android/location/LocationProvider.java  
 来上报定位信息给app调用的


### 2.关闭gps定位功能的核心类



```
/frameworks/base/location/java/android/location/LocationProvider.java
/frameworks/base/services/core/jni/com_android_server_location_GnssLocationProvider.cpp

```

### 3.关闭gps定位功能的核心功能分析和实现


首选分析gps定位功能  
 Gps定位功能的实现如下：



```
// 判断GPS是否正常启动
        if (!mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // 返回开启GPS导航设置界面
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            context.startActivityForResult(intent, 0);
            return;
        }

// 为获取地理位置信息时设置查询条件
        String mBestProvider = mLocationManager.getBestProvider(getCriteria(), true);

private static Criteria getCriteria() {
        Criteria criteria = new Criteria();
        // 设置定位精确度 Criteria.ACCURACY_COARSE比较粗略，Criteria.ACCURACY_FINE则比较精细
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        // 设置是否要求速度
        criteria.setSpeedRequired(false);
        // 设置是否允许运营商收费
        criteria.setCostAllowed(false);
        // 设置是否需要方位信息
        criteria.setBearingRequired(false);
        // 设置是否需要海拔信息
        criteria.setAltitudeRequired(false);
        // 设置对电源的需求
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        return criteria;
   }

// 获取位置信息
        // 如果不设置查询要求，getLastKnownLocation方法传人的参数为LocationManager.GPS_PROVIDER
        Location location = mLocationManager.getLastKnownLocation(mBestProvider);


// 监听状态
        mLocationManager.addGpsStatusListener(listener);

// 状态监听
    GpsStatus.Listener listener = new GpsStatus.Listener() {
        public void onGpsStatusChanged(int event) {
            switch (event) {
                // 第一次定位
                case GpsStatus.GPS_EVENT_FIRST_FIX:
                    break;
                // 卫星状态改变
                case GpsStatus.GPS_EVENT_SATELLITE_STATUS:

                    GpsStatus gpsStatus = mLocationManager.getGpsStatus(null);
                    // 获取卫星颗数的默认最大值
                    int maxSatellites = gpsStatus.getMaxSatellites();
                    // 创建一个迭代器保存所有卫星
                    Iterator<GpsSatellite> iters = gpsStatus.getSatellites()
                            .iterator();
                    int count = 0;
                    while (iters.hasNext() && count <= maxSatellites) {
                        GpsSatellite s = iters.next();
                        count++;
                    }
                    System.out.println("搜索到：" + count + "颗卫星");
                    break;
                // 定位启动
                case GpsStatus.GPS_EVENT_STARTED:
                    Log.i(TAG, "定位启动");
                    break;
                // 定位结束
                case GpsStatus.GPS_EVENT_STOPPED:
                    Log.i(TAG, "定位结束");
                    break;
            }
        }
    };

```

在app中可以通过上述的方法来完成gps定位功能的实现，获取对应的定位数据


通过代码可以看出通过LocationManager调用LocationProvider来实现数据上报


LocationProvider.java定位相关的功能对应的jni代码为：  
 ./frameworks/base/services/core/jni/com\_android\_server\_location\_GnssLocationProvider.cpp  
 接下来看源码



```
1. gps jni callback
/*
 * GnssCallback class implements the callback methods for IGnss interface.
 */
struct GnssCallback : public IGnssCallback {
     // gps位置变化的回调
    Return<void> gnssLocationCb(const GnssLocation_V1_0& location) override;
   // gps状态变化的回调
    Return<void> gnssStatusCb(const IGnssCallback::GnssStatusValue status) override;
   // gps卫星状态变化的回调
    Return<void> gnssSvStatusCb(const IGnssCallback_V1_0::GnssSvStatus& svStatus) override {
        return gnssSvStatusCbImpl(svStatus);
    }
    Return<void> gnssNmeaCb(int64_t timestamp, const android::hardware::hidl_string& nmea) override;
    Return<void> gnssSetCapabilitesCb(uint32_t capabilities) override;
    Return<void> gnssAcquireWakelockCb() override;
    Return<void> gnssReleaseWakelockCb() override;
    Return<void> gnssRequestTimeCb() override;
    Return<void> gnssRequestLocationCb(const bool independentFromGnss) override;

    Return<void> gnssSetSystemInfoCb(const IGnssCallback::GnssSystemInfo& info) override;

    // New in 1.1
    Return<void> gnssNameCb(const android::hardware::hidl_string& name) override;

    // New in 2.0
    Return<void> gnssRequestLocationCb_2_0(const bool independentFromGnss, const bool isUserEmergency)
            override;
    Return<void> gnssSetCapabilitiesCb_2_0(uint32_t capabilities) override;
    Return<void> gnssLocationCb_2_0(const GnssLocation_V2_0& location) override;
    Return<void> gnssSvStatusCb_2_0(const hidl_vec<IGnssCallback::GnssSvInfo>& svInfoList) override {
        return gnssSvStatusCbImpl(svInfoList);
    }

    Return<void> gnssSetCapabilitesCbImpl(uint32_t capabilities, bool hasSubHalCapabilityFlags);

    // TODO: Reconsider allocation cost vs threadsafety on these statics
    static const char* sNmeaString;
    static size_t sNmeaStringLength;
private:
    template<class T>
    Return<void> gnssLocationCbImpl(const T& location);

    template<class T>
    Return<void> gnssSvStatusCbImpl(const T& svStatus);

    uint32_t getGnssSvInfoListSize(const IGnssCallback_V1_0::GnssSvStatus& svStatus) {
        return svStatus.numSvs;
    }

    uint32_t getGnssSvInfoListSize(const hidl_vec<IGnssCallback::GnssSvInfo>& svInfoList) {
        return svInfoList.size();
    }

    const IGnssCallback_V1_0::GnssSvInfo& getGnssSvInfoOfIndex(
            const IGnssCallback_V1_0::GnssSvStatus& svStatus, size_t i) {
        return svStatus.gnssSvList.data()[i];
    }

    const IGnssCallback_V1_0::GnssSvInfo& getGnssSvInfoOfIndex(
            const hidl_vec<IGnssCallback::GnssSvInfo>& svInfoList, size_t i) {
        return svInfoList[i].v1_0;
    }

    uint32_t getConstellationType(const IGnssCallback_V1_0::GnssSvStatus& svStatus, size_t i) {
        return static_cast<uint32_t>(svStatus.gnssSvList.data()[i].constellation);
    }

    uint32_t getConstellationType(const hidl_vec<IGnssCallback::GnssSvInfo>& svInfoList, size_t i) {
        return static_cast<uint32_t>(svInfoList[i].constellation);
    }
};

```

在GnssCallback 中具体实现的是gnss的回调数据经过分析发现  
 gps位置变化的具体实现方法



```
Return<void> GnssCallback::gnssLocationCb(const GnssLocation_V1_0& location) {
    return gnssLocationCbImpl<GnssLocation_V1_0>(location);
}

```

接下来具体分析gnssLocationCbImpl 关于gnss的相关方法  
 gnssLocationCbImpl 方法如下:



```
Return<void> GnssCallback::gnssLocationCbImpl(const T& location) {
    JNIEnv* env = getJniEnv();

    jobject jLocation = translateGnssLocation(env, location);

    env->CallVoidMethod(mCallbacksObj,
                        method_reportLocation,
                        boolToJbool(hasLatLong(location)),
                        jLocation);
    checkAndClearExceptionFromCallback(env, __FUNCTION__);
    env->DeleteLocalRef(jLocation);
    return Void();
}

```

修改方案：  
 用个系统属性来控制是否返回数据:  
 修改如下：



```
Return<void> GnssCallback::gnssLocationCbImpl(const T& location) {
   // add code start 
   // 定义一个系统开关
   char property[8];
   int len = __system_property_get("gps.location.custom",property);
   if(len>0){
        if(strcmp(property,"1")==0) return Void();
    }
   // add code end
    JNIEnv* env = getJniEnv();

    jobject jLocation = translateGnssLocation(env, location);

    env->CallVoidMethod(mCallbacksObj,
                        method_reportLocation,
                        boolToJbool(hasLatLong(location)),
                        jLocation);
    checkAndClearExceptionFromCallback(env, __FUNCTION__);
    env->DeleteLocalRef(jLocation);
    return Void();
}

```

在上述方法中通过gnssLocationCbImpl中的系统属性控制是否返回定位数据来控制gps关闭





