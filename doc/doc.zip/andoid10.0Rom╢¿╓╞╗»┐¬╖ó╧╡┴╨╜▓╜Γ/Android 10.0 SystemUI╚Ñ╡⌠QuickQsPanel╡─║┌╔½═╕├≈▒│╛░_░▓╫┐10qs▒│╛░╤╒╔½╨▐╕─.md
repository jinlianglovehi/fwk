






### 1.概述


在10.0的原生系统中，下拉状态栏的QuickQsPanel默认会有黑色透明背景，当设置默认壁纸比较透明的时候 能够看到很清楚，所以要去掉这些黑色透明背景，就需要看布局文件分析


### 2.SystemUI去掉QuickQsPanel的黑色透明背景的核心类



```
frameworks/base/packages/SystemUI/res/layout/qs_panel.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java


```

### 3.SystemUI去掉QuickQsPanel的黑色透明背景核心功能分析和实现


而下拉状态栏布局文件为qs\_panel.xml,接下来从下拉状态栏布局文件中，查看是否  
 由黑色透明背景的添加，然后去掉黑色透明背景



```
<com.android.systemui.qs.QSContainerImpl
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/quick\_settings\_container"
    android:layout_width="match\_parent"
    android:layout_height="wrap\_content"
    android:clipToPadding="false"
    android:clipChildren="false" >

    <!-- Main QS background -->
    <View
        android:id="@+id/quick\_settings\_background"
        android:layout_width="match\_parent"
        android:layout_height="0dp"
        android:elevation="4dp"
        android:background="@drawable/qs\_background\_primary" />

    <!-- Black part behind the status bar -->
    <View
        android:id="@+id/quick\_settings\_status\_bar\_background"
        android:layout_width="match\_parent"
        android:layout_height="@\*android:dimen/quick\_qs\_offset\_height"
        android:clipToPadding="false"
        android:clipChildren="false"
        android:background="#ff000000" />

    <!-- Gradient view behind QS -->
    <View
        android:id="@+id/quick\_settings\_gradient\_view"
        android:layout_width="match\_parent"
        android:layout_height="126dp"
        android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
        android:clipToPadding="false"
        android:clipChildren="false"
        android:background="@drawable/qs\_bg\_gradient" />


    <com.android.systemui.qs.QSPanel
        android:id="@+id/quick\_settings\_panel"
        android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_marginBottom="@dimen/qs\_footer\_height"
        android:elevation="4dp"
        android:background="@android:color/transparent"
        android:focusable="true"
        android:accessibilityTraversalBefore="@android:id/edit"
    />

    <include layout="@layout/quick\_status\_bar\_expanded\_header" />

    <include layout="@layout/qs\_footer\_impl" />

    <include android:id="@+id/qs\_detail" layout="@layout/qs\_detail" />

    <include android:id="@+id/qs\_customize" layout="@layout/qs\_customize\_panel"
        android:visibility="gone" />

</com.android.systemui.qs.QSContainerImpl>

```

通过在qs\_panel.xml中发现  
 quick\_settings\_status\_bar\_background 就是最上面status的背景  
 quick\_settings\_gradient\_view 就是功能开关键的背景，去掉黑色透明背景  
 所以修改为



```
  <View
        android:id="@+id/quick\_settings\_status\_bar\_background"
        android:layout_width="match\_parent"
        android:layout_height="@\*android:dimen/quick\_qs\_offset\_height"
        android:clipToPadding="false"
        android:clipChildren="false"
        android:background="#00000000" />

    <!-- Gradient view behind QS -->
    <View
        android:id="@+id/quick\_settings\_gradient\_view"
        android:layout_width="match\_parent"
        android:layout_height="126dp"
        android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
        android:clipToPadding="false"
        android:clipChildren="false"/>

```

### 2.关于QuickQsPanel 设置功能开关键的透明度的修改


在QuickStatusBarHeader.java 中就是关于下拉状态栏头部的管理类，所以在这里  
 可以看关于设置相关背景资源的方法中，去掉黑色透明背景的设置



```
  
      @Override
      protected void onFinishInflate() {
          super.onFinishInflate();
  
          mHeaderQsPanel = findViewById(R.id.quick_qs_panel);
          mSystemIconsView = findViewById(R.id.quick_status_bar_system_icons);
          mQuickQsStatusIcons = findViewById(R.id.quick_qs_status_icons);
          StatusIconContainer iconContainer = findViewById(R.id.statusIcons);
          iconContainer.setShouldRestrictIcons(false);
          mIconManager = new TintedIconManager(iconContainer);
  
          // Views corresponding to the header info section (e.g. ringer and next alarm).
          mHeaderTextContainerView = findViewById(R.id.header_text_container);
          mStatusSeparator = findViewById(R.id.status_separator);
          mNextAlarmIcon = findViewById(R.id.next_alarm_icon);
          mNextAlarmTextView = findViewById(R.id.next_alarm_text);
          mNextAlarmContainer = findViewById(R.id.alarm_container);
          mNextAlarmContainer.setOnClickListener(this::onClick);
          mRingerModeIcon = findViewById(R.id.ringer_mode_icon);
          mRingerModeTextView = findViewById(R.id.ringer_mode_text);
          mRingerContainer = findViewById(R.id.ringer_container);
          mCarrierGroup = findViewById(R.id.carrier_group);
  
  
          updateResources();
  
          Rect tintArea = new Rect(0, 0, 0, 0);
          int colorForeground = Utils.getColorAttrDefaultColor(getContext(),
                  android.R.attr.colorForeground);
          float intensity = getColorIntensity(colorForeground);
          int fillColor = mDualToneHandler.getSingleColor(intensity);
  
          // Set light text on the header icons because they will always be on a black background
          applyDarkness(R.id.clock, tintArea, 0, DarkIconDispatcher.DEFAULT_ICON_TINT);
  
          // Set the correct tint for the status icons so they contrast
          mIconManager.setTint(fillColor);
          mNextAlarmIcon.setImageTintList(ColorStateList.valueOf(fillColor));
          mRingerModeIcon.setImageTintList(ColorStateList.valueOf(fillColor));
  
          mClockView = findViewById(R.id.clock);
          mClockView.setOnClickListener(this);
          mDateView = findViewById(R.id.date);
  
          // Tint for the battery icons are handled in setupHost()
          mBatteryRemainingIcon = findViewById(R.id.batteryRemainingIcon);
          // Don't need to worry about tuner settings for this icon
 mBatteryRemainingIcon.setIgnoreTunerUpdates(true);
 // QS will always show the estimate, and BatteryMeterView handles the case where
 // it's unavailable or charging
          mBatteryRemainingIcon.setPercentShowMode(BatteryMeterView.MODE_ESTIMATE);
          mRingerModeTextView.setSelected(true);
          mNextAlarmTextView.setSelected(true);
      }
  
private void updateResources() {
        Resources resources = mContext.getResources();
        updateMinimumHeight();

        // Update height for a few views, especially due to landscape mode restricting space.
        mHeaderTextContainerView.getLayoutParams().height =
                resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
        mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

        mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
                com.android.internal.R.dimen.quick_qs_offset_height);
        mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        if (mQsDisabled) {
            lp.height = resources.getDimensionPixelSize(
                    com.android.internal.R.dimen.quick_qs_offset_height);
        } else {
            lp.height = Math.max(getMinimumHeight(),
                    resources.getDimensionPixelSize(
                            com.android.internal.R.dimen.quick_qs_total_height));
        }

        setLayoutParams(lp);

        updateStatusIconAlphaAnimator();
        updateHeaderTextContainerAlphaAnimator();
    }
    private void updateStatusIconAlphaAnimator() {
        mStatusIconsAlphaAnimator = new TouchAnimator.Builder()
                .addFloat(mQuickQsStatusIcons, "alpha", 1, 0, 0)
                .build();
    }

```

在updateResources() 中调用updateStatusIconAlphaAnimator();来设置关于状态栏的icon透明度  
 updateStatusIconAlphaAnimator(); 就是mQuickQsStatusIcons动画 设置它的透明度  
 会有所影响 所以应该把它去掉  
 修改为：`/*updateStatusIconAlphaAnimator();*/`


通过上面这些操作就去掉了黑色透明了





