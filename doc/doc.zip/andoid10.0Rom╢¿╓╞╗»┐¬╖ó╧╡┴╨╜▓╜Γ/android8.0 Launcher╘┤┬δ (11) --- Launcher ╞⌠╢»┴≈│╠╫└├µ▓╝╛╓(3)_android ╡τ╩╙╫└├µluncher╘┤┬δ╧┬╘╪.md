






这篇依然讲解桌面布局的创建，这一部分依然服务于setupViews，创建每一个UI模块，所有模块都创建完了也就组成了完整的Launcher。


workspace进行基本绑定  
 我们先来看这一段的代码，代码主要做了workspace的基本绑定。



```
      // Setup the workspace
        mWorkspace.setHapticFeedbackEnabled(false);
        mWorkspace.setOnLongClickListener(this);
        mWorkspace.setup(mDragController);
        // Until the workspace is bound, ensure that we keep the wallpaper offset locked to the
        // default state, otherwise we will update to the wrong offsets in RTL
        mWorkspace.lockWallpaperToDefaultPage();
        mWorkspace.bindAndInitFirstWorkspaceScreen(null /* recycled qsb */);
        mDragController.addDragListener(mWorkspace);

        // Get the search/delete/uninstall bar
        mDropTargetBar = mDragLayer.findViewById(R.id.drop_target_bar);

        // Setup Apps and Widgets
        mAppsView = (AllAppsContainerView) findViewById(R.id.apps_view);
        mWidgetsView = (WidgetsContainerView) findViewById(R.id.widgets_view);
        // Setup the drag controller (drop targets have to be added in reverse order in priority)
        mDragController.setMoveTarget(mWorkspace);
        mDragController.addDropTarget(mWorkspace);
        mDropTargetBar.setup(mDragController);

        mAllAppsController.setupViews(mAppsView, mHotseat, mWorkspace);
mWorkspace.setHapticFeedbackEnabled(false);

```

设置在触摸时没有触感反馈。


mWorkspace.setOnLongClickListener(this);  
 设置workspace的长按事件监听，在方法里面绑定的是Launcher的onlongclick（因为传入的是this，也就是Launcher的上下文），所以当长按workspace的时候就会启用Launcher的onlongclick。


在Launcher的onLongClick中绑定了很多模块的事件，其中会进行判断 if (v instanceof Workspace)是否是在workspace中，然后会接着判断是否是overView模式，不是就进入这个模式。  
 其中有一个是设置震动反馈的就是在Launcher的OnlongClick中的这段代码



```
mWorkspace.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,
HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);

mWorkspace.setup(mDragController);

```

给workspace传入DragController，我们一直在说DragController用途广泛，比如拖拽时顶部出现的选项栏等都是由DragController控制。


mWorkspace.lockWallpaperToDefaultPage();  
 设置默认壁纸的起始页，workspace背景壁纸的偏移量，Launcher有个壁纸随着页面滑动的功能，在Workspace绑定之前确保我们将壁纸偏移量锁定为默认状态。


mWorkspace.bindAndInitFirstWorkspaceScreen(null /\* recycled qsb \*/);  
 绑定起始桌面的默认google search的。正如之前提到，google在开发Launcher的时候特地留了一个google search widget的入口。


mDragController.addDragListener(mWorkspace);  
 给DragController添加拖拽的监听事件。


mDropTargetBar = mDragLayer.findViewById(R.id.drop\_target\_bar);  
 获得顶部查找，删除，卸载的控件。mDropTargetBar顶部选项按钮，是Launcher.xml的组件之一。  
 当拖动应用的时候，顶部会给出该应用能够供给的一些选项。


通常有info、remove、disable、uninstall


info：从allapp拖动应用到桌面会出现，将应用拖到info并松开会显示应用的参数


Remove：删掉桌面的快捷方式，allapp中仍然保留


Disable：禁用应用，针对系统应用，这些应用不能被删除，如有需要，可以选择禁用该应用的功能。比如平板的通话和短信功能。


Uninstall：对于用户安装的应用，在拖拽时顶部会有uninstall选项。这是用户在桌面删除手机中应用的唯一方法。 删除应用可以在设置或者其他应用管理软件里面进行。



```
mDragController.setMoveTarget(mWorkspace);
        mDragController.addDropTarget(mWorkspace);
        mDropTargetBar.setup(mDragController);
这里是将把拖拽，移动的事件添加到集合中，给DropTargetBar.传入DragController来进行操作。

mAllAppsController.setupViews(mAppsView, mHotseat, mWorkspace);

```

给AllAppsController绑定视图，AppsView，Hotseat，workspace。方便拖拽的操作  
 到这里，Launcher 启动流程创建桌面布局就全部讲解完毕了





