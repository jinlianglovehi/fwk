



## 1.前言


在10.0的系统定制化开发中，在进行Settings的开发中，在导航栏和设置菜单项布局中，会有一条分割线但是白色的，高度太小一般是 不注意看不出来的，产品开发需要要求设置分割线高度大一些修改分割线的高度，接下来就分析下相关功能实现流程


## 2.系统Settings修改底部导航栏和设置菜单项的分割线高度大小的核心类



```
frameworks\base\core\java\com\android\internal\policy\DecorView.java
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NavigationBarView.java
```

## 3.系统Settings修改底部导航栏和设置菜单项的分割线高度大小的核心功能分析和实现


在Android应用开发中,NavigationBarView 是一个用于显示导航栏的视图组件。导航栏通常位于屏幕底部,提供了返回按钮、 菜单按钮等常用的界面导航功能，所以说关于导航栏和设置菜单项的分割线高度大小的功能修改，对于NavigationBarView.java 的布局分析相当的重要， DecorView为整个Window界面的最顶层View。 二、DecorView只有一个子元素为LinearLayout。 代表整个Window界面，包含通知栏，标题栏，内容显示栏三块区域。 三、LinearLayout里有两个FrameLayout子元素。 为标题栏显示界面。只有一个TextView显示应用 DecorView具体布局: 一、DecorView为整个Window界面的最顶层View。 二、DecorView只有一个子元素为LinearLayout。代表整个Window界面，包含通知栏，标题栏，内容显示栏三块区域。 三、LinearLayout里有两个FrameLayout子元素。


## 3.1 NavigationBarView.java相关布局分析


在系统Settings修改底部导航栏和设置菜单项的分割线高度大小的实现功能开发中，通过上述分析， NavigationBarView.java主要就是三键系统导航模式的导航栏布局，它主要就是com.android.systemui.statusbar.phone. NavigationBarInflaterView这个子控件，接下来看下相关源码



```
public class NavigationBarView extends FrameLayout implements
        NavigationModeController.ModeChangedListener {
    final static boolean DEBUG = false;
    final static String TAG = "StatusBar/NavBarView";
    public NavigationBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
....
        mContextualButtonGroup.addButton(accessibilityButton);
        mKeyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        mOverviewProxyService = Dependency.get(OverviewProxyService.class);
        mRecentsOnboarding = new RecentsOnboarding(context, mOverviewProxyService);
        mFloatingRotationButton = new FloatingRotationButton(context);
        mRotationButtonController = new RotationButtonController(context,
                R.style.RotateButtonCCWStart90,
                isGesturalMode ? mFloatingRotationButton : rotateSuggestionButton);

        final ContextualButton backButton = new ContextualButton(R.id.back, 0);

        mConfiguration = new Configuration();
        mTmpLastConfiguration = new Configuration();
        mConfiguration.updateFrom(context.getResources().getConfiguration());

        mScreenPinningNotify = new ScreenPinningNotify(mContext);
        mBarTransitions = new NavigationBarTransitions(this);

        mButtonDispatchers.put(R.id.back, backButton);
        mButtonDispatchers.put(R.id.home, new ButtonDispatcher(R.id.home));
        mButtonDispatchers.put(R.id.home_handle, new ButtonDispatcher(R.id.home_handle));
        mButtonDispatchers.put(R.id.recent_apps, new ButtonDispatcher(R.id.recent_apps));
        mButtonDispatchers.put(R.id.ime_switcher, imeSwitcherButton);
        mButtonDispatchers.put(R.id.accessibility_button, accessibilityButton);
        mButtonDispatchers.put(R.id.rotate_suggestion, rotateSuggestionButton);
        mButtonDispatchers.put(R.id.menu_container, mContextualButtonGroup);
...
    }
```

在系统Settings修改底部导航栏和设置菜单项的分割线高度大小的实现功能开发中，通过上述分析， 在NavigationBarView.java中的相关源码中分析得知，它继承自FrameLayout父布局，而在 NavigationBarView(Context context, AttributeSet attrs)构造方法中，在这里这样是构建 home键 back键 recent\_apps键等核心导航键布局，接下来具体分析下它的根布局控件 DecorView的相关源码分析


## 3.2 DecorView的相关源码分析


在系统Settings修改底部导航栏和设置菜单项的分割线高度大小的实现功能开发中，通过上述分析， DecorView是FrameLayout类的子类,通常认为DecorView是Android视图树的根节点,也就是最顶层的View, 所以就需要看这个类是如何设置分割线高度的



```
 WindowInsets updateColorViews(WindowInsets insets, boolean animate) {
....
            boolean navBarToRightEdge = isNavBarToRightEdge(mLastBottomInset, mLastRightInset);
            boolean navBarToLeftEdge = isNavBarToLeftEdge(mLastBottomInset, mLastLeftInset);
            int navBarSize = getNavBarSize(mLastBottomInset, mLastRightInset, mLastLeftInset);
            updateColorViewInt(mNavigationColorViewState, sysUiVisibility,
                    calculateNavigationBarColor(), mWindow.mNavigationBarDividerColor, navBarSize,
                    navBarToRightEdge || navBarToLeftEdge, navBarToLeftEdge,
                    0 /* sideInset */, animate && !disallowAnimate,
                    mForceWindowDrawsBarBackgrounds);
....
            boolean statusBarNeedsRightInset = navBarToRightEdge
                    && mNavigationColorViewState.present;
            boolean statusBarNeedsLeftInset = navBarToLeftEdge
                    && mNavigationColorViewState.present;
            int statusBarSideInset = statusBarNeedsRightInset ? mLastRightInset
                    : statusBarNeedsLeftInset ? mLastLeftInset : 0;
            updateColorViewInt(mStatusColorViewState, sysUiVisibility,
                    calculateStatusBarColor(), 0, mLastTopInset,
                    false /* matchVertical */, statusBarNeedsLeftInset, statusBarSideInset,
                    animate && !disallowAnimate,
                    mForceWindowDrawsBarBackgrounds);
        }
    private void updateColorViewInt(final ColorViewState state, int sysUiVis, int color,
            int dividerColor, int size, boolean verticalBar, boolean seascape, int sideMargin,
            boolean animate, boolean force) {
....

        if (view == null) {
            if (showView) {
                state.view = view = new View(mContext);
                setColor(view, color, dividerColor, verticalBar, seascape);
                view.setTransitionName(state.attributes.transitionName);
                view.setId(state.attributes.id);
                visibilityChanged = true;
                view.setVisibility(INVISIBLE);
                state.targetVisibility = VISIBLE;

                LayoutParams lp = new LayoutParams(resolvedWidth, resolvedHeight,
                        resolvedGravity);
                if (seascape) {
                    lp.leftMargin = sideMargin;
                } else {
                    lp.rightMargin = sideMargin;
                }
                addView(view, lp);
                updateColorViewTranslations();
            }
        } else {
            int vis = showView ? VISIBLE : INVISIBLE;
            visibilityChanged = state.targetVisibility != vis;
            state.targetVisibility = vis;
            LayoutParams lp = (LayoutParams) view.getLayoutParams();
            int rightMargin = seascape ? 0 : sideMargin;
            int leftMargin = seascape ? sideMargin : 0;
            if (lp.height != resolvedHeight || lp.width != resolvedWidth
                    || lp.gravity != resolvedGravity || lp.rightMargin != rightMargin
                    || lp.leftMargin != leftMargin) {
                lp.height = resolvedHeight;
                lp.width = resolvedWidth;
                lp.gravity = resolvedGravity;
                lp.rightMargin = rightMargin;
                lp.leftMargin = leftMargin;
                view.setLayoutParams(lp);
            }
            if (showView) {
                setColor(view, color, dividerColor, verticalBar, seascape);
            }
        }
```

在系统Settings修改底部导航栏和设置菜单项的分割线高度大小的实现功能开发中，通过上述分析， 在 DecorView.java中的上述分析中得知，在updateColorViews(WindowInsets insets, boolean animate) 来负责更新窗口window的颜色样式等等功能，而它最终调用updateColorViewInt(final ColorViewState state, int sysUiVis, int color, int dividerColor, int size, boolean verticalBar, boolean seascape, int sideMargin, boolean animate, boolean force)来负责最近更新布局颜色等样式，最终调用 setColor(view, color, dividerColor, verticalBar, seascape);来设置这些颜色样式等，接下来具体看 该怎么样设置样式颜色等等功能



```
 private static void setColor(View v, int color, int dividerColor, boolean verticalBar,
            boolean seascape) {
        if (dividerColor != 0) {
            final Pair<Boolean, Boolean> dir = (Pair<Boolean, Boolean>) v.getTag();
            if (dir == null || dir.first != verticalBar || dir.second != seascape) {
                final int size = Math.round(
                     -   TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1,
                     +   TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5,
                                v.getContext().getResources().getDisplayMetrics()));
                // Use an inset to make the divider line on the side that faces the app.
                final InsetDrawable d = new InsetDrawable(new ColorDrawable(color),
                        verticalBar && !seascape ? size : 0,
                        !verticalBar ? size : 0,
                        verticalBar && seascape ? size : 0, 0);
                v.setBackground(new LayerDrawable(new Drawable[] {
                        new ColorDrawable(dividerColor), d }));
                v.setTag(new Pair<>(verticalBar, seascape));
            } else {
                final LayerDrawable d = (LayerDrawable) v.getBackground();
                final InsetDrawable inset = ((InsetDrawable) d.getDrawable(1));
                ((ColorDrawable) inset.getDrawable()).setColor(color);
                ((ColorDrawable) d.getDrawable(0)).setColor(dividerColor);
            }
        } else {
            v.setTag(null);
            v.setBackgroundColor(color);
        }
    }
```

在系统Settings修改底部导航栏和设置菜单项的分割线高度大小的实现功能开发中，通过上述分析， 在 DecorView.java中的上述分析中得知，在TypedValue.applyDimension(TypedValue.COMPLEX\_UNIT\_DIP, 1这段 代码中1就是代表分割线高度为1，所以就需要更改为自己想要的高度就可以了



