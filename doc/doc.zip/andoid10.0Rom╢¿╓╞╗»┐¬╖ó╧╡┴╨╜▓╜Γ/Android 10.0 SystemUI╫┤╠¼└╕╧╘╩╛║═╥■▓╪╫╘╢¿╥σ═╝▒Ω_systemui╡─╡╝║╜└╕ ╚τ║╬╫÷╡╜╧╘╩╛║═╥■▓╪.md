



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.SystemUI状态栏显示和隐藏自定义图标的相关功能代码](#2.SystemUI%E7%8A%B6%E6%80%81%E6%A0%8F%E6%98%BE%E7%A4%BA%E5%92%8C%E9%9A%90%E8%97%8F%E8%87%AA%E5%AE%9A%E4%B9%89%E5%9B%BE%E6%A0%87%E7%9A%84%E7%9B%B8%E5%85%B3%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81)


[3.SystemUI状态栏显示和隐藏自定义图标的和功能分析](#3.SystemUI%E7%8A%B6%E6%80%81%E6%A0%8F%E6%98%BE%E7%A4%BA%E5%92%8C%E9%9A%90%E8%97%8F%E8%87%AA%E5%AE%9A%E4%B9%89%E5%9B%BE%E6%A0%87%E7%9A%84%E5%92%8C%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[1. StatusBar 关于wifi图标相关代码](#%C2%A01.%20StatusBar%20%E5%85%B3%E4%BA%8Ewifi%E5%9B%BE%E6%A0%87%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.2 PhoneStatusBarPolicy.java关于添加自定义图标相关代码](#3.2%20PhoneStatusBarPolicy.java%E5%85%B3%E4%BA%8E%E6%B7%BB%E5%8A%A0%E8%87%AA%E5%AE%9A%E4%B9%89%E5%9B%BE%E6%A0%87%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


  在rom开发中，需要定制化的功能很多，而SystemUI状态栏显示的图标也是挺多的，为了加深对这块的了解，所以需要深入了解这方面的相关知识代码，目前就来实现在状态栏显示和隐藏自定义图标的相关功能


## 2.SystemUI状态栏显示和隐藏自定义图标的相关功能代码



```
     frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\StatusBar.java
   frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarSignalPolicy.java
```

## 3.SystemUI状态栏显示和隐藏自定义图标的和功能分析


在系统启动的过程中，在SystemServer.java类中，在启动SystemUIService这个服务以后，这个SystemUIService服务会  
 调用SystemUI类的Start()方法;SystemUI类又是被BaseStatusBar类实现的；PhoneStatusBar类又继承了  
 BaseStatusBar类，重写了start()方法，因此实际调用的是PhoneStatusBar的start()方法来完成状态栏的启动。  
 在Statusbar.java这个状态栏中，有两个比较重要，一个是statusbarSignalPolicy.java这个主要是管理状态栏的  
 网络信号策略，另外一个就是PhoneStatusBarPolicy.java主要是管理状态栏通知图标策略的，  
 所以针对图标的管理主要分析PhoneStatusBarPolicy.java的相关源码就可以了



##  1. StatusBar 关于wifi图标相关代码


StatusBar创建的创建过程中



```
public class StatusBar extends SystemUI implements DemoMode,
        ActivityStarter, OnUnlockMethodChangedListener,
        OnHeadsUpChangedListener, CommandQueue.Callbacks, ZenModeController.Callback,
        ColorExtractor.OnColorsChangedListener, ConfigurationListener,
        StatusBarStateController.StateListener, ShadeController,
        ActivityLaunchAnimator.Callback, AmbientPulseManager.OnAmbientChangedListener,
        AppOpsController.Callback {


protected void makeStatusBarView(@Nullable RegisterStatusBarResult result) {
        final Context context = mContext;
        updateDisplaySize(); // populates mDisplayMetrics
        updateResources();
        updateTheme();

        inflateStatusBarWindow(context);
        mStatusBarWindow.setService(this);
        mStatusBarWindow.setOnTouchListener(getStatusBarWindowTouchListener());

        // TODO: Deal with the ugliness that comes from having some of the statusbar broken out
        // into fragments, but the rest here, it leaves some awkward lifecycle and whatnot.
        mNotificationPanel = mStatusBarWindow.findViewById(R.id.notification_panel);
        mStackScroller = mStatusBarWindow.findViewById(R.id.notification_stack_scroller);
        mZenController.addCallback(this);
        NotificationListContainer notifListContainer = (NotificationListContainer) mStackScroller;
        mNotificationLogger.setUpWithContainer(notifListContainer);

        mNotificationIconAreaController = SystemUIFactory.getInstance()
                .createNotificationIconAreaController(context, this, mStatusBarStateController);
        inflateShelf();
        mNotificationIconAreaController.setupShelf(mNotificationShelf);

        Dependency.get(DarkIconDispatcher.class).addDarkReceiver(mNotificationIconAreaController);
        // Allow plugins to reference DarkIconDispatcher and StatusBarStateController
        Dependency.get(PluginDependencyProvider.class)
                .allowPluginDependency(DarkIconDispatcher.class);
        Dependency.get(PluginDependencyProvider.class)
                .allowPluginDependency(StatusBarStateController.class);
        FragmentHostManager.get(mStatusBarWindow)
                .addTagListener(CollapsedStatusBarFragment.TAG, (tag, fragment) -> {
                    CollapsedStatusBarFragment statusBarFragment =
                            (CollapsedStatusBarFragment) fragment;
                    statusBarFragment.initNotificationIconArea(mNotificationIconAreaController);
                    PhoneStatusBarView oldStatusBarView = mStatusBarView;
                    mStatusBarView = (PhoneStatusBarView) fragment.getView();
                    mStatusBarView.setBar(this);
                    mStatusBarView.setPanel(mNotificationPanel);
                    mStatusBarView.setScrimController(mScrimController);

                    // CollapsedStatusBarFragment re-inflated PhoneStatusBarView and both of
                    // mStatusBarView.mExpanded and mStatusBarView.mBouncerShowing are false.
                    // PhoneStatusBarView's new instance will set to be gone in
                    // PanelBar.updateVisibility after calling mStatusBarView.setBouncerShowing
                    // that will trigger PanelBar.updateVisibility. If there is a heads up showing,
                    // it needs to notify PhoneStatusBarView's new instance to update the correct
                    // status by calling mNotificationPanel.notifyBarPanelExpansionChanged().
                    if (mHeadsUpManager.hasPinnedHeadsUp()) {
                        mNotificationPanel.notifyBarPanelExpansionChanged();
                    }
                    mStatusBarView.setBouncerShowing(mBouncerShowing);
                    if (oldStatusBarView != null) {
                        float fraction = oldStatusBarView.getExpansionFraction();
                        boolean expanded = oldStatusBarView.isExpanded();
                        mStatusBarView.panelExpansionChanged(fraction, expanded);
                    }

                    HeadsUpAppearanceController oldController = mHeadsUpAppearanceController;
                    if (mHeadsUpAppearanceController != null) {
                        // This view is being recreated, let's destroy the old one
                        mHeadsUpAppearanceController.destroy();
                    }
                    mHeadsUpAppearanceController = new HeadsUpAppearanceController(
                            mNotificationIconAreaController, mHeadsUpManager, mStatusBarWindow);
                    mHeadsUpAppearanceController.readFrom(oldController);
                    mStatusBarWindow.setStatusBarView(mStatusBarView);
                    updateAreThereNotifications();
                    checkBarModes();
                }).getFragmentManager()
                .beginTransaction()
                .replace(R.id.status_bar_container, new CollapsedStatusBarFragment(),
                        CollapsedStatusBarFragment.TAG)
                .commit();
        mIconController = Dependency.get(StatusBarIconController.class);

        mHeadsUpManager = new HeadsUpManagerPhone(context, mStatusBarWindow, mGroupManager, this,

        
    }
.....
}
```

        //设置icon的图标策略类  
         mIconPolicy = new PhoneStatusBarPolicy(mContext, mIconController);  
         //设置icon的信号图标策略类  
         mSignalPolicy = new StatusBarSignalPolicy(mContext, mIconController);


所以添加自定义图标处理在PhoneStatusBarPolicy.java中


### 3.2 PhoneStatusBarPolicy.java关于添加自定义图标相关代码



```
public class PhoneStatusBarPolicy
        implements BluetoothController.Callback,
                CommandQueue.Callbacks,
                RotationLockControllerCallback,
                Listener,
                ZenModeController.Callback,
                DeviceProvisionedListener,
                KeyguardMonitor.Callback,
                LocationController.LocationChangeCallback {

// 添加相关参数
    private final String mSlotShowImg="input_type";
    private final String ACTION_INPUT_TYPE_CHANGED = "android.action.INPUT_TYPE_CHANGED";


public PhoneStatusBarPolicy(Context context, StatusBarIconController iconController) {
        mContext = context;
        mIconController = iconController;
        mCast = Dependency.get(CastController.class);
        mHotspot = Dependency.get(HotspotController.class);
        mBluetooth = Dependency.get(BluetoothController.class);
        mNextAlarmController = Dependency.get(NextAlarmController.class);
        mAlarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        mUserInfoController = Dependency.get(UserInfoController.class);
        mUserManager = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
        mRotationLockController = Dependency.get(RotationLockController.class);
        mDataSaver = Dependency.get(DataSaverController.class);
        mZenController = Dependency.get(ZenModeController.class);
        mProvisionedController = Dependency.get(DeviceProvisionedController.class);
        mKeyguardMonitor = Dependency.get(KeyguardMonitor.class);
        mLocationController = Dependency.get(LocationController.class);
        mSensorPrivacyController = Dependency.get(SensorPrivacyController.class);

        mSlotCast = context.getString(com.android.internal.R.string.status_bar_cast);
        mSlotHotspot = context.getString(com.android.internal.R.string.status_bar_hotspot);
        mSlotBluetooth = context.getString(com.android.internal.R.string.status_bar_bluetooth);
        mSlotTty = context.getString(com.android.internal.R.string.status_bar_tty);
        mSlotZen = context.getString(com.android.internal.R.string.status_bar_zen);
        mSlotVolume = context.getString(com.android.internal.R.string.status_bar_volume);
        mSlotAlarmClock = context.getString(com.android.internal.R.string.status_bar_alarm_clock);
        mSlotManagedProfile = context.getString(
                com.android.internal.R.string.status_bar_managed_profile);
        mSlotRotate = context.getString(com.android.internal.R.string.status_bar_rotate);
        mSlotHeadset = context.getString(com.android.internal.R.string.status_bar_headset);
        mSlotDataSaver = context.getString(com.android.internal.R.string.status_bar_data_saver);
        mSlotLocation = context.getString(com.android.internal.R.string.status_bar_location);
        mSlotSensorsOff = context.getString(com.android.internal.R.string.status_bar_sensors_off);

        // listen for broadcasts
        IntentFilter filter = new IntentFilter();
        filter.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION);
        filter.addAction(AudioManager.INTERNAL_RINGER_MODE_CHANGED_ACTION);
        filter.addAction(AudioManager.ACTION_HEADSET_PLUG);
        filter.addAction(TelephonyIntents.ACTION_SIM_STATE_CHANGED);
        filter.addAction(TelecomManager.ACTION_CURRENT_TTY_MODE_CHANGED);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_AVAILABLE);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_UNAVAILABLE);
        filter.addAction(Intent.ACTION_MANAGED_PROFILE_REMOVED);

        // 添加自定义广播
        + filter.addAction(ACTION_INPUT_TYPE_CHANGED);


        mContext.registerReceiver(mIntentReceiver, filter, null, mHandler);

       ....
    }
}
```

通过mIntentReceiver监听图标的相关广播 然后通过mIconController.setIcon(mSlotSensorsOff, R.drawable.stat\_sys\_sensors\_off,  
                 mContext.getString(R.string.accessibility\_sensors\_off\_active));来显示相关图标  
 所以增加相关的自定义广播来显示相应的图标


接下来增加相关自定义图标的方法  
 //增加自定义图标



```
private int[] inputImgArray = {
            R.drawable.phone_btn,
            R.drawable.net_btn,
            R.drawable.location_btn,
            R.drawable.msg_btn
    };

    private final void updateShowImg(Intent intent) {
        final int input = intent.getIntExtra(mSlotShowImg, 0);
        if (input >= inputImgArray.length) return;
        if(input < 0){
            mIconController.setIconVisibility(mSlotShowImg, false);
            return;
        }
        int iconId = inputImgArray[input];
        mIconController.setIcon(mSlotShowImg, iconId, "");
        mIconController.setIconVisibility(mSlotShowImg, true);
    }

在广播接收中调用显示图标方法
 private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            switch (action) {
                case AudioManager.RINGER_MODE_CHANGED_ACTION:
                case AudioManager.INTERNAL_RINGER_MODE_CHANGED_ACTION:
                    updateVolumeZen();
                    break;
                case TelephonyIntents.ACTION_SIM_STATE_CHANGED:
                    // Avoid rebroadcast because SysUI is direct boot aware.
                    if (intent.getBooleanExtra(TelephonyIntents.EXTRA_REBROADCAST_ON_UNLOCK,
                            false)) {
                        break;
                    }
                    updateSimState(intent);
                    break;
                case TelecomManager.ACTION_CURRENT_TTY_MODE_CHANGED:
                    updateTTY(intent.getIntExtra(TelecomManager.EXTRA_CURRENT_TTY_MODE,
                            TelecomManager.TTY_MODE_OFF));
                    break;
                case Intent.ACTION_MANAGED_PROFILE_AVAILABLE:
                case Intent.ACTION_MANAGED_PROFILE_UNAVAILABLE:
                case Intent.ACTION_MANAGED_PROFILE_REMOVED:
                    updateManagedProfile();
                    break;
                case AudioManager.ACTION_HEADSET_PLUG:
                    updateHeadsetPlug(intent);
                    break;

                // 接收自定义图标广播，处理添加广播事件
	+ case ACTION_INPUT_TYPE_CHANGED:
                +  updateShowImg(intent);
                 +  break;
            }
        }
    };
```

通过上述在StatusBar.java中的相关源码的修改，就可以根据广播，显示和隐藏相关的通知图标，这样就可以实现  
 显示和隐藏相关的通知图标的功能



