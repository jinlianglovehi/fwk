






Launcher3源码涉及到的android基础知识  
 如果想学习Launcher就必须熟练掌握这些android基本知识，权重比例在图中都标明了。不会的可以先学习一下这些知识。  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20191128085837954.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)


基础知识  
 这里我们先介绍一下Launcher里面常用类的主要功能


Launcher：继承Activity，主界面，用来显示图标，widget和文件夹等，它的布局就是桌面的基本结构，布局内部为DragLayer。  
 LauncherModel：继承BroadcastReceiver，是一个广播接收器，用来接收广播，主要作用是加载数据，处理数据，保存桌面状态，内部类LoaderTask用来初始化桌面。  
 LauncherProvider：继承ContentProvider，主要处理数据库的操作。  
 LauncherAppState:单例模式的全局管理类，主要初始化一些对象注册广播，获取硬件设备信息。  
 compat：兼容包，带这个后缀的都是做兼容处理的类，比如（LauncherAppsCompat 【App列表的兼容类】AppweightManagerCompat【Appweight的兼容类】）。  
 InvariantDeviceProfile：一些不变的设备相关参数管理类，内部包含了横竖屏模式的DeviceProfile。  
 WidgetPreviewLoader：存储Widget信息的数据库，内部创建了数据库widgetpreviewsdb。  
 LauncherStateTransitionAnimation：各类动画总管处理类，负责各种情况下的各种动画的效果处理。  
 IconCache：图标缓存类，应用程序icon和title的缓存，内部类创建了数据库app\_icons.db。  
 LauncherAppWidgetHost：AppWidgetHost子类，是桌面插件宿主，为了方便拖拽等才继承处理。  
 LauncherAppWidgetHostView：AppWidgetHostView子类，配合LauncherAppWidgetHost得到HostView。  
 LauncherRootView：竖屏模式下根布局，继承了InsettavleFrameLayout，控制是否显示在状态栏下面。  
 DragLayer：一个用来负责分发事件的viewGroup。  
 DragController：DragLayer只是一个ViewGroup，具体的拖拽的处理都放到了DragController中。  
 BubbleTextView：图标都基于他，继承自TextView。  
 DragView：拖拽图标时跟随手指移动的view。  
 Folder：打开文件夹展示的view。  
 FolderIcon：文件夹图标。  
 DragSource、DrogTarget：拖拽接口，DragSource表示图标从哪里开始拖拽，DrogTarget表示图标被拖到了哪里。  
 ItemInfo：桌面上每个Item的信息数据结构，包括在第几屏第几行，第几列，宽高等信息，该对象与数据库中记录一一对应，该类有多个子类如：FolderIcon的FolderInfo，BubbleTextView的shorcutInfo。  
 默认图标配置  
 default\_workspace.xml  
 我们知道当我们在启动Launcher的时候桌面会有一些已经配置好的图标，其实在第一次运行Launcher的时候会读取一个配置xml文件来进行布局（launcher/res/xml/default\_workspace.xml）这个文件可以配置App的快捷方式，weight，search搜索栏等。(具体的内容可以去源码中查看，这里只贴出来一部分)  
 文件中的一些属性：



```
 <appwidget
        launcher:packageName="com.google.android.googlequicksearchbox"
        launcher:className="com.google.android.googlequicksearchbox.SearchWidgetProvider"
        launcher:screen="0"
        launcher:x="0"
        launcher:y="0"
        launcher:spanX="4"
        launcher:spanY="1" />
<favorite
        launcher:packageName="com.android.vending"
        launcher:className="com.android.vending.AssetBrowserActivity"
        launcher:screen="0"
        launcher:x="-1"
        launcher:y="-1" />
<favorite>
<appwidget>

```

插件  
 其属性有：  
 launcher:className：应用的类名。  
 launcher:packageName：该应用的包名。  
 launcher:screen：当前屏幕位置，0-4屏，共5屏。  
 launcher:x：图标X位置，左上角第一个为0，向右递增0-4共5个。  
 launcher:y：图标Y位置，左上角第一个为0，向下递增，0-2共3个。  
 launcher:spanX：在X方向上所占格数。  
 launcher:spanY：在Y方向上所占格数。


default\_workspace\_4\*4.xml  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20191128085821139.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)


接下来我们可以看到有一些这样的文件：  
 default\_workspace\_3 \* 3.xml  
 default\_workspace\_4 \* 4.xml  
 default\_workspace\_5 \* 5.xml  
 default\_workspace\_5 \* 6.xml  
 这些事我们默认的布局文件3 \* 3,4 \* 4,5 \* 5,5 \* 6表示桌面图标的列数和行数，可以根据屏幕的大小来进行适配选择用那一个布局，（具体适配文件是launcher/res/xml/device\_profiles.xml）具体操作后面的文章会详细解释。





