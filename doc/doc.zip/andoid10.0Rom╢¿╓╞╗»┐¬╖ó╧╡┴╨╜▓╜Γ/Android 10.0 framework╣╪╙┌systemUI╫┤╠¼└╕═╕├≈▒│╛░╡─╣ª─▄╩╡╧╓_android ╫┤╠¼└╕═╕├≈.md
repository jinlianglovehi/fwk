



## 1.概述


在10.0的系统产品定制化开发中，在对于系统原生SystemUI的状态栏背景在沉浸式状态栏的  
 情况下默认是会随着背景颜色的变化而改变的，在一些特定背景下状态栏的背景也是会改变的，所以由于产品开发需要  
 要求需要设置状态栏背景为透明的，所以就需要在Activity创建的时候设置状态栏的背景色来完成功能的开发


如图:


![](https://img-blog.csdnimg.cn/b4378f13c1614180a0c9e64166df9241.png)


## 2.framework关于systemUI状态栏透明背景的功能实现的核心类



```
frameworks\base\core\java\android\app\ActivityThread.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
```

## 3.framework关于systemUI状态栏透明背景的功能实现的核心功能分析和实现


在系统SystemUI状态栏中，StatusBar也是继承SystemUI，启动流程和SystemUI一致。并在start的时候添加创建StatusBar相关的view。  
 我们从StatusBar的start()方法开始看，从这里来分析下Statusbar的加载流程和工作原理


## 3.1 关于StatusBar的相关布局构建分析相关源码



```
@Override
public void start() {

    // 省略部分代码......

    // 创建整个SystemUI视图并添加到WindowManager中

    createAndAddWindows();//这个重点方法，创建相关的视图

    // 省略部分代码......

}

public void createAndAddWindows(@Nullable RegisterStatusBarResult result) {

    // 创建整个SystemUI视图

    makeStatusBarView(result);

    // 把视图添加到Window中

    mStatusBarWindowController = Dependency.get(StatusBarWindowController.class);  //管理状态栏，导航栏、面板的状态切换
    mStatusBarWindowController.add(mStatusBarWindow, getStatusBarHeight());

}
```

在上述的Statusbar.java中的源码中，可以看到在SystemUI中的Statusbar中的start()中开始创建状态栏的相关视图，  
 在createAndAddWindows(@Nullable RegisterStatusBarResult result)中负责构建系统状态栏的图标布局等相关功能  
 而在app中实现状态栏透明效果 可以设置样式


在Android中，我们可以通过以下几个步骤来设置状态栏背景透明。  
 第一步：在styles.xml文件中定义主题


首先，我们需要在styles.xml文件中定义一个主题用于设置状态栏的样式。打开res/values/styles.xml文件，并添加以下代码：  
 <resources>  
     <style name="AppTheme" parent="Theme.AppCompat.Light.NoActionBar">  
         <item name="android:windowTranslucentStatus">true</item>  
     </style>  
 </resources>


在上述代码中，我们定义了一个名为AppTheme的主题，并在其中设置了android:windowTranslucentStatus属性为true。这个属性表示设置状态栏为透明。


第二步：在AndroidManifest.xml文件中应用主题


接下来，我们需要在AndroidManifest.xml文件中应用上一步中定义的主题。找到<application>标签，并在其中添加以下代码：


<application  
     ...  
     android:theme="@style/AppTheme">  
     ...  
 </application>


第三步：设置导航栏透明（可选）


如果你想要将导航栏（底部的导航栏）也设置为透明，可以在styles.xml文件中的AppTheme中添加以下代码：  
 <item name="android:windowTranslucentNavigation">true</item>


第四步：透明状态栏下的布局


为了适应状态栏的透明，我们需要调整布局。在你的布局文件的根布局中添加以下代码：  
 android:fitsSystemWindows="true"  
 这样可以使布局内容从状态栏的位置开始绘制，避免与状态栏重叠。  
 而这样修改的布局只有单个app有效，对于其他app就不行了，所以需要在framework中，在构建Activity的  
 布局的时候，就设置创建的状态栏透明比较就可以了


## 3.2 ActivityThread.java中相关状态栏透明背景分析


在Android系统启动的过程中，系统中第一个启动起来的进程就是zygote进程，然后由zygote负责启动SystemServer，然后就是启动  
 ActivityManagerService、WindowManagerService等系统核心服务引导服务以及其他服务等待，而这些服务承担着整个Android系统与客户端交互的重担。  
 zygote除了启动系统服务与进程外，普通的用户进程也由zygote进程fork而来，当一个应用进程启动起来后，  
 就会加载用户在AndroidManifest.xml中配置的默认加载带有Launcher属性的Activity，此时加载的入口是ActivityThread，  
 是整个应用程序的入口


首先，我们看一下Activity的启动逻辑过程：Applicationthread的ScheduleActivity通过一个叫H的Handler发送了一个启动Activity信息。handleLaunchActivity接收了这个消息，然后做处理，处理的逻辑是让PreformLaunchActivity处理，并最终执行Activity的启动。



```
    /**
     * Extended implementation of activity launch. Used when server requests a launch or relaunch.
     */
    @Override
    public Activity handleLaunchActivity(ActivityClientRecord r,
            PendingTransactionActions pendingActions, Intent customIntent) {
        // If we are getting ready to gc after going to the background, well
        // we are back active so skip it.
        unscheduleGcIdler();
        mSomeActivitiesChanged = true;
 
        if (r.profilerInfo != null) {
            mProfiler.setProfiler(r.profilerInfo);
            mProfiler.startProfiling();
        }
 
        // Make sure we are running with the most recent config.
        handleConfigurationChanged(null, null);
 
        if (localLOGV) Slog.v(
            TAG, "Handling launch of " + r);
 
        // Initialize before creating the activity
        if (!ThreadedRenderer.sRendererDisabled
                && (r.activityInfo.flags & ActivityInfo.FLAG_HARDWARE_ACCELERATED) != 0) {
            HardwareRenderer.preload();
        }
        WindowManagerGlobal.initialize();
 
        // Hint the GraphicsEnvironment that an activity is launching on the process.
        GraphicsEnvironment.hintActivityLaunch();
    //1.创建并且加载Activity，调用其onCreate函数。
        final Activity a = performLaunchActivity(r, customIntent);
 
        if (a != null) {
            r.createdConfig = new Configuration(mConfiguration);
            reportSizeConfigurations(r);
            if (!r.activity.mFinished && pendingActions != null) {
                pendingActions.setOldState(r.state);
                pendingActions.setRestoreInstanceState(true);
                pendingActions.setCallOnPostCreate(true);
            }
        } else {
            // If there was an error, for any reason, tell the activity manager to stop us.
            try {
                ActivityTaskManager.getService()
                        .finishActivity(r.token, Activity.RESULT_CANCELED, null,
                                Activity.DONT_FINISH_TASK_WITH_ACTIVITY);
            } catch (RemoteException ex) {
                throw ex.rethrowFromSystemServer();
            }
        }
 
        return a;
    }

```

在上述的ActivityThread.java的方法中，在ActivityThread.java在接收到需要启动Acitivivity的时候，会在ActivityThread的内部类H的handlMessage函数会处理该消息，然后会调用ActivityThread的  
 handleLaunchActivity(ActivityClientRecord r, Intent customIntent, String reason)函数，  
 在这个函数中会创建将要启动的Activity，并且调用其生命周期函数onCreate、onResume。



```
    @Override
    public void handleResumeActivity(IBinder token, boolean finalStateRequest, boolean isForward,
            String reason) {
        // If we are getting ready to gc after going to the background, well
        // we are back active so skip it.
        unscheduleGcIdler();
        mSomeActivitiesChanged = true;

        // TODO Push resumeArgs into the activity for consideration
        final ActivityClientRecord r = performResumeActivity(token, finalStateRequest, reason);
        if (r == null) {
            // We didn't actually resume the activity, so skipping any follow-up actions.
            return;
        }
        if (mActivitiesToBeDestroyed.containsKey(token)) {
            // Although the activity is resumed, it is going to be destroyed. So the following
            // UI operations are unnecessary and also prevents exception because its token may
            // be gone that window manager cannot recognize it. All necessary cleanup actions
            // performed below will be done while handling destruction.
            return;
        }

        final Activity a = r.activity;

        if (localLOGV) {
            Slog.v(TAG, "Resume " + r + " started activity: " + a.mStartedActivity
                    + ", hideForNow: " + r.hideForNow + ", finished: " + a.mFinished);
        }

        final int forwardBit = isForward
                ? WindowManager.LayoutParams.SOFT_INPUT_IS_FORWARD_NAVIGATION : 0;

        // If the window hasn't yet been added to the window manager,
        // and this guy didn't finish itself or start another activity,
        // then go ahead and add the window.
        boolean willBeVisible = !a.mStartedActivity;
        if (!willBeVisible) {
            try {
                willBeVisible = ActivityTaskManager.getService().willActivityBeVisible(
                        a.getActivityToken());
            } catch (RemoteException e) {
                throw e.rethrowFromSystemServer();
            }
        }
        if (r.window == null && !a.mFinished && willBeVisible) {
            r.window = r.activity.getWindow();
            View decor = r.window.getDecorView();
            decor.setVisibility(View.INVISIBLE);

//add core start
            r.window.setStatusBarColor(android.graphics.Color.TRANSPARENT);
//add core end

            ViewManager wm = a.getWindowManager();
            WindowManager.LayoutParams l = r.window.getAttributes();
            a.mDecor = decor;
            l.type = WindowManager.LayoutParams.TYPE_BASE_APPLICATION;
            l.softInputMode |= forwardBit;
....

}
```

在上述的ActivityThread.java的相关源码中，在  
 handleReumeActivity函数又调用了performResumeActivty函数来回调Activity的onResume函数，并且DecorView  
 添加到WindowManager中，最后将Activity的DecorView设置为可见，并且通知ActivityManagerService渲染视图  
 ，因此，在onResume函数之后，Activity就显示在屏幕上了。  
 ActivityThread的main函数被调用之后，依次执行Activity的onCreate、onStart、onResume函数，用户通常在  
 Activity的子类中覆写onCreate方法，并且在其中调用setContentView方法来设置布局。从上文可以知道，  
 在onResume之后，Activity的布局内容就显示到窗口上了。  
 所以在ActivityThread.java的相关源码中，在handleReumeActivity函数中构建布局的时候，在  
 if (r.window == null && !a.mFinished && willBeVisible) 中增加  
 r.window.setStatusBarColor(android.graphics.Color.TRANSPARENT);来设置窗口的状态栏背景为透明背景  
 就实现了功能，  
 注意事项，在某些沉浸式状态栏中，会出现状态栏灰色背景，如果需要去掉沉浸式灰色背景，就需要  
 在 Android 9.0 10.0 沉浸式状态栏导致导航栏状态栏灰色蒙层的解决方案 这篇博文中找到处理方法



