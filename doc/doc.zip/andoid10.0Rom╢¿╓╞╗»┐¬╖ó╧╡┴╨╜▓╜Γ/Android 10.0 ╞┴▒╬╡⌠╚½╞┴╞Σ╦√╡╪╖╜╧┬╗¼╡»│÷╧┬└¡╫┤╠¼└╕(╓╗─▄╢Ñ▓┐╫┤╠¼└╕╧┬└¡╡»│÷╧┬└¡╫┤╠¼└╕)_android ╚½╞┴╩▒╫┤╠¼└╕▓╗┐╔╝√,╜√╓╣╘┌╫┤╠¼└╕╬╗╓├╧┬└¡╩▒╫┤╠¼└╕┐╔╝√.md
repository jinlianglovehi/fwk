






在10.0的设备中，有个客户提出在全屏任意地方下滑都可以下拉出状态栏，所以想改成只能在状态栏的区域下拉滑出下拉状态栏  
 所以根据客户需求来修改这个bug，开始的时候就在framework层找全局手势 看是不是这里的问题  
 可是不是，全局手势只是发出下拉通知 不会弹出下拉状态栏


下面就是全局手势的代码  
 frameworks/base/services/core/java/com/android/server/wm/SystemGesturesPointerEventListener.java



```
 @Override
    public void onPointerEvent(MotionEvent event) {
        if (mGestureDetector != null && event.isTouchEvent()) {
            mGestureDetector.onTouchEvent(event);
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mSwipeFireable = true;
                mDebugFireable = true;
                mDownPointers = 0;
                captureDown(event, 0);
                if (mMouseHoveringAtEdge) {
                    mMouseHoveringAtEdge = false;
                    mCallbacks.onMouseLeaveFromEdge();
                }
                mCallbacks.onDown();
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                captureDown(event, event.getActionIndex());
                if (mDebugFireable) {
                    mDebugFireable = event.getPointerCount() < 5;
                    if (!mDebugFireable) {
                        if (DEBUG) Slog.d(TAG, "Firing debug");
                        mCallbacks.onDebug();
                    }
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (mSwipeFireable) {
                    final int swipe = detectSwipe(event);
                    mSwipeFireable = swipe == SWIPE_NONE;
                    if (swipe == SWIPE_FROM_TOP) {
                        if (DEBUG) Slog.d(TAG, "Firing onSwipeFromTop");
                        mCallbacks.onSwipeFromTop();
                    } else if (swipe == SWIPE_FROM_BOTTOM) {
                        if (DEBUG) Slog.d(TAG, "Firing onSwipeFromBottom");
                        mCallbacks.onSwipeFromBottom();
                    } else if (swipe == SWIPE_FROM_RIGHT) {
                        if (DEBUG) Slog.d(TAG, "Firing onSwipeFromRight");
                        mCallbacks.onSwipeFromRight();
                    } else if (swipe == SWIPE_FROM_LEFT) {
                        if (DEBUG) Slog.d(TAG, "Firing onSwipeFromLeft");
                        mCallbacks.onSwipeFromLeft();
                    }
                }
                break;
            case MotionEvent.ACTION_HOVER_MOVE:
                if (event.isFromSource(InputDevice.SOURCE_MOUSE)) {
                    if (!mMouseHoveringAtEdge && event.getY() == 0) {
                        mCallbacks.onMouseHoverAtTop();
                        mMouseHoveringAtEdge = true;
                    } else if (!mMouseHoveringAtEdge && event.getY() >= screenHeight - 1) {
                        mCallbacks.onMouseHoverAtBottom();
                        mMouseHoveringAtEdge = true;
                    } else if (mMouseHoveringAtEdge
                            && (event.getY() > 0 && event.getY() < screenHeight - 1)) {
                        mCallbacks.onMouseLeaveFromEdge();
                        mMouseHoveringAtEdge = false;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                mSwipeFireable = false;
                mDebugFireable = false;
                mCallbacks.onUpOrCancel();
                break;
            default:
                if (DEBUG) Slog.d(TAG, "Ignoring " + event);
        }
    }

```

在这里也没找到相关的下拉状态栏的代码


最后是由StatusManager下拉状态栏找到灵感  
 路径:frameworks/base/core/java/android/app/StatusBarManager.java



```
@UnsupportedAppUsage
public void expandNotificationsPanel() {
	android.util.Log.e("statusManger","expandNotificationsPanel");
    try {
        final IStatusBarService svc = getService();
        if (svc != null) {
            svc.expandNotificationsPanel();
        }
    } catch (RemoteException ex) {
        throw ex.rethrowFromSystemServer();
    }
}

```

通过日志发现确实执行了这里 但是在framework 下面又找不到哪里有调用这个方法


所以只能全局搜索 expandNotificationsPanel  
 发现在Launcher3的GesturesController.java执行了相关的代码  
 路径：packages/apps/Launcher3/src/com/sprd/ext/gestures/GesturesController.java



```
private final LauncherAppMonitorCallback mAppMonitorCallback = new LauncherAppMonitorCallback() {
        @Override
        public void onLauncherCreated() {
            mGesture = new LauncherRootViewGestures(mMonitor.getLauncher());
            mPullDownAction = Utilities.getPrefs(mContext)
                    .getString(LauncherSettingsExtension.PREF_ONEFINGER_PULLDOWN,
                            mContext.getResources().getString(R.string.default_pull_down_value));
            mPullDownListener = (launcher, gesture) -> {
                if (gesture == Gesture.ONE_FINGER_SLIDE_DOWN) {
                    return doAction(launcher, mPullDownAction);
                }
                return false;
            };
        }

        @Override
        public void onLauncherStart() {
            if (mGesture != null) {
                mGesture.registerOnGestureListener(mPullDownListener);
            }
        }

        @Override
        public void onLauncherStop() {
            if (mGesture != null) {
                mGesture.unregisterOnGestureListener(mPullDownListener);
            }
        }

        @Override
        public void onLauncherDestroy() {
            mPullDownListener = null;
            mGesture = null;
        }
    };

    private boolean doAction(Launcher launcher, String action) {
        switch (action) {
            case SEARCH:
                if (launcher != null) {
                    launcher.onSearchRequested();
                }
                return true;
            case NOTIFICATION:
                UtilitiesExt.openNotifications(mContext);
                return true;
            case NONE:
                //do nothing
                return true;
            default:
                LogUtils.w(TAG, "error action : " + action);
                break;
        }
        return false;
    }

```

在doAction 的 case NOTIFICATION:  
 中UtilitiesExt.java调用打开下拉状态栏的方法  
 路径为:packages/apps/Launcher3/src/com/sprd/ext/UtilitiesExt.java



```
private static Method getExpandNotificationsMethod() throws Exception {
    if (mExpandNotificationsMethod == null) {
        Class clazz = getStatusBarManagerClass();
        mExpandNotificationsMethod = clazz.getDeclaredMethod("expandNotificationsPanel");
    }
    return mExpandNotificationsMethod;
}

public static void openNotifications(Context context){
    try{
        if (getExpandNotificationsMethod() != null) {
            Method method = getExpandNotificationsMethod();
            method.invoke(context.getSystemService("statusbar"));
        }
    } catch(Exception ex) {
        LogUtils.e(TAG, "expand notifications panel failed : ");
        ex.printStackTrace();
    }
}

```

这里通过反射的方式调用了expandNotificationsPanel  
 打开了下拉状态栏 所以具体修改如下:



```
private boolean doAction(Launcher launcher, String action) {
        switch (action) {
            case SEARCH:
                if (launcher != null) {
                    launcher.onSearchRequested();
                }
                return true;
            case NOTIFICATION:
                //UtilitiesExt.openNotifications(mContext);
                return true;
            case NONE:
                //do nothing
                return true;
            default:
                LogUtils.w(TAG, "error action : " + action);
                break;
        }
        return false;
    }

```

注释掉 GesturesController.java 的doAction的NOTIFICATION事件处理方法  
 编译执行发现只有在状态栏下拉 才能弹出下拉状态栏





