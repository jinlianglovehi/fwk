






### 1.概述


在正常设备下root权限会被关闭的，为了系统的安全性所以不会打开，但是在工作中由于功能需求来要求通过属性来控制root权限方便操作一些系统权限


### 2.User版本通过属性来开启或关闭root权限核心代码部分



```
build\make\tools\buildinfo.sh
system/core/adb/daemon/main.cpp
build/make/core/main.mk
system/core/init/selinux.cpp

```

### 3.User版本通过属性来开启或关闭root权限核心代码部分功能分析


### 3.1 首先来增加一个属性来控制是否开启root权限


build\make\tools\buildinfo.sh中增加persist.sys.user.root



```
echo "ro.build.id=$BUILD\_ID"
echo "ro.build.display.id=$BUILD\_DISPLAY\_ID"
echo "ro.build.version.incremental=$BUILD\_NUMBER"
echo "ro.build.version.sdk=$PLATFORM\_SDK\_VERSION"
echo "ro.build.version.preview\_sdk=$PLATFORM\_PREVIEW\_SDK\_VERSION"
echo "ro.build.version.preview\_sdk\_fingerprint=$PLATFORM\_PREVIEW\_SDK\_FINGERPRINT"
echo "ro.build.version.codename=$PLATFORM\_VERSION\_CODENAME"
echo "ro.build.version.all\_codenames=$PLATFORM\_VERSION\_ALL\_CODENAMES"
echo "ro.build.version.release=$PLATFORM\_VERSION"
echo "ro.build.version.security\_patch=$PLATFORM\_SECURITY\_PATCH"
echo "ro.build.version.base\_os=$PLATFORM\_BASE\_OS"
echo "ro.build.version.min\_supported\_target\_sdk=$PLATFORM\_MIN\_SUPPORTED\_TARGET\_SDK\_VERSION"
echo "ro.build.date=`$DATE`"
echo "ro.build.date.utc=`$DATE +%s`"
echo "ro.build.type=$TARGET\_BUILD\_TYPE"
echo "ro.build.user=$BUILD\_USERNAME"
echo "persist.sys.timezone=Asia/Shanghai"
echo "ro.config.media\_vol\_default=20"
echo "ro.product.bt=MID"
+echo "persist.sys.user.root=0"

```

增加一个属性值方便通过设置属性来控制root权限是否打开  
 值为0时表示关闭 为1时表示打开


### 3.2关闭selinux权限 root权限必须关闭selinux权限


在系统seliunx权限的限制下 root权限也是受限的所以就不好控制，需要关闭seliunx功能


在selinux.cpp文件中IsEnforcing()方法中false  
 路径:system/core/init/selinux.cpp



```
bool IsEnforcing() {
{
int fd(open("/mboot/selinux", O_RDONLY | O_CLOEXEC | O_BINARY));
if (fd != -1) {
char v = 0xff;
if (read(fd, &v, 1) < 0)
PLOG(ERROR) << "Failed to read /mboot/selinux";
close(fd);
LOG(WARNING) << "/mboot/selinux is " << v;
return v == '1';
}
}
if (ALLOW_PERMISSIVE_SELINUX) {
return StatusFromCmdline() == SELINUX_ENFORCING;
}
return true;
}

```

修改为:



```
bool IsEnforcing() {
/{int fd(open("/mboot/selinux", O_RDONLY | O_CLOEXEC | O_BINARY));if (fd != -1) {char v = 0xff;if (read(fd, &v, 1) < 0)PLOG(ERROR) << "Failed to read /mboot/selinux";close(fd);LOG(WARNING) << "/mboot/selinux is " << v;return v == '1';}}if (ALLOW_PERMISSIVE_SELINUX) {return StatusFromCmdline() == SELINUX_ENFORCING;}/
return false;
}

```

### 3.3 在system/core/adb/daemon/main.cpp中获取属性值


控制root权限 drop为fasle 不开启root权限 为true开启root权限  
 通过should\_drop\_privileges()的值来是否开启root



```
static bool should\_drop\_privileges() {
// "adb root" not allowed, always drop privileges.
if (!ALLOW_ADBD_ROOT && !is_device_unlocked()) return true;
// The properties that affect `adb root` and `adb unroot` are ro.secure and
// ro.debuggable. In this context the names don't make the expected behavior
// particularly obvious.
//
// ro.debuggable:
//   Allowed to become root, but not necessarily the default. Set to 1 on
//   eng and userdebug builds.
//
// ro.secure:
//   Drop privileges by default. Set to 1 on userdebug and user builds.
bool ro_secure = android::base::GetBoolProperty("ro.secure", true);
bool ro_debuggable = __android_log_is_debuggable();

// Drop privileges if ro.secure is set...
bool drop = ro_secure;

// ... except "adb root" lets you keep privileges in a debuggable build.
std::string prop = android::base::GetProperty("service.adb.root", "");
bool adb_root = (prop == "1");
bool adb_unroot = (prop == "0");
if (ro_debuggable && adb_root) {
    drop = false;
}
// ... and "adb unroot" lets you explicitly drop privileges.
if (adb_unroot) {
    drop = true;
}

return drop;

}

```

修改为:



```
static bool should\_drop\_privileges() {
// "adb root" not allowed, always drop privileges.
// add core start
std::string persist_user_root = android::base::GetProperty("persist.sys.user.secure", "0");
//persist_user_root 为1 开启 0 关闭
if (!ALLOW_ADBD_ROOT && !is_device_unlocked()){
if(!persist_user_root.equal=="1"){
return false;
}else{
return true;
}
}
// add core end
// The properties that affect `adb root` and `adb unroot` are ro.secure and
// ro.debuggable. In this context the names don't make the expected behavior
// particularly obvious.
//
// ro.debuggable:
//   Allowed to become root, but not necessarily the default. Set to 1 on
//   eng and userdebug builds.
//
// ro.secure:
//   Drop privileges by default. Set to 1 on userdebug and user builds.
bool ro_secure = android::base::GetBoolProperty("ro.secure", true);
bool ro_debuggable = __android_log_is_debuggable();

// Drop privileges if ro.secure is set...
bool drop = ro_secure;

// ... except "adb root" lets you keep privileges in a debuggable build.
std::string prop = android::base::GetProperty("service.adb.root", "");
bool adb_root = (prop == "1");
bool adb_unroot = (prop == "0");
if (ro_debuggable && adb_root) {
    drop = false;
}
// ... and "adb unroot" lets you explicitly drop privileges.
if (adb_unroot) {
    drop = true;
}
return drop;

}

```

### 3.4 main.mk脚本中修改如下


地址如下:build/make/core/main.mk



```
diff --git a/build/make/core/main.mk b/build/make/core/main.mk
index c7df0f7..f09692b 100755
--- a/build/make/core/main.mk
+++ b/build/make/core/main.mk
@@ -283,11 +283,11 @@ enable_target_debugging := true
 tags_to_install :=
 ifneq (,$(user\_variant))
   # Target is secure in user builds.
-  ADDITIONAL_DEFAULT_PROPERTIES += ro.secure=1
+  ADDITIONAL_DEFAULT_PROPERTIES += ro.secure=0
   ADDITIONAL_DEFAULT_PROPERTIES += security.perf_harden=1
 
   ifeq ($(user\_variant),user)
-    ADDITIONAL_DEFAULT_PROPERTIES += ro.adb.secure=1
+    ADDITIONAL_DEFAULT_PROPERTIES += ro.adb.secure=0
   endif
 
   # Fix by yubin.chen for remove debug app 2020-11-28 BEGIN #
@@ -296,7 +296,7 @@ ifneq (,$(user\_variant))
     #tags\_to\_install += debug
   else
     # Disable debugging in plain user builds.
-    enable_target_debugging :=
+    #enable\_target\_debugging :=
   endif
   # Fix by yubin.chen for remove debug app 2020-11-28 END #

```

修改ro.adb.secure和ro.secure的值来开启root权限


### 3.5system/core/fs\_mgr/Android.bp中授予root的相关配置



```
--- a/system/core/fs_mgr/Android.bp
+++ b/system/core/fs_mgr/Android.bp
@@ -75,7 +75,8 @@ cc_library {
         "libfstab",
     ],
     cppflags: [
-        "-DALLOW\_ADBD\_DISABLE\_VERITY=0",
+        "-UALLOW\_ADBD\_DISABLE\_VERITY",
+        "-DALLOW\_ADBD\_DISABLE\_VERITY=1",
     ],
     product_variables: {
         debuggable: {
@@ -132,7 +133,8 @@ cc_binary {
         "fs\_mgr\_remount.cpp",
     ],
     cppflags: [
-        "-DALLOW\_ADBD\_DISABLE\_VERITY=0",
+        "-UALLOW\_ADBD\_DISABLE\_VERITY",
+        "-DALLOW\_ADBD\_DISABLE\_VERITY=1",
     ],

```

### 3.6system/sepolicy/Android.mk关于root的相关配置



```
--- a/system/sepolicy/Android.mk
+++ b/system/sepolicy/Android.mk
@@ -309,7 +309,7 @@ LOCAL_REQUIRED_MODULES += \
 
 endif
 
-ifneq ($(TARGET\_BUILD\_VARIANT), user)
+ifneq ($(TARGET\_BUILD\_VARIANT), eng)
 LOCAL_REQUIRED_MODULES += \
     selinux_denial_metadata \
 
@@ -1104,7 +1104,7 @@ endif
 ifneq ($(filter address,$(SANITIZE\_TARGET)),)
   local_fc_files += $(wildcard $(addsuffix /file\_contexts\_asan, $(PLAT\_PRIVATE\_POLICY)))
 endif
-ifneq (,$(filter userdebug eng,$(TARGET\_BUILD\_VARIANT)))
+ifneq (,$(filter user userdebug eng,$(TARGET\_BUILD\_VARIANT)))
   local_fc_files += $(wildcard $(addsuffix /file\_contexts\_overlayfs, $(PLAT\_PRIVATE\_POLICY)))
 endif
 ifeq ($(TARGET\_FLATTEN\_APEX),true)
@@ -1166,7 +1166,7 @@ file_contexts.device.tmp :=
 file_contexts.local.tmp :=
 
 ##################################
-ifneq ($(TARGET\_BUILD\_VARIANT), user)
+ifneq ($(TARGET\_BUILD\_VARIANT), eng)
 include $(CLEAR\_VARS)
 
 LOCAL_MODULE := selinux_denial_metadata

```




