



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2. Launcher3仿ios长按app图标实现抖动动画开始拖拽停止动画的核心代码](#2.%20Launcher3%E4%BB%BFios%E9%95%BF%E6%8C%89app%E5%9B%BE%E6%A0%87%E5%AE%9E%E7%8E%B0%E6%8A%96%E5%8A%A8%E5%8A%A8%E7%94%BB%E5%BC%80%E5%A7%8B%E6%8B%96%E6%8B%BD%E5%81%9C%E6%AD%A2%E5%8A%A8%E7%94%BB%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3. Launcher3仿ios长按app图标实现抖动动画开始拖拽停止动画功能分析以及实现](#3.%20Launcher3%E4%BB%BFios%E9%95%BF%E6%8C%89app%E5%9B%BE%E6%A0%87%E5%AE%9E%E7%8E%B0%E6%8A%96%E5%8A%A8%E5%8A%A8%E7%94%BB%E5%BC%80%E5%A7%8B%E6%8B%96%E6%8B%BD%E5%81%9C%E6%AD%A2%E5%8A%A8%E7%94%BB%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E4%BB%A5%E5%8F%8A%E5%AE%9E%E7%8E%B0)


[3.1 WorkspaceLayoutManager.java长按事件的分析](#%C2%A0%C2%A0%203.1%20WorkspaceLayoutManager.java%E9%95%BF%E6%8C%89%E4%BA%8B%E4%BB%B6%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 ItemLongClickListener关于长按事件分析](#3.2%20ItemLongClickListener%E5%85%B3%E4%BA%8E%E9%95%BF%E6%8C%89%E4%BA%8B%E4%BB%B6%E5%88%86%E6%9E%90)


[3.3 DragController.java关于拖拽的相关方法](#3.3%20DragController.java%E5%85%B3%E4%BA%8E%E6%8B%96%E6%8B%BD%E7%9A%84%E7%9B%B8%E5%85%B3%E6%96%B9%E6%B3%95)




---



## 1.概述


  在做Launcher3定制化开发中，由于看到ios桌面在长按app图标时上下左右抖动的动画，开始拖拽停止动画觉得功能很不错，所以需求要求要在Launcher3中实现这个动画，所以就要从长按事件开始分析添加动画，判断开始拖拽以后停止动画就能满足功能需求了


如图:


![](https://img-blog.csdnimg.cn/49558af363e445e4b85eb5c65c9f46c1.png)



## 2. Launcher3仿ios长按app图标实现抖动动画开始拖拽停止动画的核心代码



```
   packages\apps\Launcher3\src\com\android\launcher3\WorkspaceLayoutManager.java
   packages\apps\Launcher3\src\com\android\launcher3\touch\ItemLongClickListener.java
   packages\apps\Launcher3\src\com\android\launcher3\dragndrop\DragController.java
```

## 3. Launcher3仿ios长按app图标实现抖动动画开始拖拽停止动画功能分析以及实现


## 


在Launcher3的拖拽长按事件的管理类中，就是在WorkspaceLayoutManager.java中负责对拖拽长按事件的响应管理类的，它路径在packages\apps\Launcher3\src\com\android\launcher3\WorkspaceLayoutManager.java，在这个类中，在addInScreen(View child, int container, int screenId, int x, int y,int spanX, int spanY)中主要是绑定workspace的app图标，然后处理长按事件的，所以接下来就需要分析下WorkspaceLayoutManager.java的相关方法


## 


## 3.1 WorkspaceLayoutManager.java长按事件的分析



```
   public interface WorkspaceLayoutManager {
         default void addInScreen(View child, int container, int screenId, int x, int y,
            int spanX, int spanY) {
        if (container == LauncherSettings.Favorites.CONTAINER_DESKTOP) {
            if (getScreenWithId(screenId) == null) {
                Log.e(TAG, "Skipping child, screenId " + screenId + " not found");
                // DEBUGGING - Print out the stack trace to see where we are adding from
                new Throwable().printStackTrace();
                return;
            }
        }
        if (screenId == EXTRA_EMPTY_SCREEN_ID) {
            // This should never happen
            throw new RuntimeException("Screen id should not be EXTRA_EMPTY_SCREEN_ID");
        }

        final CellLayout layout;
        if (container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
            layout = getHotseat();

            // Hide folder title in the hotseat
            if (child instanceof FolderIcon) {
                ((FolderIcon) child).setTextVisible(false);
            }
        } else {
            // Show folder title if not in the hotseat
            if (child instanceof FolderIcon) {
                ((FolderIcon) child).setTextVisible(true);
            }
            layout = getScreenWithId(screenId);
        }

       
        child.setHapticFeedbackEnabled(false);
        child.setOnLongClickListener(ItemLongClickListener.INSTANCE_WORKSPACE);
        if (child instanceof DropTarget) {
            onAddDropTarget((DropTarget) child);
        }
    }
}
```

在上述的WorkspaceLayoutManager.java的相关方法中，对于


addInScreen(View child, int container, int screenId, int x, int y, int spanX, int spanY) 就是绑定  
 workspace中每一屏的元素布局而child.setOnLongClickListener(ItemLongClickListener.INSTANCE\_WORKSPACE);就是设置长按事件所以长按事件是在ItemLongClickListener中，接下来看ItemLongClickListener的相关方法


## 3.2 ItemLongClickListener关于长按事件分析





```
    public class ItemLongClickListener {

    public static OnLongClickListener INSTANCE_WORKSPACE =
            ItemLongClickListener::onWorkspaceItemLongClick;

    public static OnLongClickListener INSTANCE_ALL_APPS =
            ItemLongClickListener::onAllAppsItemLongClick;
    private static boolean onWorkspaceItemLongClick(final View v) {
        Launcher launcher = Launcher.getLauncher(v.getContext());
        if (!canStartDrag(launcher)) return false;
        if (!launcher.isInState(NORMAL) && !launcher.isInState(OVERVIEW)) return false;
        if (!(v.getTag() instanceof ItemInfo)) return false;

        launcher.setWaitingForResult(null);
        beginDrag(v, launcher, (ItemInfo) v.getTag(), new DragOptions());
        return true;
    }
```

在上述的ItemLongClickListener.java的相关方法中，在OnLongClickListener INSTANCE\_WORKSPACE =  
             ItemLongClickListener::onWorkspaceItemLongClick;这里就表示处理的是


在launcher3中的app拖拽的长按事件处理，所以需要接下来分析下，如何添加长按拖拽抖动事件


的相关功能，


下面添加长按抖动动画的相关自定义类，然后把这里方法添加到长按事件里面去具体实现如下:



```
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
    private static boolean onWorkspaceItemLongClick(final View v) {
    // add core start
		android.util.Log.e("AllApps","onWorkspaceItemLongClick");
        AnimationSet set = new AnimationSet(false);
        TranslateAnimation lefttranslateAnimation=new TranslateAnimation(0,-20,0,-20);
                lefttranslateAnimation.setDuration(200);
                lefttranslateAnimation.setRepeatCount(3);
                lefttranslateAnimation.setRepeatMode(Animation.REVERSE);
                final TranslateAnimation left_downtranslateAnimation=new TranslateAnimation(0,-20,0,20);
                left_downtranslateAnimation.setDuration(200);
                left_downtranslateAnimation.setRepeatCount(3);
                left_downtranslateAnimation.setRepeatMode(Animation.REVERSE);
                final TranslateAnimation right_uptranslateAnimation=new TranslateAnimation(0,20,0,-20);
                right_uptranslateAnimation.setDuration(200);
                right_uptranslateAnimation.setRepeatCount(3);
                right_uptranslateAnimation.setRepeatMode(Animation.REVERSE);
                final TranslateAnimation translateAnimation=new TranslateAnimation(0,20,0,20);
                translateAnimation.setDuration(200);
                translateAnimation.setRepeatCount(3);
                translateAnimation.setRepeatMode(Animation.REVERSE);

                set.addAnimation(lefttranslateAnimation);
                v.setAnimation(set);
                
                lefttranslateAnimation.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        v.startAnimation(left_downtranslateAnimation);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
                left_downtranslateAnimation.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        v.startAnimation(right_uptranslateAnimation);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
                right_uptranslateAnimation.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        v.startAnimation(translateAnimation);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
        v.startAnimation(set);
   // add core end

        Launcher launcher = Launcher.getLauncher(v.getContext());
        if (!canStartDrag(launcher)) return false;
        if (!launcher.isInState(NORMAL) && !launcher.isInState(OVERVIEW)) return false;
        if (!(v.getTag() instanceof ItemInfo)) return false;

        launcher.setWaitingForResult(null);
        beginDrag(v, launcher, (ItemInfo) v.getTag(), new DragOptions());
        return true;
    }
    public static void beginDrag(View v, Launcher launcher, ItemInfo info,
            DragOptions dragOptions) {
        if (info.container >= 0) {
            Folder folder = Folder.getOpen(launcher);
            if (folder != null) {
                if (!folder.getItemsInReadingOrder().contains(v)) {
                    folder.close(true);
                } else {
                    folder.startDrag(v, dragOptions);
                    return;
                }
            }
        }

        // add core start 添加方法把当前长按view赋值给DragController方便停止动画
         DragController dragController = launcher.getDragController();
        dragController.setCurMoveView(v);
       // add core end

        CellLayout.CellInfo longClickCellInfo = new CellLayout.CellInfo(v, info);
        launcher.getWorkspace().startDrag(longClickCellInfo, dragOptions);
    }
```

虽然动画添加成功了 但是要在开始拖拽的时候停止动画 这就需要在DragController.java处理 这里面有开始拖拽 停止拖拽 拖拽距离等相关方法


## 3.3 DragController.java关于拖拽的相关方法


在Launcher和WorkSpace的布局中，对于.Launcher的onLongClick事件会调用WorkSpace的startDrag方法,startDrag方法会调用beginDragShared方法, beginDragShared方法最终调用DragController的startDrag方法 startDrag的重载方法,不过我不知道它是什么时候执行的,这个重载方法最终还是进入到图中的startDrag方法.  
 根据传入的一些参数创建了一个DragView,DragView就是我们拖动图标的时候显示的图片




```
   public class DragController implements DragDriver.EventListener, TouchController {
   // 添加当前长按View的相关方法
    + private View mCurMoveView;
    // 上次拖拽坐标
     +   private int mLastDragX=-1,mLastDragY=-1;
     +    public void setCurMoveView(View view){
     +		mCurMoveView = view;
     +   }
private void handleMoveEvent(int x, int y) {
        if (TestProtocol.sDebugTracing) {
            android.util.Log.d(TestProtocol.NO_DRAG_TAG,
                    "handleMoveEvent 1");
        }

        mDragObject.dragView.move(x, y);
        // Drop on someone?
        final int[] coordinates = mCoordinatesTemp;
        DropTarget dropTarget = findDropTarget(x, y, coordinates);
        mDragObject.x = coordinates[0];
        mDragObject.y = coordinates[1];
        checkTouchMove(dropTarget);

        // Check if we are hovering over the scroll areas
        mDistanceSinceScroll += Math.hypot(mLastTouch[0] - x, mLastTouch[1] - y);
        mLastTouch[0] = x;
        mLastTouch[1] = y;

        if (TestProtocol.sDebugTracing) {
           Log.d(TestProtocol.NO_DRAG_TAG,
                    "handleMoveEvent Conditions " +
                            mIsInPreDrag + ", " +
                            (mIsInPreDrag && mOptions.preDragCondition != null) + ", " +
                            (mIsInPreDrag && mOptions.preDragCondition != null
                                    && mOptions.preDragCondition.shouldStartDrag(
                                    mDistanceSinceScroll)));
        }

        if (mIsInPreDrag && mOptions.preDragCondition != null
                && mOptions.preDragCondition.shouldStartDrag(mDistanceSinceScroll)) {
            if (TestProtocol.sDebugTracing) {
                android.util.Log.d(TestProtocol.NO_DRAG_TAG,
                        "handleMoveEvent 2");
            }
            callOnDragStart();
        }
    }
在handleMoveEvent(int x, int y) 是计算当前拖拽后坐标值 所以在这里计算当前坐标和上一次坐标值做比较

private void handleMoveEvent(int x, int y) {
        if (TestProtocol.sDebugTracing) {
            android.util.Log.d(TestProtocol.NO_DRAG_TAG,
                    "handleMoveEvent 1");
        }

        // add core start  计算当前坐标和上一次坐标值做比较超过10 就停止动画
		if(mLastDragY!=-1&&mLastDragX!=-1){
		  if(mLastDragX-x>10||mLastDragX-x<-10||mLastDragY-y>10||mLastDragY-y<-10){
			 android.util.Log.e("AllApps","clearAnimation");
			 mCurMoveView.clearAnimation();
		  }
		}
       // add core end

        mDragObject.dragView.move(x, y);

// add core start
        mLastDragX = x;
        mLastDragY = y;
// add core end

        // Drop on someone?
        final int[] coordinates = mCoordinatesTemp;
        DropTarget dropTarget = findDropTarget(x, y, coordinates);
        mDragObject.x = coordinates[0];
        mDragObject.y = coordinates[1];
        checkTouchMove(dropTarget);

        // Check if we are hovering over the scroll areas
        mDistanceSinceScroll += Math.hypot(mLastTouch[0] - x, mLastTouch[1] - y);
        mLastTouch[0] = x;
        mLastTouch[1] = y;

        if (TestProtocol.sDebugTracing) {
           Log.d(TestProtocol.NO_DRAG_TAG,
                    "handleMoveEvent Conditions " +
                            mIsInPreDrag + ", " +
                            (mIsInPreDrag && mOptions.preDragCondition != null) + ", " +
                            (mIsInPreDrag && mOptions.preDragCondition != null
                                    && mOptions.preDragCondition.shouldStartDrag(
                                    mDistanceSinceScroll)));
        }

        if (mIsInPreDrag && mOptions.preDragCondition != null
                && mOptions.preDragCondition.shouldStartDrag(mDistanceSinceScroll)) {
            if (TestProtocol.sDebugTracing) {
                android.util.Log.d(TestProtocol.NO_DRAG_TAG,
                        "handleMoveEvent 2");
            }
            callOnDragStart();
        }
    }
 接下来需要在结束拖动后 坐标值清零
    private void endDrag() {
    // add core start
		mLastDragX=-1;
		mLastDragY=-1;
// add core end

        if (isDragging()) {
            mDragDriver = null;
            boolean isDeferred = false;
            if (mDragObject.dragView != null) {
                isDeferred = mDragObject.deferDragViewCleanupPostAnimation;
                if (!isDeferred) {
                    mDragObject.dragView.remove();
                } else if (mIsInPreDrag) {
                    animateDragViewToOriginalPosition(null, null, -1);
                }
                mDragObject.dragView = null;
            }

            // Only end the drag if we are not deferred
            if (!isDeferred) {
                callOnDragEnd();
            }
        }

        mFlingToDeleteHelper.releaseVelocityTracker();
    }
```

通过上述添加自定义抖动功能的相关工具类，然后在长按拖拽app图标时，调用抖动图标的相关功能来实现长按图标拖拽抖动的功能，就最终实现了功能的开发



