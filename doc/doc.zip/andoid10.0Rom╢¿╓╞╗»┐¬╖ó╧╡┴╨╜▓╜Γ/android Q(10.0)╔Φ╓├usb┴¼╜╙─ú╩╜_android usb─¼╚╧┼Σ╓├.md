






### 1.概述


在10.0的产品定制化开发中，在产品开发中usb的默认连接方式很重要，所以产品需求默认需要设置  
 产品的usb连接模式，来实现对功能的快速开发，所以要分析usb连接模式然后设置默认连接方式


### 2.设置usb连接模式的核心类



```
frameworks/base/services/usb/java/com/android/server/usb/UsbDeviceManager.java

```

### 3.设置usb连接模式的核心功能分析和实现


### 3.1当USB连接安装设备时，USB连接流程



```
 onPreferenceChange -> DevelopmentSettings.java 点击后响应
	writeUsbConfigurationOption ->
	  manager.setCurrentFunction ->
		setCurrentFunction -> UsbManager.java
		  mService.setCurrentFunction ->
			setCurrentFunction -> UsbService.java
			  mDeviceManager.setCurrentFunctions ->
				setCurrentFunctions -> UsbDeviceManager.java
				   mHandler.sendMessage -> //MSG_SET_CURRENT_FUNCTIONS
					 handleMessage ->
					   setEnabledFunctions ->
						 trySetEnabledFunctions ->
						   setUsbConfig -> 
						     SystemProperties.set ->  //设置属性USB_CONFIG_PROPERTY，即sys.usb.config

```

根据流程可以看出来是通过 UsbManager和UsbDeviceManager来设置连接模式的  
 所以就从这入手来设置连接模式


### 3.2 UsbDeviceManager关于usb默认连接方式分析


在系统中对于usb设备的管理 都是在UsbDeviceManager.java中处理的，接下来  
 看下关于设置usb连接方式的处理



```

  public class UsbDeviceManager implements ActivityTaskManagerInternal.ScreenObserver {
public UsbDeviceManager(Context context, UsbAlsaManager alsaManager,
              UsbSettingsManager settingsManager) {
          mContext = context;
          mContentResolver = context.getContentResolver();
          PackageManager pm = mContext.getPackageManager();
          mHasUsbAccessory = pm.hasSystemFeature(PackageManager.FEATURE_USB_ACCESSORY);
          initRndisAddress();
  
          boolean halNotPresent = false;
          try {
              IUsbGadget.getService(true);
          } catch (RemoteException e) {
              Slog.e(TAG, "USB GADGET HAL present but exception thrown", e);
          } catch (NoSuchElementException e) {
              halNotPresent = true;
              Slog.i(TAG, "USB GADGET HAL not present in the device", e);
          }
  
          mControlFds = new HashMap<>();
          FileDescriptor mtpFd = nativeOpenControl(UsbManager.USB_FUNCTION_MTP);
          if (mtpFd == null) {
              Slog.e(TAG, "Failed to open control for mtp");
          }
          mControlFds.put(UsbManager.FUNCTION_MTP, mtpFd);
          FileDescriptor ptpFd = nativeOpenControl(UsbManager.USB_FUNCTION_PTP);
          if (ptpFd == null) {
              Slog.e(TAG, "Failed to open control for ptp");
          }
          mControlFds.put(UsbManager.FUNCTION_PTP, ptpFd);
  
          if (halNotPresent) {
              /**
               * Initialze the legacy UsbHandler
               */
              mHandler = new UsbHandlerLegacy(FgThread.get().getLooper(), mContext, this,
                      alsaManager, settingsManager);
          } else {
              /**
               * Initialize HAL based UsbHandler
               */
              mHandler = new UsbHandlerHal(FgThread.get().getLooper(), mContext, this,
                      alsaManager, settingsManager);
          }
  
          if (nativeIsStartRequested()) {
              if (DEBUG) Slog.d(TAG, "accessory attached at boot");
              startAccessoryMode();
          }
  
          BroadcastReceiver portReceiver = new BroadcastReceiver() {
              @Override
              public void onReceive(Context context, Intent intent) {
                  ParcelableUsbPort port = intent.getParcelableExtra(UsbManager.EXTRA_PORT);
                  UsbPortStatus status = intent.getParcelableExtra(UsbManager.EXTRA_PORT_STATUS);
                  mHandler.updateHostState(
                          port.getUsbPort(context.getSystemService(UsbManager.class)), status);
              }
          };
  
          BroadcastReceiver chargingReceiver = new BroadcastReceiver() {
              @Override
              public void onReceive(Context context, Intent intent) {
                  int chargePlug = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
                  boolean usbCharging = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
                  mHandler.sendMessage(MSG_UPDATE_CHARGING_STATE, usbCharging);
              }
          };
  
          BroadcastReceiver hostReceiver = new BroadcastReceiver() {
              @Override
              public void onReceive(Context context, Intent intent) {
                  Iterator devices = ((UsbManager) context.getSystemService(Context.USB\_SERVICE))
                          .getDeviceList().entrySet().iterator();
                  if (intent.getAction().equals(UsbManager.ACTION_USB_DEVICE_ATTACHED)) {
                      mHandler.sendMessage(MSG_UPDATE_HOST_STATE, devices, true);
                  } else {
                      mHandler.sendMessage(MSG_UPDATE_HOST_STATE, devices, false);
                  }
              }
          };
  
          BroadcastReceiver languageChangedReceiver = new BroadcastReceiver() {
              @Override
              public void onReceive(Context context, Intent intent) {
                  mHandler.sendEmptyMessage(MSG_LOCALE_CHANGED);
              }
          };
  
          mContext.registerReceiver(portReceiver,
                  new IntentFilter(UsbManager.ACTION_USB_PORT_CHANGED));
          mContext.registerReceiver(chargingReceiver,
                  new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
  
          IntentFilter filter =
                  new IntentFilter(UsbManager.ACTION_USB_DEVICE_ATTACHED);
          filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
          mContext.registerReceiver(hostReceiver, filter);
  
          mContext.registerReceiver(languageChangedReceiver,
                  new IntentFilter(Intent.ACTION_LOCALE_CHANGED));
  
          // Watch for USB configuration changes
          mUEventObserver = new UsbUEventObserver();
          mUEventObserver.startObserving(USB_STATE_MATCH);
          mUEventObserver.startObserving(ACCESSORY_START_MATCH);
      }
  
      public void systemReady() {
          if (DEBUG) Slog.d(TAG, "systemReady");
  
          LocalServices.getService(ActivityTaskManagerInternal.class).registerScreenObserver(this);
  
          mHandler.sendEmptyMessage(MSG_SYSTEM_READY);
      }
  
      public void bootCompleted() {
          if (DEBUG) Slog.d(TAG, "boot completed");
          mHandler.sendEmptyMessage(MSG_BOOT_COMPLETED);
      }
 

```

在UsbDeviceManager 的构造源码中可以看到usb连接模式可以在启动完毕在finishBoot()  
 调用mOemLockManager.setOemUnlockAllowedByUser(true)设置



```
diff --git a/frameworks/base/services/usb/java/com/android/server/usb/UsbDeviceManager.java b/frameworks/base/services/usb/java/com/android/server/usb/UsbDeviceManager.java
index 8ec47bac33..7de64062b5 100755
--- a/frameworks/base/services/usb/java/com/android/server/usb/UsbDeviceManager.java
+++ b/frameworks/base/services/usb/java/com/android/server/usb/UsbDeviceManager.java
@@ -1127,6 +1127,8 @@ public class UsbDeviceManager implements ActivityTaskManagerInternal.ScreenObser
         }
 
         protected void finishBoot() {
+                       android.service.oemlock.OemLockManager mOemLockManager = (android.service.oemlock.OemLockManager) mContext.getSystemService(Context.OEM_LOCK_SERVICE);
+                       mOemLockManager.setOemUnlockAllowedByUser(true);
             if (mBootCompleted && mCurrentUsbFunctionsReceived && mSystemReady) {
                 if (mPendingBootBroadcast) {
                     updateUsbStateBroadcastIfNeeded(getAppliedFunctions(mCurrentFunctions));

```

### 3.3 设置当前连接模式


增加自定义方法来设置当前usb连接模式



```
 public void setUSBDataDisabled(boolean disabled)  {
        Log.e(TAG,"setUSBDataDisabled:" + disabled);
        UsbManager mUsbManager = mContext.getSystemService(UsbManager.class);
        mUsbManager.setCurrentFunctions(disabled ? UsbManager.FUNCTION_NONE : UsbManager.FUNCTION_MTP);
    }

```

在setUSBDataDisabled连接模式为MTP连接模式


3.4获取当前连接模式  
 增加自定义方法设置当前usb连接模式



```
  public boolean isUSBDataDisabled()  {
        UsbManager mUsbManager = mContext.getSystemService(UsbManager.class);
        long currentFunctions = mUsbManager.getCurrentFunctions();
        boolean disable = (UsbManager.FUNCTION_MTP != currentFunctions);
        Log.e(TAG,"isUSBDataDisabled:" + disable);
        return disable;
    }

```




