



## 1.前言


 在10.0的系统产品开发中，在wifi模块也很重要，但是在某些情况下对于一些wifi连接成功后，确显示已连接成功，但是无法访问互联网  
 的情况，所以实际上这时可以正常上网的，就是显示的不正常，所以就需要分析连接流程然后解决问题 如图所示


![](https://img-blog.csdnimg.cn/fe26b15d59a24656a047f538d2a90658.png)


## 2.系统wifi列表显示已连接但无法访问网络问题解决的核心类



```
frameworks\opt\net\wifi\service\java\com\android\server\wifi\WifiConnectivityManager.java
packages\modules\NetworkStack\src\com\android\server\connectivity\NetworkMonitor.java
packages\modules\NetworkStack\res\values\config.xml
```

## 3.系统wifi列表显示已连接但无法访问网络问题解决的核心功能分析和解决


使用现象:在机器连接国内wifi成功之后，但是在系统settings的wifi连接界面显示已连接但无法访问互联网，同时systemUI会提示当前网络不可用，是否要保持连接的弹框。  
 这其实没收到是google的204服务器的回调结果，就会出现这样的情况  
 在Android系统中，关于wifi模块系统引入的网络评估机制，当机器连上网络后，这时网络会给目标产生204响应的服务器发送给一个请求，如果服务器返回的是状态码为204的响应，那么就被认为网络可以访问；否则，  
 如果返回的是其他状态码，那么将被视为网络访问需要登录操作等；没有响应的话，就被认为是网络不可访问。所以这种情况下就会  
 显示虽然网络可以访问，但是显示连接已成功无法访问互联网的字样，其实就是国内的机器在访问谷歌的204服务器的时候，网络  
 受限会出现这样的情况  
 Android系统默认测试网络的连接是用的google相关的域名，在国内网络无法访问，所以造成这样的情况


## 3.1 WifiConnectivityManager.java关于网络连接的相关代码分析



```
private boolean handleScanResults(List<ScanDetail> scanDetails, String listenerName) {
        //NOTE: Support wifi-p2p do not coexist BEG-->
        if (!WifiFeaturesUtils.FeatureProperty.SUPPORT_SPRD_WIFI_COEXIST_P2P
            && WifiP2pServiceImpl.mP2pConnectingOrConnected) {
            Log.i(TAG, "Do not auto connect when wifi and p2p should not coexsit");
            return false;
        }
        //<-- Support wifi-p2p do not coexist END

        if (mSupportAppConnectPolicy && mWifiFeaturesUtils.isAutoConnect() == false) {
            Log.i(TAG, "WifiFeaturesUtils isAutoConnect false,  " + mWifiFeaturesUtils.isAutoConnect());
            return false;
        }

        // Check if any blacklisted BSSIDs can be freed.
        refreshBssidBlacklist();

        if (mStateMachine.isSupplicantTransientState()) {
            localLog(listenerName
                    + " onResults: No network selection because supplicantTransientState is "
                    + mStateMachine.isSupplicantTransientState());
            return false;
        }

        localLog(listenerName + " onResults: start network selection");

        WifiConfiguration candidate =
                mNetworkSelector.selectNetwork(scanDetails, buildBssidBlacklist(), mWifiInfo,
                mStateMachine.isConnected(), mStateMachine.isDisconnected(),
                mUntrustedConnectionAllowed);
        mWifiLastResortWatchdog.updateAvailableNetworks(
                mNetworkSelector.getConnectableScanDetails());
        mWifiMetrics.countScanResults(scanDetails);
        if (candidate != null) {
            localLog(listenerName + ":  WNS candidate-" + candidate.SSID);
            connectToNetwork(candidate);
            return true;
        } else {
            if (mWifiState == WIFI_STATE_DISCONNECTED) {
                mOpenNetworkNotifier.handleScanResults(
                        mNetworkSelector.getFilteredScanDetailsForOpenUnsavedNetworks());
                if (mCarrierNetworkConfig.isCarrierEncryptionInfoAvailable()) {
                    mCarrierNetworkNotifier.handleScanResults(
                            mNetworkSelector.getFilteredScanDetailsForCarrierUnsavedNetworks(
                                    mCarrierNetworkConfig));
                }
            }
            return false;
        }
    }
```

在上述的WifiConnectivityManager.java的相关源码中，分析得知，在handleScanResults(List<ScanDetail> scanDetails, String listenerName)中，  
 WifiConnectivityManager 内部类 AllSingleScanListener 的 onResults 方法会在接收到扫描结果后被调用  
 onResults 的其中这一行调用 handleScanResults 方法连接选出的网络，接下来看下NetworkMonitor.java中  
 关于对google的204服务器的回调结果的相关源码分析


## 3.2 NetworkMonitor.java关于网络限制的相关代码分析



```

        mCaptivePortalHttpsUrl = makeURL(getCaptivePortalServerHttpsUrl());
        mCaptivePortalHttpUrl = makeURL(getCaptivePortalServerHttpUrl());

    private String getCaptivePortalServerHttpsUrl() {
        return getSettingFromResource(mContext, R.string.config_captive_portal_https_url,
                R.string.default_captive_portal_https_url, CAPTIVE_PORTAL_HTTPS_URL);
    }
    /**
     * Get the captive portal server HTTP URL that is configured on the device.
     *
     * NetworkMonitor does not use {@link ConnectivityManager#getCaptivePortalServerUrl()} as
     * it has its own updatable strategies to detect captive portals. The framework only advises
     * on one URL that can be used, while NetworkMonitor may implement more complex logic.
     */
    public String getCaptivePortalServerHttpUrl() {
        return getSettingFromResource(mContext, R.string.config_captive_portal_http_url,
                R.string.default_captive_portal_http_url, CAPTIVE_PORTAL_HTTP_URL);
    }
    @VisibleForTesting
    protected CaptivePortalProbeResult isCaptivePortal() {
        if (!mIsCaptivePortalCheckEnabled) {
            validationLog("Validation disabled.");
            return CaptivePortalProbeResult.SUCCESS;
        }

        URL pacUrl = null;
        URL httpsUrl = mCaptivePortalHttpsUrl;
        URL httpUrl = mCaptivePortalHttpUrl;

        final ProxyInfo proxyInfo = mLinkProperties.getHttpProxy();
        if (proxyInfo != null && !Uri.EMPTY.equals(proxyInfo.getPacFileUrl())) {
            pacUrl = makeURL(proxyInfo.getPacFileUrl().toString());
            if (pacUrl == null) {
                return CaptivePortalProbeResult.FAILED;
            }
        }

        if ((pacUrl == null) && (httpUrl == null || httpsUrl == null)) {
            return CaptivePortalProbeResult.FAILED;
        }

        long startTime = SystemClock.elapsedRealtime();

        final CaptivePortalProbeResult result;
        if (pacUrl != null) {
            result = sendDnsAndHttpProbes(null, pacUrl, ValidationProbeEvent.PROBE_PAC);
            reportHttpProbeResult(NETWORK_VALIDATION_PROBE_HTTP, result);
        } else if (mUseHttps) {
            // Probe results are reported inside sendParallelHttpProbes.
            result = sendParallelHttpProbes(proxyInfo, httpsUrl, httpUrl);
        } else {
            result = sendDnsAndHttpProbes(proxyInfo, httpUrl, ValidationProbeEvent.PROBE_HTTP);
            reportHttpProbeResult(NETWORK_VALIDATION_PROBE_HTTP, result);
        }

        long endTime = SystemClock.elapsedRealtime();

        sendNetworkConditionsBroadcast(true /* response received */,
                result.isPortal() /* isCaptivePortal */,
                startTime, endTime);

        log("isCaptivePortal: isSuccessful()=" + result.isSuccessful()
                + " isPortal()=" + result.isPortal()
                + " RedirectUrl=" + result.redirectUrl
                + " isPartialConnectivity()=" + result.isPartialConnectivity()
                + " Time=" + (endTime - startTime) + "ms");

        return result;
    }
```

在NetworkMonitor.java的上述相关源码中，在 CaptivePortalProbeResult isCaptivePortal()  
 这里主要判断是否开启wifi连接成功后，网络检测的服务，就是开启网络评估机制的相关功能，  
 在这里主要的根据        URL httpsUrl = mCaptivePortalHttpsUrl;和URL httpUrl = mCaptivePortalHttpUrl;  
 这两个google的204的服务器回调结果，来判断当前网络是否可以访问互联网的，但是过年的  
 wifi可能对这个204的服务器访问不是很好，就会出现上面的结果


## 3.3 config.xml中添加204的相关网址



```
  <!-- Configuration hooks for the above settings.
         Empty by default but may be overridden by RROs. -->
    <integer name="config_captive_portal_dns_probe_timeout"></integer>
    <!--suppress CheckTagEmptyBody: overlayable resource to use as configuration hook -->
    <string name="config_captive_portal_http_url" translatable="false"></string>
    <!--suppress CheckTagEmptyBody: overlayable resource to use as configuration hook -->
    <string name="config_captive_portal_https_url" translatable="false"></string>
    <string-array name="config_captive_portal_fallback_urls" translatable="false">
    </string-array>
    <string-array name="config_captive_portal_fallback_probe_specs" translatable="false">
    </string-array>

```

在config.xml中，相关源码看出，在config\_captive\_portal\_http\_url和config\_captive\_portal\_https\_url这两个  
 属性中发现都是空，所以可以添加上可以访问的204地址，具体修改为



```
 -   <string name="config_captive_portal_http_url" translatable="false"></string>
    <!--suppress CheckTagEmptyBody: overlayable resource to use as configuration hook -->
-    <string name="config_captive_portal_https_url" translatable="false"></string>

+    <string name="config_captive_portal_http_url" translatable="false">http://connect.rom.miui.com/generate_204</string>
    <!--suppress CheckTagEmptyBody: overlayable resource to use as configuration hook -->
+    <string name="config_captive_portal_https_url" translatable="false">https://connect.rom.miui.com/generate_204</string>
```



