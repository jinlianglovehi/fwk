






### 1.概述


在10.0的系统产品开发中，在锁屏界面默认是显示导航栏的，但是客户要求在锁屏解锁界面不要导航栏，所以又得定制化锁屏界面去掉导航栏


### 2.SystemUI锁屏解锁界面（KeyguardHostView）隐藏导航栏（NavigationBarFragment）的核心类



```
frameworks/base/packages/SystemUI/src/com/android/keyguard/KeyguardHostView.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarFragment.java

```

### 3.SystemUI锁屏解锁界面（KeyguardHostView）隐藏导航栏（NavigationBarFragment）的核心功能分析和实现


实现思路:


1. 在锁屏解锁界面系统数据库写标志位1隐藏导航栏 解锁后标志位为0,显示导航栏
2. 导航栏界面 监听数值的变化 做显示和隐藏导航栏操作


先看锁屏解锁界面 KeyguardHostView.java  
 思路:  
 1.在进入解锁界面时 OnResume() 标志位只为0 隐藏状态栏  
 2.在离开解锁界面时，标志位只为1 显示状态栏


### 3.1KeyguardHostView.java关于锁屏解锁的监听



```
diff --git a/frameworks/base/packages/SystemUI/src/com/android/keyguard/KeyguardHostView.java b/frameworks/base/packages/SystemUI/src/com/android/keyguard/KeyguardHostView.java

old mode 100644

new mode 100755

index b5ff148fe7..22c5d4d8bf

--- a/frameworks/base/packages/SystemUI/src/com/android/keyguard/KeyguardHostView.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/keyguard/KeyguardHostView.java

@@ -36,7 +36,7 @@ import com.android.keyguard.KeyguardSecurityContainer.SecurityCallback;

 import com.android.keyguard.KeyguardSecurityModel.SecurityMode;

 import com.android.settingslib.Utils;

 import com.android.systemui.plugins.ActivityStarter.OnDismissAction;

-

+import android.provider.Settings;

 import java.io.File;

 

 /**

@@ -103,7 +103,7 @@ public class KeyguardHostView extends FrameLayout implements SecurityCallback {

     private static final boolean KEYGUARD_MANAGES_VOLUME = false;

     public static final boolean DEBUG = KeyguardConstants.DEBUG;

     private static final String TAG = "KeyguardViewBase";

-

+    private Context mContext;//add code

     private KeyguardSecurityContainer mSecurityContainer;

 

     public KeyguardHostView(Context context) {

@@ -113,6 +113,7 @@ public class KeyguardHostView extends FrameLayout implements SecurityCallback {

     public KeyguardHostView(Context context, AttributeSet attrs) {

         super(context, attrs);

         KeyguardUpdateMonitor.getInstance(context).registerCallback(mUpdateCallback);

+               mContext = context;

     }

```

在这里给KeyguardHostView.java添加一些系统参数方便调用


在 dismiss() 当解锁界面消失时调用，然后设置show\_nav\_button的值来方便  
 显示和隐藏导航栏



```
     @Override

@@ -211,6 +212,12 @@ public class KeyguardHostView extends FrameLayout implements SecurityCallback {

 

     @Override

     public boolean dismiss(boolean authenticated, int targetUserId) {

+               //add code start

+               int showNavRightButton = Settings.System.getInt(mContext.getContentResolver(),"show\_nav\_button",1);

+               if(showNavRightButton == 0){

+                       Settings.System.putInt(mContext.getContentResolver(),"show\_nav\_button",1);

+               }

+               //add code end

         if (DEBUG) Log.d(TAG , "dismiss and showNextSecurityScreenOrFinish authenticated =" + authenticated  + " caller:"+android.os.Debug.getCallers(12

));

         return mSecurityContainer.showNextSecurityScreenOrFinish(authenticated, targetUserId);

     }

```

onResume（）当进入解锁界面时调用  
 在 onResume（）当解锁界面消失时调用，根据是否锁屏然后设置show\_nav\_button的值来方便  
 显示和隐藏导航栏



```
@@ -291,6 +298,17 @@ public class KeyguardHostView extends FrameLayout implements SecurityCallback {

 /**
     * Called when the Keyguard is actively shown on the screen.
     */
    public void onResume() {
        if (DEBUG) Log.d(TAG, "screen on, instance " + Integer.toHexString(hashCode()));
        mSecurityContainer.onResume(KeyguardSecurityView.SCREEN_ON);
        requestFocus();

+               //add code start

+               boolean lock  = mLockPatternUtils.isSecure(KeyguardUpdateMonitor.getCurrentUser());

+               if(lock){

+                       Settings.System.putInt(mContext.getContentResolver(),"show\_nav\_button",0);

+               }else {

+                       int showNavRightButton = Settings.System.getInt(mContext.getContentResolver(),"show\_nav\_button",1);

+                       if(showNavRightButton == 0){

+                               Settings.System.putInt(mContext.getContentResolver(),"show\_nav\_button",1);

+                       }

+               }

+               //add code end

     }

```

### 3.2NavigationBarFragment 导航栏界面


当监听到标志位变化时，做显示和隐藏的操作



```
    /**

diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarFragment.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarFragment.java

index 57766f595d..5ef9682f4e 100755

--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarFragment.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarFragment.java

@@ -447,8 +447,45 @@ public class NavigationBarFragment extends LifecycleFragment implements Callback

         if (mScreenDecorations != null) {

             getBarTransitions().addDarkIntensityListener(mScreenDecorations);

         }

+               //add code start

+                  getContext().getContentResolver().registerContentObserver(

+                Settings.System.getUriFor("show\_nav\_button"), true,

+                mNavigationRightBarShowObserver);

+               //add code end

     }

 

+       //add code start

+    private final ContentObserver mNavigationRightBarShowObserver = new ContentObserver(new Handler()) {

+        @Override

+        public void onChange(boolean selfChange) {

+            boolean lock = Settings.System.getInt(getContext().getContentResolver(), "show\_nav\_button", 0) == 0;

+                       android.util.Log.e("junjie","lock :"+lock);

+            if (lock) {

+                //hide

+                               mNavigationBarView.getBluetoothButton().setVisibility(View.GONE);

+                       mNavigationBarView.getBrightnessButton().setVisibility(View.GONE);

+                       mNavigationBarView.getVolumeButton().setVisibility(View.GONE);

+                               mNavigationBarView.getWifiButton().setVisibility(View.GONE);

+                               mNavigationBarView.getKeyboardButton().setVisibility(View.GONE);

+                               mNavigationBarView.getClock().setVisibility(View.GONE);

+                               mNavigationBarView.getmBattery().setVisibility(View.GONE);

+                               mNavigationBarView.getPanelButton().setVisibility(View.GONE);

+            } else {

+                //show

+                               mNavigationBarView.getBluetoothButton().setVisibility(View.VISIBLE);

+                       mNavigationBarView.getBrightnessButton().setVisibility(View.VISIBLE);

+                       mNavigationBarView.getVolumeButton().setVisibility(View.VISIBLE);

+                               mNavigationBarView.getWifiButton().setVisibility(View.VISIBLE);

+                               mNavigationBarView.getKeyboardButton().setVisibility(View.VISIBLE);

+                               mNavigationBarView.getClock().setVisibility(View.VISIBLE);

+                               mNavigationBarView.getmBattery().setVisibility(View.VISIBLE);

+                               mNavigationBarView.getPanelButton().setVisibility(View.VISIBLE);

+            }

+

+        }

+    };

+   //add code end

+

     @Override

     public void onDestroyView() {

         super.onDestroyView();

diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java

index 2be14f33f3..a7f719533d 100755

--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java

@@ -496,8 +496,12 @@ public class NavigationBarView extends FrameLayout implements

     public ButtonDispatcher getClock() {

         return mButtonDispatchers.get(R.id.navi_clock);

     }


+       public void setArrow(boolean folded) {

                Log.e("NavBarInflater","folded:"+folded);

                KeyButtonDrawable bgDrawable = null;

                if(folded){

```

在NavigationBarFragment.java中注册监听show\_nav\_button的值的变化，然后根据show\_nav\_button值的变化从而实现导航栏的显示和隐藏功能





