



## 1.概述


在10.0的产品定制化开发中，可以要求设置某些wifi不出现在wifi列表中，然后实现不让连接此wifi的功能，就是设置wifi黑名单,wifiManager管理所有wifi操作，接口就加在wifiManager就可以了


## 2.设置wifi列表黑名单(ssid不显示wifi列表）的核心类



```
frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
frameworks/base/wifi/java/android/net/wifi/WifiManager.java
frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java

```

## 3.设置wifi列表黑名单(ssid不显示wifi列表）的核心功能分析和实现


### 3.1IWifiManager.aidl中增加黑名单列表的相关接口



```
  --- a/frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
+++ b/frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
@@ -262,4 +262,7 @@ interface IWifiManager
     boolean registerWifiRssiLinkSpeedAndFrequencyObserver(IWifiRssiLinkSpeedAndFrequencyObserver observer);
     boolean unregisterWifiRssiLinkSpeedAndFrequencyObserver(IWifiRssiLinkSpeedAndFrequencyObserver observer);
     //<-- Add for Wifi Rssi LinkSpeed And Frequency Observer
+       void setWiFiBlackList(in List<String> blackList);
+       List<String> getWiFiBlackList();
 }

```

通过在IWifiManager.aidl增加获取和设置wifi黑名单的接口，在搜索wifi名单中过滤这些wifi的ssid


### 3.2 在WifiManager.java中调用service设置这些wifi黑名单接口



```
diff --git a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
index a55dbde9c0..4bdc586e9b 100755
--- a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
+++ b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
@@ -1764,7 +1764,28 @@ public class WifiManager {
            throw e.rethrowFromSystemServer();
        }
    }
+       public void setWiFiBlackList(List<String> blackList){
+               try {
+            mService.setWiFiBlackList(blackList); 
+        } catch (RemoteException e) {
+            throw e.rethrowFromSystemServer();
+        }
+    }

+    public List<String> getWiFiBlackList(){
+               try {
+            return mService.getWiFiBlackList();
+        } catch (RemoteException e) {
+            throw e.rethrowFromSystemServer();
+        }
+    }

```

在WifiManager.java中增加获取和设置wifi黑名单的接口，以便在app中可以通过这些接口来调用这两个接口，从而实现功能


### 3.3BaseWifiService.java实现这个设置和获取黑名单接口



```
diff --git a/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java b/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.j
ava
old mode 100644
new mode 100755
index 8ca3753b7b..d826f33a25
--- a/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
+++ b/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
@@ -565,4 +565,19 @@ public class BaseWifiService extends IWifiManager.Stub {
        throw new UnsupportedOperationException();

    }
+       @Override
+       public void setWiFiBlackList( List<String> blackList){
+                throw new UnsupportedOperationException();
+               
+       };
+       @Override
+       public List<String> getWiFiBlackList(){
+                throw new UnsupportedOperationException();
+               
+       };
}


```

BaseWifiService.java是IWifiManager.aidl的实现类，所以需要在这里实现增加的wifi黑名单的接口，实现接口如上所述


### 3.4WifiServiceImpl.java搜索wifi列表中去掉这些wifi黑名单列表实现黑名单功能



```


```bash
public class WifiServiceImpl extends BaseWifiService {
   public WifiServiceImpl(Context context, WifiInjector wifiInjector, AsyncChannel asyncChannel) {
         mContext = context;
         mWifiInjector = wifiInjector;
         mClock = wifiInjector.getClock();
 ....
         mSoftApBackupRestore = mWifiInjector.getSoftApBackupRestore();
         mWifiApConfigStore = mWifiInjector.getWifiApConfigStore();
         mWifiPermissionsUtil = mWifiInjector.getWifiPermissionsUtil();
         mLog = mWifiInjector.makeLog(TAG);
         mFrameworkFacade = wifiInjector.getFrameworkFacade();
         mTetheredSoftApTracker = new TetheredSoftApTracker();
         mActiveModeWarden.registerSoftApCallback(mTetheredSoftApTracker);
         mLohsSoftApTracker = new LohsSoftApTracker();
         mActiveModeWarden.registerLohsCallback(mLohsSoftApTracker);
         mWifiNetworkSuggestionsManager = mWifiInjector.getWifiNetworkSuggestionsManager();
         mDppManager = mWifiInjector.getDppManager();
         mWifiThreadRunner = mWifiInjector.getWifiThreadRunner();
         mWifiConfigManager = mWifiInjector.getWifiConfigManager();
         mPasspointManager = mWifiInjector.getPasspointManager();
         mWifiScoreCard = mWifiInjector.getWifiScoreCard();
         mMemoryStoreImpl = new MemoryStoreImpl(mContext, mWifiInjector,
                 mWifiScoreCard,  mWifiInjector.getWifiHealthMonitor());
     }
     /**
      * Return the results of the most recent access point scan, in the form of
      * a list of {@link ScanResult} objects.
      * @return the list of results
      */
     @Override
     public List<ScanResult> getScanResults(String callingPackage, String callingFeatureId) {
         enforceAccessPermission();
         int uid = Binder.getCallingUid();
         long ident = Binder.clearCallingIdentity();
         if (mVerboseLoggingEnabled) {
             mLog.info("getScanResults uid=%").c(uid).flush();
         }
         try {
             mWifiPermissionsUtil.enforceCanAccessScanResults(callingPackage, callingFeatureId,
                     uid, null);
             List<ScanResult> scanResults = mWifiThreadRunner.call(
                     mScanRequestProxy::getScanResults, Collections.emptyList());
             return scanResults;
         } catch (SecurityException e) {
             Log.e(TAG, "Permission violation - getScanResults not allowed for uid="
                     + uid + ", packageName=" + callingPackage + ", reason=" + e);
             return new ArrayList<>();
         } finally {
             Binder.restoreCallingIdentity(ident);
         }
     }

```

在WifiServiceImpl.java的实现类 就是对wifiservice的实现类，在这里主要是wifi服务的具体实现，所以关于wifi服务的功能基本上都是在这里实现的



```
diff --git a/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java b/frameworks/opt/net/wifi/service/java/com/android/server/
wifi/WifiServiceImpl.java
old mode 100644
new mode 100755
index c429630db2..561e03a49b
--- a/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java
+++ b/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java
@@ -2423,6 +2423,16 @@ public class WifiServiceImpl extends BaseWifiService {
List<ScanResult> scanResults = mWifiThreadRunner.call(
                      mScanRequestProxy::getScanResults, Collections.emptyList());
+                       if(this.ssid_blackList!=null && this.ssid_blackList.size()!=0){
+                                    List<ScanResult> result1 =new ArrayList<>();
+                for (ScanResult resultbean : scanResults){
+                    if(this.ssid_blackList.contains(resultbean.SSID)){
+                        continue;
+                    }
+                    result1.add(resultbean);
+                           }
+                               return  result1;
+                       }
             return scanResults;
         } catch (SecurityException e) {
             Slog.e(TAG, "Permission violation - getScanResults not allowed for uid="
@@ -2432,7 +2442,27 @@ public class WifiServiceImpl extends BaseWifiService {
             Binder.restoreCallingIdentity(ident);
         }
     }
-
+       private List<String> ssid_blackList;
+       @Override
+       public void setWiFiBlackList(List<String> blackList){
+               this.ssid_blackList=blackList;
+               
+       }
+       @Override
+       public List<String> getWiFiBlackList(){
+               return this.ssid_blackList;
+               
+       }

```

通过在WifiServiceImpl.java中获取wifi列表的时候，在搜索列表去掉wifi黑名单中的ssid,就可以在


wifi列表实现黑名单功能，然后就可以实现搜不到这些ssid控制这些ssid的连接实现功能




