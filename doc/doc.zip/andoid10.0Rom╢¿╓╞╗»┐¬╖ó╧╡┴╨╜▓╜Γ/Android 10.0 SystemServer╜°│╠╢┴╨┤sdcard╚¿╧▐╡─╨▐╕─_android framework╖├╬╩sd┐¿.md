



## 1.前言


  
   在10.0的系统开发中，在一些系统进程中，也就是在SystemServer的进程中，其中系统服务中会要求读写Sdcard的一些功能，然后  
 默认是没有读取sdcard权限的，而在app中可以申请sdcard读写权限在系统服务中就不能申请权限，接下来看怎么授权实现sdcard授权


如图:


![](https://img-blog.csdnimg.cn/b854dcc73d6342c5b05ff536b23d1118.png)


 


## 2.SystemServer进程读写sdcard权限的修改的核心类



```
kernel-4.14\fs\namei.c
frameworks\base\core\java\com\android\internal\os\ZygoteInit.java
frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java
```

## 3.SystemServer进程读写sdcard权限的修改的核心功能分析和实现 3.1 ZygoteInit.java的相关权限分析


SystemServer就是系统用来启动service的入口。  
 Android系统在启动的时候,在启动两个重要的进程，一个是Zygote进程  
 另一个是由zygote进程fork出来的system\_server进程;  
 SystemServer会启动我们在系统中所需要的一系列service


SystemServer是Android系统中重要的进程，系统中主要的服务驻留在其中:  
 常见的比如WindowManagerServer(WMS),ActivityManagerService（AMS）,  
 PackageManagerServer(PMS),这些系统服务都存在于SystemServer进程中；  
 此进程在系统中的名称为“system\_server”。


system\_server是由ZygoteInit类负责初始化和启动的，其中关键的启动代码如下。  
 从代码中可以看到，在启动sysetm\_server时通过--setgroups为其设置了所属用户组。



```
  /**
     * Prepare the arguments and forks for the system server process.
     *
     * @return A {@code Runnable} that provides an entrypoint into system_server code in the child
     * process; {@code null} in the parent.
     */
    private static Runnable forkSystemServer(String abiList, String socketName,
            ZygoteServer zygoteServer) {
        long capabilities = posixCapabilitiesAsBits(
                OsConstants.CAP_IPC_LOCK,
                OsConstants.CAP_KILL,
                OsConstants.CAP_NET_ADMIN,
                OsConstants.CAP_NET_BIND_SERVICE,
                OsConstants.CAP_NET_BROADCAST,
                OsConstants.CAP_NET_RAW,
                OsConstants.CAP_SYS_MODULE,
                OsConstants.CAP_SYS_NICE,
                OsConstants.CAP_SYS_PTRACE,
                OsConstants.CAP_SYS_TIME,
                OsConstants.CAP_SYS_TTY_CONFIG,
                OsConstants.CAP_WAKE_ALARM,
                OsConstants.CAP_BLOCK_SUSPEND,
   +             OsConstants.CAP_CHOWN,
   +                  OsConstants.CAP_DAC_OVERRIDE,
   +                  OsConstants.CAP_DAC_READ_SEARCH
        );
        /* Containers run without some capabilities, so drop any caps that are not available. */
        StructCapUserHeader header = new StructCapUserHeader(
                OsConstants._LINUX_CAPABILITY_VERSION_3, 0);
        StructCapUserData[] data;
        try {
            data = Os.capget(header);
        } catch (ErrnoException ex) {
            throw new RuntimeException("Failed to capget()", ex);
        }
        capabilities &= ((long) data[0].effective) | (((long) data[1].effective) << 32);

        /* Hardcoded command line to start the system server */
        String args[] = {
                "--setuid=1000",
                "--setgid=1000",
     -           "--setgroups=1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1018,1021,1023,"
     +           "--setgroups=1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1015,1018,1021,1023,"
                        + "1024,1032,1065,3001,3002,3003,3006,3007,3009,3010,3011",
                "--capabilities=" + capabilities + "," + capabilities,
                "--nice-name=system_server",
                "--runtime-args",
                "--target-sdk-version=" + VMRuntime.SDK_VERSION_CUR_DEVELOPMENT,
                "com.android.server.SystemServer",
        };
        ZygoteArguments parsedArgs = null;

        int pid;

        try {
            parsedArgs = new ZygoteArguments(args);
            Zygote.applyDebuggerSystemProperty(parsedArgs);
            Zygote.applyInvokeWithSystemProperty(parsedArgs);

            if (Zygote.nativeSupportsTaggedPointers()) {
                /* Enable pointer tagging in the system server. Hardware support for this is present
                 * in all ARMv8 CPUs. */
                parsedArgs.mRuntimeFlags |= Zygote.MEMORY_TAG_LEVEL_TBI;
            }

            /* Enable gwp-asan on the system server with a small probability. This is the same
             * policy as applied to native processes and system apps. */
            parsedArgs.mRuntimeFlags |= Zygote.GWP_ASAN_LEVEL_LOTTERY;

            if (shouldProfileSystemServer()) {
                parsedArgs.mRuntimeFlags |= Zygote.PROFILE_SYSTEM_SERVER;
            }

            /* Request to fork the system server process */
            pid = Zygote.forkSystemServer(
                    parsedArgs.mUid, parsedArgs.mGid,
                    parsedArgs.mGids,
                    parsedArgs.mRuntimeFlags,
                    null,
                    parsedArgs.mPermittedCapabilities,
                    parsedArgs.mEffectiveCapabilities);
        } catch (IllegalArgumentException ex) {
            throw new RuntimeException(ex);
        }

        /* For child process */
        if (pid == 0) {
            if (hasSecondZygote(abiList)) {
                waitForSecondaryZygote(socketName);
            }

            zygoteServer.closeServerSocket();
            return handleSystemServerProcess(parsedArgs);
        }

        return null;
    }
```

在ZygoteInit.java的上述源码中，在forkSystemServer(String abiList, String socketName,  
             ZygoteServer zygoteServer)中主要就是在Zygote启动过程中，进行孵化SystemSever进程，  
 然后根据args[] 来设置SystemServer所在的gid组 在上述的--setgroups中，没有sdcard\_rw组，所以  
 就不能访问sdcard权限，所以需要增加对应的1015 gid值  
 同时也需要增加long capabilities中的OsConstants.CAP\_CHOWN OsConstants.CAP\_DAC\_OVERRIDE  
 OsConstants.CAP\_DAC\_READ\_SEARCH的值，如果还是不能访问sdcard ,就需要修改  
 kernel的权限限制接口了


## 3.2 namei.c中权限限制接口



```
/*
 * This does the basic permission checking
 */
static int acl_permission_check(struct inode *inode, int mask)
{
	unsigned int mode = inode->i_mode;

	if (likely(uid_eq(current_fsuid(), inode->i_uid)))
		mode >>= 6;
	else {
		if (IS_POSIXACL(inode) && (mode & S_IRWXG)) {
			int error = check_acl(inode, mask);
			if (error != -EAGAIN)
				return error;
		}

		if (in_group_p(inode->i_gid))
			mode >>= 3;
	}

	/*
	 * If the DACs are ok we don't need any capability check.
	 */
	if ((mask & ~mode & (MAY_READ | MAY_WRITE | MAY_EXEC)) == 0)
		return 0;
-	return -EACCES;
+	return 0/*-EACCES*/;
}
```

在上述的namei.c中的相关源码分析得知，可以从上述的acl\_permission\_check(struct inode \*inode, int mask)这个检测是否systemserver进程是否有权限的时候，可以判断此时


在systemserver进程中读写sdcard,无权限的时候，会最终输出 EACCES的提示无读写权限，所以  
 就需要把最后的返回值-EACCES修改成0，有点暴力 看实际项目情况吧


## 3.3 PhoneWindowManager.java 查询sdcard测试



```
	//add code start
    BroadcastReceiver mWallpaperChangedReceiver  = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Log.e("PhoneWindowManager","action:"+action);
			if(action.equals("com.android.startfile")||action.equals("android.intent.action.BOOT_COMPLETED")){
                startTest();
			}
        }
    };

   /** {@inheritDoc} */
    @Override
    public void systemReady() {
        // In normal flow, systemReady is called before other system services are ready.
        // So it is better not to bind keyguard here.
        mKeyguardDelegate.onSystemReady();

        mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
        if (mVrManagerInternal != null) {
            mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
        }

        readCameraLensCoverState();
        updateUiMode();
        mDefaultDisplayRotation.updateOrientationListener();
        synchronized (mLock) {
            mSystemReady = true;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    updateSettings();
                }
            });
            // If this happens, for whatever reason, systemReady came later than systemBooted.
            // And keyguard should be already bound from systemBooted
            if (mSystemBooted) {
                mKeyguardDelegate.onBootCompleted();
            }
        }
		//add code start
        IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction("com.android.startfile");
		intentFilter.addAction("android.intent.action.BOOT_COMPLETED");		
        mContext.registerReceiver(mWallpaperChangedReceiver, intentFilter);
		//add code end
        mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
    }
//add core start
	private void startTest(){
		try{
		  File f = new File("/mnt/sdcard");
		  boolean isExit = f.exists();
		  listFile("/storage/self/primary/Android");
		  listFile("/mnt/sdcard");
		  File f0 = new File("/storage/self/primary");
		  boolean isExit0 = f0.exists();
		  File f1 = new File("/storage");
		  boolean isExit1 = f1.exists();
		  File f2 = new File("/system/etc");
		  listFile("/system/etc");
		  boolean isExit2 = f2.exists();
		  File f3 = new File("/product/etc");
		  boolean isExit3 = f3.exists();
		  listFile("/product/etc");
		  File f4 = new File("/vendor/app");
		  boolean isExit4 = f4.exists();
		  listFile("/vendor/app");
		  Log.e("PhoneWindowManager","isExit:"+isExit+"--isExit0:"+isExit0+"--isExit1:"+isExit1+"--isExit2:"+isExit2+"--isExit3:"+isExit3+"--isExit4:"+isExit4);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
    private static void listFile(final String home) {
		Log.e("PhoneWindowManager", "Home ="+home);
		File f = new File(home);
		if (null != f && f.exists()) {
			Log.e("PhoneWindowManager", "Home " + home + "  is avaiable!");
			File list[] = f.listFiles();
			if (null != list && 0 < list.length) {
				Log.e("PhoneWindowManager", "File list is not empty.");
				for (File tf : list) {
					if (null != tf) {
						Log.e("PhoneWindowManager", "File name=" + tf.getName());
					}
				}
			}
			else {
				Log.e("PhoneWindowManager", "File list is empty.");
			}
		} else {
			Log.e("PhoneWindowManager", "Home " + home + " is not avaiable.");
		}
	}
//add core end
```

在PhoneWindowManager.java的上述源码中，在systemReady()中增加注册监听开机完成广播，


在开机完成以后，就可以收到开机广播，在系统中监听开机广播完成以后，就然后调用startTest()来遍历sdcard的相关文件夹，发现可以读取到sdcard下的相关文件，就这样通过这样的实验发现这种方法确实可以在SystemServer的进程中读取sdcard的内容



