






### 1.概述


在10.0的系统产品开发中，在系统开机过程中系统会检测/system/build.prop 和 /vendor/build.prop，如果发现不一致的地方，就会提示报错，实际不影响使用，直接可以注释掉源码就可以了


### 2.启动到桌面显示 There’s an internal problem with your device. Contact your manufacturer的核心类



```
frameworks\base\services\core\java\com\android\server\wm\ActivityTaskManagerService.java

```

### 3.启动到桌面显示 There’s an internal problem with your device. Contact your manufacturer的核心功能实现和分析


在系统启动的时候，有时候会显示There’s an internal problem with your device. Contact your manufacturer的弹窗，这对系统产品开发很不利，所以就需要去掉这个弹窗，就需要看这个弹窗的源码ActivityTaskManagerService.java  
 源码部分：



```
  public class ActivityTaskManagerService extends IActivityTaskManager.Stub {
      private static final String TAG = TAG_WITH_CLASS_NAME ? "ActivityTaskManagerService" : TAG_ATM;
	  @VisibleForTesting(visibility = VisibleForTesting.Visibility.PACKAGE)
      public ActivityTaskManagerService(Context context) {
          mContext = context;
          mFactoryTest = FactoryTest.getMode();
          mSystemThread = ActivityThread.currentActivityThread();
          mUiContext = mSystemThread.getSystemUiContext();
          mLifecycleManager = new ClientLifecycleManager();
          mInternal = new LocalService();
          GL_ES_VERSION = SystemProperties.getInt("ro.opengles.version", GL_ES_VERSION_UNDEFINED);
      }
  
      public void onSystemReady() {
          synchronized (mGlobalLock) {
              mHasHeavyWeightFeature = mContext.getPackageManager().hasSystemFeature(
                      PackageManager.FEATURE_CANT_SAVE_STATE);
              mAssistUtils = new AssistUtils(mContext);
              mVrController.onSystemReady();
              mRecentTasks.onSystemReadyLocked();
              mStackSupervisor.onSystemReady();
          }
      }
      public void initialize(IntentFirewall intentFirewall, PendingIntentController intentController,
              Looper looper) {
          mH = new H(looper);
          mUiHandler = new UiHandler();
          mIntentFirewall = intentFirewall;
          final File systemDir = SystemServiceManager.ensureSystemDir();
          mAppWarnings = new AppWarnings(this, mUiContext, mH, mUiHandler, systemDir);
          mCompatModePackages = new CompatModePackages(this, systemDir, mH);
          mPendingIntentController = intentController;
  
          mTempConfig.setToDefaults();
          mTempConfig.setLocales(LocaleList.getDefault());
          mConfigurationSeq = mTempConfig.seq = 1;
          mStackSupervisor = createStackSupervisor();
          mRootActivityContainer = new RootActivityContainer(this);
          mRootActivityContainer.onConfigurationChanged(mTempConfig);
  
          mTaskChangeNotificationController =
                  new TaskChangeNotificationController(mGlobalLock, mStackSupervisor, mH);
          mLockTaskController = new LockTaskController(mContext, mStackSupervisor, mH);
          mActivityStartController = new ActivityStartController(this);
          mRecentTasks = createRecentTasks();
          mStackSupervisor.setRecentTasks(mRecentTasks);
          mVrController = new VrController(mGlobalLock);
          mKeyguardController = mStackSupervisor.getKeyguardController();
      }

```

在上述的代码中，发现在ATMS的构造方法和通过initialize的初始化方法中，初始化ATMS的参数变量以及一些控制类，而onSystemReady()是在系统启动准备完毕后调用的一些方法，接下来看下相关弹窗相关的方法，来解决今天的问题所在



```
      @Override
          public void showSystemReadyErrorDialogsIfNeeded() {
              synchronized (mGlobalLock) {
                  try {
                      if (AppGlobals.getPackageManager().hasSystemUidErrors()) {
                          Slog.e(TAG, "UIDs on the system are inconsistent, you need to wipe your"
                                  + " data partition or your device will be unstable.");
                          mUiHandler.post(() -> {
 if (mShowDialogs) {
 AlertDialog d = new BaseErrorDialog(mUiContext);
 d.getWindow().setType(WindowManager.LayoutParams.TYPE\_SYSTEM\_ERROR);
 d.setCancelable(false);
 d.setTitle(mUiContext.getText(R.string.android\_system\_label));
                                  d.setMessage(mUiContext.getText(R.string.system_error_wipe_data));
                                  d.setButton(DialogInterface.BUTTON_POSITIVE,
                                          mUiContext.getText(R.string.ok),
                                          mUiHandler.obtainMessage(DISMISS_DIALOG_UI_MSG, d));
                                  d.show();
                              }
                          });
                      }
                  } catch (RemoteException e) {
                  }
  
                  if (!Build.isBuildConsistent()) {
                      Slog.e(TAG, "Build fingerprint is not consistent, warning user");
                      mUiHandler.post(() -> {
 if (mShowDialogs) {
 AlertDialog d = new BaseErrorDialog(mUiContext);
 d.getWindow().setType(WindowManager.LayoutParams.TYPE\_SYSTEM\_ERROR);
 d.setCancelable(false);
 d.setTitle(mUiContext.getText(R.string.android\_system\_label));
                              d.setMessage(mUiContext.getText(R.string.system_error_manufacturer));
                              d.setButton(DialogInterface.BUTTON_POSITIVE,
                                      mUiContext.getText(R.string.ok),
                                      mUiHandler.obtainMessage(DISMISS_DIALOG_UI_MSG, d));
                              d.show();
                          }
                      });
                  }
              }
          }

```

在上述源码中发现在initialize(）中初始化在ATMS的需要的参数，而在这里关于弹窗的分析  
 在进行相关源码分析得知，在grep的搜索相关字符串发现是在showSystemReadyErrorDialogsIfNeeded()中弹出提示弹窗的，所以不需要这个弹窗。就需要注释掉这些关于这方面的弹窗  
 具体实现如下:



```
 @Override
        public void showSystemReadyErrorDialogsIfNeeded() {
            synchronized (mGlobalLock) {
                try {
                    if (AppGlobals.getPackageManager().hasSystemUidErrors()) {
                        Slog.e(TAG, "UIDs on the system are inconsistent, you need to wipe your"
                                + " data partition or your device will be unstable.");
                        mUiHandler.post(() -> {
                            if (mShowDialogs) {
                                AlertDialog d = new BaseErrorDialog(mUiContext);
                                d.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ERROR);
                                d.setCancelable(false);
                                d.setTitle(mUiContext.getText(R.string.android_system_label));
                                d.setMessage(mUiContext.getText(R.string.system_error_wipe_data));
                                d.setButton(DialogInterface.BUTTON_POSITIVE,
                                        mUiContext.getText(R.string.ok),
                                        mUiHandler.obtainMessage(DISMISS_DIALOG_UI_MSG, d));
                                d.show();
                            }
                        });
                    }
                } catch (RemoteException e) {
                }

                if (!Build.isBuildConsistent()) {
                    Slog.e(TAG, "Build fingerprint is not consistent, warning user");
                    mUiHandler.post(() -> {
                        if (mShowDialogs) {
                            //AlertDialog d = new BaseErrorDialog(mUiContext);
                            //d.getWindow().setType(WindowManager.LayoutParams.TYPE\_SYSTEM\_ERROR);
                            //d.setCancelable(false);
                            //d.setTitle(mUiContext.getText(R.string.android\_system\_label));
                            //d.setMessage(mUiContext.getText(R.string.system\_error\_manufacturer));
                            //d.setButton(DialogInterface.BUTTON\_POSITIVE,
                            // mUiContext.getText(R.string.ok),
                            // mUiHandler.obtainMessage(DISMISS\_DIALOG\_UI\_MSG, d));
                            //d.show();
                        }
                    });
                }
            }
        }

```

通过上述代码发现，其实就是在showSystemReadyErrorDialogsIfNeeded()中的mShowDialogs为ture时，弹出的AlertDialog弹窗，它的message就是system\_error\_manufacturer这个就是弹出的错误信息，所以需要  
 注释掉相关的弹窗就可以了  
 就这样轻松解决





