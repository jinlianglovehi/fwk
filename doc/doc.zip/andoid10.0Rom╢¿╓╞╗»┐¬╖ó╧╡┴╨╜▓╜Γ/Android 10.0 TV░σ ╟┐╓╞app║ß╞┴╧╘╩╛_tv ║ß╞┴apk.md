






TV开发板定制化开发，一般要求都是固定横屏显示的，但是安装一些app如果是竖屏的话，感觉就有些不协调，所以要强制app必须横屏显示才行


关于显示都是在WMS中处理的 接下来看下WMS的源码  
 路径framework/base/services/core/java/com/android/server/wm/WindowManagerService.java



```
@Override
    public void setWindowingMode(int displayId, int mode) {
        if (!checkCallingPermission(INTERNAL_SYSTEM_WINDOW, "setWindowingMode()")) {
            throw new SecurityException("Requires INTERNAL\_SYSTEM\_WINDOW permission");
        }

        synchronized (mGlobalLock) {
            final DisplayContent displayContent = getDisplayContentOrCreate(displayId, null);
            if (displayContent == null) {
                Slog.w(TAG_WM, "Attempted to set windowing mode to a display that does not exist: "
                        + displayId);
                return;
            }

            int lastWindowingMode = displayContent.getWindowingMode();
            mDisplayWindowSettings.setWindowingModeLocked(displayContent, mode);

            reconfigureDisplayLocked(displayContent);

            if (lastWindowingMode != displayContent.getWindowingMode()) {
                // reconfigure won't detect this change in isolation because the windowing mode is
                // already set on the display, so fire off a new config now.
                mH.removeMessages(H.SEND_NEW_CONFIGURATION);

                final long origId = Binder.clearCallingIdentity();
                try {
                    // direct call since lock is shared.
                    sendNewConfiguration(displayId);
                } finally {
                    Binder.restoreCallingIdentity(origId);
                }
                // Now that all configurations are updated, execute pending transitions
                displayContent.executeAppTransition();
            }
        }
    }

```

从代码中可以看到reconfigureDisplayLocked 锁定屏幕显示  
 接下来看下它的源码



```
void reconfigureDisplayLocked(@NonNull DisplayContent displayContent) {
        reconfigureDisplayLocked(displayContent, false);
    }

    void reconfigureDisplayLocked(@NonNull DisplayContent displayContent, boolean forced) {
        if (!displayContent.isReady()) {
            return;
        }
        displayContent.configureDisplayPolicy();
        displayContent.setLayoutNeeded();

        boolean configChanged = displayContent.updateOrientationFromAppTokens();
        final Configuration currentDisplayConfig = displayContent.getConfiguration();
        mTempConfiguration.setTo(currentDisplayConfig);
        displayContent.computeScreenConfiguration(mTempConfiguration);
        configChanged |= currentDisplayConfig.diff(mTempConfiguration) != 0;

        if (configChanged || forced) {
            displayContent.mWaitingForConfig = true;
            startFreezingDisplayLocked(0 /* exitAnim */,
                    0 /* enterAnim */, displayContent);
            displayContent.sendNewConfiguration();
        }

        mWindowPlacerLocked.performSurfacePlacement();
    }

```

从源码中看到调用了displayContent.updateOrientationFromAppTokens() 来获取当前屏幕的方向  
 可以在这里来设置屏幕方向  
 修改如下:



```

--- a/services/core/java/com/android/server/wm/DisplayContent.java
+++ b/services/core/java/com/android/server/wm/DisplayContent.java
@@ -1323,7 +1323,7 @@ class DisplayContent extends WindowContainer<DisplayContent.DisplayChildWindowCo
 
 
     private boolean updateOrientationFromAppTokens(boolean forceUpdate) {
-        final int req = getOrientation();
+        final int req = Surface.ROTATION_0;
         if (req != mLastOrientation || forceUpdate) {
             mLastOrientation = req;
             mDisplayRotation.setCurrentOrientation(req);

```




