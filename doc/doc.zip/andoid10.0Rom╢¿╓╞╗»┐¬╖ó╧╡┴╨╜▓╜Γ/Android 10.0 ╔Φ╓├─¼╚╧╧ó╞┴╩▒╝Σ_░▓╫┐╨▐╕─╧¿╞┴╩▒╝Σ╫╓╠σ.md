






### 1.概述


在10.0的系统产品定制化开发中，由于系统默认的息屏时间过短，所以要求修改默认息屏时间修改也是常见的修改功能，  
 在系统Settings中屏幕超时会根据默认息屏时间来显示屏幕超时的选项，然后设置对应的息屏时间


### 2.设置默认息屏时间的核心类



```
frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
/packages/apps/Settings/res/xml/display_settings.xml

```

### 3.设置默认息屏时间的核心功能分析和实现


对于屏幕默认的超时时间，需要首选看下系统Settings中，关于屏幕超时的选项，就是display\_settings.xml中  
 接下来看下这个文件分析问题  
 在系统设置中的 display\_settings.xml中



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2016 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:key="display\_settings\_screen"
    android:title="@string/display\_settings"
    settings:keywords="@string/keywords\_display"
    settings:initialExpandedChildrenCount="5">

    <com.android.settingslib.RestrictedPreference
        android:key="brightness"
        android:title="@string/brightness"
        settings:keywords="@string/keywords\_display\_brightness\_level"
        settings:useAdminDisabledSummary="true"
        settings:userRestriction="no\_config\_brightness">
        <intent android:action="com.android.intent.action.SHOW\_BRIGHTNESS\_DIALOG" />
    </com.android.settingslib.RestrictedPreference>

    <com.android.settings.display.NightDisplayPreference
        android:key="night\_display"
        android:title="@string/night\_display\_title"
        android:fragment="com.android.settings.display.NightDisplaySettings"
        android:widgetLayout="@null"
        settings:widgetLayout="@null"
        settings:searchable="false" />

    <!-- UNISOC: Add for Color Temperature Adjusting -->
    <Preference
        android:key="colors\_contrast"
        android:title="@string/colors\_contrast\_title">
    </Preference>

    <Preference
        android:key="auto\_brightness\_entry"
        android:title="@string/auto\_brightness\_title"
        android:summary="@string/summary\_placeholder"
        android:fragment="com.android.settings.display.AutoBrightnessSettings"
        settings:controller="com.android.settings.display.AutoBrightnessPreferenceController"/>

    <com.android.settingslib.RestrictedPreference
        android:key="wallpaper"
        android:title="@string/wallpaper\_settings\_title"
        settings:keywords="@string/keywords\_display\_wallpaper"
        settings:useAdminDisabledSummary="true"
        settings:controller="com.android.settings.display.WallpaperPreferenceController">
    </com.android.settingslib.RestrictedPreference>


    <SwitchPreference
        android:key="dark\_ui\_mode"
        android:title="@string/dark\_ui\_mode"
        settings:keywords="@string/keywords\_dark\_ui\_mode"
        settings:controller="com.android.settings.display.DarkUIPreferenceController"/>

    <!-- Cross-listed item, if you change this, also change it in power_usage_summary.xml -->
    <com.android.settings.display.TimeoutListPreference
        android:key="screen\_timeout"
        android:title="@string/screen\_timeout"
        android:summary="@string/summary\_placeholder"
        android:entries="@array/screen\_timeout\_entries"
        android:entryValues="@array/screen\_timeout\_values"
        settings:keywords="@string/keywords\_screen\_timeout" />

    <!-- UNISOC:1185786 Support "One-handed mode" start -->
    <Preference
        android:key="one\_handed\_mode"
        android:title="@string/one\_handed\_mode"
        android:summary="@string/summary\_placeholder"
        android:fragment="com.sprd.settings.onehandedmode.OneHandedModeSettings"
        settings:controller="com.sprd.settings.onehandedmode.OneHandedModeSettingsController" />
    <!-- UNISOC:1185786 Support "One-handed mode" end -->

    <Preference
        android:key="adaptive\_sleep\_entry"
        android:title="@string/adaptive\_sleep\_title"
        android:summary="@string/summary\_placeholder"
        android:fragment="com.android.settings.display.AdaptiveSleepSettings"
        settings:controller="com.android.settings.display.AdaptiveSleepPreferenceController" />

    <SwitchPreference
        android:key="auto\_rotate"
        android:title="@string/accelerometer\_title"
        settings:keywords="@string/keywords\_auto\_rotate"
        settings:controller="com.android.settings.display.AutoRotatePreferenceController" />

    <Preference
        android:key="color\_mode"
        android:title="@string/color\_mode\_title"
        android:fragment="com.android.settings.display.ColorModePreferenceFragment"
        settings:controller="com.android.settings.display.ColorModePreferenceController"
        settings:keywords="@string/keywords\_color\_mode" />

    <SwitchPreference
        android:key="display\_white\_balance"
        android:title="@string/display\_white\_balance\_title"
        settings:controller="com.android.settings.display.DisplayWhiteBalancePreferenceController" />

    <Preference
        android:key="font\_size"
        android:title="@string/title\_font\_size"
        android:fragment="com.android.settings.display.ToggleFontSizePreferenceFragment"
        settings:controller="com.android.settings.display.FontSizePreferenceController" />

    <com.android.settings.display.ScreenZoomPreference
        android:key="display\_settings\_screen\_zoom"
        android:title="@string/screen\_zoom\_title"
        android:fragment="com.android.settings.display.ScreenZoomSettings"
        settings:searchable="false"/>

    <SwitchPreference
        android:key="show\_operator\_name"
        android:title="@string/show\_operator\_name\_title"
        android:summary="@string/show\_operator\_name\_summary" />

    <Preference
        android:key="screensaver"
        android:title="@string/screensaver\_settings\_title"
        android:fragment="com.android.settings.dream.DreamSettings"
        settings:searchable="false" />

    <com.android.settingslib.RestrictedPreference
        android:key="lockscreen\_from\_display\_settings"
        android:title="@string/lockscreen\_settings\_title"
        android:fragment="com.android.settings.security.LockscreenDashboardFragment"
        settings:controller="com.android.settings.security.screenlock.LockScreenPreferenceController"
        settings:userRestriction="no\_ambient\_display" />

    <SwitchPreference
        android:key="camera\_gesture"
        android:title="@string/camera\_gesture\_title"
        android:summary="@string/camera\_gesture\_desc" />

    <SwitchPreference
        android:key="lift\_to\_wake"
        android:title="@string/lift\_to\_wake\_title" />

    <SwitchPreference
        android:key="tap\_to\_wake"
        android:title="@string/tap\_to\_wake"
        android:summary="@string/tap\_to\_wake\_summary" />

    <ListPreference
        android:key="theme"
        android:title="@string/device\_theme"
        android:summary="@string/summary\_placeholder" />

    <Preference
        android:key="vr\_display\_pref"
        android:title="@string/display\_vr\_pref\_title"
        android:fragment="com.android.settings.display.VrDisplayPreferencePicker" />

</PreferenceScreen>
而 
    <com.android.settings.display.TimeoutListPreference
        android:key="screen\_timeout"
        android:title="@string/screen\_timeout"
        android:summary="@string/summary\_placeholder"
        android:entries="@array/screen\_timeout\_entries"
        android:entryValues="@array/screen\_timeout\_values"
        settings:keywords="@string/keywords\_screen\_timeout" />

```

从上述的文件中可以看到TimeoutListPreference就是系统settings中屏幕超时项 的布局类  
 而修改完息屏时间的具体处理事项是在TimeoutPreferenceController.java 中处理的息屏时间



```
    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        try {
            //int value = Integer.parseInt((String) newValue);
            //Settings.System.putInt(mContext.getContentResolver(), SCREEN_OFF_TIMEOUT, value);
            long value = Integer.parseInt((String) newValue);
            Settings.System.putLong(mContext.getContentResolver(), SCREEN_OFF_TIMEOUT, value);
            updateTimeoutPreferenceDescription((TimeoutListPreference) preference, value);
        } catch (NumberFormatException e) {
            Log.e(TAG, "could not persist screen timeout setting", e);
        }
        return true;
    }

```

从TimeoutPreferenceController中的onPreferenceChange可以发现，修改完息屏时间后  
 会把值保存在Settings.System.putLong(mContext.getContentResolver(), SCREEN\_OFF\_TIMEOUT, value);  
 中 数据库的值就是screen\_off\_timeout


所以只要在framework/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java  
 中修改SCREEN\_OFF\_TIMEOUT这个值就可以了



```
private void loadSystemSettings(SQLiteDatabase db) {
        SQLiteStatement stmt = null;
        try {
            stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                    + " VALUES(?,?);");

            loadBooleanSetting(stmt, Settings.System.DIM_SCREEN,
                    R.bool.def_dim_screen);
            loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                    R.integer.def_screen_off_timeout);

            // Set default cdma DTMF type
            loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);

```

代码中可以看出就是在loadSystemSettings(SQLiteDatabase db)中进行  
 数据库加载的时候 从def\_screen\_off\_timeout 来获取默认值，所以修改下它的值


所以修改如下 在



```
--- a/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
+++ b/frameworks/base/packages/SettingsProvider/res/values/defaults.xml
@@ -19,7 +19,7 @@
 <resources>
     <string name="time\_12\_24" translatable="false">24</string>
     <bool name="def\_dim\_screen">true</bool>
-    <integer name="def\_screen\_off\_timeout">60000</integer>
+    <integer name="def\_screen\_off\_timeout">1800000</integer>
     <integer name="def\_sleep\_timeout">-1</integer>
     <bool name="def\_airplane\_mode\_on">false</bool>
     <bool name="def\_theater\_mode\_on">false</bool>

```

在MTK 等平台 会出现同时需要在 vendor下面把这个值def\_screen\_off\_timeout也要改成相同的 这里会覆盖掉修改的值





