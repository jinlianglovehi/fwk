



## 1.概述


系统SystemUI下拉状态栏UI定制化第七讲 下拉状态栏下拉一次展开 系统默认是两次下拉


完全展现状态栏 目前根据功能要求修改为一次展开状态栏


## 2.核心代码



```
主要代码如下:
/frameworks/base/packages/SystemUI/res/layout/quick_status_bar_expanded_header.xml
/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java
 /frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSFragment.java

```

## 3.核心代码功能分析实现功能要求


#### 3.1QuickStatusBarHeader.java代码分析


从/[frameworks](http://aospxref.com/android-10.0.0_r47/xref/frameworks/ "frameworks")/[base](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/ "base")/[packages](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/packages/ "packages")/[SystemUI](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/packages/SystemUI/ "SystemUI")/[res](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/packages/SystemUI/res/ "res")/[layout](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/packages/SystemUI/res/layout/ "layout")/[quick\_status\_bar\_expanded\_header.xml](http://aospxref.com/android-10.0.0_r47/xref/frameworks/base/packages/SystemUI/res/layout/quick_status_bar_expanded_header.xml "quick_status_bar_expanded_header.xml")


分析源码



```
<?xml version="1.0" encoding="utf-8"?>
<!--
** Copyright 2012, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
-->

<!-- Extends RelativeLayout -->
<com.android.systemui.qs.QuickStatusBarHeader
xmlns:android="http://schemas.android.com/apk/res/android"
android:id="@+id/header"
android:layout_width="match_parent"
android:layout_height="@*android:dimen/quick_qs_total_height"
android:layout_gravity="@integer/notification_panel_layout_gravity"
android:background="@android:color/transparent"
android:baselineAligned="false"
android:clickable="false"
android:clipChildren="false"
android:clipToPadding="false"
android:paddingTop="0dp"
android:paddingEnd="0dp"
android:paddingStart="0dp"
android:elevation="4dp" >

<include layout="@layout/quick_status_bar_header_system_icons" />

<!-- Status icons within the panel itself (and not in the top-most status bar) -->
<include layout="@layout/quick_qs_status_icons" />

<!-- Layout containing tooltips, alarm text, etc. -->
<include layout="@layout/quick_settings_header_info" />

<com.android.systemui.qs.QuickQSPanel
android:id="@+id/quick_qs_panel"
android:layout_width="match_parent"
android:layout_height="48dp"
android:layout_below="@id/quick_qs_status_icons"
android:layout_marginStart="@dimen/qs_header_tile_margin_horizontal"
android:layout_marginEnd="@dimen/qs_header_tile_margin_horizontal"
android:accessibilityTraversalAfter="@+id/date_time_group"
android:accessibilityTraversalBefore="@id/expand_indicator"
android:clipChildren="false"
android:clipToPadding="false"
android:focusable="true"
android:importantForAccessibility="yes" />

<com.android.systemui.statusbar.AlphaOptimizedImageView
android:id="@+id/qs_detail_header_progress"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:layout_alignParentBottom="true"
android:alpha="0"
android:background="@color/qs_detail_progress_track"
android:src="@drawable/indeterminate_anim"/>

<TextView
android:id="@+id/header_debug_info"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:layout_gravity="center_vertical"
android:fontFamily="sans-serif-condensed"
android:padding="2dp"
android:textColor="#00A040"
android:textSize="11dp"
android:textStyle="bold"
android:visibility="invisible"/>

</com.android.systemui.qs.QuickStatusBarHeader>
```

代码中可以看出首次下拉状态栏高度其实就是在QuickStatusBarHeader.java中布局的


接下来看他的布局



```
public class QuickStatusBarHeader extends RelativeLayout implements
View.OnClickListener, NextAlarmController.NextAlarmChangeCallback,
ZenModeController.Callback {
private static final String TAG = "QuickStatusBarHeader";
private static final boolean DEBUG = false;

/** Delay for auto fading out the long press tooltip after it's fully visible (in ms). */
private static final long AUTO_FADE_OUT_DELAY_MS = DateUtils.SECOND_IN_MILLIS * 6;
private static final int FADE_ANIMATION_DURATION_MS = 300;
private static final int TOOLTIP_NOT_YET_SHOWN_COUNT = 0;
public static final int MAX_TOOLTIP_SHOWN_COUNT = 2;

private final Handler mHandler = new Handler();
private final NextAlarmController mAlarmController;
private final ZenModeController mZenController;
private final StatusBarIconController mStatusBarIconController;
private final ActivityStarter mActivityStarter;

private QSPanel mQsPanel;

private boolean mExpanded;
private boolean mListening;
private boolean mQsDisabled;

private QSCarrierGroup mCarrierGroup;
protected QuickQSPanel mHeaderQsPanel;
protected QSTileHost mHost;
private TintedIconManager mIconManager;
private TouchAnimator mStatusIconsAlphaAnimator;
private TouchAnimator mHeaderTextContainerAlphaAnimator;
private DualToneHandler mDualToneHandler;

private View mSystemIconsView;
private View mQuickQsStatusIcons;
private View mHeaderTextContainerView;

private int mRingerMode = AudioManager.RINGER_MODE_NORMAL;
private AlarmManager.AlarmClockInfo mNextAlarm;

private ImageView mNextAlarmIcon;
/** {@link TextView} containing the actual text indicating when the next alarm will go off. */
private TextView mNextAlarmTextView;
private View mNextAlarmContainer;
private View mStatusSeparator;
private ImageView mRingerModeIcon;
private TextView mRingerModeTextView;
private View mRingerContainer;
private Clock mClockView;
private DateView mDateView;
private BatteryMeterView mBatteryRemainingIcon;

private final BroadcastReceiver mRingerReceiver = new BroadcastReceiver() {
@Override
public void onReceive(Context context, Intent intent) {
mRingerMode = intent.getIntExtra(AudioManager.EXTRA_RINGER_MODE, -1);
updateStatusText();
}
};
private boolean mHasTopCutout = false;

@Inject
public QuickStatusBarHeader(@Named(VIEW_CONTEXT) Context context, AttributeSet attrs,
NextAlarmController nextAlarmController, ZenModeController zenModeController,
StatusBarIconController statusBarIconController,
ActivityStarter activityStarter) {
super(context, attrs);
mAlarmController = nextAlarmController;
mZenController = zenModeController;
mStatusBarIconController = statusBarIconController;
mActivityStarter = activityStarter;
mDualToneHandler = new DualToneHandler(
new ContextThemeWrapper(context, R.style.QSHeaderTheme));
}

@Override
protected void onFinishInflate() {
super.onFinishInflate();

mHeaderQsPanel = findViewById(R.id.quick_qs_panel);
mSystemIconsView = findViewById(R.id.quick_status_bar_system_icons);
mQuickQsStatusIcons = findViewById(R.id.quick_qs_status_icons);
StatusIconContainer iconContainer = findViewById(R.id.statusIcons);
iconContainer.setShouldRestrictIcons(false);
mIconManager = new TintedIconManager(iconContainer);

// Views corresponding to the header info section (e.g. ringer and next alarm).
mHeaderTextContainerView = findViewById(R.id.header_text_container);
mStatusSeparator = findViewById(R.id.status_separator);
mNextAlarmIcon = findViewById(R.id.next_alarm_icon);
mNextAlarmTextView = findViewById(R.id.next_alarm_text);
mNextAlarmContainer = findViewById(R.id.alarm_container);
mNextAlarmContainer.setOnClickListener(this::onClick);
mRingerModeIcon = findViewById(R.id.ringer_mode_icon);
mRingerModeTextView = findViewById(R.id.ringer_mode_text);
mRingerContainer = findViewById(R.id.ringer_container);
mCarrierGroup = findViewById(R.id.carrier_group);


updateResources();

Rect tintArea = new Rect(0, 0, 0, 0);
int colorForeground = Utils.getColorAttrDefaultColor(getContext(),
android.R.attr.colorForeground);
float intensity = getColorIntensity(colorForeground);
int fillColor = mDualToneHandler.getSingleColor(intensity);

// Set light text on the header icons because they will always be on a black background
applyDarkness(R.id.clock, tintArea, 0, DarkIconDispatcher.DEFAULT_ICON_TINT);

// Set the correct tint for the status icons so they contrast
mIconManager.setTint(fillColor);
mNextAlarmIcon.setImageTintList(ColorStateList.valueOf(fillColor));
mRingerModeIcon.setImageTintList(ColorStateList.valueOf(fillColor));

mClockView = findViewById(R.id.clock);
mClockView.setOnClickListener(this);
mDateView = findViewById(R.id.date);

// Tint for the battery icons are handled in setupHost()
mBatteryRemainingIcon = findViewById(R.id.batteryRemainingIcon);
// Don't need to worry about tuner settings for this icon
mBatteryRemainingIcon.setIgnoreTunerUpdates(true);
// QS will always show the estimate, and BatteryMeterView handles the case where
// it's unavailable or charging
mBatteryRemainingIcon.setPercentShowMode(BatteryMeterView.MODE_ESTIMATE);
mRingerModeTextView.setSelected(true);
mNextAlarmTextView.setSelected(true);
}

private void updateStatusText() {
boolean changed = updateRingerStatus() || updateAlarmStatus();

if (changed) {
boolean alarmVisible = mNextAlarmTextView.getVisibility() == View.VISIBLE;
boolean ringerVisible = mRingerModeTextView.getVisibility() == View.VISIBLE;
mStatusSeparator.setVisibility(alarmVisible && ringerVisible ? View.VISIBLE
: View.GONE);
}
}

private boolean updateRingerStatus() {
boolean isOriginalVisible = mRingerModeTextView.getVisibility() == View.VISIBLE;
CharSequence originalRingerText = mRingerModeTextView.getText();

boolean ringerVisible = false;
if (!ZenModeConfig.isZenOverridingRinger(mZenController.getZen(),
mZenController.getConsolidatedPolicy())) {
if (mRingerMode == AudioManager.RINGER_MODE_VIBRATE) {
mRingerModeIcon.setImageResource(R.drawable.ic_volume_ringer_vibrate);
mRingerModeTextView.setText(R.string.qs_status_phone_vibrate);
ringerVisible = true;
} else if (mRingerMode == AudioManager.RINGER_MODE_SILENT) {
mRingerModeIcon.setImageResource(R.drawable.ic_volume_ringer_mute);
mRingerModeTextView.setText(R.string.qs_status_phone_muted);
ringerVisible = true;
}
}
mRingerModeIcon.setVisibility(ringerVisible ? View.VISIBLE : View.GONE);
mRingerModeTextView.setVisibility(ringerVisible ? View.VISIBLE : View.GONE);
mRingerContainer.setVisibility(ringerVisible ? View.VISIBLE : View.GONE);

return isOriginalVisible != ringerVisible ||
!Objects.equals(originalRingerText, mRingerModeTextView.getText());
}

private boolean updateAlarmStatus() {
boolean isOriginalVisible = mNextAlarmTextView.getVisibility() == View.VISIBLE;
CharSequence originalAlarmText = mNextAlarmTextView.getText();

boolean alarmVisible = false;
if (mNextAlarm != null) {
alarmVisible = true;
mNextAlarmTextView.setText(formatNextAlarm(mNextAlarm));
}
mNextAlarmIcon.setVisibility(alarmVisible ? View.VISIBLE : View.GONE);
mNextAlarmTextView.setVisibility(alarmVisible ? View.VISIBLE : View.GONE);
mNextAlarmContainer.setVisibility(alarmVisible ? View.VISIBLE : View.GONE);

return isOriginalVisible != alarmVisible ||
!Objects.equals(originalAlarmText, mNextAlarmTextView.getText());
}

private void applyDarkness(int id, Rect tintArea, float intensity, int color) {
View v = findViewById(id);
if (v instanceof DarkReceiver) {
((DarkReceiver) v).onDarkChanged(tintArea, intensity, color);
}
}

@Override
protected void onConfigurationChanged(Configuration newConfig) {
super.onConfigurationChanged(newConfig);
updateResources();

// Update color schemes in landscape to use wallpaperTextColor
boolean shouldUseWallpaperTextColor =
newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE;
mClockView.useWallpaperTextColor(shouldUseWallpaperTextColor);
}

@Override
public void onRtlPropertiesChanged(int layoutDirection) {
super.onRtlPropertiesChanged(layoutDirection);
updateResources();
}

/**
* The height of QQS should always be the status bar height + 128dp. This is normally easy, but
* when there is a notch involved the status bar can remain a fixed pixel size.
*/
private void updateMinimumHeight() {
int sbHeight = mContext.getResources().getDimensionPixelSize(
com.android.internal.R.dimen.status_bar_height);
int qqsHeight = mContext.getResources().getDimensionPixelSize(
R.dimen.qs_quick_header_panel_height);

setMinimumHeight(sbHeight + qqsHeight);
}

private void updateResources() {
Resources resources = mContext.getResources();
updateMinimumHeight();

// Update height for a few views, especially due to landscape mode restricting space.
mHeaderTextContainerView.getLayoutParams().height =
resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
com.android.internal.R.dimen.quick_qs_offset_height);
mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
if (mQsDisabled) {
lp.height = resources.getDimensionPixelSize(
com.android.internal.R.dimen.quick_qs_offset_height);
} else {
lp.height = Math.max(getMinimumHeight(),
resources.getDimensionPixelSize(
com.android.internal.R.dimen.quick_qs_total_height));
}

setLayoutParams(lp);

updateStatusIconAlphaAnimator();
updateHeaderTextContainerAlphaAnimator();
}

private void updateStatusIconAlphaAnimator() {
mStatusIconsAlphaAnimator = new TouchAnimator.Builder()
addFloat(mQuickQsStatusIcons, "alpha", 1, 0, 0)
build();
}

private void updateHeaderTextContainerAlphaAnimator() {
mHeaderTextContainerAlphaAnimator = new TouchAnimator.Builder()
addFloat(mHeaderTextContainerView, "alpha", 0, 0, 1)
build();
}

public void setExpanded(boolean expanded) {
if (mExpanded == expanded) return;
mExpanded = expanded;
mHeaderQsPanel.setExpanded(expanded);
updateEverything();
}

/**
* Animates the inner contents based on the given expansion details.
*
* @param isKeyguardShowing whether or not we're showing the keyguard (a.k.a. lockscreen)
* @param expansionFraction how much the QS panel is expanded/pulled out (up to 1f)
* @param panelTranslationY how much the panel has physically moved down vertically (required
*                          for keyguard animations only)
*/
public void setExpansion(boolean isKeyguardShowing, float expansionFraction,
float panelTranslationY) {
final float keyguardExpansionFraction = isKeyguardShowing ? 1f : expansionFraction;
if (mStatusIconsAlphaAnimator != null) {
mStatusIconsAlphaAnimator.setPosition(keyguardExpansionFraction);
}

if (isKeyguardShowing) {
// If the keyguard is showing, we want to offset the text so that it comes in at the
// same time as the panel as it slides down.
mHeaderTextContainerView.setTranslationY(panelTranslationY);
} else {
mHeaderTextContainerView.setTranslationY(0f);
}

if (mHeaderTextContainerAlphaAnimator != null) {
mHeaderTextContainerAlphaAnimator.setPosition(keyguardExpansionFraction);
if (keyguardExpansionFraction > 0) {
mHeaderTextContainerView.setVisibility(VISIBLE);
} else {
mHeaderTextContainerView.setVisibility(INVISIBLE);
}
}
}

public void disable(int state1, int state2, boolean animate) {
final boolean disabled = (state2 & DISABLE2_QUICK_SETTINGS) != 0;
if (disabled == mQsDisabled) return;
mQsDisabled = disabled;
mHeaderQsPanel.setDisabledByPolicy(disabled);
mHeaderTextContainerView.setVisibility(mQsDisabled ? View.GONE : View.VISIBLE);
mQuickQsStatusIcons.setVisibility(mQsDisabled ? View.GONE : View.VISIBLE);
updateResources();
}

@Override
public void onAttachedToWindow() {
super.onAttachedToWindow();
mStatusBarIconController.addIconGroup(mIconManager);
requestApplyInsets();
}

@Override
public WindowInsets onApplyWindowInsets(WindowInsets insets) {
DisplayCutout cutout = insets.getDisplayCutout();
Pair<Integer, Integer> padding = PhoneStatusBarView.cornerCutoutMargins(
cutout, getDisplay());
if (padding == null) {
mSystemIconsView.setPaddingRelative(
getResources().getDimensionPixelSize(R.dimen.status_bar_padding_start), 0,
getResources().getDimensionPixelSize(R.dimen.status_bar_padding_end), 0);
} else {
mSystemIconsView.setPadding(padding.first, 0, padding.second, 0);

}
return super.onApplyWindowInsets(insets);
}

@Override
@VisibleForTesting
public void onDetachedFromWindow() {
setListening(false);
mStatusBarIconController.removeIconGroup(mIconManager);
super.onDetachedFromWindow();
}

public void setListening(boolean listening) {
if (listening == mListening) {
return;
}
mHeaderQsPanel.setListening(listening);
mListening = listening;
mCarrierGroup.setListening(mListening);

if (listening) {
mZenController.addCallback(this);
mAlarmController.addCallback(this);
mContext.registerReceiver(mRingerReceiver,
new IntentFilter(AudioManager.INTERNAL_RINGER_MODE_CHANGED_ACTION));
} else {
mZenController.removeCallback(this);
mAlarmController.removeCallback(this);
mContext.unregisterReceiver(mRingerReceiver);
}
}

@Override
public void onClick(View v) {
if (v == mClockView) {
mActivityStarter.postStartActivityDismissingKeyguard(new Intent(
AlarmClock.ACTION_SHOW_ALARMS), 0);
} else if (v == mNextAlarmContainer && mNextAlarmContainer.isVisibleToUser()) {
if (mNextAlarm.getShowIntent() != null) {
mActivityStarter.postStartActivityDismissingKeyguard(
mNextAlarm.getShowIntent());
} else {
Log.d(TAG, "No PendingIntent for next alarm. Using default intent");
mActivityStarter.postStartActivityDismissingKeyguard(new Intent(
AlarmClock.ACTION_SHOW_ALARMS), 0);
}
} else if (v == mRingerContainer && mRingerContainer.isVisibleToUser()) {
mActivityStarter.postStartActivityDismissingKeyguard(new Intent(
Settings.ACTION_SOUND_SETTINGS), 0);
}
}

@Override
public void onNextAlarmChanged(AlarmManager.AlarmClockInfo nextAlarm) {
mNextAlarm = nextAlarm;
updateStatusText();
}

@Override
public void onZenChanged(int zen) {
updateStatusText();
}

@Override
public void onConfigChanged(ZenModeConfig config) {
updateStatusText();
}

public void updateEverything() {
post(() -> setClickable(!mExpanded));
}

public void setQSPanel(final QSPanel qsPanel) {
mQsPanel = qsPanel;
setupHost(qsPanel.getHost());
}

public void setupHost(final QSTileHost host) {
mHost = host;
//host.setHeaderView(mExpandIndicator);
mHeaderQsPanel.setQSPanelAndHeader(mQsPanel, this);
mHeaderQsPanel.setHost(host, null /* No customization in header */);


Rect tintArea = new Rect(0, 0, 0, 0);
int colorForeground = Utils.getColorAttrDefaultColor(getContext(),
android.R.attr.colorForeground);
float intensity = getColorIntensity(colorForeground);
int fillColor = mDualToneHandler.getSingleColor(intensity);
mBatteryRemainingIcon.onDarkChanged(tintArea, intensity, fillColor);
}

public void setCallback(Callback qsPanelCallback) {
mHeaderQsPanel.setCallback(qsPanelCallback);
}

private String formatNextAlarm(AlarmManager.AlarmClockInfo info) {
if (info == null) {
return "";
}
String skeleton = android.text.format.DateFormat
is24HourFormat(mContext, ActivityManager.getCurrentUser()) ? "EHm" : "Ehma";
String pattern = android.text.format.DateFormat
getBestDateTimePattern(Locale.getDefault(), skeleton);
return android.text.format.DateFormat.format(pattern, info.getTriggerTime()).toString();
}

public static float getColorIntensity(@ColorInt int color) {
return color == Color.WHITE ? 0 : 1;
}

public void setMargins(int sideMargins) {
for (int i = 0; i < getChildCount(); i++) {
View v = getChildAt(i);
// Prevents these views from getting set a margin.
// The Icon views all have the same padding set in XML to be aligned.
if (v == mSystemIconsView || v == mQuickQsStatusIcons || v == mHeaderQsPanel
|| v == mHeaderTextContainerView) {
continue;
}
RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) v.getLayoutParams();
lp.leftMargin = sideMargins;
lp.rightMargin = sideMargins;
}
}
}
```

从上述代码可以看出其实在updateResources()中给整个布局设置高度


设置高度可以这样修改



```
private void updateResources() {
Resources resources = mContext.getResources();
updateMinimumHeight();

// Update height for a few views, especially due to landscape mode restricting space.
mHeaderTextContainerView.getLayoutParams().height =
resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
com.android.internal.R.dimen.quick_qs_offset_height);
mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
         if (mQsDisabled) {
-            lp.height = resources.getDimensionPixelSize(
-                    com.android.internal.R.dimen.quick_qs_offset_height);
+            lp.height = resources.getDimensionPixelSize(R.dimen.quick_qs_height);
         } else {
-            lp.height = Math.max(getMinimumHeight(),
-                    resources.getDimensionPixelSize(
-                            com.android.internal.R.dimen.quick_qs_total_height));
+            lp.height = Math.max(getMinimumHeight(),resources.getDimensionPixelSize(R.dimen.quick_qs_height));
         }

setLayoutParams(lp);

updateStatusIconAlphaAnimator();
updateHeaderTextContainerAlphaAnimator();
}
```

quick\_qs\_height 就是根据项目需要设置的 首次下拉状态栏的高度(不包括通知栏)


## 4.分析两次下拉状态栏高度来确定怎么修改为一次下拉展开状态栏


#### 4.1分析QSFragment的源码



```
2.在StatusBar.java中 @+id/qs_frame的界面的控制就被转移到QSFragment，相应的layout也就变成了qs_panel
 //快捷面板
        View container = mStatusBarWindow.findViewById(R.id.qs_frame);
        if (container != null) {
            FragmentHostManager fragmentHostManager = FragmentHostManager.get(container);
            ExtensionFragmentListener.attachExtensonToFragment(container, QS.TAG, R.id.qs_frame,
                    Dependency.get(ExtensionController.class)
                            .newExtension(QS.class)
                            .withPlugin(QS.class)
                            .withFeature(PackageManager.FEATURE_AUTOMOTIVE, CarQSFragment::new)
                            .withDefault(QSFragment::new)
                            .build());
            final QSTileHost qsh = SystemUIFactory.getInstance().createQSTileHost(mContext, this,
                    mIconController);
            mBrightnessMirrorController = new BrightnessMirrorController(mStatusBarWindow,
                    (visible) -> {
                        mBrightnessMirrorVisible = visible;
                        updateScrimController();
                    });
            fragmentHostManager.addTagListener(QS.TAG, (tag, f) -> {
                QS qs = (QS) f;
                if (qs instanceof QSFragment) {
                    ((QSFragment) qs).setHost(qsh);
                    mQSPanel = ((QSFragment) qs).getQsPanel();
                    mQSPanel.setBrightnessMirror(mBrightnessMirrorController);
                    mKeyguardStatusBar.setQSPanel(mQSPanel);
                }
            });
        }




```

从上述代码可以分析出具体高度在QSFragment.java中可以获取



```
@Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mQSPanel = view.findViewById(R.id.quick_settings_panel);
        mQSDetail = view.findViewById(R.id.qs_detail);
        mHeader = view.findViewById(R.id.header);
        mFooter = view.findViewById(R.id.qs_footer);
        mContainer = view.findViewById(id.quick_settings_container);

        mQSDetail.setQsPanel(mQSPanel, mHeader, (View) mFooter);
        mQSAnimator = new QSAnimator(this,
                mHeader.findViewById(R.id.quick_qs_panel), mQSPanel);

        mQSCustomizer = view.findViewById(R.id.qs_customize);
        mQSCustomizer.setQs(this);
        if (savedInstanceState != null) {
            setExpanded(savedInstanceState.getBoolean(EXTRA_EXPANDED));
            setListening(savedInstanceState.getBoolean(EXTRA_LISTENING));
            setEditLocation(view);
            mQSCustomizer.restoreInstanceState(savedInstanceState);
            if (mQsExpanded) {
                mQSPanel.getTileLayout().restoreInstanceState(savedInstanceState);
            }
        }
        setHost(mHost);
    }

/**
     * The height this view wants to be. This is different from {@link #getMeasuredHeight} such that
     * during closing the detail panel, this already returns the smaller height.
     */
    @Override
    public int getDesiredHeight() {
        if (mQSCustomizer.isCustomizing()) {
            return getView().getHeight();
        }
        if (mQSDetail.isClosingDetail()) {
            LayoutParams layoutParams = (LayoutParams) mQSPanel.getLayoutParams();
            int panelHeight = layoutParams.topMargin + layoutParams.bottomMargin +
                    + mQSPanel.getMeasuredHeight();
            return panelHeight + getView().getPaddingBottom();
        } else {
			android.util.Log.e("QSFragment","getview.height:"+getView().getMeasuredHeight()+"---qspanel:"+mQSPanel.getMeasuredHeight()+"--mHeader:"+mHeader.getHeight()
			+"---mContainer:"+mContainer.getHeight());
            return getView().getMeasuredHeight();
        }
    }

在getDesiredHeight() 中可以打印出相关的高度值 这时只要能保证mContainer.getHeight()=mQSPanel.getMeasuredHeight()+状态栏高度+1就可以了
由于项目时间紧没有分析出设置相等要两次才能下拉出来状态栏 所以设置相差1px 也无影响
这样就保证下拉状态栏就全部展开了


```



