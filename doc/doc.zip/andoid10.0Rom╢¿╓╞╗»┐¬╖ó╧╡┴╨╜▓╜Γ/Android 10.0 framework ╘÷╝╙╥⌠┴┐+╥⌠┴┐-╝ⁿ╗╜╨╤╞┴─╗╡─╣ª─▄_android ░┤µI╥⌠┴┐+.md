






### 1.概述


定制化10.0 的产品开发中，在原生系统中设置息屏时间后，到息屏时间后屏幕息屏，当屏幕息屏后，想要唤醒屏幕只有按下power电源键才能唤醒屏幕由于产品开发的需要，需要增加音量+和音量-都可以唤醒屏幕，这就需要看相关事件然后做功能处理


### 2.framework 增加音量+音量-键唤醒屏幕的功能核心类



```
frameworks/base/core/java/android/view/KeyEvent.java
frameworks/base/services/core/java/com/android/server/power/PowerManagerService.java

```

### 3.framework 增加音量+音量-键唤醒屏幕的功能核心功能实现和分析


在系统中对于事件相关的都是在KeyEvent中，有对应的事件 供上层调用，系统KeyEvent事件有很多，  
 所以来分析下相关的事件


### 3.1首选在KeyEvent.java中增加唤醒的keycode值


路径:frameworks/base/core/java/android/view/KeyEvent.java



```
/** @hide */
public final boolean isWakeKey() {
return isWakeKey(mKeyCode);
}
/** @hide */
public static final boolean isWakeKey(int keyCode) {
    switch (keyCode) {
        case KeyEvent.KEYCODE_BACK:
        case KeyEvent.KEYCODE_MENU:
        case KeyEvent.KEYCODE_WAKEUP:
        case KeyEvent.KEYCODE_PAIRING:
        case KeyEvent.KEYCODE_STEM_1:
        case KeyEvent.KEYCODE_STEM_2:
        case KeyEvent.KEYCODE_STEM_3:
            return true;
    }
    return false;
}

在isWakeKey(int keyCode)中会判断是否是唤醒键
修改为:
/** @hide */
public static final boolean isWakeKey(int keyCode) {
switch (keyCode) {
case KeyEvent.KEYCODE_BACK:
case KeyEvent.KEYCODE_MENU:
case KeyEvent.KEYCODE_WAKEUP:
case KeyEvent.KEYCODE_PAIRING:
case KeyEvent.KEYCODE_STEM_1:
case KeyEvent.KEYCODE_STEM_2:
case KeyEvent.KEYCODE_STEM_3:
 +     case KeyEvent.KEYCODE_VOLUME_DOWN:

 +     case KeyEvent.KEYCODE_VOLUME_UP:

          return true;
  }
  return false;

}

```

在isWakeKey(int keyCode)根据KeyEvent的事件类型，来判断是否是息屏事件，所以要增加音量加音量减为唤醒事件，就需要  
 增加这两个事件到这里面，为唤醒事件


### 3.2在PhoneWindowManager.java中对唤醒屏幕事件做部分的修改


在PhoneWindowManager.java中的interceptKeyBeforeQueueing(KeyEvent event, int policyFlags)中是对各种事件做处理的  
 接下来看下相关代码



```
public int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
          if (!mSystemBooted) {
              // If we have not yet booted, don't let key events do anything.
 return 0;
 }
 
 final boolean interactive = (policyFlags & FLAG\_INTERACTIVE) != 0;
 final boolean down = event.getAction() == KeyEvent.ACTION\_DOWN;
 final boolean canceled = event.isCanceled();
 final int keyCode = event.getKeyCode();
 final int displayId = event.getDisplayId();
 
 final boolean isInjected = (policyFlags & WindowManagerPolicy.FLAG\_INJECTED) != 0;
 
 // If screen is off then we treat the case where the keyguard is open but hidden
 // the same as if it were open and in front.
 // This will prevent any keys other than the power button from waking the screen
 // when the keyguard is hidden by another activity.
 final boolean keyguardActive = (mKeyguardDelegate == null ? false :
 (interactive ?
 isKeyguardShowingAndNotOccluded() :
 mKeyguardDelegate.isShowing()));
 
 if (DEBUG\_INPUT) {
 Log.d(TAG, "interceptKeyTq keycode=" + keyCode
 + " interactive=" + interactive + " keyguardActive=" + keyguardActive
 + " policyFlags=" + Integer.toHexString(policyFlags));
 }
 
 // Basic policy based on interactive state.
 int result;
 boolean isWakeKey = (policyFlags & WindowManagerPolicy.FLAG\_WAKE) != 0
 || event.isWakeKey();
 if (interactive || (isInjected && !isWakeKey)) {
 // When the device is interactive or the key is injected pass the
 // key to the application.
 result = ACTION\_PASS\_TO\_USER;
 isWakeKey = false;
 
 if (interactive) {
 // If the screen is awake, but the button pressed was the one that woke the device
 // then don't pass it to the application
                  if (keyCode == mPendingWakeKey && !down) {
                      result = 0;
                  }
                  // Reset the pending key
                  mPendingWakeKey = PENDING_KEY_NULL;
              }
          } else if (!interactive && shouldDispatchInputWhenNonInteractive(displayId, keyCode)) {
              // If we're currently dozing with the screen on and the keyguard showing, pass the key
 // to the application but preserve its wake key status to make sure we still move
 // from dozing to fully interactive if we would normally go from off to fully
 // interactive.
 result = ACTION\_PASS\_TO\_USER;
 // Since we're dispatching the input, reset the pending key
              mPendingWakeKey = PENDING_KEY_NULL;
          } else {
              // When the screen is off and the key is not injected, determine whether
              // to wake the device but don't pass the key to the application.
 result = 0;
 if (isWakeKey && (!down || !isWakeKeyWhenScreenOff(keyCode))) {
 isWakeKey = false;
 }
 // Cache the wake key on down event so we can also avoid sending the up event to the app
 if (isWakeKey && down) {
 mPendingWakeKey = keyCode;
 }
 }
 
 // If the key would be handled globally, just return the result, don't worry about special
          // key processing.
          if (isValidGlobalKey(keyCode)
                  && mGlobalKeyManager.shouldHandleGlobalKey(keyCode, event)) {
              if (isWakeKey) {
                  wakeUp(event.getEventTime(), mAllowTheaterModeWakeFromKey,
                          PowerManager.WAKE_REASON_WAKE_KEY, "android.policy:KEY");
              }
              return result;
          }
....
}
private boolean isWakeKeyWhenScreenOff(int keyCode) {
switch (keyCode) {
// ignore volume keys unless docked
case KeyEvent.KEYCODE_VOLUME_UP:
case KeyEvent.KEYCODE_VOLUME_DOWN:
case KeyEvent.KEYCODE_VOLUME_MUTE:
return mDefaultDisplayPolicy.getDockMode() != Intent.EXTRA_DOCK_STATE_UNDOCKED;
        // ignore media and camera keys
        case KeyEvent.KEYCODE_MUTE:
        case KeyEvent.KEYCODE_HEADSETHOOK:
        case KeyEvent.KEYCODE_MEDIA_PLAY:
        case KeyEvent.KEYCODE_MEDIA_PAUSE:
        case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
        case KeyEvent.KEYCODE_MEDIA_STOP:
        case KeyEvent.KEYCODE_MEDIA_NEXT:
        case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
        case KeyEvent.KEYCODE_MEDIA_REWIND:
        case KeyEvent.KEYCODE_MEDIA_RECORD:
        case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
        case KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK:
        case KeyEvent.KEYCODE_CAMERA:
            return false;
    }
    return true;
}

```

在interceptKeyBeforeQueueing的主要唤醒屏幕代码



```
if (isWakeKey && (!down || !isWakeKeyWhenScreenOff(keyCode))) {
                  isWakeKey = false;
              }
              // Cache the wake key on down event so we can also avoid sending the up event to the app
              if (isWakeKey && down) {
                  mPendingWakeKey = keyCode;
              }

```

对isWakeKeyWhenScreenOff(keyCode)判断如果不是唤醒事件就不做唤醒屏幕处理  
 通过注释可以看出 这些键是被忽略的唤醒键 所以要去掉音量+和音量-  
 修改为:



```
private boolean isWakeKeyWhenScreenOff(int keyCode) {
switch (keyCode) {
// ignore volume keys unless docked
     -  case KeyEvent.KEYCODE_VOLUME_UP:

     -  case KeyEvent.KEYCODE_VOLUME_DOWN:

     +  /*case KeyEvent.KEYCODE_VOLUME_UP:

     +   case KeyEvent.KEYCODE_VOLUME_DOWN:*/

      case KeyEvent.KEYCODE_VOLUME_MUTE:
          return mDefaultDisplayPolicy.getDockMode() != Intent.EXTRA_DOCK_STATE_UNDOCKED;

      // ignore media and camera keys
      case KeyEvent.KEYCODE_MUTE:
      case KeyEvent.KEYCODE_HEADSETHOOK:
      case KeyEvent.KEYCODE_MEDIA_PLAY:
      case KeyEvent.KEYCODE_MEDIA_PAUSE:
      case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
      case KeyEvent.KEYCODE_MEDIA_STOP:
      case KeyEvent.KEYCODE_MEDIA_NEXT:
      case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
      case KeyEvent.KEYCODE_MEDIA_REWIND:
      case KeyEvent.KEYCODE_MEDIA_RECORD:
      case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
      case KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK:
      case KeyEvent.KEYCODE_CAMERA:
          return false;
  }
  return true;

}

```




