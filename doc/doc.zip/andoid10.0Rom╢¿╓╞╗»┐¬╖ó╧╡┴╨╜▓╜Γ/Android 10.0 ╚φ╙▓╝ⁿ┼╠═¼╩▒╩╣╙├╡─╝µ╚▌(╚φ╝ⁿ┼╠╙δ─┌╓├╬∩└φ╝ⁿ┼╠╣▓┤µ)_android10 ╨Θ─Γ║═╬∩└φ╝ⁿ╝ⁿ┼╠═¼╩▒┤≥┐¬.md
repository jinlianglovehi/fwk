






### 1.概述


在有些设备上，如果外接了USB扫描枪之类的设备，当插入USB扫描枪以后，然后点击输入调用输入法的时候，没有反应，但是拔掉USB扫描枪以后，输入法又能正常使用，这说明和输入法起冲突了，询问了好多同时，说可能把会把USB扫描枪识别为硬键盘，所以就关闭了软键盘  
 这样肯定是不行的，这就要解决冲突的问题 看是哪里识别有误了


### 2.软硬盘同时使用兼容性的相关代码



```
frameworks/base/core/java/android/inputmethodservice/InputMethodService.java
frameworks/base/core/java/android/content/res/Configuration.java

```

### 3.软硬盘同时使用兼容性的相关代码功能分析和实现功能


### 3.1首先看下Configuration设备的配置信息


Configuration类专门用于描述手机设备上的配置信息,这些配置信息既包括用户特定的配置项,也包括系统的动态设备配 置



```
    public final class Configuration implements Parcelable, Comparable<Configuration> {
     /** @hide */
     public static final Configuration EMPTY = new Configuration();
 
     private static final String TAG = "Configuration";
 
	public int keyboard;
  
      /** Constant for {@link #keyboardHidden}: a value indicating that no value has been set. \*/
      public static final int KEYBOARDHIDDEN_UNDEFINED = 0;
      /** Constant for {@link #keyboardHidden}, value corresponding to the
       * <a href="{@docRoot}guide/topics/resources/providing-resources.html#KeyboardAvailQualifier">keysexposed</a>
       * resource qualifier. */
      public static final int KEYBOARDHIDDEN_NO = 1;
      /** Constant for {@link #keyboardHidden}, value corresponding to the
       * <a href="{@docRoot}guide/topics/resources/providing-resources.html#KeyboardAvailQualifier">keyshidden</a>
       * resource qualifier. */
      public static final int KEYBOARDHIDDEN_YES = 2;
      /** Constant matching actual resource implementation. {@hide} */
      public static final int KEYBOARDHIDDEN_SOFT = 3;
  
      /**
       * A flag indicating whether any keyboard is available.  Unlike
       * {@link #hardKeyboardHidden}, this also takes into account a soft
       * keyboard, so if the hard keyboard is hidden but there is soft
       * keyboard available, it will be set to NO.  Value is one of:
       * {@link #KEYBOARDHIDDEN\_NO}, {@link #KEYBOARDHIDDEN\_YES}.
       */
      public int keyboardHidden;
  
      /** Constant for {@link #hardKeyboardHidden}: a value indicating that no value has been set. \*/
      public static final int HARDKEYBOARDHIDDEN_UNDEFINED = 0;
      /** Constant for {@link #hardKeyboardHidden}, value corresponding to the
       * physical keyboard being exposed. */
      public static final int HARDKEYBOARDHIDDEN_NO = 1;
      /** Constant for {@link #hardKeyboardHidden}, value corresponding to the
       * physical keyboard being hidden. */
      public static final int HARDKEYBOARDHIDDEN_YES = 2;


```

HARDKEYBOARDHIDDEN\_YES 物理键盘被隐藏  
 HARDKEYBOARDHIDDEN\_NO 物理键盘被显示  
 所以需要查看哪里调用了Configuration.HARDKEYBOARDHIDDEN\_YES导致误将硬键盘被隐藏


### 3.2查看InputMethodService.java类的键盘兼容分析


InputMethodService。它是InputMethod的一个完整实现，同时也是输入法服务，负责管理输入法相关的事件功能，InputMethodService.java是负责对输入事件的管理，这里在插入物理键盘等输入设备后，会分析是否启用软键盘看哪里是否在启用硬件盘的时候关闭了软键盘的使用


frameworks/base/core/java/android/inputmethodservice/InputMethodService.java



```
public class InputMethodService extends AbstractInputMethodService {
      static final String TAG = "InputMethodService";
      static final boolean DEBUG = false;

      LayoutInflater mInflater;
      TypedArray mThemeAttrs;
      @UnsupportedAppUsage
      View mRootView;
      SoftInputWindow mWindow;
      boolean mInitialized;
      boolean mViewsCreated;
      // IME views visibility.
      boolean mDecorViewVisible;
      boolean mDecorViewWasVisible;
      boolean mInShowWindow;
      // True if pre-rendering of IME views/window is supported.
      boolean mCanPreRender;
      // If IME is pre-rendered.
      boolean mIsPreRendered;
      // IME window visibility.
      // Use (mDecorViewVisible && mWindowVisible) to check if IME is visible to the user.
      boolean mWindowVisible;
  
      ViewGroup mFullscreenArea;
      FrameLayout mExtractFrame;
      FrameLayout mCandidatesFrame;
      FrameLayout mInputFrame;
  
      IBinder mToken;
  
      InputBinding mInputBinding;
      InputConnection mInputConnection;
      boolean mInputStarted;
      boolean mInputViewStarted;
      boolean mCandidatesViewStarted;
      InputConnection mStartedInputConnection;
      EditorInfo mInputEditorInfo;
  
      int mShowInputFlags;
      boolean mShowInputRequested;
public boolean onShowInputRequested(int flags, boolean configChange) {
          if (!onEvaluateInputViewShown()) {
              return false;
          }
          if ((flags&InputMethod.SHOW\_EXPLICIT) == 0) {
 if (!configChange && onEvaluateFullscreenMode()) {
                  // Don't show if this is not explicitly requested by the user and
 // the input method is fullscreen. That would be too disruptive.
 // However, we skip this change for a config change, since if
 // the IME is already shown we do want to go into fullscreen
 // mode at this point.
 return false;
 }
 if (!mSettingsObserver.shouldShowImeWithHardKeyboard() &&
 getResources().getConfiguration().keyboard != Configuration.KEYBOARD\_NOKEYS) {
 // And if the device has a hard keyboard, even if it is
 // currently hidden, don't show the input method implicitly.
                  // These kinds of devices don't need it that much.
                  return false;
              }
          }
          return true;
      }
 @Override public void onConfigurationChanged(Configuration newConfig) {
          super.onConfigurationChanged(newConfig);
          resetStateForNewConfiguration();
      }
  
      private void resetStateForNewConfiguration() {
          boolean visible = mDecorViewVisible;
          int showFlags = mShowInputFlags;
          boolean showingInput = mShowInputRequested;
          CompletionInfo[] completions = mCurCompletions;
          initViews();
          mInputViewStarted = false;
          mCandidatesViewStarted = false;
          if (mInputStarted) {
              doStartInput(getCurrentInputConnection(),
                      getCurrentInputEditorInfo(), true);
          }
          if (visible) {
              if (showingInput) {
                  // If we were last showing the soft keyboard, try to do so again.
                  if (dispatchOnShowInputRequested(showFlags, true)) {
                      showWindow(true);
                      if (completions != null) {
                          mCurCompletions = completions;
                          onDisplayCompletions(completions);
                      }
                  } else {
                      doHideWindow();
                  }
              } else if (mCandidatesVisibility == View.VISIBLE) {
                  // If the candidates are currently visible, make sure the
                  // window is shown for them.
                  showWindow(false);
              } else {
                  // Otherwise hide the window.
                  doHideWindow();
              }
              // If user uses hard keyboard, IME button should always be shown.
              boolean showing = onEvaluateInputViewShown();
              setImeWindowStatus(IME_ACTIVE | (showing ? IME_VISIBLE : 0), mBackDisposition);
          }
      }
  
onEvaluateInputViewShown()方法里：
/**
* Override this to control when the soft input area should be shown to the user.  The default
* implementation returns {@code false} when there is no hard keyboard or the keyboard is hidden
* unless the user shows an intention to use software keyboard.  If you change what this
* returns, you will need to call {@link #updateInputViewShown()} yourself whenever the returned
* value may have changed to have it re-evaluated and applied.
*
* <p>When you override this method, it is recommended to call
* {@code super.onEvaluateInputViewShown()} and return {@code true} when {@code true} is
* returned.</p>
*/
@CallSuper
public boolean onEvaluateInputViewShown() {
if (mSettingsObserver == null) {
Log.w(TAG, "onEvaluateInputViewShown: mSettingsObserver must not be null here.");
return false;
}
if (mSettingsObserver.shouldShowImeWithHardKeyboard()) {
return true;
}
Configuration config = getResources().getConfiguration();
return config.keyboard == Configuration.KEYBOARD_NOKEYS
|| config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES;
}

```

resetStateForNewConfiguration()调用onEvaluateInputViewShown()重新设置软键盘相关的配置  
 onShowInputRequested根据cofig 重新设置软键盘，所以最终通过  
 代码分析可以看出onEvaluateInputViewShown() 是软键盘调用的时候 来判断是否显示键盘，所以对于实现键盘硬件盘和软件盘就需要在onEvaluateInputViewShown中做修改  
 修改如下:



```
public boolean onEvaluateInputViewShown() {
if (mSettingsObserver == null) {
Log.w(TAG, "onEvaluateInputViewShown: mSettingsObserver must not be null here.");
return false;
}
if (mSettingsObserver.shouldShowImeWithHardKeyboard()) {
return true;
}
Configuration config = getResources().getConfiguration();
- return config.keyboard == Configuration.KEYBOARD_NOKEYS
-         || config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES;
+ return true;
}

```




