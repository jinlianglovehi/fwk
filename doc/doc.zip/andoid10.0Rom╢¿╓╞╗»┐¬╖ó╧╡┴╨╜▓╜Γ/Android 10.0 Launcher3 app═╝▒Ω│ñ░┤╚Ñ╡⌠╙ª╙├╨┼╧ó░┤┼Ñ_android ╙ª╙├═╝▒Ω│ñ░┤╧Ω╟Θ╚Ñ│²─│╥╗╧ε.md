



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Launcher3 app图标长按去掉应用信息按钮的核心代码](#%C2%A02.Launcher3%20app%E5%9B%BE%E6%A0%87%E9%95%BF%E6%8C%89%E5%8E%BB%E6%8E%89%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E6%8C%89%E9%92%AE%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.Launcher3 app图标长按去掉应用信息按钮的核心代码分析](#3.Launcher3%20app%E5%9B%BE%E6%A0%87%E9%95%BF%E6%8C%89%E5%8E%BB%E6%8E%89%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E6%8C%89%E9%92%AE%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 SystemShortcut.java关于应用信息的分析](#%C2%A0%203.1%20SystemShortcut.java%E5%85%B3%E4%BA%8E%E5%BA%94%E7%94%A8%E4%BF%A1%E6%81%AF%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 PopupContainerWithArrow.java关于弹窗的相关代码](#3.2%20PopupContainerWithArrow.java%E5%85%B3%E4%BA%8E%E5%BC%B9%E7%AA%97%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


  在Launcher3定制化开发中，在Launcher3的app列表页会在长按时，弹出微件和应用信息两个按钮，点击对应的按钮跳转到相关的功能页面，现在由于禁用应用信息，不让进入到应用信息页面所以要去掉应用信息按钮,这就要从加载应用信息按钮流程开始分析然后去掉应用信息按钮


效果图如下:


![](https://img-blog.csdnimg.cn/a6e6e7ede0f44847bf69058c7224df97.png)


##  2.Launcher3 app图标长按去掉应用信息按钮的核心代码



```
   packages/apps/Launcher3/src/com/android/launcher3/popup/SystemShortcutFactory.java
   packages/apps/Launcher3/src/com/android/launcher3/popup/PopupContainerWithArrow.java
   packages/apps/Launcher3/src/com/android/launcher3/popup/SystemShortcut.java
```

## 3.Launcher3 app图标长按去掉应用信息按钮的核心代码分析



Shortcuts在系统Launcher3的主要功能就是  
 每个Shortcut可以对应一个或者多个Intent，它们各自会通过特定的Intent来启动你的应用程序，例如：  
     对于一个地图应用，可以提供一个Shortcut导航用户至某个特定的地点  
     对于一个通信应用，可以提供一个Shortcut来发送消息给好友  
     对于一个视频应用，可以提供一个Shortcut来播放某个电视剧  
     对于一个游戏应用，可以提供一个Shortcut来继续上次的存档  
 当一个Shortcut包括了多个Intent时，用户的一次点击会触发所有这些Intent，跳转到对应的功能，  
 应用程序可以在Launcher中放置一些常用的应用入口以方便用户使用，


ShortcutManager提供了API来动态管理Shortcut，包括：  
     通过setDynamicShortcuts() 来更新整个动态Shortcut列表，或者通过addDynamicShortcuts() 来向已经存在的列表中添加新的条目  
     通过updateShortcuts() 来进行更新  
     通过removeDynamicShortcuts()来删除指定的Shortcuts，或者通过removeAllDynamicShortcuts()来删除所有动态Shortcuts



##   3.1 SystemShortcut.java关于应用信息的分析


  从AS开发工具分析弹出应用信息布局就是在此类



```
 public abstract class SystemShortcut<T extends BaseDraggingActivity> extends ItemInfo {
    private final int mIconResId;
    private final int mLabelResId;
    private final Icon mIcon;
    private final CharSequence mLabel;
    private final CharSequence mContentDescription;
    private final int mAccessibilityActionId;

    public SystemShortcut(int iconResId, int labelResId) {
        mIconResId = iconResId;
        mLabelResId = labelResId;
        mAccessibilityActionId = labelResId;
        mIcon = null;
        mLabel = null;
        mContentDescription = null;
    }

    public SystemShortcut(Icon icon, CharSequence label, CharSequence contentDescription,
            int accessibilityActionId) {
        mIcon = icon;
        mLabel = label;
        mContentDescription = contentDescription;
        mAccessibilityActionId = accessibilityActionId;
        mIconResId = 0;
        mLabelResId = 0;
    }

    public SystemShortcut(SystemShortcut other) {
        mIconResId = other.mIconResId;
        mLabelResId = other.mLabelResId;
        mIcon = other.mIcon;
        mLabel = other.mLabel;
        mContentDescription = other.mContentDescription;
        mAccessibilityActionId = other.mAccessibilityActionId;
    }

public static class Widgets extends SystemShortcut<Launcher> {

        public Widgets() {
            super(R.drawable.ic_widget, R.string.widget_button_text);
        }

        @Override
        public View.OnClickListener getOnClickListener(final Launcher launcher,
                final ItemInfo itemInfo) {
            final List<WidgetItem> widgets =
                    launcher.getPopupDataProvider().getWidgetsForPackageUser(new PackageUserKey(
                            itemInfo.getTargetComponent().getPackageName(), itemInfo.user));
            if (widgets == null) {
                return null;
            }
            return (view) -> {
                if (launcher.getPackageManager().isSafeMode()) {
                    Toast.makeText(launcher, R.string.safemode_widget_error, Toast.LENGTH_SHORT).show();
                    return ;
                }
                AbstractFloatingView.closeAllOpenViews(launcher);
                WidgetsBottomSheet widgetsBottomSheet =
                        (WidgetsBottomSheet) launcher.getLayoutInflater().inflate(
                                R.layout.widgets_bottom_sheet, launcher.getDragLayer(), false);
                widgetsBottomSheet.populateAndShow(itemInfo);
                launcher.getUserEventDispatcher().logActionOnControl(Action.Touch.TAP,
                        ControlType.WIDGETS_BUTTON, view);
            };
        }
    }

    public static class AppInfo extends SystemShortcut {
        public AppInfo() {
            super(R.drawable.ic_info_no_shadow, R.string.app_info_drop_target_label);
        }

        @Override
        public View.OnClickListener getOnClickListener(
                BaseDraggingActivity activity, ItemInfo itemInfo) {
            return (view) -> {
                dismissTaskMenuView(activity);
                Rect sourceBounds = activity.getViewBounds(view);
                new PackageManagerHelper(activity).startDetailsActivityForInfo(
                        itemInfo, sourceBounds, ActivityOptions.makeBasic().toBundle());
                activity.getUserEventDispatcher().logActionOnControl(Action.Touch.TAP,
                        ControlType.APPINFO_TARGET, view);
            };
        }
    }
...}
```

从上述SystemShortcut.java的分析代码可以看出，在AppInfo类就是应用信息按钮的信息 getOnClickListener(）就是长按事件,而具体的弹窗的布局就是PopupContainerWithArrow.java类 接下来分析PopupContainerWithArrow.java类,看下如何布局弹窗的


## 3.2 PopupContainerWithArrow.java关于弹窗的相关代码


PopupContainerWithArrow:悬浮窗实际就是一个自定义view，  
 PopupContainerWithArrow就是它的实现类，它继承自AbstractFloatingView  
 用户长按桌面应用图标，该长按事件在Launcher里处理，再经过Workspace的处理最后会调用PopupContainerWithArrow的showForIcon方法来显示悬浮窗。在showForIcon里通过PopupDataProvider获取要应用的shortcuts(包括静态和动态的shortcuts),系统shortcuts(当前只有widget和AppInfo shortcut




```
   public class PopupContainerWithArrow extends ArrowPopup implements DragSource,
        DragController.DragListener, View.OnLongClickListener,
        View.OnTouchListener, PopupDataChangeListener {

    

    public PopupContainerWithArrow(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mStartDragThreshold = getResources().getDimensionPixelSize(
                R.dimen.deep_shortcuts_start_drag_threshold);
        mAccessibilityDelegate = new ShortcutMenuAccessibilityDelegate(mLauncher);
    }

    public PopupContainerWithArrow(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PopupContainerWithArrow(Context context) {
        this(context, null, 0);
    }
   
   /**
     * Shows the notifications and deep shortcuts associated with {@param icon}.
     * @return the container if shown or null.
     */
    public static PopupContainerWithArrow showForIcon(BubbleTextView icon) {
        Launcher launcher = Launcher.getLauncher(icon.getContext());
        if (getOpen(launcher) != null) {
            // There is already an items container open, so don't open this one.
            icon.clearFocus();
            return null;
        }
        ItemInfo itemInfo = (ItemInfo) icon.getTag();
        if (!DeepShortcutManager.supportsShortcuts(itemInfo)) {
            return null;
        }

        final PopupContainerWithArrow container =
                (PopupContainerWithArrow) launcher.getLayoutInflater().inflate(
                        R.layout.popup_container, launcher.getDragLayer(), false);
        container.populateAndShow(icon, itemInfo, SystemShortcutFactory.INSTANCE.get(launcher));
        return container;
    }

```

通过populateAndShow显示弹窗信息 而SystemShortcutFactory.INSTANCE.get(launcher)负责构建弹窗的信息比如应用信息 微件 设置等信息



```
protected void populateAndShow(
            BubbleTextView icon, ItemInfo item, SystemShortcutFactory factory) {
        PopupDataProvider popupDataProvider = mLauncher.getPopupDataProvider();
        populateAndShow(icon,
                popupDataProvider.getShortcutCountForItem(item),
                popupDataProvider.getNotificationKeysForItem(item),
                factory.getEnabledShortcuts(mLauncher, item));
    }

    public ViewGroup getSystemShortcutContainerForTesting() {
        return mSystemShortcutContainer;
    }

    @TargetApi(Build.VERSION_CODES.P)
    protected void populateAndShow(final BubbleTextView originalIcon, int shortcutCount,
            final List<NotificationKeyData> notificationKeys, List<SystemShortcut> systemShortcuts) {
        mNumNotifications = notificationKeys.size();
        mOriginalIcon = originalIcon;

       // add core start  去掉应用信息后 没有其他信息弹窗出现倒三角的情况 所以返回
        if(systemShortcuts.size()==0)return;
      // add core end 

        // Add views
        if (mNumNotifications > 0) {
            // Add notification entries
            View.inflate(getContext(), R.layout.notification_content, this);
            mNotificationItemView = new NotificationItemView(this);
            if (mNumNotifications == 1) {
                mNotificationItemView.removeFooter();
            }
            updateNotificationHeader();
        }
        int viewsToFlip = getChildCount();
        mSystemShortcutContainer = this;

  
    }

....
}
```

从上述分析代码中可以看出最关键的代码是在populateAndShow方法中，通过这里可以分析出哪里需要弹窗出现的信息，哪些不需要弹窗出现的信息


##  3.3 SystemShortcutFactory.java关于构造弹窗信息的相关代码



```
   public class SystemShortcutFactory implements ResourceBasedOverride {

    public static final MainThreadInitializedObject<SystemShortcutFactory> INSTANCE =
            new MainThreadInitializedObject<>(c -> Overrides.getObject(
                    SystemShortcutFactory.class, c, R.string.system_shortcut_factory_class));

    /** Note that these are in order of priority. */
    private final SystemShortcut[] mAllShortcuts;

    @SuppressWarnings("unused")
    public SystemShortcutFactory() {
        this(new SystemShortcut.AppInfo(),new SystemShortcut.Widgets(), new SystemShortcut.Install());
    }

    protected SystemShortcutFactory(SystemShortcut... shortcuts) {
        mAllShortcuts = shortcuts;
    }

    public @NonNull List<SystemShortcut> getEnabledShortcuts(Launcher launcher, ItemInfo info) {
        List<SystemShortcut> systemShortcuts = new ArrayList<>();
        for (SystemShortcut systemShortcut : mAllShortcuts) {
            if (systemShortcut.getOnClickListener(launcher, info) != null) {
                systemShortcuts.add(systemShortcut);
            }
        }
        return systemShortcuts;
    }
}
```

    public SystemShortcutFactory() {  
         this(new SystemShortcut.AppInfo(),new SystemShortcut.Widgets(), new SystemShortcut.Install());  
     }  
     就是构造应用信息 微件 设置等弹窗信息


所以修改为



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/popup/SystemShortcutFactory.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/popup/SystemShortcutFactory.java
@@ -37,8 +37,7 @@ public class SystemShortcutFactory implements ResourceBasedOverride {
 
     @SuppressWarnings("unused")
     public SystemShortcutFactory() {
-        this(new SystemShortcut.AppInfo(),
-                new SystemShortcut.Widgets(), new SystemShortcut.Install());
+        this(new SystemShortcut.Widgets(), new SystemShortcut.Install());
     }
```



