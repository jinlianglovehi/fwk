



## 1.概述


  
    在10.0的系统产品开发中,在Launcher3中系统默认是上滑抽屉模式，而产品需求要求修改为单层模式，而在前面两篇文章中已经  
 修改了第一和第二部分，接下来要继续修改Launcher3去掉抽屉模式，修改双层为单层系列的第三讲


## 2.Launcher3去掉抽屉模式 双层改成单层系列三的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/DeleteDropTarget.java
packages/apps/Launcher3/src/com/android/launcher3/dragndrop/DragController.java
```

## 3.Launcher3去掉抽屉模式 双层改成单层系列三的核心功能分析和实现


## 


在Launcher3中的去掉抽屉的开发过程中，需要更改的内容  
 1.显示所有app在桌面上  
 2.去掉上划展开应用列表  
 3.长按拖动图标去掉删除改成取消 卸载


在Launcher3的界面的布局的launcher.xml中, 从上往下分别为:DeleteDropTarget(应用卸载区域,它是一个DropTarget)  
 Workspace(页面容器,一个页面是一个CellLayout)  
 PageIndicator(指示器,指示workspace当前位于第几个页面)  
 Hotseat(底部图标区域)


长按拖动图标去掉删除改成取消 卸载  
 长按图标出现删除,卸载栏的源码为:  
 src/com.android.launcher3.DropTargetBar  
 应用图标拖动的控制类的源码为:  
 src/com.android.launcher3.dragndrop.DragController  
 删除,卸载类的源码为:  
 src/com.android.launcher3.DeleteDropTarget  
 src/com.android.launcher3.SecondaryDropTarget  
 拖动应用图标或者文件夹的时候我们需要把删除改成取消,并且拖到取消后桌面不能移除图标  
 DeleteDropTarget.java: 中更改长按时的监听，开始时直接屏蔽删除按钮  
 所以说从上面的源码分析得知，关于去掉拖拽时显示的删除源码就需要从  
 DeleteDropTarget.java的源码分析


##    3.1 在DeleteDropTarget.java页面关于删除改成取消的相关修改



```
      public class DeleteDropTarget extends ButtonDropTarget {
  
      private int mControlType = ControlType.DEFAULT_CONTROLTYPE;
  
      public DeleteDropTarget(Context context, AttributeSet attrs) {
          this(context, attrs, 0);
      }
  
      public DeleteDropTarget(Context context, AttributeSet attrs, int defStyle) {
          super(context, attrs, defStyle);
      }
  
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        // Get the hover color
        mHoverColor = getResources().getColor(R.color.delete_target_hover_tint);

        setDrawable(R.drawable.ic_remove_shadow);
    }

    @Override
    public void onDragStart(DropTarget.DragObject dragObject, DragOptions options) {
        super.onDragStart(dragObject, options);
        setTextBasedOnDragSource(dragObject.dragInfo);
        setControlTypeBasedOnDragSource(dragObject.dragInfo);
    }

    /**
     * @return true for items that should have a "Remove" action in accessibility.
     */
    @Override
    public boolean supportsAccessibilityDrop(ItemInfo info, View view) {
        if (MultiModeController.isSingleLayerMode()) {
            return (info instanceof WorkspaceItemInfo
                    && info.itemType != LauncherSettings.Favorites.ITEM_TYPE_APPLICATION)
                    || (info instanceof LauncherAppWidgetInfo)
                    || (info instanceof PendingAddItemInfo);
        }
        if (info instanceof WorkspaceItemInfo) {
            // Support the action unless the item is in a context menu.
            return info.screenId >= 0;
        }

        return (info instanceof LauncherAppWidgetInfo)
                || (info instanceof FolderInfo);
    }
```

在DeleteDropTarget.java的上述方法中可以看到在相关构造方法和onFinishInflate()  
 开始设置DeleteDropTarget的显示图标



```
   /**
       * Set the drop target's text to either "Remove" or "Cancel" depending on the drag item.
       */
      private void setTextBasedOnDragSource(ItemInfo item) {
          if (!TextUtils.isEmpty(mText)) {
              mText = getResources().getString(canRemove(item)
                      ? R.string.remove_drop_target_label
                      : android.R.string.cancel);
              setContentDescription(mText);
              requestLayout();
          }
      }


```

在setTextBasedOnDragSource(ItemInfo item)中，就是显示开始拖拽的实现，显示是删除的文字，所以就  
 需要在这里修改，具体修改如下：  
  



```
      private void setTextBasedOnDragSource(ItemInfo item) {
          if (!TextUtils.isEmpty(mText)) {
              mText = getResources().getString(canRemove(item)
                      ? R.string.remove_drop_target_label
                      : android.R.string.cancel);
+            if(BaseFlags.IS_SINGLE_MODEL){
+                mText = getResources().getString(isCanDrop(item)
+                        ? R.string.remove_drop_target_label
+                        : android.R.string.cancel);
+            }
              setContentDescription(mText);
              requestLayout();
          }
      }
```

关于文字的第二部分的修改  
    /\*\*  
        \* Set mControlType depending on the drag item.  
        \*/  
       private void setControlTypeBasedOnDragSource(ItemInfo item) {  
           mControlType = item.id != ItemInfo.NO\_ID ? ControlType.REMOVE\_TARGET  
                   : ControlType.CANCEL\_TARGET;  
       }  
 在DeleteDropTarget.java的setControlTypeBasedOnDragSource(ItemInfo item)的关于设置拖动删除的ControlType  
 的类型中判断是否需要删除来显示ControlType的类型，具体修改如下:



```
    private void setControlTypeBasedOnDragSource(ItemInfo item) {
         mControlType = item.id != ItemInfo.NO_ID ? ControlType.REMOVE_TARGET
                 : ControlType.CANCEL_TARGET;
+        if(BaseFlags.IS_SINGLE_MODEL) {
+            mControlType = isCanDrop(item) ? ControlType.REMOVE_TARGET
+                    : ControlType.CANCEL_TARGET;
+        }
+    }
+    private boolean isCanDrop(ItemInfo item){
+        return !(item.itemType == LauncherSettings.Favorites.ITEM_TYPE_APPLICATION ||
+                item.itemType == LauncherSettings.Favorites.ITEM_TYPE_FOLDER);
     }

```

## 3.2 DragController.java关于拖拽的时候判断如果是系统app，去掉卸载的功能



```
      private void drop(DropTarget dropTarget, Runnable flingAnimation) {
          final int[] coordinates = mCoordinatesTemp;
          mDragObject.x = coordinates[0];
          mDragObject.y = coordinates[1];
  
          // Move dragging to the final target.
          if (dropTarget != mLastDropTarget) {
              if (mLastDropTarget != null) {
                  mLastDropTarget.onDragExit(mDragObject);
              }
              mLastDropTarget = dropTarget;
              if (dropTarget != null) {
                  dropTarget.onDragEnter(mDragObject);
              }
          }
  
          mDragObject.dragComplete = true;
          if (mIsInPreDrag) {
              if (dropTarget != null) {
                  dropTarget.onDragExit(mDragObject);
              }
              return;
          }
  
          // Drop onto the target.
          boolean accepted = false;
          if (dropTarget != null) {
              dropTarget.onDragExit(mDragObject);
              if (dropTarget.acceptDrop(mDragObject)) {
                  if (flingAnimation != null) {
                      flingAnimation.run();
                  } else {
                      dropTarget.onDrop(mDragObject, mOptions);
                  }
                  accepted = true;
+                if (BaseFlags.IS_SINGLE_MODEL && dropTarget instanceof DeleteDropTarget &&
+                        isNeedCancelDrag(mDragObject.dragInfo)) {
+                    cancelDrag();
+                }
              }
          }
          final View dropTargetAsView = dropTarget instanceof View ? (View) dropTarget : null;
          mLauncher.getUserEventDispatcher().logDragNDrop(mDragObject, dropTargetAsView);
          dispatchDropComplete(dropTargetAsView, accepted);
      }
+    private boolean isNeedCancelDrag(ItemInfo item){
+        return (item.itemType == LauncherSettings.Favorites.ITEM_TYPE_APPLICATION ||
+            item.itemType == LauncherSettings.Favorites.ITEM_TYPE_FOLDER);
+    }

```

在DragController.java的上述代码中，在drop(DropTarget dropTarget, Runnable flingAnimation) 的  
 相关方法处理，开始拖拽app图标的功能处理，所以可以在if (dropTarget != null) 中，可以在这里对应  
 的系统app进行取消拖拽返回的初始拖拽的位置，在isNeedCancelDrag(ItemInfo item)中可以判断  
 是否需要卸载的app了



