






在android系统中，UsbManager调用接口，会binder通信到UsbService。而UsbService又有两个实例，一个


UsbHostManager，一个UsbDeviceManager。UsbDeviceManager和


UsbHostManager是一个相对的概念，


UsbHostManager是手机作为一个host，比如键盘、鼠标通过usb连接手机。而UsbDeviceManager是手机与电脑连接  
 USB的连接方式都是在UsbDeviceManager.java中处理的  
 接下来看下frameworks/base/services/usb/java/com/android/server/usb/UsbDeviceManager.java



```
 @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_UPDATE_STATE:
                    mConnected = (msg.arg1 == 1);
                    mConfigured = (msg.arg2 == 1);

                    updateUsbNotification(false);
                    updateAdbNotification(false);
                    if (mBootCompleted) {
                        /*SPRD: add for usb sim activate @{ */
                        if (mConnected && isUsbShouldActived() && !mIsSimChecking) {
                            setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                            clearNotification();
                        }
                        /* @} */
                        updateUsbStateBroadcastIfNeeded(getAppliedFunctions(mCurrentFunctions));
                    }
                    if ((mCurrentFunctions & UsbManager.FUNCTION\_ACCESSORY) != 0) {
 updateCurrentAccessory();
 }
 if (mBootCompleted) {
 if (!mConnected && !hasMessages(MSG\_ACCESSORY\_MODE\_ENTER\_TIMEOUT)
 && !hasMessages(MSG\_FUNCTION\_SWITCH\_TIMEOUT)) {
                            // restore defaults when USB is disconnected
                            if (!mScreenLocked
                                    && mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE) {
                                setScreenUnlockedFunctions();
                            } else {
                                 setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                            }
                        }
                        updateUsbFunctions();
                    } else {
                        mPendingBootBroadcast = true;
                    }
                    break;
                case MSG_UPDATE_PORT_STATE:
                    SomeArgs args = (SomeArgs) msg.obj;
                    boolean prevHostConnected = mHostConnected;
                    UsbPort port = (UsbPort) args.arg1;
                    UsbPortStatus status = (UsbPortStatus) args.arg2;
                    mHostConnected = status.getCurrentDataRole() == DATA_ROLE_HOST;
                    mSourcePower = status.getCurrentPowerRole() == POWER_ROLE_SOURCE;
                    mSinkPower = status.getCurrentPowerRole() == POWER_ROLE_SINK;
                    mAudioAccessoryConnected = (status.getCurrentMode() == MODE_AUDIO_ACCESSORY);
                    mAudioAccessorySupported = port.isModeSupported(MODE_AUDIO_ACCESSORY);
                    // Ideally we want to see if PR_SWAP and DR_SWAP is supported.
                    // But, this should be suffice, since, all four combinations are only supported
                    // when PR_SWAP and DR_SWAP are supported.
                    mSupportsAllCombinations = status.isRoleCombinationSupported(
                            POWER_ROLE_SOURCE, DATA_ROLE_HOST)
                            && status.isRoleCombinationSupported(POWER_ROLE_SINK, DATA_ROLE_HOST)
                            && status.isRoleCombinationSupported(POWER_ROLE_SOURCE,
                            DATA_ROLE_DEVICE)
                            && status.isRoleCombinationSupported(POWER_ROLE_SINK, DATA_ROLE_DEVICE);

                    args.recycle();
                    updateUsbNotification(false);
                    if (mBootCompleted) {
                        if (mHostConnected || prevHostConnected) {
                            updateUsbStateBroadcastIfNeeded(getAppliedFunctions(mCurrentFunctions));
                        }
                    } else {
                        mPendingBootBroadcast = true;
                    }
                    break;
                case MSG_UPDATE_CHARGING_STATE:
                    updateUsbNotification(false);
                    boolean usbCharging = (msg.arg1 == 1);
                    /* add sprd usb feature @{*/
                    if(usbCharging != mUsbCharging) {
                        mUsbCharging = usbCharging;
                        if(!usbCharging) {
                            try{
                                String state = FileUtils.readTextFile(new File(STATE_PATH), 0, null).trim();
                                Slog.d(TAG, "receive power disconnected : usb state " + state);
                                if ("DISCONNECTED".equals(state)) {
                                    updateDisconnectStateAndNotification();
                                }
                            } catch (IOException e) {
                                Slog.e(TAG, "Error read usb\_state path", e);
                            }
                        }
                    }
                    /* @} */
                    break;
                case MSG_UPDATE_HOST_STATE:
                    Iterator devices = (Iterator) msg.obj;
                    boolean connected = (msg.arg1 == 1);

                    if (DEBUG) {
                        Slog.i(TAG, "HOST\_STATE connected:" + connected);
                    }

                    mHideUsbNotification = false;
                    while (devices.hasNext()) {
                        Map.Entry pair = (Map.Entry) devices.next();
                        if (DEBUG) {
                            Slog.i(TAG, pair.getKey() + " = " + pair.getValue());
                        }
                        UsbDevice device = (UsbDevice) pair.getValue();
                        int configurationCount = device.getConfigurationCount() - 1;
                        while (configurationCount >= 0) {
                            UsbConfiguration config = device.getConfiguration(configurationCount);
                            configurationCount--;
                            int interfaceCount = config.getInterfaceCount() - 1;
                            while (interfaceCount >= 0) {
                                UsbInterface intrface = config.getInterface(interfaceCount);
                                interfaceCount--;
                                if (sBlackListedInterfaces.contains(intrface.getInterfaceClass())) {
                                    mHideUsbNotification = true;
                                    break;
                                }
                            }
                        }
                    }
                    updateUsbNotification(false);
                    break;
                case MSG_ENABLE_ADB:
                    setAdbEnabled(msg.arg1 == 1);
                    break;
                case MSG_SET_CURRENT_FUNCTIONS:
                    long functions = (Long) msg.obj;
                    setEnabledFunctions(functions, false);
                    break;
                case MSG_SET_SCREEN_UNLOCKED_FUNCTIONS:
                    mScreenUnlockedFunctions = (Long) msg.obj;
                    if (mSettings != null) {
                        SharedPreferences.Editor editor = mSettings.edit();
                        editor.putString(String.format(Locale.ENGLISH, UNLOCKED_CONFIG_PREF,
                                mCurrentUser),
                                UsbManager.usbFunctionsToString(mScreenUnlockedFunctions));
                        editor.commit();
                    }
                    if (!mScreenLocked && mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE) {
                        // If the screen is unlocked, also set current functions.
                        setScreenUnlockedFunctions();
                    }
                    break;
                case MSG_UPDATE_SCREEN_LOCK:
                    if (msg.arg1 == 1 == mScreenLocked) {
                        break;
                    }
                    mScreenLocked = msg.arg1 == 1;
                    if (!mBootCompleted) {
                        break;
                    }
                    if (mScreenLocked) {
                        if (!mConnected) {
                            setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                        }
                    } else {
                        if (mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE
                                && mCurrentFunctions == UsbManager.FUNCTION_NONE) {
                            // Set the screen unlocked functions if current function is charging.
                            setScreenUnlockedFunctions();
                        }
                    }
                    break;
                case MSG_UPDATE_USER_RESTRICTIONS:
                    // Restart the USB stack if USB transfer is enabled but no longer allowed.
                    if (isUsbDataTransferActive(mCurrentFunctions) && !isUsbTransferAllowed()) {
                        setEnabledFunctions(UsbManager.FUNCTION_NONE, true);
                    }
                    break;
                case MSG_SYSTEM_READY:
                    mNotificationManager = (NotificationManager)
                            mContext.getSystemService(Context.NOTIFICATION_SERVICE);
                    mConnectivityManager = (ConnectivityManager) mContext.getSystemService(
                            Context.CONNECTIVITY_SERVICE);

                    LocalServices.getService(
                            AdbManagerInternal.class).registerTransport(new AdbTransport(this));

                    // Ensure that the notification channels are set up
                    if (isTv()) {
                        // TV-specific notification channel
                        mNotificationManager.createNotificationChannel(
                                new NotificationChannel(ADB_NOTIFICATION_CHANNEL_ID_TV,
                                        mContext.getString(
                                                com.android.internal.R.string
                                                        .adb_debugging_notification_channel_tv),
                                        NotificationManager.IMPORTANCE_HIGH));
                    }
                    mSystemReady = true;
                    finishBoot();
                    break;
                case MSG_LOCALE_CHANGED:
                    updateAdbNotification(true);
                    updateUsbNotification(true);
                    break;
                case MSG_BOOT_COMPLETED:
                    mBootCompleted = true;
                    finishBoot();
                    /*SPRD: add for usb state activate @{ */
                    if (isUsbShouldActived()) {
                        sendMessageDelayed(Message.obtain(this, MSG_SIM_CHECKING), SIM_CHECKING_TIMEOUT);
                    }
                    /* @} */
                    break;
                case MSG_USER_SWITCHED: {
                    if (mCurrentUser != msg.arg1) {
                        if (DEBUG) {
                            Slog.v(TAG, "Current user switched to " + msg.arg1);
                        }
                        mCurrentUser = msg.arg1;
                        mScreenLocked = true;
                        mScreenUnlockedFunctions = UsbManager.FUNCTION_NONE;
                        if (mSettings != null) {
                            mScreenUnlockedFunctions = UsbManager.usbFunctionsFromString(
                                    mSettings.getString(String.format(Locale.ENGLISH,
                                            UNLOCKED_CONFIG_PREF, mCurrentUser), ""));
                        }
                        setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                    }
                    break;
                }
                case MSG_ACCESSORY_MODE_ENTER_TIMEOUT: {
                    if (DEBUG) {
                        Slog.v(TAG, "Accessory mode enter timeout: " + mConnected);
                    }
                    if (!mConnected || (mCurrentFunctions & UsbManager.FUNCTION_ACCESSORY) == 0) {
                        notifyAccessoryModeExit();
                    }
                    break;
                }

                /*SPRD: add for Usb sim activate @{ */
                case MSG_SIM_CHECKING:
                    mIsSimChecking = false;
                    updateUsbNotification(false);
                    updateAdbNotification(false);
                    if (mConnected && isUsbShouldActived()) {
                        setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                        showWarningDialog();
                    }
                    break;
                case MSG_SWITCH_FOR_USB_ACTIVE_CHANGED:
                    if (msg.arg1 == 1) {
                        mIsSimChecking = false;
                        if (mConnected && isUsbShouldActived()) {
                            setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                            showWarningDialog();
                        }
                        if (isUsbShouldActived() && mIsSimStateRegister == false) {
                            IntentFilter simFilter = new IntentFilter(TelephonyIntents.ACTION_SIM_STATE_CHANGED);
                            mContext.registerReceiver(mSimStateChangeReceiver, simFilter);
                            mIsSimStateRegister = true;
                        }
                    } else {
                        if (mWarningDialog != null) {
                            mWarningDialog.dismiss();
                            if(!mScreenLocked)
                                setScreenUnlockedFunctions();
                            else
                                setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                        }
                        if (mIsSimStateRegister) {
                            mContext.unregisterReceiver(mSimStateChangeReceiver);
                            mIsSimStateRegister = false;
                        }
                    }
                    break;
                /* @} */
            }
        }

```

从 handler 事件看出 MSG\_BOOT\_COMPLETED  
 处理 开机完成的事件 finishBoot();


看下finishBoot()



```
protected void finishBoot() {
	android.service.oemlock.OemLockManager mOemLockManager = (android.service.oemlock.OemLockManager) mContext.getSystemService(Context.OEM_LOCK_SERVICE);
	mOemLockManager.setOemUnlockAllowedByUser(true);
    if (mBootCompleted && mCurrentUsbFunctionsReceived && mSystemReady) {
        if (mPendingBootBroadcast) {
            updateUsbStateBroadcastIfNeeded(getAppliedFunctions(mCurrentFunctions));
            mPendingBootBroadcast = false;
        }
        if (!mScreenLocked
                && mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE) {
            setScreenUnlockedFunctions();
        } else {
             setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
        }
        if (mCurrentAccessory != null) {
            mUsbDeviceManager.getCurrentSettings().accessoryAttached(mCurrentAccessory);
        }

        updateUsbNotification(false);
        updateAdbNotification(false);
        updateUsbFunctions();
    }
}

```

从setEnabledFunctions(FUNCTION\_NONE，false); 设置默认为充电模式  
 修改方式1：



```
protected void finishBoot() {
			android.service.oemlock.OemLockManager mOemLockManager = (android.service.oemlock.OemLockManager) mContext.getSystemService(Context.OEM_LOCK_SERVICE);
			mOemLockManager.setOemUnlockAllowedByUser(true);
            if (mBootCompleted && mCurrentUsbFunctionsReceived && mSystemReady) {
                if (mPendingBootBroadcast) {
                    updateUsbStateBroadcastIfNeeded(getAppliedFunctions(mCurrentFunctions));
                    mPendingBootBroadcast = false;
                }
                if (!mScreenLocked
                        && mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE) {
                    setScreenUnlockedFunctions();
                } else {
                    //add code  start
                    setEnabledFunctions(UsbManager.FUNCTION_MTP, false);
                    //add code  end
                }
                if (mCurrentAccessory != null) {
                    mUsbDeviceManager.getCurrentSettings().accessoryAttached(mCurrentAccessory);
                }

                updateUsbNotification(false);
                updateAdbNotification(false);
                updateUsbFunctions();
            }
        }

```

第二部分：  
 开机检测完 如果有usb 连接时会发送  
 MSG\_UPDATE\_STATE  
 所以在



```
 if (mBootCompleted) {
                        if (!mConnected && !hasMessages(MSG_ACCESSORY_MODE_ENTER_TIMEOUT)
                                && !hasMessages(MSG_FUNCTION_SWITCH_TIMEOUT)) {
                            // restore defaults when USB is disconnected
                            if (!mScreenLocked
                                    && mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE) {
                                setScreenUnlockedFunctions();
                            } else {
                                 setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                            }
                        }

```

设置 模式 setEnabledFunctions(UsbManager.FUNCTION\_NONE, false); 改成 setEnabledFunctions(UsbManager.FUNCTION\_MTP, false);


修改如下:



```
case MSG_UPDATE_STATE:
                    mConnected = (msg.arg1 == 1);
                    mConfigured = (msg.arg2 == 1);

                    updateUsbNotification(false);
                    updateAdbNotification(false);
                    if (mBootCompleted) {
                        /*SPRD: add for usb sim activate @{ */
                        if (mConnected && isUsbShouldActived() && !mIsSimChecking) {
                            setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                            clearNotification();
                        }
                        /* @} */
                        updateUsbStateBroadcastIfNeeded(getAppliedFunctions(mCurrentFunctions));
                    }
                    if ((mCurrentFunctions & UsbManager.FUNCTION\_ACCESSORY) != 0) {
 updateCurrentAccessory();
 }
 if (mBootCompleted) {
 if (!mConnected && !hasMessages(MSG\_ACCESSORY\_MODE\_ENTER\_TIMEOUT)
 && !hasMessages(MSG\_FUNCTION\_SWITCH\_TIMEOUT)) {
                            // restore defaults when USB is disconnected
                            if (!mScreenLocked
                                    && mScreenUnlockedFunctions != UsbManager.FUNCTION_NONE) {
                                setScreenUnlockedFunctions();
                            } else {
                               - setEnabledFunctions(UsbManager.FUNCTION_NONE, false);
                                + setEnabledFunctions(UsbManager.FUNCTION_MTP, false);
                            }
                        }
                        updateUsbFunctions();
                    } else {
                        mPendingBootBroadcast = true;
                    }

```

修改完 编译验证即可





