



## 1.概述


在10.0的产品定制化开发中，由于客户要求对某些app在后台运行的时候不能被杀掉进程，所以这就需要进行进程保活，在低内存的时候也需要保活进程，从而达到app不被杀掉，当重新调用app时能够热启动。


## 2.lowmemorykiller低内存保活白名单的功能分析


而通过查阅资料发现 lmkd\_param.conf文件是lmkd杀进程的白名单配置文件，其中配置的应用是不会被lowmemorykiller杀掉的 所以我们就需要把保活进程app包名放在这个文件里面


## 3.lowmemorykiller低内存保活白名单的功能主要代码分析


#### 3.1添加白名单app包名


创建lmkd\_param.conf



```
添加包名
com.pro.leixun
com.pro.mark
com.pro.project

接下来编译把这个文件拷贝到/vendor/etc/目录下
配置如下:

--- a/device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk
+++ b/device/sprd/sharkl5Pro/ums512_2h10/ums512_2h10_Base.mk
@@ -134,8 +134,7 @@ PRODUCT_COPY_FILES += \
     $(BOARDDIR)/features/otpdata/sale_after_input_parameters_values.txt:system/etc/otpdata/sale_after_input_parameters_values.txt \
     $(BOARDDIR)/features/otpdata/spw_input_parameters_values.txt:system/etc/otpdata/spw_input_parameters_values.txt \
     $(BOARDDIR)/features/otpdata/oz1_input_parameters_values.txt:system/etc/otpdata/oz1_input_parameters_values.txt \
    device/sprd/sharkl5Pro/ums512_2h10/lmkd_param.conf:(TARGET_COPY_OUT_VENDOR)/etc/lmkd_param.conf
编译完成后，机器中的lmkd white list:
/vendor/etc/lmkd_param.conf
```

#### 3.2 在AMS中避免被杀掉进程的修改


这部分处理主要在RamPolicyExecutor.java中处理


接下来看下AMS关于进程相关的源码


路径:framework/base/services/core/java/com/android/server/performance/policy/ram/RamPolicyExecutor.java



```
public class RamPolicyExecutor extends PolicyExecutor {
    private static String TAG = "performance";
    private static String THREAD_NAME = "RamPolicyExecutor";
    private static String CONF_TAG_ACTION = "action";
    private static String ATTR_NAME = "name";
    private static String ATTR_RAM_SIZE = "ramsize";
    private static String ATTR_SCENE = "scene";

    private int CPU_LOADING_SAMPLE_LOW_COUNT = 3;
    private int CPU_LOADING_SAMPLE_HIGH_COUNT = 2;
    private int RECLAIM_ADJ_THROL_RECLAIM = 800;
    private int RECLAIM_ADJ_BOOST_KILL = 900;
    private int FS_RECLAIM_ADJ = 200;
    private static int LRU_RECLAIM_KILL_ADJ = 800;
    private int MAX_RECLAIM_COUNT = 2;
    private int MAX_RECLAIM_PERSIST_COUNT = 10;
    private static final int SIGSTOP = 19;
    private static final int SIGCONT = 18;
    private static final int MSG_SCREEN_ON = 1;
    private static final int MSG_UNFREEZE_PROCESS = 2;
    private static final int SCEN_NORMAL = 0;
    private static final int SCEN_EM = 1;
    private static final int SCEN_BOOST = 2;
    private static final int MEMRECLAIM_CMD_PROCESS_RECLAIM = 0;
    private static final String RECLAIM_TYPE_ANON = "anon";
    private static final String RECLAIM_TYPE_FILE = "file";
    private static final String RECLAIM_TYPE_ALL = "all";
    private static final String RECLAIM_TYPE_HIBER = "hiber";
    private static final int PAGE_SIZE = 4 * 1024;
    private static final long MB = 1024 * 1024;
    private static final long NOTIFICATIONLOWTIME = 2 * 60 * 1000;
    private static final long NOTIFICATIONNORMALTIME = 5 * 60 * 1000;
    private static final long RECLAIM_IDLE_TIME = 5 * 60 * 1000;
    private static final long WAKELOCK_PROTECTED_TIME = 15 * 1000;
    private static final int CRITIAL_SWAP_USAGE = 99;
    private static final long VMPRESSURE_INTERVAL = 1000;
    private static final long MIN_IDLE_WAIT_TIME = 5000;
    private static final int MAX_LRU_FS_RECLAIM_COUNT = 2;
    private static final long FOCUS_CHANGE_PROTECT_LIMIT = 10 * 1000;
    private static final long FOCU_CHANGE_PROTECT_IDLE_LIMIT = 60 * 60 * 1000;
    private static final int LRU_NORMAL = -1;
    private static final int LRU_CRITICAL = 0;
    private static final int LRU_EMERGENCY = 1;

public RamPolicyExecutor(PolicyItem config,
            PerformanceManagerService service) {
        super();
        mMemoryConstant = MemoryConstant.loadFromConfig(config
                .getConfig(MemoryConstant.TAG), service.getRamConfig());
        mMemoryScene = MemoryScene.loadFromConfig(config
                .getConfig(MemoryScene.TAG));
        mService = service;
        mAm = (ActivityManagerServiceEx) ActivityManagerNative.getDefault();
        mAtm = (ActivityTaskManagerService) ActivityTaskManager.getService();
        mAmInternal = LocalServices.getService(ActivityManagerInternal.class);
        mReclaimProcessEnabled = reclaimProcessEnabled();
        mUserHabitCollector = mService.getUserHabitCollector();
        mSpecialPackages.add("com.android");
        mSpecialPackages.add("com.google");
        mSpecialPackages.add("com.quicinc.vellamo");
        mSpecialPackages.add("com.tencent.mm");
        mSpecialPackages.add("com.immomo.momo");
        mSpecialPackages.add("com.tencent.mobileqq");
        mSpecialPackages.add("android.inputmethodservice.cts");
        mSpecialPackages.add("com.whatsapp");
        mSpecialPackages.add("com.facebook.orca");
        mSpecialPackages.add("com.sprdsrt.srtmemtest");
        mNotificationProtectPackages.add("com.tencent.android.qqdownloader");
        if (mMemoryConstant.isVmpressureListenerEnabled()) {
            VmpressureListener mVmpressureListener = new VmpressureListener(mService);
            mVmpressureListener.setThrashing(mMemoryConstant.getThrashing());
            mVmpressureListener.start();
        }
    }

@Override
    protected void handleActivityStateChange(ActivityStateData aData) {
        if (aData == null) {
            return;
        }
        int state = aData.bundle.getInt(ProcessInfo.KEY_ACTIVITY_STATE);
        ComponentName app = aData.intent.getComponent();
        if (state == ProcessInfo.ACTIVITY_STATE_LAUNCHDONE && app != null) {
            checkMemoryStatus(mService.getCurrentSystemStatus(true));
        } else if (state == ProcessInfo.ACTIVITY_STATE_RESUME && app != null) {
            // TODO: Fix ugly way to get Launcher... adjtype sometimes not work..
            String home = getHomePackageName();
            if (home != null && home.equals(app.getPackageName())) {
                checkMemoryStatus(mService.getCurrentSystemStatus(true));
            }
            mCurrentFocusPackage =  app.getPackageName();
        }
    }

private void checkMemoryStatus(SystemStatus status) {
        if (DEBUG_RAMPOLICY) {
            Slog.d(TAG, "checkMemoryStatus:"
                    + (status.getRamStatus().getAvailableMemKb() / 1024)
                    + "mReclaimProcessEnabled = " + mReclaimProcessEnabled);
        }
        if (mInReclaimProcess) {
            return;
        }
        mInReclaimProcess = true;
        try {
            long currentMem = status.getRamStatus().getAvailableMemKb() / 1024;
            long idleTime = -1;
            if (mReclaimProcessEnabled && isMemoryPressureReclaim(currentMem)) {
                long request = mMemoryConstant.getNormalMemory();
                doMemoryReclaim(request * 1024,
                        mMemoryScene.getPolicyForScene(SCENE_IDLE));
            } else if (mReclaimProcessEnabled
                    && isMemoryPressureEmergency(currentMem)) {
                // try to reclaim persist-procs
                long request = mMemoryConstant.getEmergencyMemory();
                doMemoryReclaim(request * 1024,
                        mMemoryScene.getPolicyForScene(SCENE_EMERGENCY));
            }
            if (!mService.getInStrumentationStatus() &&
                (idleTime = mMemoryConstant.getCurrentForceStopIdleTime(currentMem)) != -1) {
                if (idleTime < MIN_IDLE_WAIT_TIME) idleTime = MIN_IDLE_WAIT_TIME;
                if (DEBUG_RAMPOLICY) Slog.d(TAG, "system under memPressure current available ->" + currentMem);
                String reason = "available memory:" + currentMem;
                doLRUReclaim(idleTime, LRU_NORMAL, false, reason);
            }
        } catch (Exception e) {
           e.printStackTrace();
        } finally {
            mInReclaimProcess = false;
        }
    }

    private void doLRUReclaim(long idleTime, int swapKill, boolean force, String reason) {
        List<LRUReclaimProcessRecord> procs = getLeastRecentUsedPkg(idleTime, swapKill, force);
        if (procs != null && procs.size() > 0) {
            for (LRUReclaimProcessRecord proc : procs) {
                if (isSpecialPackage(proc.pkgName)) {
                    if (DEBUG_RAMPOLICY) {
                        Slog.d(TAG, "Killing uid:" + proc.uid + proc.pkgName + " due to "
                                    + reason + "to free " + proc.rss + "KB");
                    }
                    mAm.killUid(UserHandle.getAppId(proc.uid), UserHandle.getUserId(proc.uid), "rampolicy");
                } else {
                    Slog.d(TAG, "force-stop " + proc.pkgName + " due to " + reason
                                + "to free " + proc.rss + "KB");
                    mAm.forceStopPackage(proc.pkgName, UserHandle.USER_CURRENT);
                }
            }
        }
        doLRUReclaimKill(swapKill, reason);
    }
```

## 4.lowmemorykiller低内存保活白名单的功能功能解决


根据上面的相关代码分析发现，具体处理


在doLRUReclaim(long idleTime, int swapKill, boolean force, String reason) 中 避免 保活app 被杀掉 具体修改如下:



```
相关代码如下:
private void doLRUReclaim(long idleTime, int swapKill, boolean force, String reason) {
        List<LRUReclaimProcessRecord> procs = getLeastRecentUsedPkg(idleTime, swapKill, force);
        if (procs != null && procs.size() > 0) {
            for (LRUReclaimProcessRecord proc : procs) {
               // 主要代码这里负责过滤白名单app
               + if(proc.pkgName.contains("com.pro.leixun")||proc.pkgName.contains("com.pro.mark")||proc.pkgName.contains("com.pro.project")){
               +     continue;
               + }
                if (isSpecialPackage(proc.pkgName)) {
                    if (DEBUG_RAMPOLICY) {
                        Slog.d(TAG, "Killing uid:" + proc.uid + proc.pkgName + " due to "
                                    + reason + "to free " + proc.rss + "KB");
                    }
                    mAm.killUid(UserHandle.getAppId(proc.uid), UserHandle.getUserId(proc.uid), "rampolicy");
                } else {
                    Slog.d(TAG, "force-stop " + proc.pkgName + " due to " + reason
                                + "to free " + proc.rss + "KB");
                    mAm.forceStopPackage(proc.pkgName, UserHandle.USER_CURRENT);
                }
            }
        }
        doLRUReclaimKill(swapKill, reason);
    }
```



