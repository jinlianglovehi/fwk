



**目录**


[简述](#%E7%AE%80%E8%BF%B0)


[分析](#%E5%88%86%E6%9E%90)


[1.SystemUI下 config.xml中的修改](#%C2%A0%201.SystemUI%E4%B8%8B%20config.xml%E4%B8%AD%E7%9A%84%E4%BF%AE%E6%94%B9)


[QSTileHost.java的相关分析](#QSTileHost.java%E7%9A%84%E7%9B%B8%E5%85%B3%E5%88%86%E6%9E%90)




---



## 简述


下拉状态栏UI定制化开发(三)也是下拉状态栏定制化第三篇本篇主要 针对首次下拉状态栏 QuickQSPanel 快捷功能图标的排序调整的调整


## 分析


####   1.SystemUI下 config.xml中的修改


下面看下config.xml的相关代码


第一步首选修改quick\_settings\_tiles\_default的排列顺序  
 具体路径为：



```


frameworks/base/packages/SystemUI/res/values/config.xml
<resources>
<!-- Whether to clip notification contents with a rounded rectangle. Might be expensive on
certain GPU's and thus can be turned off with only minimal visual impact. -->
<bool name="config_notifications_round_rect_clipping">true</bool>

<!-- Control whether status bar should distinguish HSPA data icon form UMTS
data icon on devices -->
<bool name="config_hspa_data_distinguishable">false</bool>

<!-- Component to be used as the status bar service.  Must implement the IStatusBar
interface.  This name is in the ComponentName flattened format (package/class)  -->
<string name="config_statusBarComponent" translatable="false">com.android.systemui.statusbar.phone.StatusBar</string>

<!-- Component to be used as the recents implementation.  Must implement the
RecentsImplementation interface.  This name is in the ComponentName flattened format
(package/class)  -->
<string name="config_recentsComponent" translatable="false">com.android.systemui.recents.OverviewProxyRecentsImpl</string>

<!-- Whether or not we show the number in the bar. -->
<bool name="config_statusBarShowNumber">false</bool>

<!-- For how long the lock screen can be on before the display turns off. -->
<integer name="config_lockScreenDisplayTimeout">10000</integer>

<!-- Vibrator pattern for camera gesture launch. -->
<integer-array translatable="false" name="config_cameraLaunchGestureVibePattern">
<item>0</item>
<item>400</item>
</integer-array>

<!-- How many icons may be shown at once in the system bar. Includes any
slots that may be reused for things like IME control. -->
<integer name="config_maxNotificationIcons">5</integer>

<!-- Show phone (voice) signal strength instead of data in mobile RSSI. -->
<bool name="config_showPhoneRSSIForData">false</bool>

<!-- When true, show 1/2G networks as 3G. -->
<bool name="config_showMin3G">false</bool>

<!-- Show rotation lock toggle in System UI-->
<bool name="config_showRotationLock">true</bool>

<!-- Vibration duration for GlowPadView used in SearchPanelView -->
<integer translatable="false" name="config_vibration_duration">0</integer>

<!-- Vibration duration for GlowPadView used in SearchPanelView -->
<integer translatable="false" name="config_search_panel_view_vibration_duration">20</integer>

<!-- Show mic or phone affordance on Keyguard -->
<bool name="config_keyguardShowLeftAffordance">false</bool>

<!-- Show camera affordance on Keyguard -->
<bool name="config_keyguardShowCameraAffordance">false</bool>

<!-- The length of the vibration when the notification pops open. -->
<integer name="one_finger_pop_duration_ms">10</integer>

<!-- decay duration (from size_max -> size), in ms -->
<integer name="navigation_bar_deadzone_hold">333</integer>
<integer name="navigation_bar_deadzone_decay">333</integer>

<!-- orientation of the dead zone when touches have recently occurred elsewhere on screen -->
<integer name="navigation_bar_deadzone_orientation">0</integer>

<bool name="config_dead_zone_flash">false</bool>

<!-- Whether to enable dimming navigation buttons when wallpaper is not visible, should be
enabled for OLED devices to reduce/prevent burn in on the navigation bar (because of the
black background and static button placements) and disabled for all other devices to
prevent wasting cpu cycles on the dimming animation -->
<bool name="config_navigation_bar_enable_auto_dim_no_visible_wallpaper">true</bool>

<!-- The maximum number of tiles in the QuickQSPanel -->
<integer name="quick_qs_panel_max_columns">6</integer>

<!-- The number of columns in the QuickSettings -->
<integer name="quick_settings_num_columns">3</integer>

<!-- The number of rows in the QuickSettings -->
<integer name="quick_settings_max_rows">3</integer>

<!-- The number of columns that the top level tiles span in the QuickSettings -->
<integer name="quick_settings_user_time_settings_tile_span">1</integer>

<!-- The default tiles to display in QuickSettings -->
<string name="quick_settings_tiles_default" translatable="false">
wifi,bt,dnd,flashlight,rotation,battery,cell,airplane,cast,screenrecord
</string>

<!-- The minimum number of tiles to display in QuickSettings -->
<integer name="quick_settings_min_num_tiles">6</integer>

<!-- Tiles native to System UI. Order should match "quick_settings_tiles_default" -->
<string name="quick_settings_tiles_stock" translatable="false">
wifi,cell,battery,dnd,flashlight,rotation,bt,airplane,location,hotspot,inversion,saver,dark,work,cast,night,screenrecord,reverse
</string>

<!-- The tiles to display in QuickSettings -->
<string name="quick_settings_tiles" translatable="false">default</string>

<!-- The tiles to display in QuickSettings in retail mode -->
<string name="quick_settings_tiles_retail_mode" translatable="false">
night,dark,dnd,flashlight,rotation,location
</string>

<!-- Tiles to auto add to Quick Settings upon first change of a given secure setting.
The syntax is setting-name:spec. If the tile is a TileService, the spec should be specified
as custom(package/class). Relative class name is supported. -->
<string-array name="config_quickSettingsAutoAdd" translatable="false">
<item>accessibility_display_inversion_enabled:inversion</item>
</string-array>

<!-- Whether or not the RSSI tile is capitalized or not. -->
<bool name="quick_settings_rssi_tile_capitalization">true</bool>

<!-- Timeouts for brightness dialog to disappear -->
<integer name="quick_settings_brightness_dialog_short_timeout">2000</integer>
<integer name="quick_settings_brightness_dialog_long_timeout">4000</integer>

<!-- Show indicator for Wifi on but not connected. -->
<bool name="config_showWifiIndicatorWhenEnabled">false</bool>

<!-- The number of milliseconds before the heads up notification auto-dismisses. -->
<integer name="heads_up_notification_decay">5000</integer>

<!-- The number of milliseconds before the heads up notification sent automatically by the system auto-dismisses. -->
<integer name="auto_heads_up_notification_decay">3000</integer>

<!-- The number of milliseconds after a heads up notification is pushed back
before the app can interrupt again. -->
<integer name="heads_up_default_snooze_length_ms">60000</integer>

<!-- Minimum display time for a heads up notification, in milliseconds. -->
<integer name="heads_up_notification_minimum_time">2000</integer>

<!-- The number of milliseconds before the heads up notification accepts touches. -->
<integer name="touch_acceptance_delay">700</integer>

<!-- The number of milliseconds to extend ambient pulse by when prompted (e.g. on touch) -->
<integer name="ambient_notification_extension_time">10000</integer>

<!-- In multi-window, determines whether the stack where recents lives should grow from
the smallest position when being launched. -->
<bool name="recents_grow_in_multiwindow">true</bool>

<!-- Animation duration when using long press on recents to dock -->
<integer name="long_press_dock_anim_duration">250</integer>

<!-- Whether to enable KeyguardService or not -->
<bool name="config_enableKeyguardService">true</bool>

<!-- The maximum count of notifications on Keyguard. The rest will be collapsed in an overflow
card. -->
<integer name="keyguard_max_notification_count">3</integer>

<!-- Defines the implementation of the velocity tracker to be used for the panel expansion. Can
be 'platform' or 'noisy' (i.e. for noisy touch screens). -->
<string name="velocity_tracker_impl" translatable="false">platform</string>

<!-- Doze: does this device support STATE_DOZE?  -->
<bool name="doze_display_state_supported">false</bool>

<!-- Doze: does this device support STATE_DOZE_SUSPEND?  -->
<bool name="doze_suspend_display_state_supported">false</bool>

<!-- Doze: should the significant motion sensor be used as a pulse signal? -->
<bool name="doze_pulse_on_significant_motion">false</bool>

<!-- Doze: check proximity sensor before pulsing? -->
<bool name="doze_proximity_check_before_pulse">true</bool>

<!-- Doze: should notifications be used as a pulse signal? -->
<bool name="doze_pulse_on_notifications">true</bool>

<!-- Doze: duration to avoid false pickup gestures triggered by notification vibrations -->
<integer name="doze_pickup_vibration_threshold">2000</integer>

<!-- Type of a sensor that provides a low-power estimate of the desired display
brightness, suitable to listen to while the device is asleep (e.g. during
always-on display) -->
<string name="doze_brightness_sensor_type" translatable="false"></string>

<!-- Override value to use for proximity sensor.  -->
<string name="proximity_sensor_type" translatable="false"></string>

<!-- If using proximity_sensor_type, specifies a threshold value to distinguish near and
far break points. A sensor value less than this is considered "near". -->
<item name="proximity_sensor_threshold" translatable="false" format="float" type="dimen"></item>

<!-- If using proximity_sensor_type, specifies a threshold value to distinguish near and
far break points. A sensor value more than this is considered "far". If not set,
proximity_sensor_threshold is used. This allows one to implement a latching mechanism for
noisy sensors. -->
<item name="proximity_sensor_threshold_latch" translatable="false" format="float" type="dimen"></item>

<!-- Override value to use for proximity sensor as confirmation for proximity_sensor_type. -->
<string name="proximity_sensor_secondary_type" translatable="false"></string>

<!-- If using proximity_sensor_secondary_type, specifies a threshold value to distinguish
near and far break points. A sensor value less than this is considered "near". -->
<item name="proximity_sensor_secondary_threshold" translatable="false" format="float"
type="dimen"></item>

<!-- If using proximity_sensor_secondary_type, specifies a threshold value to distinguish near and
far break points. A sensor value more than this is considered "far". If not set,
proximity_sensor_secondary_threshold is used. This allows one to implement a latching
mechanism for noisy sensors. -->
<item name="proximity_sensor_secondary_threshold_latch" translatable="false" format="float" type="dimen"></item>

<!-- Doze: pulse parameter - how long does it take to fade in? -->
<integer name="doze_pulse_duration_in">130</integer>

<!-- Doze: pulse parameter - once faded in, how long does it stay visible? -->
<integer name="doze_pulse_duration_visible">6000</integer>

<!-- Doze: pulse parameter - how long does it take to fade out? -->
<integer name="doze_pulse_duration_out">600</integer>
.....



```

## 具体修改为:



```
@@ -93,7 +93,7 @@
     <bool name="config_navigation_bar_enable_auto_dim_no_visible_wallpaper">true</bool>
 
     <!-- The maximum number of tiles in the QuickQSPanel -->
-    <integer name="quick_qs_panel_max_columns">6</integer>
+    <integer name="quick_qs_panel_max_columns">9</integer>
 
     <!-- Whether QuickSettings is in a phone landscape -->
     <bool name="quick_settings_wide">false</bool>
@@ -109,11 +109,11 @@
     <!-- The number of columns that the top level tiles span in the QuickSettings -->
     <integer name="quick_settings_user_time_settings_tile_span">1</integer>
 
-    <!-- The default tiles to display in QuickSettings rotation cast lte1,lte2,cell,airplane-->
+    <!-- The default tiles to display in QuickSettings -->
     <string name="quick_settings_tiles_default" translatable="false">
-        volte1,volte2,wifi,bt,dnd,vowifi,onehand,flashlight,battery
+        volte1,volte2,wifi,bt,vowifi,onehand,ring,screenshot,cast,rotation,night,airplane,flashlight
     </string>
-
+    <string name="quick_config_icon_mask" translatable="false">"M50,50m-50,0a50,50 0,1 1,100 0a50,50 0,1 1,-100 0"</string>
     <!-- The minimum number of tiles to display in QuickSettings -->
     <integer name="quick_settings_min_num_tiles">6</integer>
```

## QSTileHost.java的相关分析


2.看哪里加载QSTile 然后看是否按照顺序加载  
 在QuickQSPanel 加载的时候，会通过QSTileHost.java的loadTileSpecs 来加载quick\_settings\_tiles\_default的QSTile功能开关  
 路径为:frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java



```

@Override
    public void onTuningChanged(String key, String newValue) {
        if (!TILES_SETTING.equals(key)) {
            return;
        }
        if (DEBUG) Log.d(TAG, "Recreating tiles");
        if (newValue == null && UserManager.isDeviceInDemoMode(mContext)) {
            newValue = mContext.getResources().getString(R.string.quick_settings_tiles_retail_mode);
        }
        final List<String> tileSpecs = loadTileSpecs(mContext, newValue);
        int currentUser = ActivityManager.getCurrentUser();
        if (tileSpecs.equals(mTileSpecs) && currentUser == mCurrentUser) return;
        mTiles.entrySet().stream().filter(tile -> !tileSpecs.contains(tile.getKey())).forEach(
                tile -> {
                    if (DEBUG) Log.d(TAG, "Destroying tile: " + tile.getKey());
                    tile.getValue().destroy();
                });
        final LinkedHashMap<String, QSTile> newTiles = new LinkedHashMap<>();
        for (String tileSpec : tileSpecs) {
            QSTile tile = mTiles.get(tileSpec);
            if (tile != null && (!(tile instanceof CustomTile)
                    || ((CustomTile) tile).getUser() == currentUser)) {
                if (tile.isAvailable()) {
                    if (DEBUG) Log.d(TAG, "Adding " + tile);
                    tile.removeCallbacks();
                    if (!(tile instanceof CustomTile) && mCurrentUser != currentUser) {
                        tile.userSwitch(currentUser);
                    }
                    newTiles.put(tileSpec, tile);
                } else {
                    tile.destroy();
                }
            } else {
                if (DEBUG) Log.d(TAG, "Creating tile: " + tileSpec);
                try {
                    tile = createTile(tileSpec);
                    if (tile != null) {
                        if (tile.isAvailable()) {
                            tile.setTileSpec(tileSpec);
                            newTiles.put(tileSpec, tile);
                        } else {
                            tile.destroy();
                        }
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "Error creating tile for spec: " + tileSpec, t);
                }
            }
        }
        mCurrentUser = currentUser;
        List<String> currentSpecs = new ArrayList(mTileSpecs);
        mTileSpecs.clear();
        mTileSpecs.addAll(tileSpecs);
        mTiles.clear();
        mTiles.putAll(newTiles);
        if (newTiles.isEmpty() && !tileSpecs.isEmpty()) {
            // If we didn't manage to create any tiles, set it to empty (default)
            if (DEBUG) Log.d(TAG, "No valid tiles on tuning changed. Setting to default.");
            changeTiles(currentSpecs, loadTileSpecs(mContext, ""));
        } else {
            for (int i = 0; i < mCallbacks.size(); i++) {
                mCallbacks.get(i).onTilesChanged();
            }
        }
    }
    private void changeTileSpecs(Predicate<List<String>> changeFunction) {
        final String setting = Settings.Secure.getStringForUser(mContext.getContentResolver(),
            TILES_SETTING, ActivityManager.getCurrentUser());
        /* UNISOC: Bug 1074234,Super power feature @{ */
        boolean is_special_request = false;
        if (SprdPowerManagerUtil.isSuperPower()) {
            is_special_request = true;
        }
        if (DEBUG) Log.d(TAG,"addTile, setting =" + setting);
        /* @} */
        final List<String> tileSpecs = loadTileSpecs(mContext, setting, is_special_request);
        if (changeFunction.test(tileSpecs)) {
            Settings.Secure.putStringForUser(mContext.getContentResolver(), TILES_SETTING,
                TextUtils.join(",", tileSpecs), ActivityManager.getCurrentUser());
        }
    }

通过 loadTileSpecs(Context context, String tileList ,boolean is_special_request)来加载快捷功能键

protected List<String> loadTileSpecs(Context context, String tileList ,boolean is_special_request) {
        final Resources res = context.getResources();
        String defaultTileList = res.getString(R.string.quick_settings_tiles_default);
        if (TextUtils.isEmpty(tileList)) {
            tileList = res.getString(R.string.quick_settings_tiles);
            if (DEBUG) Log.d(TAG, "Loaded tile specs from config: " + tileList);
        } else {
            if (DEBUG) Log.d(TAG, "Loaded12 tile specs from setting: " + tileList);
        }
        if (!mIsEnableWifiDisplay) {
            tileList = tileList.replaceAll( ",cast|cast,|cast","");
            defaultTileList = defaultTileList.replaceAll( ",cast|cast,|cast","");
        }

        /* UNISOC: Bug 1074234,885650,Super power feature*/
        if (!is_special_request) {
            if(SprdPowerManagerUtil.isSuperPower()) {
                tileList = "wifi,cell,battery";
            }
        }
        /*@}*/
        /* UNISOC: Bug 1074234,895419,780848,remove battery quick setting label under guest mode */
        if (ActivityManager.getCurrentUser() != UserHandle.USER_OWNER) {
            tileList = tileList.replaceAll("battery","");
            defaultTileList = defaultTileList.replaceAll("battery","");
        }
        /* @} */
        /* UNISOC: Bug 1073208,1127438,longscreenshot feature @{ */
        if (ActivityManager.getCurrentUser() != UserHandle.USER_OWNER) {
            tileList = tileList.replaceAll("longscreenshot","");
            defaultTileList = defaultTileList.replaceAll("longscreenshot","");
        }
        /* @} */
        if (ActivityManager.getCurrentUser() != UserHandle.USER_OWNER) {
            tileList = tileList.replaceAll("lte","");
            defaultTileList = defaultTileList.replaceAll("lte","");
            tileList = tileList.replaceAll("volte","");
            defaultTileList = defaultTileList.replaceAll("volte","");
            tileList = tileList.replaceAll("vowifi","");
            defaultTileList = defaultTileList.replaceAll("vowifi","");
        }

        final ArrayList<String> tiles = new ArrayList<String>();
        boolean addedDefault = false;
        
        // 遍历tileList的集合 添加功能开关 但发现这里不是默认的quick_settings_tiles_default的内容
        for (String tile : tileList.split(",")) {
            tile = tile.trim();
            if (tile.isEmpty()) continue;
            if (tile.equals("default")) {
                if (!addedDefault) {
                    tiles.addAll(Arrays.asList(defaultTileList.split(",")));
                    if (Build.IS_DEBUGGABLE
                            && GarbageMonitor.MemoryTile.ADD_TO_DEFAULT_ON_DEBUGGABLE_BUILDS) {
                        tiles.add(GarbageMonitor.MemoryTile.TILE_SPEC);
                    }
                    addedDefault = true;
                }
            } else {
                tiles.add(tile);
            }
        }
        return tiles;
    }




```

// 遍历tileList的集合 添加功能开关 但发现这里不是默认的quick\_settings\_tiles\_default的内容  
 for (String tile : tileList.split(",")) {  
 所以需要修改成默认的资源集合为defaultTileList


具体修改为：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java
@@ -458,7 +458,7 @@ public class QSTileHost implements QSHost, Tunable, PluginListener<QSFactory>, D
             tileList = res.getString(R.string.quick_settings_tiles);
             if (DEBUG) Log.d(TAG, "Loaded tile specs from config: " + tileList);
         } else {
-            if (DEBUG) Log.d(TAG, "Loaded tile specs from setting: " + tileList);
+            if (DEBUG) Log.d(TAG, "Loaded12 tile specs from setting: " + tileList);
         }
         if (!mIsEnableWifiDisplay) {
             tileList = tileList.replaceAll( ",cast|cast,|cast","");
@@ -495,7 +495,7 @@ public class QSTileHost implements QSHost, Tunable, PluginListener<QSFactory>, D
 
         final ArrayList<String> tiles = new ArrayList<String>();
         boolean addedDefault = false;
-        for (String tile : tileList.split(",")) {
+        for (String tile : defaultTileList.split(",")) {
             tile = tile.trim();
             if (tile.isEmpty()) continue;
             if (tile.equals("default")) {

```



