






### 1.概述


在进行10.0的产品定制化开发中，展讯内置可卸载恢复的app 其实把apk编译到system/proloadapp 目录下即可


### 2.展讯 MTK内置可卸载app的实现步骤


实现方式：  
 1 预置应用可删除/可恢复  
 2.可删除、恢复出厂设置后可恢复：  
 Android.mk的分析  
 Android.mk是Android提供的一种makefile文件，用来指定诸如编译生成so库名、引用的头文件目录、需要编译的.c/.cpp文件和.a静态库文件等  
 Android.mk文件是GNU Makefile的一小部分，它用来对Android程序进行编译。


因为所有的编译文件都在同一个 GNU MAKE 执行环境中进行执行，而Android.mk中所有的变量都是全局的。因此，您应尽量少声明变量，不要认为某些变量在解析过程中不会被定义。


一个Android.mk文件可以编译多个模块，每个模块属下列类型之一：  
 1）APK程序  
 一般的Android程序，编译打包生成apk文件  
 2）JAVA库  
 java类库，编译打包生成jar文件  
 3)C\C++应用程序  
 可执行的C\C++应用程序  
 4）C\C++静态库  
 编译生成C\C++静态库，并打包成.a文件  
 5）C\C++共享库  
 编译生成共享库（动态链接库），并打包成.so文， 有且只有共享库才能被安装/复制到您的应用软件（APK）包中。


模块描述变量


下面的变量用于向编译系统描述你的模块。你应该定义在’include $(CLEAR\_VARS)'和’include  
 
 
 
 
 ( 
 
 
 B 
 
 
 U 
 
 
 I 
 
 
 L 
 
 
 
 D 
 
 
 X 
 
 
 
 X 
 
 
 X 
 
 
 X 
 
 
 X 
 
 
 
 ) 
 
 
 ′ 
 
 
 
 之间。正如前面描写的那样， 
 
 
 
 (BUILD\_XXXXX)'之间。正如前面描写的那样， 
 
 
 (BUILDX​XXXX)′之间。正如前面描写的那样，(CLEAR\_VARS)是一个脚本，清除所有这些变量。


（1） LOCAL\_PATH: 这个变量用于给出当前文件的路径。必须在 Android.mk 的开头定义，可以这样使用：LOCAL\_PATH :=  
 
 
 
 
 ( 
 
 
 c 
 
 
 a 
 
 
 l 
 
 
 l 
 
 
 m 
 
 
 y 
 
 
 − 
 
 
 d 
 
 
 i 
 
 
 r 
 
 
 ) 
 
 
 这个变量不会被 
 
 
 
 (call my-dir) 这个变量不会被 
 
 
 (callmy−dir)这个变量不会被(CLEAR\_VARS)清除，因此每个 Android.mk 只需要定义一次(即使在一个文件中定义了几个模块的情况下)。


（2）LOCAL\_MODULE: 这是模块的名字，它必须是唯一的，而且不能包含空格。必须在包含任一的$(BUILD\_XXXX)脚本之前定义它。模块的名字决定了生成文件的名字。例如，如果一个一个共享库模块的名字是，那么生成文件的名字就是 lib.so。但是，在的 NDK 生成文


件中(或者 Android.mk 或者 Application.mk)，应该只涉及(引用)有正常名字的其他模块。


（3）LOCAL\_SRC\_FILES: 这是要编译的源代码文件列表。只要列出要传递给编译器的文件，因为编译系统自动计算依赖。注意源代码文件名称都是相对于 LOCAL\_PATH的，你可以使用路径部分，例如：


LOCAL\_SRC\_FILES := foo.c toto/bar.c\Hello.c


文件之间可以用空格或Tab键进行分割,换行请用"".如果是追加源代码文件的话，请用LOCAL\_SRC\_FILES +=


注意：在生成文件中都要使用UNIX风格的斜杠(/).windows风格的反斜杠不会被正确的处理。


注意：可以LOCAL\_SRC\_FILES := $(call all-subdir-java-files)这种形式来包含local\_path目录下的所有java文件。


（4） LOCAL\_CPP\_EXTENSION: 这是一个可选变量， 用来指定C++代码文件的扩展名，默认是’.cpp’,但是可以改变它，比如：


LOCAL\_CPP\_EXTENSION := .cxx


（5） LOCAL\_C\_INCLUDES: 可选变量，表示头文件的搜索路径。默认的头文件的搜索路径是LOCAL\_PATH目录。


示例:LOCAL\_C\_INCLUDES := sources/foo或LOCAL\_C\_INCLUDES := $(LOCAL\_PATH)/…/foo


LOCAL\_C\_INCLUDES需要在任何包含LOCAL\_CFLAGS/LOCAL\_CPPFLAGS标志之前进行设置。


（6）LOCAL\_CFLAGS: 可选的编译器选项，在编译 C 代码文件的时候使用。这可能是有


用的，指定一个附加的包含路径(相对于NDK的顶层目录)，宏定义，或者编译选项。


注意：不要在 Android.mk 中改变 optimization/debugging 级别，只要在 Application.mk 中指定合适的信息，就会自动地为你处理这个问题，在调试期间，会让 NDK自动生成有用的数据文件。  
 （7）LOCAL\_CXXFLAGS: 与 LOCAL\_CFLAGS同理，针对 C++源文件。  
 （8）LOCAL\_CPPFLAGS: 与 LOCAL\_CFLAGS同理，但是对 C 和 C++ source files都适用。  
 （9）LOCAL\_STATIC\_LIBRARIES: 表示该模块需要使用哪些静态库，以便在编译时进行链接。  
 （10）LOCAL\_SHARED\_LIBRARIES: 表示模块在运行时要依赖的共享库（动态库），在链接时就需要，以便在生成文件时嵌入其相应的信息。注意：它不会附加列出的模块到编译图，也就是仍然需要在Application.mk 中把它们添加到程序要求的模块中。  
 （11）LOCAL\_LDLIBS: 编译模块时要使用的附加的链接器选项。这对于使用‘-l’前缀传递指定库的名字是有用的。  
 例如，LOCAL\_LDLIBS := -lz表示告诉链接器生成的模块要在加载时刻链接到/system/lib/libz.so  
 可查看 docs/STABLE-APIS.TXT 获取使用 NDK发行版能链接到的开放的系统库列表。  
 （12） LOCAL\_ALLOW\_UNDEFINED\_SYMBOLS: 默认情况下， 在试图编译一个共享库时，任何未定义的引用将导致一个“未定义的符号”错误。这对于在源代码文件中捕捉错误会有很大的帮助。然而，如果因为某些原因，需要不启动这项检查，可把这个变量设为‘true’。  
 注意相应的共享库可能在运行时加载失败。(这个一般尽量不要去设为 true)。  
 （13） LOCAL\_ARM\_MODE: 默认情况下， arm目标二进制会以 thumb 的形式生成(16 位)，你可以通过设置这个变量为 arm，如果你希望你的 module 是以 32 位指令的形式。  
 ‘arm’ (32-bit instructions) mode. E.g.:  
 LOCAL\_ARM\_MODE := arm  
 注意：可以在编译的时候告诉系统针对某个源码文件进行特定的类型的编译  
 比如，LOCAL\_SRC\_FILES := foo.c bar.c.arm 这样就告诉系统总是将 bar.c 以arm的模式编译。  
 (14)LOCAL\_MODULE\_PATH 和 LOCAL\_UNSTRIPPED\_PATH  
 在 Android.mk 文件中， 还可以用LOCAL\_MODULE\_PATH 和LOCAL\_UNSTRIPPED\_PATH指定最后的目标安装路径.  
 不同的文件系统路径用以下的宏进行选择：  
 TARGET\_ROOT\_OUT：表示根文件系统。  
 TARGET\_OUT：表示 system文件系统。  
 TARGET\_OUT\_DATA：表示 data文件系统。  
 用法如：LOCAL\_MODULE\_PATH :=$(TARGET\_ROOT\_OUT)


android.bp关于.a和.so文件的引用  
 在Android开发的时候，经常会使用到用c或c++编写的第三方的静态库。如果有源码的话，可以直接跟你自己的代码一去编译成动态库so，但是如果没有源码的话，你就必须在自己的动态库so里面将别人生成好的静态库导入进来一起编译了。我在编译的时候遇到了不少问题，我觉得有必要进行总结一下。  
 .a静态库引入方式  
 在模块源码根文件下新建文件夹 libs，复制要引入的.a文件至此，新建 Android.bp  
 这样就会在obj生成文件夹下面重新生成一个libhisdk.a文件，这个文件就可以在其他android.bp文件中进行编译引用。  
 android.bp文件  
 cc\_prebuilt\_library\_static {  
 name: “libhisdk”,  
 recovery\_available: true,  
 defaults: [  
 “recovery\_defaults”,  
 ],  
 arch: {  
 arm: {  
 srcs: [“libhisdk.a”],  
 },  
 arm64: {  
 srcs: [“libhisdk.a”],  
 },  
 },


}  
 .so动态库引用方式  
 在模块源码根文件下新建文件夹 lib，复制要引入的 so 至此，在该文件中新建 Android.bp，这里以 libjniopencv\_face.so 为例, arm 和 arm64 分别对应32/64的so库,针对源码环境位数都是确定的，所以我们就写成一样了。  
 android.bp文件  
 cc\_prebuilt\_library\_shared {  
 name: “libjniopencv\_face”,  
 arch: {  
 arm: {  
 srcs: [“libjniopencv\_face.so”],  
 },  
 arm64: {  
 srcs: [“libjniopencv\_face.so”],  
 },  
 },  
 }


Android.mk中参数配置



```
LOCAL_MODULE_PATH := $(TARGET\_OUT)/preloadapp // 预置到system/preloadapp

```

2.baidu.apk 为例 创建Baidu文件夹  
 package/app/Baidu 放入Baidu.apk 配置Android.mk



```
LOCAL_PATH := $(call my-dir)
include $(CLEAR\_VARS)
LOCAL_POST_PROCESS_COMMAND := $(shell mkdir $(TARGET\_OUT)/preloadapp)//如果没有preloadapp就创建preloadapp文件夹
LOCAL_MODULE_TAGS := optional
LOCAL_MODULE := Baidu
LOCAL_MODULE_CLASS := APPS
LOCAL_CERTIFICATE := PRESIGNED
LOCAL_MODULE_PATH := $(TARGET\_OUT)/preloadapp //apk安装路径
LOCAL_SRC_FILES := Baidu.apk
include $(BUILD\_PREBUILT)

```

3.handheld\_product.mk 增加参与编译的app  
 路径:  
 build/make/target/product/handheld\_product.mk  
 具体源码为:



```
#
2 # Copyright (C) 2019 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
 # Unless required by applicable law or agreed to in writing, software
 # distributed under the License is distributed on an "AS IS" BASIS,
 # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 # See the License for the specific language governing permissions and
 # limitations under the License.
 #
 
 # This makefile contains the product partition contents for
 # a generic phone or tablet device. Only add something here if
 # it definitely doesn't belong on other types of devices (if it
 # does, use base\_vendor.mk).
 $(call inherit-product, $(SRC\_TARGET\_DIR)/product/media\_product.mk)
 
 # /product packages
 PRODUCT_PACKAGES += \
     Browser2 \
     Calendar \
     Camera2 \
     Contacts \
     DeskClock \
     Email \
     Gallery2 \
     LatinIME \
     Launcher3QuickStep \
     Music \
     OneTimeInitializer \
     Provision \
     QuickSearchBox \
     Settings \
     SettingsIntelligence \
     StorageManager \
     SystemUI \
     WallpaperCropper \
     frameworks-base-overlays
 
 PRODUCT_PACKAGES_DEBUG += \
     frameworks-base-overlays-debug

```

在handheld\_product.mk 中的 PRODUCT\_PACKAGES增加  
 需要参与编译app的名称，任何在系统编译的时候可以把需要编译的app参与系统的整个编译



```
PRODUCT_PACKAGES += \
Baidu  //添加 Baidu文件名

```




