






### 1.概述


在10.0的系统产品开发中，对于产品有些音量需求要求音量默认设置为最大音量的80%，所以就需要  
 在开机完成的时候，设置默认值


### 2.SystemUI VolumeUI媒体音量设置为最大值80%的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/volume/VolumeDialogImpl.java
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java

```

### 3.SystemUI VolumeUI媒体音量设置为最大值80%的核心功能分析和实现


接下来对音量条分析：  
 在按下音量键时，会弹出音量条，这就是SystemUI的音量条,其实就是  
 VolumeDialogImpl.java 路径就是 ：frameworks/base/packages/SystemUI/src/com/android/systemui/volume/VolumeDialogImpl.java


通过阅读代码得知 默认音量的类型就是AudioManager.STREAM\_MUSIC  
 首选我们看 怎么打开音量条的  
 代码如下:



```
synchronized (this) {
            if (mAudioManager == null) {
                mAudioManager = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            }
        }
        int flags = AudioManager.FLAG_SHOW_UI | AudioManager.FLAG_PLAY_SOUND;
        mAudioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, flags);

```

通过对AudioManager的接口调用实现了对音量条的音量的设置，而如果需要设置默认音量值为最大音量的80%


默认设置为80% Stream\_music


设置默认音量如下:



```
private void setDefaultVolume(){
    synchronized (this) {
        if (mAudioManager == null) {
            mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
        }
    }
    int flags = AudioManager.FLAG_SHOW_UI | AudioManager.FLAG_PLAY_SOUND;
    mAudioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, flags);
    int maxVolume = (int)(mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)*0.8);
    int minVolume = mAudioManager.getStreamMinVolume(AudioManager.STREAM_MUSIC);
    mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,maxVolume,flags);
    int currentVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
    Log.e(TAG,"maxVolume:"+maxVolume+"---minVolume:"+minVolume+"currentvolume:"+currentVolume);

}

```

通过上述setDefaultVolume()已经完成对默认音量Stream\_music 80% 的设置  
 接下来在PhoneWindowManager.java中设置默认音量  
 路径:  
 /frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java  
 systemBooted() 表示系统启动完毕可以与窗口交互所以加载setDefaultVolume()这个  
 方法里面就可以了



```
/**
   * WindowManagerPolicy implementation for the Android phone UI.  This
   * introduces a new method suffix, Lp, for an internal lock of the
   * PhoneWindowManager.  This is used to protect some internal state, and
   * can be acquired with either the Lw and Li lock held, so has the restrictions
   * of both of those when held.
   */
  public class PhoneWindowManager implements WindowManagerPolicy {

@Override
      public void onSystemUiStarted() {
          bindKeyguard();
      }
  
      /** {@inheritDoc} */
      @Override
      public void systemReady() {
          // In normal flow, systemReady is called before other system services are ready.
          // So it is better not to bind keyguard here.
          mKeyguardDelegate.onSystemReady();
  
          mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
          if (mVrManagerInternal != null) {
              mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
          }
  
          readCameraLensCoverState();
          updateUiMode();
          mDefaultDisplayRotation.updateOrientationListener();
          synchronized (mLock) {
              mSystemReady = true;
              mHandler.post(new Runnable() {
                  @Override
                  public void run() {
                      updateSettings();
                  }
              });
              // If this happens, for whatever reason, systemReady came later than systemBooted.
              // And keyguard should be already bound from systemBooted
              if (mSystemBooted) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
  
          mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
      }
  
      /** {@inheritDoc} */
      @Override
      public void systemBooted() {
          bindKeyguard();
          synchronized (mLock) {
              mSystemBooted = true;
              if (mSystemReady) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
          startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
          finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
          screenTurningOn(null);
          screenTurnedOn();
      }
      ProgressDialog mBootMsgDialog = null;
  
      /** {@inheritDoc} */
      @Override
      public void showBootMessage(final CharSequence msg, final boolean always) {
          mHandler.post(new Runnable() {
              @Override public void run() {
                  if (mBootMsgDialog == null) {
                      int theme;
                      if (mContext.getPackageManager().hasSystemFeature(FEATURE_LEANBACK)) {
                          theme = com.android.internal.R.style.Theme_Leanback_Dialog_Alert;
                      } else {
                          theme = 0;
                      }
  
                      mBootMsgDialog = new ProgressDialog(mContext, theme) {
                          // This dialog will consume all events coming in to
                          // it, to avoid it trying to do things too early in boot.
                          @Override public boolean dispatchKeyEvent(KeyEvent event) {
                              return true;
                          }
                          @Override public boolean dispatchKeyShortcutEvent(KeyEvent event) {
                              return true;
                          }
                          @Override public boolean dispatchTouchEvent(MotionEvent ev) {
                              return true;
                          }
                          @Override public boolean dispatchTrackballEvent(MotionEvent ev) {
                              return true;
                          }
                          @Override public boolean dispatchGenericMotionEvent(MotionEvent ev) {
                              return true;
                          }
                          @Override public boolean dispatchPopulateAccessibilityEvent(
                                  AccessibilityEvent event) {
                              return true;
                          }
                      };
                      if (mContext.getPackageManager().isDeviceUpgrading()) {
                          mBootMsgDialog.setTitle(R.string.android_upgrading_title);
                      } else {
                          mBootMsgDialog.setTitle(R.string.android_start_title);
                      }
                      mBootMsgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                      mBootMsgDialog.setIndeterminate(true);
                      mBootMsgDialog.getWindow().setType(
                              WindowManager.LayoutParams.TYPE_BOOT_PROGRESS);
                      mBootMsgDialog.getWindow().addFlags(
                              WindowManager.LayoutParams.FLAG_DIM_BEHIND
                              | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
                      mBootMsgDialog.getWindow().setDimAmount(1);
                      WindowManager.LayoutParams lp = mBootMsgDialog.getWindow().getAttributes();
                      lp.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_NOSENSOR;
                      mBootMsgDialog.getWindow().setAttributes(lp);
                      mBootMsgDialog.setCancelable(false);
                      mBootMsgDialog.show();
                  }
                  mBootMsgDialog.setMessage(msg);
              }
          });
      }
  

```

上述就是PhoneWindowManager的systemReady()和systemBooted()在开机启动完毕都会掉这两个方法，所以可以在这里面添加setDefaultVolume()就可以完成功能了





