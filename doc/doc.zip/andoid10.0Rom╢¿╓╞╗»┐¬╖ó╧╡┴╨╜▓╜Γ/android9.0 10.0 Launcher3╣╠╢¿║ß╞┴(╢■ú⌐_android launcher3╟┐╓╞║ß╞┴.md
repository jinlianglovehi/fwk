






### 1.概述


在10.0的产品定制化开发中,对于定制化launcher3中，平板由于竖屏显示不太美观，所以需要固定横屏,所以就需要在Launcher.java中来实现固定横屏功能


### 2.Launcher3固定横屏(二）的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/Launcher.java
packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

```

### 3.Launcher3固定横屏(二）的核心的核心功能分析和实现


### 3.1设置Launche3 固定横屏



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/Launcher.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/Launcher.java
@@ -19,7 +19,7 @@ package com.android.launcher3;
 import static android.content.pm.ActivityInfo.CONFIG_LOCALE;
 import static android.content.pm.ActivityInfo.CONFIG_ORIENTATION;
 import static android.content.pm.ActivityInfo.CONFIG_SCREEN_SIZE;
-
+import android.content.pm.ActivityInfo;
 import static com.android.launcher3.AbstractFloatingView.TYPE_DISCOVERY_BOUNCE;
 import static com.android.launcher3.AbstractFloatingView.TYPE_SNACKBAR;
 import static com.android.launcher3.LauncherAnimUtils.SPRING_LOADED_EXIT_DELAY;
@@ -31,7 +31,7 @@ import static com.android.launcher3.dragndrop.DragLayer.ALPHA_INDEX_LAUNCHER_LOA
 import static com.android.launcher3.dragndrop.DragLayer.ALPHA_INDEX_OVERLAY;
 import static com.android.launcher3.logging.LoggerUtils.newContainerTarget;
 import static com.android.launcher3.logging.LoggerUtils.newTarget;
-import static com.android.launcher3.states.RotationHelper.REQUEST_NONE;
+import static com.android.launcher3.states.RotationHelper.REQUEST_LOCK;
 import static com.android.launcher3.util.RaceConditionTracker.ENTER;
 import static com.android.launcher3.util.RaceConditionTracker.EXIT;
 import static com.sprd.ext.FeatureOption.SPRD_APP_REMOTE_ANIM_SUPPORT;
@@ -428,7 +428,7 @@ public class Launcher extends BaseDraggingActivity implements LauncherExterns,
@Override
     protected void onCreate(Bundle savedInstanceState) {
         RaceConditionTracker.onEvent(ON_CREATE_EVT, ENTER);
         if (DEBUG_STRICT_MODE) {
             StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                     .detectDiskReads()
                     .detectDiskWrites()
                     .detectNetwork()   // or .detectAll() for all detectable problems
                     .penaltyLog()
                     .build());
             StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                     .detectLeakedSqlLiteObjects()
                     .detectLeakedClosableObjects()
                     .penaltyLog()
                     .penaltyDeath()
                     .build());
         }
         TraceHelper.beginSection("Launcher-onCreate");
 
         super.onCreate(savedInstanceState);
         TraceHelper.partitionSection("Launcher-onCreate", "super call");
 
         LauncherAppState app = LauncherAppState.getInstance(this);
         mOldConfig = new Configuration(getResources().getConfiguration());
         ...
         }
    public void onEnterAnimationComplete() {
         super.onEnterAnimationComplete();
         UiFactory.onEnterAnimationComplete(this);
         mAllAppsController.highlightWorkTabIfNecessary();
-        mRotationHelper.setCurrentTransitionRequest(REQUEST_NONE);
+        mRotationHelper.setCurrentTransitionRequest(REQUEST_LOCK);
     }
 
     @Override
@@ -1025,6 +1025,7 @@ public class Launcher extends BaseDraggingActivity implements LauncherExterns,
    protected void onResume() {
         mAppMonitor.onLauncherResumed();
         TraceHelper.endSection("ON\_RESUME");
         RaceConditionTracker.onEvent(ON_RESUME_EVT, EXIT);
+        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
     }
       @Override
      protected void onStop() {
          super.onStop();
  
          if (mLauncherCallbacks != null) {
              mLauncherCallbacks.onStop();
          }
  
          getUserEventDispatcher().logActionCommand(Action.Command.STOP,
                  mStateManager.getState().containerType, -1);
  
          mAppWidgetHost.setListenIfResumed(false);
  
          NotificationListener.removeNotificationsChangedListener();
          getStateManager().moveToRestState();
  
          UiFactory.onLauncherStateOrResumeChanged(this);
  
          // Workaround for b/78520668, explicitly trim memory once UI is hidden
          onTrimMemory(TRIM_MEMORY_UI_HIDDEN);
      }

```

在Launcher 中的onEnterAnimationComplete() 和 onResume() 中对于设置屏幕旋转方向的setRequestedOrientation可以设置为横屏就是ActivityInfo.SCREEN\_ORIENTATION\_LANDSCAPE表示页面是固定横屏的方向


### 3.2 在系统中设置默认屏幕不旋转


在系统DatabaseHelper.java设置默认屏幕旋转方向  
 路径:  
 packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java



```
      private void loadSystemSettings(SQLiteDatabase db) {
          SQLiteStatement stmt = null;
          try {
              stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                      + " VALUES(?,?);");
  
              // Set default cdma DTMF type
              loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);
  
              // Set default hearing aid
              loadSetting(stmt, Settings.System.HEARING_AID, 0);
  
              // Set default tty mode
              loadSetting(stmt, Settings.System.TTY_MODE, 0);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                      R.integer.def_screen_brightness);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_FOR_VR,
                      com.android.internal.R.integer.config_screenBrightnessForVrSettingDefault);
  
              loadBooleanSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_MODE,
                      R.bool.def_screen_brightness_automatic_mode);
  
              loadBooleanSetting(stmt, Settings.System.ACCELEROMETER_ROTATION,
                      R.bool.def_accelerometer_rotation);
  
              loadUISoundEffectsSettings(stmt);
  
              loadIntegerSetting(stmt, Settings.System.POINTER_SPEED,
                      R.integer.def_pointer_speed);
  
//add core start
  loadBooleanSetting(stmt, Settings.System.ACCELEROMETER_ROTATION,
        false);
//add core end
          } finally {
              if (stmt != null) stmt.close();
          }
      }

```

在DatabaseHelper.java中的loadSystemSettings(SQLiteDatabase db)中添加系统默认屏幕方向  
 loadBooleanSetting(stmt, Settings.System.ACCELEROMETER\_ROTATION, false);  
 默认设置屏幕方向不允许旋转 就可以固定屏幕方向了





