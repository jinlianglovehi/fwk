






### 1.概述


在10.0设备定制化中，系统对于app崩溃或者无响应会弹出对话框来提示用户出现了问题，但是有些客户认为这样会不友好，所以就想去掉这个提示对话框,所以就要看这些是从哪里弹出来的 然后注释掉就可以了


### 2.屏蔽掉无响应和已停止对话框的核心类



```
frameworks\base\services\core\java\com\android\server\am\AppErrors.java
frameworks\base\services\core\java\com\android\server\am\ActivityManagerService.java

```

### 3.屏蔽掉无响应和已停止对话框的核心功能和分析


系统中，无响应的就是AppNotRespondingDialog.java 而已停止的就是AppErrorDialog.java,接下来就看AMS里面是怎么调用的  
 通过搜索源码发现 这两个Dialog都是在AppErrors.java中，调用这两个的  
 路径为:frameworks\base\services\core\java\com\android\server\am\AppErrors.java  
 // 已停止



```
void handleShowAppErrorUi(Message msg) {
        AppErrorDialog.Data data = (AppErrorDialog.Data) msg.obj;
        boolean showBackground = Settings.Secure.getInt(mContext.getContentResolver(),
                Settings.Secure.ANR_SHOW_BACKGROUND, 0) != 0;

        AppErrorDialog dialogToShow = null;
        final String packageName;
        final int userId;
        synchronized (mService) {
            final ProcessRecord proc = data.proc;
            final AppErrorResult res = data.result;
            if (proc == null) {
                Slog.e(TAG, "handleShowAppErrorUi: proc is null");
                return;
            }
            packageName = proc.info.packageName;
            userId = proc.userId;
            if (proc.crashDialog != null) {
                Slog.e(TAG, "App already has crash dialog: " + proc);
                if (res != null) {
                    res.set(AppErrorDialog.ALREADY_SHOWING);
                }
                return;
            }
            boolean isBackground = (UserHandle.getAppId(proc.uid)
                    >= Process.FIRST_APPLICATION_UID
                    && proc.pid != MY_PID);
            for (int profileId : mService.mUserController.getCurrentProfileIds()) {
                isBackground &= (userId != profileId);
            }
            if (isBackground && !showBackground) {
                Slog.w(TAG, "Skipping crash dialog of " + proc + ": background");
                if (res != null) {
                    res.set(AppErrorDialog.BACKGROUND_USER);
                }
                return;
            }
            final boolean showFirstCrash = Settings.Global.getInt(
                    mContext.getContentResolver(),
                    Settings.Global.SHOW_FIRST_CRASH_DIALOG, 0) != 0;
            final boolean showFirstCrashDevOption = Settings.Secure.getIntForUser(
                    mContext.getContentResolver(),
                    Settings.Secure.SHOW_FIRST_CRASH_DIALOG_DEV_OPTION,
                    0,
                    mService.mUserController.getCurrentUserId()) != 0;
            final boolean crashSilenced = mAppsNotReportingCrashes != null &&
                    mAppsNotReportingCrashes.contains(proc.info.packageName);
            if ((mService.mAtmInternal.canShowErrorDialogs() || showBackground)
 && !crashSilenced
 && (showFirstCrash || showFirstCrashDevOption || data.repeating)) {
                proc.crashDialog = dialogToShow = new AppErrorDialog(mContext, mService, data);
            } else {
                // The device is asleep, so just pretend that the user
                // saw a crash dialog and hit "force quit".
                if (res != null) {
                    res.set(AppErrorDialog.CANT_SHOW);
                }
            }
        }
        // If we've created a crash dialog, show it without the lock held
        if (dialogToShow != null) {
            Slog.i(TAG, "Showing crash dialog for package " + packageName + " u" + userId);
            dialogToShow.show();
        }
    }

```

从handleShowAppErrorUi(Message msg)可以看出调用handleShowAnrUi(Message msg)来  
 实现anr无响应的弹窗


// anr 无响应



```
void handleShowAnrUi(Message msg) {
    Dialog dialogToShow = null;
    List<VersionedPackage> packageList = null;
    synchronized (mService) {
        AppNotRespondingDialog.Data data = (AppNotRespondingDialog.Data) msg.obj;
        final ProcessRecord proc = data.proc;
        if (proc == null) {
            Slog.e(TAG, "handleShowAnrUi: proc is null");
            return;
        }
        if (!proc.isPersistent()) {
            packageList = proc.getPackageListWithVersionCode();
        }
        if (proc.anrDialog != null) {
            Slog.e(TAG, "App already has anr dialog: " + proc);
            MetricsLogger.action(mContext, MetricsProto.MetricsEvent.ACTION_APP_ANR,
                    AppNotRespondingDialog.ALREADY_SHOWING);
            return;
        }

        boolean showBackground = Settings.Secure.getInt(mContext.getContentResolver(),
                Settings.Secure.ANR_SHOW_BACKGROUND, 0) != 0;
        if (mService.mAtmInternal.canShowErrorDialogs() || showBackground) {
            dialogToShow = new AppNotRespondingDialog(mService, mContext, data);
            proc.anrDialog = dialogToShow;
        } else {
            MetricsLogger.action(mContext, MetricsProto.MetricsEvent.ACTION_APP_ANR,
                    AppNotRespondingDialog.CANT_SHOW);
            // Just kill the app if there is no dialog to be shown.
            mService.killAppAtUsersRequest(proc, null);
        }
    }
    // If we've created a crash dialog, show it without the lock held
    if (dialogToShow != null) {
        dialogToShow.show();
    }
    // Notify PackageWatchdog without the lock held
    if (packageList != null) {
        mPackageWatchdog.onPackageFailure(packageList);
    }
}

```

而在handleShowAnrUi(Message msg)中关于anr的弹窗最终还是由AMS中进行处理的  
 接下来看AMS中哪里调用屏蔽掉即可  
 路径:frameworks\base\services\core\java\com\android\server\am\ActivityManagerService.java



```
final class UiHandler extends Handler {
        public UiHandler() {
            super(com.android.server.UiThread.get().getLooper(), null, true);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case SHOW_ERROR_UI_MSG: {
               // mAppErrors.handleShowAppErrorUi(msg);
                ensureBootCompleted();
            } break;
            case SHOW_NOT_RESPONDING_UI_MSG: {
              //  mAppErrors.handleShowAnrUi(msg);
                ensureBootCompleted();
            } break;
            case SHOW_STRICT_MODE_VIOLATION_UI_MSG: {
                HashMap<String, Object> data = (HashMap<String, Object>) msg.obj;
                synchronized (ActivityManagerService.this) {
                    ProcessRecord proc = (ProcessRecord) data.get("app");
                    if (proc == null) {
                        Slog.e(TAG, "App not found when showing strict mode dialog.");
                        break;
                    }
                    if (proc.crashDialog != null) {
                        Slog.e(TAG, "App already has strict mode dialog: " + proc);
                        return;
                    }
                    AppErrorResult res = (AppErrorResult) data.get("result");
                    if (mAtmInternal.showStrictModeViolationDialog()) {
                        Dialog d = new StrictModeViolationDialog(mUiContext,
                                ActivityManagerService.this, res, proc);
                        d.show();
                        proc.crashDialog = d;
                    } else {
                        // The device is asleep, so just pretend that the user
                        // saw a crash dialog and hit "force quit".
                        res.set(0);
                    }
                }
                ensureBootCompleted();
            } break;
            case WAIT_FOR_DEBUGGER_UI_MSG: {
                synchronized (ActivityManagerService.this) {
                    ProcessRecord app = (ProcessRecord)msg.obj;
                    if (msg.arg1 != 0) {
                        if (!app.waitedForDebugger) {
                            Dialog d = new AppWaitingForDebuggerDialog(
                                    ActivityManagerService.this,
                                    mUiContext, app);
                            app.waitDialog = d;
                            app.waitedForDebugger = true;
                            d.show();
                        }
                    } else {
                        if (app.waitDialog != null) {
                            app.waitDialog.dismiss();
                            app.waitDialog = null;
                        }
                    }
                }
            } break;
            case DISPATCH_PROCESSES_CHANGED_UI_MSG: {
                dispatchProcessesChanged();
                break;
            }
            case DISPATCH_PROCESS_DIED_UI_MSG: {
                final int pid = msg.arg1;
                final int uid = msg.arg2;
                dispatchProcessDied(pid, uid);
                break;
            }
            case DISPATCH_UIDS_CHANGED_UI_MSG: {
                if (false) { // DO NOT SUBMIT WITH TRUE
                    maybeTriggerWatchdog();
                }
                dispatchUidsChanged();
            } break;
            case DISPATCH_OOM_ADJ_OBSERVER_MSG: {
                dispatchOomAdjObserver((String)msg.obj);
            } break;
            case PUSH_TEMP_WHITELIST_UI_MSG: {
                pushTempWhitelist();
            } break;
            }
        }
    }

```

在AMS中可以看出UiHandler 中的  
 SHOW\_ERROR\_UI\_MSG 即为已停止的消息处理  
 SHOW\_NOT\_RESPONDING\_UI\_MSG 即为无响应的消息处理 所以在这里注释掉相关的执行方法即可





