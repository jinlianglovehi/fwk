



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2. wifimac地址去掉随机改变的主要核心代码：](#2.%20wifimac%E5%9C%B0%E5%9D%80%E5%8E%BB%E6%8E%89%E9%9A%8F%E6%9C%BA%E6%94%B9%E5%8F%98%E7%9A%84%E4%B8%BB%E8%A6%81%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%EF%BC%9A)


[3. wifimac地址去掉随机改变的主要核心代码和功能分析](#3.%20wifimac%E5%9C%B0%E5%9D%80%E5%8E%BB%E6%8E%89%E9%9A%8F%E6%9C%BA%E6%94%B9%E5%8F%98%E7%9A%84%E4%B8%BB%E8%A6%81%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%92%8C%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 ClientModeImpl.java功能代码分析](#%C2%A03.1%20ClientModeImpl.java%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 ExtendedWifiInfo.java关于设置随机mac地址相关代码](#3.2%20ExtendedWifiInfo.java%E5%85%B3%E4%BA%8E%E8%AE%BE%E7%BD%AE%E9%9A%8F%E6%9C%BAmac%E5%9C%B0%E5%9D%80%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.3 WifiMetrics.java关于设置随机mac地址的相关方法](#3.3%20WifiMetrics.java%E5%85%B3%E4%BA%8E%E8%AE%BE%E7%BD%AE%E9%9A%8F%E6%9C%BAmac%E5%9C%B0%E5%9D%80%E7%9A%84%E7%9B%B8%E5%85%B3%E6%96%B9%E6%B3%95)


[3.4 随机mac地址修改为固定mac地址的修改方法为](#3.4%20%E9%9A%8F%E6%9C%BAmac%E5%9C%B0%E5%9D%80%E4%BF%AE%E6%94%B9%E4%B8%BA%E5%9B%BA%E5%AE%9Amac%E5%9C%B0%E5%9D%80%E7%9A%84%E4%BF%AE%E6%94%B9%E6%96%B9%E6%B3%95%E4%B8%BA)




---



## 1.概述


  在10.0的产品中，wifi的mac地址在联网前后会变化，因为默认是随机显示mac地址，所以会在连上wifi后mac地址会变动但是如果根据mac地址来升级会引起一系列问题，为了避免这些问题 所以就要求固定mac地址，这就需要看wifi模块怎么改变mac地址的


## 2. wifimac地址去掉随机改变的主要核心代码：



```
  frameworks\opt\net\wifi\service\java\com\android\server\wifi\ClientModeImpl.java
  frameworks\opt\net\wifi\service\java\com\android\server\wifi\ExtendedWifiInfo.java
  frameworks\opt\net\wifi\service\java\com\android\server\wifi\WifiMetrics.java
```

## 3. wifimac地址去掉随机改变的主要核心代码和功能分析


在系统中在wifi模块中，在ClientModeImpl.java中


ClientModeImpl 是ClientMode的状态机，是用于控制WiFi 连接，获取IP ,设置网络配置。上一篇我们说到启动后，发送消息使得ClientModeImpl 状态机切换到DisconnectedState 状态；调用DisconnectedState enter 方法；enter主要是调用 WifiConnectivityManager  
 的handleConnectionStateChanged 方法处理WiFi 网络状态的改变  
 WifiConnectivityManager 是管理WiFi 连接管理的类，主要管理者WiFi 网络的评分及网络选择，和扫描。



###  3.1 ClientModeImpl.java功能代码分析



```
  public class ClientModeImpl extends StateMachine {

   

public ClientModeImpl(Context context, FrameworkFacade facade, Looper looper,
                            UserManager userManager, WifiInjector wifiInjector,
                            BackupManagerProxy backupManagerProxy, WifiCountryCode countryCode,
                            WifiNative wifiNative, WrongPasswordNotifier wrongPasswordNotifier,
                            SarManager sarManager, WifiTrafficPoller wifiTrafficPoller,
                            LinkProbeManager linkProbeManager) {
        super(TAG, looper);
        mWifiInjector = wifiInjector;
        mWifiMetrics = mWifiInjector.getWifiMetrics();
        mClock = wifiInjector.getClock();
        mPropertyService = wifiInjector.getPropertyService();
        mBuildProperties = wifiInjector.getBuildProperties();
        mWifiScoreCard = wifiInjector.getWifiScoreCard();
        mContext = context;
        mFacade = facade;
        mWifiNative = wifiNative;
        mBackupManagerProxy = backupManagerProxy;
        mWrongPasswordNotifier = wrongPasswordNotifier;
        mSarManager = sarManager;
        mWifiTrafficPoller = wifiTrafficPoller;
        mLinkProbeManager = linkProbeManager;

        mNetworkInfo = new NetworkInfo(ConnectivityManager.TYPE_WIFI, 0, NETWORKTYPE, "");
        mBatteryStats = IBatteryStats.Stub.asInterface(mFacade.getService(
                BatteryStats.SERVICE_NAME));
        mWifiStateTracker = wifiInjector.getWifiStateTracker();
        IBinder b = mFacade.getService(Context.NETWORKMANAGEMENT_SERVICE);

        mWifiFeaturesUtils = WifiFeaturesUtils.getInstance(context);

        mP2pSupported = mContext.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_WIFI_DIRECT)
                && mWifiFeaturesUtils.isSupportP2pFeature();

        mWifiPermissionsUtil = mWifiInjector.getWifiPermissionsUtil();
        mWifiConfigManager = mWifiInjector.getWifiConfigManager();

        mPasspointManager = mWifiInjector.getPasspointManager();

        mWifiMonitor = mWifiInjector.getWifiMonitor();
        mWifiDiagnostics = mWifiInjector.getWifiDiagnostics();
        mWifiPermissionsWrapper = mWifiInjector.getWifiPermissionsWrapper();
        mWifiDataStall = mWifiInjector.getWifiDataStall();
        mWifiApClientStats = mWifiInjector.getWifiApClientStats();

        mWifiInfo = new ExtendedWifiInfo();
        mSupplicantStateTracker =
                mFacade.makeSupplicantStateTracker(context, mWifiConfigManager, getHandler());
        mWifiConnectivityManager = mWifiInjector.makeWifiConnectivityManager(this);


        mLinkProperties = new LinkProperties();
        mMcastLockManagerFilterController = new McastLockManagerFilterController();

        mNetworkInfo.setIsAvailable(false);
        mLastBssid = null;
        mLastNetworkId = WifiConfiguration.INVALID_NETWORK_ID;
        mLastSignalLevel = -1;

        mCountryCode = countryCode;

       .....

        //Unisoc: Add for Wifi Rssi LinkSpeed And Frequency Observer
        mWifiRssiLinkSpeedAndFrequencyMonitor = new WifiRssiLinkSpeedAndFrequencyMonitor(context);

        
        //<-- Add for Wifi Auto Roam Feature END

        if (mWifiFeaturesUtils.isConnectMaxTimeDisableNetworkSupported()){
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(Intent.ACTION_DATE_CHANGED);
            intentFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
            mContext.registerReceiver(
                    new BroadcastReceiver() {
                        @Override
                        public void onReceive(Context context, Intent intent) {
                            String action = intent.getAction();
                            if (action.equals(Intent.ACTION_DATE_CHANGED)) {
                                sendMessage(CMD_DATE_CHANGED);
                            } else if (action.equals(WifiManager.WIFI_STATE_CHANGED_ACTION)) {
                                int wifiState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, WifiManager.WIFI_STATE_UNKNOWN);
                                if (WifiManager.WIFI_STATE_ENABLED == wifiState) {
                                    sendMessage(CMD_WIFI_STATE_ENABLED);
                                }
                            }
                        }
                    }, intentFilter);
        }

        PowerManager powerManager = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
        mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getName());

        mSuspendWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WifiSuspend");
        mSuspendWakeLock.setReferenceCounted(false);

        mConnectedMacRandomzationSupported = mContext.getResources()
                .getBoolean(R.bool.config_wifi_connected_mac_randomization_supported);
        mWifiInfo.setEnableConnectedMacRandomization(mConnectedMacRandomzationSupported);
        mWifiMetrics.setIsMacRandomizationOn(mConnectedMacRandomzationSupported);

        mTcpBufferSizes = mContext.getResources().getString(
                R.string.config_wifi_tcp_buffers);

        // CHECKSTYLE:OFF IndentationCheck
        addState(mDefaultState);
            addState(mConnectModeState, mDefaultState);
                addState(mL2ConnectedState, mConnectModeState);
                    addState(mObtainingIpState, mL2ConnectedState);
                    addState(mConnectedState, mL2ConnectedState);
                    addState(mRoamingState, mL2ConnectedState);
                addState(mDisconnectingState, mConnectModeState);
                addState(mDisconnectedState, mConnectModeState);
        // CHECKSTYLE:ON IndentationCheck

        setInitialState(mDefaultState);

        setLogRecSize(NUM_LOG_RECS_NORMAL);
        setLogOnlyTransitions(false);
    }
```

在ClientModeImpl.java中上述的源码中分析得知，在  


mConnectedMacRandomzationSupported = mContext.getResources()  
                 .getBoolean(R.bool.config\_wifi\_connected\_mac\_randomization\_supported);  
         mWifiInfo.setEnableConnectedMacRandomization(mConnectedMacRandomzationSupported);  
         mWifiMetrics.setIsMacRandomizationOn(mConnectedMacRandomzationSupported);  
   这里就是设置是否开启随机mac地址


### 3.2 ExtendedWifiInfo.java关于设置随机mac地址相关代码



```
    /**
     * Updates whether Connected MAC Randomization is enabled.
     *
     * @hide
     */
    public void setEnableConnectedMacRandomization(boolean enableConnectedMacRandomization) {
        mEnableConnectedMacRandomization = enableConnectedMacRandomization;
    }
    @Override
    public void reset() {
        super.reset();
        mLastSource = SOURCE_UNKNOWN;
        mLastPacketCountUpdateTimeStamp = RESET_TIME_STAMP;
        if (mEnableConnectedMacRandomization) {
            setMacAddress(DEFAULT_MAC_ADDRESS);
        }
    }
```

   在上述代码分析，根据mConnectedMacRandomzationSupported 的值来判断是否打开随机mac时 mac地址设置为默认mac地址，而它的值取决于config\_wifi\_connected\_mac\_randomization\_supported的值，


### 3.3 WifiMetrics.java关于设置随机mac地址的相关方法



```
    /** Sets if Connected MAC Randomization feature is enabled */
    public void setIsMacRandomizationOn(boolean enabled) {
        synchronized (mLock) {
            mIsMacRandomizationOn = enabled;
        }
    }
```

### 


### 在WifiMetrics.java中可以看出在设置是否开启随机mac地址的功能，


通过 setIsMacRandomizationOn(boolean enabled)来设置是否开启随机mac地址的模式，所以


关键看哪里调用这个方法


### 3.4 随机mac地址修改为固定mac地址的修改方法为



```
   --- a/frameworks/base/core/res/res/values/config.xml
+++ b/frameworks/base/core/res/res/values/config.xml
@@ -747,7 +747,7 @@
     <bool translatable="false" name="config_wifi_local_only_hotspot_5ghz">false</bool>
 
     <!-- Indicates that connected MAC randomization is supported on this device -->
-    <bool translatable="false" name="config_wifi_connected_mac_randomization_supported">true</bool>
+    <bool translatable="false" name="config_wifi_connected_mac_randomization_supported">false</bool>
 
     <!-- Indicates that p2p MAC randomization is supported on this device -->
     <bool translatable="false" name="config_wifi_p2p_mac_randomization_supported">true</bool>
```

通过上述修改config\_wifi\_connected\_mac\_randomization\_supported的值来实现去掉随机修改mac地址的功能，修改成固定mac地址的功能



