



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2. SystemUI锁屏界面去掉多用户和只能拨打紧急电话提示功能核心代码](#2.%20SystemUI%E9%94%81%E5%B1%8F%E7%95%8C%E9%9D%A2%E5%8E%BB%E6%8E%89%E5%A4%9A%E7%94%A8%E6%88%B7%E5%92%8C%E5%8F%AA%E8%83%BD%E6%8B%A8%E6%89%93%E7%B4%A7%E6%80%A5%E7%94%B5%E8%AF%9D%E6%8F%90%E7%A4%BA%E5%8A%9F%E8%83%BD%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.SystemUI锁屏界面去掉多用户和只能拨打紧急电话提示功能代码分析](#3.SystemUI%E9%94%81%E5%B1%8F%E7%95%8C%E9%9D%A2%E5%8E%BB%E6%8E%89%E5%A4%9A%E7%94%A8%E6%88%B7%E5%92%8C%E5%8F%AA%E8%83%BD%E6%8B%A8%E6%89%93%E7%B4%A7%E6%80%A5%E7%94%B5%E8%AF%9D%E6%8F%90%E7%A4%BA%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 KeyguardStatusBarView.java关于锁屏功能的分析](#%C2%A0%203.1%20KeyguardStatusBarView.java%E5%85%B3%E4%BA%8E%E9%94%81%E5%B1%8F%E5%8A%9F%E8%83%BD%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 keyguard\_status\_bar.xml锁屏界面相关布局](#3.2%20keyguard_status_bar.xml%E9%94%81%E5%B1%8F%E7%95%8C%E9%9D%A2%E7%9B%B8%E5%85%B3%E5%B8%83%E5%B1%80)




---



## 1.概述


  在SystemUI的锁屏页面中，系统进入锁屏解锁页面后，会检测sim卡相关功能，如果未插sim卡会提示只能拨打紧急电话的提示这在wifi版的机器上感觉有点多余所以要求去掉提示，在状态栏也会显示多用户图标 点击多用户图标会有选择多用户的选项这也是不符合产品功能需求的，所以也是要求去掉多用户的


如图：


![](https://img-blog.csdnimg.cn/98a930de84254272a027a11f7d278b7a.png)



## 2. SystemUI锁屏界面去掉多用户和只能拨打紧急电话提示功能核心代码



```
  frameworks\base\packages\SystemUI\res\layout\keyguard_status_bar.xml
  frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\KeyguardStatusBarView.java
```

## 3.SystemUI锁屏界面去掉多用户和只能拨打紧急电话提示功能代码分析


  


1.在系统启动SystemUI的时候，在SystemUI启动完成后，进入的第一个界面为锁屏界面。  
 锁屏keyguard属于SystemUI。  
 锁屏开机大致分为两部分，第一部分是从WindowManagerService开始，处理锁屏显示等流程。  
 第二部分是KeyguardViewMediator的启动


KeyguardService绑定成功后调用了onSystemReady方法。  
 onSystemReady最终的处理流程是在KeyguardViewMediator的onSystemReady方法  
 KeyguardViewMediator中的onSystemReady方法发送了一条handler消息。经过消息传递会由handleSystemReady方法处理。handleSystemReady方法的关键调用是doKeyguardLocked。


KeyguardViewMediator中的在handleShow中调用StatusBarKeyguardViewManager方法，锁屏处理由KeyguardViewMediator转移到StatusBarKeyguardViewManager。


StatusBarKeyguardViewManager中show方法设置keyguard是否显示，通知statusbar显示锁屏，  
 重置view的状态，进行锁屏。  
 最终在开机进入锁屏界面和电源键锁屏都是在 KeyguardStatusBarView中处理相关数据，接下来分析下  
 KeyguardStatusBarView.java中锁屏页面布局的相关控件


##   3.1 KeyguardStatusBarView.java关于锁屏功能的分析



```
  public class KeyguardStatusBarView extends RelativeLayout
        implements BatteryStateChangeCallback, OnUserInfoChangedListener, ConfigurationListener {

   

    public KeyguardStatusBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mSystemIconsContainer = findViewById(R.id.system_icons_container);
        // 多用户相关布局
        mMultiUserSwitch = findViewById(R.id.multi_user_switch);
        mMultiUserAvatar = findViewById(R.id.multi_user_avatar);
        // 关于检测sim卡 无sim卡显示只能拨打紧急电话
        mCarrierLabel = findViewById(R.id.keyguard_carrier_text);
        mBatteryView = mSystemIconsContainer.findViewById(R.id.battery);
        mCutoutSpace = findViewById(R.id.cutout_space_view);
        mStatusIconArea = findViewById(R.id.status_icon_area);
        mStatusIconContainer = findViewById(R.id.statusIcons);

        loadDimens();
        updateUserSwitcher();
        mBatteryController = Dependency.get(BatteryController.class);
    }

    @Override
    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        //UNISOC: fix for bug 1217632
        MarginLayoutParams lp = (MarginLayoutParams) getLayoutParams();
        lp.height =  getResources().getDimensionPixelSize(
                R.dimen.status_bar_header_height_keyguard);
        setLayoutParams(lp);

        lp = (MarginLayoutParams) mMultiUserAvatar.getLayoutParams();
        lp.width = lp.height = getResources().getDimensionPixelSize(
                R.dimen.multi_user_avatar_keyguard_size);
        mMultiUserAvatar.setLayoutParams(lp);

        // Multi-user switch  多用户布局
        lp = (MarginLayoutParams) mMultiUserSwitch.getLayoutParams();
        lp.width = getResources().getDimensionPixelSize(
                R.dimen.multi_user_switch_width_keyguard);
        lp.setMarginEnd(getResources().getDimensionPixelSize(
                R.dimen.multi_user_switch_keyguard_margin));
        mMultiUserSwitch.setLayoutParams(lp);

        // System icons
        lp = (MarginLayoutParams) mSystemIconsContainer.getLayoutParams();
        lp.setMarginStart(getResources().getDimensionPixelSize(
                R.dimen.system_icons_super_container_margin_start));
        mSystemIconsContainer.setLayoutParams(lp);
        mSystemIconsContainer.setPaddingRelative(mSystemIconsContainer.getPaddingStart(),
                mSystemIconsContainer.getPaddingTop(),
                getResources().getDimensionPixelSize(R.dimen.system_icons_keyguard_padding_end),
                mSystemIconsContainer.getPaddingBottom());

        // Respect font size setting.
        mCarrierLabel.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                getResources().getDimensionPixelSize(
                        com.android.internal.R.dimen.text_size_small_material));
        lp = (MarginLayoutParams) mCarrierLabel.getLayoutParams();
        lp.setMarginStart(
                getResources().getDimensionPixelSize(R.dimen.keyguard_carrier_text_margin));
        mCarrierLabel.setLayoutParams(lp);
    }

    
....
}
```

在KeyguardStatusBarView.java中的上述代码中发现，在onFinishInflate()中加载完布局后，在


R.id.multi\_user\_switch和R.id.multi\_user\_avatar是多用户的相关布局，而R.id.keyguard\_carrier\_text就是拨打紧急电话的相关布局



## 3.2 keyguard\_status\_bar.xml锁屏界面相关布局



```
     <com.android.systemui.statusbar.phone.KeyguardStatusBarView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:id="@+id/keyguard_header"
    android:layout_width="match_parent"
    android:layout_height="@dimen/status_bar_header_height_keyguard"
    android:baselineAligned="false"
    android:gravity="center_vertical"
    >

    <LinearLayout
        android:id="@+id/status_icon_area"
        android:layout_width="wrap_content"
        android:layout_height="match_parent"
        android:layout_alignParentEnd="true"
        android:gravity="center_vertical|end" >
        <FrameLayout android:id="@+id/system_icons_container"
            android:layout_width="0dp"
            android:layout_height="match_parent"
            android:layout_weight="1"
            android:layout_marginStart="@dimen/system_icons_super_container_margin_start"
            android:gravity="center_vertical|end"
            android:paddingEnd="@dimen/system_icons_keyguard_padding_end" >
            <include layout="@layout/system_icons" />
        </FrameLayout>

        <com.android.systemui.statusbar.phone.MultiUserSwitch android:id="@+id/multi_user_switch"
            android:layout_width="@dimen/multi_user_switch_width_keyguard"
            android:layout_height="match_parent"
            android:background="@drawable/ripple_drawable"
+			android:visibility="gone"
            android:layout_marginEnd="@dimen/multi_user_switch_keyguard_margin">
            <ImageView android:id="@+id/multi_user_avatar"
                android:layout_width="@dimen/multi_user_avatar_keyguard_size"
                android:layout_height="@dimen/multi_user_avatar_keyguard_size"
                android:layout_gravity="center"
                android:scaleType="centerInside"/>
        </com.android.systemui.statusbar.phone.MultiUserSwitch>
    </LinearLayout>

    <Space
        android:id="@+id/cutout_space_view"
        android:layout_width="0dp"
        android:layout_height="match_parent"
        android:gravity="center"
        android:visibility="gone" />

    <com.android.keyguard.CarrierText
        android:id="@+id/keyguard_carrier_text"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layout_marginStart="@dimen/keyguard_carrier_text_margin"
        android:layout_toStartOf="@id/system_icons_container"
        android:gravity="center_vertical"
        android:ellipsize="marquee"
        android:textDirection="locale"
        android:textAppearance="@style/TextAppearance.StatusBar.Clock"
        android:textColor="?attr/wallpaperTextColorSecondary"
        android:singleLine="true"
+		android:visibility="gone"
        systemui:showMissingSim="true"
        systemui:showAirplaneMode="true" />

</com.android.systemui.statusbar.phone.KeyguardStatusBarView>
```

从keyguard\_status\_bar.xml上述代码可以发现代码中


CarrierText就是提示只能拨打紧急电话布局 而MultiUserSwitch就是多用户布局


所以隐藏掉对应的布局就好了



