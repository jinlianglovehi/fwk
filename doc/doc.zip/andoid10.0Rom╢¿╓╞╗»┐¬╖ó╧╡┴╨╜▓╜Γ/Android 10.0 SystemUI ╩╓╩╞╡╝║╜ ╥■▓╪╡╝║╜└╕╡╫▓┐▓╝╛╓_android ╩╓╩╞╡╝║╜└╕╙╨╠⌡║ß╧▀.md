






在10.0SystemUI 中导航栏 分为手势导航和三键导航 三键导航切换到手势导航时，默认会有 一条黑色的横线 布局 代表当前是手势布局  
 由于客户觉得 这条黑色横线 布局 觉得不美观，所以要求去掉黑色布局 为了实现需求，来看下这个布局


首选看下 NavigationBarView.java 这个底部导航栏布局的源码



```
public NavigationBarView(Context context, AttributeSet attrs) {
    super(context, attrs);
    mIsVertical = false;
    mLongClickableAccessibilityButton = false;
    mNavBarMode = Dependency.get(NavigationModeController.class).addListener(this);
    /* UNISCO: Bug 1072090,1116092 new feature of dynamic navigationbar @{*/
    mSupportDynamicBar = isSupportDynamicNavBar(mContext, mNavBarMode);
    /* }@ */
    boolean isGesturalMode = isGesturalMode(mNavBarMode);

    // Set up the context group of buttons
    mContextualButtonGroup = new ContextualButtonGroup(R.id.menu_container);
    final ContextualButton imeSwitcherButton = new ContextualButton(R.id.ime_switcher,
            R.drawable.ic_ime_switcher_default);
    final RotationContextButton rotateSuggestionButton = new RotationContextButton(
            R.id.rotate_suggestion, R.drawable.ic_sysbar_rotate_button);
    final ContextualButton accessibilityButton =
            new ContextualButton(R.id.accessibility_button,
                    R.drawable.ic_sysbar_accessibility_button);
    mContextualButtonGroup.addButton(imeSwitcherButton);
    if (!isGesturalMode) {
        mContextualButtonGroup.addButton(rotateSuggestionButton);
    }
    mContextualButtonGroup.addButton(accessibilityButton);
    mKeyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
    mOverviewProxyService = Dependency.get(OverviewProxyService.class);
    mRecentsOnboarding = new RecentsOnboarding(context, mOverviewProxyService);
    mFloatingRotationButton = new FloatingRotationButton(context);
    mRotationButtonController = new RotationButtonController(context,
            R.style.RotateButtonCCWStart90,
            isGesturalMode ? mFloatingRotationButton : rotateSuggestionButton);

    final ContextualButton backButton = new ContextualButton(R.id.back, 0);

    mConfiguration = new Configuration();
    mTmpLastConfiguration = new Configuration();
    mConfiguration.updateFrom(context.getResources().getConfiguration());

    mScreenPinningNotify = new ScreenPinningNotify(mContext);
    mBarTransitions = new NavigationBarTransitions(this);

    mButtonDispatchers.put(R.id.back, backButton);
    mButtonDispatchers.put(R.id.home, new ButtonDispatcher(R.id.home));
    mButtonDispatchers.put(R.id.home_handle, new ButtonDispatcher(R.id.home_handle));
    mButtonDispatchers.put(R.id.recent_apps, new ButtonDispatcher(R.id.recent_apps));
    mButtonDispatchers.put(R.id.ime_switcher, imeSwitcherButton);
    mButtonDispatchers.put(R.id.accessibility_button, accessibilityButton);
    mButtonDispatchers.put(R.id.rotate_suggestion, rotateSuggestionButton);
    mButtonDispatchers.put(R.id.menu_container, mContextualButtonGroup);
    mDeadZone = new DeadZone(this);
    /* UNISOC: Bug 1072090 new feature of dynamic navigationbar @{ */
    if(mSupportDynamicBar){
        mStatusBar = SysUiServiceProvider.getComponent(getContext(), StatusBar.class);
        mButtonDispatchers.put(R.id.hide, new ButtonDispatcher(R.id.hide));
        mButtonDispatchers.put(R.id.pull, new ButtonDispatcher(R.id.pull));
    }
    /* }@ */
    mEdgeBackGestureHandler = new EdgeBackGestureHandler(context, mOverviewProxyService);
    mTintController = new NavBarTintController(this, getLightTransitionsController());
}

```

从源码中可以看到 mButtonDispatchers 把每个导航栏相关布局文件都放在集合里 方便获取  
 而 mButtonDispatchers.put(R.id.home\_handle, new ButtonDispatcher(R.id.home\_handle)); 就是手势导航底部的布局  
 布局文件为:home\_handle.xml  
 路径为:frameworks\base\packages\SystemUI\res\layout\home\_handle.xml



```
<com.android.systemui.statusbar.phone.NavigationHandle
xmlns:android="http://schemas.android.com/apk/res/android"
android:id="@+id/home\_handle"
android:layout_width="@dimen/navigation\_home\_handle\_width"
android:layout_height="match\_parent"
android:layout_weight="0"
android:paddingStart="@dimen/navigation\_key\_padding"
android:paddingEnd="@dimen/navigation\_key\_padding"
/>

```

NavigationHandle.java 来负责绘制布局  
 路径:frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NavigationHandle.java



```
public class NavigationHandle extends View implements ButtonInterface {
private float mDarkIntensity = -1;
private final Paint mPaint = new Paint();
private @ColorInt final int mLightColor;
private @ColorInt final int mDarkColor;
private final int mRadius;
private final int mBottom;
public NavigationHandle(Context context) {
this(context, null);
}
public NavigationHandle(Context context, AttributeSet attr) {
super(context, attr);
final Resources res = context.getResources();
mRadius = res.getDimensionPixelSize(R.dimen.navigation_handle_radius);
mBottom = res.getDimensionPixelSize(R.dimen.navigation_handle_bottom);
final int dualToneDarkTheme = Utils.getThemeAttr(context, R.attr.darkIconTheme);
final int dualToneLightTheme = Utils.getThemeAttr(context, R.attr.lightIconTheme);
Context lightContext = new ContextThemeWrapper(context, dualToneLightTheme);
Context darkContext = new ContextThemeWrapper(context, dualToneDarkTheme);
mLightColor = Utils.getColorAttrDefaultColor(lightContext, R.attr.singleToneColor);
mDarkColor = Utils.getColorAttrDefaultColor(darkContext, R.attr.singleToneColor);
mPaint.setAntiAlias(true);
setFocusable(false);
}
@Override
protected void onDraw(Canvas canvas) {
super.onDraw(canvas);
// Draw that bar
int navHeight = getHeight();
int height = mRadius * 2;
int width = getWidth();
int y = (navHeight - mBottom - height);
//canvas.drawRoundRect(0, y, width, y + height, mRadius, mRadius, mPaint);//motify
}
。。。
}

```

布局绘制都是通过onDraw(Canvas canvas)来绘制的 所以注释掉绘制部分



```
canvas.drawRoundRect(0, y, width, y + height, mRadius, mRadius, mPaint);//motify

```

重新烧录SystemUI 发现底部布局已经没有了





