



**目录**


[简述](#%E7%AE%80%E8%BF%B0)


[功能分析与实现](#%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E4%B8%8E%E5%AE%9E%E7%8E%B0)


[QSTileBaseView.java 定制图标和背景](#QSTileBaseView.java%20%E5%AE%9A%E5%88%B6%E5%9B%BE%E6%A0%87%E5%92%8C%E8%83%8C%E6%99%AF)




---



## 简述


下拉状态栏定制化开发(四）本篇主要讲解 增加快捷功能的图标和背景 在默认首次展开下拉状态栏时 会发现快捷功能图标是不带文字的 只有在第二次展开时 会显示带文字的快捷功能图标


## 功能分析与实现


首次下拉状态栏带文字实现



```
public class QSFactoryImpl implements QSFactory {

private static final String TAG = "QSFactory";

private final Provider<WifiTile> mWifiTileProvider;
private final Provider<BluetoothTile> mBluetoothTileProvider;
private final Provider<CellularTile> mCellularTileProvider;
private final Provider<DndTile> mDndTileProvider;
private final Provider<ColorInversionTile> mColorInversionTileProvider;
private final Provider<AirplaneModeTile> mAirplaneModeTileProvider;
private final Provider<WorkModeTile> mWorkModeTileProvider;
private final Provider<RotationLockTile> mRotationLockTileProvider;
private final Provider<FlashlightTile> mFlashlightTileProvider;
private final Provider<LocationTile> mLocationTileProvider;
private final Provider<CastTile> mCastTileProvider;
private final Provider<HotspotTile> mHotspotTileProvider;
private final Provider<UserTile> mUserTileProvider;
private final Provider<BatterySaverTile> mBatterySaverTileProvider;
private final Provider<DataSaverTile> mDataSaverTileProvider;
private final Provider<NightDisplayTile> mNightDisplayTileProvider;
private final Provider<NfcTile> mNfcTileProvider;
private final Provider<GarbageMonitor.MemoryTile> mMemoryTileProvider;
private final Provider<UiModeNightTile> mUiModeNightTileProvider;
private final Provider<ScreenRecordTile> mScreenRecordTileProvider;

private final Lazy<QSHost> mQsHostLazy;

@Inject
public QSFactoryImpl(Lazy<QSHost> qsHostLazy,
Provider<WifiTile> wifiTileProvider,
Provider<BluetoothTile> bluetoothTileProvider,
Provider<CellularTile> cellularTileProvider,
Provider<DndTile> dndTileProvider,
Provider<ColorInversionTile> colorInversionTileProvider,
Provider<AirplaneModeTile> airplaneModeTileProvider,
Provider<WorkModeTile> workModeTileProvider,
Provider<RotationLockTile> rotationLockTileProvider,
Provider<FlashlightTile> flashlightTileProvider,
Provider<LocationTile> locationTileProvider,
Provider<CastTile> castTileProvider,
Provider<HotspotTile> hotspotTileProvider,
Provider<UserTile> userTileProvider,
Provider<BatterySaverTile> batterySaverTileProvider,
Provider<DataSaverTile> dataSaverTileProvider,
Provider<NightDisplayTile> nightDisplayTileProvider,
Provider<NfcTile> nfcTileProvider,
Provider<GarbageMonitor.MemoryTile> memoryTileProvider,
Provider<UiModeNightTile> uiModeNightTileProvider,
Provider<ScreenRecordTile> screenRecordTileProvider) {
mQsHostLazy = qsHostLazy;
mWifiTileProvider = wifiTileProvider;
mBluetoothTileProvider = bluetoothTileProvider;
mCellularTileProvider = cellularTileProvider;
mDndTileProvider = dndTileProvider;
mColorInversionTileProvider = colorInversionTileProvider;
mAirplaneModeTileProvider = airplaneModeTileProvider;
mWorkModeTileProvider = workModeTileProvider;
mRotationLockTileProvider = rotationLockTileProvider;
mFlashlightTileProvider = flashlightTileProvider;
mLocationTileProvider = locationTileProvider;
mCastTileProvider = castTileProvider;
mHotspotTileProvider = hotspotTileProvider;
mUserTileProvider = userTileProvider;
mBatterySaverTileProvider = batterySaverTileProvider;
mDataSaverTileProvider = dataSaverTileProvider;
mNightDisplayTileProvider = nightDisplayTileProvider;
mNfcTileProvider = nfcTileProvider;
mMemoryTileProvider = memoryTileProvider;
mUiModeNightTileProvider = uiModeNightTileProvider;
mScreenRecordTileProvider = screenRecordTileProvider;
}

public QSTile createTile(String tileSpec) {
QSTileImpl tile = createTileInternal(tileSpec);
if (tile != null) {
tile.handleStale(); // Tile was just created, must be stale.
}
return tile;
}

private QSTileImpl createTileInternal(String tileSpec) {
// Stock tiles.
switch (tileSpec) {
case "wifi":
return mWifiTileProvider.get();
case "bt":
return mBluetoothTileProvider.get();
case "cell":
return mCellularTileProvider.get();
case "dnd":
return mDndTileProvider.get();
case "inversion":
return mColorInversionTileProvider.get();
case "airplane":
return mAirplaneModeTileProvider.get();
case "work":
return mWorkModeTileProvider.get();
case "rotation":
return mRotationLockTileProvider.get();
case "flashlight":
return mFlashlightTileProvider.get();
case "location":
return mLocationTileProvider.get();
case "cast":
return mCastTileProvider.get();
case "hotspot":
return mHotspotTileProvider.get();
case "user":
return mUserTileProvider.get();
case "battery":
return mBatterySaverTileProvider.get();
case "saver":
return mDataSaverTileProvider.get();
case "night":
return mNightDisplayTileProvider.get();
case "nfc":
return mNfcTileProvider.get();
case "dark":
return mUiModeNightTileProvider.get();
case "screenrecord":
return mScreenRecordTileProvider.get();
}

// Custom tiles
if (tileSpec.startsWith(CustomTile.PREFIX)) {
return CustomTile.create(mQsHostLazy.get(), tileSpec,
mQsHostLazy.get().getUserContext());
}

// Debug tiles.
if (Build.IS_DEBUGGABLE) {
if (tileSpec.equals(GarbageMonitor.MemoryTile.TILE_SPEC)) {
return mMemoryTileProvider.get();
}
}

// Broken tiles.
Log.w(TAG, "No stock tile spec: " + tileSpec);
return null;
}

@Override
public QSTileView createTileView(QSTile tile, boolean collapsedView) {
Context context = new ContextThemeWrapper(mQsHostLazy.get().getContext(), R.style.qs_theme);
QSIconView icon = tile.createTileView(context);
if (collapsedView) {
return new QSTileBaseView(context, icon, collapsedView);
} else {
return new com.android.systemui.qs.tileimpl.QSTileView(context, icon);
}
}
}





```

在QSFactoryImpl.java 中的createTileView(QSTile tile, boolean collapsedView)  
 负责构建两种不同的快捷功能图标


    @Override  
     public QSTileView createTileView(QSTile tile, boolean collapsedView) {  
         Context context = new ContextThemeWrapper(mHost.getContext(), R.style.qs\_theme);  
         QSIconView icon = tile.createTileView(context);  
         if (collapsedView) {  
             return new QSTileBaseView(context, icon, collapsedView);  
         } else {  
             return new com.android.systemui.qs.tileimpl.QSTileView(context, icon);  
         }  
     }  
 QSTileView.java 就是带文字的功能图标  而QSTileBaseView.java就是不带文字的图标



```
所以修改为:
    @Override
    public QSTileView createTileView(QSTile tile, boolean collapsedView) {
        Context context = new ContextThemeWrapper(mHost.getContext(), R.style.qs_theme);
        QSIconView icon = tile.createTileView(context);
       // if (collapsedView) {
       //     return new QSTileBaseView(context, icon, collapsedView);
       // } else {
            return new com.android.systemui.qs.tileimpl.QSTileView(context, icon);
       // }
    }
```

## QSTileBaseView.java 定制图标和背景



```
接下来 快捷功能view就是QSTileBaseView.java 定制图标和背景
路径:
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSTileBaseView.java

public class QSTileBaseView extends com.android.systemui.plugins.qs.QSTileView {

    private static final String TAG = "QSTileBaseView";
    private static final int ICON_MASK_ID = R.string.quick_config_icon_mask;
    private final H mHandler = new H();
    private final int[] mLocInScreen = new int[2];
    private final FrameLayout mIconFrame;
    protected QSIconView mIcon;
    protected RippleDrawable mRipple;
    private Drawable mTileBackground;
    private String mAccessibilityClass;
    private boolean mTileState;
    private boolean mCollapsedView;
    private boolean mClicked;
    private boolean mShowRippleEffect = true;

    private final ImageView mBg;
    private final int mColorActive;
    private final int mColorInactive;
    private final int mColorDisabled;
    private int mCircleColor;
    private int mBgSize;
    private ValueAnimator mAnimator; // UNISOC: Modify for bug 1244855

    public QSTileBaseView(Context context, QSIconView icon) {
        this(context, icon, false);
    }

    public QSTileBaseView(Context context, QSIconView icon, boolean collapsedView) {
        super(context);
        // Default to Quick Tile padding, and QSTileView will specify its own padding.
        int padding = context.getResources().getDimensionPixelSize(R.dimen.qs_quick_tile_padding);
        mIconFrame = new FrameLayout(context);
        int size = context.getResources().getDimensionPixelSize(R.dimen.qs_quick_tile_size);
        addView(mIconFrame, new LayoutParams(size, size));
        mBg = new ImageView(getContext());
        Path path = new Path(PathParser.createPathFromPathData(
                context.getResources().getString(ICON_MASK_ID)));
        float pathSize = AdaptiveIconDrawable.MASK_SIZE;
        PathShape p = new PathShape(path, pathSize, pathSize);
        ShapeDrawable d = new ShapeDrawable(p);
        d.setTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        int bgSize = context.getResources().getDimensionPixelSize(R.dimen.qs_tile_background_size);
        d.setIntrinsicHeight(bgSize);
        d.setIntrinsicWidth(bgSize);
        mBg.setImageDrawable(d);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(bgSize, bgSize, Gravity.CENTER);
        mIconFrame.addView(mBg, lp);
        mBg.setLayoutParams(lp);
        mIcon = icon;
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        mIconFrame.addView(mIcon, params);
        mIconFrame.setClipChildren(false);
        mIconFrame.setClipToPadding(false);

        mTileBackground = newTileBackground();
        if (mTileBackground instanceof RippleDrawable) {
            setRipple((RippleDrawable) mTileBackground);
        }
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        setBackground(mTileBackground);

        mColorActive = /*Utils.getColorAttrDefaultColor(context, android.R.attr.colorAccent)*/Color.parseColor("#1E90FF");
        mColorDisabled = /*Utils.getDisabled(context,Utils.getColorAttrDefaultColor(context, android.R.attr.textColorTertiary))*/Color.parseColor("#F5F6F7");
        mColorInactive = Utils.getColorAttrDefaultColor(context, android.R.attr.textColorSecondary);

        setPadding(0, 0, 0, 0);
        setClipChildren(false);
        setClipToPadding(false);
        mCollapsedView = collapsedView;
        setFocusable(true);
    }



```

在构造方法中主要设置相关的参数  
 ICON\_MASK\_ID 为背景svg xml相关代码  
 修改背景颜色就是这里修改


<string name="quick\_config\_icon\_mask" translatable="false">"M50,50m-50,0a50,50 0,1 1,100 0a50,50 0,1 1,-100 0"</string>


  
 背景图片的大小为res/value/dimens.xml中的  
 qs\_tile\_background\_size


图标的宽高  
 qs\_quick\_tile\_size  
 可以调整自己适合的高度即可  
 mColorActive为快捷键开关打开状态的颜色  
 如果想修改颜色 可以这样修改：  
 mColorActive = /\*Utils.getColorAttrDefaultColor(context, android.R.attr.colorAccent)\*/Color.parseColor("#1E90FF");


  
 同理mColorDisabled为未选中的颜色  
 可以这样修改：  
  mColorDisabled = /\*Utils.getDisabled(context,Utils.getColorAttrDefaultColor(context, android.R.attr.textColorTertiary))\*/Color.parseColor("#F5F6F7");



