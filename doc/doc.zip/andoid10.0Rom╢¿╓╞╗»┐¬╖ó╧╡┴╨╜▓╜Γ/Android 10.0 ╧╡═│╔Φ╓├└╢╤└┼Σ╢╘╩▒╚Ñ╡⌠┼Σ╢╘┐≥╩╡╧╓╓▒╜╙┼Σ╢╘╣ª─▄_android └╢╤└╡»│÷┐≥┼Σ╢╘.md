



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.系统设置蓝牙配对时去掉配对框实现直接配对功能核心代码](#2.%E7%B3%BB%E7%BB%9F%E8%AE%BE%E7%BD%AE%E8%93%9D%E7%89%99%E9%85%8D%E5%AF%B9%E6%97%B6%E5%8E%BB%E6%8E%89%E9%85%8D%E5%AF%B9%E6%A1%86%E5%AE%9E%E7%8E%B0%E7%9B%B4%E6%8E%A5%E9%85%8D%E5%AF%B9%E5%8A%9F%E8%83%BD%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.系统设置蓝牙配对时去掉配对框实现直接配对功能分析以及实现功能  3.1 首选搜索到蓝牙设备后点击配对BluetoothPairingRequest.java接收配对请求](#3.%E7%B3%BB%E7%BB%9F%E8%AE%BE%E7%BD%AE%E8%93%9D%E7%89%99%E9%85%8D%E5%AF%B9%E6%97%B6%E5%8E%BB%E6%8E%89%E9%85%8D%E5%AF%B9%E6%A1%86%E5%AE%9E%E7%8E%B0%E7%9B%B4%E6%8E%A5%E9%85%8D%E5%AF%B9%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E4%BB%A5%E5%8F%8A%E5%AE%9E%E7%8E%B0%E5%8A%9F%E8%83%BD%C2%A0%203.1%20%E9%A6%96%E9%80%89%E6%90%9C%E7%B4%A2%E5%88%B0%E8%93%9D%E7%89%99%E8%AE%BE%E5%A4%87%E5%90%8E%E7%82%B9%E5%87%BB%E9%85%8D%E5%AF%B9BluetoothPairingRequest.java%E6%8E%A5%E6%94%B6%E9%85%8D%E5%AF%B9%E8%AF%B7%E6%B1%82)


[3.2 BluetoothPairingDialog.java 中相关代码分析](#3.2%20BluetoothPairingDialog.java%20%E4%B8%AD%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.3 BluetoothPairingDialogFragment中相关代码分析](#3.3%20BluetoothPairingDialogFragment%E4%B8%AD%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.4 BluetoothPairingController.java的相关代码分析](#3.4%20BluetoothPairingController.java%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)




---


## 1.概述


  在10.0定制化开发中，客户要求在系统设置里面设备配对其他蓝牙设备时，去掉配对框直接配对就可以了这就要分析下整个配对过程，看看配对框点击配对后怎么实现配对的


## 2.系统设置蓝牙配对时去掉配对框实现直接配对功能核心代码



```
  packages/apps/Settings/src/com/android/settings/bluetooth/BluetoothPairingRequest.java
  packages\apps\Settings\src\com\android\settings\bluetooth\BluetoothPairingDialog.java
  packages\apps\Settings\src\com\android\settings\bluetooth\BluetoothPairingDialogFragment.java
  packages\apps\Settings\src\com\android\settings\bluetooth\BluetoothPairingController.java
```

### 3.系统设置蓝牙配对时去掉配对框实现直接配对功能分析以及实现功能   3.1 首选搜索到蓝牙设备后点击配对BluetoothPairingRequest.java接收配对请求



```
packages/apps/Settings/src/com/android/settings/bluetooth/BluetoothPairingRequest.java

public final class BluetoothPairingRequest extends BroadcastReceiver {

  @Override
  public void onReceive(Context context, Intent intent) {
    String action = intent.getAction();
    // SPRD:bug#785347 action may be null
    if (!BluetoothDevice.ACTION_PAIRING_REQUEST.equals(action)) {
      return;
    }
    // convert broadcast intent into activity intent (same action string)
    Intent pairingIntent = BluetoothPairingService.getPairingDialogIntent(context, intent);

    PowerManager powerManager =
        (PowerManager)context.getSystemService(Context.POWER_SERVICE);
    BluetoothDevice device =
        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
    String deviceAddress = device != null ? device.getAddress() : null;
    String deviceName = device != null ? device.getName() : null;
    boolean shouldShowDialog = LocalBluetoothPreferences.shouldShowDialogInForeground(
        context, deviceAddress, deviceName);
    if (powerManager.isInteractive() && shouldShowDialog) {
      // Since the screen is on and the BT-related activity is in the foreground,
      // just open the dialog
      context.startActivityAsUser(pairingIntent, UserHandle.CURRENT);
    } else {
      // Put up a notification that leads to the dialog
      intent.setClass(context, BluetoothPairingService.class);
      context.startServiceAsUser(intent, UserHandle.CURRENT);
    }
  }
}

shouldShowDialog 是否弹出配对框
配对框的处理是在 BluetoothPairingDialog.java 中
```

### 3.2 BluetoothPairingDialog.java 中相关代码分析



```
路径:packages\apps\Settings\src\com\android\settings\bluetooth\BluetoothPairingDialog.java
@Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addSystemFlags(SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS);
        Intent intent = getIntent();
        //SPRD:bug#786611 If there is no device, there is no need to show the dialog
        if (intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) == null) {
            finish();
            return;
        }
        mBluetoothPairingController = new BluetoothPairingController(intent, this);
        // build the dialog fragment
        boolean fragmentFound = true;
        // check if the fragment has been preloaded
        BluetoothPairingDialogFragment bluetoothFragment =
            (BluetoothPairingDialogFragment) getSupportFragmentManager().
                    findFragmentByTag(FRAGMENT_TAG);
        // dismiss the fragment if it is already used
        if (bluetoothFragment != null && (bluetoothFragment.isPairingControllerSet()
            || bluetoothFragment.isPairingDialogActivitySet())) {
            bluetoothFragment.dismiss();
            bluetoothFragment = null;
        }
        // build a new fragment if it is null
        if (bluetoothFragment == null) {
            fragmentFound = false;
            bluetoothFragment = new BluetoothPairingDialogFragment();
        }
        bluetoothFragment.setPairingController(mBluetoothPairingController);
        bluetoothFragment.setPairingDialogActivity(this);
        // pass the fragment to the manager when it is created from scratch
        if (!fragmentFound) {
            bluetoothFragment.show(getSupportFragmentManager(), FRAGMENT_TAG);
        }
        /*
         * Leave this registered through pause/resume since we still want to
         * finish the activity in the background if pairing is canceled.
         */
        registerReceiver(mReceiver, new IntentFilter(BluetoothDevice.ACTION_PAIRING_CANCEL));
        registerReceiver(mReceiver, new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED));
        mReceiverRegistered = true;
    }

具体的配对框的UI 界面是在BluetoothPairingDialogFragment中
```

### 3.3 BluetoothPairingDialogFragment中相关代码分析



```
路径:packages\apps\Settings\src\com\android\settings\bluetooth\BluetoothPairingDialogFragment.java
@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (!isPairingControllerSet()) {
            throw new IllegalStateException(
                "Must call setPairingController() before showing dialog");
        }
        if (!isPairingDialogActivitySet()) {
            throw new IllegalStateException(
                "Must call setPairingDialogActivity() before showing dialog");
        }
        mBuilder = new AlertDialog.Builder(getActivity());
        mDialog = setupDialog();
        mDialog.setCanceledOnTouchOutside(false);
        return mDialog;
    }
    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (which == DialogInterface.BUTTON_POSITIVE) {
            mPairingController.onDialogPositiveClick(this);
        } else if (which == DialogInterface.BUTTON_NEGATIVE) {
            mPairingController.onDialogNegativeClick(this);
        }
        mPairingDialogActivity.dismiss();
    }
    /**
     * Creates the appropriate type of dialog and returns it.
     */
    private AlertDialog setupDialog() {
        AlertDialog dialog;
        switch (mPairingController.getDialogType()) {
            case BluetoothPairingController.USER_ENTRY_DIALOG:
                dialog = createUserEntryDialog();
                break;
            case BluetoothPairingController.CONFIRMATION_DIALOG:
                dialog = createConsentDialog();
                break;
            case BluetoothPairingController.DISPLAY_PASSKEY_DIALOG:
                dialog = createDisplayPasskeyOrPinDialog();
                break;
            default:
                dialog = null;
                Log.e(TAG, "Incorrect pairing type received, not showing any dialog");
        }
        return dialog;
    }
 /**
     * Creates a dialog with UI elements that allow the user to confirm a pairing request.
     */
    private AlertDialog createConfirmationDialog() {
        mBuilder.setTitle(getString(R.string.bluetooth_pairing_request,
                mPairingController.getDeviceName()));
        mBuilder.setView(createView());
        mBuilder.setPositiveButton(getString(R.string.bluetooth_pairing_accept), this);
        mBuilder.setNegativeButton(getString(R.string.bluetooth_pairing_decline), this);
        AlertDialog dialog = mBuilder.create();
        return dialog;
    }

    /**
     * Creates a dialog with UI elements that allow the user to consent to a pairing request.
     */
    private AlertDialog createConsentDialog() {
        return createConfirmationDialog();
    }

    /**
     * Creates a custom view for dialogs which need to show users additional information but do
     * not require user input.
     */
    private View createView() {
        View view = getActivity().getLayoutInflater().inflate(R.layout.bluetooth_pin_confirm, null);
        TextView pairingViewCaption = (TextView) view.findViewById(R.id.pairing_caption);
        TextView pairingViewContent = (TextView) view.findViewById(R.id.pairing_subhead);
        TextView messagePairing = (TextView) view.findViewById(R.id.pairing_code_message);
        CheckBox contactSharing = (CheckBox) view.findViewById(
                R.id.phonebook_sharing_message_confirm_pin);
        contactSharing.setText(getString(R.string.bluetooth_pairing_shares_phonebook,
                mPairingController.getDeviceName()));

        contactSharing.setVisibility(
                mPairingController.isProfileReady() ? View.GONE : View.VISIBLE);
        mPairingController.setContactSharingState();
        contactSharing.setChecked(mPairingController.getContactSharingState());
        contactSharing.setOnCheckedChangeListener(mPairingController);

        messagePairing.setVisibility(mPairingController.isDisplayPairingKeyVariant()
                ? View.VISIBLE : View.GONE);
        if (mPairingController.hasPairingContent()) {
            pairingViewCaption.setVisibility(View.VISIBLE);
            pairingViewContent.setVisibility(View.VISIBLE);
            pairingViewContent.setText(mPairingController.getPairingContent());
        }
        return view;
    }

从相关代码可以看出点击配对后执行的是mPairingController.onDialogPositiveClick(this);
接下来看下BluetoothPairingController.java的代码
```

### 3.4 BluetoothPairingController.java的相关代码分析



```
路径:packages\apps\Settings\src\com\android\settings\bluetooth\BluetoothPairingController.java
    @Override
    public void onDialogPositiveClick(BluetoothPairingDialogFragment dialog) {
        if (mPbapAllowed) {
            mDevice.setPhonebookAccessPermission(BluetoothDevice.ACCESS_ALLOWED);
        } else {
            mDevice.setPhonebookAccessPermission(BluetoothDevice.ACCESS_REJECTED);
        }

        if (getDialogType() == USER_ENTRY_DIALOG) {
            onPair(mUserInput);
        } else {
            onPair(null);
        }
    }

 /**
     * handles the necessary communication with the bluetooth device to establish a successful
     * pairing
     *
     * @param passkey - The passkey we will attempt to pair to the device with.
     */
    public void onPair(String passkey) {
        Log.d(TAG, "Pairing dialog accepted");
        switch (mType) {
            case BluetoothDevice.PAIRING_VARIANT_PIN:
            case BluetoothDevice.PAIRING_VARIANT_PIN_16_DIGITS:
                byte[] pinBytes = BluetoothDevice.convertPinToBytes(passkey);
                if (pinBytes == null) {
                    return;
                }
                mDevice.setPin(pinBytes);
                break;

            case BluetoothDevice.PAIRING_VARIANT_PASSKEY:
                int pass = Integer.parseInt(passkey);
                mDevice.setPasskey(pass);
                break;

            case BluetoothDevice.PAIRING_VARIANT_PASSKEY_CONFIRMATION:
            case BluetoothDevice.PAIRING_VARIANT_CONSENT:
                mDevice.setPairingConfirmation(true);
                break;

            case BluetoothDevice.PAIRING_VARIANT_DISPLAY_PASSKEY:
            case BluetoothDevice.PAIRING_VARIANT_DISPLAY_PIN:
                // Do nothing.
                break;

            case BluetoothDevice.PAIRING_VARIANT_OOB_CONSENT:
                mDevice.setRemoteOutOfBandData();
                break;

            default:
                Log.e(TAG, "Incorrect pairing type received");
        }
    }

最终调用onPair(null)实现配对 

所以最终修改方法就是
在BluetoothPairingDialog.java 调用onPair(null)就可以了

@Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addSystemFlags(SYSTEM_FLAG_HIDE_NON_SYSTEM_OVERLAY_WINDOWS);
        Intent intent = getIntent();
        //SPRD:bug#786611 If there is no device, there is no need to show the dialog
        if (intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) == null) {
            finish();
            return;
        }
        mBluetoothPairingController = new BluetoothPairingController(intent, this);

       //add core start 
       + mBluetoothPairingController.onPair(null);
       + finish();
       //add core end

        // build the dialog fragment
        boolean fragmentFound = true;
        // check if the fragment has been preloaded
        BluetoothPairingDialogFragment bluetoothFragment =
            (BluetoothPairingDialogFragment) getSupportFragmentManager().
                    findFragmentByTag(FRAGMENT_TAG);
        // dismiss the fragment if it is already used
        if (bluetoothFragment != null && (bluetoothFragment.isPairingControllerSet()
            || bluetoothFragment.isPairingDialogActivitySet())) {
            bluetoothFragment.dismiss();
            bluetoothFragment = null;
        }
        // build a new fragment if it is null
        if (bluetoothFragment == null) {
            fragmentFound = false;
            bluetoothFragment = new BluetoothPairingDialogFragment();
        }
        bluetoothFragment.setPairingController(mBluetoothPairingController);
        bluetoothFragment.setPairingDialogActivity(this);
        // pass the fragment to the manager when it is created from scratch
        if (!fragmentFound) {
            bluetoothFragment.show(getSupportFragmentManager(), FRAGMENT_TAG);
        }
        /*
         * Leave this registered through pause/resume since we still want to
         * finish the activity in the background if pairing is canceled.
         */
        registerReceiver(mReceiver, new IntentFilter(BluetoothDevice.ACTION_PAIRING_CANCEL));
        registerReceiver(mReceiver, new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED));
        mReceiverRegistered = true;
    }

2.BluetoothPairingController.java的onPair(String passkey)改为public
```



