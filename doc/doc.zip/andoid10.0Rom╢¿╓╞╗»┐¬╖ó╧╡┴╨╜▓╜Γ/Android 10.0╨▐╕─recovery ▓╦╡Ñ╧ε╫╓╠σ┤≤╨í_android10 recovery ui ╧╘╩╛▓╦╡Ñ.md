






在Android 进入recovery模式后，界面会g\_menu\_actions 菜单选项和 提示文字，而这些文字的  
 大小不像上层一样是通过设置属性来表示大小的 而它确是通过字体png图片的大小来计算文字的宽和高的


首选来看build/make/core/Makefile 文件



```
recovery_density := $(strip \
 $(or $(if $(filter $(shell echo $$(($(recovery\_density\_value) >= 560))),1),xxxhdpi),\
       $(if $(filter $(shell echo $$(($(recovery\_density\_value) >= 400))),1),xxhdpi),\
       $(if $(filter $(shell echo $$(($(recovery\_density\_value) >= 280))),1),xhdpi),\
       $(if $(filter $(shell echo $$(($(recovery\_density\_value) >= 200))),1),hdpi,mdpi)))
endif

ifneq (,$(wildcard $(recovery\_resources\_common)-$(recovery\_density)))
recovery_resources_common := $(recovery\_resources\_common)-$(recovery\_density)
else
recovery_resources_common := $(recovery\_resources\_common)-xhdpi
endif

# Select the 18x32 font on high-density devices (xhdpi and up); and the 12x22 font on other devices.
# Note that the font selected here can be overridden for a particular device by putting a font.png
# in its private recovery resources.
ifneq (,$(filter xxxhdpi xxhdpi xhdpi,$(recovery\_density)))
recovery_font := $(call include-path-for, recovery)/fonts/18x32.png
else
recovery_font := $(call include-path-for, recovery)/fonts/12x22.png
endif

```

通过Makefile 我们可以看到 是通过设备的密度来选择字体的大小的


当密度大于280时 就是用的recovery\_font := $(call include-path-for, recovery)/fonts/18x32.png 来设置字体的  
 而路径就在：bootable\recovery\fonts\18x32.png


而具体计算字体的宽高是通过  
 bootable\recovery\minui\graphics.c 来处理这些图片  
 中的



```
int gr_init_font(const char* name, GRFont** dest) {
  GRFont* font = static_cast<GRFont*>(calloc(1, sizeof(*gr_font)));
  if (font == nullptr) {
    return -1;
  }

  int res = res_create_alpha_surface(name, &(font->texture));
  if (res < 0) {
    free(font);
    return res;
  }

  // The font image should be a 96x2 array of character images.  The
  // columns are the printable ASCII characters 0x20 - 0x7f.  The
  // top row is regular text; the bottom row is bold.
  font->char_width = font->texture->width / 96;
  font->char_height = font->texture->height / 2;

  *dest = font;

  return 0;
}

```

通过获取图片的宽来除以96 为字体的宽 图片的高/2为字体的高


所以要修改字体只需要把 18X32.png的图片 通过photoshop工具 重新做张图片 修改长和宽  
 例如：修改成36x64.png 宽设置成36x96 高设置成64x2 即为3456x128的图片  
 然后放在bootable\recovery\fonts\ 下  
 如图:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/9361728c49624f7989ea748d15e59364.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_9,color_FFFFFF,t_70,g_se,x_16#pic_center)


然后Makefile中修改使用这个font图片  
 修改如下:



```
ifneq (,$(filter xxxhdpi xxhdpi xhdpi,$(recovery\_density)))
- recovery_font := $(call include-path-for, recovery)/fonts/18x32.png
+recovery_font := $(call include-path-for, recovery)/fonts/36x64.png
else
recovery_font := $(call include-path-for, recovery)/fonts/12x22.png
endif

```

然后编译即可 发现 recovery 界面字体已经变大了





