






修改系统默认的音量条样式 去掉铃声和设置音量的功能  
 1.去掉铃声和设置音量的功能  
 音量条功能 在SystemUI中VolumeDialogImpl.java进行管理的  
 路径:  
 \frameworks\base\packages\SystemUI\src\com\android\systemui\volume\VolumeDialogImpl.java  
 接下来看源码:



```
private void initDialog() {
        mDialog = new CustomDialog(mContext);

        mConfigurableTexts = new ConfigurableTexts(mContext);
        mHovering = false;
        mShowing = false;
        mWindow = mDialog.getWindow();
        mWindow.requestFeature(Window.FEATURE_NO_TITLE);
        mWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mWindow.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND
                | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR);
        mWindow.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        mWindow.setType(WindowManager.LayoutParams.TYPE_VOLUME_OVERLAY);
        mWindow.setWindowAnimations(com.android.internal.R.style.Animation_Toast);
        WindowManager.LayoutParams lp = mWindow.getAttributes();
        lp.format = PixelFormat.TRANSLUCENT;
        lp.setTitle(VolumeDialogImpl.class.getSimpleName());
        lp.windowAnimations = -1;
        lp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
        mWindow.setAttributes(lp);
        mWindow.setLayout(WRAP_CONTENT, WRAP_CONTENT);

        mDialog.setContentView(R.layout.volume_dialog);
        mDialogView = mDialog.findViewById(R.id.volume_dialog);
        mDialogView.setAlpha(0);
        mDialog.setCanceledOnTouchOutside(true);
        mDialog.setOnShowListener(dialog -> {
            if (!isLandscape()) mDialogView.setTranslationX(mDialogView.getWidth() / 2.0f);
            mDialogView.setAlpha(0);
            mDialogView.animate()
                    .alpha(1)
                    .translationX(0)
                    .setDuration(DIALOG_SHOW_ANIMATION_DURATION)
                    .setInterpolator(new SystemUIInterpolators.LogDecelerateInterpolator())
                    .withEndAction(() -> {
 if (!Prefs.getBoolean(mContext, Prefs.Key.TOUCHED\_RINGER\_TOGGLE, false)) {
                            if (mRingerIcon != null) {
                                mRingerIcon.postOnAnimationDelayed(
                                        getSinglePressFor(mRingerIcon), 1500);
                            }
                        }
                    })
                    .start();
        });

        mDialogView.setOnHoverListener((v, event) -> {
 int action = event.getActionMasked();
 mHovering = (action == MotionEvent.ACTION\_HOVER\_ENTER)
 || (action == MotionEvent.ACTION\_HOVER\_MOVE);
 rescheduleTimeoutH();
 return true;
 });

 mDialogRowsView = mDialog.findViewById(R.id.volume\_dialog\_rows);
 mRinger = mDialog.findViewById(R.id.ringer);
 mRinger.setVisibility(GONE);
 if (mRinger != null) {
 mRingerIcon = mRinger.findViewById(R.id.ringer\_icon);
 mZenIcon = mRinger.findViewById(R.id.dnd\_icon);
 }

 mODICaptionsView = mDialog.findViewById(R.id.odi\_captions);
 if (mODICaptionsView != null) {
 mODICaptionsIcon = mODICaptionsView.findViewById(R.id.odi\_captions\_icon);
 }
 mODICaptionsTooltipViewStub = mDialog.findViewById(R.id.odi\_captions\_tooltip\_stub);
 if (mHasSeenODICaptionsTooltip && mODICaptionsTooltipViewStub != null) {
 mDialogView.removeView(mODICaptionsTooltipViewStub);
 mODICaptionsTooltipViewStub = null;
 }

 mSettingsView = mDialog.findViewById(R.id.settings\_container);
 mSettingsIcon = mDialog.findViewById(R.id.settings);

 if (mRows.isEmpty()) {
            if (!AudioSystem.isSingleVolume(mContext)) {
                addRow(STREAM_ACCESSIBILITY, R.drawable.ic_volume_accessibility,
                        R.drawable.ic_volume_accessibility, true, false);
            }
            addRow(AudioManager.STREAM_MUSIC,
                    R.drawable.ic_volume_media, R.drawable.ic_volume_media_mute, true, true);
            if (!AudioSystem.isSingleVolume(mContext)) {
                /*addRow(AudioManager.STREAM_RING,
                        R.drawable.ic_volume_ringer, R.drawable.ic_volume_ringer_mute, true, false);*/
                addRow(STREAM_ALARM,
                        R.drawable.ic_volume_alarm, R.drawable.ic_volume_alarm_mute, true, false);
                addRow(AudioManager.STREAM_VOICE_CALL,
                        com.android.internal.R.drawable.ic_phone,
                        com.android.internal.R.drawable.ic_phone, false, false);
                addRow(AudioManager.STREAM_BLUETOOTH_SCO,
                        R.drawable.ic_volume_bt_sco, R.drawable.ic_volume_bt_sco, false, false);
                addRow(AudioManager.STREAM_SYSTEM, R.drawable.ic_volume_system,
                        R.drawable.ic_volume_system_mute, false, false);
            }
        } else {
            addExistingRows();
        }

        updateRowsH(getActiveRow());
        initRingerH();
        initSettingsH();
        initODICaptionsH();
    }

```

布局文件为:  
 mDialog.setContentView(R.layout.volume\_dialog);  
 在volume\_dialog.xml中



```
<LinearLayout
        android:id="@+id/volume\_dialog"
        android:minWidth="@dimen/volume\_dialog\_panel\_width"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:gravity="right"
        android:layout_gravity="right"
        android:background="@android:color/transparent"
        android:paddingRight="@dimen/volume\_dialog\_panel\_transparent\_padding\_right"
        android:paddingTop="@dimen/volume\_dialog\_panel\_transparent\_padding"
        android:paddingBottom="@dimen/volume\_dialog\_panel\_transparent\_padding"
        android:paddingLeft="@dimen/volume\_dialog\_panel\_transparent\_padding"
        android:orientation="vertical"
        android:clipToPadding="false">

        <FrameLayout
            android:id="@+id/ringer"
            android:layout_width="@dimen/volume\_dialog\_ringer\_size"
            android:layout_height="@dimen/volume\_dialog\_ringer\_size"
            android:layout_marginBottom="@dimen/volume\_dialog\_spacer"
            android:gravity="right"
            android:layout_gravity="right"
            android:translationZ="@dimen/volume\_dialog\_elevation"
            android:clipToPadding="false">
            <com.android.keyguard.AlphaOptimizedImageButton
                android:id="@+id/ringer\_icon"
                style="@style/VolumeButtons"
                android:background="@drawable/rounded\_ripple"
                android:layout_width="match\_parent"
                android:layout_height="match\_parent"
                android:scaleType="fitCenter"
                android:padding="@dimen/volume\_dialog\_ringer\_icon\_padding"
                android:tint="@color/accent\_tint\_color\_selector"
                android:layout_gravity="center"
                android:soundEffectsEnabled="false" />

            <include layout="@layout/volume\_dnd\_icon"
                     android:layout_width="match\_parent"
                     android:layout_height="wrap\_content"
                     android:layout_marginRight="@dimen/volume\_dialog\_stream\_padding"
                     android:layout_marginTop="6dp"/>
        </FrameLayout>

        <LinearLayout
            android:id="@+id/main"
            android:minWidth="@dimen/volume\_dialog\_panel\_width"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:gravity="right"
            android:layout_gravity="right"
            android:orientation="vertical"
            android:translationZ="@dimen/volume\_dialog\_elevation"
            android:clipChildren="false"
            android:clipToPadding="false"
            android:background="@drawable/rounded\_bg\_full" >
            <LinearLayout
                android:id="@+id/volume\_dialog\_rows"
                android:layout_width="wrap\_content"
                android:layout_height="wrap\_content"
                android:minWidth="@dimen/volume\_dialog\_panel\_width"
                android:gravity="center"
                android:orientation="horizontal"
                android:paddingRight="@dimen/volume\_dialog\_stream\_padding"
                android:paddingLeft="@dimen/volume\_dialog\_stream\_padding">
                    <!-- volume rows added and removed here! :-) -->
            </LinearLayout>
            <FrameLayout
                android:id="@+id/settings\_container"
                android:layout_width="match\_parent"
                android:layout_height="wrap\_content"
                android:background="@drawable/rounded\_bg\_bottom\_background">
                <com.android.keyguard.AlphaOptimizedImageButton
                    android:id="@+id/settings"
                    android:src="@drawable/ic\_tune\_black\_16dp"
                    android:layout_width="@dimen/volume\_dialog\_tap\_target\_size"
                    android:layout_height="@dimen/volume\_dialog\_tap\_target\_size"
                    android:layout_gravity="center"
                    android:contentDescription="@string/accessibility\_volume\_settings"
                    android:background="@drawable/ripple\_drawable\_20dp"
                    android:tint="?android:attr/textColorSecondary"
                    android:soundEffectsEnabled="false" />
            </FrameLayout>
        </LinearLayout>

```

android:id=“@+id/ringer” 为铃声布局 android:id="@+id/settings\_container"为设置音量布局  
 mRinger = mDialog.findViewById(R.id.ringer);  
 mRinger.setVisibility(GONE);  
 mRinger为铃声布局 隐藏掉即可  
 mSettingsView = mDialog.findViewById(R.id.settings\_container);  
 mSettingsView为设置音量布局 隐藏掉即可


2.增加减少音量布局:  
 volume\_dialog\_rows.xml 为此布局



```
<FrameLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:tag="row"
    android:layout_height="wrap\_content"
    android:layout_width="@dimen/volume\_dialog\_panel\_width"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:theme="@style/qs\_theme">

    <LinearLayout
        android:layout_height="wrap\_content"
        android:layout_width="match\_parent"
        android:gravity="center"
        android:layout_gravity="center"
        android:orientation="vertical" >
        <TextView
            android:id="@+id/volume\_row\_header"
            android:layout_width="wrap\_content"
            android:layout_height="wrap\_content"
            android:ellipsize="end"
            android:maxLength="10"
            android:maxLines="1"
            android:visibility="gone"
            android:textColor="?android:attr/colorControlNormal"
            android:textAppearance="@style/TextAppearance.Volume.Header" />
        <FrameLayout
            android:id="@+id/volume\_row\_slider\_frame"
            android:layout_width="match\_parent"
            android:layout_marginTop="@dimen/volume\_dialog\_slider\_margin\_top"
            android:layout_marginBottom="@dimen/volume\_dialog\_slider\_margin\_bottom"
            android:layoutDirection="rtl"
            android:layout_height="@dimen/volume\_dialog\_slider\_height">
            <SeekBar
                android:id="@+id/volume\_row\_slider"
                android:clickable="true"
                android:layout_width="@dimen/volume\_dialog\_slider\_height"
                android:layout_height="match\_parent"
                android:layoutDirection="rtl"
				android:thumb="@null"
                android:layout_gravity="center"
				android:progressDrawable="@drawable/seek\_style"
                android:rotation="90" />
        </FrameLayout>

        <com.android.keyguard.AlphaOptimizedImageButton
            android:id="@+id/volume\_row\_icon"
            style="@style/VolumeButtons"
            android:layout_width="@dimen/volume\_dialog\_tap\_target\_size"
            android:layout_height="@dimen/volume\_dialog\_tap\_target\_size"
            android:background="@drawable/ripple\_drawable\_20dp"
            android:layout_marginBottom="@dimen/volume\_dialog\_row\_margin\_bottom"
            android:tint="@color/accent\_tint\_color\_selector"
            android:soundEffectsEnabled="false" />
    </LinearLayout>

    <include layout="@layout/volume\_dnd\_icon"/>

</FrameLayout>

```

android:id=“@+id/volume\_row\_slider” 为此布局  
 所以修改音量条样式  
 android:thumb=“@null”  
 去掉拖动图标  
 android:progressDrawable=“@drawable/seek\_style”  
 增加新的样式


seek\_style.xml为:



```
<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@android:id/background">
        <shape>
            <solid android:color="#B5B5B5" />
        </shape>
    </item>
    <item android:id="@android:id/progress">
        <clip>
            <shape>
                <solid android:color="#FF6347" />
            </shape>
        </clip>
    </item>
</layer-list>

```

编译SystemUI 验证就可以了





