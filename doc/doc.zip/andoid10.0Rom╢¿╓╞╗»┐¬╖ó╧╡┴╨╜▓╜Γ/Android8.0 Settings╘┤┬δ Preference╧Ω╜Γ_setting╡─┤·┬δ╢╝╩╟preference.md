






Android 设置是每个App必不可小的东西，看似很简单，但是初学不熟悉的很花时间去研究，特别样式兼容方面，以及有自定义设置的需求，下面是对用法做一个总结  
 Preference结构  
 界面结构看下图


界面主要由PrefercenScreen、PreferenceCategory和Preference三个主要部分组成


PrefercenScreen最根的部分;  
 PreferenceCategory是每个设置的分组;  
 Preference是具体到每个设置元素；


XML文件  
 XML结构层级大致如图  
 <android.support.v7.preference.PreferenceScreen  
 xmlns:android=“http://schemas.android.com/apk/res/android”>  
 <android.support.v7.preference.PreferenceCategory  
 android:title=“preference v7”>  
 <android.support.v7.preference.CheckBoxPreference  
 android:defaultValue=“false”  
 android:key=“key\_checkbox”  
 android:summaryOff="@string/theme\_light"  
 android:summaryOn="@string/theme\_dark"  
 android:title=“Checkbox”  
 />  
 </android.support.v7.preference.PreferenceCategory>  
 </android.support.v7.preference.PreferenceScreen>  
 Preference介绍  
 Preference  
 Preference 是所有设置项目的基类，很多属性都从这个类派生出来。  
 它有android.preference.Preference和 android.support.v7.preference.Preference两个部分，大致用法相同，详细请参考文档；


从文档可了解到android.preference.Preference 是针对PreferenceActivity  
 ListView旧款偏好而设计，而android.support.v7.preference.Preference则适合  
 用RecyclerView重新设计的PreferenceFragmentCompat,使用的时候对号入座就可以了;


他们都是内置 SharedPreferences 以及对应的android:key属性来存储数据


关键属性：


android:title，显示的标题;  
 android:summary，标题下面对应的摘要;  
 android:key,存储数据的键值;  
 android:dependency: 这是一个键值，如果设置，必须依赖key这个才可以启用;  
 Preference 用来管理应用程序的偏好设置和保证使用这些的每个应用程序的所有参数 拥有同样的方式和用户体验 并且系统和其他应用程序的UI保持偏一致。


一个应用程序的偏好部分应作为一个独立的活动扩展preferenceactivity类 类中的对象应该是preferencescreen ，preferencescreen包含偏好等元素的布局的根元素 比如checkboxpreference ，EditTextPreference, ListPreference, PreferenceCategory, RingtonePreference.


对于一个给定的偏好设置将自动保存到SharedPreferences ， 拿到SharedPreferences应用实例的很简单getsharedpreferences（）；值的注意的是保存首选项只能由创建的应用程序去操作。  
 安卓给我们提供了一下接口：


Preference.OnPreferenceChangeListener


接口定义一个回调时调用的值Preference由用户改变了,是吗 关于设置和/或持久化。


Preference.OnPreferenceClickListener


接口定义一个回调时被调用Preference是 点击。


PreferenceManager.OnActivityDestroyListener


接口定义一个类时,将调用容器的活动 被摧毁。


PreferenceManager.OnActivityResultListener


接口定义一个类时,将调用容器的活动 接收到一个活动的结果。


PreferenceManager.OnActivityStopListener


接口定义一个类时,将调用容器的活动 是停止了。


也定义了如下api：


CheckBoxPreference


一个Preference提供checkbox小部件 功能。


DialogPreference


一个基类Preference对象 基于对话框的。


EditTextPreference


一个Preference允许字符串 输入。


ListPreference


一个Preference显示条目的列表 一个对话框。


Preference


代表的基本UI构建的偏好 块显示的PreferenceActivity的形式ListView。


Preference.BaseSavedState


一个基类来管理实例的状态Preference。


preferenceactivity


显示了一个层次Preference对象作为 列表,可能跨越多个屏幕。


PreferenceCategory


用于集团Preference对象 并提供一个残疾人标题上面。


PreferenceGroup


一个容器为多个Preference对象。


PreferenceManager


用于帮助创建Preference层次结构 从活动或XML。


PreferenceScreen


代表一个顶级Preference那 是优先的层次结构的根。


RingtonePreference


一个Preference允许用户选择从这些设备上的铃声。


1 Preference 可实现的接口


interfacePreference.OnPreferenceChangeListener（偏好值已更改的用户和改变的时候 调用） 和Preference.OnPreferenceClickListener（偏好设置被点击的时候调用 ）


装载请标明出处：：http://blog.csdn.net/sk719887916


2.Preference元素的通用XML Attributes：  
 android:key ： key：唯一标识，SharedPreferences也将通过此Key值进行数据保存,也可以通过key值获取保存的信息 。


android:defaultValue ： 默认值。 例如，CheckPreference的默认值可为”true”，默认为选中状态。


android:enabled ： 表示该Preference是否可用状态。


android:title ： 每个Preference在PreferenceScreen布局上显示的标题——大标题


android:summary ： 每个Preference在PreferenceScreen布局上显示的标题——小标题(可以没有)


android:persistent： 表示Preference元素所对应的值是否写入sharedPreferen文件中，如果是true，则表示写入；否则，则表示不写入该Preference元素的值。


android:layout： 在一个preferenceactivity的偏好布局 用于填充view


android:dependency： 表示一个Preference(用A表示)的可用状态依赖另外一个Preference(用B表示)。B可用，



```
                                          则A可用；B不可用，则A不可用。

```

android:icon: 偏好图标 对于偏好选择图标必须是一个引用到另一个资源的形式或以packagetypename 主题属性.


android:disableDependentsState： 与android:dependency相反。B可用，则A不可用；B不可用，则A可用。


android:order：表示偏好顺序，对于偏好较低的值的顺序是先点如果不指定默认的排序将字母必须是一个整数，如100，这也可能是一个参考值在含有这类这相当于全局属性资源符号秩序的形式或 形式packagetypename主题属性的一个资源。


android:shouldDisableView：是否被禁用，这种偏好是必须是布尔值true或false 这也可能是一个参考的形式或主题属性packagetypename资源，packagetypename形式包含一个值 相当于全局属性资源符号shoulddisableview相关方法  
 android:selectable：偏好是否是可选的。  
 android:widgetLayout：可以做小部部件部分的布局。  
 android:fragment： 使用时，可以碎片化PreferenceActivity。


3.显示Preference布局结构的方法为：  
 使我们的Activity继承PreferenceActivity，然后在onCreate()方法中通过



```
  addPreferencesFromResource(R.xml.custom_preference) (我们自定义的Preference 布局)。

  怎么样，是不是似曾相识？稍后会用一个Demo来为您详述。

```

常用的方法则包括：



```
          getKey()            setKey()

         getSummary()        setSummary()

         getText()           setText()

       getXXX()代表取得xxx属性的值。

```

4.Preference的跳转：  
 方法一：在配置每个Preference元素节点时，我们可以显示为点击它时所跳转的Intent。点击该Preference，跳转至目标Intent。除非在onPreferenceTreeClick()方法中进行抉择。在xml中配置如下：



```
<pre name="code" class="html"></pre><pre name="code" class="java" style="font-size: 14px; color: rgb(34, 34, 34);">1.<Preference android:key="wifi\_setting" android:title="Wi-Fi设置"  
    android:summary="设置和管理无线接入点" android:dependency="apply\_wifi">  
    <!-- 点击时 自定义一个默认跳转Intent  action指定隐式Intent -->  
    <!-- action指定隐式Intent ; targetPackage和targetClass指定显示Intent-->  
    <intent android:action="com.feixun.action.seemAction"   
        android:targetPackage="com.feixun.qin" android:targetClass="com.feixun.qin.MainActivity" />  
</Preference>  

```

8. android:key 唯一标识符。它对应保存的XML保存的配置文件中的节点的 name属性
9. android:defaultValue 默认值，对应XML中的Value属性的值。


方法二：可以在onPreferenceTreeClick()创建新的intent显示的进行跳转。


接下来，对每个Preference的的独有XML Attributes和方法进行一下总结，使大家有更好的深入理解。



```
   1、EditPreference 

     可输入的设置项

        方法：

           getEditText()  返回的是我们在该控件中输入的文本框值

           getText()     返回的是我们之前sharedPreferen文件保存的值

        

                 

    2、ListPreference

     多选对话框设置项

      XML Attributes：

          android:dialogTitle：弹出控件对话框时显示的标题

          android:entries：类型为array，控件欲显示的文本

          android:entryValues：类型为array，与文本相对应的key-value键值对，value保存至sharedPreference文件

          说明：entries和entryValue属性使用的数组为定义在资源文件arrays.xml的数组名：

      方法：

          CharSequence[]    getEntries()： 返回的是控件显示文本的一个”key”数组，对应于属性android:entries

          CharSequence[]    getEntryValues()：返回的一个”value”数组，对应于属性android: entryValues

          CharSequence      getEntry(): 返回当前选择文本

            String          getValue() :返回当前选中文本选中的value 。

   其实用法和对选对话框一致 只不过做了保存设置。

                              

采用的数组为：      

```

entries：列表中显示的值。为一个数组，通读通过资源文件进行设置。


entryValues：列表中实际保存的值，也entries对应。为一个数组，通读通过资源文件进行设置。以下代码显示的是arrays.xml文件中内容：

 春节 元旦 元宵 001 002 003 
3 CheckBoxPreference  
 可点击的设置项


4 dialogPreference



```
弹出一个对话框 用户选择确定和取消 

```

重点：分析Preference事件



```
  以下摘自网络：

```



---


★在PreferenceActivity方法中，一个比较重要的监听点击事件方法为：



```
     public boolean onPreferenceTreeClick (PreferenceScreen preferenceScreen, Preference preference)

                       说 明 ： 当Preference控件被点击时，触发该方法。

       参数说明： preference 点击的对象。

       返回值：   true  代表点击事件已成功捕捉，无须执行默认动作或者返回上层调用链。 例如，不跳转至默认Intent。

             false 代表执行默认动作并且返回上层调用链。例如，跳转至默认Intent。

  在我们继承PreferenceActivity的Activity可以重写该方法，来完成我们对Preference事件的捕捉。



 相信通过前面的介绍，你一定知道了如何使用了Preference家族并且对其触发方法。下面我们抛出另外两枚炸弹——

```

Preference相关的两个重要监听接口。


★ Preference.OnPreferenceChangeListener 该监听器的一个重要方法如下：



```
    boolean onPreferenceChange(Preference preference,Object objValue)

         说明：  当Preference的元素值发送改变时，触发该事件。

         返回值：true  代表将新值写入sharedPreference文件中。

                 false 则不将新值写入sharedPreference文件

```

★ Preference.OnPreferenceClickListener 该监听器的一个重要方法如下：



```
     public booleanonPreferenceClick(Preference preference)

         说明：当点击控件时触发发生，可以做相应操作。

                         

那么当一个Preference控件实现这两个接口时，当被点击或者值发生改变时，触发方法是如何执行的呢?事实上，

```

它的触发规则如下：



```
  1 先调用onPreferenceClick()方法，如果该方法返回true，则不再调用onPreferenceTreeClick方法 ；

   如果onPreferenceClick方法返回false，则继续调用onPreferenceTreeClick方法。

  2 onPreferenceChange的方法独立与其他两种方法的运行。也就是说，它总是会运行。

```

补充：点击某个Preference控件后，会先回调onPreferenceChange()方法，即是否保存值，然后再回调onPreferenceClick以及onPreferenceTreeClick()方法，因此在onPreferenceClick/onPreferenceTreeClick


方法中我们得到的控件值就是最新的Preference控件值。


那么，开始我们的实战之旅吧！ 下面给您最火热的战场。



```
1，新建我们的preference.xml文件。

     ① 在res文件夹下，新建xml文件夹。

     ② 在新建的xml文件夹下，新建Android XML File。命名为mypeference.xml 。类型选择为Preference。

     ③ 打开我们的mypeference.xml，视图选择Structure。可以手动配置我们的布局文件。可选的Preference空间如下：

```

导出的xml文件：yourpageName"\_prefenrences.xml



```
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
<boolean name="Apply\_wireless" value="false" />
<boolean name="apply\_fly" value="true" />
<boolean name="apply\_bluetooth" value="true" />
<string name="number\_edit2">123@baidu.com</string>
<boolean name="apply\_wifi" value="true" />
<boolean name="apply\_gps" value="true" />
<string name="number\_edit">android.widget.EditText@41a45c00</string>
</map>

```



---


二、PreferenceFragment  
 PreferenceFragment可以在一屏幕放上多个SharedPreferences片段。实现多屏结构显示 ，


用于显示层次结构的偏好对象列表 这些列表的选项将自动保存到SharedPreferences作为与用户交互以检索实例，在该片段SharedPreferences偏好的层次结构用默认的 sharedpreferences去拿值。


此外所示的偏好将遵循系统偏好视觉风格很容易创建一个层次结构鲜明的偏好，可以显示在多个屏幕上通过XML配置，由于这些原因，建议使用此片段作为一个父类的处理SharedPreferences。  
 PreferenceFragment偏好层次可以以多种方式形成。  
 @ 从XML文件中指定的层次结构  
 @ 从不同的活动，可以指定自己的喜好 通过 XML文件的Activity meta-data中。  
 @从一个对象层次结构植根于preferencescreen.


使用addpreferences 加入要展现的xml, xml可以给根元素添加一个子元素，显示一个充满屏幕的preferencescreen ，其xml可以这样写。


代码示例：



```
<PreferenceScreen
        xmlns:android="http://schemas.android.com/apk/res/android">
 
    <PreferenceCategory
            android:title="显示一排偏好">
 
        <CheckBoxPreference
                android:key="checkbox\_preference"
                android:title="开关"
                android:summary="@string/summary\_checkbox\_preference" />
 
    </PreferenceCategory>
 
    <PreferenceCategory
            android:title="这是对画框偏好">
 
        <EditTextPreference
                android:key="edittext\_preference"
                android:title="@string/title\_edittext\_preference"
                android:summary="@string/summary\_edittext\_preference"
                android:dialogTitle="@string/dialog\_title\_edittext\_preference" />
 
        <ListPreference
                android:key="list\_preference"
                android:title="@string/title\_list\_preference"
                android:summary="@string/summary\_list\_preference"
                android:entries="@array/entries\_list\_preference"
                android:entryValues="@array/entryvalues\_list\_preference"
                android:dialogTitle="@string/dialog\_title\_list\_preference" />
 
    </PreferenceCategory>
 
    <PreferenceCategory
            android:title="@string/launch\_preferences">

```


```
    <!--这个标签作为一个屏幕preferencescreen打破类似于分页符在字处理像其他偏好类型我们分配一个关键在这里能够很好的保存和恢复它的实例的状态. 就是所谓的同属一个一样的类别<pre name="code" class="java" style="color: rgb(34, 34, 34); font-size: 14px; line-height: 19px;"><span style="font-family: Roboto, sans-serif;">--></span>

```


```
<PreferenceScreen android:key="screen\_preference" android:title="@string/title\_screen\_preference" android:summary="@string/summary\_screen\_preference"> <!-- 你可以定义更多的Preference，将在下一个屏幕上显示. 点击的时候这个类别会充满屏幕 -->
<CheckBoxPreference android:key="next\_screen\_checkbox\_preference" android:title="@string/title\_next\_screen\_toggle\_preference" android:summary="@string/summary\_next\_screen\_toggle\_preference" /> </PreferenceScreen> <PreferenceScreen android:title="@string/title\_intent\_preference" android:summary="@string/summary\_intent\_preference"> <intent android:action="android.intent.action.VIEW" android:data="http://www.android.com" /> </PreferenceScreen> </PreferenceCategory> <PreferenceCategory android:title="@string/preference\_attributes">
    <!-- 可以定义一个子sp 包括自己视觉风格和主题的  以下俩个子选项属于同一个类别-->
<CheckBoxPreference android:key="parent\_checkbox\_preference" android:title="@string/title\_parent\_preference" android:summary="@string/summary\_parent\_preference" /> <CheckBoxPreference android:key="child\_checkbox\_preference" android:dependency="parent\_checkbox\_preference" android:layout="?android:attr/preferenceLayoutChild" android:title="@string/title\_child\_preference" android:summary="@string/summary\_child\_preference" /> </PreferenceCategory></PreferenceScreen>

```

具体显示如图所示：


java 代码可以这样写;



```
public static class PrefsFragment extends PreferenceFragment {
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
 
        // 加载布局
        addPreferencesFromResource(R.xml.preferences);
    }
}

```

包含如下几个方法：  
 1 要指定添加一个意图可以使用:


addPreferencesFromResource (int preferencesResId)


2 每个意图可以指定清单中的元数据通过Key来获取子Preference


Preference findPreference (CharSequence key)


3 获取根preferencescreen：  
 PreferenceScreen getPreferenceScreen ()


4 设置一个满屏的Preference  
 setPreferenceScreen (PreferenceScreen preferenceScreen)  
 其他生命会周期和activty的一模一样不做细说  
 3 PreferenceGroup


一种Preference的父类，如preferencecategory， preferencescreen 做基类容器。构造方法有以下三种，具体请看viewgroup的源代码 举一反三，这里不做细说


public PreferenceGroup (Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes)  
 Added in API level 21  
 public PreferenceGroup (Context context, AttributeSet attrs, int defStyleAttr)  
 Added in API level 1  
 public PreferenceGroup (Context context, AttributeSet attrs)


4 RingtonePreference



```
作为铃声设置，（调用系统的铃声设置） 
          android:ringtoneType：响铃的铃声类型，主要有：ringtone(音乐)、notification(通知)、alarm(闹铃)（以后楼主为详细介绍alarm类）

                                  、all(所有可用声 音类型)。

           android:showDefault ：默认铃声，可以使用系统(布尔值---true,false)的或者自定义的铃声

           android:showSilent  ：指定铃声是否为静音。指定铃声包括系统默认铃声或者自定义的铃声

```

5 SwitchPreference



```
  类似左右开关的设置项，可以作为一个滑动开关 

```

6 TwoStatePreference


有两个可选状态偏好共同基类 和SharedPreferences布尔值和可能相关的偏好，enabled 和disabled基于当前选中的状态来





