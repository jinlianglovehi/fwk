






在原生的下拉状态栏时间格式为 某月某日周几 这样的格式 客户需要修改为年月日周几 某时某分这种格式  
 这就需要修改 显示时间的格式 在更新时间时 按照这个格式更新就可以了


首选来看 时间控件的布局文件quick\_qs\_status\_icons.xml  
 路径: frameworks\base\packages\SystemUI\res\layout\quick\_qs\_status\_icons.xml



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2017 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:id="@+id/quick\_qs\_status\_icons"
    android:layout_width="match\_parent"
    android:layout_height="wrap\_content"
    android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
    android:paddingBottom="@dimen/qs\_header\_bottom\_padding"
    android:paddingStart="@dimen/status\_bar\_padding\_start"
    android:paddingEnd="@dimen/status\_bar\_padding\_end"
    android:layout_below="@id/quick\_status\_bar\_system\_icons"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:minHeight="20dp"
    android:clickable="false"
    android:focusable="true"
    android:theme="@style/QSHeaderTheme">

    <com.android.systemui.statusbar.policy.DateView
        android:id="@+id/date"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="start|center\_vertical"
        android:gravity="center\_vertical"
        android:singleLine="true"
        android:textAppearance="@style/TextAppearance.QS.Status"
        systemui:datePattern="@string/abbrev\_wday\_month\_day\_no\_year\_alarm" />

    <com.android.systemui.statusbar.phone.StatusIconContainer
        android:id="@+id/statusIcons"
        android:layout_width="0dp"
        android:layout_height="match\_parent"
        android:layout_weight="1"
        android:paddingEnd="@dimen/signal\_cluster\_battery\_padding" />

    <com.android.systemui.BatteryMeterView
        android:id="@+id/batteryRemainingIcon"
        android:layout_height="match\_parent"
        android:layout_width="wrap\_content"
        systemui:textAppearance="@style/TextAppearance.QS.Status"
        android:paddingEnd="2dp" />

</LinearLayout>

```

在xml文件中 com.android.systemui.statusbar.policy.DateView 就是显示时间的控件  
 而 systemui:datePattern=“@string/abbrev\_wday\_month\_day\_no\_year\_alarm” 就是显示时间的格式  
 而他定义在donottranslate.xml  
 路径:frameworks\base\packages\SystemUI\res-keyguard\values\donottranslate.xml



```
<resources xmlns:xliff="urn:oasis:names:tc:xliff:document:1.2">
    <!-- Skeleton string format for displaying the date. -->
    <string name="abbrev\_wday\_month\_day\_no\_year">EEEEMMMMd</string>

    <!-- Skeleton string format for displaying the date when an alarm is set. -->
    <string name="abbrev\_wday\_month\_day\_no\_year\_alarm">eeeMMMMd</string>

    <!-- Skeleton string format for displaying the time in 12-hour format. -->
    <string name="clock\_12hr\_format">hm</string>

    <!-- Skeleton string format for displaying the time in 24-hour format. -->
    <string name="clock\_24hr\_format">Hm</string>
</resources>

```

修改时间格式为:



```
 <string name="abbrev\_wday\_month\_day\_no\_year\_alarm">YYYYeeeMMMMd HH:mm</string>

```

接下来看更新时间DateView.java的相关源码



```
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\policy\DateView.java
private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (Intent.ACTION_TIME_TICK.equals(action)
                    || Intent.ACTION_TIME_CHANGED.equals(action)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                    || Intent.ACTION_LOCALE_CHANGED.equals(action)) {
                if (Intent.ACTION_LOCALE_CHANGED.equals(action)
                        || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
                    // need to get a fresh date format
                    getHandler().post(() -> mDateFormat = null);
 }
 getHandler().post(() -> updateClock());
            }
        }
    };

    public DateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.DateView,
                0, 0);

        try {
            mDatePattern = a.getString(R.styleable.DateView_datePattern);
        } finally {
            a.recycle();
        }
        if (mDatePattern == null) {
            mDatePattern = getContext().getString(R.string.abbrev_wday_month_day_no_year_alarm);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_TIME_TICK);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        filter.addAction(Intent.ACTION_LOCALE_CHANGED);
        getContext().registerReceiver(mIntentReceiver, filter, null,
                Dependency.get(Dependency.TIME_TICK_HANDLER));

        updateClock();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mDateFormat = null; // reload the locale next time
        getContext().unregisterReceiver(mIntentReceiver);
    }

    protected void updateClock() {
        if (mDateFormat == null) {
            final Locale l = Locale.getDefault();
            DateFormat format = DateFormat.getInstanceForSkeleton(mDatePattern, l);
            format.setContext(DisplayContext.CAPITALIZATION_FOR_STANDALONE);
            mDateFormat = format;
        }

        mCurrentTime.setTime(System.currentTimeMillis());

        final String text = mDateFormat.format(mCurrentTime);
        if (!text.equals(mLastText)) {
            setText(text);
            mLastText = text;
        }
    }

```

在updateClock()的时间格式是由mDatePattern来决定的 mDatePattern是在构造方法中定义的  
 所以修改mDatePattern 为:



```
if (mDatePattern == null) {
 -   mDatePattern = getContext().getString(R.string.system_ui_date_pattern);
 +   mDatePattern = getContext().getString(R.string.abbrev_wday_month_day_no_year_alarm);
}

```

经过这样修改后 显示时间格式就会改变了





