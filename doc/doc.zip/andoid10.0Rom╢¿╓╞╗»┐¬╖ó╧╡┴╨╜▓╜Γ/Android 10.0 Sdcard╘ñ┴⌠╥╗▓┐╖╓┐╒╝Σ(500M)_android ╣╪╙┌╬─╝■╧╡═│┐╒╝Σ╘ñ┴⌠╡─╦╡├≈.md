






### 1.概述


在10.0的系统产品开发中，由于产品是低配置，其本身的内置sdcard的空间，本身就不大，所以必须预留出一部分，来缓存一些数据，由于产品需求，所以由于产品有这需求，所以就来开发完成这个功能了


### 2.Sdcard预留一部分空间(500M)的核心类



```
system\core\sdcard\sdcard.cpp

```

### 3.Sdcard预留一部分空间(500M)核心功能分析和实现


系统/system/bin/sdcard守护进程，使用FUSE实现类FAT格式SD卡文件系统的模拟，也就是我们经常说的内置SD卡,  
 对于系统sdcard的相关容量的处理部分和功能分析部分，都是在sdcard.cpp  
 而关于Sdcard 挂载部分的代码源于System下的sdcard.cpp  
 接下来看Sdcard.cpp的相关源码  
 路径为:system\core\sdcard\sdcard.cpp



```
static bool sdcardfs_setup(const std::string& source_path, const std::string& dest_path,
                           uid_t fsuid, gid_t fsgid, bool multi_user, userid_t userid, gid_t gid,
                           mode_t mask, bool derive_gid, bool default_normal, bool unshared_obb,
                           bool use_esdfs) {
    // Add new options at the end of the vector.
    std::vector<std::string> new_opts_list;
    if (multi_user) new_opts_list.push_back("multiuser,");
    if (derive_gid) new_opts_list.push_back("derive\_gid,");
    if (default_normal) new_opts_list.push_back("default\_normal,");
    if (unshared_obb) new_opts_list.push_back("unshared\_obb,");
    // Try several attempts, each time with one less option, to gracefully
    // handle older kernels that aren't updated yet.
    for (int i = 0; i <= new_opts_list.size(); ++i) {
        std::string new_opts;
        for (int j = 0; j < new_opts_list.size() - i; ++j) {
            new_opts += new_opts_list[j];
        }

        auto opts = android::base::StringPrintf("fsuid=%d,fsgid=%d,%smask=%d,userid=%d,gid=%d,reserved\_mb=%d",
                                                fsuid, fsgid, new_opts.c_str(), mask, userid, gid ,SDCARDFS_RESERVED_MB);
        if (mount(source_path.c_str(), dest_path.c_str(), use_esdfs ? "esdfs" : "sdcardfs",
                  MS_NOSUID | MS_NODEV | MS_NOEXEC | MS_NOATIME, opts.c_str()) == -1) {
            PLOG(WARNING) << "Failed to mount sdcardfs with options " << opts;
        } else {
            return true;
        }
    }

    return false;
}

static bool sdcardfs_setup_bind_remount(const std::string& source_path, const std::string& dest_path,
                                        gid_t gid, mode_t mask) {
    std::string opts = android::base::StringPrintf("mask=%d,gid=%d", mask, gid);

    if (mount(source_path.c_str(), dest_path.c_str(), nullptr,
            MS_BIND, nullptr) != 0) {
        PLOG(ERROR) << "failed to bind mount sdcardfs filesystem";
        return false;
    }

    if (mount(source_path.c_str(), dest_path.c_str(), "none",
            MS_REMOUNT | MS_NOSUID | MS_NODEV | MS_NOEXEC | MS_NOATIME, opts.c_str()) != 0) {
        PLOG(ERROR) << "failed to mount sdcardfs filesystem";
        if (umount2(dest_path.c_str(), MNT_DETACH))
            PLOG(WARNING) << "Failed to unmount bind";
        return false;
    }

    return true;
}

static void run_sdcardfs(const std::string& source_path, const std::string& label, uid_t uid,
                         gid_t gid, userid_t userid, bool multi_user, bool full_write,
                         bool derive_gid, bool default_normal, bool unshared_obb, bool use_esdfs) {
    std::string dest_path_default = "/mnt/runtime/default/" + label;
    std::string dest_path_read = "/mnt/runtime/read/" + label;
    std::string dest_path_write = "/mnt/runtime/write/" + label;
    std::string dest_path_full = "/mnt/runtime/full/" + label;

    umask(0);
    if (multi_user) {
        // Multi-user storage is fully isolated per user, so "other"
        // permissions are completely masked off.
        if (!sdcardfs_setup(source_path, dest_path_default, uid, gid, multi_user, userid,
                            AID_SDCARD_RW, 0006, derive_gid, default_normal, unshared_obb,
                            use_esdfs) ||
            !sdcardfs_setup_secondary(dest_path_default, source_path, dest_path_read, uid, gid,
                                      multi_user, userid, AID_EVERYBODY, 0027, derive_gid,
                                      default_normal, unshared_obb, use_esdfs) ||
            !sdcardfs_setup_secondary(dest_path_default, source_path, dest_path_write, uid, gid,
                                      multi_user, userid, AID_EVERYBODY, full_write ? 0007 : 0027,
                                      derive_gid, default_normal, unshared_obb, use_esdfs) ||
            !sdcardfs_setup_secondary(dest_path_default, source_path, dest_path_full, uid, gid,
                                      multi_user, userid, AID_EVERYBODY, 0007, derive_gid,
                                      default_normal, unshared_obb, use_esdfs)) {
            LOG(FATAL) << "failed to sdcardfs\_setup";
        }
    } else {
        // Physical storage is readable by all users on device, but
        // the Android directories are masked off to a single user
        // deep inside attr_from_stat().
        if (!sdcardfs_setup(source_path, dest_path_default, uid, gid, multi_user, userid,
                            AID_SDCARD_RW, 0006, derive_gid, default_normal, unshared_obb,
                            use_esdfs) ||
            !sdcardfs_setup_secondary(dest_path_default, source_path, dest_path_read, uid, gid,
                                      multi_user, userid, AID_EVERYBODY, full_write ? 0027 : 0022,
                                      derive_gid, default_normal, unshared_obb, use_esdfs) ||
            !sdcardfs_setup_secondary(dest_path_default, source_path, dest_path_write, uid, gid,
                                      multi_user, userid, AID_EVERYBODY, full_write ? 0007 : 0022,
                                      derive_gid, default_normal, unshared_obb, use_esdfs) ||
            !sdcardfs_setup_secondary(dest_path_default, source_path, dest_path_full, uid, gid,
                                      multi_user, userid, AID_EVERYBODY, 0007, derive_gid,
                                      default_normal, unshared_obb, use_esdfs)) {
            LOG(FATAL) << "failed to sdcardfs\_setup";
        }
    }

    // Will abort if priv-dropping fails.
    drop_privs(uid, gid);

    if (multi_user) {
        std::string obb_path = source_path + "/obb";
        fs_prepare_dir(obb_path.c_str(), 0775, uid, gid);
    }

    exit(0);
}

```

通过上述sdcard.cpp的源码分析，可知在sdcard.cpp的main()中就开始调用run\_sdcardfs()当挂载sdcard时 运行的方法，sdcardfs\_setup\_bind\_remount()绑定remount() sdcardfs\_setup() sdcard设置  
 所以 修改预留空间就在这里即可



```
+ #define SDCARDFS\_RESERVED\_MB 500
static bool sdcardfs_setup(const std::string& source_path, const std::string& dest_path,
                           uid_t fsuid, gid_t fsgid, bool multi_user, userid_t userid, gid_t gid,
                           mode_t mask, bool derive_gid, bool default_normal, bool unshared_obb,
                           bool use_esdfs) {
    // Add new options at the end of the vector.
    std::vector<std::string> new_opts_list;
    if (multi_user) new_opts_list.push_back("multiuser,");
    if (derive_gid) new_opts_list.push_back("derive\_gid,");
    if (default_normal) new_opts_list.push_back("default\_normal,");
    if (unshared_obb) new_opts_list.push_back("unshared\_obb,");
    // Try several attempts, each time with one less option, to gracefully
    // handle older kernels that aren't updated yet.
    for (int i = 0; i <= new_opts_list.size(); ++i) {
        std::string new_opts;
        for (int j = 0; j < new_opts_list.size() - i; ++j) {
            new_opts += new_opts_list[j];
        }

    -    auto opts = android::base::StringPrintf("fsuid=%d,fsgid=%d,%smask=%d,userid=%d,gid=%d",
    -                                             fsuid, fsgid, new_opts.c_str(), mask, userid, gid);
    +    auto opts = android::base::StringPrintf("fsuid=%d,fsgid=%d,%smask=%d,userid=%d,gid=%d,reserved\_mb=%d",
    +                                             fsuid, fsgid, new_opts.c_str(), mask, userid, gid ,SDCARDFS_RESERVED_MB);
        if (mount(source_path.c_str(), dest_path.c_str(), use_esdfs ? "esdfs" : "sdcardfs",
                  MS_NOSUID | MS_NODEV | MS_NOEXEC | MS_NOATIME, opts.c_str()) == -1) {
            PLOG(WARNING) << "Failed to mount sdcardfs with options " << opts;
        } else {
            return true;
        }
    }

    return false;
}

```

通过上述sdcardfs\_setup的方法中设置sdcard的空间大小，可以在auto opts中预留一部分空间作为备用空间达到功能需求





