






### 1.概述


在10.0的box版本的设备中，系统设置有Settings和TvSettings，这款产品用的是TvSettings 但是发现用遥控器的Home键 点击HOME键时 无反应退不到Launcher桌面或者 input keyevent 3命令模拟Home键时，还是无响应退不到桌面，TvSettings没有退出 回到Launcher 这就需要看keycode Home事件是否由底层驱动反馈到上层应用，然后查询问题所在


### 2.问题分析


1.adb shell getevent 发现点击home 键时 有事件上报可以查到相关的信息  
 2.想办法监听在TvSettings的onKeyDown事件 看能不能监听到Home事件、  
 但是发现始终监听不到Home键 对于Home按键消息的处理，既不能通过onKeyDown、onKeyUp接收到  
 在每次点击Home按键时都会发出一个action为Intent.ACTION\_CLOSE\_SYSTEM\_DIALOGS的广播，它是关闭系统Dialog的广播，我们可以通过注册它来监听Home按键消息  
 3.在TvSettings中监听Intent.ACTION\_CLOSE\_SYSTEM\_DIALOGS 广播 当intent.getStringExtra(“reason”)  
 的值为homekey时就表示是home键，收到Home消息时就finish掉窗口回到桌面


### 3.home键不响应核心代码



```
xref: /packages/apps/TvSettings/Settings/src/com/android/tv/settings/TvSettingsActivity.java

```

首先来看下TvSettingsActivity.java的源码，它是MainSettings.java的父类，  
 而所有一级菜单Fragement都是在MainSettings中实例化的



```

public class MainSettings extends TvSettingsActivity {
  
      @Override
      protected Fragment createSettingsFragment() {
          return FeatureFactory.getFactory(this).getSettingsFragmentProvider()
              .newSettingsFragment(MainFragment.class.getName(), null);
      }
  }

```

从代码中可以看出其实主页面是TvSettingsActivity.java 所以在这里面做监听Home广播比较  
 合适，监听到广播处理finish就可以了



```



public abstract class TvSettingsActivity extends Activity {
    private static final String TAG = "TvSettingsActivity";

    private static final String SETTINGS_FRAGMENT_TAG =
            "com.android.tv.settings.MainSettings.SETTINGS\_FRAGMENT";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {

            final Fragment fragment = createSettingsFragment();
            if (fragment == null) {
                return;
            }
            if (FeatureFactory.getFactory(this).isTwoPanelLayout()) {
                getFragmentManager().beginTransaction()
                        .setCustomAnimations(android.R.animator.fade_in,
                                android.R.animator.fade_out)
                        .add(android.R.id.content, fragment, SETTINGS_FRAGMENT_TAG)
                        .commitNow();
                return;
            }

            final ViewGroup root = findViewById(android.R.id.content);
            root.getViewTreeObserver().addOnPreDrawListener(
                    new ViewTreeObserver.OnPreDrawListener() {

                    }
            @Override
            public boolean onPreDraw () {
                root.getViewTreeObserver().removeOnPreDrawListener(this);
                final Scene scene = new Scene(root);
                scene.setEnterAction(() -> {
 if (getFragmentManager().isStateSaved()
 || getFragmentManager().isDestroyed()) {
                        Log.d(TAG, "Got torn down before adding fragment");
                        return;
                    }
                    getFragmentManager().beginTransaction()
                            .add(android.R.id.content, fragment,
                                    SETTINGS_FRAGMENT_TAG)
                            .commitNow();
                });

                final Slide slide = new Slide(Gravity.END);
                slide.setSlideFraction(
                        getResources().getDimension(R.dimen.lb_settings_pane_width)
                                / root.getWidth());
                TransitionManager.go(scene, slide);

                // Skip the current draw, there's nothing in it
                return false;
            }
        });
    }
}

@Override
public void finish() {
    final Fragment fragment = getFragmentManager().findFragmentByTag(SETTINGS_FRAGMENT_TAG);
    if (FeatureFactory.getFactory(this).isTwoPanelLayout()) {
        super.finish();
        return;
    }
    if (isResumed() && fragment != null) {
        final ViewGroup root = findViewById(android.R.id.content);
        final Scene scene = new Scene(root);
        scene.setEnterAction(() -> getFragmentManager().beginTransaction().remove(fragment)
 .commitNow());
        final Slide slide = new Slide(Gravity.END);
        slide.setSlideFraction(
                getResources().getDimension(R.dimen.lb_settings_pane_width) / root.getWidth());
        slide.addListener(new Transition.TransitionListener() {
            @Override
            public void onTransitionStart(Transition transition) {
                getWindow().setDimAmount(0);

            }

            @Override
            public void onTransitionEnd(Transition transition) {
                transition.removeListener(this);
                TvSettingsActivity.super.finish();

            }

            @Override
            public void onTransitionCancel(Transition transition) {

            }

            @Override
            public void onTransitionPause(Transition transition) {

            }

            @Override
            public void onTransitionResume(Transition transition) {

            }

        });
        TransitionManager.go(scene, slide);

    } else {
        super.finish();
    }
}

```

经过相关的监听home键的方法终于找到第三种方法可用  
 具体修改为:



```
public abstract class TvSettingsActivity extends Activity {
    private static final String TAG = "TvSettingsActivity";

    private static final String SETTINGS_FRAGMENT_TAG =
            "com.android.tv.settings.MainSettings.SETTINGS\_FRAGMENT";
    + private HomeWatcherReceiver mHomeKeyReceiver = null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {

            final Fragment fragment = createSettingsFragment();
            if (fragment == null) {
                return;
            }
            if (FeatureFactory.getFactory(this).isTwoPanelLayout()) {
                getFragmentManager().beginTransaction()
                        .setCustomAnimations(android.R.animator.fade_in,
                                android.R.animator.fade_out)
                        .add(android.R.id.content, fragment, SETTINGS_FRAGMENT_TAG)
                        .commitNow();
                return;
            }

            final ViewGroup root = findViewById(android.R.id.content);
            root.getViewTreeObserver().addOnPreDrawListener(
                    new ViewTreeObserver.OnPreDrawListener() {

                    }
            @Override
            public boolean onPreDraw () {
                root.getViewTreeObserver().removeOnPreDrawListener(this);
                final Scene scene = new Scene(root);
                scene.setEnterAction(() -> {
 if (getFragmentManager().isStateSaved()
 || getFragmentManager().isDestroyed()) {
                        Log.d(TAG, "Got torn down before adding fragment");
                        return;
                    }
                    getFragmentManager().beginTransaction()
                            .add(android.R.id.content, fragment,
                                    SETTINGS_FRAGMENT_TAG)
                            .commitNow();
                });

                final Slide slide = new Slide(Gravity.END);
                slide.setSlideFraction(
                        getResources().getDimension(R.dimen.lb_settings_pane_width)
                                / root.getWidth());
                TransitionManager.go(scene, slide);

                // Skip the current draw, there's nothing in it
                return false;
            }
        });

    // add code start
    mHomeKeyReceiver = new HomeWatcherReceiver();
    final IntentFilter homeFilter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);

    registerReceiver(mHomeKeyReceiver, homeFilter);
    // add code end
    
    }
}

public class HomeWatcherReceiver extends BroadcastReceiver {
    private static final String LOG_TAG = "HomeWatcherReceiver";
    private static final String SYSTEM_DIALOG_REASON_KEY = "reason";
    private static final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.i(LOG_TAG, "onReceive: action: " + action);
        if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
            // android.intent.action.CLOSE_SYSTEM_DIALOGS
            String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
            Log.i(LOG_TAG, "reason: " + reason);

            if (SYSTEM_DIALOG_REASON_HOME_KEY.equals(reason)) {
                // 短按Home键 当home键时，finish掉TvSettingsActivity就可以了 这样就退出了TvSettings了
                Log.e(LOG_TAG, "homekey");
                finish();

            }
            
        }
    }
}

@Override
public void finish() {
   + unregisterReceiver(mHomeKeyReceiver);
    final Fragment fragment = getFragmentManager().findFragmentByTag(SETTINGS_FRAGMENT_TAG);
    if (FeatureFactory.getFactory(this).isTwoPanelLayout()) {
        super.finish();
        return;
    }
    if (isResumed() && fragment != null) {
        final ViewGroup root = findViewById(android.R.id.content);
        final Scene scene = new Scene(root);
        scene.setEnterAction(() -> getFragmentManager().beginTransaction().remove(fragment)
 .commitNow());
        final Slide slide = new Slide(Gravity.END);
        slide.setSlideFraction(
                getResources().getDimension(R.dimen.lb_settings_pane_width) / root.getWidth());
        slide.addListener(new Transition.TransitionListener() {
            @Override
            public void onTransitionStart(Transition transition) {
                getWindow().setDimAmount(0);

            }

            @Override
            public void onTransitionEnd(Transition transition) {
                transition.removeListener(this);
                TvSettingsActivity.super.finish();

            }

            @Override
            public void onTransitionCancel(Transition transition) {

            }

            @Override
            public void onTransitionPause(Transition transition) {

            }

            @Override
            public void onTransitionResume(Transition transition) {

            }

        });
        TransitionManager.go(scene, slide);

    } else {
        super.finish();
    }
}

```




