



## 1.前言


在10.0的系统定制化开发中，在关于MTK平台的产品中，系统默认的充电动画是竖屏显示的，但是在像平板的产品中竖屏动画肯定不符合规范， 所以需要在平板TV产品中，充电动画同时也是需要修改为横屏显示的，接下来就来分析下充电动画的相关绘制流程，然后实现功能


## 2.MTK平台关机充电动画横屏显示修改的核心类



```
vendor\mediatek\proprietary\external\libshowlogo\charging_animation.cpp
```

## 3.MTK平台关机充电动画横屏显示修改的核心功能分析和实现


在系统中开机和关机流程都是非常重要的模块，这些流程都是相对来说比较复杂的流程 在系统正常开机流程中，长按按开机键，后然后开始系统的开机流程 可大致分成三部分 （1）、OS\_level：UBOOT、kenrel、init这三步完成系统启动； （2）、Android\_level：这部分完成android部的初始化； （3）、Home Screen：这部分就是我们看到的launcher部分。 这三部分也是在开机中非常重要的核心流程，接下来看下关机充电的相关逻辑流程 插入DC，charger IC从硬件上唤醒系统，相当于长按开机键开机。 DC插入，其实相当于关机状态下“按开机键”开机。第一步要走UBOOT、kernel 、android init这一流程 如果能过寄存器判断是DC插入，把androidboot.mode设定为charger状态


## 3.1 charging\_animation.cpp中关于关机充电动画的相关流程分析


在MTK平台关机充电动画横屏显示的核心功能实现中，在关于MTK平台的关机充电动画的 核心类处理关机充电流程，就是在charging\_animation.cpp，接下来就具体分析下相关的关机充电动画的绘制流程 来实现横屏显示关机充电动画的相关逻辑



```
/*
 * Charging animation init
 *
 */
// modified by elink_phil start <<<
#ifdef ELINK_ITEMS_SUPPORT
extern void elink_logo_init(LCM_SCREEN_T *phical_screen);
#endif
// added end >>>
void anim_init()
{
// modified by elink_phil start <<<
#ifndef ELINK_ITEMS_SUPPORT
    init_charging_animation_ui_dimension();
#endif
// modified end >>>
    if (MTK_LOG_ENABLE == 1) {
        SLOGD("[libshowlogo: %s %d]\n",__FUNCTION__,__LINE__);
    }
    anim_logo_init();

    if (draw_anim_mode == (DRAW_ANIM_MODE_FB)) {
        anim_fb_init();
    } else {
        anim_surface_init();
    }
// modified by elink_phil start <<<
#ifdef ELINK_ITEMS_SUPPORT
    elink_logo_init(&phical_screen);
#endif
// modified end >>>
}

/*
 * Charging animation framebuffer related init
 *
 */
int anim_fb_init(void)
{
    if (MTK_LOG_ENABLE == 1) {
        SLOGD("[libshowlogo: %s %d]\n",__FUNCTION__,__LINE__);
    }

    fb_fd = open(FB_NODE_PATH, O_RDWR);
    if(fb_fd < 0)
    {
        if (MTK_LOG_ENABLE == 1) {
            SLOGE("[libshowlogo: %s %d]open dev file fail, errno = %d \n",__FUNCTION__,__LINE__ , errno);
        }
        close(fb_fd);
        error_flag = 1;

        return -1;
    }

    ioctl(fb_fd, FBIOGET_VSCREENINFO, &vinfo);
    ioctl(fb_fd, FBIOGET_FSCREENINFO, &finfo);

    fb_size  = finfo.line_length * vinfo.yres;
    dec_logo_addr = (unsigned int*) malloc(fb_size);

    lk_fb_addr =(unsigned int*)mmap(0, fb_size*3, PROT_READ | PROT_WRITE, MAP_SHARED, fb_fd, 0);
    charging_fb_addr = (unsigned int*)((unsigned int)lk_fb_addr + fb_size);
    kernel_fb_addr = (unsigned int*)((unsigned int)charging_fb_addr + fb_size);
    fb_addr = lk_fb_addr;
    if (MTK_LOG_ENABLE == 1) {
        SLOGD("[libshowlogo: %s %d]vinfo:xres  = %d, yres = %d, xres_virtual =%d, bits_per_pixel = %d,red.offset = %d,blue.offset = %d\n"
                ,__FUNCTION__, __LINE__, vinfo.xres,vinfo.yres, vinfo.xres_virtual, vinfo.bits_per_pixel,vinfo.red.offset,vinfo.blue.offset);

        SLOGD("[libshowlogo: %s %d]fb_size =%d, fb_addr = %d,charging_fb_addr=%d\n"
                ,__FUNCTION__, __LINE__, fb_size,( int)fb_addr, (int)charging_fb_addr);
    }

    if(fb_addr == NULL || charging_fb_addr == NULL)
    {
        if (MTK_LOG_ENABLE == 1) {
            SLOGE("ChargingAnimation mmap fail\n");
        }
        munmap(lk_fb_addr, fb_size*2);
        close(fb_fd);
        error_flag = 1;

        return -1;
    }

    phical_screen.bits_per_pixel = vinfo.bits_per_pixel;
    phical_screen.fill_dst_bits = vinfo.bits_per_pixel;
    phical_screen.red_offset = vinfo.red.offset;
    phical_screen.blue_offset = vinfo.blue.offset;

    phical_screen.width = vinfo.xres;
    phical_screen.height = vinfo.yres;

    phical_screen.allignWidth = finfo.line_length/(vinfo.bits_per_pixel/8);

    phical_screen.needAllign = 1;
    phical_screen.need180Adjust = 1;
    phical_screen.fb_size = fb_size;
    if (MTK_LOG_ENABLE == 1) {
        SLOGD("[libshowlogo: %s %d]MTK_LCM_PHYSICAL_ROTATION = %s\n",__FUNCTION__,__LINE__, MTK_LCM_PHYSICAL_ROTATION);
    }

   // modified by elink_phil start <<<
#ifndef ELINK_ITEMS_SUPPORT
   int rotation = getRotation();
    if (MTK_LOG_ENABLE == 1) {
        SLOGD("[libshowlogo: %s %d]rotation = %d\n",__FUNCTION__,__LINE__, rotation);
    }

    if(ORIENTATION_270 == rotation){//270
        phical_screen.rotation = 270;
    } else if(ORIENTATION_90 == rotation){//90
        phical_screen.rotation = 90;
    } else if((ORIENTATION_180 == rotation) && (phical_screen.need180Adjust == 1)){//180
        phical_screen.rotation = 180;
    } else {
        phical_screen.rotation = 0;
    }
#endif
// modified end >>>

    if (MTK_LOG_ENABLE == 1) {
        SLOGD("[libshowlogo]phical_screen: width= %d,height= %d,bits_per_pixel =%d,needAllign = %d,allignWidth=%d rotation =%d ,need180Adjust = %d\n",
                phical_screen.width, phical_screen.height,
                phical_screen.bits_per_pixel, phical_screen.needAllign,
                phical_screen.allignWidth, phical_screen.rotation, phical_screen.need180Adjust);
        SLOGD("[libshowlogo: %s %d]show old animtion= 1, running show_animationm_ver %d\n",__FUNCTION__,__LINE__, show_animationm_ver);
        SLOGD("[libshowlogo: %s %d]draw_anim_mode = 1, running mode %d\n",__FUNCTION__,__LINE__, draw_anim_mode);
    }

    return 0;
}
```

在MTK平台关机充电动画横屏显示的核心功能实现中，通过上述的源码分析得知，在 charging\_animation.cpp的相关源码中，在anim\_init()这个当前关机充电的动画中负责初始化关机充电的动画中，而在 anim\_init()这个方法中调用anim\_fb\_init(void)来负责更新当前充电的百分比，而在anim\_fb\_init(void)这个 关机充电动画更新方法中，同样也是调用int rotation = getRotation();来获取当前的关机充电的动画绘制屏幕方向, 然后通过设置phical\_screen.rotation来作为当前关机充电动画的显示屏幕方向， 所以说具体实现同样也是在根据phical\_screen.rotation中设置的屏幕方向值，进行相关的关机充电动画绘制的 通过分析得知，修改phical\_screen.rotation的值就可以了,所以说横屏显示就需要修改这个方法就可以了，接下来具体实现如下



```
@@ -711,7 +711,7 @@ int anim_fb_init(void) } else if((ORIENTATION_180 == rotation) && (phical_screen.need180Adjust == 1)){//180 phical_screen.rotation = 180; } else { - phical_screen.rotation = 0; + phical_screen.rotation = 270;//根据设备旋转合适的方向 } if (MTK_LOG_ENABLE == 1) { SLOGD("[libshowlogo]phical_screen: width= %d,height= %d,bits_per_pixel =%d,needAllign = %d,allignWidth=%d rotation =%d ,need180Adjust = %d\n", 
```

在MTK平台关机充电动画横屏显示的核心功能实现中，通过上述的源码分析得知，在 charging\_animation.cpp的相关源码中，通过上面的分析，通过上面的修改就完成了关机充电动画横屏显示的功能



