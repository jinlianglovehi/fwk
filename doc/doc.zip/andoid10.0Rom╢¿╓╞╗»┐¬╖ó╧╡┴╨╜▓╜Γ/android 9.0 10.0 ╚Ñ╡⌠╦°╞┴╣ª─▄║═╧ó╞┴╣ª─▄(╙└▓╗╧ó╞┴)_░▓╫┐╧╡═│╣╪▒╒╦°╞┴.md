






### 1.概述


在10.0的系统产品定制化开发中，需要对去掉锁屏功能和 息屏功能 让屏幕永远不要熄灭，  
 在android api中默认息屏时间为1分钟


### 2.去掉锁屏功能和息屏功能(永不息屏)的核心类



```
packages/SettingsProvider/res/values/defaults.xml
frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java

```

### 3.去掉锁屏功能和息屏功能(永不息屏)的核心功能分析和实现


在相关的源码分析，在系统数据库中会保存相关的初始化数据  
 通过查看 packages/SettingsProvider/res/values/defaults.xml  
 中的60000  
 值可知


而在/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java  
 中的



```
        private void loadSettings(SQLiteDatabase db) {
          loadSystemSettings(db);
          loadSecureSettings(db);
          // The global table only exists for the 'owner/system' user
          if (mUserHandle == UserHandle.USER_SYSTEM) {
              loadGlobalSettings(db);
          }
      }
  
      private void loadSystemSettings(SQLiteDatabase db) {
          SQLiteStatement stmt = null;
          try {
              stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                      + " VALUES(?,?);");
  
              loadBooleanSetting(stmt, Settings.System.DIM_SCREEN,
                      R.bool.def_dim_screen);
              loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                      R.integer.def_screen_off_timeout);
  
              // Set default cdma DTMF type
              loadSetting(stmt, Settings.System.DTMF_TONE_TYPE_WHEN_DIALING, 0);
  
              // Set default hearing aid
              loadSetting(stmt, Settings.System.HEARING_AID, 0);
  
              // Set default tty mode
              loadSetting(stmt, Settings.System.TTY_MODE, 0);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS,
                      R.integer.def_screen_brightness);
  
              loadIntegerSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_FOR_VR,
                      com.android.internal.R.integer.config_screenBrightnessForVrSettingDefault);
  
              loadBooleanSetting(stmt, Settings.System.SCREEN_BRIGHTNESS_MODE,
                      R.bool.def_screen_brightness_automatic_mode);
  
              loadBooleanSetting(stmt, Settings.System.ACCELEROMETER_ROTATION,
                      R.bool.def_accelerometer_rotation);
  
              loadDefaultHapticSettings(stmt);
  
              loadBooleanSetting(stmt, Settings.System.NOTIFICATION_LIGHT_PULSE,
                      R.bool.def_notification_pulse);
  
              loadUISoundEffectsSettings(stmt);
  
              loadIntegerSetting(stmt, Settings.System.POINTER_SPEED,
                      R.integer.def_pointer_speed);
  
              /*
               * IMPORTANT: Do not add any more upgrade steps here as the global,
               * secure, and system settings are no longer stored in a database
               * but are kept in memory and persisted to XML.
               *
               * See: SettingsProvider.UpgradeController#onUpgradeLocked
               */
          } finally {
              if (stmt != null) stmt.close();
          }
      }
     private void loadVibrateSetting(SQLiteDatabase db, boolean deleteOld) {
          if (deleteOld) {
              db.execSQL("DELETE FROM system WHERE name='" + Settings.System.VIBRATE_ON + "'");
          }
  
          SQLiteStatement stmt = null;
          try {
              stmt = db.compileStatement("INSERT OR IGNORE INTO system(name,value)"
                      + " VALUES(?,?);");
  
              // Vibrate on by default for ringer, on for notification
              int vibrate = 0;
              vibrate = AudioSystem.getValueForVibrateSetting(vibrate,
                      AudioManager.VIBRATE_TYPE_NOTIFICATION,
                      AudioManager.VIBRATE_SETTING_ONLY_SILENT);
              vibrate |= AudioSystem.getValueForVibrateSetting(vibrate,
                      AudioManager.VIBRATE_TYPE_RINGER, AudioManager.VIBRATE_SETTING_ONLY_SILENT);
              loadSetting(stmt, Settings.System.VIBRATE_ON, vibrate);
          } finally {
              if (stmt != null) stmt.close();
          }
      }

```

在loadSystemSettings(SQLiteDatabase db)中设置默认的息屏时间是



```
              loadIntegerSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
                      R.integer.def_screen_off_timeout);

```

默认是1分钟，所以想要  
 会默认设置最长息屏时间为30分钟


所以修改息屏时间就要从这两个地方入手


修改如下:



```
diff --git a/packages/SettingsProvider/res/values/defaults.xml b/packages/SettingsProvider/res/values/defaults.xml
old mode 100644
new mode 100755
index 7b81d9a..1b735f6
--- a/packages/SettingsProvider/res/values/defaults.xml
+++ b/packages/SettingsProvider/res/values/defaults.xml
@@ -18,7 +18,7 @@
 -->
 <resources>
     <bool name="def\_dim\_screen">true</bool>
-    <integer name="def\_screen\_off\_timeout">60000</integer>
+    <integer name="def\_screen\_off\_timeout">2147483647</integer>
     <integer name="def\_sleep\_timeout">-1</integer>
     <bool name="def\_airplane\_mode\_on">false</bool>
     <bool name="def\_theater\_mode\_on">false</bool>

```

def\_screen\_off\_timeout修改为2147483647就可以设置永不息屏  
 DatabaseHelper.java的修改



```
diff --git a/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java b/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
old mode 100644
new mode 100755
index b3ff9d0..4743137
--- a/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
+++ b/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
@@ -2020,7 +2020,7 @@ class DatabaseHelper extends SQLiteOpenHelper {
 
                 // Set the timeout to 30 minutes in milliseconds
                 loadSetting(stmt, Settings.System.SCREEN_OFF_TIMEOUT,
-                        Integer.toString(30 * 60 * 1000));
+                        Integer.toString(2147483647));
             } finally {
                 if (stmt != null) stmt.close();
             }

```

在upgradeScreenTimeoutFromNever(SQLiteDatabase db)中修改息屏时间为2147483647


2.SystemUI的config中不启用锁屏功能  
 在SystemUI的锁屏界面可知，对于是否开启锁屏功能是在config\_enableKeyguardService中决定的  
 通过查看源码可知  
 true  
 为默认开启锁屏功能


修改如下：



```
diff --git a/packages/SystemUI/res/values/config.xml b/packages/SystemUI/res/values/config.xml
old mode 100644
new mode 100755
index be1e1ca..3ca3255
--- a/packages/SystemUI/res/values/config.xml
+++ b/packages/SystemUI/res/values/config.xml
@@ -165,7 +165,7 @@
     <integer name="long\_press\_dock\_anim\_duration">250</integer>
 
     <!-- Whether to enable KeyguardService or not -->
-    <bool name="config\_enableKeyguardService">true</bool>
+    <bool name="config\_enableKeyguardService">false</bool>

```




