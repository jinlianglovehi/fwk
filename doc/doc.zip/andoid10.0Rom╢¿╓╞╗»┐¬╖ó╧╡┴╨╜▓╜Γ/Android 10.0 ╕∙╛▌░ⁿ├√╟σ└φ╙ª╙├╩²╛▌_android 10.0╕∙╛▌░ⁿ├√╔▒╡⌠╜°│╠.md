



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.根据包名清理应用数据的核心代码](#2.%E6%A0%B9%E6%8D%AE%E5%8C%85%E5%90%8D%E6%B8%85%E7%90%86%E5%BA%94%E7%94%A8%E6%95%B0%E6%8D%AE%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.根据包名清理应用数据的核心代码功能分析](#3.%E6%A0%B9%E6%8D%AE%E5%8C%85%E5%90%8D%E6%B8%85%E7%90%86%E5%BA%94%E7%94%A8%E6%95%B0%E6%8D%AE%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1AppInfoDashboardFragment.java清除应用数据的相关代码分析](#%C2%A0%203.1AppInfoDashboardFragment.java%E6%B8%85%E9%99%A4%E5%BA%94%E7%94%A8%E6%95%B0%E6%8D%AE%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 AppStoragePreferenceController.java来管理清理数据的相关接口](#3.2%20AppStoragePreferenceController.java%E6%9D%A5%E7%AE%A1%E7%90%86%E6%B8%85%E7%90%86%E6%95%B0%E6%8D%AE%E7%9A%84%E7%9B%B8%E5%85%B3%E6%8E%A5%E5%8F%A3)


[3.3 AppStorageSettings.java 清理数据的相关代码](#3.3%20AppStorageSettings.java%20%E6%B8%85%E7%90%86%E6%95%B0%E6%8D%AE%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[4. 实现清理数据功能](#4.%20%E5%AE%9E%E7%8E%B0%E6%B8%85%E7%90%86%E6%95%B0%E6%8D%AE%E5%8A%9F%E8%83%BD)




---



## 1.概述


  最近在定制化开发中，要求根据包名清除应用数据的接口，来实现清除app里面的数据,在ActivityManagerService.java中提供了清理数据的相关接口，可以调用api来实现功能就可以了


## 2.根据包名清理应用数据的核心代码



```
  packages/apps/Settings/src/com/android/settings/applications/appinfo/AppInfoDashboardFragment.java
  frameworks\base\services\core\java\com\android\server\am\ActivityManagerService.java
  packages/apps/Settings/src/com/android/settings/applications/appinfo/AppStoragePreferenceController.java
```

## 3.根据包名清理应用数据的核心代码功能分析


###   3.1AppInfoDashboardFragment.java清除应用数据的相关代码分析



```
 public class AppInfoDashboardFragment extends DashboardFragment
        implements ApplicationsState.Callbacks,
        ButtonActionDialogFragment.AppButtonsDialogListener {

    private static final String TAG = "AppInfoDashboard";
.....

    private InstantAppButtonsPreferenceController mInstantAppButtonPreferenceController;
    private AppButtonsPreferenceController mAppButtonsPreferenceController;

    /**
     * Callback to invoke when app info has been changed.
     */
    public interface Callback {
        void refreshUi();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        final String packageName = getPackageName();
        use(TimeSpentInAppPreferenceController.class).setPackageName(packageName);

        use(AppDataUsagePreferenceController.class).setParentFragment(this);
        final AppInstallerInfoPreferenceController installer =
                use(AppInstallerInfoPreferenceController.class);
        installer.setPackageName(packageName);
        installer.setParentFragment(this);
        use(AppInstallerPreferenceCategoryController.class).setChildren(Arrays.asList(installer));
        use(AppNotificationPreferenceController.class).setParentFragment(this);
        use(AppOpenByDefaultPreferenceController.class).setParentFragment(this);
        use(AppPermissionPreferenceController.class).setParentFragment(this);
        use(AppPermissionPreferenceController.class).setPackageName(packageName);
        use(AppSettingPreferenceController.class)
                .setPackageName(packageName)
                .setParentFragment(this);
        use(AppStoragePreferenceController.class).setParentFragment(this);
        use(AppVersionPreferenceController.class).setParentFragment(this);
        use(InstantAppDomainsPreferenceController.class).setParentFragment(this);

        final WriteSystemSettingsPreferenceController writeSystemSettings =
                use(WriteSystemSettingsPreferenceController.class);
        writeSystemSettings.setParentFragment(this);

        final DrawOverlayDetailPreferenceController drawOverlay =
                use(DrawOverlayDetailPreferenceController.class);
        drawOverlay.setParentFragment(this);

        final PictureInPictureDetailPreferenceController pip =
                use(PictureInPictureDetailPreferenceController.class);
        pip.setPackageName(packageName);
        pip.setParentFragment(this);
        final ExternalSourceDetailPreferenceController externalSource =
                use(ExternalSourceDetailPreferenceController.class);
        externalSource.setPackageName(packageName);
        externalSource.setParentFragment(this);

        use(AdvancedAppInfoPreferenceCategoryController.class).setChildren(Arrays.asList(
                writeSystemSettings, drawOverlay, pip, externalSource));
    }
}
```

在上述代码中可以看出，在onAttach()中加载AppStoragePreferenceController.java来管理清理数据的相关接口，以及各种Controller管理类的代码，最主要的还是AppStoragePreferenceController.java关于管理app存储的相关代码


### 3.2 AppStoragePreferenceController.java来管理清理数据的相关接口



```
    public class AppStoragePreferenceController extends AppInfoPreferenceControllerBase
        implements LoaderManager.LoaderCallbacks<StorageStatsSource.AppStorageStats>,
        LifecycleObserver, OnResume, OnPause {

    private StorageStatsSource.AppStorageStats mLastResult;

    public AppStoragePreferenceController(Context context, String key) {
        super(context, key);
    }

    @Override
    public void updateState(Preference preference) {
        final boolean isExternal =
                (mParent.getAppEntry().info.flags & ApplicationInfo.FLAG_EXTERNAL_STORAGE) != 0;
        preference.setSummary(getStorageSummary(mLastResult, isExternal));
    }

    @Override
    public void onResume() {
        mParent.getLoaderManager().restartLoader(mParent.LOADER_STORAGE, Bundle.EMPTY, this);
    }

    @Override
    public void onPause() {
        mParent.getLoaderManager().destroyLoader(mParent.LOADER_STORAGE);
    }

    @Override
    protected Class<? extends SettingsPreferenceFragment> getDetailFragmentClass() {
        return AppStorageSettings.class;
    }

    @VisibleForTesting
    CharSequence getStorageSummary(
            StorageStatsSource.AppStorageStats stats, boolean isExternal) {
        if (stats == null) {
            return mContext.getText(R.string.computing_size);
        }
        final CharSequence storageType = mContext.getString(isExternal
                ? R.string.storage_type_external
                : R.string.storage_type_internal);
        return mContext.getString(R.string.storage_summary_format,
                Formatter.formatFileSize(mContext, stats.getTotalBytes()),
                storageType.toString().toLowerCase());
    }

    @Override
    public Loader<StorageStatsSource.AppStorageStats> onCreateLoader(int id, Bundle args) {
        return new FetchPackageStorageAsyncLoader(mContext, new StorageStatsSource(mContext),
                mParent.getAppEntry().info, UserHandle.of(UserHandle.myUserId()));
    }

    @Override
    public void onLoadFinished(Loader<StorageStatsSource.AppStorageStats> loader,
            StorageStatsSource.AppStorageStats result) {
        mLastResult = result;
        updateState(mPreference);
    }

    @Override
    public void onLoaderReset(Loader<StorageStatsSource.AppStorageStats> loader) {
    }

}
```

通过    @Override  
     protected Class<? extends SettingsPreferenceFragment> getDetailFragmentClass() {  
         return AppStorageSettings.class;  
     }  
 具体实现在AppStorageSettings.java  
 接下来看AppStorageSettings.java 的相关代码


### 3.3 AppStorageSettings.java 清理数据的相关代码



```
@VisibleForTesting
    void handleClearDataClick() {
        if (mAppsControlDisallowedAdmin != null && !mAppsControlDisallowedBySystem) {
            RestrictedLockUtils.sendShowAdminSupportDetailsIntent(
                    getActivity(), mAppsControlDisallowedAdmin);
        } else if (mAppEntry.info.manageSpaceActivityName != null) {
            if (!Utils.isMonkeyRunning()) {
                Intent intent = new Intent(Intent.ACTION_DEFAULT);
                intent.setClassName(mAppEntry.info.packageName,
                        mAppEntry.info.manageSpaceActivityName);
                startActivityForResult(intent, REQUEST_MANAGE_SPACE);
            }
        } else {
            showDialogInner(DLG_CLEAR_DATA, 0);
        }
    }
@Override
    protected AlertDialog createDialog(int id, int errorCode) {
        switch (id) {
            case DLG_CLEAR_DATA:
                return new AlertDialog.Builder(getActivity())
                        .setTitle(getActivity().getText(R.string.clear_data_dlg_title))
                        .setMessage(getActivity().getText(R.string.clear_data_dlg_text))
                        .setPositiveButton(R.string.dlg_ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Clear user data here
                                initiateClearUserData();
                            }
                        })
                        .setNegativeButton(R.string.dlg_cancel, null)
                        .create();
            case DLG_CANNOT_CLEAR_DATA:
                return new AlertDialog.Builder(getActivity())
                        .setTitle(getActivity().getText(R.string.clear_user_data_text))
                        .setMessage(getActivity().getText(R.string.clear_failed_dlg_text))
                        .setNeutralButton(R.string.dlg_ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                mButtonsPref.setButton1Enabled(false);
                                //force to recompute changed value
                                setIntentAndFinish(false  /* appChanged */);
                            }
                        })
                        .create();
        }
        return null;
    }
```

在上述代码的 createDialog(int id, int errorCode)可以看出在DLG\_CLEAR\_DATA 类型中调用的initiateClearUserData();就是清理数据的方法


接下来看下initiateClearUserData();关于清理数据的方法



```
private void initiateClearUserData() {
        /* Bug1118834:Repeatedly clicking the "Clear Storage" button while splitting the screen causes the settings to crash @{ */
        final Context context = getActivity();
        if (context == null) {
            Log.i(TAG, "Couldn't clear application user data");
            return;
        }
        /* @} */
        mMetricsFeatureProvider.action(context, SettingsEnums.ACTION_SETTINGS_CLEAR_APP_DATA);
        mButtonsPref.setButton1Enabled(false);
        // Invoke uninstall or clear user data based on sysPackage
        String packageName = mAppEntry.info.packageName;
        Log.i(TAG, "Clearing user data for package : " + packageName);
        if (mClearDataObserver == null) {
            mClearDataObserver = new ClearUserDataObserver();
        }
        ActivityManager am = (ActivityManager)
                context.getSystemService(Context.ACTIVITY_SERVICE);
        boolean res = am.clearApplicationUserData(packageName, mClearDataObserver);
        if (!res) {
            // Clearing data failed for some obscure reason. Just log error for now
            Log.i(TAG, "Couldn't clear application user data for package:" + packageName);
            showDialogInner(DLG_CANNOT_CLEAR_DATA, 0);
        } else {
            mButtonsPref.setButton1Text(R.string.recompute_size);
        }
    }
```

通过initiateClearUserData()发现清理数据就是  
         ActivityManager am = (ActivityManager)  
                 context.getSystemService(Context.ACTIVITY\_SERVICE);  
         boolean res = am.clearApplicationUserData(packageName, mClearDataObserver);  
 即可实现清理数据


## 4. 实现清理数据功能


在系统service中调用



```
public void clearAppDatas(String pkg,Context context){
        final long ident = Binder.clearCallingIdentity();
        try {
           ActivityManager ams = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
           boolean result = ams.clearApplicationUserData(pkg, null);
           Log.e(TAG,"result :"+result);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            Binder.restoreCallingIdentity(ident);
        }
       }
```

通过在系统frameworks中自定义服务中调用clearAppDatas(String pkg,Context context)就实现了根据包名清理app缓存数据的功能



