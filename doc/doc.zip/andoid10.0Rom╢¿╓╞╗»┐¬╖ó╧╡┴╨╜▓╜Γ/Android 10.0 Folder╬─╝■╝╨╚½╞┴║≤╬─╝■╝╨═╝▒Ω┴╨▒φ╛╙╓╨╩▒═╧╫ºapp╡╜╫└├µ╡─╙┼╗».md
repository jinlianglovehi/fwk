



## 1.概述


在10.0的系统rom产品开发中，在Launcher3中在目前的产品需求开发中，对于Launcher3中的文件夹Folder的布局UI  
 进行了定制化的需求要求把Folder修改为全屏，然后在中间显示文件夹图标的列表，这时候如果Folder是全屏的话，如果拖拽文件夹列表中的app图标，只有拖拽  
 到屏幕边缘才可以拖拽到workspace的页面，所以产品需求要求在app拖拽出中间的文件夹灰色区域的时候，就可以拖拽到workspace的页面，所以这就需要  
 对比folder非全屏的时候的拖拽情况，然后看拖拽流程来分析功能的实现  
 效果图如图:



## 2.Folder文件夹全屏后文件夹图标列表居中时拖拽app到桌面的优化的核心类



```
    packages/apps/Launcher3/src/com/android/launcher3/folder/Folder.java
    packages/apps/Launcher3/src/com/android/launcher3/folder/FolderPagedView.java
    packages/apps/Launcher3/src/com/android/launcher3/dragndrop/DragController.java
```

## 3.Folder文件夹全屏后文件夹图标列表居中时拖拽app到桌面的优化的核心功能分析和实现


Folder Widget（大文件夹小部件）是一个强大的启动器小部件，它允许用户创建文件夹来放置应用程序、快捷设置和弹出小组件以便快速启动


在系统源码的Launcher3模块中，对于文件夹中的app的图标进行拖拽的相关处理流程中，对于文件夹的管理都是在Folder中进行的，Folder文件夹布局，监听文件夹里的图标的拖拽  
 然后分别处理文件夹内的app图标拖拽功能，接下来分析下Folder模块中关于app拖拽流程的相关功能代码


## 3.1 Folder.java中关于app拖拽流程的相关功能分析



```
    public class Folder extends AbstractFloatingView implements ClipPathView, DragSource,
            View.OnLongClickListener, DropTarget, FolderListener, TextView.OnEditorActionListener,
            View.OnFocusChangeListener, DragListener, ExtendedEditText.OnBackKeyListener {
        private static final String TAG = "Launcher.Folder";
        private static final boolean DEBUG = false;
     
        /**
         * Used for separating folder title when logging together.
         */
        private static final CharSequence FOLDER_LABEL_DELIMITER = "~";
     
        public Folder(Context context, AttributeSet attrs) {
            super(context, attrs);
            setAlwaysDrawnWithCacheEnabled(false);
            mContext = context;
            mLauncher = Launcher.getLauncher(context);
            mStatsLogManager = StatsLogManager.newInstance(context);
            // We need this view to be focusable in touch mode so that when text editing of the folder
            // name is complete, we have something to focus on, thus hiding the cursor and giving
            // reliable behavior when clicking the text field (since it will always gain focus on click).
            setFocusableInTouchMode(true);
     
        }
     
        @Override
        protected void onFinishInflate() {
            super.onFinishInflate();
            mContent = findViewById(R.id.folder_content);
            mContent.setFolder(this);
            mPageIndicator = findViewById(R.id.folder_page_indicator);
            mFolderName = findViewById(R.id.folder_name);
            mFolderName.setOnBackKeyListener(this);
            mFolderName.setOnFocusChangeListener(this);
            mFolderName.setOnEditorActionListener(this);
            mFolderName.setSelectAllOnFocus(true);
            mFolderName.setInputType(mFolderName.getInputType()
                    & ~InputType.TYPE_TEXT_FLAG_AUTO_CORRECT
                    & ~InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
            mFolderName.forceDisableSuggestions(!FeatureFlags.FOLDER_NAME_SUGGEST.get());
     
            mFooter = findViewById(R.id.folder_footer);
     
            // We find out how tall footer wants to be (it is set to wrap_content), so that
            // we can allocate the appropriate amount of space for it.
            int measureSpec = MeasureSpec.UNSPECIFIED;
            mFooter.measure(measureSpec, measureSpec);
            mFooterHeight = mFooter.getMeasuredHeight();
        }
```

在launcher3中的Folder.java中的上述源码中，在Folder(Context context, AttributeSet attrs)中，mLauncher获取Launcher的对象，实例化StatsLogManager的相关管理类,  
 在onFinishInflate()的相关方法中，mContent就是文件夹的app列表类，mFolderName就是文件夹列表的文件夹名称，通过调用mFooter.measure(measureSpec, measureSpec);  
 来测量绘制文件夹底部的布局，接下来分析下相关的绘制文件夹布局的相关源码



```

        private int getFolderWidth() {
            return 1920/*getPaddingLeft() + getPaddingRight() + mContent.getDesiredWidth()*/;
        }
     
        private int getFolderHeight() {
            return 1080/*getFolderHeight(getContentAreaHeight())*/;
        }
     
        private int getFolderHeight(int contentAreaHeight) {
            return 1080/*getPaddingTop() + getPaddingBottom() + contentAreaHeight + mFooterHeight*/;
        }

```

在launcher3中的Folder.java中的上述源码中，在getFolderWidth() 中设置当前Folder的宽度，而在getFolderHeight()中通过设置当前Folder的高度，  
 在getFolderHeight(int contentAreaHeight)中通过调用文件夹内部app列表的高度来设置当前Folder高度，通过上述的修改，直接设置为屏幕的宽高度  
 这样就可以让Folder的布局为全屏显示，接下来分析下Folder拖拽到workspace的相关源码


## 3.2 FolderPagedView.java中关于文件夹内部app列表灰色区域的高度宽度分析


在Launcher3的Folder模块中，如果有多个folder构建的folder文件夹列表时，可以通过分页的形式  
 来构建多页的folder文件夹列表页，所以可以在每个列表页中，来设定列表页的宽高等相关要素，  
 这些都是在FolderPagedView.java中完成构建的，所以就需要分析FolderPagedView.java的  
 相关源码



```
      public class FolderPagedView extends PagedView<PageIndicatorDots> {
     
        private static final String TAG = "FolderPagedView";
        @SuppressLint("InflateParams")
        public View createNewView(WorkspaceItemInfo item) {
            if (item == null) {
                return null;
            }
            final BubbleTextView textView = mViewCache.getView(
                    R.layout.folder_application, getContext(), null);
            textView.applyFromWorkspaceItem(item);
            textView.setOnClickListener(ItemClickHandler.INSTANCE);
            textView.setOnLongClickListener(mFolder);
            textView.setOnFocusChangeListener(mFocusIndicatorHelper);
            CellLayout.LayoutParams lp = (CellLayout.LayoutParams) textView.getLayoutParams();
            if (lp == null) {
                textView.setLayoutParams(new CellLayout.LayoutParams(
                        item.cellX, item.cellY, item.spanX, item.spanY));
            } else {
                lp.cellX = item.cellX;
                lp.cellY = item.cellY;
                lp.cellHSpan = lp.cellVSpan = 1;
            }
            return textView;
        }
     
        public int getDesiredWidth() {
            return getPageCount() > 0 ?
                    500/*(getPageAt(0).getDesiredWidth() + getPaddingLeft() + getPaddingRight())*/ : 0;
        }
     
        public int getDesiredHeight()  {
            return  getPageCount() > 0 ?
                    500/*(getPageAt(0).getDesiredHeight() + getPaddingTop() + getPaddingBottom())*/ : 0;
        }
     
        /**
         * @return the rank of the cell nearest to the provided pixel position.
         */
        public int findNearestArea(int pixelX, int pixelY) {
            int pageIndex = getNextPage();
            CellLayout page = getPageAt(pageIndex);
            page.findNearestArea(pixelX, pixelY, 1, 1, sTmpArray);
            if (mFolder.isLayoutRtl()) {
                sTmpArray[0] = page.getCountX() - sTmpArray[0] - 1;
            }
            return Math.min(mAllocatedContentSize - 1,
                    pageIndex * mOrganizer.getMaxItemsPerPage()
                            + sTmpArray[1] * mGridCountX + sTmpArray[0]);
        }
```

在FolderPagedView.java中的上述的相关源码中，发现在getDesiredWidth()中设置文件夹内部灰色区域app列表部分的宽度,  
 而在getDesiredHeight()中通过设置文件夹内部灰色区域app列表部分的高度，而通过findNearestArea(int pixelX, int pixelY)  
 方法通过x，y的坐标值来寻找最近的app图标的位置，然后交换位置，通过上面的修改，就把灰色区域的app列表的宽和高都设置为500，来实现修改文件夹内部灰色区域app列表部分的宽高


## 3.3DragController.java中关于拖拽app内部文件夹列表的分析


在Launcher3中，关于拖拽是由DragController进行控制的。  
 基本流程是相应的View在检测到用户操作后进行判断，若可以触发拖拽，则设置自身的相应状态，然后将待拖拽对象的Bitmap对象、当前位置、拖拽源、待拖拽对象等信息传给DragController的startDrag方法启动拖拽。接下来，DragLayer的onInterceptTouchEvent拦截触屏事件，  
 将其转到DragController的onTouchEvent方法。在DragController的onTouchEvent中  
 调用DragController的handleMoveEvent进行对象的移动，并通知相应拖拽目的对象状态的改变。  
 最后在DragController的onTouchEvent中检测到抬起事件时调用drop方法释放待拖拽对象，  
 调用endDrag方法结束拖拽。



```
       public DragView startDrag(Bitmap b, DraggableView originalView, int dragLayerX, int dragLayerY,
                DragSource source, ItemInfo dragInfo, Point dragOffset, Rect dragRegion,
                float initialDragViewScale, float dragViewScaleOnDrop, DragOptions options) {
            if (PROFILE_DRAWING_DURING_DRAG) {
                android.os.Debug.startMethodTracing("Launcher");
            }
    ......
     
            mLauncher.getDragLayer().performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            dragView.show(mLastTouch.x, mLastTouch.y);
            mDistanceSinceScroll = 0;
     
            if (!mIsInPreDrag) {
                callOnDragStart();
            } else if (mOptions.preDragCondition != null) {
                mOptions.preDragCondition.onPreDragStart(mDragObject);
            }
     
            handleMoveEvent(mLastTouch.x, mLastTouch.y);
            mLauncher.getUserEventDispatcher().resetActionDurationMillis();
     
            if (!mLauncher.isTouchInProgress() && options.simulatedDndStartPoint == null) {
                // If it is an internal drag and the touch is already complete, cancel immediately
                MAIN_EXECUTOR.submit(this::cancelDrag);
            }
            return dragView;
        }

```

在DragController.java中的上述方法中，在 startDrag(Bitmap b, DraggableView originalView, int dragLayerX, int dragLayerY,  
 DragSource source, ItemInfo dragInfo, Point dragOffset, Rect dragRegion,  
 float initialDragViewScale, float dragViewScaleOnDrop, DragOptions options)中处理关于文件夹 app图标 hotseat的  
 拖拽处理流程，而在这里面由 handleMoveEvent(mLastTouch.x, mLastTouch.y);来负责更新触摸拖拽的app的位置信息  
 接下来看下 handleMoveEvent(mLastTouch.x, mLastTouch.y);的相关源码流程分析



```
       private void handleMoveEvent(int x, int y) {
            mDragObject.dragView.move(x, y);
     
            // Drop on someone?
            final int[] coordinates = mCoordinatesTemp;
            DropTarget dropTarget = findDropTarget(x, y, coordinates);
            mDragObject.x = coordinates[0];
            mDragObject.y = coordinates[1];
            checkTouchMove(dropTarget);
     
            // Check if we are hovering over the scroll areas
            mDistanceSinceScroll += Math.hypot(mLastTouch.x - x, mLastTouch.y - y);
            mLastTouch.set(x, y);
     
            int distanceDragged = mDistanceSinceScroll;
            if (ATLEAST_Q && mLastTouchClassification == MotionEvent.CLASSIFICATION_DEEP_PRESS) {
                distanceDragged /= DEEP_PRESS_DISTANCE_FACTOR;
            }
            if (mIsInPreDrag && mOptions.preDragCondition != null
                    && mOptions.preDragCondition.shouldStartDrag(distanceDragged)) {
                callOnDragStart();
            }
        }
```

在DragController.java中的上述方法中，在handleMoveEvent(int x, int y) 的方法中，通过findDropTarget(x, y, coordinates);中根据xy的坐标值来寻找


最近的app hotseat folder中的图标值，然后判断当前所在的区域是folder还是workspace,然后是否需要替换掉原来位置的app的图标，然后接着走完整个拖拽流程


接下来分析下findDropTarget(x, y, coordinates);中关于查找负责的app图标的相关方法的分析



```
       private DropTarget findDropTarget(int x, int y, int[] dropCoordinates) {
            mDragObject.x = x;
            mDragObject.y = y;
     
            Rect r = mRectTemp;
            final ArrayList<DropTarget> dropTargets = mDropTargets;
            final int count = dropTargets.size();
            for (int i = count - 1; i >= 0; i--) {
                DropTarget target = dropTargets.get(i);
                if (!target.isDropEnabled())
                    continue;
     
                target.getHitRectRelativeToDragLayer(r);
     
    //add core start
                if(target instanceof Folder){
                    Folder folder = (Folder)target;
                    if(folder!=null){
                        FolderPagedView pagedview = folder.mContent;
                        Log.e("DragController","top:"+pagedview.getTop()+"--left:"+pagedview.getLeft()+"--x:"+x+"--y:"+y);
                        r = new Rect(pagedview.getLeft(),pagedview.getTop(),pagedview.getRight(),pagedview.getBottom());
                    }
                }
    //add core end
     
                if (r.contains(x, y)) {
                    dropCoordinates[0] = x;
                    dropCoordinates[1] = y;
                    mLauncher.getDragLayer().mapCoordInSelfToDescendant((View) target, dropCoordinates);
                    return target;
                }
            }
            // Pass all unhandled drag to workspace. Workspace finds the correct
            // cell layout to drop to in the existing drag/drop logic.
            dropCoordinates[0] = x;
            dropCoordinates[1] = y;
            mLauncher.getDragLayer().mapCoordInSelfToDescendant(mLauncher.getWorkspace(),
                    dropCoordinates);
            return mLauncher.getWorkspace();
        }
```

在DragController.java中的上述方法中，在findDropTarget(int x, int y, int[] dropCoordinates)中，通过x 和y的值来查找附近的Folder中当前的DropTarget值，判断是文件


夹还是workspace 布局，会根据Rect r = mRectTemp;来判断当前Folder的宽高布局，看当前拖拽是否移动到workspace了，所以当Folder全屏的话，会难拖拽出Folder


的区域，所以当前需要以folder.mContent的宽高来判断，就是文件夹内部灰色的app列表区域来判断是否需要拖拽到Workspace 区域了


所以增加上述的代码后，来把folder.mContent的宽高作为判断依据看当前是否拖拽出folder.mContent，拖拽出这个区域后就会返回Workspace，就拖拽到workspace区域了


从而实现了功能



