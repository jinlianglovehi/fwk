



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Camera2退出屏幕旋转为横屏的主要功能分析](#2.Camera2%E9%80%80%E5%87%BA%E5%B1%8F%E5%B9%95%E6%97%8B%E8%BD%AC%E4%B8%BA%E6%A8%AA%E5%B1%8F%E7%9A%84%E4%B8%BB%E8%A6%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.Camera2退出屏幕旋转为横屏的主要代码分析](#3.Camera2%E9%80%80%E5%87%BA%E5%B1%8F%E5%B9%95%E6%97%8B%E8%BD%AC%E4%B8%BA%E6%A8%AA%E5%B1%8F%E7%9A%84%E4%B8%BB%E8%A6%81%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 Activity的相关finish方法分析](#%C2%A0%203.1%20Activity%E7%9A%84%E7%9B%B8%E5%85%B3finish%E6%96%B9%E6%B3%95%E5%88%86%E6%9E%90)


[3.2 接下来分析下ATMS 即ActivityTaskManagerSevice.java的相关finishActivity方法](#3.2%20%E6%8E%A5%E4%B8%8B%E6%9D%A5%E5%88%86%E6%9E%90%E4%B8%8BATMS%20%E5%8D%B3ActivityTaskManagerSevice.java%E7%9A%84%E7%9B%B8%E5%85%B3finishActivity%E6%96%B9%E6%B3%95)


[3.3 ActivityRecord关于Activity包名信息查询](#3.3%20ActivityRecord%E5%85%B3%E4%BA%8EActivity%E5%8C%85%E5%90%8D%E4%BF%A1%E6%81%AF%E6%9F%A5%E8%AF%A2)


[4.Camera2退出屏幕旋转为横屏的功能实现](#4.Camera2%E9%80%80%E5%87%BA%E5%B1%8F%E5%B9%95%E6%97%8B%E8%BD%AC%E4%B8%BA%E6%A8%AA%E5%B1%8F%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[4.1. 在ActivityRecord中增加获取包名的方法如下：](#%C2%A0%204.1.%20%E5%9C%A8ActivityRecord%E4%B8%AD%E5%A2%9E%E5%8A%A0%E8%8E%B7%E5%8F%96%E5%8C%85%E5%90%8D%E7%9A%84%E6%96%B9%E6%B3%95%E5%A6%82%E4%B8%8B%EF%BC%9A)


[4.2.在ATMS中finishActivity增加旋转屏幕功能](#%C2%A0%204.2.%E5%9C%A8ATMS%E4%B8%ADfinishActivity%E5%A2%9E%E5%8A%A0%E6%97%8B%E8%BD%AC%E5%B1%8F%E5%B9%95%E5%8A%9F%E8%83%BD)




---



## 1.概述


  在10.0的定制化中，由于屏幕是默认横屏的，但是在进入Camera2相机时变成竖屏，退出相机时，还是竖屏，对于横屏的机器来说不太符合要求，所以要求在退出相机时，旋转为横屏，这就需要知道哪个api监听Camera2 退出了，然后在旋转横屏就可以了


## 2.Camera2退出屏幕旋转为横屏的主要功能分析


  在10.0中 activity执行finish后由AMS执行相关的finish工作，接下来由ATMS执行相关的finish工作  
 所以功能实现的重心在于在AMS ATMS的相关finish流程中判断如果是Camera2,然后实现屏幕旋转


## 3.Camera2退出屏幕旋转为横屏的主要代码分析


###   3.1 Activity的相关finish方法分析



```
      /**
     * Finishes the current activity and specifies whether to remove the task associated with this
     * activity.
     */
    @UnsupportedAppUsage
    private void finish(int finishTask) {
        if (mParent == null) {
            int resultCode;
            Intent resultData;
            synchronized (this) {
                resultCode = mResultCode;
                resultData = mResultData;
            }
            if (false) Log.v(TAG, "Finishing self: token=" + mToken);
            try {
                if (resultData != null) {
                    resultData.prepareToLeaveProcess(this);
                }
                if (ActivityTaskManager.getService()
                        .finishActivity(mToken, resultCode, resultData, finishTask)) {
                    mFinished = true;
                }
            } catch (RemoteException e) {
                // Empty
            }
        } else {
            mParent.finishFromChild(this);
        }

        // Activity was launched when user tapped a link in the Autofill Save UI - Save UI must
        // be restored now.
        if (mIntent != null && mIntent.hasExtra(AutofillManager.EXTRA_RESTORE_SESSION_TOKEN)) {
            getAutofillManager().onPendingSaveUi(AutofillManager.PENDING_UI_OPERATION_RESTORE,
                    mIntent.getIBinderExtra(AutofillManager.EXTRA_RESTORE_SESSION_TOKEN));
        }
    }

    /**
     * Call this when your activity is done and should be closed.  The
     * ActivityResult is propagated back to whoever launched you via
     * onActivityResult().
     */
    public void finish() {
        if (DEBUG_ACTIVITY) {
            Log.d(TAG, "finish is called", new Throwable());
        }
        finish(DONT_FINISH_TASK_WITH_ACTIVITY);
    }

    /**
     * Finish this activity as well as all activities immediately below it
     * in the current task that have the same affinity.  This is typically
     * used when an application can be launched on to another task (such as
     * from an ACTION_VIEW of a content type it understands) and the user
     * has used the up navigation to switch out of the current task and in
     * to its own task.  In this case, if the user has navigated down into
     * any other activities of the second application, all of those should
     * be removed from the original task as part of the task switch.
     *
     * <p>Note that this finish does <em>not</em> allow you to deliver results
     * to the previous activity, and an exception will be thrown if you are trying
     * to do so.</p>
     */
    public void finishAffinity() {
        if (mParent != null) {
            throw new IllegalStateException("Can not be called from an embedded activity");
        }
        if (mResultCode != RESULT_CANCELED || mResultData != null) {
            throw new IllegalStateException("Can not be called to deliver a result");
        }
        try {
            if (ActivityTaskManager.getService().finishActivityAffinity(mToken)) {
                mFinished = true;
            }
        } catch (RemoteException e) {
            // Empty
        }
    }

    /**
     * This is called when a child activity of this one calls its
     * {@link #finish} method.  The default implementation simply calls
     * finish() on this activity (the parent), finishing the entire group.
     *
     * @param child The activity making the call.
     *
     * @see #finish
     */
    public void finishFromChild(Activity child) {
        finish();
    }

    /**
     * Reverses the Activity Scene entry Transition and triggers the calling Activity
     * to reverse its exit Transition. When the exit Transition completes,
     * {@link #finish()} is called. If no entry Transition was used, finish() is called
     * immediately and the Activity exit Transition is run.
     * @see android.app.ActivityOptions#makeSceneTransitionAnimation(Activity, android.util.Pair[])
     */
    public void finishAfterTransition() {
        if (!mActivityTransitionState.startExitBackTransition(this)) {
            finish();
        }
    }

    /**
     * Force finish another activity that you had previously started with
     * {@link #startActivityForResult}.
     *
     * @param requestCode The request code of the activity that you had
     *                    given to startActivityForResult().  If there are multiple
     *                    activities started with this request code, they
     *                    will all be finished.
     */
    public void finishActivity(int requestCode) {
        if (mParent == null) {
            try {
                ActivityTaskManager.getService()
                    .finishSubActivity(mToken, mEmbeddedID, requestCode);
            } catch (RemoteException e) {
                // Empty
            }
        } else {
            mParent.finishActivityFromChild(this, requestCode);
        }
    }
```

从finish(int finishTask)的代码中可以看出  
 if (ActivityTaskManager.getService()  
                         .finishActivity(mToken, resultCode, resultData, finishTask)) {  
                     mFinished = true;  
                 }  
 调用执行的是ATMS的finishActivity(mToken, resultCode, resultData, finishTask) 来finish()掉Activity的


### 3.2 接下来分析下ATMS 即ActivityTaskManagerSevice.java的相关finishActivity方法



```
    /**
     * This is the internal entry point for handling Activity.finish().
     *
     * @param token The Binder token referencing the Activity we want to finish.
     * @param resultCode Result code, if any, from this Activity.
     * @param resultData Result data (Intent), if any, from this Activity.
     * @param finishTask Whether to finish the task associated with this Activity.
     *
     * @return Returns true if the activity successfully finished, or false if it is still running.
     */
    @Override
    public final boolean finishActivity(IBinder token, int resultCode, Intent resultData,
            int finishTask) {
        // Refuse possible leaked file descriptors
        if (resultData != null && resultData.hasFileDescriptors()) {
            throw new IllegalArgumentException("File descriptors passed in Intent");
        }

        synchronized (mGlobalLock) {
            ActivityRecord r = ActivityRecord.isInStackLocked(token);
            if (r == null) {
                return true;
            }
            // Keep track of the root activity of the task before we finish it
            final TaskRecord tr = r.getTaskRecord();
            ActivityRecord rootR = tr.getRootActivity();
            if (rootR == null) {
                Slog.w(TAG, "Finishing task with all activities already finished");
            }
            // Do not allow task to finish if last task in lockTask mode. Launchable priv-apps can
            // finish.
            if (getLockTaskController().activityBlockedFromFinish(r)) {
                return false;
            }

            // TODO: There is a dup. of this block of code in ActivityStack.navigateUpToLocked
            // We should consolidate.
            if (mController != null) {
                // Find the first activity that is not finishing.
                ActivityRecord next = r.getActivityStack().topRunningActivityLocked(token, 0);

                // SPRD:bug778642, widen the finish request check area.
                ActivityStack homeStack = mRootActivityContainer.getDefaultDisplay().getHomeStack();
                if (next == null && homeStack != null && r.isActivityTypeHome()) {
                    next = homeStack.topRunningActivityLocked();
                    Slog.i(TAG, "Adjust the next resume activity check to " + next + " for "
                            + r + " finish request.");
                    // The home stack top running activity is null, we need to check the home
                    // activity package for monkey test. Ensure that not finish the last activity
                    // of the monkey white list packages, so that we can avoid the refuse of start
                    // home acivity which may make ANR happen.
                    if (next == null) {
                        boolean resumeOK = true;
                        ActivityInfo aInfo = null;
                        try {
                            aInfo = AppGlobals.getPackageManager().getActivityInfo(
                                    getHomeIntent().getComponent(), STOCK_PM_FLAGS, UserHandle.getCallingUserId());
                        } catch (RemoteException e) {
                            //ignore
                        }
                        if (aInfo != null) {
                            try {
                                resumeOK = mController.activityResuming(aInfo.packageName);
                            } catch (RemoteException e) {
                                mController = null;
                                Watchdog.getInstance().setActivityController(null);
                            }

                            if (!resumeOK) {
                                Slog.i(TAG, "Not finishing activity because controller resumed,"
                                        + " check packageName:" + aInfo.packageName);
                                return false;
                            }
                        }
                    }
                }

                if (next != null) {
                    // ask watcher if this is allowed
                    boolean resumeOK = true;
                    try {
                        resumeOK = mController.activityResuming(next.packageName);
                    } catch (RemoteException e) {
                        mController = null;
                        Watchdog.getInstance().setActivityController(null);
                    }

                    if (!resumeOK) {
                        Slog.i(TAG, "Not finishing activity because controller resumed");
                        return false;
                    }
                }
            }

            // note down that the process has finished an activity and is in background activity
            // starts grace period
            if (r.app != null) {
                r.app.setLastActivityFinishTimeIfNeeded(SystemClock.uptimeMillis());
            }

            final long origId = Binder.clearCallingIdentity();
            try {
                boolean res;
                final boolean finishWithRootActivity =
                        finishTask == Activity.FINISH_TASK_WITH_ROOT_ACTIVITY;
                if (finishTask == Activity.FINISH_TASK_WITH_ACTIVITY
                        || (finishWithRootActivity && r == rootR)) {
                    // If requested, remove the task that is associated to this activity only if it
                    // was the root activity in the task. The result code and data is ignored
                    // because we don't support returning them across task boundaries. Also, to
                    // keep backwards compatibility we remove the task from recents when finishing
                    // task with root activity.
                    res = mStackSupervisor.removeTaskByIdLocked(tr.taskId, false,
                            finishWithRootActivity, "finish-activity");
                    if (!res) {
                        Slog.i(TAG, "Removing task failed to finish activity");
                    }
                    // Explicitly dismissing the activity so reset its relaunch flag.
                    r.mRelaunchReason = RELAUNCH_REASON_NONE;
                } else {
                    res = tr.getStack().requestFinishActivityLocked(token, resultCode,
                            resultData, "app-request", true);
                    if (!res) {
                        Slog.i(TAG, "Failed to finish by app-request");
                    }
                }
                return res;
            } finally {
                Binder.restoreCallingIdentity(origId);
            }
        }
    }

    @Override
    public boolean finishActivityAffinity(IBinder token) {
        synchronized (mGlobalLock) {
            final long origId = Binder.clearCallingIdentity();
            try {
                ActivityRecord r = ActivityRecord.isInStackLocked(token);
                if (r == null) {
                    return false;
                }

                // Do not allow task to finish if last task in lockTask mode. Launchable priv-apps
                // can finish.
                final TaskRecord task = r.getTaskRecord();
                if (getLockTaskController().activityBlockedFromFinish(r)) {
                    return false;
                }
                return task.getStack().finishActivityAffinityLocked(r);
            } finally {
                Binder.restoreCallingIdentity(origId);
            }
        }
    }

```

在finishActivity(IBinder token, int resultCode, Intent resultData,int finishTask)中是最终实现finish掉Activity的方法然后从栈中去掉该Activity的，所以说在这里判断包名为com.android.camera2的activity时，旋转屏幕就可以了  
 而在代码中的ActivityRecord类一个ActivityRecord对应着一个Activity，保存着一个Activity的所有信息；但是一个Activity可能会有多个ActivityRecord  
 所以可以从这个类里面获取包名


## 3.3 ActivityRecord关于Activity包名信息查询



```
    final String packageName; // the package implementing intent's component
     ActivityRecord(ActivityTaskManagerService _service, WindowProcessController _caller,
            int _launchedFromPid, int _launchedFromUid, String _launchedFromPackage, Intent _intent,
            String _resolvedType, ActivityInfo aInfo, Configuration _configuration,
            ActivityRecord _resultTo, String _resultWho, int _reqCode, boolean _componentSpecified,
            boolean _rootVoiceInteraction, ActivityStackSupervisor supervisor,
            ActivityOptions options, ActivityRecord sourceRecord) {
        mAtmService = _service;
        mRootActivityContainer = _service.mRootActivityContainer;
        appToken = new Token(this, _intent);
        info = aInfo;
        launchedFromPid = _launchedFromPid;
        launchedFromUid = _launchedFromUid;
        launchedFromPackage = _launchedFromPackage;
        mUserId = UserHandle.getUserId(aInfo.applicationInfo.uid);
        intent = _intent;
        shortComponentName = _intent.getComponent().flattenToShortString();
        resolvedType = _resolvedType;
        componentSpecified = _componentSpecified;
        rootVoiceInteraction = _rootVoiceInteraction;
        mLastReportedConfiguration = new MergedConfiguration(_configuration);
        resultTo = _resultTo;
        resultWho = _resultWho;
        requestCode = _reqCode;
        setState(INITIALIZING, "ActivityRecord ctor");
        frontOfTask = false;
        launchFailed = false;
        stopped = false;
        delayedResume = false;
        finishing = false;
        deferRelaunchUntilPaused = false;
        keysPaused = false;
        inHistory = false;
        visible = false;
        nowVisible = false;
        mDrawn = false;
        idle = false;
        hasBeenLaunched = false;
        mStackSupervisor = supervisor;
        callerPid = _caller != null ? _caller.getPid() : -1;

        // This starts out true, since the initial state of an activity is that we have everything,
        // and we shouldn't never consider it lacking in state to be removed if it dies.
        haveState = true;

        // If the class name in the intent doesn't match that of the target, this is
        // probably an alias. We have to create a new ComponentName object to keep track
        // of the real activity name, so that FLAG_ACTIVITY_CLEAR_TOP is handled properly.
        if (aInfo.targetActivity == null
                || (aInfo.targetActivity.equals(_intent.getComponent().getClassName())
                && (aInfo.launchMode == LAUNCH_MULTIPLE
                || aInfo.launchMode == LAUNCH_SINGLE_TOP))) {
            mActivityComponent = _intent.getComponent();
        } else {
            mActivityComponent = new ComponentName(aInfo.packageName, aInfo.targetActivity);
        }
        taskAffinity = aInfo.taskAffinity;
        stateNotNeeded = (aInfo.flags & FLAG_STATE_NOT_NEEDED) != 0;
        appInfo = aInfo.applicationInfo;
        nonLocalizedLabel = aInfo.nonLocalizedLabel;
        labelRes = aInfo.labelRes;
        if (nonLocalizedLabel == null && labelRes == 0) {
            ApplicationInfo app = aInfo.applicationInfo;
            nonLocalizedLabel = app.nonLocalizedLabel;
            labelRes = app.labelRes;
        }
        icon = aInfo.getIconResource();
        logo = aInfo.getLogoResource();
        theme = aInfo.getThemeResource();
        realTheme = theme;
        if (realTheme == 0) {
            realTheme = aInfo.applicationInfo.targetSdkVersion < HONEYCOMB
                    ? android.R.style.Theme : android.R.style.Theme_Holo;
        }
        if ((aInfo.flags & ActivityInfo.FLAG_HARDWARE_ACCELERATED) != 0) {
            windowFlags |= LayoutParams.FLAG_HARDWARE_ACCELERATED;
        }
        if ((aInfo.flags & FLAG_MULTIPROCESS) != 0 && _caller != null
                && (aInfo.applicationInfo.uid == SYSTEM_UID
                    || aInfo.applicationInfo.uid == _caller.mInfo.uid)) {
            processName = _caller.mName;
        } else {
            processName = aInfo.processName;
        }

        if ((aInfo.flags & FLAG_EXCLUDE_FROM_RECENTS) != 0) {
            intent.addFlags(FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        }

        packageName = aInfo.applicationInfo.packageName;
        launchMode = aInfo.launchMode;

        Entry ent = AttributeCache.instance().get(packageName,
                realTheme, com.android.internal.R.styleable.Window, mUserId);

        if (ent != null) {
            fullscreen = !ActivityInfo.isTranslucentOrFloating(ent.array);
            hasWallpaper = ent.array.getBoolean(R.styleable.Window_windowShowWallpaper, false);
            noDisplay = ent.array.getBoolean(R.styleable.Window_windowNoDisplay, false);
        } else {
            hasWallpaper = false;
            noDisplay = false;
        }

        setActivityType(_componentSpecified, _launchedFromUid, _intent, options, sourceRecord);

        immersive = (aInfo.flags & FLAG_IMMERSIVE) != 0;

        requestedVrComponent = (aInfo.requestedVrComponent == null) ?
                null : ComponentName.unflattenFromString(aInfo.requestedVrComponent);

        mShowWhenLocked = (aInfo.flags & FLAG_SHOW_WHEN_LOCKED) != 0;
        mInheritShownWhenLocked = (aInfo.privateFlags & FLAG_INHERIT_SHOW_WHEN_LOCKED) != 0;
        mTurnScreenOn = (aInfo.flags & FLAG_TURN_SCREEN_ON) != 0;

        mRotationAnimationHint = aInfo.rotationAnimation;
        lockTaskLaunchMode = aInfo.lockTaskLaunchMode;
        if (appInfo.isPrivilegedApp() && (lockTaskLaunchMode == LOCK_TASK_LAUNCH_MODE_ALWAYS
                || lockTaskLaunchMode == LOCK_TASK_LAUNCH_MODE_NEVER)) {
            lockTaskLaunchMode = LOCK_TASK_LAUNCH_MODE_DEFAULT;
        }

        if (options != null) {
            pendingOptions = options;
            mLaunchTaskBehind = options.getLaunchTaskBehind();

            final int rotationAnimation = pendingOptions.getRotationAnimationHint();
            // Only override manifest supplied option if set.
            if (rotationAnimation >= 0) {
                mRotationAnimationHint = rotationAnimation;
            }
            final PendingIntent usageReport = pendingOptions.getUsageTimeReport();
            if (usageReport != null) {
                appTimeTracker = new AppTimeTracker(usageReport);
            }
            final boolean useLockTask = pendingOptions.getLockTaskMode();
            if (useLockTask && lockTaskLaunchMode == LOCK_TASK_LAUNCH_MODE_DEFAULT) {
                lockTaskLaunchMode = LOCK_TASK_LAUNCH_MODE_IF_WHITELISTED;
            }
            // Gets launch display id from options. It returns INVALID_DISPLAY if not set.
            mHandoverLaunchDisplayId = options.getLaunchDisplayId();
        }
        supportThumbnail = PerformanceManagerInternal.getDefault().pkgSupportRecentThumbnail(packageName);
    }
```

在构造函数中packageName = aInfo.applicationInfo.packageName; 赋值 由于是final类型所以不能调用


## 4.Camera2退出屏幕旋转为横屏的功能实现


###   4.1. 在ActivityRecord中增加获取包名的方法如下：



```
        public String getCurPackageName(){
		return packageName;
	}
```

###   4.2.在ATMS中finishActivity增加旋转屏幕功能



```
 public final boolean finishActivity(IBinder token, int resultCode, Intent resultData,
            int finishTask) {
        // Refuse possible leaked file descriptors
        if (resultData != null && resultData.hasFileDescriptors()) {
            throw new IllegalArgumentException("File descriptors passed in Intent");
        }

        synchronized (mGlobalLock) {
            ActivityRecord r = ActivityRecord.isInStackLocked(token);
            if (r == null) {
                return true;
            }

          //add code start
			String pkgname = r.getCurPackageName();
			android.util.Log.e("ATMS","pkgname:"+pkgname);
			if(pkgname!=null&&pkgname.equals("com.android.camera2")){
				setRequestedOrientation(token,ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
			}
      //add code end



            // Keep track of the root activity of the task before we finish it
            final TaskRecord tr = r.getTaskRecord();
            ActivityRecord rootR = tr.getRootActivity();
            if (rootR == null) {
                Slog.w(TAG, "Finishing task with all activities already finished");
            }
            // Do not allow task to finish if last task in lockTask mode. Launchable priv-apps can
            // finish.
            if (getLockTaskController().activityBlockedFromFinish(r)) {
                return false;
            }

            // TODO: There is a dup. of this block of code in ActivityStack.navigateUpToLocked
            // We should consolidate.
            if (mController != null) {
                // Find the first activity that is not finishing.
                ActivityRecord next = r.getActivityStack().topRunningActivityLocked(token, 0);

                // SPRD:bug778642, widen the finish request check area.
                ActivityStack homeStack = mRootActivityContainer.getDefaultDisplay().getHomeStack();
                if (next == null && homeStack != null && r.isActivityTypeHome()) {
                    next = homeStack.topRunningActivityLocked();
                    Slog.i(TAG, "Adjust the next resume activity check to " + next + " for "
                            + r + " finish request.");
                    // The home stack top running activity is null, we need to check the home
                    // activity package for monkey test. Ensure that not finish the last activity
                    // of the monkey white list packages, so that we can avoid the refuse of start
                    // home acivity which may make ANR happen.
                    if (next == null) {
                        boolean resumeOK = true;
                        ActivityInfo aInfo = null;
                        try {
                            aInfo = AppGlobals.getPackageManager().getActivityInfo(
                                    getHomeIntent().getComponent(), STOCK_PM_FLAGS, UserHandle.getCallingUserId());
                        } catch (RemoteException e) {
                            //ignore
                        }
                        if (aInfo != null) {
                            try {
                                resumeOK = mController.activityResuming(aInfo.packageName);
                            } catch (RemoteException e) {
                                mController = null;
                                Watchdog.getInstance().setActivityController(null);
                            }

                            if (!resumeOK) {
                                Slog.i(TAG, "Not finishing activity because controller resumed,"
                                        + " check packageName:" + aInfo.packageName);
                                return false;
                            }
                        }
                    }
                }

                if (next != null) {
                    // ask watcher if this is allowed
                    boolean resumeOK = true;
                    try {
                        resumeOK = mController.activityResuming(next.packageName);
                    } catch (RemoteException e) {
                        mController = null;
                        Watchdog.getInstance().setActivityController(null);
                    }

                    if (!resumeOK) {
                        Slog.i(TAG, "Not finishing activity because controller resumed");
                        return false;
                    }
                }
            }

            // note down that the process has finished an activity and is in background activity
            // starts grace period
            if (r.app != null) {
                r.app.setLastActivityFinishTimeIfNeeded(SystemClock.uptimeMillis());
            }

            final long origId = Binder.clearCallingIdentity();
            try {
                boolean res;
                final boolean finishWithRootActivity =
                        finishTask == Activity.FINISH_TASK_WITH_ROOT_ACTIVITY;
                if (finishTask == Activity.FINISH_TASK_WITH_ACTIVITY
                        || (finishWithRootActivity && r == rootR)) {
                    // If requested, remove the task that is associated to this activity only if it
                    // was the root activity in the task. The result code and data is ignored
                    // because we don't support returning them across task boundaries. Also, to
                    // keep backwards compatibility we remove the task from recents when finishing
                    // task with root activity.
                    res = mStackSupervisor.removeTaskByIdLocked(tr.taskId, false,
                            finishWithRootActivity, "finish-activity");
                    if (!res) {
                        Slog.i(TAG, "Removing task failed to finish activity");
                    }
                    // Explicitly dismissing the activity so reset its relaunch flag.
                    r.mRelaunchReason = RELAUNCH_REASON_NONE;
                } else {
                    res = tr.getStack().requestFinishActivityLocked(token, resultCode,
                            resultData, "app-request", true);
                    if (!res) {
                        Slog.i(TAG, "Failed to finish by app-request");
                    }
                }
                return res;
            } finally {
                Binder.restoreCallingIdentity(origId);
            }
        }
    }
```



