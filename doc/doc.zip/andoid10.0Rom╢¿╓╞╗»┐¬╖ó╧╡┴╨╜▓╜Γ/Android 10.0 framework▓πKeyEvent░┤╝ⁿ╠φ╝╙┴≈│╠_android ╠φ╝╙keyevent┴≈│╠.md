






在Tv定制化开发中，会增加些遥控按键值，下面就Framework层添加KeyEvent按键流程做简单讲解  
 如下:


第一步:


通过adb shell getevent查看驱动按键值上报情况


命令如下:



```
adb shell getevent
 
打印值如下：

```

C:\Users\admin>



```
/dev/input/event2: 0001 00d5 00000001
/dev/input/event2: 0000 0000 00000000
/dev/input/event2: 0001 00d5 00000000
/dev/input/event2: 0000 0000 00000000

```

其中：  
 00d5: 是十六进制数，对应十进制数为213.  
 而 0001 00d5 00000001 则代表按键按下的动作


0001 00d5 00000000则代表按键弹起的动作。  
 说明驱动上报事件已经正确上报


下面在添加Device下的


device/sprd/sharkl5Pro/common/rootdir/system/usr/keylayout/gpio-keys.kl文件中添加自定义key值


在kl文件中我们可以仿照power键添加key 值。



```
+++ b/device/sprd/sharkl5Pro/common/rootdir/system/usr/keylayout/gpio-keys.kl

```


```
@@ -3,3 +3,4 @@ key 115     VOLUME_UP       WAKE
 key 116     POWER           WAKE
 key 212     CAMERA          WAKE
 key 0x210   FOCUS           WAKE
+key 213     KEY_YES          WAKE

```

这样就可以完成物理按键 kl 文件到 KEY\_YES的映射。


这个kl 文件是通过DeviceCommon.mk中编译到系统中，当驱动上报按键事件时，会查询对应的按键值 上报到framwork


第二步:


在frameworks/base/data/keyboards/Generic.kl文件中添加自定义的key值


修改方法如下：



```
+++ b/frameworks/base/data/keyboards/Generic.kl

```


```
# Copyright (C) 2010 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# Generic key layout file for full alphabetic US English PC style external keyboards.
#
# This file is intentionally very generic and is intended to support a broad range of keyboards.
# Do not edit the generic key layout to support a specific keyboard; instead, create
# a new key layout file with the required keyboard configuration.
#

key 1     ESCAPE
key 2     1
key 3     2
key 4     3
key 5     4
key 6     5
key 7     6
key 8     7
key 9     8
key 10    9
key 11    0
key 12    MINUS
key 13    EQUALS
key 14    DEL
key 15    TAB
key 16    Q
key 17    W
key 18    E
key 19    R
key 20    T
key 21    Y
key 22    U
key 23    I
key 24    O
key 25    P
key 26    LEFT_BRACKET
key 27    RIGHT_BRACKET
key 28    ENTER
key 29    CTRL_LEFT
key 30    A
key 31    S
key 32    D
key 33    F
key 34    G
key 35    H
key 36    J
key 37    K
key 38    L
key 39    SEMICOLON
key 40    APOSTROPHE
key 41    GRAVE
key 42    SHIFT_LEFT
key 43    BACKSLASH
key 44    Z
key 45    X
key 46    C
key 47    V
key 48    B
key 49    N
key 50    M
key 51    COMMA
key 52    PERIOD
key 53    SLASH
key 54    SHIFT_RIGHT
key 55    NUMPAD_MULTIPLY
key 56    ALT_LEFT
key 57    SPACE
key 58    CAPS_LOCK
key 59    F1
key 60    F2
key 61    F3
key 62    F4
key 63    F5
key 64    F6
key 65    F7
key 66    F8
key 67    F9
key 68    F10
key 69    NUM_LOCK
key 70    SCROLL_LOCK
key 71    NUMPAD_7
key 72    NUMPAD_8
key 73    NUMPAD_9
key 74    NUMPAD_SUBTRACT
key 75    NUMPAD_4
key 76    NUMPAD_5
key 77    NUMPAD_6
key 78    NUMPAD_ADD
key 79    NUMPAD_1
key 80    NUMPAD_2
key 81    NUMPAD_3
key 82    NUMPAD_0
key 83    NUMPAD_DOT
# key 84 (undefined)
key 85    ZENKAKU_HANKAKU
key 86    BACKSLASH
key 87    F11
key 88    F12
key 89    RO
# key 90 "KEY\_KATAKANA"
# key 91 "KEY\_HIRAGANA"
key 92    HENKAN
key 93    KATAKANA_HIRAGANA
key 94    MUHENKAN
key 95    NUMPAD_COMMA
key 96    NUMPAD_ENTER
key 97    CTRL_RIGHT
key 98    NUMPAD_DIVIDE
key 99    SYSRQ
key 100   ALT_RIGHT
# key 101 "KEY\_LINEFEED"
key 102   MOVE_HOME
key 103   DPAD_UP
key 104   PAGE_UP
key 105   DPAD_LEFT
key 106   DPAD_RIGHT
key 107   MOVE_END
key 108   DPAD_DOWN
key 109   PAGE_DOWN
key 110   INSERT
key 111   FORWARD_DEL
# key 112 "KEY\_MACRO"
key 113   VOLUME_MUTE
key 114   VOLUME_DOWN
key 115   VOLUME_UP
key 116   POWER
key 117   NUMPAD_EQUALS
# key 118 "KEY\_KPPLUSMINUS"
key 119   BREAK
# key 120 (undefined)
key 121   NUMPAD_COMMA
key 122   KANA
key 123   EISU
key 124   YEN
key 125   META_LEFT
key 126   META_RIGHT
key 127   MENU
key 128   MEDIA_STOP
# key 129 "KEY\_AGAIN"
# key 130 "KEY\_PROPS"
# key 131 "KEY\_UNDO"
# key 132 "KEY\_FRONT"
key 133   COPY
# key 134 "KEY\_OPEN"
key 135   PASTE
# key 136 "KEY\_FIND"
key 137   CUT
# key 138 "KEY\_HELP"
key 139   MENU
key 140   CALCULATOR
# key 141 "KEY\_SETUP"
key 142   SLEEP
key 143   WAKEUP
# key 144 "KEY\_FILE"
# key 145 "KEY\_SENDFILE"
# key 146 "KEY\_DELETEFILE"
# key 147 "KEY\_XFER"
# key 148 "KEY\_PROG1"
# key 149 "KEY\_PROG2"
key 150   EXPLORER
# key 151 "KEY\_MSDOS"
key 152   POWER
# key 153 "KEY\_DIRECTION"
# key 154 "KEY\_CYCLEWINDOWS"
key 155   ENVELOPE
key 156   BOOKMARK
# key 157 "KEY\_COMPUTER"
key 158   BACK
key 159   FORWARD
key 160   MEDIA_CLOSE
key 161   MEDIA_EJECT
key 162   MEDIA_EJECT
key 163   MEDIA_NEXT
key 164   MEDIA_PLAY_PAUSE
key 165   MEDIA_PREVIOUS
key 166   MEDIA_STOP
key 167   MEDIA_RECORD
key 168   MEDIA_REWIND
key 169   CALL
# key 170 "KEY\_ISO"
key 171   MUSIC
key 172   HOME
key 173   REFRESH
# key 174 "KEY\_EXIT"
# key 175 "KEY\_MOVE"
# key 176 "KEY\_EDIT"
key 177   PAGE_UP
key 178   PAGE_DOWN
key 179   NUMPAD_LEFT_PAREN
key 180   NUMPAD_RIGHT_PAREN
# key 181 "KEY\_NEW"
# key 182 "KEY\_REDO"
# key 183 F13
# key 184 F14
# key 185 F15
# key 186 F16
# key 187 F17
# key 188 F18
# key 189 F19
# key 190 F20
# key 191 F21
# key 192 F22
# key 193 F23
# key 194 F24
# key 195 (undefined)
# key 196 (undefined)
# key 197 (undefined)
# key 198 (undefined)
# key 199 (undefined)
key 200   MEDIA_PLAY
key 201   MEDIA_PAUSE
# key 202 "KEY\_PROG3"
# key 203 "KEY\_PROG4"
# key 204 (undefined)
# key 205 "KEY\_SUSPEND"
# key 206 "KEY\_CLOSE"
key 207   MEDIA_PLAY
key 208   MEDIA_FAST_FORWARD
# key 209 "KEY\_BASSBOOST"
# key 210 "KEY\_PRINT"
# key 211 "KEY\_HP"
key 212   CAMERA
key 213   MUSIC
# key 214 "KEY\_QUESTION"
key 215   ENVELOPE
# key 216 "KEY\_CHAT"
key 217   SEARCH
# key 218 "KEY\_CONNECT"
# key 219 "KEY\_FINANCE"
# key 220 "KEY\_SPORT"
# key 221 "KEY\_SHOP"
# key 222 "KEY\_ALTERASE"
# key 223 "KEY\_CANCEL"
key 224   BRIGHTNESS_DOWN
key 225   BRIGHTNESS_UP
key 226   HEADSETHOOK

key 256   BUTTON_1
key 257   BUTTON_2
key 258   BUTTON_3
key 259   BUTTON_4
key 260   BUTTON_5
key 261   BUTTON_6
key 262   BUTTON_7
key 263   BUTTON_8
key 264   BUTTON_9
key 265   BUTTON_10
key 266   BUTTON_11
key 267   BUTTON_12
key 268   BUTTON_13
key 269   BUTTON_14
key 270   BUTTON_15
key 271   BUTTON_16
+ key 213 KEY_YES
key 288   BUTTON_1
key 289   BUTTON_2
key 290   BUTTON_3
key 291   BUTTON_4
key 292   BUTTON_5
key 293   BUTTON_6
key 294   BUTTON_7
key 295   BUTTON_8
key 296   BUTTON_9
key 297   BUTTON_10
key 298   BUTTON_11
key 299   BUTTON_12
key 300   BUTTON_13
key 301   BUTTON_14
key 302   BUTTON_15
key 303   BUTTON_16


key 304   BUTTON_A
key 305   BUTTON_B
key 306   BUTTON_C
key 307   BUTTON_X
key 308   BUTTON_Y
key 309   BUTTON_Z
key 310   BUTTON_L1
key 311   BUTTON_R1
key 312   BUTTON_L2
key 313   BUTTON_R2
key 314   BUTTON_SELECT
key 315   BUTTON_START
key 316   BUTTON_MODE
key 317   BUTTON_THUMBL
key 318   BUTTON_THUMBR


# key 352 "KEY\_OK"
key 353   DPAD_CENTER
# key 354 "KEY\_GOTO"
# key 355 "KEY\_CLEAR"
# key 356 "KEY\_POWER2"
# key 357 "KEY\_OPTION"
# key 358 "KEY\_INFO"
# key 359 "KEY\_TIME"
# key 360 "KEY\_VENDOR"
# key 361 "KEY\_ARCHIVE"
key 362   GUIDE
# key 363 "KEY\_CHANNEL"
# key 364 "KEY\_FAVORITES"
# key 365 "KEY\_EPG"
key 366   DVR
# key 367 "KEY\_MHP"
# key 368 "KEY\_LANGUAGE"
# key 369 "KEY\_TITLE"
# key 370 "KEY\_SUBTITLE"
# key 371 "KEY\_ANGLE"
# key 372 "KEY\_ZOOM"
# key 373 "KEY\_MODE"
# key 374 "KEY\_KEYBOARD"
# key 375 "KEY\_SCREEN"
# key 376 "KEY\_PC"
key 377   TV
# key 378 "KEY\_TV2"
# key 379 "KEY\_VCR"
# key 380 "KEY\_VCR2"
# key 381 "KEY\_SAT"
# key 382 "KEY\_SAT2"
# key 383 "KEY\_CD"
# key 384 "KEY\_TAPE"
# key 385 "KEY\_RADIO"
# key 386 "KEY\_TUNER"
# key 387 "KEY\_PLAYER"
# key 388 "KEY\_TEXT"
# key 389 "KEY\_DVD"
# key 390 "KEY\_AUX"
# key 391 "KEY\_MP3"
# key 392 "KEY\_AUDIO"
# key 393 "KEY\_VIDEO"
# key 394 "KEY\_DIRECTORY"
# key 395 "KEY\_LIST"
# key 396 "KEY\_MEMO"
key 397   CALENDAR
# key 398 "KEY\_RED"
# key 399 "KEY\_GREEN"
# key 400 "KEY\_YELLOW"
# key 401 "KEY\_BLUE"
key 402   CHANNEL_UP
key 403   CHANNEL_DOWN
# key 404 "KEY\_FIRST"
# key 405 "KEY\_LAST"
# key 406 "KEY\_AB"
# key 407 "KEY\_NEXT"
# key 408 "KEY\_RESTART"
# key 409 "KEY\_SLOW"
# key 410 "KEY\_SHUFFLE"
# key 411 "KEY\_BREAK"
# key 412 "KEY\_PREVIOUS"
# key 413 "KEY\_DIGITS"
# key 414 "KEY\_TEEN"
# key 415 "KEY\_TWEN"

key 429   CONTACTS

# key 448 "KEY\_DEL\_EOL"
# key 449 "KEY\_DEL\_EOS"
# key 450 "KEY\_INS\_LINE"
# key 451 "KEY\_DEL\_LINE"


key 464   FUNCTION
key 465   ESCAPE            FUNCTION
key 466   F1                FUNCTION
key 467   F2                FUNCTION
key 468   F3                FUNCTION
key 469   F4                FUNCTION
key 470   F5                FUNCTION
key 471   F6                FUNCTION
key 472   F7                FUNCTION
key 473   F8                FUNCTION
key 474   F9                FUNCTION
key 475   F10               FUNCTION
key 476   F11               FUNCTION
key 477   F12               FUNCTION
key 478   1                 FUNCTION
key 479   2                 FUNCTION
key 480   D                 FUNCTION
key 481   E                 FUNCTION
key 482   F                 FUNCTION
key 483   S                 FUNCTION
key 484   B                 FUNCTION


# key 497 KEY\_BRL\_DOT1
# key 498 KEY\_BRL\_DOT2
# key 499 KEY\_BRL\_DOT3
# key 500 KEY\_BRL\_DOT4
# key 501 KEY\_BRL\_DOT5
# key 502 KEY\_BRL\_DOT6
# key 503 KEY\_BRL\_DOT7
# key 504 KEY\_BRL\_DOT8

key 522   STAR
key 523   POUND
key 580   APP_SWITCH
key 582   VOICE_ASSIST

# Keys defined by HID usages
key usage 0x0c006F BRIGHTNESS_UP
key usage 0x0c0070 BRIGHTNESS_DOWN

# Joystick and game controller axes.
# Axes that are not mapped will be assigned generic axis numbers by the input subsystem.
axis 0x00 X
axis 0x01 Y
axis 0x02 Z
axis 0x03 RX
axis 0x04 RY
axis 0x05 RZ
axis 0x06 THROTTLE
axis 0x07 RUDDER
axis 0x08 WHEEL
axis 0x09 GAS
axis 0x0a BRAKE
axis 0x10 HAT_X
axis 0x11 HAT_Y

# LEDs
led 0x00 NUM_LOCK
led 0x01 CAPS_LOCK
led 0x02 SCROLL_LOCK
led 0x03 COMPOSE
led 0x04 KANA
led 0x05 SLEEP
led 0x06 SUSPEND
led 0x07 MUTE
led 0x08 MISC
led 0x09 MAIL
led 0x0a CHARGING

```

第三步：


在 /frameworks/base/data/keyboards/qwerty.kl文件中添加自定义key值


修改方法如下：



```
    +++ b/frameworks/base/data/keyboards/qwerty.kl
# Copyright (C) 2010 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# Emulator keyboard layout #1.
#
# This file is no longer used as the platform's default keyboard layout.
# Refer to Generic.kl instead.
#

key 399   GRAVE
key 2     1
key 3     2
key 4     3
key 5     4
key 6     5
key 7     6
key 8     7
key 9     8
key 10    9
key 11    0
key 158   BACK
key 230   SOFT_RIGHT
key 60    SOFT_LEFT
key 107   ENDCALL
key 62    ENDCALL
key 229   MENU
key 139   MENU
key 59    MENU
key 127   SEARCH
key 217   SEARCH
key 228   POUND
key 227   STAR
key 231   CALL
key 61    CALL
key 232   DPAD_CENTER
key 108   DPAD_DOWN
key 103   DPAD_UP
key 102   HOME
key 105   DPAD_LEFT
key 106   DPAD_RIGHT
key 115   VOLUME_UP
key 114   VOLUME_DOWN
key 116   POWER
key 212   CAMERA

key 16    Q
key 17    W
key 18    E
key 19    R
key 20    T
key 21    Y
key 22    U
key 23    I
key 24    O
key 25    P
key 26    LEFT_BRACKET
key 27    RIGHT_BRACKET
key 43    BACKSLASH

key 30    A
key 31    S
key 32    D
key 33    F
key 34    G
key 35    H
key 36    J
key 37    K
key 38    L
key 39    SEMICOLON
key 40    APOSTROPHE
key 14    DEL

key 44    Z
key 45    X
key 46    C
key 47    V
key 48    B
key 49    N
key 50    M
key 51    COMMA
key 52    PERIOD
key 53    SLASH
key 28    ENTER

key 56    ALT_LEFT
key 100   ALT_RIGHT
key 42    SHIFT_LEFT
key 54    SHIFT_RIGHT
key 15    TAB
key 57    SPACE
key 150   EXPLORER
key 155   ENVELOPE

key 12    MINUS
key 13    EQUALS
key 215   AT

# On an AT keyboard: ESC, F10
key 1     BACK
key 68    MENU

# App switch = Overview key
key 580   APP_SWITCH

# Media control keys
key 160   MEDIA_CLOSE
key 161   MEDIA_EJECT
key 163   MEDIA_NEXT
key 164   MEDIA_PLAY_PAUSE
key 165   MEDIA_PREVIOUS
key 166   MEDIA_STOP
key 167   MEDIA_RECORD
key 168   MEDIA_REWIND
+ key 213 KEY_YES
key 142   SLEEP
key 581   STEM_PRIMARY
key 582   STEM_1
key 583   STEM_2
key 584   STEM_3

```

第四步：


在Native 层frameworks/native/include/android/keycodes.h添加keycode 值与标签


注意下面的289 keycode 值，是延续上面288 keycode 的值，跟驱动上报的213不一样，那是底层的数值，上层最好跟底层差分。


修改方法如下：



```
+++ b frameworks/native/include/android/keycodes.h
@@ -776,8 +776,11 @@ enum {
   /** Unknown key code. */
AKEYCODE_UNKNOWN         = 0,
/** Soft Left key.
 * Usually situated below the display on phones and used as a multi-function
 * feature key for selecting a software defined function shown on the bottom left
 * of the display. */
AKEYCODE_SOFT_LEFT       = 1,
/** Soft Right key.
 * Usually situated below the display on phones and used as a multi-function
 * feature key for selecting a software defined function shown on the bottom right
 * of the display. */
AKEYCODE_SOFT_RIGHT      = 2,
/** Home key.
 * This key is handled by the framework and is never delivered to applications. */
AKEYCODE_HOME            = 3,
/** Back key. */
AKEYCODE_BACK            = 4,
/** Call key. */
AKEYCODE_CALL            = 5,
/** End Call key. */
AKEYCODE_ENDCALL         = 6,
/** '0' key. */
AKEYCODE_0               = 7,
/** '1' key. */
AKEYCODE_1               = 8,
/** '2' key. */
AKEYCODE_2               = 9,
/** '3' key. */
AKEYCODE_3               = 10,
/** '4' key. */
AKEYCODE_4               = 11,
/** '5' key. */
AKEYCODE_5               = 12,
/** '6' key. */
AKEYCODE_6               = 13,
/** '7' key. */
AKEYCODE_7               = 14,
/** '8' key. */
AKEYCODE_8               = 15,
/** '9' key. */
AKEYCODE_9               = 16,
/** '\*' key. */
AKEYCODE_STAR            = 17,
/** '#' key. */
AKEYCODE_POUND           = 18,
/** Directional Pad Up key.
 * May also be synthesized from trackball motions. */
AKEYCODE_DPAD_UP         = 19,
/** Directional Pad Down key.
 * May also be synthesized from trackball motions. */
AKEYCODE_DPAD_DOWN       = 20,
/** Directional Pad Left key.
 * May also be synthesized from trackball motions. */
AKEYCODE_DPAD_LEFT       = 21,
/** Directional Pad Right key.
 * May also be synthesized from trackball motions. */
AKEYCODE_DPAD_RIGHT      = 22,
/** Directional Pad Center key.
 * May also be synthesized from trackball motions. */
AKEYCODE_DPAD_CENTER     = 23,
/** Volume Up key.
 * Adjusts the speaker volume up. */
AKEYCODE_VOLUME_UP       = 24,
/** Volume Down key.
 * Adjusts the speaker volume down. */
AKEYCODE_VOLUME_DOWN     = 25,
/** Power key. */
AKEYCODE_POWER           = 26,
/** Camera key.
 * Used to launch a camera application or take pictures. */
AKEYCODE_CAMERA          = 27,
/** Clear key. */
AKEYCODE_CLEAR           = 28,
/** 'A' key. */
AKEYCODE_A               = 29,
/** 'B' key. */
AKEYCODE_B               = 30,
/** 'C' key. */
AKEYCODE_C               = 31,
/** 'D' key. */
AKEYCODE_D               = 32,
/** 'E' key. */
AKEYCODE_E               = 33,
/** 'F' key. */
AKEYCODE_F               = 34,
/** 'G' key. */
AKEYCODE_G               = 35,
/** 'H' key. */
AKEYCODE_H               = 36,
/** 'I' key. */
AKEYCODE_I               = 37,
/** 'J' key. */
AKEYCODE_J               = 38,
/** 'K' key. */
AKEYCODE_K               = 39,
/** 'L' key. */
AKEYCODE_L               = 40,
/** 'M' key. */
AKEYCODE_M               = 41,
/** 'N' key. */
AKEYCODE_N               = 42,
/** 'O' key. */
AKEYCODE_O               = 43,
/** 'P' key. */
AKEYCODE_P               = 44,
/** 'Q' key. */
AKEYCODE_Q               = 45,
/** 'R' key. */
AKEYCODE_R               = 46,
/** 'S' key. */
AKEYCODE_S               = 47,
/** 'T' key. */
AKEYCODE_T               = 48,
/** 'U' key. */
AKEYCODE_U               = 49,
/** 'V' key. */
AKEYCODE_V               = 50,
/** 'W' key. */
AKEYCODE_W               = 51,
/** 'X' key. */
AKEYCODE_X               = 52,
/** 'Y' key. */
AKEYCODE_Y               = 53,
/** 'Z' key. */
AKEYCODE_Z               = 54,
/** ',' key. */
AKEYCODE_COMMA           = 55,
/** '.' key. */
AKEYCODE_PERIOD          = 56,
/** Left Alt modifier key. */
AKEYCODE_ALT_LEFT        = 57,
/** Right Alt modifier key. */
AKEYCODE_ALT_RIGHT       = 58,
/** Left Shift modifier key. */
AKEYCODE_SHIFT_LEFT      = 59,
/** Right Shift modifier key. */
AKEYCODE_SHIFT_RIGHT     = 60,
/** Tab key. */
AKEYCODE_TAB             = 61,
/** Space key. */
AKEYCODE_SPACE           = 62,
/** Symbol modifier key.
 * Used to enter alternate symbols. */
AKEYCODE_SYM             = 63,
/** Explorer special function key.
 * Used to launch a browser application. */
AKEYCODE_EXPLORER        = 64,
/** Envelope special function key.
 * Used to launch a mail application. */
AKEYCODE_ENVELOPE        = 65,
/** Enter key. */
AKEYCODE_ENTER           = 66,
/** Backspace key.
 * Deletes characters before the insertion point, unlike {@link AKEYCODE_FORWARD_DEL}. */
AKEYCODE_DEL             = 67,
/** '`' (backtick) key. */
AKEYCODE_GRAVE           = 68,
/** '-'. */
AKEYCODE_MINUS           = 69,
/** '=' key. */
AKEYCODE_EQUALS          = 70,
/** '[' key. */
AKEYCODE_LEFT_BRACKET    = 71,
/** ']' key. */
AKEYCODE_RIGHT_BRACKET   = 72,
/** '\' key. */
AKEYCODE_BACKSLASH       = 73,
/** ';' key. */
AKEYCODE_SEMICOLON       = 74,
/** ''' (apostrophe) key. */
AKEYCODE_APOSTROPHE      = 75,
/** '/' key. */
AKEYCODE_SLASH           = 76,
/** '@' key. */
AKEYCODE_AT              = 77,
/** Number modifier key.
 * Used to enter numeric symbols.
 * This key is not {@link AKEYCODE_NUM_LOCK}; it is more like {@link AKEYCODE_ALT_LEFT}. */
AKEYCODE_NUM             = 78,
/** Headset Hook key.
 * Used to hang up calls and stop media. */
AKEYCODE_HEADSETHOOK     = 79,
/** Camera Focus key.
 * Used to focus the camera. */
AKEYCODE_FOCUS           = 80,
/** '+' key. */
AKEYCODE_PLUS            = 81,
/** Menu key. */
AKEYCODE_MENU            = 82,
/** Notification key. */
AKEYCODE_NOTIFICATION    = 83,
/** Search key. */
AKEYCODE_SEARCH          = 84,
/** Play/Pause media key. */
AKEYCODE\_MEDIA\_PLAY\_PAUSE= 85,
/** Stop media key. */
AKEYCODE_MEDIA_STOP      = 86,
/** Play Next media key. */
AKEYCODE_MEDIA_NEXT      = 87,
/** Play Previous media key. */
AKEYCODE_MEDIA_PREVIOUS  = 88,
/** Rewind media key. */
AKEYCODE_MEDIA_REWIND    = 89,
/** Fast Forward media key. */
AKEYCODE_MEDIA_FAST_FORWARD = 90,
/** Mute key.
 * Mutes the microphone, unlike {@link AKEYCODE_VOLUME_MUTE}. */
AKEYCODE_MUTE            = 91,
/** Page Up key. */
AKEYCODE_PAGE_UP         = 92,
/** Page Down key. */
AKEYCODE_PAGE_DOWN       = 93,
/** Picture Symbols modifier key.
 * Used to switch symbol sets (Emoji, Kao-moji). */
AKEYCODE_PICTSYMBOLS     = 94,
/** Switch Charset modifier key.
 * Used to switch character sets (Kanji, Katakana). */
AKEYCODE_SWITCH_CHARSET  = 95,
/** A Button key.
 * On a game controller, the A button should be either the button labeled A
 * or the first button on the bottom row of controller buttons. */
AKEYCODE_BUTTON_A        = 96,
/** B Button key.
 * On a game controller, the B button should be either the button labeled B
 * or the second button on the bottom row of controller buttons. */
AKEYCODE_BUTTON_B        = 97,
/** C Button key.
 * On a game controller, the C button should be either the button labeled C
 * or the third button on the bottom row of controller buttons. */
AKEYCODE_BUTTON_C        = 98,
/** X Button key.
 * On a game controller, the X button should be either the button labeled X
 * or the first button on the upper row of controller buttons. */
AKEYCODE_BUTTON_X        = 99,
/** Y Button key.
 * On a game controller, the Y button should be either the button labeled Y
 * or the second button on the upper row of controller buttons. */
AKEYCODE_BUTTON_Y        = 100,
/** Z Button key.
 * On a game controller, the Z button should be either the button labeled Z
 * or the third button on the upper row of controller buttons. */
AKEYCODE_BUTTON_Z        = 101,
/** L1 Button key.
 * On a game controller, the L1 button should be either the button labeled L1 (or L)
 * or the top left trigger button. */
AKEYCODE_BUTTON_L1       = 102,
/** R1 Button key.
 * On a game controller, the R1 button should be either the button labeled R1 (or R)
 * or the top right trigger button. */
AKEYCODE_BUTTON_R1       = 103,
/** L2 Button key.
 * On a game controller, the L2 button should be either the button labeled L2
 * or the bottom left trigger button. */
AKEYCODE_BUTTON_L2       = 104,
/** R2 Button key.
 * On a game controller, the R2 button should be either the button labeled R2
 * or the bottom right trigger button. */
AKEYCODE_BUTTON_R2       = 105,
/** Left Thumb Button key.
 * On a game controller, the left thumb button indicates that the left (or only)
 * joystick is pressed. */
AKEYCODE_BUTTON_THUMBL   = 106,
/** Right Thumb Button key.
 * On a game controller, the right thumb button indicates that the right
 * joystick is pressed. */
AKEYCODE_BUTTON_THUMBR   = 107,
/** Start Button key.
 * On a game controller, the button labeled Start. */
AKEYCODE_BUTTON_START    = 108,
/** Select Button key.
 * On a game controller, the button labeled Select. */
AKEYCODE_BUTTON_SELECT   = 109,
/** Mode Button key.
 * On a game controller, the button labeled Mode. */
AKEYCODE_BUTTON_MODE     = 110,
/** Escape key. */
AKEYCODE_ESCAPE          = 111,
/** Forward Delete key.
 * Deletes characters ahead of the insertion point, unlike {@link AKEYCODE_DEL}. */
AKEYCODE_FORWARD_DEL     = 112,
/** Left Control modifier key. */
AKEYCODE_CTRL_LEFT       = 113,
/** Right Control modifier key. */
AKEYCODE_CTRL_RIGHT      = 114,
/** Caps Lock key. */
AKEYCODE_CAPS_LOCK       = 115,
/** Scroll Lock key. */
AKEYCODE_SCROLL_LOCK     = 116,
/** Left Meta modifier key. */
AKEYCODE_META_LEFT       = 117,
/** Right Meta modifier key. */
AKEYCODE_META_RIGHT      = 118,
/** Function modifier key. */
AKEYCODE_FUNCTION        = 119,
/** System Request / Print Screen key. */
AKEYCODE_SYSRQ           = 120,
/** Break / Pause key. */
AKEYCODE_BREAK           = 121,
/** Home Movement key.
 * Used for scrolling or moving the cursor around to the start of a line
 * or to the top of a list. */
AKEYCODE_MOVE_HOME       = 122,
/** End Movement key.
 * Used for scrolling or moving the cursor around to the end of a line
 * or to the bottom of a list. */
AKEYCODE_MOVE_END        = 123,
/** Insert key.
 * Toggles insert / overwrite edit mode. */
AKEYCODE_INSERT          = 124,
/** Forward key.
 * Navigates forward in the history stack.  Complement of {@link AKEYCODE_BACK}. */
AKEYCODE_FORWARD         = 125,
/** Play media key. */
AKEYCODE_MEDIA_PLAY      = 126,
/** Pause media key. */
AKEYCODE_MEDIA_PAUSE     = 127,
/** Close media key.
 * May be used to close a CD tray, for example. */
AKEYCODE_MEDIA_CLOSE     = 128,
/** Eject media key.
 * May be used to eject a CD tray, for example. */
AKEYCODE_MEDIA_EJECT     = 129,
/** Record media key. */
AKEYCODE_MEDIA_RECORD    = 130,
/** F1 key. */
AKEYCODE_F1              = 131,
/** F2 key. */
AKEYCODE_F2              = 132,
/** F3 key. */
AKEYCODE_F3              = 133,
/** F4 key. */
AKEYCODE_F4              = 134,
/** F5 key. */
AKEYCODE_F5              = 135,
/** F6 key. */
AKEYCODE_F6              = 136,
/** F7 key. */
AKEYCODE_F7              = 137,
/** F8 key. */
AKEYCODE_F8              = 138,
/** F9 key. */
AKEYCODE_F9              = 139,
/** F10 key. */
AKEYCODE_F10             = 140,
/** F11 key. */
AKEYCODE_F11             = 141,
/** F12 key. */
AKEYCODE_F12             = 142,
/** Num Lock key.
 * This is the Num Lock key; it is different from {@link AKEYCODE_NUM}.
 * This key alters the behavior of other keys on the numeric keypad. */
AKEYCODE_NUM_LOCK        = 143,
/** Numeric keypad '0' key. */
AKEYCODE_NUMPAD_0        = 144,
/** Numeric keypad '1' key. */
AKEYCODE_NUMPAD_1        = 145,
/** Numeric keypad '2' key. */
AKEYCODE_NUMPAD_2        = 146,
/** Numeric keypad '3' key. */
AKEYCODE_NUMPAD_3        = 147,
/** Numeric keypad '4' key. */
AKEYCODE_NUMPAD_4        = 148,
/** Numeric keypad '5' key. */
AKEYCODE_NUMPAD_5        = 149,
/** Numeric keypad '6' key. */
AKEYCODE_NUMPAD_6        = 150,
/** Numeric keypad '7' key. */
AKEYCODE_NUMPAD_7        = 151,
/** Numeric keypad '8' key. */
AKEYCODE_NUMPAD_8        = 152,
/** Numeric keypad '9' key. */
AKEYCODE_NUMPAD_9        = 153,
/** Numeric keypad '/' key (for division). */
AKEYCODE_NUMPAD_DIVIDE   = 154,
/** Numeric keypad '\*' key (for multiplication). */
AKEYCODE_NUMPAD_MULTIPLY = 155,
/** Numeric keypad '-' key (for subtraction). */
AKEYCODE_NUMPAD_SUBTRACT = 156,
/** Numeric keypad '+' key (for addition). */
AKEYCODE_NUMPAD_ADD      = 157,
/** Numeric keypad '.' key (for decimals or digit grouping). */
AKEYCODE_NUMPAD_DOT      = 158,
/** Numeric keypad ',' key (for decimals or digit grouping). */
AKEYCODE_NUMPAD_COMMA    = 159,
/** Numeric keypad Enter key. */
AKEYCODE_NUMPAD_ENTER    = 160,
/** Numeric keypad '=' key. */
AKEYCODE_NUMPAD_EQUALS   = 161,
/** Numeric keypad '(' key. */
AKEYCODE_NUMPAD_LEFT_PAREN = 162,
/** Numeric keypad ')' key. */
AKEYCODE_NUMPAD_RIGHT_PAREN = 163,
/** Volume Mute key.
 * Mutes the speaker, unlike {@link AKEYCODE_MUTE}.
 * This key should normally be implemented as a toggle such that the first press
 * mutes the speaker and the second press restores the original volume. */
AKEYCODE_VOLUME_MUTE     = 164,
/** Info key.
 * Common on TV remotes to show additional information related to what is
 * currently being viewed. */
AKEYCODE_INFO            = 165,
/** Channel up key.
 * On TV remotes, increments the television channel. */
AKEYCODE_CHANNEL_UP      = 166,
/** Channel down key.
 * On TV remotes, decrements the television channel. */
AKEYCODE_CHANNEL_DOWN    = 167,
/** Zoom in key. */
AKEYCODE_ZOOM_IN         = 168,
/** Zoom out key. */
AKEYCODE_ZOOM_OUT        = 169,
/** TV key.
 * On TV remotes, switches to viewing live TV. */
AKEYCODE_TV              = 170,
/** Window key.
 * On TV remotes, toggles picture-in-picture mode or other windowing functions. */
AKEYCODE_WINDOW          = 171,
/** Guide key.
 * On TV remotes, shows a programming guide. */
AKEYCODE_GUIDE           = 172,
/** DVR key.
 * On some TV remotes, switches to a DVR mode for recorded shows. */
AKEYCODE_DVR             = 173,
/** Bookmark key.
 * On some TV remotes, bookmarks content or web pages. */
AKEYCODE_BOOKMARK        = 174,
/** Toggle captions key.
 * Switches the mode for closed-captioning text, for example during television shows. */
AKEYCODE_CAPTIONS        = 175,
/** Settings key.
 * Starts the system settings activity. */
AKEYCODE_SETTINGS        = 176,
/** TV power key.
 * On TV remotes, toggles the power on a television screen. */
AKEYCODE_TV_POWER        = 177,
/** TV input key.
 * On TV remotes, switches the input on a television screen. */
AKEYCODE_TV_INPUT        = 178,
/** Set-top-box power key.
 * On TV remotes, toggles the power on an external Set-top-box. */
AKEYCODE_STB_POWER       = 179,
/** Set-top-box input key.
 * On TV remotes, switches the input mode on an external Set-top-box. */
AKEYCODE_STB_INPUT       = 180,
/** A/V Receiver power key.
 * On TV remotes, toggles the power on an external A/V Receiver. */
AKEYCODE_AVR_POWER       = 181,
/** A/V Receiver input key.
 * On TV remotes, switches the input mode on an external A/V Receiver. */
AKEYCODE_AVR_INPUT       = 182,
/** Red "programmable" key.
 * On TV remotes, acts as a contextual/programmable key. */
AKEYCODE_PROG_RED        = 183,
/** Green "programmable" key.
 * On TV remotes, actsas a contextual/programmable key. */
AKEYCODE_PROG_GREEN      = 184,
/** Yellow "programmable" key.
 * On TV remotes, acts as a contextual/programmable key. */
AKEYCODE_PROG_YELLOW     = 185,
/** Blue "programmable" key.
 * On TV remotes, acts as a contextual/programmable key. */
AKEYCODE_PROG_BLUE       = 186,
/** App switch key.
 * Should bring up the application switcher dialog. */
AKEYCODE_APP_SWITCH      = 187,
/** Generic Game Pad Button #1.\*/
AKEYCODE_BUTTON_1        = 188,
/** Generic Game Pad Button #2.\*/
AKEYCODE_BUTTON_2        = 189,
/** Generic Game Pad Button #3.\*/
AKEYCODE_BUTTON_3        = 190,
/** Generic Game Pad Button #4.\*/
AKEYCODE_BUTTON_4        = 191,
/** Generic Game Pad Button #5.\*/
AKEYCODE_BUTTON_5        = 192,
/** Generic Game Pad Button #6.\*/
AKEYCODE_BUTTON_6        = 193,
/** Generic Game Pad Button #7.\*/
AKEYCODE_BUTTON_7        = 194,
/** Generic Game Pad Button #8.\*/
AKEYCODE_BUTTON_8        = 195,
/** Generic Game Pad Button #9.\*/
AKEYCODE_BUTTON_9        = 196,
/** Generic Game Pad Button #10.\*/
AKEYCODE_BUTTON_10       = 197,
/** Generic Game Pad Button #11.\*/
AKEYCODE_BUTTON_11       = 198,
/** Generic Game Pad Button #12.\*/
AKEYCODE_BUTTON_12       = 199,
/** Generic Game Pad Button #13.\*/
AKEYCODE_BUTTON_13       = 200,
/** Generic Game Pad Button #14.\*/
AKEYCODE_BUTTON_14       = 201,
/** Generic Game Pad Button #15.\*/
AKEYCODE_BUTTON_15       = 202,
/** Generic Game Pad Button #16.\*/
AKEYCODE_BUTTON_16       = 203,
/** Language Switch key.
 * Toggles the current input language such as switching between English and Japanese on
 * a QWERTY keyboard.  On some devices, the same function may be performed by
 * pressing Shift+Spacebar. */
AKEYCODE_LANGUAGE_SWITCH = 204,
/** Manner Mode key.
 * Toggles silent or vibrate mode on and off to make the device behave more politely
 * in certain settings such as on a crowded train.  On some devices, the key may only
 * operate when long-pressed. */
AKEYCODE_MANNER_MODE     = 205,
/** 3D Mode key.
 * Toggles the display between 2D and 3D mode. */
AKEYCODE_3D_MODE         = 206,
/** Contacts special function key.
 * Used to launch an address book application. */
AKEYCODE_CONTACTS        = 207,
/** Calendar special function key.
 * Used to launch a calendar application. */
AKEYCODE_CALENDAR        = 208,
/** Music special function key.
 * Used to launch a music player application. */
AKEYCODE_MUSIC           = 209,
/** Calculator special function key.
 * Used to launch a calculator application. */
AKEYCODE_CALCULATOR      = 210,
/** Japanese full-width / half-width key. */
AKEYCODE_ZENKAKU_HANKAKU = 211,
/** Japanese alphanumeric key. */
AKEYCODE_EISU            = 212,
/** Japanese non-conversion key. */
AKEYCODE_MUHENKAN        = 213,
/** Japanese conversion key. */
AKEYCODE_HENKAN          = 214,
/** Japanese katakana / hiragana key. */
AKEYCODE_KATAKANA_HIRAGANA = 215,
/** Japanese Yen key. */
AKEYCODE_YEN             = 216,
/** Japanese Ro key. */
AKEYCODE_RO              = 217,
/** Japanese kana key. */
AKEYCODE_KANA            = 218,
/** Assist key.
 * Launches the global assist activity.  Not delivered to applications. */
AKEYCODE_ASSIST          = 219,
/** Brightness Down key.
 * Adjusts the screen brightness down. */
AKEYCODE_BRIGHTNESS_DOWN = 220,
/** Brightness Up key.
 * Adjusts the screen brightness up. */
AKEYCODE_BRIGHTNESS_UP   = 221,
/** Audio Track key.
 * Switches the audio tracks. */
AKEYCODE_MEDIA_AUDIO_TRACK = 222,
/** Sleep key.
 * Puts the device to sleep.  Behaves somewhat like {@link AKEYCODE_POWER} but it
 * has no effect if the device is already asleep. */
AKEYCODE_SLEEP           = 223,
/** Wakeup key.
 * Wakes up the device.  Behaves somewhat like {@link AKEYCODE_POWER} but it
 * has no effect if the device is already awake. */
AKEYCODE_WAKEUP          = 224,
/** Pairing key.
 * Initiates peripheral pairing mode. Useful for pairing remote control
 * devices or game controllers, especially if no other input mode is
 * available. */
AKEYCODE_PAIRING         = 225,
/** Media Top Menu key.
 * Goes to the top of media menu. */
AKEYCODE_MEDIA_TOP_MENU  = 226,
/** '11' key. */
AKEYCODE_11              = 227,
/** '12' key. */
AKEYCODE_12              = 228,
/** Last Channel key.
 * Goes to the last viewed channel. */
AKEYCODE_LAST_CHANNEL    = 229,
/** TV data service key.
 * Displays data services like weather, sports. */
AKEYCODE_TV_DATA_SERVICE = 230,
/** Voice Assist key.
 * Launches the global voice assist activity. Not delivered to applications. */
AKEYCODE_VOICE_ASSIST    = 231,
/** Radio key.
 * Toggles TV service / Radio service. */
AKEYCODE_TV_RADIO_SERVICE = 232,
/** Teletext key.
 * Displays Teletext service. */
AKEYCODE_TV_TELETEXT     = 233,
/** Number entry key.
 * Initiates to enter multi-digit channel nubmber when each digit key is assigned
 * for selecting separate channel. Corresponds to Number Entry Mode (0x1D) of CEC
 * User Control Code. */
AKEYCODE_TV_NUMBER_ENTRY = 234,
/** Analog Terrestrial key.
 * Switches to analog terrestrial broadcast service. */
AKEYCODE_TV_TERRESTRIAL_ANALOG = 235,
/** Digital Terrestrial key.
 * Switches to digital terrestrial broadcast service. */
AKEYCODE_TV_TERRESTRIAL_DIGITAL = 236,
/** Satellite key.
 * Switches to digital satellite broadcast service. */
AKEYCODE_TV_SATELLITE    = 237,
/** BS key.
 * Switches to BS digital satellite broadcasting service available in Japan. */
AKEYCODE_TV_SATELLITE_BS = 238,
/** CS key.
 * Switches to CS digital satellite broadcasting service available in Japan. */
AKEYCODE_TV_SATELLITE_CS = 239,
/** BS/CS key.
 * Toggles between BS and CS digital satellite services. */
AKEYCODE_TV_SATELLITE_SERVICE = 240,
/** Toggle Network key.
 * Toggles selecting broacast services. */
AKEYCODE_TV_NETWORK      = 241,
/** Antenna/Cable key.
 * Toggles broadcast input source between antenna and cable. */
AKEYCODE_TV_ANTENNA_CABLE = 242,
/** HDMI #1 key.
 * Switches to HDMI input #1. \*/
AKEYCODE_TV_INPUT_HDMI_1 = 243,
/** HDMI #2 key.
 * Switches to HDMI input #2. \*/
AKEYCODE_TV_INPUT_HDMI_2 = 244,
/** HDMI #3 key.
 * Switches to HDMI input #3. \*/
AKEYCODE_TV_INPUT_HDMI_3 = 245,
/** HDMI #4 key.
 * Switches to HDMI input #4. \*/
AKEYCODE_TV_INPUT_HDMI_4 = 246,
/** Composite #1 key.
 * Switches to composite video input #1. \*/
AKEYCODE_TV_INPUT_COMPOSITE_1 = 247,
/** Composite #2 key.
 * Switches to composite video input #2. \*/
AKEYCODE_TV_INPUT_COMPOSITE_2 = 248,
/** Component #1 key.
 * Switches to component video input #1. \*/
AKEYCODE_TV_INPUT_COMPONENT_1 = 249,
/** Component #2 key.
 * Switches to component video input #2. \*/
AKEYCODE_TV_INPUT_COMPONENT_2 = 250,
/** VGA #1 key.
 * Switches to VGA (analog RGB) input #1. \*/
AKEYCODE_TV_INPUT_VGA_1  = 251,
/** Audio description key.
 * Toggles audio description off / on. */
AKEYCODE_TV_AUDIO_DESCRIPTION = 252,
/** Audio description mixing volume up key.
 * Louden audio description volume as compared with normal audio volume. */
AKEYCODE_TV_AUDIO_DESCRIPTION_MIX_UP = 253,
/** Audio description mixing volume down key.
 * Lessen audio description volume as compared with normal audio volume. */
AKEYCODE_TV_AUDIO_DESCRIPTION_MIX_DOWN = 254,
/** Zoom mode key.
 * Changes Zoom mode (Normal, Full, Zoom, Wide-zoom, etc.) */
AKEYCODE_TV_ZOOM_MODE    = 255,
/** Contents menu key.
 * Goes to the title list. Corresponds to Contents Menu (0x0B) of CEC User Control
 * Code */
AKEYCODE_TV_CONTENTS_MENU = 256,
/** Media context menu key.
 * Goes to the context menu of media contents. Corresponds to Media Context-sensitive
 * Menu (0x11) of CEC User Control Code. */
AKEYCODE_TV_MEDIA_CONTEXT_MENU = 257,
/** Timer programming key.
 * Goes to the timer recording menu. Corresponds to Timer Programming (0x54) of
 * CEC User Control Code. */
AKEYCODE_TV_TIMER_PROGRAMMING = 258,
/** Help key. */
AKEYCODE_HELP            = 259,
AKEYCODE_NAVIGATE_PREVIOUS = 260,
AKEYCODE_NAVIGATE_NEXT   = 261,
AKEYCODE_NAVIGATE_IN     = 262,
AKEYCODE_NAVIGATE_OUT    = 263,
/** Primary stem key for Wear
 * Main power/reset button on watch. */
AKEYCODE_STEM_PRIMARY = 264,
/** Generic stem key 1 for Wear */
AKEYCODE_STEM_1 = 265,
/** Generic stem key 2 for Wear */
AKEYCODE_STEM_2 = 266,
/** Generic stem key 3 for Wear */
AKEYCODE_STEM_3 = 267,
/** Directional Pad Up-Left */
AKEYCODE_DPAD_UP_LEFT    = 268,
/** Directional Pad Down-Left */
AKEYCODE_DPAD_DOWN_LEFT  = 269,
/** Directional Pad Up-Right */
AKEYCODE_DPAD_UP_RIGHT   = 270,
/** Directional Pad Down-Right */
AKEYCODE_DPAD_DOWN_RIGHT = 271,
/** Skip forward media key */
AKEYCODE_MEDIA_SKIP_FORWARD = 272,
/** Skip backward media key */
AKEYCODE_MEDIA_SKIP_BACKWARD = 273,
/** Step forward media key.
 * Steps media forward one from at a time. */
AKEYCODE_MEDIA_STEP_FORWARD = 274,
/** Step backward media key.
 * Steps media backward one from at a time. */
AKEYCODE_MEDIA_STEP_BACKWARD = 275,
/** Put device to sleep unless a wakelock is held. */
AKEYCODE_SOFT_SLEEP = 276,
/** Cut key. */
AKEYCODE_CUT = 277,
/** Copy key. */
AKEYCODE_COPY = 278,
/** Paste key. */
AKEYCODE_PASTE = 279,
/** fingerprint navigation key, up. */
AKEYCODE_SYSTEM_NAVIGATION_UP = 280,
/** fingerprint navigation key, down. */
AKEYCODE_SYSTEM_NAVIGATION_DOWN = 281,
/** fingerprint navigation key, left. */
AKEYCODE_SYSTEM_NAVIGATION_LEFT = 282,
/** fingerprint navigation key, right. */
AKEYCODE_SYSTEM_NAVIGATION_RIGHT = 283,
/** all apps */
AKEYCODE_ALL_APPS = 284,
/** refresh key */
AKEYCODE_REFRESH = 285,
/** Thumbs up key. Apps can use this to let user upvote content. */
AKEYCODE_THUMBS_UP = 286,
/** Thumbs down key. Apps can use this to let user downvote content. */
AKEYCODE_THUMBS_DOWN = 287,
+    AKEYCODE_PROFILE_SWITCH = 288,
+    /**
+       *Nokia custom key 
+       **/
+    AKEYCODE_KEY_YES = 289,

```

第五步:


在frameworks/native/include/input/InputEventLabels.h 添加自定义标签



```
+++ b frameworks/native/include/input/InputEventLabels.h
@@ -328,7 +328,7 @@ static const InputEventLabel KEYCODES[] = {
DEFINE_KEYCODE(SYSTEM_NAVIGATION_LEFT),
DEFINE_KEYCODE(SYSTEM_NAVIGATION_RIGHT),
DEFINE_KEYCODE(ALL_APPS),
DEFINE_KEYCODE(REFRESH),
DEFINE_KEYCODE(THUMBS_UP),
DEFINE_KEYCODE(THUMBS_DOWN),
DEFINE_KEYCODE(PROFILE_SWITCH),
+    DEFINE_KEYCODE(KEY_YES),

```

第六步:


在frameworks/base/core/res/res/values/attrs.xml 中添加自定义Key对应的属性值


修改方法如下：



```
+++ b/frameworks/base/core/res/res/values/attrs.xml
@@ -1924,6 +1924,7 @@
         <enum name="KEYCODE\_THUMBS\_UP" value="286" />
         <enum name="KEYCODE\_THUMBS\_DOWN" value="287" />
         <enum name="KEYCODE\_PROFILE\_SWITCH" value="288" />
+               <enum name="KEYCODE\_KEY\_OK" value="289" />
     </attr>

```

第七步:


frameworks/base/core/java/android/view/KeyEvent.java 中添加key的值


修改方法如下：



```
+++ b /frameworks/base/core/java/android/view/KeyEvent.java
@@ -823,6 +823,11 @@ public class KeyEvent extends InputEvent implements Parcelable {
      * consuming content. May be consumed by system to set account globally.
      */
     public static final int KEYCODE_PROFILE_SWITCH = 288;
+        /**
+     * Integer value of the last KEYCODE. Nokia custom  ok key.
+     * @hide
+     */
+       public static final int KEYCODE_KEY_YES = 289;

```

第八步:


在 /frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java中处理按键事件


PhoneWindowManager 的interceptKeyBeforeDispatchingInner方法处理按键事件 所有的按键事件上报后最后都会在这里处理  
 修改如下:



```
    +++ b/frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
    private long interceptKeyBeforeDispatchingInner(WindowState win, KeyEvent event,
            int policyFlags) {     

             if (mPendingCapsLockToggle && !KeyEvent.isMetaKey(keyCode) && !KeyEvent.isAltKey(keyCode)) {
                 mPendingCapsLockToggle = false;
             }
    -
    +               // add for key yes
    +               if(keyCode == KeyEvent.KEYCODE_KEY_YES){
    +                       if("SPR\_India".equals(android.os.Build.SPR)){
    +                        // 做相应的事件处理
    +                        
    +                       }
    +                       return -1;
    +               }
    +               // add for key yes
}

```

重新编译验证按键事件是否能处理





