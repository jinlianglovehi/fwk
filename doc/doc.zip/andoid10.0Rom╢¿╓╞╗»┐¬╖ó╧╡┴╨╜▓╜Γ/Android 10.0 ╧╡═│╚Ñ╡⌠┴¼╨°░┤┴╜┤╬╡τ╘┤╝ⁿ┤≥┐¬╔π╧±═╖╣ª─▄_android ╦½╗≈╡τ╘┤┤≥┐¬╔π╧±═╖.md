



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.系统去掉连续按两次电源键打开摄像头功能的核心代码](#2.%E7%B3%BB%E7%BB%9F%E5%8E%BB%E6%8E%89%E8%BF%9E%E7%BB%AD%E6%8C%89%E4%B8%A4%E6%AC%A1%E7%94%B5%E6%BA%90%E9%94%AE%E6%89%93%E5%BC%80%E6%91%84%E5%83%8F%E5%A4%B4%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.系统去掉连续按两次电源键打开摄像头功能的核心代码功能分析](#3.%E7%B3%BB%E7%BB%9F%E5%8E%BB%E6%8E%89%E8%BF%9E%E7%BB%AD%E6%8C%89%E4%B8%A4%E6%AC%A1%E7%94%B5%E6%BA%90%E9%94%AE%E6%89%93%E5%BC%80%E6%91%84%E5%83%8F%E5%A4%B4%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 PhoneWindowManager.java双击电源键打开摄像头的相关操作](#%C2%A0%203.1%20PhoneWindowManager.java%E5%8F%8C%E5%87%BB%E7%94%B5%E6%BA%90%E9%94%AE%E6%89%93%E5%BC%80%E6%91%84%E5%83%8F%E5%A4%B4%E7%9A%84%E7%9B%B8%E5%85%B3%E6%93%8D%E4%BD%9C)


[3.2 GestureLauncherService中关于双击电源键打开摄像头的相关操作](#3.2%20GestureLauncherService%E4%B8%AD%E5%85%B3%E4%BA%8E%E5%8F%8C%E5%87%BB%E7%94%B5%E6%BA%90%E9%94%AE%E6%89%93%E5%BC%80%E6%91%84%E5%83%8F%E5%A4%B4%E7%9A%84%E7%9B%B8%E5%85%B3%E6%93%8D%E4%BD%9C)




---



## 1.概述


  在系统原生的api中，保留着连续按两次电源键会打开摄像机拍照的功能，由于项目开发需要要求去掉这个功能，电源键保留亮屏息屏和开关机的相关功能所以这就需要查看两次连续按电源键进行了哪些操作流程


## 2.系统去掉连续按两次电源键打开摄像头功能的核心代码



```
  frameworks/base/services/core/java/com/android/server/GestureLauncherService.java
  frameworks/base/core/res/res/values/config.xml
  frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java
```

## 3.系统去掉连续按两次电源键打开摄像头功能的核心代码功能分析


PhoneWindowManager也是运行于systemserver线程中,在Event事件分发之前处理,比如电源键  
 PhoneWindowManager主要管理Android 手机的特定UI行为、包括定义窗口的分层、窗口的类型、  
 input事件的调度和窗口的布局。按照这些职责来划分，其实PhoneWindowManager的结构就变得比较清晰。  
 PhoneWindowManager对Android的窗口布局管理。  
 PhoneWindowManager的beginLayoutLw() 方法中构建SystemBar对应的视图窗口区域坐标对象的  
 同样在监听电源键事件  
 PhoneWindowManager对Power（KeyEvent.KEYCODE\_POWER）和Home（KeyEvent.KEYCODE\_HOME）键做了处理，不会把这些键传送上层应用程序。如需要把这些键发送给Activity和Service，需要在PhoneWindowManager处理这些键时“发送一个广播出去，然后在应用程序接收到广播后做处理”。        如果应用程序只需要获取获取待机、唤醒、关机、网络状态变化消息，则可监听以下广播消息：  
 1) 待机：  
 广播消息：Android.intent.action.SCREEN\_OFF (代码)  
 2) 唤醒：  
 广播消息：Android.intent.action.SCREEN\_ON (代码)  
 3) 关机：  
 广播消息：Android.intent.action.ACTION\_SHUTDOWN (XML或代码)  
 4) 网络状态变化：  
  广播消息：Android.Net.conn.CONNECTIVITY\_CHANGE (XML或代码)



###   3.1 PhoneWindowManager.java双击电源键打开摄像头的相关操作



```
      private void interceptPowerKeyDown(KeyEvent event, boolean interactive) {
        // Hold a wake lock until the power key is released.
        if (!mPowerKeyWakeLock.isHeld()) {
            mPowerKeyWakeLock.acquire();
        }

        // Cancel multi-press detection timeout.
        if (mPowerKeyPressCounter != 0) {
            mHandler.removeMessages(MSG_POWER_DELAYED_PRESS);
        }

        mWindowManagerFuncs.onPowerKeyDown(interactive);

        // Latch power key state to detect screenshot chord.
        if (interactive && !mScreenshotChordPowerKeyTriggered
                && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
            mScreenshotChordPowerKeyTriggered = true;
            mScreenshotChordPowerKeyTime = event.getDownTime();
            interceptScreenshotChord();
            interceptRingerToggleChord();
        }

        // Stop ringing or end call if configured to do so when power is pressed.
        TelecomManager telecomManager = getTelecommService();
        boolean hungUp = false;
        if (telecomManager != null) {
            if (telecomManager.isRinging()) {
                // Pressing Power while there's a ringing incoming
                // call should silence the ringer.
                telecomManager.silenceRinger();
            } else if ((mIncallPowerBehavior
                    & Settings.Secure.INCALL_POWER_BUTTON_BEHAVIOR_HANGUP) != 0
                    && telecomManager.isInCall() && interactive) {
                // Otherwise, if "Power button ends call" is enabled,
                // the Power button will hang up any current active call.
                hungUp = telecomManager.endCall();
            }
        }

        //SprdGestureLauncherService gestureService = LocalServices.getService(
        //        SprdGestureLauncherService.class);
        boolean gesturedServiceIntercepted = false;
        if (getGestureLauncherService()) {
            gesturedServiceIntercepted = mGestureService.interceptPowerKeyDown(event, interactive,
                    mTmpBoolean, isScreenOn(), hasInPowerUtrlSavingMode());
            if (mTmpBoolean.value && mRequestedOrGoingToSleep) {
                mCameraGestureTriggeredDuringGoingToSleep = true;
            }
        }

        // Inform the StatusBar; but do not allow it to consume the event.
        sendSystemKeyToStatusBarAsync(event.getKeyCode());

        schedulePossibleVeryLongPressReboot();

        // If the power key has still not yet been handled, then detect short
        // press, long press, or multi press and decide what to do.
        mPowerKeyHandled = hungUp || mScreenshotChordVolumeDownKeyTriggered
                || mA11yShortcutChordVolumeUpKeyTriggered || gesturedServiceIntercepted;
        
    }

    private void interceptPowerKeyUp(KeyEvent event, boolean interactive, boolean canceled) {
        final boolean handled = canceled || mPowerKeyHandled;
        mScreenshotChordPowerKeyTriggered = false;
        cancelPendingScreenshotChordAction();
        cancelPendingPowerKeyAction();

        if (!handled) {
            if ((event.getFlags() & KeyEvent.FLAG_LONG_PRESS) == 0) {
                // Abort possibly stuck animations only when power key up without long press case.
                mHandler.post(mWindowManagerFuncs::triggerAnimationFailsafe);
            }

            // Figure out how to handle the key now that it has been released.
            mPowerKeyPressCounter += 1;

            final int maxCount = getMaxMultiPressPowerCount();
            final long eventTime = event.getDownTime();
            if (mPowerKeyPressCounter < maxCount) {
                // This could be a multi-press.  Wait a little bit longer to confirm.
                // Continue holding the wake lock.
                Message msg = mHandler.obtainMessage(MSG_POWER_DELAYED_PRESS,
                        interactive ? 1 : 0, mPowerKeyPressCounter, eventTime);
                msg.setAsynchronous(true);
                mHandler.sendMessageDelayed(msg, ViewConfiguration.getMultiPressTimeout());
                return;
            }

            // No other actions.  Handle it immediately.
            powerPress(eventTime, interactive, mPowerKeyPressCounter);
        }

        // Done.  Reset our state.
        finishPowerKeyPress();
    }
```

在power键按下在interceptPowerKeyDown（）执行，松开的操作在interceptPowerKeyUp（）中执行  
 interceptPowerKeyDown（）方法中会调用 GestureLauncherService.java 的 interceptPowerKeyDown() 方法



```
GestureLauncherService gestureService = LocalServices.getService(
                GestureLauncherService.class);
        boolean gesturedServiceIntercepted = false;
        if (gestureService != null) {
            gesturedServiceIntercepted = gestureService.interceptPowerKeyDown(event, interactive,
                    mTmpBoolean);
            if (mTmpBoolean.value && mRequestedOrGoingToSleep) {
                mCameraGestureTriggeredDuringGoingToSleep = true;
            }
        }

```

接下来看下GestureLauncherService的interceptPowerKeyDown()的相关操作


### 3.2 GestureLauncherService中关于双击电源键打开摄像头的相关操作



```
public class GestureLauncherService extends SystemService {


    public GestureLauncherService(Context context) {
        this(context, new MetricsLogger());
    }

    @VisibleForTesting
    GestureLauncherService(Context context, MetricsLogger metricsLogger) {
        super(context);
        mContext = context;
        mMetricsLogger = metricsLogger;
    }
@VisibleForTesting
    void updateCameraDoubleTapPowerEnabled() {
        boolean enabled = isCameraDoubleTapPowerSettingEnabled(mContext, mUserId);
        boolean volumeEnabled = isCameraDoubleTapVolumeUpSettingEnabled(mContext, mUserId);
        synchronized (this) {
            mCameraDoubleTapPowerEnabled = enabled;
            mCameraDoubleTapVolumeUpEnabled = volumeEnabled;
        }
    }



    /**
     * Whether GestureLauncherService should be enabled according to system properties.
     */
    public static boolean isGestureLauncherEnabled(Resources resources) {
        return isCameraLaunchEnabled(resources) || isCameraDoubleTapPowerEnabled(resources) ||
                isCameraLiftTriggerEnabled(resources) || isCameraDoubleTapVolumeUpEnabled(resources);
    }

    public boolean interceptPowerKeyDown(KeyEvent event, boolean interactive,
            MutableBoolean outLaunched) {
        return interceptPowerKeyDown(event, interactive, outLaunched, false);
    }

    public boolean interceptPowerKeyDown(KeyEvent event, boolean interactive,
            MutableBoolean outLaunched, boolean isScreenOn) {
        if (event.isLongPress()) {
            // Long presses are sent as a second key down. If the long press threshold is set lower
            // than the double tap of sequence interval thresholds, this could cause false double
            // taps or consecutive taps, so we want to ignore the long press event.
            return false;
        }
        boolean launched = false;
        boolean intercept = false;
        long powerTapInterval;
        synchronized (this) {
            powerTapInterval = event.getEventTime() - mLastPowerDown;
            if (mCameraDoubleTapPowerEnabled
                    && powerTapInterval < CAMERA_POWER_DOUBLE_TAP_MAX_TIME_MS) {
                launched = true;
                intercept = interactive;
                mPowerButtonConsecutiveTaps++;
            //unisoc: double power key, open camera
            } else if (mCameraDoubleTapPowerEnabled
                    && powerTapInterval > CAMERA_POWER_DOUBLE_TAP_MAX_TIME_MS
                    && isScreenOn && mPowerButtonConsecutiveTaps == 1) {//双击事件
                isDelayCamera = true;
            } else if (powerTapInterval < POWER_SHORT_TAP_SEQUENCE_MAX_INTERVAL_MS) {//延迟双击事件
                mPowerButtonConsecutiveTaps++;
            } else {//单击事件
                mPowerButtonConsecutiveTaps = 1;
                //unisoc: double power key, open camera
                isDelayCamera = false;
            }
            mLastPowerDown = event.getEventTime();
            if(launched && mPowerButtonConsecutiveTaps > 2){
                Slog.i(TAG, "Do not receive more power key, because Quick Camera is start");
                return  intercept && launched;
            }
        }
        if (DBG && mPowerButtonConsecutiveTaps > 1) {
            Slog.i(TAG, Long.valueOf(mPowerButtonConsecutiveTaps) +
                    " consecutive power button taps detected");
        }
        if (launched) {
            Slog.i(TAG, "Power button double tap gesture detected, launching camera. Interval="
                    + powerTapInterval + "ms");
            //unisoc: double power key, open camera
            if(!isDelayCamera){
                launched = handleCameraGesture(false /* useWakelock */, 0);
            } else {
                launched = handleCameraGesture(false /* useWakelock */,
                        StatusBarManager.CAMERA_LAUNCH_SOURCE_POWER_DOUBLE_TAP);
            }
            if (launched) {
                mMetricsLogger.action(MetricsEvent.ACTION_DOUBLE_TAP_POWER_CAMERA_GESTURE,
                        (int) powerTapInterval);
            }
            isDelayCamera = false;
        }
        mMetricsLogger.histogram("power_consecutive_short_tap_count", mPowerButtonConsecutiveTaps);
        mMetricsLogger.histogram("power_double_tap_interval", (int) powerTapInterval);
        outLaunched.value = launched;
        return intercept && launched;
    }

    /**
     * @return true if camera was launched, false otherwise.
     */
    @VisibleForTesting
    boolean handleCameraGesture(boolean useWakelock, int source) {
        Trace.traceBegin(Trace.TRACE_TAG_ACTIVITY_MANAGER, "GestureLauncher:handleCameraGesture");
        try {
            boolean userSetupComplete = Settings.Secure.getIntForUser(mContext.getContentResolver(),
                    Settings.Secure.USER_SETUP_COMPLETE, 0, UserHandle.USER_CURRENT) != 0;
            if (!userSetupComplete) {
                if (DBG) {
                    Slog.d(TAG, String.format(
                            "userSetupComplete = %s, ignoring camera gesture.",
                            userSetupComplete));
                }
                return false;
            }
            if (DBG) {
                Slog.d(TAG, String.format(
                        "userSetupComplete = %s, performing camera gesture.",
                        userSetupComplete));
            }

            if (useWakelock) {
                // Make sure we don't sleep too early
                mWakeLock.acquire(500L);
            }
            StatusBarManagerInternal service = LocalServices.getService(
                    StatusBarManagerInternal.class);
            service.onCameraLaunchGestureDetected(source);
            return true;
        } finally {
            Trace.traceEnd(Trace.TRACE_TAG_ACTIVITY_MANAGER);
        }
    }

}
```

在interceptPowerKeyDown(）中处理单双击事件，经过分析得知  
 而把mCameraDoubleTapPowerEnabled的值为true时 就不会双击启动相机  
     public static boolean isCameraDoubleTapPowerEnabled(Resources resources) {  
         return resources.getBoolean(  
                 com.android.internal.R.bool.config\_cameraDoubleTapPowerGestureEnabled);  
     }  
 具体修改如下:



```
--- a/frameworks/base/core/res/res/values/config.xml
+++ b/frameworks/base/core/res/res/values/config.xml
@@ -3258,7 +3258,7 @@
 
     <!-- Allow the gesture to double tap the power button twice to start the camera while the device
          is non-interactive. -->
-    <bool name="config_cameraDoubleTapPowerGestureEnabled">false</bool>
+    <bool name="config_cameraDoubleTapPowerGestureEnabled">true</bool>
 
     <!-- Allow the gesture to double tap the volumeup button twice to start the camera while the device
          is non-interactive. -->
```



