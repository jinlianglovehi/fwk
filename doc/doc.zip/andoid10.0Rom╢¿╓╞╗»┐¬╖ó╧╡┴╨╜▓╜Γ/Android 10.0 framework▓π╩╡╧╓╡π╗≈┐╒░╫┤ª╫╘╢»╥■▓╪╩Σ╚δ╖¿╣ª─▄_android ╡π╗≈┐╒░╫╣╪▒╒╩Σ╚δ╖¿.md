



## 1.前言


在10.0的系统rom产品定制化开发中，在进行一些定制开发中，在某些无源码的app中，如果app中没实现点击空白区域外  
 自动隐藏输入法功能的时候，那么就需要在系统framework层中进行相关功能的开发，接下来看下相关功能的实现


## 2.framework层实现点击空白处自动隐藏输入法功能的核心类



```
frameworks\base\core\java\android\app\Activity.java
```

## 3.framework层实现点击空白处自动隐藏输入法功能的核心功能分析和实现


关于系统中点击事件分发流程，就是在当用户触摸屏幕时，会产生一个touch事件，这个touch事件（motionEvent）传递到某个具体的view处理的整个过程  
 用户触摸屏幕会产生一个事件流（ACTION\_DOWN -> ACTION\_MOVE -> ACTION\_UP）  
 一般来说，view负责处理action\_down事件后，会由这个view来处理接下来的事件，所以就是说主要还是在Activity.java的  
 监听事件分发流程中来处理，  
 下面看下在app中如何实现点击空白区域自动隐藏输入法功能



```
      // 获取点击事件
     @Override
     public boolean dispatchTouchEvent(MotionEvent ev) {
         // TODO Auto-generated method stub
         if (ev.getAction() == MotionEvent.ACTION_DOWN) {
             View view = getCurrentFocus();
             if (isHideInput(view, ev)) {
                 HideSoftInput(view.getWindowToken());
             }
         }
         return super .dispatchTouchEvent(ev);
     }
     // 判定是否需要隐藏
     private boolean isHideInput(View v, MotionEvent ev) {
         if (v != null && (v instanceof EditText)) {
             int [] l = { 0 , 0 };
             v.getLocationInWindow(l);
             int left = l[ 0 ], top = l[ 1 ], bottom = top + v.getHeight(), right = left
                     + v.getWidth();
             if (ev.getX() > left && ev.getX() < right && ev.getY() > top
                     && ev.getY() < bottom) {
                 return false ;
             } else {
                 return true ;
             }
         }
         return false ;
     }
     // 隐藏软键盘
     private void HideSoftInput(IBinder token) {
         if (token != null ) {
             InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
             manager.hideSoftInputFromWindow(token,
                     InputMethodManager.HIDE_NOT_ALWAYS);
         }
     } 
```

根据上面在app的activity类中增加dispatchTouchEvent(MotionEvent ev)的监听，判断点击区域是否在EditText的范围内  
 不在这个范围类就来收缩输入法软键盘功能，接下来看下在framework层中如何实现这个功能


## 3.1 Activity.java中实现dispatchTouchEvent相关事件分发功能分析


activity是Android组件中最基本也是最为常见用的四大组件之一。Android四大组件有Activity，Service服务，Content Provider内容提供，BroadcastReceiver广播接收器  
 Activity是Android四大组件之一,主要功能就是实现一个可以让用户与程序交互的窗口。一般来说一个activity表示一个与用户交互的界面



```
public class Activity extends ContextThemeWrapper
        implements LayoutInflater.Factory2,
        Window.Callback, KeyEvent.Callback,
        OnCreateContextMenuListener, ComponentCallbacks2,
        Window.OnWindowDismissedCallback,
        AutofillManager.AutofillClient, ContentCaptureManager.ContentCaptureClient {
    /**
     * Called to process key events.  You can override this to intercept all
     * key events before they are dispatched to the window.  Be sure to call
     * this implementation for key events that should be handled normally.
     *
     * @param event The key event.
     *
     * @return boolean Return true if this event was consumed.
     */
    public boolean dispatchKeyEvent(KeyEvent event) {
        onUserInteraction();

        // Let action bars open menus in response to the menu key prioritized over
        // the window handling it
        final int keyCode = event.getKeyCode();
        if (keyCode == KeyEvent.KEYCODE_MENU &&
                mActionBar != null && mActionBar.onMenuKeyEvent(event)) {
            return true;
        }

        Window win = getWindow();
        if (win.superDispatchKeyEvent(event)) {
            return true;
        }
        View decor = mDecor;
        if (decor == null) decor = win.getDecorView();
        return event.dispatch(this, decor != null
                ? decor.getKeyDispatcherState() : null, this);
    }

    /**
     * Called to process a key shortcut event.
     * You can override this to intercept all key shortcut events before they are
     * dispatched to the window.  Be sure to call this implementation for key shortcut
     * events that should be handled normally.
     *
     * @param event The key shortcut event.
     * @return True if this event was consumed.
     */
    public boolean dispatchKeyShortcutEvent(KeyEvent event) {
        onUserInteraction();
        if (getWindow().superDispatchKeyShortcutEvent(event)) {
            return true;
        }
        return onKeyShortcut(event.getKeyCode(), event);
    }

    /**
     * Called to process touch screen events.  You can override this to
     * intercept all touch screen events before they are dispatched to the
     * window.  Be sure to call this implementation for touch screen events
     * that should be handled normally.
     *
     * @param ev The touch screen event.
     *
     * @return boolean Return true if this event was consumed.
     */
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            onUserInteraction();
        }
        if (getWindow().superDispatchTouchEvent(ev)) {
            return true;
        }
        return onTouchEvent(ev);
    }
```

在实现framework层实现点击空白处自动隐藏输入法功能的核心功能中，在通过上述的分析得知，在  
 Activity.java中的上述源码中，在dispatchKeyEvent(KeyEvent event)中，和dispatchKeyShortcutEvent(KeyEvent event)  
 ，dispatchTouchEvent(MotionEvent ev)这三个主要就是处理activity的相关拦截事件功能的，而关于触摸事件的  
 拦截流程核心方法就是dispatchTouchEvent(MotionEvent ev)事件，在这个方法中，  
 onUserInteraction()是个空方法，只要接收到down事件，就会执行（用户可重写）。  
 如果getWindow().superDispatchTouchEvent()返回true，则意味着事件被viewGroup或者子view消费掉，则activity.dispatchTouchEvent()也返回true，事件分发结束；  
 若子view或者viewGroup没有对事件进行处理，则getWindow().superDispatchTouchEvent()返回false , 则执行activity.onTouchEvent()  
  无论activity.onTouchEvent() 返回true 还是false, 事件分发都结束  
 getWindow()#superDispatchTouchEvent()  
 以前我们说过getWindow返回的是一个PhoneWindow对象，PhoneWindow对象是在activity.attach()里实例化的。  
 mDecor是通过installDecor()实例化的，是window的根布局。mDecor继承自FrameLayout，FrameLayout继承自ViewGroup。即motionEvent对象由Activity传递到了ViewGroup  
 通过分析所以说可以在onTouchEvent()中处理添加点击空白处自动隐藏输入法功能的核心源码



```
//add core start
     private boolean isHideInput(View v, MotionEvent ev) {
         if (v != null && (v instanceof EditText)) {
             int [] l = { 0 , 0 };
             v.getLocationInWindow(l);
             int left = l[ 0 ], top = l[ 1 ], bottom = top + v.getHeight(), right = left
                     + v.getWidth();
             if (ev.getX() > left && ev.getX() < right && ev.getY() > top
                     && ev.getY() < bottom) {
                 return false ;
             } else {
                 return true ;
             }
         }
         return false ;
     }

     private void hideSoftInput(IBinder token) {
         if (token != null ) {
             InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
             manager.hideSoftInputFromWindow(token,
                     InputMethodManager.HIDE_NOT_ALWAYS);
         }
     } 
//add core end

    public boolean onTouchEvent(MotionEvent event) {
        if (mWindow.shouldCloseOnTouch(this, event)) {
            finish();
            return true;
        }
//add core start
else{
          if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View view = getCurrentFocus();
            if (isHideInput(view, event)) {
                hideSoftInput(view.getWindowToken());
            } 
          }
}
//add core end
        return false;
    }
```

在实现framework层实现点击空白处自动隐藏输入法功能的核心功能中，在通过上述的分析得知，在  
 Activity.java中的上述源码中，在onTouchEvent(MotionEvent event)中来负责核心功能实现，所以通过  
 增加isHideInput(View v, MotionEvent ev)和 hideSoftInput(IBinder token)来判断是否在触摸点EditText控件的  
 范围外，然后就隐藏输入法功能，通过在onTouchEvent(MotionEvent event)中添加相应的MotionEvent.ACTION\_DOWN  
 事件，获取当前的焦点事件在EditText上就来实现隐藏输入法功能



