






最近客户提出要添加关机动画和关机音乐的需求，于是就来实现这一需求，和开机动画开机音乐一样要添加资源  
 先看BootAnimation.cpp来分析源码  
 frameworks\base\cmds\bootanimation\BootAnimation.cpp



```
static const char PRODUCT_SHUTDOWNSOUND_FILE[] = "/product/media/shutdownsound.mp3";
static const char SYSTEM_SHUTDOWNSOUND_FILE[] = "/system/media/shutdownsound.mp3";

```

表示关机音乐



```
static const char PRODUCT_SHUTDOWNANIMATION_FILE[] = "/product/media/shutdownanimation.zip";
static const char SYSTEM_SHUTDOWNANIMATION_FILE[] = "/system/media/shutdownanimation.zip";

```

表示关机动画  
 所以要把关机动画和关机音乐放在system/media下 和开机动画开机音乐放在同样的目录下即可


1.资源  
 device\sprd\common\elink\customer\system\media  
 添加 关机音乐shutdownsound.mp3和关机动画shutdownanimation.zip


2.关机模块分析


接下来我们来关机的ShutdownThread.java中 的源码分析  
 路径位于:frameworks\base\services/core/java/com/android/server/power/ShutdownThread.java



```
  /**
     * Makes sure we handle the shutdown gracefully.
     * Shuts off power regardless of radio state if the allotted time has passed.
     */
    public void run() {
        TimingsTraceLog shutdownTimingLog = newTimingsLog();
        shutdownTimingLog.traceBegin("SystemServerShutdown");
        metricShutdownStart();
        metricStarted(METRIC_SYSTEM_SERVER);

        BroadcastReceiver br = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                // We don't allow apps to cancel this, so ignore the result.
 actionDone();
 }
 };

 /\*
 \* Write a system property in case the system\_server reboots before we
 \* get to the actual hardware restart. If that happens, we'll retry at
         * the beginning of the SystemServer startup.
         */
        {
            String reason = (mReboot ? "1" : "0") + (mReason != null ? mReason : "");
            SystemProperties.set(SHUTDOWN_ACTION_PROPERTY, reason);
        }

        /*
         * If we are rebooting into safe mode, write a system property
         * indicating so.
         */
        if (mRebootSafeMode) {
            SystemProperties.set(REBOOT_SAFEMODE_PROPERTY, "1");
        }

        metricStarted(METRIC_SEND_BROADCAST);
        shutdownTimingLog.traceBegin("SendShutdownBroadcast");
        Log.i(TAG, "Sending shutdown broadcast...");

        // First send the high-level shut down broadcast.
        mActionDone = false;
        Intent intent = new Intent(Intent.ACTION_SHUTDOWN);
        intent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND | Intent.FLAG_RECEIVER_REGISTERED_ONLY);
        mContext.sendOrderedBroadcastAsUser(intent,
                UserHandle.ALL, null, br, mHandler, 0, null, null);

        final long endTime = SystemClock.elapsedRealtime() + MAX_BROADCAST_TIME;
        synchronized (mActionDoneSync) {
            while (!mActionDone) {
                long delay = endTime - SystemClock.elapsedRealtime();
                if (delay <= 0) {
                    Log.w(TAG, "Shutdown broadcast timed out");
                    break;
                } else if (mRebootHasProgressBar) {
                    int status = (int)((MAX\_BROADCAST\_TIME - delay) \* 1.0 \*
 BROADCAST\_STOP\_PERCENT / MAX\_BROADCAST\_TIME);
 sInstance.setRebootProgress(status, null);
 }
 try {
 mActionDoneSync.wait(Math.min(delay, ACTION\_DONE\_POLL\_WAIT\_MS));
                } catch (InterruptedException e) {
                }
            }
        }
        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(BROADCAST_STOP_PERCENT, null);
        }
        shutdownTimingLog.traceEnd(); // SendShutdownBroadcast
        metricEnded(METRIC_SEND_BROADCAST);

        Log.i(TAG, "Shutting down activity manager...");
        shutdownTimingLog.traceBegin("ShutdownActivityManager");
        metricStarted(METRIC_AM);

        final IActivityManager am =
                IActivityManager.Stub.asInterface(ServiceManager.checkService("activity"));
        if (am != null) {
            try {
                am.shutdown(MAX_BROADCAST_TIME);
            } catch (RemoteException e) {
            }
        }
        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(ACTIVITY_MANAGER_STOP_PERCENT, null);
        }
        shutdownTimingLog.traceEnd();// ShutdownActivityManager
        metricEnded(METRIC_AM);

        Log.i(TAG, "Shutting down package manager...");
        shutdownTimingLog.traceBegin("ShutdownPackageManager");
        metricStarted(METRIC_PM);

        final PackageManagerService pm = (PackageManagerService)
            ServiceManager.getService("package");
        if (pm != null) {
            pm.shutdown();
        }
        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(PACKAGE_MANAGER_STOP_PERCENT, null);
        }
        shutdownTimingLog.traceEnd(); // ShutdownPackageManager
        metricEnded(METRIC_PM);

        // Shutdown radios.
        shutdownTimingLog.traceBegin("ShutdownRadios");
        metricStarted(METRIC_RADIOS);
        shutdownRadios(MAX_RADIO_WAIT_TIME);
        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(RADIO_STOP_PERCENT, null);
        }
        shutdownTimingLog.traceEnd(); // ShutdownRadios
        metricEnded(METRIC_RADIOS);

        if (mRebootHasProgressBar) {
            sInstance.setRebootProgress(MOUNT_SERVICE_STOP_PERCENT, null);

            // If it's to reboot to install an update and uncrypt hasn't been
            // done yet, trigger it now.
            uncrypt();
        }

        shutdownTimingLog.traceEnd(); // SystemServerShutdown
        metricEnded(METRIC_SYSTEM_SERVER);
        saveMetrics(mReboot, mReason);
        // SPRD:add for shutdownanim
        shutdownAnim.waitForBootanim();
        // Remaining work will be done by init, including vold shutdown
        rebootOrShutdown(mContext, mReboot, mReason);
    }

```

run方法中 有个shutdownAnim.waitForBootanim();


接下来看ShutdownAnim.java 关机动画处理类


frameworks\base\services/core/java/com/android/server/power/ShutdownAnimation.java



```
void waitForBootanim() {
        // SPRD: SPCSS00331921 Add for extended shutdown time off BEG-->
        if (mPlayAnim && SystemProperties.get("service.wait\_for\_bootanim").equals("1")) {
            mPlayAnim = false;
            synchronized (mAnimationDoneSync) {
                final long endBootAnimationTime = SystemClock.elapsedRealtime() + MAX_BOOTANIMATION_WAIT_TIME;
                while (SystemProperties.get("service.bootanim.end").equals("0")) {
                    long delay = endBootAnimationTime - SystemClock.elapsedRealtime();
                    if (delay <= 0) {
                        Slog.w(TAG, "BootAnimation wait timed out");
                        break;
                    }
                    try {
                        Slog.d(TAG,"-----waiting boot animation completed-----");
                        mAnimationDoneSync.wait(BOOT_ANIMATION_CHECK_SPAN);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

```

在service.wait\_for\_bootanim等于1的时候 来准备播放关机动画


所以我们要在播放关机动画的方法中 设置值为1


所以修改为:



```
boolean playShutdownAnimation() {
        IWindowManager wm = IWindowManager.Stub.asInterface(ServiceManager.getService("window"));
        try {
            wm.updateRotation(false, false);
        } catch (RemoteException e) {
            Slog.e(TAG, "stop orientation failed!", e);
        }

        //String[] bootcmd = {"bootanimation", "shutdown"} ;
        try {
            mPlayAnim = true;
            Slog.i(TAG, "exec the bootanimation ");
       +     SystemProperties.set("service.wait\_for\_bootanim", "1");
            SystemProperties.set("service.bootanim.exit", "0");
            SystemProperties.set("service.bootanim.end", "0");
            SystemProperties.set("service.bootanim.shutdown", "1");
            SystemProperties.set("ctl.start", "bootanim");
            //Runtime.getRuntime().exec(bootcmd);
        } catch (Exception e) {
            mPlayAnim = false;
            Slog.e(TAG,"bootanimation command exe err!");
        }
        return true;
    }

```

在playShutdownAnimation() 增加SystemProperties.set(“service.wait\_for\_bootanim”, “1”);


接下来看下 BootAnimation.cpp 的源码



```
#ifdef BOOTANIMATION\_EXT
BootAnimation::BootAnimation(sp<Callbacks> callbacks, bool systemCalled)
#else
BootAnimation::BootAnimation(sp<Callbacks> callbacks)
#endif
        : Thread(false), mClockEnabled(true), mTimeIsAccurate(false),
        mTimeFormat12Hour(false), mTimeCheckThread(nullptr), mCallbacks(callbacks) {
    mSession = new SurfaceComposerClient();

    std::string powerCtl = android::base::GetProperty("sys.powerctl", "");
    if (powerCtl.empty()) {
        mShuttingDown = false;
    } else {
        mShuttingDown = true;
    }
    ALOGD("%sAnimationStartTiming start time: %" PRId64 "ms", mShuttingDown ? "Shutdown" : "Boot",
            elapsedRealtime());
#ifdef BOOTANIMATION\_EXT
    ALOGD("System Called %d ", systemCalled);
    mSystemCalled = systemCalled;
    mfd = -1;
    if (!mShuttingDown) {
        mShuttingDown = android::base::GetProperty("service.bootanim.shutdown", "").compare("1") == 0;
    }
    if (mShuttingDown) {
        mWaitForComplete = android::base::GetBoolProperty("service.wait\_for\_bootanim", false);
    }
    char buf[PROPERTY_VALUE_MAX];
    property_get("persist.sys.animation.log", buf, "false");
    if(!strcmp(buf,"true")){
        gAnimationLog = true;
        ALOGD("Animation debug log is enabled");
    } else if (!strcmp(buf, "false")) {
        gAnimationLog = false;
        ALOGD("Animation debug log is disabled");
    }
#endif
}

```

mWaitForComplete = android::base::GetBoolProperty(“service.wait\_for\_bootanim”, false);  
 来获取是否播放关机动画



```
bool BootAnimation::playAnimation(const Animation& animation)
{
    const size_t pcount = animation.parts.size();
    nsecs_t frameDuration = s2ns(1) / animation.fps;
    const int animationX = (mWidth - animation.width) / 2;
    const int animationY = (mHeight - animation.height) / 2;

    ALOGD("%sAnimationShownTiming start time: %" PRId64 "ms,folder count is %zu",
            mShuttingDown ? "Shutdown" : "Boot", elapsedRealtime(), pcount);
#ifdef BOOTANIMATION\_EXT
    scaleSurfaceIfNeeded();
#endif
    for (size_t i=0 ; i<pcount ; i++) {
        const Animation::Part& part(animation.parts[i]);
        const size_t fcount = part.frames.size();
        ALOGD("folder%zu pictures count is %zu",i,fcount);
        glBindTexture(GL_TEXTURE_2D, 0);

        // Handle animation package
        if (part.animation != nullptr) {
            playAnimation(*part.animation);
            if (exitPending())
                break;
            continue; //to next part
        }
      +  #ifdef BOOTANIMATION\_EXT
      +   if (mShuttingDown && mfd == -1 && mWaitForComplete && (i==(pcount-1))) {
      +      ALOGD("shutdown animation finished, quit");
      +       property_set("service.bootanim.end", "1");
      +   }
      +   #endif
        for (int r=0 ; !part.count || r<part.count ; r++) {
            // Exit any non playuntil complete parts immediately
            if(exitPending() && !part.playUntilComplete)
                break;

            mCallbacks->playPart(i, part, r);

            glClearColor(
                    part.backgroundColor[0],
                    part.backgroundColor[1],
                    part.backgroundColor[2],
                    1.0f);

            for (size_t j=0 ; j<fcount && (!exitPending() || part.playUntilComplete) ; j++) {
                const Animation::Frame& frame(part.frames[j]);
                nsecs_t lastFrame = systemTime();

                if (r > 0) {
                    glBindTexture(GL_TEXTURE_2D, frame.tid);
                } else {
                    if (part.count != 1) {
                        glGenTextures(1, &frame.tid);
                        glBindTexture(GL_TEXTURE_2D, frame.tid);
                        glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                        glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                    }
                    int w, h;
                    initTexture(frame.map, &w, &h);
                }

                const int xc = animationX + frame.trimX;
                const int yc = animationY + frame.trimY;
                Region clearReg(Rect(mWidth, mHeight));
                ALOGD_ANIMATION("subtractSelf Surface xc is %d, yc is %d,xc+frame.trimWidth is %d,yc+frame.trimHeight is %d",
                                xc, yc, (xc+frame.trimWidth),(yc+frame.trimHeight));
                clearReg.subtractSelf(Rect(xc, yc, xc+frame.trimWidth, yc+frame.trimHeight));
                if (!clearReg.isEmpty()) {
                    Region::const_iterator head(clearReg.begin());
                    Region::const_iterator tail(clearReg.end());
                    glEnable(GL_SCISSOR_TEST);
                    while (head != tail) {
                        const Rect& r2(*head++);
                        glScissor(r2.left, mHeight - r2.bottom, r2.width(), r2.height());
                        glClear(GL_COLOR_BUFFER_BIT);
                    }
                    glDisable(GL_SCISSOR_TEST);
                }
                // specify the y center as ceiling((mHeight - frame.trimHeight) / 2)
 // which is equivalent to mHeight - (yc + frame.trimHeight)
 glDrawTexiOES(xc, mHeight - (yc + frame.trimHeight),
 0, frame.trimWidth, frame.trimHeight);
 if (mClockEnabled && mTimeIsAccurate && validClock(part)) {
                    drawClock(animation.clockFont, part.clockPosX, part.clockPosY);
                }
                handleViewport(frameDuration);

                eglSwapBuffers(mDisplay, mSurface);

                nsecs_t now = systemTime();
                nsecs_t delay = frameDuration - (now - lastFrame);
                ALOGD_ANIMATION("frameDuration=%" PRId64 "ms,this frame costs time=%" PRId64 "ms, delay=%" PRId64 "ms", ns2ms(frameDuration), ns2ms(now - lastFrame), ns2ms(delay));
                lastFrame = now;

                if (delay > 0) {
                    struct timespec spec;
                    spec.tv_sec  = (now + delay) / 1000000000;
                    spec.tv_nsec = (now + delay) % 1000000000;
                    int err;
                    do {
                        err = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &spec, nullptr);
                    } while (err<0 && errno == EINTR);
                }

                if (!mShuttingDown) {
                    checkExit();
                }
            }

            usleep(part.pause * ns2us(frameDuration));

            // For infinite parts, we've now played them at least once, so perhaps exit
            if(exitPending() && !part.count && mCurrentInset >= mTargetInset)
                break;
        }
 -#ifdef BOOTANIMATION\_EXT
  -      if (mShuttingDown && mfd == -1 && mWaitForComplete) {
   -         ALOGD("shutdown animation part1 finished, quit");
  -          property_set("service.bootanim.end", "1");
   -    }
  -      
-#endif
    }

    // Free textures created for looping parts now that the animation is done.
    for (const Animation::Part& part : animation.parts) {
        if (part.count != 1) {
            const size_t fcount = part.frames.size();
            for (size_t j = 0; j < fcount; j++) {
                const Animation::Frame& frame(part.frames[j]);
                glDeleteTextures(1, &frame.tid);
            }
        }
    }
#ifdef BOOTANIMATION\_EXT
    // SPRD: stop soundplay
    if (playSoundsAllowed()) {
        soundstop();
    }
#endif
    return true;
}

```

编译验证即可发现实现了关机动画的功能





