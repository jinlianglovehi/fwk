






在Android系统源码中，绝大多数应用程序的UI布局采用了Preference的布局结构，而不是我们平时在模拟器中构建应用程序时使用的View布局结构，例如，Setting模块中布局。当然，凡事都有例外，FMRadio应用程序中则使用了View布局结构(可能是该应用程序是marvel公司提供的，如果由google公司做，那可说不准)。归根到底，Preference布局结构和View的布局结构本质上还是大同小异，Preference的优点在于布局界面的可控性和高效率以及可存储值的简洁性(每个PreferenPreferencece存储在相对应下的SharedPreference文件夹下)。 下面，我们对比Preference和View下得各个子控件，对他们的家庭元素在宏观上有个更好的把握性。  
 单一控件：  
 Preference 控件家庭 View控件家庭 控件含义



```
                      Preference                  TextView           文本框

                      CheckPreference             CheckBox           单选框

                      EditTextPreference          EditText          输入文本框 

                      ListPreference              ListView          列表框

                      RingtonePreference          ——               铃声

      其实在Android源码系统中还有很多的”未完工”的Preference, 没有为它们提供PI接口，例如SeekBarPreference，

   有兴趣的同学可以参考源码，具体路径为：frameworks/base/core/java/preference。





组合控件：
          PreferenceCategory :类似于LinearLayou、RelativeLayout，用于组合一组Preference，使布局更具备层次感 。

          PreferenceScreen  : 所有Preference元素的根节点。

```

显示Preference布局结构的方法为：  
 使我们的Activity继承PreferenceActivity，然后在onCreate()方法中通过



```
  addPreferencesFromResource(R.xml.custom_preference) (我们自定义的Preference 布局)。

  怎么样，是不是似曾相识？稍后会用一个Demo来为您详述。

```

Preference元素的通用XML Attributes说明：  
 android:key ： 每个Preference控件独一无二的”ID”,唯一表示此Preference。



```
     android:defaultValue ： 默认值。 例如，CheckPreference的默认值可为”true”，默认为选中状态；

                                         EditTextPreference的默认值可为”110” 。

     android:enabled ：      表示该Preference是否可用状态。     

     android:title ：        每个Preference在PreferenceScreen布局上显示的标题——大标题

     android:summary ：      每个Preference在PreferenceScreen布局上显示的标题——小标题(可以没有)

     android:persistent：    表示Preference元素所对应的值是否写入sharedPreferen文件中，如果是true，则表示写

                                   入；否则，则表示不写入该Preference元素的值。

     android:dependency：    表示一个Preference(用A表示)的可用状态依赖另外一个Preference(用B表示)。B可用，

                                          则A可用；B不可用，则A不可用。

     android:disableDependentsState：  与android:dependency相反。B可用，则A不可用；B不可用，则A可用。

```

常用的方法则包括：



```
            getKey()            setKey()

         getSummary()        setSummary()

         getText()           setText()

  getXXX()代表取得xxx属性的值。

```

一个简易的效果图如下：


Preference的跳转：  
 方法一：在配置每个Preference元素节点时，我们可以显示为点击它时所跳转的Intent。点击该Preference，跳转至目标Intent。除非在onPreferenceTreeClick()方法中进行抉择。在xml中配置如下：


[java] view plaincopyprint?  
   

  

  
   
   
 方法二：可以在onPreferenceTreeClick()创建新的intent显示的进行跳转。


接下来，对每个Preference的的独有XML Attributes和方法进行一下总结，使大家有更好的深入理解。



```
   1、EditPreference 

        方法：

           getEditText()  返回的是我们在该控件中输入的文本框值

           getText()     返回的是我们之前sharedPreferen文件保存的值

        效果图：

                 

    2、ListPreference

      XML Attributes：

          android:dialogTitle：弹出控件对话框时显示的标题

          android:entries：类型为array，控件欲显示的文本

          android:entryValues：类型为array，与文本相对应的key-value键值对，value保存至sharedPreference文件

          说明：entries和entryValue属性使用的数组为定义在资源文件arrays.xml的数组名：

      方法：

          CharSequence[]    getEntries()： 返回的是控件显示文本的一个”key”数组，对应于属性android:entries

          CharSequence[]    getEntryValues()：返回的一个”value”数组，对应于属性android: entryValues

          CharSequence      getEntry(): 返回当前选择文本

            String          getValue() :返回当前选中文本选中的value 。

       与之对应的还有它们所对应的setXXX()方法，可以参考SDK进行分析。效果图：

                              

     采用的数组为：      

```


```
[java] view plaincopyprint?
<?xml version="1.0" encoding="utf-8"?>  
<resources>  
    <string-array name="department">  
        <item>IT</item>  
        <item>Commerce</item>  
        <item>HR</item>  
    </string-array>  
    <string-array name="department\_value">  
        <item>001</item>  
        <item>002</item>  
        <item>003</item>  
    </string-array>  
</resources>

```


```
   3、RingtonePreference

         XML Attributes：

         android:ringtoneType：响铃的铃声类型，主要有：ringtone(音乐)、notification(通知)、alarm(闹铃)

                                  、all(所有可用声 音类型)。

           android:showDefault ：默认铃声，可以使用系统(布尔值---true,false)的或者自定义的铃声

           android:showSilent  ：指定铃声是否为静音。指定铃声包括系统默认铃声或者自定义的铃声

     效果图：

```

重点：分析Preference事件


★在PreferenceActivity方法中，一个比较重要的监听点击事件方法为：



```
     public booleanonPreferenceTreeClick (PreferenceScreen preferenceScreen, Preference preference)

                       说 明 ： 当Preference控件被点击时，触发该方法。

       参数说明： preference   点击的对象。

       返回值：   true  代表点击事件已成功捕捉，无须执行默认动作或者返回上层调用链。 例如，不跳转至默认Intent。

                  false 代表执行默认动作并且返回上层调用链。例如，跳转至默认Intent。



  在我们继承PreferenceActivity的Activity可以重写该方法，来完成我们对Preference事件的捕捉。

  

 相信通过前面的介绍，你一定知道了如何使用了Preference家族并且对其触发方法。下面我们抛出另外两枚炸弹——

```

Preference相关的两个重要监听接口。


★ Preference.OnPreferenceChangeListener 该监听器的一个重要方法如下：



```
    boolean onPreferenceChange(Preference preference,Object objValue)

         说明：  当Preference的元素值发送改变时，触发该事件。

         返回值：true  代表将新值写入sharedPreference文件中。

                 false 则不将新值写入sharedPreference文件

```

★ Preference.OnPreferenceClickListener 该监听器的一个重要方法如下：



```
     public booleanonPreferenceClick(Preference preference)

         说明：当点击控件时触发发生，可以做相应操作。

                         

那么当一个Preference控件实现这两个接口时，当被点击或者值发生改变时，触发方法是如何执行的呢?事实上，

```

它的触发规则如下：



```
  1 先调用onPreferenceClick()方法，如果该方法返回true，则不再调用onPreferenceTreeClick方法 ；

   如果onPreferenceClick方法返回false，则继续调用onPreferenceTreeClick方法。

  2 onPreferenceChange的方法独立与其他两种方法的运行。也就是说，它总是会运行。



  补充：点击某个Preference控件后，会先回调onPreferenceChange()方法，即是否保存值，然后再回            调onPreferenceClick以及onPreferenceTreeClick()方法，因此在onPreferenceClick/onPreferenceTreeClick

```

方法中我们得到的控件值就是最新的Preference控件值。


那么，开始我们的实战之旅吧！ 下面给您最火热的战场。



```
，新建我们的preference.xml文件。

         ① 在res文件夹下，新建xml文件夹。

         ② 在新建的xml文件夹下，新建Android XML File。命名为mypeference.xml 。类型选择为Preference。

         ③ 打开我们的mypeference.xml，视图选择Structure。可以手动配置我们的布局文件。可选的Preference空间如下：

               

   Demo中mypeference.xml的布局文件如下： 

 

[java] view plaincopyprint?
<?xml version="1.0" encoding="utf-8"?>  
<PreferenceScreen xmlns:android="http://schemas.android.com/apk/res/android">  
  
    <PreferenceCategory android:title="我的位置"  
        android:key="set\_local" />  
    <CheckBoxPreference android:key="apply\_wireless"  
        android:title="使用无线网络" android:summary="使用无线网络在应用程序（例如Google地图）中查看位置"  
        android:defaultValue="true">  
    </CheckBoxPreference>  
    <CheckBoxPreference android:key="apply\_gps"  
        android:title="使用GPS" android:summary="定位到街道级别（需要消耗更多的电量以及天气允许）">  
    </CheckBoxPreference>  
  
    <PreferenceCategory android:title="无线和网络设置"></PreferenceCategory>  
  
    <CheckBoxPreference android:key="apply\_fly"   
        android:title="飞行模式" android:summary="禁用所有无线连接" >  
    </CheckBoxPreference>  
  
    <CheckBoxPreference android:key="apply\_internet"  
        android:title="Internet共享" android:summary="禁用通过USB共享Internet连接">  
    </CheckBoxPreference>  
  
    <CheckBoxPreference android:key="apply\_wifi"  
        android:title="Wi-Fi" android:summary="打开Wi-Fi">  
    </CheckBoxPreference>  
    <Preference android:key="wifi\_setting" android:title="Wi-Fi设置"  
        android:summary="设置和管理无线接入点" android:dependency="apply\_wifi">  
        <!-- 点击时 自定义一个默认跳转Intent  action指定隐式Intent -->  
        <!-- action指定隐式Intent ; targetPackage和targetClass指定显示Intent-->  
        <intent android:action="com.feixun.action.seemAction"   
            android:targetPackage="com.feixun.qin" android:targetClass="com.feixun.qin.MainActivity" />  
    </Preference>  
    <CheckBoxPreference android:key="apply\_bluetooth"  
        android:title="蓝牙" android:summary="启用蓝牙">  
    </CheckBoxPreference>  
    <Preference android:key="bluetooth\_setting" android:title="蓝牙设置"  
        android:summary="管理连接、设备设备名称和可检测性" android:dependency="apply\_bluetooth">  
    </Preference>  
    <EditTextPreference android:key="number\_edit"  
        android:title="输入电话号码" android:defaultValue="123">  
    </EditTextPreference>  
    <ListPreference android:key="depart\_value"  
        android:title="部门设置" android:dialogTitle="选择部门" android:entries="@array/department"  
        android:entryValues="@array/department\_value">  
    </ListPreference>  
    <RingtonePreference android:key="ring\_key"  
        android:title="铃声" android:ringtoneType="all" android:showDefault="true"  
        android:showSilent="true">  
    </RingtonePreference>  
</PreferenceScreen>  

```


```
2，新建一个HelloActivity继承PreferenceActivity，代码如下：   

```


```
[java] view plaincopyprint?
package com.feixun.qin;  
  
import android.content.Intent;  
import android.content.SharedPreferences;  
import android.os.Bundle;  
import android.preference.CheckBoxPreference;  
import android.preference.EditTextPreference;  
import android.preference.ListPreference;  
import android.preference.Preference;  
import android.preference.PreferenceActivity;  
import android.preference.PreferenceManager;  
import android.preference.PreferenceScreen;  
import android.preference.Preference.OnPreferenceClickListener;  
import android.util.Log;  
  
public class HelloPreference extends PreferenceActivity implements  
        Preference.OnPreferenceClickListener,  
        Preference.OnPreferenceChangeListener {  
    private static String TAG = "HelloPreference";            
    private CheckBoxPreference mapply_wifiPreference;       //打开wifi  
    private CheckBoxPreference mapply_internetPreference;   //Internet共享  
    private ListPreference depart_valuePreference;          //部门设置  
    private EditTextPreference number_editPreference;       //输入电话号码  
    private Preference mwifi_settingPreference;             //wifi设置  
    private String oldDeptId; // 旧部门的名称  
  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        addPreferencesFromResource(R.xml.mypreference);  
        //根据key值找到控件  
        mapply_wifiPreference = (CheckBoxPreference) findPreference("apply\_wifi");  
        mapply_internetPreference = (CheckBoxPreference) findPreference("apply\_internet");  
        depart_valuePreference = (ListPreference) findPreference("depart\_value");  
        number_editPreference = (EditTextPreference) findPreference("number\_edit");  
        mwifi_settingPreference = (Preference) findPreference("wifi\_setting");  
  
        // 设置监听器  
        mapply_internetPreference.setOnPreferenceClickListener(this);  
        mapply_internetPreference.setOnPreferenceChangeListener(this);  
        depart_valuePreference.setOnPreferenceClickListener(this);  
        depart_valuePreference.setOnPreferenceChangeListener(this);  
        number_editPreference.setOnPreferenceClickListener(this);  
        number_editPreference.setOnPreferenceChangeListener(this);  
        mwifi_settingPreference.setOnPreferenceClickListener(this);  
  
        // 得到我们的存储Preferences值的对象，然后对其进行相应操作  
        SharedPreferences shp = PreferenceManager.getDefaultSharedPreferences(this);  
        boolean apply_wifiChecked = shp.getBoolean("apply\_wifi", false);  
    }  
  
    // 对控件进行的一些操作  
    private void operatePreference(Preference preference) {  
        if (preference == mapply_wifiPreference){                  //点击了    "打开wifi"  
            Log.i(TAG, " Wifi CB, and isCheckd ="+ mapply_wifiPreference.isChecked());  
        }else if (preference.getKey().equals("apply\_internet")){   //点击了"Internet共享"  
            Log.i(TAG, " internet CB, and isCheckd = "+mapply_internetPreference.isChecked());  
        }else if (preference == depart_valuePreference){           //点击了 "部门设置"  
            Log.i(TAG, " department CB,and selectValue = "+ depart_valuePreference.getValue() + ", Text="+ depart_valuePreference.getEntry());  
        }else if (preference.getKey().equals("wifi\_setting")) {    //点击了"wifi设置"  
            mwifi_settingPreference.setTitle("its turn me.");  
        }else if (preference == number_editPreference)             //点击了"输入电话号码"  
            Log.i(TAG, "Old Value="+ number_editPreference.getText() + ", New Value="+ number_editPreference.getEditText().toString());  
    }  
    // 点击事件触发  
    @Override  
    public boolean onPreferenceClick(Preference preference) {  
        // TODO Auto-generated method stub  
        Log.i(TAG, "onPreferenceClick----->"+String.valueOf(preference.getKey()));  
        // 对控件进行操作  
        operatePreference(preference);  
        return false;  
    }  
        //点击事件触发  
    public boolean onPreferenceTreeClick(PreferenceScreen preferenceScreen,  
            Preference preference) {  
        Log.i(TAG, "onPreferenceTreeClick----->"+preference.getKey());  
        // 对控件进行操作  
        operatePreference(preference);  
        if (preference.getKey().equals("wifi\_setting")) {  
            // 创建一个新的Intent，  
            // 函数如果返回true， 则跳转至该自定义的新的Intent ;  
            // 函数如果返回false，则跳转至xml文件中配置的Intent ;  
            Intent i = new Intent(HelloPreference.this, OtherActivity.class);  //OtherActivity只是一个简单的Activity  
            i.putExtra("type", "wifi");  
            startActivity(i);  
            return true;  
        }  
        return false;  
    }  
  
    // 当Preference的值发生改变时触发该事件，true则以新值更新控件的状态，false则do noting  
    public boolean onPreferenceChange(Preference preference, Object objValue) {  
        Log.i(TAG, "onPreferenceChange----->"+String.valueOf(preference.getKey()));  
        if (preference == mapply_wifiPreference){  
            Log.i(TAG, "Wifi CB, and isCheckd = " + String.valueOf(objValue));  
        }else if (preference.getKey().equals("apply\_internet")) {  
            Log.i(TAG, "internet CB, and isCheckd = "+ String.valueOf(objValue));  
            return false;  //不保存该新值  
        }else if (preference == depart_valuePreference){  
            Log.i(TAG, " Old Value"+ depart_valuePreference.getValue()+" NewDeptName"+objValue);  
        }else if (preference.getKey().equals("wifi\_setting")) {  
            Log.i(TAG, "change" + String.valueOf(objValue));  
            mwifi_settingPreference.setTitle("its turn me.");  //重新设置title  
        } else if (preference == number_editPreference) {  
            Log.i(TAG, "Old Value = " + String.valueOf(objValue));  
            return false; // 不保存更新值  
        }  
        return true;  //保存更新后的值  
    }  
}  

         3，AndroidManifest 文件如下：

[java] view plaincopyprint?
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>  
  
<map>  
  
<boolean name="apply\_wifi" value="true" />  
  
<boolean name="apply\_internet" value="true" />  
  
<string name="number\_edit">45677</string>  
<string name="ring\_key">content://settings/system/ringtone</string>  
  
<boolean name="apply\_bluetooth" value="true" />  
  
<boolean name="apply\_fly" value="true" />  
  
<string name="depart\_value">001</string>  
  
<boolean name="apply\_gps" value="true" />  
  
<boolean name="apply\_wireless" value="false" />  
  
</map>  

```


```
   程序运行后，效果如上所示，是不是很给力呀！ 

```

sharedPreference文件  
 前面我们说过，Android系统会将Preference元素的值存储在sharedPreference文件中。该文件存放路径位于


DDMS视图下的data/data/[packgename]/shared\_prefs/文件下，命名约定为：packagename\_preferencse.xml。



```
 我们的com.feixun.qin_preferences.xm保存的值为：

[java] view plaincopyprint?
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>  
  
<map>  
  
<boolean name="apply\_wifi" value="true" />  
  
<boolean name="apply\_internet" value="true" />  
  
<string name="number\_edit">45677</string>  
<string name="ring\_key">content://settings/system/ringtone</string>  
  
<boolean name="apply\_bluetooth" value="true" />  
  
<boolean name="apply\_fly" value="true" />  
  
<string name="depart\_value">001</string>  
  
<boolean name="apply\_gps" value="true" />  
  
<boolean name="apply\_wireless" value="false" />  
  
</map>  

```


```
已一个键值对的形式保存，name为Preference的key值，value为Preference的value值。

```

在应用程序中，我们可以通过代码的方式来访问该sharedPreference文件，继而可以对其进行读取甚至任何操作。



```
  代码如下： 

```

[java] view plaincopyprint?  
 // 得到我们的存储Preferences值的对象，然后对其进行相应操作  
 SharedPreferences shp = PreferenceManager.getDefaultSharedPreferences(this);  
 boolean apply\_wifiChecked = shp.getBoolean(“apply\_wifi”, false);





