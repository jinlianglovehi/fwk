






本篇讲解Launcher的oncreate的第四步setupViews();生成桌面布局，进行事件的绑定等，这里把setupViews();方法分为三步来讲解。以setupViews（）方法中的setupOverviewPanel();为分界线，以上为第一步，以下为第三步。


setupViews,方法第一部分  
 第一部分源码为



```
mDragLayer = (DragLayer) findViewById(R.id.drag_layer);
mFocusHandler = mDragLayer.getFocusIndicatorHelper();
mWorkspace = mDragLayer.findViewById(R.id.workspace);
mWorkspace.initParentViews(mDragLayer);

mLauncherView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

// Setup the drag layer
mDragLayer.setup(this, mDragController, mAllAppsController);

// Setup the hotseat
mHotseat = (Hotseat) findViewById(R.id.hotseat);
if (mHotseat != null) {
    mHotseat.setOnLongClickListener(this);
}

```

接下来我们就一步一步进行分析。


1.mDragLayer = (DragLayer) findViewById(R.id.drag\_layer);  
 setupViews方法是在Launcher的oncreate中直接调用，所以我们可以得出结论是setupView方法在Launcher中，通过读取res布局文件来找到各个UI控件，这里是创建了重要的DragLayer，所有操作基本都是在这个布局里面进行的。


2.mFocusHandler = mDragLayer.getFocusIndicatorHelper();  
 这里通过DrayLayer来获取FocusIndicatorHelper，FocusIndicatorHelper是用于处理Focus的类，也就是焦点，android里面的focus是指UI界面，当前处理的对象一般不会被感知到也不用处理focus，我们能感知到focus的是editText，当前焦点在输入框时，输入框会有光标，其实我们点击的任何一个组件时，都会有焦点锁定到该组件上，这样就可以理解为什么focus会放到Draglayer里面了，方便进行事件的处理。例如Launcher中有代码“favorite.setOnFocusChangeListener(mFocusHandler)。


3. mWorkspace = mDragLayer.findViewById(R.id.workspace);  
 获取Workspace，创建workspace的对象，桌面放图标的地方由workspace和hotseat两部分组成，我们将hotseat称作快捷栏，它在屏幕下方，用于放一些不随“页面”滑动变化的固定图标。页面就是我们说的workspace。  
 workspace的父类是pagedView，由多个可以滑动的页面组成，PagedView的父类是ViewGroup，PagedView的子类是workspace和FolderPagedView，即Launcher利用ViewGroup做了一套放置图标且可以通过滑动改变当前展示页的类，这个类我们用在了桌面和文件夹中。
4. 



```
mWorkspace.initParentViews(mDragLayer);
public void initParentViews(View parent) {
        super.initParentViews(parent);
        mPageIndicator.setAccessibilityDelegate(new OverviewAccessibilityDelegate());
    }

```

这个方法里面调用了 mPageIndicator.setAccessibilityDelegate方法，这里调用的是View的setAccessibilityDelegate方法，因为PageIndicator继承FramLayout，FramLayout继承ViewGroup，ViewGroup又继承View，这里自定义了AccessibilityDelegate（OverviewAccessibilityDelegate()），来处理一些点击事件，  
 点进OverviewAccessibilityDelegate可以看到，里面定义了点击OVERVIEW ，WALLPAPERS，WIDGETS，SETTINGS事件。


AccessibilityDelegate主要用来对View做一个检测和处理，包括View的点击选中，滑动，touch，文本变化等等。


5.通过Flag设置屏幕状态



```
mLauncherView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
对系统UI进行了Flag设置。
全屏 ：View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
隐藏导航栏： View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
状态栏 ：View.SYSTEM_UI_FLAG_LAYOUT_STABLE

```

6. mDragLayer.setup(this, mDragController, mAllAppsController);  
 把DragLayer与DragController，AllAppsController进行绑定，这样，点击拖拽模块就完成了框架层的搭建。
7. mHotseat = (Hotseat) findViewById(R.id.hotseat);  
 创建Hotseat对象，并且为它设置长按点击事件。





