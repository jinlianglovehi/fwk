



## 1.概述


在10.0的系统产品rom定制化开发中，在Launcher3中的定制化的一些功能中，对于一些产品要求需要实现动态时钟图标功能，这就需要先绘制时分秒时针表盘，然后  
 每秒刷新一次时钟图标，时钟需要做到实时更新，做到动态时钟的效果，接下来就来分析这个功能的实现  
 如图:


![](https://img-blog.csdnimg.cn/39b07e173c10421f98d3b209efb12697.png)


## 2.动态时钟图标功能实现的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\BubbleTextView.java

```

## 3.动态时钟图标功能实现的核心功能分析和实现


在对于自定义view的开发中，在自定义控件类中，可继承View，同样也可以继承Drawable,来实现一个图标绘制背景功能，就可以直接作为  
 某个图标的背景了，而  
 Drawable在我们平时的开发中，基本都会用到，而且对于大家来说也是很实用的。那么什么是Drawable呢？能够在canvas上绘制的一个玩意，而且相比于View，  
 并不需要去考虑measure、layout，仅仅只要去考虑如何draw（canavs）自定义Drawable，是通过继承drawable子类，重写draw(Canvas canvas)方法，  
 实现稍复杂的drawable


## 3.1 自定义添加动态时钟Drawable类


Drawable 是一个可以调用 Canvas 来进行绘制的上层工具。调用 Drawable.draw(Canvas) 可以把 Drawable 设置的绘制内容绘制到 Canvas  
 中。  
 Drawable 内部存储的是绘制规则，这个规则可以是一个具体的 Bitmap，也可以是 一个纯粹的颜色，甚至可以是一个抽象的、灵活的描述。Drawable 可以不含有具体 的像素信息，只要它含有的信息足以在 draw(Canvas) 方法被调用时进行绘制就 够了。  
 由于 Drawable 存储的只是绘制规则，因此在它的 draw() 方法被调用前，需要先  
 调用 Drawable.setBounds() 来为它设置绘制边界  
 接下来就通过自定义Drawable控件，来继承Drawable,重点实现  
 drawable()方法来绘制图标



```
      package com.android.launcher3;
     
    import android.content.Context;
    import android.graphics.Bitmap;
    import android.graphics.BitmapFactory;
    import android.graphics.Canvas;
    import android.graphics.Color;
    import android.graphics.ColorFilter;
    import android.graphics.Paint;
    import android.graphics.PixelFormat;
    import android.graphics.PorterDuff;
    import android.graphics.PorterDuffXfermode;
    import android.graphics.Rect;
    import android.graphics.Path;
    import android.graphics.RectF;
    import android.graphics.drawable.Drawable;
    import android.os.Handler;
    import android.os.Message;
    import androidx.annotation.NonNull;
    import androidx.annotation.Nullable;
    import com.android.launcher3.R;
    import java.util.Calendar;
     
    public class CustomClockDrawable  extends Drawable {
        public final int START_CLOCK=1000;
        //圆，指针，刻度画笔
        private Paint mPaint;
        //半径
        public float mRadius;
        // 外圆的宽度
        public float mCircleWidth;
        //控件宽度
        public int mViewWidth;
        //控件高度
        public int mViewHeight;
        public int mHour,minute,mSecond,angleHour,angleMinute,angleSecond;
        //private Bitmap mBitmap;
        private Path mPath;
        private Rect mRect;
        private Calendar mCalendar;
        private Context mContext;
        private RectF mBgRectF;
        public ClockDrawable(Context context){
            mPaint=new Paint();
            mPaint.setAntiAlias(true);
            mPaint.setStyle(Paint.Style.STROKE);
            mRadius = 45;
            mCircleWidth = 20;
            mViewWidth=90;
            mViewHeight=90;
            mPath = new Path();
            mRect = new Rect();
            mContext= context;
            mBgRectF = new RectF(0, 0, 112, 112);
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            drawbackground(canvas);
            canvas.translate(mRadius+11, mRadius+11);
            //首先绘制圆
            drawCircle(canvas);
            drawClockScale(canvas);
            //绘制指针
            drawPointer(canvas);
            //发送消息刷新ui
            mHandler.sendEmptyMessageDelayed(START_CLOCK,1000);
        }
        private void drawbackground(Canvas canvas){
            mPaint.setColor(Color.WHITE);
            mPaint.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(mBgRectF, 15, 15, mPaint);
        }
        /**
         * 画圆
         * @param canvas
         */
        private void drawCircle(Canvas canvas) {
            mPaint.setStrokeWidth(mCircleWidth);
            mPaint.setStyle(Paint.Style.FILL);
            mPaint.setColor(Color.parseColor("#BBDFFF"));
            canvas.drawCircle(0, 0,mRadius,mPaint);
        }
     
        public void drawClockScale(Canvas canvas){
            for (int index =1;index<=60;index++) {
                // 刻度绘制以12点钟为准，每次将表盘旋转6°，后续绘制都以12点钟为基准绘制
                canvas.rotate(6F, 0F, 0F);
                // 绘制长刻度线
                if (index % 5 == 0) {
                    // 设置长刻度画笔宽度
                    //mPaint.strokeWidth = 4.0F
                    // 绘制刻度线
                    //canvas.drawLine(0F, -radius, 0F, -radius + scaleMax, mPaint)
                    /** 绘制文本 **/
                    canvas.save();
                    mPaint.setColor(Color.BLACK);
                    // 设置画笔宽度
                    mPaint.setStrokeWidth(1f);
                    mPaint.setTextSize(15);
                    // 设置画笔实心风格
                    mPaint.setStyle(Paint.Style.FILL);
                    mPaint.getTextBounds(
                            String.valueOf((index / 5)),
                            0,
                            String.valueOf((index / 5)).length(),
                            mRect
                    );
                    canvas.translate(0,  -mRadius+2+ /*+ scaleMax*/ (mRect.height() / 2));
                    canvas.rotate((float)(index * -6));
                    canvas.drawText(
                            String.valueOf((index / 5)),(-mRect.width() / 2),
                            (mRect.height() / 2), mPaint
                    );
                    canvas.restore();
                }
            }
        }
     
        /**
         * 第四步：绘制指针
         */
        private void drawPointer(Canvas canvas) {
            // 获取当前时间：时分秒
            mCalendar = Calendar.getInstance();
            mHour = mCalendar.get(Calendar.HOUR);
            minute = mCalendar.get(Calendar.MINUTE);
            mSecond = mCalendar.get(Calendar.SECOND);
            // 计算时分秒转过的角度
            angleHour = (mHour * 60 + minute) / 2;
            angleMinute = (minute+mSecond/60)*6;
            angleSecond = mSecond * 6;
     
            // 绘制时针
            canvas.save();
            // 旋转到时针的角度
            canvas.rotate(angleHour, 0F, 0F);
            // 设置时针画笔属性
            mPaint.setColor(Color.BLACK);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeWidth(2f);
            canvas.drawLine(0, 0 - mViewWidth*0.2f, 0, 0 +  mViewWidth*0.075f, mPaint);
            mPaint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(
                    0F,
                    -mViewWidth*0.13f, 2, mPaint
            );
            canvas.restore();
     
            // 绘制分针
            canvas.save();
            // 旋转到分针的角度
            canvas.rotate(angleMinute, 0F, 0F);
            // 设置分针画笔属性
            mPaint.setStrokeWidth(2f);
            mPaint.setColor(Color.BLACK);
            canvas.drawLine(0, 0 - mViewWidth*0.35f, 0, 0 +  mViewWidth*0.06f, mPaint);
            mPaint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(
                    0F,
                    -mViewWidth*0.25f, 2, mPaint
            );
            canvas.restore();
     
            // 绘制秒针
            canvas.save();
            // 旋转到分针的角度
            canvas.rotate(angleSecond, 0F, 0F);
            // 设置秒针画笔属性
            mPaint.setStrokeWidth(0.8f);
            mPaint.setColor(Color.RED);
            canvas.drawLine(0, 0 - mViewWidth*0.4f, 0, 0 +  mViewWidth*0.05f, mPaint);
            canvas.restore();
     
            // 绘制原点
            mPaint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(
                    0F,
                    0F, 5, mPaint
            );
        }
     
        /**
         * handler处理
         */
        private Handler mHandler =new Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what){
                    case START_CLOCK:
                        mHandler.removeMessages(START_CLOCK);
                        mCalendar=null;
                        //更新时分秒
                        invalidateSelf();
                        //每隔1秒更新一次
                        mHandler.sendEmptyMessageDelayed(START_CLOCK,1000);
                        break;
                }
            }
        };
     
        @Override
        public void setAlpha(int i) {
            mPaint.setAlpha(i);
        }
     
        @Override
        public void setColorFilter(@Nullable ColorFilter colorFilter) {
            mPaint.setColorFilter(colorFilter);
        }
     
        @Override
        public int getIntrinsicWidth()
        {
            return 112;
        }
     
        @Override
        public int getIntrinsicHeight()
        {
            return 112;
        }
        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

```

通过上述代码的分析，发现在自定义的CustomClockDrawable 中，主要是draw(@NonNull Canvas canvas) 中通过drawbackground  
 首选绘制一张背景，然后在绘制表盘，最后绘制当前时分秒等时刻，计算宽高以后，在通过canvas.drawText 根据坐标还有字体的大小来做绘制文字  
 从而来实现功能，来绘制一张可以动态改变的Drawable，同时在每隔一秒钟就会通过handle 发送更新绘制  
 界面的消息来更新时钟控件，来达到了更新时钟图标的功能，接下来就来替换时钟图标来实现功能


## 3.2 BubbleTextView.java中替换掉时钟原有的图标


在系统Launcher3的核心功能中，在BubbleTextView就是负责app图标 folder等图标，来构建


所以就是这个类来核心处理，接下来看下怎么替换动态时钟图标



```
       public void applyFromWorkspaceItem(WorkspaceItemInfo info, boolean promiseStateChanged) {
            applyIconAndLabel(info);
            setTag(info);
            if (promiseStateChanged || (info.hasPromiseIconUi())) {
                applyPromiseState(promiseStateChanged);
            }
     
            applyDotState(info, false /* animate */);
        }
     
        public void applyFromApplicationInfo(AppInfo info) {
            applyIconAndLabel(info);
     
            // We don't need to check the info since it's not a WorkspaceItemInfo
            super.setTag(info);
     
            // Verify high res immediately
            verifyHighRes();
     
            if (info instanceof PromiseAppInfo) {
                PromiseAppInfo promiseAppInfo = (PromiseAppInfo) info;
                applyProgressLevel(promiseAppInfo.level);
            }
            applyDotState(info, false /* animate */);
        }
     
        public void applyFromPackageItemInfo(PackageItemInfo info) {
            applyIconAndLabel(info);
            // We don't need to check the info since it's not a WorkspaceItemInfo
            super.setTag(info);
     
            // Verify high res immediately
            verifyHighRes();
        }
     
        private void applyIconAndLabel(ItemInfoWithIcon info) {
            String pkgname = "";
            if (info.getIntent() != null && info.getIntent().getComponent() != null) {
                pkgname = info.getIntent().getComponent().getPackageName();
            }
            //android.util.Log.e("Launcher3","pkgname:"+pkgname);
     
    //add core start
            FastBitmapDrawable iconDrawable = null;
            if( if(pkgname.equals("com.android.deskclock")){
        CustomClockDrawable clockDrawable = new CustomClockDrawable(getContext());
        if(clockDrawable!=null)setIcon(clockDrawable);
            }else{
                iconDrawable = newIcon(getContext(), info);
            }
    //add core end
     
     
            //FastBitmapDrawable iconDrawable = newIcon(getContext(), info);
            mDotParams.color = IconPalette.getMutedColor(info.bitmap.color, 0.54f);
     
            if(iconDrawable!=null)setIcon(iconDrawable);
            setText(info.title);
            if (info.contentDescription != null) {
                setContentDescription(info.isDisabled()
                        ? getContext().getString(R.string.disabled_app_label, info.contentDescription)
                        : info.contentDescription);
            }
        }
```

在上述的代码中可以看到，在BubbleTextView.java的相关代码中，在applyFromWorkspaceItem(WorkspaceItemInfo info, boolean promiseStateChanged)  
 和applyFromApplicationInfo(AppInfo info) ,applyFromPackageItemInfo(PackageItemInfo info),applyIconAndLabel(ItemInfoWithIcon info)  
 这几个方法都是添加各种不同类型图标的，而最后的app图标都是在applyIconAndLabel(ItemInfoWithIcon info)中添加的  
 所以在这个可以根据包名来设置时钟图标，调用CustomClockDrawable 然后setIcon(clockDrawable);  
 就替换了动态时钟的图标，从而实现了动态时钟的功能



