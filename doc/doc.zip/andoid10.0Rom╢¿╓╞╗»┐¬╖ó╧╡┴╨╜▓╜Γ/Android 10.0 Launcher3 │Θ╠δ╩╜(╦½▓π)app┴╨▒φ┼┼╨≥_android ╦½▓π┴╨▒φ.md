



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Launcher3 抽屉式(双层)app列表排序的相关代码](#2.Launcher3%20%E6%8A%BD%E5%B1%89%E5%BC%8F%28%E5%8F%8C%E5%B1%82%29app%E5%88%97%E8%A1%A8%E6%8E%92%E5%BA%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.Launcher3 抽屉式(双层)app列表排序的相关代码和功能实现](#3.Launcher3%20%E6%8A%BD%E5%B1%89%E5%BC%8F%28%E5%8F%8C%E5%B1%82%29app%E5%88%97%E8%A1%A8%E6%8E%92%E5%BA%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%92%8C%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 AllAppsStore.java相关代码分析](#%C2%A0%203.1%20AllAppsStore.java%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 AlphabeticalAppsList.java关于app排序的相关功能分析](#3.2%20AlphabeticalAppsList.java%E5%85%B3%E4%BA%8Eapp%E6%8E%92%E5%BA%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.2.2 在onAppsUpdated()增加排序方法](#3.2.2%20%E5%9C%A8onAppsUpdated%28%29%E5%A2%9E%E5%8A%A0%E6%8E%92%E5%BA%8F%E6%96%B9%E6%B3%95)


[3.3 BaseModelUpdateTask.java关于排序的相关修改](#3.3%20BaseModelUpdateTask.java%E5%85%B3%E4%BA%8E%E6%8E%92%E5%BA%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BF%AE%E6%94%B9)




---



## 1.概述


  在定制Launcher3的开发中，对于抽屉式即双层桌面的workspace的app列表排序的功能，也是常有的需求，把常用的app图标放在前面，其他的可以放在列表后面做个整体的排序，这就需要了解app列表排序的流程，然后根据需求来实现功能


如图:


![](https://img-blog.csdnimg.cn/d500baae39d740a096b74a880a507566.png)



## 2.Launcher3 抽屉式(双层)app列表排序的相关代码



```
  packages\apps\Launcher3\src\com\android\launcher3\allapps\AllAppsStore.java
  packages\apps\Launcher3\src\com\android\launcher3\allapps\AlphabeticalAppsList.java
  packages\apps\Launcher3\src\com\android\launcher3\model\BaseModelUpdateTask.java
  packages\apps\Launcher3\res\values\config.xml
```

## 3.Launcher3 抽屉式(双层)app列表排序的相关代码和功能实现


### 


### 


在Launcher3就是系统原生的Launcher,同样也是一个app,所以Launcher就是一个Activity，Launcher的源码中也是继承的Activity，Launcher3里面有好多个复杂的activitity,


核心类:


AppWidgetManagerCompat：兼容抽象基类，负责处理不通版本下应用和Widget管理  
 LauncherAppWidgetHost：继承子AppWidgetHost，顾名思义，AppWidgetHost是桌面app、widget等的宿主，之所以继承是为了LauncherAppWidgetHostView能更好的处理长按事件；  
 FocusIndicatorView：一个实现了View.OnFocusChangeListener的View（具体作用上不清楚）  
 DragLayer：一个用来协调子View拖拽事件的ViewGroup，实际上事件的分发拦截等是在DragController，因为DragLayer持有DragController的实例，并调用了setup方法初始化了它；  
 AllAppsStore.java 主要就是负责更新app列表，在安装app和卸载app的时候，收到相关的广播后执行相关的刷新app的动作


AlphabeticalAppsList.java 这个类主要就是在加载完app列表数据以后，在根据首字母的排序来


显示app列表，所以可以说关于app显示列表排序可以从这里出发分析相关代码




### 3.1 AllAppsStore.java相关代码分析



```
   public class AllAppsStore {

   
    public Collection<AppInfo> getApps() {
        return mComponentToAppMap.values();
    }

    /**
     * Sets the current set of apps.
     */
    public void setApps(List<AppInfo> apps) {
        mComponentToAppMap.clear();
        addOrUpdateApps(apps);
    }

    public AppInfo getApp(ComponentKey key) {
        return mComponentToAppMap.get(key);
    }

    public void enableDeferUpdates(int flag) {
        mDeferUpdatesFlags |= flag;
    }

    public void addOrUpdateApps(List<AppInfo> apps) {
        for (AppInfo app : apps) {
            mComponentToAppMap.put(app.toComponentKey(), app);
        }
        notifyUpdate();
    }

    /**
     * Removes some apps from the list.
     */
    public void removeApps(List<AppInfo> apps) {
        for (AppInfo app : apps) {
            mComponentToAppMap.remove(app.toComponentKey());
        }
        notifyUpdate();
    }


    private void notifyUpdate() {
        if (mDeferUpdatesFlags != 0) {
            mUpdatePending = true;
            if (LogUtils.DEBUG_ALL) {
                LogUtils.d("AllAppsStore", "notifyUpdate mDeferUpdatesFlags:"
                        + Integer.toBinaryString(mDeferUpdatesFlags));
            }
            return;
        }
        int count = mUpdateListeners.size();
        for (int i = 0; i < count; i++) {
            mUpdateListeners.get(i).onAppsUpdated();
        }
    }

    public void addUpdateListener(OnUpdateListener listener) {
        mUpdateListeners.add(listener);
    }

    public void removeUpdateListener(OnUpdateListener listener) {
        mUpdateListeners.remove(listener);
    }

    public void registerIconContainer(ViewGroup container) {
        if (container != null) {
            mIconContainers.add(container);
        }
    }

    public void unregisterIconContainer(ViewGroup container) {
        mIconContainers.remove(container);
    }

    public void updateNotificationDots(Predicate<PackageUserKey> updatedDots) {
        updateAllIcons((child) -> {
            if (child.getTag() instanceof ItemInfo) {
                ItemInfo info = (ItemInfo) child.getTag();
                if (mTempKey.updateFromItemInfo(info) && updatedDots.test(mTempKey)) {
                    child.applyDotState(info, true /* animate */);
                }
            }
        });
    }



    private void updateAllIcons(Consumer<BubbleTextView> action) {
        for (int i = mIconContainers.size() - 1; i >= 0; i--) {
            ViewGroup parent = mIconContainers.get(i);

            if (parent instanceof AllAppsRecyclerView) {
                AlphabeticalAppsList apps = ((AllAppsRecyclerView) parent).getApps();
                if (null != apps) {
                    List<AlphabeticalAppsList.AdapterItem> items = apps.getAdapterItems();
                    for (int j = 0; j < items.size(); j++) {
                        BubbleTextView child = items.get(j).iconView;
                        if (null != child) {
                            action.accept(child);
                        }
                    }
                }
            } else {
                int childCount = parent.getChildCount();

                for (int j = 0; j < childCount; j++) {
                    View child = parent.getChildAt(j);
                    if (child instanceof BubbleTextView) {
                        action.accept((BubbleTextView) child);
                    }
                }
            }
        }
    }

}
```

在AllAppsStore.java中可以看出addOrUpdateApps(List<AppInfo> apps)负责更新app列表  
 具体是由OnUpdateListener的onAppsUpdated();实现的，接下来看下AlphabeticalAppsList.java关于app排序的相关功能


##  3.2 AlphabeticalAppsList.java关于app排序的相关功能分析



```
  /**
 * The alphabetically sorted list of applications.
 */
public class AlphabeticalAppsList implements AllAppsStore.OnUpdateListener {

    public static final String TAG = "AlphabeticalAppsList";

    private static final int FAST_SCROLL_FRACTION_DISTRIBUTE_BY_ROWS_FRACTION = 0;
    private static final int FAST_SCROLL_FRACTION_DISTRIBUTE_BY_NUM_SECTIONS = 1;

    private static final int sFastScrollDistributionMode = FAST_SCROLL_FRACTION_DISTRIBUTE_BY_NUM_SECTIONS;

/**
     * Updates internals when the set of apps are updated.
     */
    @Override
    public void onAppsUpdated() {
        // Sort the list of apps
        mApps.clear();

        for (AppInfo app : mAllAppsStore.getApps()) {
            if (mItemFilter == null || mItemFilter.matches(app, null) || hasFilter()) {
                mApps.add(app);
            }
        }

        Collections.sort(mApps, mAppNameComparator);

        // As a special case for some languages (currently only Simplified Chinese), we may need to
        // coalesce sections
        Locale curLocale = mLauncher.getResources().getConfiguration().locale;
        boolean localeRequiresSectionSorting = curLocale.equals(Locale.SIMPLIFIED_CHINESE);
        if (localeRequiresSectionSorting) {
            // Compute the section headers. We use a TreeMap with the section name comparator to
            // ensure that the sections are ordered when we iterate over it later
            TreeMap<String, ArrayList<AppInfo>> sectionMap = new TreeMap<>(new LabelComparator());
            for (AppInfo info : mApps) {
                // Add the section to the cache
                String sectionName = getAndUpdateCachedSectionName(info.title);

                // Add it to the mapping
                ArrayList<AppInfo> sectionApps = sectionMap.get(sectionName);
                if (sectionApps == null) {
                    sectionApps = new ArrayList<>();
                    sectionMap.put(sectionName, sectionApps);
                }
                sectionApps.add(info);
            }

            // Add each of the section apps to the list in order
            mApps.clear();
            for (Map.Entry<String, ArrayList<AppInfo>> entry : sectionMap.entrySet()) {
                mApps.addAll(entry.getValue());
            }
        } else {
            // Just compute the section headers for use below
            for (AppInfo info : mApps) {
                // Add the section to the cache
                getAndUpdateCachedSectionName(info.title);
            }
        }

        LauncherAppMonitor.getInstance(mLauncher).onAllAppsListUpdated(mApps);
        updateAdapterItems();
    }
```

在AlphabeticalAppsList.java中的相关源码分析，得知在onAppsUpdated() 中的Collections.sort(mApps, mAppNameComparator);负责对app列表按照名称排序增加排序的相关方法



```
private List<AppInfo> getSortArrayApps(){
		 String[] appPkgAndClsName = new String[]{
				"com.android.music/com.android.music.MusicBrowserActivity",
				"com.android.deskclock/com.android.deskclock.DeskClock",
				"com.android.settings/com.android.settings.Settings",
				"com.android.calendar/com.android.calendar.AllInOneActivity",
				"com.sprd.sprdnote/com.sprd.sprdnote.NoteActivity"
				};
		 List<AppInfo> sortAppsArray = new ArrayList<>();
		    for(int i=0; i<appPkgAndClsName.length; i++){		
				String pkgName = appPkgAndClsName[i].split("/")[0];
				String clsName = appPkgAndClsName[i].split("/")[1];
				for(int j=0; j<mApps.size(); j++){
					AppInfo appinfo = mApps.get(j);
					String packagename = appinfo.componentName.getPackageName();
					String classname = appinfo.componentName.getClassName();
					if(packagename.equals(pkgName)&&classname.equals(clsName)){	
						sortAppsArray.add(appinfo);
						break;
					}
				}
			}
			return sortAppsArray;
	}
    private List<AppInfo> getOutArrayApps(){
		 List<AppInfo> outAppsArray = new ArrayList<>(mApps);
		 outAppsArray.removeAll(getSortArrayApps());
		 return outAppsArray;
	}
	/**
	*	将需要排序的和不需排序的列表传入，当排序列表放在前面
	*/
    private void sortNewAllApps(){
	 List<AppInfo> sortAppsArray = new ArrayList<>();
	 List<AppInfo> arrayApps = getSortArrayApps();
	 List<AppInfo> notSortArrayApps = getOutArrayApps();
		
	 if(arrayApps.size()>0 && notSortArrayApps.size()>0){
			//对集合2进行排序
			Collections.sort(notSortArrayApps, mAppNameComparator);
			boolean appIsBefore = mContext.getResources().getBoolean(R.bool.sort_is_before);
			if(!appIsBefore){
				//合并集合1和2,并将集合1放在后面
				notSortArrayApps.addAll(arrayApps);
				sortAppsArray = notSortArrayApps;
			}else{
				//合并集合1和2,并将集合1放在前面
				arrayApps.addAll(notSortArrayApps);
				sortAppsArray = arrayApps;
			}
			//将集合mApps清空				
			mApps.clear();
			//将集合1和集合2合并后放入mApps集合
			mApps.addAll(sortAppsArray);
		}
	}
```

### 3.2.2 在onAppsUpdated()增加排序方法



```
    public void onAppsUpdated() {
        // Sort the list of apps
        mApps.clear();

        for (AppInfo app : mAllAppsStore.getApps()) {
            if (mItemFilter == null || mItemFilter.matches(app, null) || hasFilter()) {
                mApps.add(app);
            }
        }

        // 注释掉按名称排序
        //Collections.sort(mApps, mAppNameComparator);

        // As a special case for some languages (currently only Simplified Chinese), we may need to
        // coalesce sections
        Locale curLocale = mLauncher.getResources().getConfiguration().locale;
        boolean localeRequiresSectionSorting = curLocale.equals(Locale.SIMPLIFIED_CHINESE);
        if (localeRequiresSectionSorting) {
            // Compute the section headers. We use a TreeMap with the section name comparator to
            // ensure that the sections are ordered when we iterate over it later
            TreeMap<String, ArrayList<AppInfo>> sectionMap = new TreeMap<>(new LabelComparator());
            for (AppInfo info : mApps) {
                // Add the section to the cache
                String sectionName = getAndUpdateCachedSectionName(info.title);

                // Add it to the mapping
                ArrayList<AppInfo> sectionApps = sectionMap.get(sectionName);
                if (sectionApps == null) {
                    sectionApps = new ArrayList<>();
                    sectionMap.put(sectionName, sectionApps);
                }
                sectionApps.add(info);
            }

            // Add each of the section apps to the list in order
            mApps.clear();
            for (Map.Entry<String, ArrayList<AppInfo>> entry : sectionMap.entrySet()) {
                mApps.addAll(entry.getValue());
            }
        } else {
            // Just compute the section headers for use below
            for (AppInfo info : mApps) {
                // Add the section to the cache
                getAndUpdateCachedSectionName(info.title);
            }
        }

        LauncherAppMonitor.getInstance(mLauncher).onAllAppsListUpdated(mApps);

        //add core start 增加排序的代码
		boolean appIsSort = mContext.getResources().getBoolean(R.bool.apps_is_sort);
		if(appIsSort){
			sortNewAllApps();
		}else {
			Collections.sort(mApps, mAppNameComparator);
		}
		// Recompose the set of adapter items from the current set of apps

     // add core end

        updateAdapterItems();
    }

  packages\apps\Launcher3\res\values\config.xml 中增加的属性
    <bool name="sort_is_before">true</bool>
    <bool name="apps_is_sort">true</bool>
```

### 3.3 BaseModelUpdateTask.java关于排序的相关修改



```
    @Override
    public final void run() {
        if (!mModel.isModelLoaded() && !mIgnoreLoaded) {
            if (DEBUG_TASKS) {
                Log.d(TAG, "Ignoring model task since loader is pending=" + this);
            }
            // 注释掉这里
            // Loader has not yet run.
            //return;
        }
        execute(mApp, mDataModel, mAllAppsList);
    }

```

通过上述的几个类来的相关代码的修改，可以发现最终在开机进入Launcher3的时候修改了排序方式，同时在安装或卸载app的时候，app列表更新的时候，同样也是按顺序排序显示app列表，最终实现了这个功能排序



