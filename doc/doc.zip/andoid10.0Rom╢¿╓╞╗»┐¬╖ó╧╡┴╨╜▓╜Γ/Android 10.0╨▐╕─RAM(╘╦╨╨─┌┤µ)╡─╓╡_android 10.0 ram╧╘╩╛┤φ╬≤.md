






在进行定制化开发的过程中，由于有些客户要求，现有的设备RAM和ROM修改高点的配置  
 于是就来完成这一需求  
 首选来看Settings的关于设备中是怎么获取运行内存的



```
private static final String KEY_SUPPORT_RAM_DISPLAY = "ram\_display";
private static final String SPRD_RAM_SIZE = "ro.boot.ddrsize";
String ramSize = getConfigRam();
        if (ramSize == null) {
            ramSize = getRamSizeFromProperty();
        }

        if (ramSize != null) {
            Log.d(TAG, "RAM Size: " + ramSize);
            preference.setSummary(ramSize);
        } else {
            preference.setVisible(false);
        }

```

实际ramSize 的值从getRamSizeFromProperty()中获取



```
public String getRamSizeFromProperty() {
    String size = SystemProperties.get(SPRD_RAM_SIZE, "unconfig");
    if ("unconfig".equals(size)) {
        Log.d(TAG, "can not get ram size from "+SPRD_RAM_SIZE);
        return null;
    } else {
        Log.d(TAG, "property value is:" + size);
        String regEx="[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(size);
        size = m.replaceAll("").trim();
        long ramSize = Long.parseLong(size);
        return Formatter.formatShortFileSize(mContext, covertUnitsToSI(ramSize));
    }
}

```

可以说ram的值是 从ro.boot.ddrsize 中获取的  
 那么就需要看内核 kenel 中是怎么设置的


通过在bsp/目录下  
 通过搜索ro.boot.ddrsize 得知



```
bsp/bootloader/u-boot15/common/loader/sprd_fdt_support.c
int fdt_fixup_ro_boot_ramsize(void *fdt)
{
#ifdef CONFIG\_DDR\_AUTO\_DETECT
	char buf[32];

	phys_size_t ddr_size;
	uint64_t ro_boot_ddrsize = 0;
	int str_len;
	int ret;

	ddr_size = get_real_ram_size();
	ddr_size = ALIGN(ddr_size, 0x100000);
	ro_boot_ddrsize = ddr_size >> 20;

	memset(buf, 0, 32);

	sprintf(buf, "androidboot.ddrsize=%ldM", ro_boot_ddrsize);
	str_len = strlen(buf);
	buf[str_len] = '\0';

	ret = fdt_chosen_bootargs_append(fdt, buf, 1);

	return ret;
#else
	return 0;
#endif
}

int fdt_fixup_ddrsize_range(void *fdt) {
    char buf[64], *range = NULL;
    int ret, str_len;
    memset(buf, 0, sizeof(buf));
#ifdef CONFIG\_DDR\_AUTO\_DETECT
    uint64_t ro_boot_ddrsize = 0;
    phys_size_t ddr_size;

    ddr_size = get_real_ram_size();
    ddr_size = ALIGN(ddr_size, 0x100000);
    ro_boot_ddrsize = ddr_size >> 20;

    if (ro_boot_ddrsize < 512) {
        range = "[0,512)";
    } else if (ro_boot_ddrsize < 1024) {
        range = "[512,1024)";
    } else if (ro_boot_ddrsize < 2048) {
        range = "[1024,2048)";
    } else {
        range = "[2048,)";
    }
#else
    range = "[1024,2048)";
#endif
    sprintf(buf, "androidboot.ddrsize.range=%s", range);
    str_len = strlen(buf);
    buf[str_len] = '\0';

    ret = fdt_chosen_bootargs_append(fdt, buf, 1);

    return 0;
}

```

这两段代码中 uint64\_t ro\_boot\_ddrsize = 0; 就是来计算ram的值的  
 所以修改ram的值就从这里修改即可  
 而get\_real\_ram\_size()定义在  
 bsp/bootloader/u-boot15/include/common.h:  
 中的  
 phys\_size\_t get\_real\_ram\_size(void);  
 具体实现在 每个驱动型号的c文件里面



```
bsp/bootloader/u-boot15/board/spreadtrum/ums512_20c10/ums512_20c10.c
phys_size_t real_ram_size = 0x40000000;

phys_size_t get_real_ram_size(void)
{
        return real_ram_size;
}

```

就是real\_ram\_size的值



```
int dram_init(void)
{
#ifdef CONFIG\_DDR\_AUTO\_DETECT
	ulong sdram_base = CONFIG_SYS_SDRAM_BASE;
	ulong sdram_size = 0;
	chipram_env_t * env = CHIPRAM_ENV_LOCATION;
	if (CHIPRAM_ENV_MAGIC != env->magic) {
		printf("Chipram magic wrong , ddr data may be broken\n");
		return 0;
	}

	real_ram_size = 0;

	if (env->cs_number == 1) {
		real_ram_size += env->cs0_size;
		debugf("dram cs0 size %x\n",env->cs0_size);
	} else if(env->cs_number == 2){
		real_ram_size += env->cs0_size;
		real_ram_size += env->cs1_size;
		debugf("dram cs0 size %x\ndram cs1 size %x\n",env->cs0_size, env->cs1_size);
	}

	//real_ram_size = get_ram_size((volatile void *)sdram_base, real_ram_size);
#else
	real_ram_size = REAL_SDRAM_SIZE;
#endif

	gd->ram_size = PHYS_SDRAM_1_SIZE;

	return 0;
}

```

初始化的过程中 获取ram的值


所以修改如下:



```
int fdt_fixup_ro_boot_ramsize(void *fdt)
{
#ifdef CONFIG\_DDR\_AUTO\_DETECT
	char buf[32];

	phys_size_t ddr_size;
	uint64_t ro_boot_ddrsize = 0;
	int str_len;
	int ret;
        - ddr_size = get_real_ram_size();
	+ ddr_size = get_real_ram_size()*2;
	ddr_size = ALIGN(ddr_size, 0x100000);
	ro_boot_ddrsize = ddr_size >> 20;

	memset(buf, 0, 32);

	sprintf(buf, "androidboot.ddrsize=%ldM", ro_boot_ddrsize);
	str_len = strlen(buf);
	buf[str_len] = '\0';

	ret = fdt_chosen_bootargs_append(fdt, buf, 1);

	return ret;
#else
	return 0;
#endif
}

int fdt_fixup_ddrsize_range(void *fdt) {
    char buf[64], *range = NULL;
    int ret, str_len;
    memset(buf, 0, sizeof(buf));
#ifdef CONFIG\_DDR\_AUTO\_DETECT
    uint64_t ro_boot_ddrsize = 0;
    phys_size_t ddr_size;
    - ddr_size = get_real_ram_size();
   + ddr_size = get_real_ram_size()*2;
    ddr_size = ALIGN(ddr_size, 0x100000);
    ro_boot_ddrsize = ddr_size >> 20;

    if (ro_boot_ddrsize < 512) {
        range = "[0,512)";
    } else if (ro_boot_ddrsize < 1024) {
        range = "[512,1024)";
    } else if (ro_boot_ddrsize < 2048) {
        range = "[1024,2048)";
    } else {
        range = "[2048,)";
    }
#else
    range = "[1024,2048)";
#endif
    sprintf(buf, "androidboot.ddrsize.range=%s", range);
    str_len = strlen(buf);
    buf[str_len] = '\0';

    ret = fdt_chosen_bootargs_append(fdt, buf, 1);

    return 0;
}

```

编译验证即可 发现settings里面的ram的值已经变化  
 ro.boot.ddrsize的值和ro.ramsize的值也有变化





