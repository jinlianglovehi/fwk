



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.核心代码功能分析](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1wipe\_data.cpp代码分析](#3.1wipe_data.cpp%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 获取ReadLogFilesToMemory()中cache的路径](#3.2%20%E8%8E%B7%E5%8F%96ReadLogFilesToMemory%28%29%E4%B8%ADcache%E7%9A%84%E8%B7%AF%E5%BE%84)


[3.3 RecoverySystem.java 中的修改](#3.3%20RecoverySystem.java%20%E4%B8%AD%E7%9A%84%E4%BF%AE%E6%94%B9)




---



## 1.概述


10.0定制化开发中，在恢复出厂设置的时候，主要清理cache和data分区，所以这两个目录下的数据都会被清理掉，所以要想保留文件不被清理 就要在清理的时候，跳过这个目录即可


## 2.核心代码



```
主要代码:
frameworks/base/core/java/android/os/RecoverySystem.java
bootable\recovery\otautil\logging.cpp
/bootable/recovery/install/wipe_data.cpp
```

## 3.核心代码功能分析


#### 3.1wipe\_data.cpp代码分析



```
static bool EraseVolume(const char* volume, RecoveryUI* ui, bool convert_fbe) {
bool is_cache = (strcmp(volume, CACHE_ROOT) == 0);
bool is_data = (strcmp(volume, DATA_ROOT) == 0);
ui->SetBackground(RecoveryUI::ERASING);
ui->SetProgressType(RecoveryUI::INDETERMINATE);
std::vector<saved_log_file> log_files;
if (is_cache) {
// If we're reformatting /cache, we load any past logs (i.e. "/cache/recovery/last_*") and the
// current log ("/cache/recovery/log") into memory, so we can restore them after the reformat.
log_files = ReadLogFilesToMemory();
}
ui->Print("Formatting %s...\n", volume);
ensure_path_unmounted(volume);
int result;
if (is_data && convert_fbe) {
constexpr const char* CONVERT_FBE_DIR = "/tmp/convert_fbe";
constexpr const char* CONVERT_FBE_FILE = "/tmp/convert_fbe/convert_fbe";
// Create convert_fbe breadcrumb file to signal init to convert to file based encryption, not
// full disk encryption.
if (mkdir(CONVERT_FBE_DIR, 0700) != 0) {
PLOG(ERROR) << "Failed to mkdir " << CONVERT_FBE_DIR;
return false;
}
FILE* f = fopen(CONVERT_FBE_FILE, "wbe");
if (!f) {
PLOG(ERROR) << "Failed to convert to file encryption";
return false;
}
fclose(f);
result = format_volume(volume, CONVERT_FBE_DIR);
remove(CONVERT_FBE_FILE);
rmdir(CONVERT_FBE_DIR);
} else {
result = format_volume(volume);
}
if (is_cache) {
RestoreLogFilesAfterFormat(log_files);
}
return (result == 0);
}
```

从上面代码可以看出


if (is\_cache) {  
 // If we're reformatting /cache, we load any past logs (i.e. "/cache/recovery/last\_\*") and the  
 // current log ("/cache/recovery/log") into memory, so we can restore them after the reformat.  
 log\_files = ReadLogFilesToMemory();  
 }


在判断是cache的时候 路径是通过ReadLogFilesToMemory()来读取路径


#### 3.2 获取ReadLogFilesToMemory()中cache的路径


地址:bootable\recovery\otautil\logging.cpp中



```
std::vector<saved_log_file> ReadLogFilesToMemory() {
ensure_path_mounted("/cache");
struct dirent* de;
std::unique_ptr<DIR, decltype(&closedir)> d(opendir(CACHE_LOG_DIR), closedir);
if (!d) {
if (errno != ENOENT) {
PLOG(ERROR) << "Failed to opendir " << CACHE_LOG_DIR;
}
return {};
}
std::vector<saved_log_file> log_files;
while ((de = readdir(d.get())) != nullptr) {
if (strncmp(de->d_name, "last_", 5) == 0 || strcmp(de->d_name, "log") == 0 ) {
std::string path = android::base::StringPrintf("%s/%s", CACHE_LOG_DIR, de->d_name);struct stat sb;
if (stat(path.c_str(), &sb) != 0) {
PLOG(ERROR) << "Failed to stat " << path;
continue;
}
// Truncate files to 512kb
size_t read_size = std::min<size_t>(sb.st_size, 1 << 19);
std::string data(read_size, '\0');android::base::unique_fd log_fd(TEMP_FAILURE_RETRY(open(path.c_str(), O_RDONLY)));
if (log_fd == -1 || !android::base::ReadFully(log_fd, data.data(), read_size)) {
PLOG(ERROR) << "Failed to read log file " << path;
continue;
}log_files.emplace_back(saved_log_file{ path, sb, data });
}
}
return log_files;
}






```

#### 从代码可以看出 while ((de = readdir(d.get())) != nullptr) 不断的读取文件夹下的文件 if (strncmp(de->d\_name, "last\_", 5) == 0 || strcmp(de->d\_name, "log") == 0 ) 来判断是否符和相关的清理文件的要求 这些文件就会被保留不被清理掉 所以具体修改为： 以kotlin 开头的文件也保留



```
std::vector<saved_log_file> ReadLogFilesToMemory() {
ensure_path_mounted("/cache");
struct dirent* de;
std::unique_ptr<DIR, decltype(&closedir)> d(opendir(CACHE_LOG_DIR), closedir);
if (!d) {
if (errno != ENOENT) {
PLOG(ERROR) << "Failed to opendir " << CACHE_LOG_DIR;
}
return {};
}
std::vector<saved_log_file> log_files;
while ((de = readdir(d.get())) != nullptr) {
  -if (strncmp(de->d_name, "last_", 5) == 0 || strcmp(de->d_name, "log") == 0 ) {
   +if (strncmp(de->d_name, "last_", 5) == 0 || strcmp(de->d_name, "log") == 0 || strncmp(de->d_name, "kotlin",6) == 0) {

std::string path = android::base::StringPrintf("%s/%s", CACHE_LOG_DIR, de->d_name);struct stat sb;
if (stat(path.c_str(), &sb) != 0) {
PLOG(ERROR) << "Failed to stat " << path;
continue;
}
// Truncate files to 512kb
size_t read_size = std::min<size_t>(sb.st_size, 1 << 19);
std::string data(read_size, '\0');android::base::unique_fd log_fd(TEMP_FAILURE_RETRY(open(path.c_str(), O_RDONLY)));
if (log_fd == -1 || !android::base::ReadFully(log_fd, data.data(), read_size)) {
PLOG(ERROR) << "Failed to read log file " << path;
continue;
}log_files.emplace_back(saved_log_file{ path, sb, data });
}
}
return log_files;
}
```

#### 3.3 RecoverySystem.java 中的修改



```
/**
* Called after booting to process and remove recovery-related files.
* @return the log file from recovery, or null if none was found.
*
* @hide
*/
public static String handleAftermath(Context context) {
// Record the tail of the LOG_FILE
String log = null;
try {
log = FileUtils.readTextFile(LOG_FILE, -LOG_FILE_MAX_LENGTH, "...\n");
} catch (FileNotFoundException e) {
Log.i(TAG, "No recovery log file");
} catch (IOException e) {
Log.e(TAG, "Error reading recovery log", e);
}
    // Only remove the OTA package if it's partially processed (uncrypt'd).
    boolean reservePackage = BLOCK_MAP_FILE.exists();
    if (!reservePackage && UNCRYPT_PACKAGE_FILE.exists()) {
        String filename = null;
        try {
            filename = FileUtils.readTextFile(UNCRYPT_PACKAGE_FILE, 0, null);
        } catch (IOException e) {
            Log.e(TAG, "Error reading uncrypt file", e);
        }

        // Remove the OTA package on /data that has been (possibly
        // partially) processed. (Bug: 24973532)
        if (filename != null && filename.startsWith("/data")) {
            if (UNCRYPT_PACKAGE_FILE.delete()) {
                Log.i(TAG, "Deleted: " + filename);
            } else {
                Log.e(TAG, "Can't delete: " + filename);
            }
        }
    }

    // We keep the update logs (beginning with LAST_PREFIX), and optionally
    // the block map file (BLOCK_MAP_FILE) for a package. BLOCK_MAP_FILE
    // will be created at the end of a successful uncrypt. If seeing this
    // file, we keep the block map file and the file that contains the
    // package name (UNCRYPT_PACKAGE_FILE). This is to reduce the work for
    // GmsCore to avoid re-downloading everything again.
    String[] names = RECOVERY_DIR.list();
    for (int i = 0; names != null && i < names.length; i++) {
        // Do not remove the last_install file since the recovery-persist takes care of it.
        if (names[i].startsWith(LAST_PREFIX) || names[i].equals(LAST_INSTALL_PATH)) continue;
        if (reservePackage && names[i].equals(BLOCK_MAP_FILE.getName())) continue;
        if (reservePackage && names[i].equals(UNCRYPT_PACKAGE_FILE.getName())) continue;
        recursiveDelete(new File(RECOVERY_DIR, names[i]));
    }

    return log;
}








```

handleAftermath(Context context) 的相关代码也是来遍历  
 哪些是recovery需要清理的文件路径  
 在 for (int i = 0; names != null && i < names.length; i++) {  
         // Do not remove the last\_install file since the recovery-persist takes care of it.  
         if (names[i].startsWith(LAST\_PREFIX) || names[i].equals(LAST\_INSTALL\_PATH)) continue;  
         if (reservePackage && names[i].equals(BLOCK\_MAP\_FILE.getName())) continue;  
         if (reservePackage && names[i].equals(UNCRYPT\_PACKAGE\_FILE.getName())) continue;  
         recursiveDelete(new File(RECOVERY\_DIR, names[i]));  
     }  
 中来去掉不需要清理的文件


所以具体修改如下:



```
/**
* Called after booting to process and remove recovery-related files.
* @return the log file from recovery, or null if none was found.
*
* @hide
*/
public static String handleAftermath(Context context) {
// Record the tail of the LOG_FILE
String log = null;
try {
log = FileUtils.readTextFile(LOG_FILE, -LOG_FILE_MAX_LENGTH, "...\n");
} catch (FileNotFoundException e) {
Log.i(TAG, "No recovery log file");
} catch (IOException e) {
Log.e(TAG, "Error reading recovery log", e);
}
    // Only remove the OTA package if it's partially processed (uncrypt'd).
    boolean reservePackage = BLOCK_MAP_FILE.exists();
    if (!reservePackage && UNCRYPT_PACKAGE_FILE.exists()) {
        String filename = null;
        try {
            filename = FileUtils.readTextFile(UNCRYPT_PACKAGE_FILE, 0, null);
        } catch (IOException e) {
            Log.e(TAG, "Error reading uncrypt file", e);
        }

        // Remove the OTA package on /data that has been (possibly
        // partially) processed. (Bug: 24973532)
        if (filename != null && filename.startsWith("/data")) {
            if (UNCRYPT_PACKAGE_FILE.delete()) {
                Log.i(TAG, "Deleted: " + filename);
            } else {
                Log.e(TAG, "Can't delete: " + filename);
            }
        }
    }

    // We keep the update logs (beginning with LAST_PREFIX), and optionally
    // the block map file (BLOCK_MAP_FILE) for a package. BLOCK_MAP_FILE
    // will be created at the end of a successful uncrypt. If seeing this
    // file, we keep the block map file and the file that contains the
    // package name (UNCRYPT_PACKAGE_FILE). This is to reduce the work for
    // GmsCore to avoid re-downloading everything again.
    String[] names = RECOVERY_DIR.list();
    for (int i = 0; names != null && i < names.length; i++) {
        // Do not remove the last_install file since the recovery-persist takes care of it.
        if (names[i].startsWith(LAST_PREFIX) || names[i].equals(LAST_INSTALL_PATH)) continue;
        if (reservePackage && names[i].equals(BLOCK_MAP_FILE.getName())) continue;
        if (reservePackage && names[i].equals(UNCRYPT_PACKAGE_FILE.getName())) continue;
     +   if (names[i].startsWith("kotlin")) continue;
        recursiveDelete(new File(RECOVERY_DIR, names[i]));
    }

    return log;
}

```



