



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Settings 显示菜单增加选择屏幕密度选项相关核心代码](#2.Settings%20%E6%98%BE%E7%A4%BA%E8%8F%9C%E5%8D%95%E5%A2%9E%E5%8A%A0%E9%80%89%E6%8B%A9%E5%B1%8F%E5%B9%95%E5%AF%86%E5%BA%A6%E9%80%89%E9%A1%B9%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.Settings 显示菜单增加选择屏幕密度选项的具体功能实现](#3.Settings%20%E6%98%BE%E7%A4%BA%E8%8F%9C%E5%8D%95%E5%A2%9E%E5%8A%A0%E9%80%89%E6%8B%A9%E5%B1%8F%E5%B9%95%E5%AF%86%E5%BA%A6%E9%80%89%E9%A1%B9%E7%9A%84%E5%85%B7%E4%BD%93%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)


[3.1 arrays.xml中添加密度选项的相关资源](#3.1%20arrays.xml%E4%B8%AD%E6%B7%BB%E5%8A%A0%E5%AF%86%E5%BA%A6%E9%80%89%E9%A1%B9%E7%9A%84%E7%9B%B8%E5%85%B3%E8%B5%84%E6%BA%90)


[3.2 在display\_settings.xml中增加布局](#3.2%20%E5%9C%A8display_settings.xml%E4%B8%AD%E5%A2%9E%E5%8A%A0%E5%B8%83%E5%B1%80)


[3.3 在DisplaySettings.java中 设置默认值](#3.3%20%E5%9C%A8DisplaySettings.java%E4%B8%AD%20%E8%AE%BE%E7%BD%AE%E9%BB%98%E8%AE%A4%E5%80%BC)




---



## 1.概述


在10.0的产品定制化开发中,在Settings的各种定制化也是系统上层常用的功能，由于客户要求在Settings中 的一级菜单红增加一个菜单来可以调整屏幕密度就是修改density的值  
 默认是320 可以选择160 240 320 480这几个选项，下面就来实现这个功能


## 2.Settings 显示菜单增加选择屏幕密度选项相关核心代码



```
相关核心代码:
packages\apps\Settings\res\values\arrays.xml
  packages/apps/Settings/res/xml/display_settings.xml
  packages/apps/Settings/src/com/android/settings/DisplaySettings.java
```

## 3.Settings 显示菜单增加选择屏幕密度选项的具体功能实现


#### 3.1 arrays.xml中添加密度选项的相关资源



```
路径:packages\apps\Settings\res\values\arrays.xml
<string-array name="entries_str">
        <item>160</item>
        <item>240</item>
        <item>320</item>
        <item>480</item>
    </string-array>
<string-array name="entries_values_str">
        <item>0</item>
        <item>1</item>
        <item>2</item>
        <item>3</item>
    </string-array>
```

####  3.2 在display\_settings.xml中增加布局



```
路径:packages/apps/Settings/res/xml/display_settings.xml
<PreferenceScreen
xmlns:android="http://schemas.android.com/apk/res/android"
xmlns:settings="http://schemas.android.com/apk/res-auto"
android:key="display_settings_screen"
android:title="@string/display_settings"
settings:keywords="@string/keywords_display"
settings:initialExpandedChildrenCount="5">

<com.android.settingslib.RestrictedPreference
android:key="brightness"
android:title="@string/brightness"
settings:keywords="@string/keywords_display_brightness_level"
settings:useAdminDisabledSummary="true"
settings:userRestriction="no_config_brightness">
<intent android:action="com.android.intent.action.SHOW_BRIGHTNESS_DIALOG" />
</com.android.settingslib.RestrictedPreference>

<com.android.settings.display.NightDisplayPreference
android:key="night_display"
android:title="@string/night_display_title"
android:fragment="com.android.settings.display.NightDisplaySettings"
android:widgetLayout="@null"
settings:widgetLayout="@null"
settings:searchable="false" />

<Preference
android:key="auto_brightness_entry"
android:title="@string/auto_brightness_title"
android:summary="@string/summary_placeholder"
android:fragment="com.android.settings.display.AutoBrightnessSettings"
settings:controller="com.android.settings.display.AutoBrightnessPreferenceController"/>

<com.android.settingslib.RestrictedPreference
android:key="wallpaper"
android:title="@string/wallpaper_settings_title"
settings:keywords="@string/keywords_display_wallpaper"
settings:useAdminDisabledSummary="true"
settings:controller="com.android.settings.display.WallpaperPreferenceController">
</com.android.settingslib.RestrictedPreference>


<SwitchPreference
android:key="dark_ui_mode"
android:title="@string/dark_ui_mode"
settings:keywords="@string/keywords_dark_ui_mode"
settings:controller="com.android.settings.display.DarkUIPreferenceController"/>

<!-- Cross-listed item, if you change this, also change it in power_usage_summary.xml -->
<com.android.settings.display.TimeoutListPreference
android:key="screen_timeout"
android:title="@string/screen_timeout"
android:summary="@string/summary_placeholder"
android:entries="@array/screen_timeout_entries"
android:entryValues="@array/screen_timeout_values"
settings:keywords="@string/keywords_screen_timeout" />

<Preference
android:key="adaptive_sleep_entry"
android:title="@string/adaptive_sleep_title"
android:summary="@string/summary_placeholder"
android:fragment="com.android.settings.display.AdaptiveSleepSettings"
settings:controller="com.android.settings.display.AdaptiveSleepPreferenceController" />

<SwitchPreference
android:key="auto_rotate"
android:title="@string/accelerometer_title"
settings:keywords="@string/keywords_auto_rotate"
settings:controller="com.android.settings.display.AutoRotatePreferenceController" />

<Preference
android:key="color_mode"
android:title="@string/color_mode_title"
android:fragment="com.android.settings.display.ColorModePreferenceFragment"
settings:controller="com.android.settings.display.ColorModePreferenceController"
settings:keywords="@string/keywords_color_mode" />

<SwitchPreference
android:key="display_white_balance"
android:title="@string/display_white_balance_title"
settings:controller="com.android.settings.display.DisplayWhiteBalancePreferenceController" />

<Preference
android:key="font_size"
android:title="@string/title_font_size"
android:fragment="com.android.settings.display.ToggleFontSizePreferenceFragment"
settings:controller="com.android.settings.display.FontSizePreferenceController" />

<com.android.settings.display.ScreenZoomPreference
android:key="display_settings_screen_zoom"
android:title="@string/screen_zoom_title"
android:fragment="com.android.settings.display.ScreenZoomSettings"
settings:searchable="false"/>

<SwitchPreference
android:key="show_operator_name"
android:title="@string/show_operator_name_title"
android:summary="@string/show_operator_name_summary" />

<Preference
android:key="screensaver"
android:title="@string/screensaver_settings_title"
android:fragment="com.android.settings.dream.DreamSettings"
settings:searchable="false" />

<com.android.settingslib.RestrictedPreference
android:key="lockscreen_from_display_settings"
android:title="@string/lockscreen_settings_title"
android:fragment="com.android.settings.security.LockscreenDashboardFragment"
settings:controller="com.android.settings.security.screenlock.LockScreenPreferenceController"
settings:userRestriction="no_ambient_display" />

<SwitchPreference
android:key="camera_gesture"
android:title="@string/camera_gesture_title"
android:summary="@string/camera_gesture_desc" />

<SwitchPreference
android:key="lift_to_wake"
android:title="@string/lift_to_wake_title" />

<SwitchPreference
android:key="tap_to_wake"
android:title="@string/tap_to_wake"
android:summary="@string/tap_to_wake_summary" />

<ListPreference
android:key="theme"
android:title="@string/device_theme"
android:summary="@string/summary_placeholder" />

<Preference
android:key="vr_display_pref"
android:title="@string/display_vr_pref_title"
android:fragment="com.android.settings.display.VrDisplayPreferencePicker" />

</PreferenceScreen>
--- a/packages/apps/Settings/res/xml/display_settings.xml
+++ b/packages/apps/Settings/res/xml/display_settings.xml
@@ -66,7 +66,13 @@
         android:title="@string/dark_ui_mode"
         settings:keywords="@string/keywords_dark_ui_mode"
         settings:controller="com.android.settings.display.DarkUIPreferenceController"/>
-
+    <ListPreference 
+            android:key="screen_density"
+            android:title="screen density"
+            android:entries="@array/entries_str"
+            android:entryValues="@array/entries_values_str"
+            android:dialogTitle="screen density"
+            />
     <!-- Cross-listed item, if you change this, also change it in power_usage_summary.xml -->
     <com.android.settings.display.TimeoutListPreference
         android:key="screen_timeout"

```

#### 3.3 在DisplaySettings.java中 设置默认值



```
packages/apps/Settings/src/com/android/settings/DisplaySettings.java
public class DisplaySettings extends DashboardFragment {
    private static final String TAG = "DisplaySettings";
    @Override
    public int getMetricsCategory() {
        return SettingsEnums.DISPLAY;
    }

    @Override
    protected String getLogTag() {
        return TAG;
    }

    @Override
    protected int getPreferenceScreenResId() {
        return R.xml.display_settings;
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        use(DarkUIPreferenceController.class).setParentFragment(this);
       }
}

在onCreate（）中设置就好了

修改如下:
--- a/packages/apps/Settings/src/com/android/settings/DisplaySettings.java
+++ b/packages/apps/Settings/src/com/android/settings/DisplaySettings.java
@@ -25,6 +25,7 @@ import android.os.Bundle;
 import android.os.sprdpower.PowerManagerEx;
 import android.provider.SearchIndexableResource;
 import androidx.preference.Preference;
+import androidx.preference.ListPreference;
 import androidx.preference.PreferenceScreen;
 
 import com.android.settings.dashboard.DashboardFragment;
@@ -61,6 +62,7 @@ public class DisplaySettings extends DashboardFragment {
        private static final String KEY_FONT_SIZE = "font_size";
     private static final String KEY_DISPLAY_SETTINGS = "display_settings_screen_zoom";
     private static final String KEY_SCREEN_SAVER = "screensaver";
+       private static final String KEY_SCREEN_DENSITY = "screen_density";
     @Override
     public int getMetricsCategory() {
         return SettingsEnums.DISPLAY;
@@ -88,6 +90,41 @@ public class DisplaySettings extends DashboardFragment {
                Preference font_size_pref = preferenceScreen.findPreference(KEY_FONT_SIZE);
                Preference display_settings_pref = preferenceScreen.findPreference(KEY_DISPLAY_SETTINGS);
                Preference screen_saver_pref = preferenceScreen.findPreference(KEY_SCREEN_SAVER);
+               final ListPreference screen_density_pref = (ListPreference)preferenceScreen.findPreference(KEY_SCREEN_DENSITY);
+               int density = getContext().getResources().getDisplayMetrics().densityDpi;  //获取当前的密度值
+               android.util.Log.e("DisplaySettings","density---:"+density);
+               if(density==320){
+                       screen_density_pref.setValueIndex(2);//根据密度值 选中对应的选项
+               }else if(density==240){
+                       screen_density_pref.setValueIndex(1);
+               }else if(density==160){
+                       screen_density_pref.setValueIndex(0);;
+               }else if(density==480){
+                       screen_density_pref.setValueIndex(3);
+               } 
+               
+               screen_density_pref.setSummary(density+"");
+               screen_density_pref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener(){
+            @Override
+            public boolean onPreferenceChange(Preference preference, Object o) {
+                               String value = (String)o;
+                               int densitydpi = 320;
+                               if(value.equals("0")){
+                                       densitydpi = 160;
+                               }else if(value.equals("1")){
+                                       densitydpi = 240;
+                               }else if(value.equals("2")){
+                                       densitydpi = 320;
+                               }else if(value.equals("3")){
+                                       densitydpi = 480;
+                               }
+                               android.util.Log.e("DisplaySettings","value:"+value+"---densitydpi:"+densitydpi);
+                               //screen_density_pref.setDefaultValue(value);
+                       screen_density_pref.setSummary(densitydpi+"");
+                               execShell("wm density " + densitydpi);
+                return false;
+            }
+        });
                int settings_custom = Settings.Global.getInt(getContext().getContentResolver(),"settings_custom",1);
                if(settings_custom==0){
                        if (pref != null) {
@@ -113,6 +150,24 @@ public class DisplaySettings extends DashboardFragment {
             }
                }
     }
+/**
+ *
+ * @param cmd
+ * @see
+ */
+public void execShell(String cmd) {
+    Process pro = null;
+    try {
+        pro = Runtime.getRuntime().exec(cmd);
+        pro.waitFor();
+        int value = pro.exitValue();
+        android.util.Log.e(TAG, "value:" + value);
+    } catch (Exception t) {
+        t.printStackTrace();
+    } finally {
+        pro.destroy();
+    }
+}
```



