



## 1.前言


在10.0的系统rom产品定制化开发中，在对Launcher3的folder文件夹功能定制中，要求folder文件夹跨行显示，就是 2x2布局显示，默认的都是占1格的，现在要求占4格显示，系统默认是不支持显示4格的，所以接下来需要分析相关的 功能，然后来实现这个功能


![](https://img-blog.csdnimg.cn/direct/736a12fdc48142be8f621c86626d1767.png)


## 2.Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\Launcher.java
packages\apps\Launcher3\src\com\android\launcher3\CellLayout.java
packages/apps/Launcher3/src/com/android/launcher3/WorkspaceLayoutManager.java
```

## 3.Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能分析和实现


在launcher3中初始化数据的时候，初始化创建launcher.db数据库，数据库里创建了两张表，分别是favorites，workspace 在数据库表中，\_id:用于标识区分各个应用图标，是表favorites的主键，当添加数据时通过generateNewId使\_id值增加。 title:在WorkSpace(HotSeat中一般会隐藏掉)中展示的应用快捷图标的标题。 intent:当点击桌面图标时的负责启动应用的intent，它通过Intent.toUri()转换为String存储，在使用时通过Intent.parseUri()转换为intent。 container:指的是当前数据所在的容器类型，在Launcher中有两种container类型：1.CONTAINER\_DESKTOP(-100)， 2.CONTAINER\_HOTSEAT(-101)。 screen:用于标识当前数据所在的页。当container为-100时，则screen的值表现为我们桌面的页数的值，当container为-101即当前快捷图标处于HotSeat时，则指快捷图标所在的第X个位置。 cellX:当前快捷图标所在页(CellLayout)的X位置，即快捷图标在当前页横向的第X个位置。 cellY:当前快捷图标所在页(CellLayout)的Y位置，即快捷图标在当前页纵向的第Y个位置。 spanX:当前快捷图标的在所在页(CellLayout)的横向范围信息，如果当前图标为application、shortcut、folder则为1，表示图标横向上占据一个cell的位置范围。如果当前图标为Widget，则横向占据范围可能为多个cell。 spanY:当前快捷图标的在所在页(CellLayout)的纵向范围信息，如果当前图标为application、shortcut、folder则为1，表示图标纵向上占据一个cell的位置范围。如果当前图标为Widget，则纵向占据范围可能为多个cell。 而在加载数据的时候，在AutoInstallsLayout.java负责解析xml的属性，然后添加到db数据库里面，而在 在Launcher3 中,工作区(Workspace)是指桌面上显示应用程序和小部件的区域 Workspace.java: 抽象的桌面。由N个cellLayout组成,从cellLayout更高一级的层面上对事件的处理。 CellLayout.java：Launcher布局的计算类，图标的显示边距等，组成workspace 的view,继承自viewgroup，既是一个dragSource又是一个dropTarget,可以将它里面 的item拖出去，也可以容纳拖动过来的item。在workspace\_screen里面定了一些它的view参数。


## 3.1 Launcher.java关于添加item的相关分析


在实现Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能中，通过上述的分析得知，在 Launcher.java中的相关源码分析得知，在这里插入相关item然后显示在桌面，接下来分析下相关源码



```
   @Override
    public void bindPredictedItems(List<AppInfo> appInfos, IntArray ranks) { }

    /**
     * Add the views for a widget to the workspace.
     */
    public void bindAppWidget(LauncherAppWidgetInfo item) {
        View view = inflateAppWidget(item);
        if (view != null) {
            mWorkspace.addInScreen(view, item);
            mWorkspace.requestLayout();
        }
    }
```

在实现Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能中，通过上述的分析得知，在 Launcher.java中的相关源码分析得知，在上述的bindAppWidget(LauncherAppWidgetInfo item)的方法中， 主要就是在调用mWorkspace.addInScreen(view, item);来绑定item,而mWorkspace.addInScreen(view, item);中 主要实现的是WorkspaceLayoutManager.java的addInScreen(view, item);的方法，接下来具体分析下 addInScreen(view, item);的相关源码 3.2 WorkspaceLayoutManager.java中的相关源码分析 在实现Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能中，通过上述的分析得知，在 WorkspaceLayoutManager.java中的相关源码分析得知，主要核心方法，就是根据item的x,y spanx spany等属性来 绑定workspace的功能实现，接下来分析下相关源码实现



```
 default void addInScreenFromBind(View child, ItemInfo info) {
        int x = info.cellX;
        int y = info.cellY;
        if (info.container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
            int screenId = info.screenId;
            x = getHotseat().getCellXFromOrder(screenId);
            y = getHotseat().getCellYFromOrder(screenId);
        }
        addInScreen(child, info.container, info.screenId, x, y, info.spanX, info.spanY);
    }

    default void addInScreen(View child, ItemInfo info) {
        addInScreen(child, info.container, info.screenId, info.cellX, info.cellY,
                info.spanX, info.spanY);
    }

    default void addInScreen(View child, int container, int screenId, int x, int y,
            int spanX, int spanY) {
        if (container == LauncherSettings.Favorites.CONTAINER_DESKTOP) {
            if (getScreenWithId(screenId) == null) {
                Log.e(TAG, "Skipping child, screenId " + screenId + " not found");
                // DEBUGGING - Print out the stack trace to see where we are adding from
                new Throwable().printStackTrace();
                return;
            }
        }
        if (screenId == EXTRA_EMPTY_SCREEN_ID) {
            // This should never happen
            throw new RuntimeException("Screen id should not be EXTRA_EMPTY_SCREEN_ID");
        }

        final CellLayout layout;
        if (container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
            layout = getHotseat();

            // Hide folder title in the hotseat
            if (child instanceof FolderIcon) {
                ((FolderIcon) child).setTextVisible(false);
            }
        } else {
            // Show folder title if not in the hotseat
            if (child instanceof FolderIcon) {
                ((FolderIcon) child).setTextVisible(true);
            }
            layout = getScreenWithId(screenId);
        }

        ViewGroup.LayoutParams genericLp = child.getLayoutParams();
        CellLayout.LayoutParams lp;
        if (genericLp == null || !(genericLp instanceof CellLayout.LayoutParams)) {
            lp = new CellLayout.LayoutParams(x, y, spanX, spanY);
        } else {
            lp = (CellLayout.LayoutParams) genericLp;
            lp.cellX = x;
            lp.cellY = y;
            lp.cellHSpan = spanX;
            lp.cellVSpan = spanY;
        }

        if (spanX < 0 && spanY < 0) {
            lp.isLockedToGrid = false;
        }

        // Get the canonical child id to uniquely represent this view in this screen
        ItemInfo info = (ItemInfo) child.getTag();
        int childId = info.getViewId();

        boolean markCellsAsOccupied = !(child instanceof Folder);
        if (!layout.addViewToCellLayout(child, -1, childId, lp, markCellsAsOccupied)) {
            // TODO: This branch occurs when the workspace is adding views
            // outside of the defined grid
            // maybe we should be deleting these items from the LauncherModel?
            Log.e(TAG, "Failed to add to item at (" + lp.cellX + "," + lp.cellY + ") to CellLayout");
        }

        child.setHapticFeedbackEnabled(false);
        child.setOnLongClickListener(ItemLongClickListener.INSTANCE_WORKSPACE);
        if (child instanceof DropTarget) {
            onAddDropTarget((DropTarget) child);
        }
    }

```

在实现Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能中，通过上述的分析得知，在 WorkspaceLayoutManager.java中的相关源码分析得知，在addInScreenFromBind(View child, ItemInfo info)绑定 workspace的item的方法中，最终调用addInScreen(View child, int container, int screenId, int x, int y, int spanX, int spanY) 来实现最终的绑定，而最终会调用layout.addViewToCellLayout(child, -1, childId, lp, markCellsAsOccupied) 实现绑定功能，接下来看下CellLayout.java的addViewToCellLayout(child, -1, childId, lp, markCellsAsOccupied)方法 看具体是如何绑定item的


## 3.3 CellLayout.java中相关绑定item的功能实现


在实现Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能中，通过上述的分析得知，在 CellLayout.java中的相关源码分析得知，在这个类中，具体实现item的边距，所占格数，item图标大小等功能，接下来 具体分析相关的实现



```
 public boolean addViewToCellLayout(View child, int index, int childId, LayoutParams params,
            boolean markCells) {
        final LayoutParams lp = params;

        // Hotseat icons - remove text
        if (child instanceof BubbleTextView) {
            BubbleTextView bubbleChild = (BubbleTextView) child;
            bubbleChild.setTextVisibility(mContainerType != HOTSEAT);
        }

//add core start
        if(child instanceof FolderIcon && lp.cellHSpan==2 && lp.cellVSpan==2){
           DeviceProfile grid = mActivity.getDeviceProfile();
           float scaleX = (float)(((grid.availableWidthPx-mCountX*grid.cellWidthPx)/(mCountX+1)*2+grid.cellWidthPx*2)/grid.cellWidthPx);
           float scaleY = (float)(((grid.availableHeightPx-mCountY*grid.cellHeightPx)/(mCountY)*2+grid.cellHeightPx*2)/grid.cellHeightPx);
           child.setScaleX(scaleX);
           child.setScaleY(scaleY);
        }else{
           child.setScaleX(mChildScale);
           child.setScaleY(mChildScale);
        }
//add core end

        // Generate an id for each view, this assumes we have at most 256x256 cells
        // per workspace screen
        if (lp.cellX >= 0 && lp.cellX <= mCountX - 1 && lp.cellY >= 0 && lp.cellY <= mCountY - 1) {
            // If the horizontal or vertical span is set to -1, it is taken to
            // mean that it spans the extent of the CellLayout
            if (lp.cellHSpan < 0) lp.cellHSpan = mCountX;
            if (lp.cellVSpan < 0) lp.cellVSpan = mCountY;

            child.setId(childId);
            if (LOGD) {
                Log.d(TAG, "Adding view to ShortcutsAndWidgetsContainer: " + child);
            }
            mShortcutsAndWidgets.addView(child, index, lp);

            if (markCells) markCellsAsOccupiedForView(child);

            return true;
        }
        return false;
    }
```

在实现Launcher3定制folder文件夹2x2布局之二foldericon的2x2的显示布局的核心功能中，通过上述的分析得知，在 CellLayout.java中的相关源码分析得知，在上述方法中，通过判断child是否是FolderIcon,然后通过调用setScaleX 和setScaleY方法来具体的进行缩放功能，默认是1的所以不会占满2x2的布局，需要计算格数的大小，然后设置 布局，通过这种方法来实现相关功能



