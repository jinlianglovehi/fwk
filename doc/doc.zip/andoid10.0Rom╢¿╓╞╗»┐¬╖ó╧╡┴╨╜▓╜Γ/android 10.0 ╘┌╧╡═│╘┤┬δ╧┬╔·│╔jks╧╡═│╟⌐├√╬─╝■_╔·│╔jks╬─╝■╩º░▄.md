






在系统开发中，会遇到在app在线升级的时候，会升级失败，由于app自己用自己的签名文件签名的  
 所以会和系统签名文件不一样，导致会出现一些问题  
 所以为了解决这一个问题 就得使用系统生成的签名文件 给app使用就可以解决这个问题


1.在系统源码下生成系统签名


1. cd到build/target/product/security/ 目录下 这里面有相关的签名文件
2. 执行 openssl pkcs8 -inform DER -nocrypt -in platform.pk8 -out platform.pem  
 然后生成platform.pem文件


3、执行 openssl pkcs12 -export -in platform.x509.pem -out platform.p12 -inkey platform.pem -password pass:pnr123456 -name pnrjks


生成platform.p12文件，其中-name pnrjks 为alias名（app添加签名要用到），pnr123456 为密码,有pass这个属性赋值。


4、执行 keytool -importkeystore -deststorepass pnr123456 -destkeystore platform.jks -srckeystore platform.p12 -srcstoretype PKCS12 -srcstorepass pnr123456


生成platform.jks （app打签名最终用到的文件），其中-deststorepass pnr123456设置的是这个签名的密码，上面指令中的-src\*的其他参数都是从前面两个指令中生成的。


经过上面的命令 后 在 build/target/product/security/ 下生成了platform.jks 签名文件 alias 为pnrjks password 为pnr123456


2. 在app 中 使用platform.jks 签名文件



```
android {



    signingConfigs {

        release {

            storeFile file("${project.getRootDir()}/signkey/platform.jks") // 签名文件路径

            storePassword '签名文件密码'

            keyAlias 'pnrjks'

            keyPassword '签名文件密码'

        }



        debug {

            storeFile file("${project.getRootDir()}/signkey/platform.jks") // 签名文件路径

            storePassword 'pnr123456'

            keyAlias 'pnrjks'

            keyPassword 'pnr123456'

        }

    }

}

```




