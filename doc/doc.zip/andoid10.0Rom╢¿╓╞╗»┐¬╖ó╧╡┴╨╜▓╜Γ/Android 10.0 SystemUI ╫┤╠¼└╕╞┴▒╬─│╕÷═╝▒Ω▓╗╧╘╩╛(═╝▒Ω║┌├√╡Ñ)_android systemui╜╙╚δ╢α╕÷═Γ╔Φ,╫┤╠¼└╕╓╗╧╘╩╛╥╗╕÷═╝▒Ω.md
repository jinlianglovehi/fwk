






### 1.概述


在10.0的系统产品开发中，在SystemUI 状态栏上面有第三方app发送或者usb 蓝牙 wifi连接会在通知区域显示图标 但是有些不想让显示出来 就得屏蔽掉了而状态栏图标都是由 StatusBarIconController.java 来负责控制显示的


### 2.SystemUI 状态栏屏蔽某个图标不显示(图标黑名单)的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarIconController.java

```

### 3.SystemUI 状态栏屏蔽某个图标不显示(图标黑名单)的核心功能分析和实现


从SystemUI的源码可以看出状态栏的图标都是在StatusBarIconController.java控制显示和隐藏的所以  
 接下来看StatusBarIconController.java 的源码


路径为：frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarIconController.java



```
public interface StatusBarIconController {

    /**
     * When an icon is added with TAG_PRIMARY, it will be treated as the primary icon
     * in that slot and not added as a sub slot.
     */
    public static final int TAG_PRIMARY = 0;

    public void addIconGroup(IconManager iconManager);
    public void removeIconGroup(IconManager iconManager);
    public void setExternalIcon(String slot);
    public void setIcon(String slot, int resourceId, CharSequence contentDescription);
    public void setIcon(String slot, StatusBarIcon icon);
    public void setSignalIcon(String slot, WifiIconState state);
    public void setMobileIcons(String slot, List<MobileIconState> states);
    public void setIconVisibility(String slot, boolean b);
    /**
     * If you don't know what to pass for `tag`, either remove all icons for slot, or use
     * TAG_PRIMARY to refer to the first icon at a given slot.
     */
    public void removeIcon(String slot, int tag);
    public void removeAllIconsForSlot(String slot);

    public static final String ICON_BLACKLIST = "icon\_blacklist";

    /*UNISOC bug 886416:New feature for display headset default*/
    public boolean HEADSET_DEFAULT_SET = SystemProperties.getBoolean("ro.product.headseticon",true);
    /*@}*/

    public static ArraySet<String> getIconBlacklist(String blackListStr) {
        ArraySet<String> ret = new ArraySet<>();
        if (blackListStr == null) {
            /*UNISOC bug 886416:New feature for display headset default*/
            if(HEADSET_DEFAULT_SET){
                blackListStr = "rotate";
            }else{
                blackListStr = "rotate,headset";
            }
            /*@}*/
        }
        String[] blacklist = blackListStr.split(",");
        for (String slot : blacklist) {
            if (!TextUtils.isEmpty(slot)) {
                ret.add(slot);
            }
        }
        return ret;
    }

.......
    private void setHeightAndCenter(ImageView imageView, int height) {
             ViewGroup.LayoutParams params = imageView.getLayoutParams();
             params.height = height;
             if (params instanceof LinearLayout.LayoutParams) {
                 ((LinearLayout.LayoutParams) params).gravity = Gravity.CENTER\_VERTICAL;
 }
 imageView.setLayoutParams(params);
 }
 
 protected void onRemoveIcon(int viewIndex) {
 if (mIsInDemoMode) {
 mDemoStatusIcons.onRemoveIcon((StatusIconDisplayable) mGroup.getChildAt(viewIndex));
             }
             mGroup.removeViewAt(viewIndex);
         }
 
         public void onSetIcon(int viewIndex, StatusBarIcon icon) {
             StatusBarIconView view = (StatusBarIconView) mGroup.getChildAt(viewIndex);
             view.set(icon);
         }
 
         public void onSetIconHolder(int viewIndex, StatusBarIconHolder holder) {
             switch (holder.getType()) {
                 case TYPE_ICON:
                     onSetIcon(viewIndex, holder.getIcon());
                     return;
                 case TYPE_WIFI:
                     onSetSignalIcon(viewIndex, holder.getWifiState());
                     return;
 
                 case TYPE_MOBILE:
                     onSetMobileIcon(viewIndex, holder.getMobileState());
                 default:
                     break;
             }
         }
 
         public void onSetSignalIcon(int viewIndex, WifiIconState state) {
             StatusBarWifiView wifiView = (StatusBarWifiView) mGroup.getChildAt(viewIndex);
             if (wifiView != null) {
                 wifiView.applyWifiState(state);
             }
 
             if (mIsInDemoMode) {
                 mDemoStatusIcons.updateWifiState(state);
             }
         }
 
         public void onSetMobileIcon(int viewIndex, MobileIconState state) {
             StatusBarMobileView view = (StatusBarMobileView) mGroup.getChildAt(viewIndex);
             if (view != null) {
                 view.applyMobileState(state);
             }
 
             if (mIsInDemoMode) {
                 mDemoStatusIcons.updateMobileState(state);
             }
         }
     }
}

```

从StatusBarIconController 的相关代码中可以看出getIconBlacklist(String blackListStr)  
 这里就是状态栏黑名单icon 方法  
 默认blackListStr 是不显示穿戴设备和旋转图标的  
 所以要新增和删除就在这里添加了


添加名称为：  
 frameworks\base\packages\SystemUI\res\xml\tuner\_prefs.xml



```
<com.android.systemui.tuner.StatusBarSwitch
            android:key="rotate"
            android:title="@string/status\_bar\_settings\_auto\_rotation" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="headset"
            android:title="@string/headset" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="managed\_profile"
            android:title="@string/status\_bar\_work" />

        <!-- ime -->
        <!-- sync_failing -->
        <!-- sync_active -->

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="cast"
            android:title="@string/quick\_settings\_cast\_title" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="hotspot"
            android:title="@string/quick\_settings\_hotspot\_label" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="bluetooth"
            android:title="@string/quick\_settings\_bluetooth\_label" />

        <!-- nfc -->
        <!-- tty -->
        <!-- speakerphone -->

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="zen"
            android:title="@string/quick\_settings\_dnd\_label" />

        <!-- mute -->

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="volume"
            android:title="@\*android:string/volume\_unknown" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="wifi"
            android:title="@string/quick\_settings\_wifi\_label" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="ethernet"
            android:title="@string/status\_bar\_ethernet" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="mobile"
            android:title="@string/quick\_settings\_cellular\_detail\_title" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="airplane"
            android:title="@string/status\_bar\_airplane" />

        <!-- other weird signal stuff -->

        <com.android.systemui.tuner.BatteryPreference
            android:title="@string/battery"
            android:summary="%s"
            android:entries="@array/battery\_options" />

        <com.android.systemui.tuner.StatusBarSwitch
            android:key="alarm\_clock"
            android:title="@string/status\_bar\_alarm" />

```

在tuner\_prefs.xml中增加com.android.systemui.tuner.StatusBarSwitch的这样的穿戴设备和旋转  
 添加这样的key 值即可





