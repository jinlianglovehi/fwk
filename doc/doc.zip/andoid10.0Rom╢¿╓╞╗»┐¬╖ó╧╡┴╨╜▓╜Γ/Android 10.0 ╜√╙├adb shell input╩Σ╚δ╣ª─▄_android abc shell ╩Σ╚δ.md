



## 1.前言


在10.0的产品开发中，在进行一些定制开发中，对于一些adb shell功能需要通过属性来控制禁止使用input 等输入功能，比如adb shell input keyevent  
 响应输入事件等，所以就需要  
 熟悉adb shell input的输入事件流程，然后来禁用adb shell input的输入事件功能，接下来分析下adb shell input的输入事件下的输入事件流程


如图:


![](https://img-blog.csdnimg.cn/7258a4e6b9f24244873cafbc688518c3.png)


![](https://img-blog.csdnimg.cn/50fd85fde097486888ca81cca7a5cc8c.png)


## 2.禁用adb shell input输入功能的核心类



```
system\core\adb\services.cpp
system\core\adb\daemon\services.cpp
```

## 3.禁用adb shell input输入功能的核心功能分析和实现


禁用adb shell input输入功能的核心功能实现中，


而adb 是pc端工具，adbd是[服务端](https://so.csdn.net/so/search?q=%E6%9C%8D%E5%8A%A1%E7%AB%AF&spm=1001.2101.3001.7020 "服务端")，运行在手机 adbd 读取 socket 解析由 adb 传过来的命令串，解析相关的命令执行相关功能，所以在pc端输入adb 相关命令 就会在system\core\adb 模块解析相关命令  
 在system\core\adb的相关模块中，在adbd和pc端通过adb 命令通讯的时候，在adb\services.cpp作为服务端来接收相关的  
 CommandLine指令，所以根据具体的参数来调用相应的模块进行通讯，所以关于adb shell的相关命令需要分析下  
 adb\services.cpp的相关源码


## 3.1 adb\services.cpp中的相关源码分析


禁用adb shell input输入功能的核心功能实现中，在system\core\adb的相关模块中，在上述的分析得知，在解析pc端发送过来的adb命令中，在adb/services.cpp中负责解析相关input输入功能的


相关命令，接下来分析下adb shell input的相关源码



```
unique_fd service_to_fd(std::string_view name, atransport* transport) {
    unique_fd ret;

    if (is_socket_spec(name)) {
        std::string error;
        if (!socket_spec_connect(&ret, name, nullptr, nullptr, &error)) {
            LOG(ERROR) << "failed to connect to socket '" << name << "': " << error;
        }
    } else {
#if !ADB_HOST
        ret = daemon_service_to_fd(name, transport);
#endif
    }

    if (ret >= 0) {
        close_on_exec(ret.get());
    }
    return ret;
}
```

禁用adb shell input输入功能的核心功能实现中，在adb\services.cpp中的上述源码中，在service\_to\_fd(std::string\_view name, atransport\* transport)负责接收  
 pc客户端发过来的指令，然后调用daemon\_service\_to\_fd(name, transport);来具体解析相关的功能操作  
 所以说具体的功能解析是在adb\daemon\services.cpp的daemon\_service\_to\_fd(name, transport);方法  
 接下来分析下adb\daemon\services.cpp的相关源码


## 3.2adb\daemon\services.cpp的相关源码分析


禁用adb shell input输入功能的核心功能实现中，在system/adb的模块中，在上述的adb\daemon\services.cpp的相关源码分析得知，主要的核心功能都是在adb\daemon\services.cpp的相关源码中分析实现的，接下来分析下相关的源码



```
unique_fd daemon_service_to_fd(std::string_view name, atransport* transport) {
#if defined(__ANDROID__) && !defined(__ANDROID_RECOVERY__)
    if (name.starts_with("abb:") || name.starts_with("abb_exec:")) {
        return execute_abb_command(name);
    }
#endif

#if defined(__ANDROID__)
    if (name.starts_with("framebuffer:")) {
        return create_service_thread("fb", framebuffer_service);
    } else if (ConsumePrefix(&name, "remount:")) {
        std::string arg(name);
        return create_service_thread("remount",
                                     std::bind(remount_service, std::placeholders::_1, arg));
    } else if (ConsumePrefix(&name, "reboot:")) {
        std::string arg(name);
        return create_service_thread("reboot",
                                     std::bind(reboot_service, std::placeholders::_1, arg));
    } else if (name.starts_with("root:")) {
        return create_service_thread("root", restart_root_service);
    } else if (name.starts_with("unroot:")) {
        return create_service_thread("unroot", restart_unroot_service);
    } else if (ConsumePrefix(&name, "backup:")) {
        std::string cmd = "/system/bin/bu backup ";
        cmd += name;
        return StartSubprocess(cmd, nullptr, SubprocessType::kRaw, SubprocessProtocol::kNone);
    } else if (name.starts_with("restore:")) {
        return StartSubprocess("/system/bin/bu restore", nullptr, SubprocessType::kRaw,
                               SubprocessProtocol::kNone);
    } else if (name.starts_with("disable-verity:")) {
        return create_service_thread("verity-on", std::bind(set_verity_enabled_state_service,
                                                            std::placeholders::_1, false));
    } else if (name.starts_with("enable-verity:")) {
        return create_service_thread("verity-off", std::bind(set_verity_enabled_state_service,
                                                             std::placeholders::_1, true));
    } else if (ConsumePrefix(&name, "tcpip:")) {
        std::string str(name);

        int port;
        if (sscanf(str.c_str(), "%d", &port) != 1) {
            return unique_fd{};
        }
        return create_service_thread("tcp",
                                     std::bind(restart_tcp_service, std::placeholders::_1, port));
    } else if (name.starts_with("usb:")) {
        return create_service_thread("usb", restart_usb_service);
    }
#endif

    if (ConsumePrefix(&name, "dev:")) {
        return unique_fd{unix_open(name, O_RDWR | O_CLOEXEC)};
    } else if (ConsumePrefix(&name, "jdwp:")) {
        pid_t pid;
        if (!ParseUint(&pid, name)) {
            return unique_fd{};
        }
        return create_jdwp_connection_fd(pid);
    } else if (ConsumePrefix(&name, "shell")) {
        return ShellService(name, transport);
    } else if (ConsumePrefix(&name, "exec:")) {
        return StartSubprocess(std::string(name), nullptr, SubprocessType::kRaw,
                               SubprocessProtocol::kNone);
    } else if (name.starts_with("sync:")) {
        return create_service_thread("sync", file_sync_service);
    } else if (ConsumePrefix(&name, "reverse:")) {
        return reverse_service(name, transport);
    } else if (name == "reconnect") {
        return create_service_thread(
                "reconnect", std::bind(reconnect_service, std::placeholders::_1, transport));
    } else if (name == "spin") {
        return create_service_thread("spin", spin_service);
    }

    return unique_fd{};
}
```

禁用adb shell input输入功能的核心功能实现中，在adb\daemon\services.cpp的相关源码分析得知，在  
  else if (ConsumePrefix(&name, "shell")) {  
         return ShellService(name, transport);  
     }  
 中负责解析相关adb shell的相关命令，具体实现adb shell的相关命令响应是  
 在ShellService(name, transport);中接下来分析下ShellService(name, transport);相关源码



```
//add core start
#include <stdio.h>
bool isAllowInput() {
	std::string value = android::base::GetProperty("persist.sys.isallow", "true");
	if (strcmp("true", value.c_str()) == 0)
                    return true;
	else
	  return false;	
}
//add core end

// Shell service string can look like:
//   shell[,arg1,arg2,...]:[command]
unique_fd ShellService(std::string_view args, const atransport* transport) {
    size_t delimiter_index = args.find(':');
    if (delimiter_index == std::string::npos) {
        LOG(ERROR) << "No ':' found in shell service arguments: " << args;
        return unique_fd{};
    }

//add core start
    LOG(ERROR) << "shell service arguments: " << args;
    std::string::size_type idx=args.find("input");
	if(idx == std::string::npos ){
	     LOG(ERROR) << "the command do not include input string";
	}else{
	  if(!isAllowInstall()) {
	     LOG(ERROR) << "can not allow to input" ;
	     return unique_fd{};
	  }else {
	     LOG(ERROR) << "Allow to input";
                  }
	}
//add core end

    // TODO: android::base::Split(const std::string_view&, ...)
    std::string service_args(args.substr(0, delimiter_index));
    std::string command(args.substr(delimiter_index + 1));

    // Defaults:
    //   PTY for interactive, raw for non-interactive.
    //   No protocol.
    //   $TERM set to "dumb".
    SubprocessType type(command.empty() ? SubprocessType::kPty : SubprocessType::kRaw);
    SubprocessProtocol protocol = SubprocessProtocol::kNone;
    std::string terminal_type = "dumb";

    for (const std::string& arg : android::base::Split(service_args, ",")) {
        if (arg == kShellServiceArgRaw) {
            type = SubprocessType::kRaw;
        } else if (arg == kShellServiceArgPty) {
            type = SubprocessType::kPty;
        } else if (arg == kShellServiceArgShellProtocol) {
            protocol = SubprocessProtocol::kShell;
        } else if (arg.starts_with("TERM=")) {
            terminal_type = arg.substr(strlen("TERM="));
        } else if (!arg.empty()) {
            // This is not an error to allow for future expansion.
            LOG(WARNING) << "Ignoring unknown shell service argument: " << arg;
        }
    }

    return StartSubprocess(command, terminal_type.c_str(), type, protocol);
}

```

禁用adb shell input输入功能的核心功能实现中，在adb\daemon\services.cpp的相关源码分析得知，在  
 ShellService(std::string\_view args, const atransport\* transport)中负责响应shell的相关命令  
 所以可以在args的命令参数中，可以判断是否包含input输入命令，然后  
 根据系统属性persist.sys.isallow是否允许响应，如果为false 就返回unique\_fd{};  
 这样就实现了禁用adb shell input输入事件的响应



