






### 1.概述


在10.0 的系统产品开发中，对于SystemUI的下拉状态栏中的二次展开和第一次展开的时候,QSPanel中功能开关键的字体，字体会随着系统字体的改变，这样会导致字体变的很大，布局变得不协调，所以产品需求要求，不随系统字体改变而改变，首选要找到布局字体的相关类通过查阅QSPanel的相关源代码发现，功能开关的的相关布局发现


### 2. SystemUI 下拉状态栏QSPanel当字体大小改变时不改变QSTileView字体的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSTileView.java

```

### 3. SystemUI 下拉状态栏QSPanel当字体大小改变时不改变QSTileView字体核心功能分析和实现


通过系统代码可以发现功能开关的布局就是QSTileView.java，对于字体的改变也是在这里处理的  
 路径是 frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSTileView.java


于是就来看相关代码



```
 public class QSTileView extends QSTileBaseView {
 
     public QSTileView(Context context, QSIconView icon) {
         this(context, icon, false);
     }
 
     public QSTileView(Context context, QSIconView icon, boolean collapsedView) {
         super(context, icon, collapsedView);
 
         setClipChildren(false);
         setClipToPadding(false);
 
         setClickable(true);
         setId(View.generateViewId());
         createLabel();
         setOrientation(VERTICAL);
         setGravity(Gravity.CENTER_HORIZONTAL | Gravity.TOP);
         mColorLabelDefault = Utils.getColorAttr(getContext(), android.R.attr.textColorPrimary);
         // The text color for unavailable tiles is textColorSecondary, same as secondaryLabel for
         // contrast purposes
         mColorLabelUnavailable = Utils.getColorAttr(getContext(),
                 android.R.attr.textColorSecondary);
     }
 
     TextView getLabel() {
         return mLabel;
     }
 
     @Override
     protected void onConfigurationChanged(Configuration newConfig) {
         super.onConfigurationChanged(newConfig);
         FontSizeUtils.updateFontSize(mLabel, R.dimen.qs_tile_text_size);
         FontSizeUtils.updateFontSize(mSecondLine, R.dimen.qs_tile_text_size);
     }
 
     @Override
     public int getDetailY() {
         return getTop() + mLabelContainer.getTop() + mLabelContainer.getHeight() / 2;
     }
 
     protected void createLabel() {
         mLabelContainer = (ViewGroup) LayoutInflater.from(getContext())
                 .inflate(R.layout.qs_tile_label, this, false);
         mLabelContainer.setClipChildren(false);
         mLabelContainer.setClipToPadding(false);
         mLabel = mLabelContainer.findViewById(R.id.tile_label);
         mPadLock = mLabelContainer.findViewById(R.id.restricted_padlock);
         mDivider = mLabelContainer.findViewById(R.id.underline);
         mExpandIndicator = mLabelContainer.findViewById(R.id.expand_indicator);
         mExpandSpace = mLabelContainer.findViewById(R.id.expand_space);
          mSecondLine = mLabelContainer.findViewById(R.id.app_label);
          addView(mLabelContainer);
      }

```

在QSTileView的构造方法中通过setOrientation(VERTICAL);设置布局为竖向布局，而在通过Gravity的相关属性  
 setGravity(Gravity.CENTER\_HORIZONTAL | Gravity.TOP);  
 设置属性为置顶垂直居中显示布局的，接下来具体看相关的绘制流程



```
      @Override
      protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
          super.onMeasure(widthMeasureSpec, heightMeasureSpec);
  
          // Remeasure view if the primary label requires more then 2 lines or the secondary label
          // text will be cut off.
          if (mLabel.getLineCount() > MAX_LABEL_LINES || !TextUtils.isEmpty(mSecondLine.getText())
                          && mSecondLine.getLineHeight() > mSecondLine.getHeight()) {
              mLabel.setSingleLine();
              super.onMeasure(widthMeasureSpec, heightMeasureSpec);
          }
      }
  
      @Override
      protected void handleStateChanged(QSTile.State state) {
          super.handleStateChanged(state);
          if (!Objects.equals(mLabel.getText(), state.label) || mState != state.state) {
              mLabel.setTextColor(state.state == Tile.STATE_UNAVAILABLE ? mColorLabelUnavailable
                      : mColorLabelDefault);
              mState = state.state;
              mLabel.setText(state.label);
          }
          if (!Objects.equals(mSecondLine.getText(), state.secondaryLabel)) {
              mSecondLine.setText(state.secondaryLabel);
              mSecondLine.setVisibility(TextUtils.isEmpty(state.secondaryLabel) ? View.GONE
                      : View.VISIBLE);
          }
          boolean dualTarget = DUAL_TARGET_ALLOWED && state.dualTarget;
          mExpandIndicator.setVisibility(dualTarget ? View.VISIBLE : View.GONE);
          mExpandSpace.setVisibility(dualTarget ? View.VISIBLE : View.GONE);
          mLabelContainer.setContentDescription(dualTarget ? state.dualLabelContentDescription
                  : null);
          if (dualTarget != mLabelContainer.isClickable()) {
              mLabelContainer.setClickable(dualTarget);
              mLabelContainer.setLongClickable(dualTarget);
              mLabelContainer.setBackground(dualTarget ? newTileBackground() : null);
          }
          mLabel.setEnabled(!state.disabledByPolicy);
          mPadLock.setVisibility(state.disabledByPolicy ? View.VISIBLE : View.GONE);
      }
  
      @Override
      public void init(OnClickListener click, OnClickListener secondaryClick,
              OnLongClickListener longClick) {
          super.init(click, secondaryClick, longClick);
          mLabelContainer.setOnClickListener(secondaryClick);
          mLabelContainer.setOnLongClickListener(longClick);
          mLabelContainer.setClickable(false);
          mLabelContainer.setLongClickable(false);
      }
  }

```

在QSTileView.java中的onMeasure(int widthMeasureSpec, int heightMeasureSpec)，根据字体的大小重绘每个Tile的文字而它是随着protected void onConfigurationChanged(Configuration newConfig)这个方法  
 就是根据系统的Configuration的相关属性变化的时候，会在这里改变当前页面的字体等功能  
 发现onConfigurationChanged 就是系统字体改变时就是要执行的方法  
 所以具体修改如下:



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSTileView.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSTileView.java

@@ -78,8 +78,8 @@ public class QSTileView extends QSTileBaseView {

     @Override

     protected void onConfigurationChanged(Configuration newConfig) {


-        FontSizeUtils.updateFontSize(mLabel, R.dimen.qs_tile_text_size);

-        FontSizeUtils.updateFontSize(mSecondLine, R.dimen.qs_tile_text_size);

+        //FontSizeUtils.updateFontSize(mLabel, R.dimen.qs_tile_text_size);

+        //FontSizeUtils.updateFontSize(mSecondLine, R.dimen.qs_tile_text_size);

     }

```

在onConfigurationChanged(Configuration newConfig)去掉关于设置字体的相关类的关于随系统Configuration属性改变而改变的对Tile文字做改变功能，就实现了不改变QSTileView的字体的功能  
 然后编译SystemUI 验证后发现问题已经解决





