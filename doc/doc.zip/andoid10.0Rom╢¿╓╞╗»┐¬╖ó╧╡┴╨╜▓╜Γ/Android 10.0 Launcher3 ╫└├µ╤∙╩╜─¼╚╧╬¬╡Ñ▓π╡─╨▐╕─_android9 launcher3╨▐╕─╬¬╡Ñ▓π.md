






在展讯平台，10.0中 桌面长按会弹出主屏幕设置 就是SettingsActivity 里面的一些布局文件 会有一些选项 来设置桌面布局的一些选项  
 布局中有桌面样式 的选项 分单层和双层 接下来就看怎么默认选择单层


桌面样式 其实就是home\_screen\_style\_title  
 接下来就来搜寻哪里引用这个属性



```
packages/apps/Launcher3/res/xml/launcher_preferences_extension.xml
<?xml version="1.0" encoding="utf-8"?>
<PreferenceScreen xmlns:android="http://schemas.android.com/apk/res/android">
<SwitchPreference
android:key="pref\_circular\_slide\_switch"
android:title="@string/allow\_circular\_sliding\_title"
android:defaultValue="@bool/default\_circle\_slide"
android:summary="@string/allow\_circular\_sliding\_summary" />
<ListPreference
android:key="pref\_pulldown\_action"
android:title="@string/pull\_down\_action\_pref\_title"
android:summary="%s"
android:entries="@array/pull\_down\_action\_entries"
android:entryValues="@array/pull\_down\_action\_values"
android:defaultValue="@string/default\_pull\_down\_value" />
<Preference
android:key="pref\_dynamicIcon"
android:title="@string/dynamic\_icon\_title"
android:persistent="false" />
<Preference
android:key="pref\_unread"
android:title="@string/unread\_notifier\_title"
android:persistent="false" />
<SwitchPreference
android:key="pref\_notification\_dots\_ext"
android:title="@string/notification\_dots\_ext\_title"
android:summary="@string/notification\_dots\_ext\_summary"
android:defaultValue="@bool/show\_notification\_dots\_num" />
<ListPreference
android:key="pref\_home\_screen\_style"
android:title="@string/home\_screen\_style\_title"
android:summary="%s"
android:entries="@array/home\_screen\_style\_entries"
android:entryValues="@array/home\_screen\_style\_values"
android:defaultValue="@string/default\_home\_screen\_style" />
<ListPreference
android:key="pref\_folder\_icon\_model"
android:title="@string/folder\_icon\_model\_pref\_title"
android:summary="%s"/>
<ListPreference
android:key="pref\_desktop\_grid"
android:title="@string/desktop\_grid"
android:summary="%s"
android:persistent="false" />
<SwitchPreference
android:key="pref\_icon\_label\_line"
android:title="@string/icon\_label\_line\_title"
android:defaultValue="@bool/enable\_icon\_label\_show\_double\_lines" />
</PreferenceScreen>

```

发现和界面的内容一致都是在这里的



```
<ListPreference
android:key="pref\_home\_screen\_style"
android:title="@string/home\_screen\_style\_title"
android:summary="%s"
android:entries="@array/home\_screen\_style\_entries"
android:entryValues="@array/home\_screen\_style\_values"
android:defaultValue="@string/default\_home\_screen\_style" />

```

就是桌面样式的选择项


home\_screen\_style\_values 在  
 packages\apps\Launcher3\res\values\arrays\_ext.xml



```
<string-array name="home\_screen\_style\_values" translatable="false">
    <item>single</item>
    <item>dual</item>
</string-array>

```

就是所谓的单双层选项 single单层 dual双层


下面就让默认值为single就可以了设置default\_home\_screen\_style的值



```
packages\apps\Launcher3\res\values\config_ext.xml
<string name="default\_home\_screen\_style" translatable="false">single</string>

```

修改default\_home\_screen\_style的值即可





