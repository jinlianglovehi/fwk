



## 1.1概述


  
  在10.0的系统rom定制化开发中，在原生系统Launcher3中是可以通过下滑workspace来下拉出状态栏的，然而在禁用systemui下拉状态栏的时候，是可以通过Launcher3下滑  
 workspace页面下拉出状态栏，也是不合理的，所以也同时需要禁用Launcher3中的下拉状态栏的功能，接下来就来分析下Launcher3中在workspace中通过下滑下拉出  
 状态栏的相关源码,来实现禁用workspace中通过下滑下拉状态栏功能


## 2.1Launcher3中workspaces桌面去掉下拉状态栏功能的核心类



```
packages/apps/Launcher3/quickstep/src/com/android/launcher3/uioverrides/touchcontrollers/StatusBarTouchController.java
packages/apps/Launcher3/go/quickstep/src/com/android/launcher3/uioverrides/RecentsUiFactory.java
packages/apps/Launcher3/src/com/android/launcher3/dragndrop/DragLayer.java

```

## 3.Launcher3中workspaces桌面去掉下拉状态栏功能的核心功能分析和实现


## 


在Launcher3主页面布局文件就是launcher.xml而 launcher.xml的View树结构的最顶层是DragLayer，接下来是WorkSpace，  
 然后是CellLayout，最后是BubbleTextView。我们查看源代码可以发现，DragLayer.Java, WorkSpace.java,  
 CellLayout.java(某一屏),BubbleTextView.java(某一个app)都没有实现dispathTouchEvent,而onTouch执行流程是  
 最顶层父控件的dispathTouchEvent(是否接受后续动作【DOWN设置为true，表示接受后续动作】)  
 -------最顶层父控件的onInterceptTouchEvent(是否拦截事件【View Group才有】)---------  
 子层控件的dispathTouchEvent-------子控件的onTouchEvent，所以就需要根据实际情况来分析  
 Launcher3的下拉出来实际是在哪里，根据源码分析得知具体处理是在StatusBarTouchController.java中，处理  
 相关的下拉流程，接下来分析下相关源码



##   3.1StatusBarTouchController.java关于workspace下滑触摸事件的分析



```
   /**
   * TouchController for handling touch events that get sent to the StatusBar. Once the
   * Once the event delta y passes the touch slop, the events start getting forwarded.
   * All events are offset by initial Y value of the pointer.
   */
  public class StatusBarTouchController implements TouchController {
  
      private static final String TAG = "StatusBarController";
  
      protected final Launcher mLauncher;
      protected final TouchEventTranslator mTranslator;
      private final float mTouchSlop;
      private ISystemUiProxy mSysUiProxy;
      private int mLastAction;
  
      /* If {@code false}, this controller should not handle the input {@link MotionEvent}.*/
      private boolean mCanIntercept;
  
      public StatusBarTouchController(Launcher l) {
          mLauncher = l;
          // Guard against TAPs by increasing the touch slop.
          mTouchSlop = 2 * ViewConfiguration.get(l).getScaledTouchSlop();
          mTranslator = new TouchEventTranslator((MotionEvent ev)-> dispatchTouchEvent(ev));
      }
```

在StatusBarTouchController.java的上述方法中，在StatusBarTouchController(Launcher l)的相关构造方法中，通过TouchEventTranslator  
 来执行dispatchTouchEvent(ev));这个处理触摸事件的方法，而在mTouchSlop变量设置处理滑动最小距离的参数，接下来分析下  
 dispatchTouchEvent(ev));的相关触摸事件的方法



```
  private void dispatchTouchEvent(MotionEvent ev) {
         try {
             if (mSysUiProxy != null) {
                 mLastAction = ev.getActionMasked();
                 mSysUiProxy.onStatusBarMotionEvent(ev);
             }
         } catch (RemoteException e) {
             Log.e(TAG, "Remote exception on sysUiProxy.", e);
         }
     }
 
     @Override
     public final boolean onControllerInterceptTouchEvent(MotionEvent ev) {
         int action = ev.getActionMasked();
         if (action == ACTION_DOWN) {
             mCanIntercept = canInterceptTouch(ev);
             if (!mCanIntercept) {
                 return false;
             }
             mTranslator.reset();
             mTranslator.setDownParameters(0, ev);
         } else if (ev.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
             // Check!! should only set it only when threshold is not entered.
             mTranslator.setDownParameters(ev.getActionIndex(), ev);
         }
         if (!mCanIntercept) {
             return false;
         }
         if (action == ACTION_MOVE) {
             float dy = ev.getY() - mTranslator.getDownY();
              float dx = ev.getX() - mTranslator.getDownX();
              if (dy > mTouchSlop && dy > Math.abs(dx)) {
                  mTranslator.dispatchDownEvents(ev);
                  mTranslator.processMotionEvent(ev);
                  return true;
              }
              if (Math.abs(dx) > mTouchSlop) {
                  mCanIntercept = false;
              }
          }
          return false;
      }
  
  
      @Override
      public final boolean onControllerTouchEvent(MotionEvent ev) {
          mTranslator.processMotionEvent(ev);
          return true;
      }
```

在StatusBarTouchController.java的上述方法中，通过dispatchTouchEvent(MotionEvent ev)来处理workspace的触摸事件，而  
 是在onControllerTouchEvent(MotionEvent ev)和onControllerInterceptTouchEvent(MotionEvent ev)中根据手势下拉来  
 判断下滑距离然后做出响应事件的相关处理功能，


## 3.2 DragLayer.java关于出来下拉状态栏事件的相关流程分析



```
   /**
      * Used to create a new DragLayer from XML.
      *
       * @param context The application's context.
       * @param attrs The attributes set containing the Workspace's customization values.
       */
      public DragLayer(Context context, AttributeSet attrs) {
          super(context, attrs, ALPHA_CHANNEL_COUNT);
  
          // Disable multitouch across the workspace/all apps/customize tray
          setMotionEventSplittingEnabled(false);
          setChildrenDrawingOrderEnabled(true);
  
          mFocusIndicatorHelper = new ViewGroupFocusHelper(this);
          mScrim = new WorkspaceAndHotseatScrim(this);
      }
  
      public void setup(DragController dragController, Workspace workspace) {
          mDragController = dragController;
          mScrim.setWorkspace(workspace);
          recreateControllers();
      }
  
      public void recreateControllers() {
          mControllers = UiFactory.createTouchControllers(mActivity);
      }
  
      public ViewGroupFocusHelper getFocusIndicatorHelper() {
          return mFocusIndicatorHelper;
      }
  
      @Override
      public boolean dispatchKeyEvent(KeyEvent event) {
          return mDragController.dispatchKeyEvent(event) || super.dispatchKeyEvent(event);
      }
  
      private boolean isEventOverAccessibleDropTargetBar(MotionEvent ev) {
          return isInAccessibleDrag() && isEventOverView(mActivity.getDropTargetBar(), ev);
      }
```

在DragLayer.java的上述的相关方法中，DragLayer(Context context, AttributeSet attrs)的构造方法中，实例化ViewGroupFocusHelper和  
  WorkspaceAndHotseatScrim的相关对象，而在setup(DragController dragController, Workspace workspace)设置相关全局参数  
 在recreateControllers()中设置触摸控制类，就是在UiFactory.createTouchControllers(mActivity);中的处理相关的Controller事件


## 3.3 UiFactory.java中关于出来下拉状态栏事件的相关流程分析



```
public class UiFactory {
  
      public static TouchController[] createTouchControllers(Launcher launcher) {
          return new TouchController[] {
                  launcher.getDragController(), new AllAppsSwipeController(launcher),new StatusBarTouchController(launcher)};
      }
```

从上述的UiFactory的相关源码发现，在createTouchControllers(Launcher launcher) 中构造了一系列的TouchControllers  
 的处理控制事件，而这里面就是StatusBarTouchController处理下拉触摸下滑事件的，所以需要具体修改为:



```
      public static TouchController[] createTouchControllers(Launcher launcher) {
          return new TouchController[] {
                  launcher.getDragController(), new AllAppsSwipeController(launcher)};
      }
```



