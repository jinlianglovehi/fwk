






### 1.概述


在系统产品开发中，有时候需要内置中文文件，中文系统属性等中文字符，但是在系统默认是不支持中文的，如果还有中文的话编译会报错，但是又没办法避免中文资源的话，就需要对系统编译支持的字符格式做修改，所以要兼容中文的修改，就要从编译的脚步出手来适应中文的编译格式


### 2.错误日志分析


先看编译的错误日志:



```
Traceback (most recent call last):
File "build/make/tools/fileslist\_util.py", line 68, in <module>
main(sys.argv)
File "build/make/tools/fileslist\_util.py", line 62, in main
PrintCanonicalList(args[0])
File "build/make/tools/fileslist\_util.py", line 30, in PrintCanonicalList
print "{0:12d} {1}".format(line["Size"], line["Name"])
UnicodeEncodeError: 'ascii' codec can't encode characters in position 47-50: ordinal not in range(128)

```

从日志中可以看出出错是在fileslist\_util.py中关于字符格式不支持中文而导致编译不通过，所以需要修改fileslist\_util.py这里面的  
 编译文字格式来达到支持中文的办法


### 3.代码分析


核心代码



```
build/make/tools/fileslist_util.py
build\make\core\Makefile

```

Makefile的相关引用代码分析：



```
ifdef BUILDING_RAMDISK_IMAGE
BUILT_DEBUG_RAMDISK_TARGET := $(PRODUCT\_OUT)/ramdisk-debug.img
INSTALLED_DEBUG_RAMDISK_TARGET := $(BUILT\_DEBUG\_RAMDISK\_TARGET)

INTERNAL_DEBUG_RAMDISK_FILES := $(filter $(TARGET\_DEBUG\_RAMDISK\_OUT)/%, \
 $(ALL\_GENERATED\_SOURCES) \
 $(ALL\_DEFAULT\_INSTALLED\_MODULES))

# Note: TARGET\_DEBUG\_RAMDISK\_OUT will be $(PRODUCT\_OUT)/debug\_ramdisk/first\_stage\_ramdisk,
# if BOARD\_USES\_RECOVERY\_AS\_BOOT is true. Otherwise, it will be $(PRODUCT\_OUT)/debug\_ramdisk.
# But the root dir of the ramdisk to build is always $(PRODUCT\_OUT)/debug\_ramdisk.
my_debug_ramdisk_root_dir := $(PRODUCT\_OUT)/debug_ramdisk

INSTALLED_FILES_FILE_DEBUG_RAMDISK := $(PRODUCT\_OUT)/installed-files-ramdisk-debug.txt
INSTALLED_FILES_JSON_DEBUG_RAMDISK := $(INSTALLED\_FILES\_FILE\_DEBUG\_RAMDISK:.txt=.json)
$(INSTALLED\_FILES\_FILE\_DEBUG\_RAMDISK): .KATI_IMPLICIT_OUTPUTS := $(INSTALLED\_FILES\_JSON\_DEBUG\_RAMDISK)
$(INSTALLED\_FILES\_FILE\_DEBUG\_RAMDISK): DEBUG_RAMDISK_ROOT_DIR := $(my\_debug\_ramdisk\_root\_dir)

# Cannot just depend on INTERNAL\_DEBUG\_RAMDISK\_FILES like other INSTALLED\_FILES\_FILE\_\* rules.
# Because ramdisk-debug.img will rsync from either ramdisk.img or ramdisk-recovery.img.
# Need to depend on the built ramdisk-debug.img, to get a complete list of the installed files.
$(INSTALLED\_FILES\_FILE\_DEBUG\_RAMDISK) : $(INSTALLED\_DEBUG\_RAMDISK\_TARGET)
$(INSTALLED\_FILES\_FILE\_DEBUG\_RAMDISK) : $(INTERNAL\_DEBUG\_RAMDISK\_FILES) $(FILESLIST)
	echo Installed file list: $@
	mkdir -p $(dir $@)
	rm -f $@
	$(FILESLIST) $(DEBUG\_RAMDISK\_ROOT\_DIR) > $(@:.txt=.json)
	build/make/tools/fileslist_util.py -c $(@:.txt=.json) > $@

# ramdisk-debug.img will rsync the content from either ramdisk.img or ramdisk-recovery.img,
# depending on whether BOARD\_USES\_RECOVERY\_AS\_BOOT is set or not.
ifeq ($(BOARD\_USES\_RECOVERY\_AS\_BOOT),true)
my_debug_ramdisk_sync_dir := $(TARGET\_RECOVERY\_ROOT\_OUT)
else
my_debug_ramdisk_sync_dir := $(TARGET\_RAMDISK\_OUT)
endif # BOARD\_USES\_RECOVERY\_AS\_BOOT

$(INSTALLED\_DEBUG\_RAMDISK\_TARGET): DEBUG_RAMDISK_SYNC_DIR := $(my\_debug\_ramdisk\_sync\_dir)
$(INSTALLED\_DEBUG\_RAMDISK\_TARGET): DEBUG_RAMDISK_ROOT_DIR := $(my\_debug\_ramdisk\_root\_dir)

ifeq ($(BOARD\_USES\_RECOVERY\_AS\_BOOT),true)
# ramdisk-recovery.img isn't a make target, need to depend on boot.img if it's for recovery.
$(INSTALLED\_DEBUG\_RAMDISK\_TARGET): $(INSTALLED\_BOOTIMAGE\_TARGET)
else
# Depends on ramdisk.img, note that some target has ramdisk.img but no boot.img, e.g., emulator.
$(INSTALLED\_DEBUG\_RAMDISK\_TARGET): $(INSTALLED\_RAMDISK\_TARGET)
endif # BOARD\_USES\_RECOVERY\_AS\_BOOT
$(INSTALLED\_DEBUG\_RAMDISK\_TARGET): $(MKBOOTFS) $(INTERNAL\_DEBUG\_RAMDISK\_FILES) | $(MINIGZIP)
	$(call pretty,"Target debug ram disk: $@")
	mkdir -p $(TARGET\_DEBUG\_RAMDISK\_OUT)
	touch $(TARGET\_DEBUG\_RAMDISK\_OUT)/force_debuggable
	rsync -a $(DEBUG\_RAMDISK\_SYNC\_DIR)/ $(DEBUG\_RAMDISK\_ROOT\_DIR)
	$(MKBOOTFS) -d $(TARGET\_OUT) $(DEBUG\_RAMDISK\_ROOT\_DIR) | $(MINIGZIP) > $@

.PHONY: ramdisk_debug-nodeps
ramdisk_debug-nodeps: DEBUG_RAMDISK_SYNC_DIR := $(my\_debug\_ramdisk\_sync\_dir)
ramdisk_debug-nodeps: DEBUG_RAMDISK_ROOT_DIR := $(my\_debug\_ramdisk\_root\_dir)
ramdisk_debug-nodeps: $(MKBOOTFS) | $(MINIGZIP)
	echo "make $@: ignoring dependencies"
	mkdir -p $(TARGET\_DEBUG\_RAMDISK\_OUT)
	touch $(TARGET\_DEBUG\_RAMDISK\_OUT)/force_debuggable
	rsync -a $(DEBUG\_RAMDISK\_SYNC\_DIR)/ $(DEBUG\_RAMDISK\_ROOT\_DIR)
	$(MKBOOTFS) -d $(TARGET\_OUT) $(DEBUG\_RAMDISK\_ROOT\_DIR) | $(MINIGZIP) > $(INSTALLED\_DEBUG\_RAMDISK\_TARGET)

my_debug_ramdisk_sync_dir :=
my_debug_ramdisk_root_dir :=

endif # BUILDING\_RAMDISK\_IMAGE

```

在2083行 引用build/make/tools/fileslist\_util.py参与编译在编译过程中默认不支持中文的编码格式  
 从错误日志看出是 编码格式的问题  
 所以要支持 编码格式为utf-8才行  
 先看下  
 build/make/tools/fileslist\_util.py



```
import getopt, json, sys
def PrintFileNames(path):
with open(path) as jf:
data = json.load(jf)
for line in data:
print(line["Name"])
def PrintCanonicalList(path):
with open(path) as jf:
data = json.load(jf)
for line in data:
print "{0:12d} {1}".format(line["Size"], line["Name"])
def PrintUsage(name):
print("""
Usage: %s -[nc] json_files_list
-n produces list of files only
-c produces classic installed-files.txt
""" % (name))
def main(argv):
try:
opts, args = getopt.getopt(argv[1:], "nc", "")
except getopt.GetoptError, err:
print(err)
PrintUsage(argv[0])
sys.exit(2)
if len(opts) == 0:
print("No conversion option specified")
PrintUsage(argv[0])
sys.exit(2)
if len(args) == 0:
print("No input file specified")
PrintUsage(argv[0])
sys.exit(2)
for o, a in opts:
if o == ("-n"):
PrintFileNames(args[0])
sys.exit()
elif o == ("-c"):
PrintCanonicalList(args[0])
sys.exit()
else:
assert False, "Unsupported option"
if name == 'main':
main(sys.argv)

```

从中可以看出没有指定默认的编码格式为utf-8 而添加默认的编码格式就需要增加下面这段代码



```
import sys
reload(sys)
sys.setdefaultencoding("utf8")

```

设置python默认字节流编/解码器按照utf8解码方式，把字节流编/解码为unicode  
 具体来说，所起到的作用，可以用下面两个错误来解释：



```
在将字节流使用str()方法转换为str对象时，会调用默认的encode函数，如果没有上述系统的默认编码设置，则自动使用'ascii' codecs进行编码，对于非ascii编码的数据，比如utf8字节流会产生错误解码提示：

```

UnicodeEncodeError: ‘ascii’ codec can’t encode characters in position 0-5: ordinal not in range(128)



```
    2.在utf8编码文件中写入汉字字符， 比如 s = '中文'时， 如果没有上述设置，运行程序会在初始s对象的值，报告错误解码提示：

```

UnicodeDecodeError: ‘ascii’ codec can’t decode byte 0xe4 in position 0: ordinal not in range(128)


### 4.解决方案


需要设置默认的编码格式修改如下:



```
import getopt, json, sys
+import sys
+reload(sys)
+sys.setdefaultencoding("utf8")
def PrintFileNames(path):
with open(path) as jf:
data = json.load(jf)
for line in data:
print(line["Name"])
def PrintCanonicalList(path):
with open(path) as jf:
data = json.load(jf)
for line in data:
print "{0:12d} {1}".format(line["Size"], line["Name"])
def PrintUsage(name):
print("""
Usage: %s -[nc] json_files_list
-n produces list of files only
-c produces classic installed-files.txt
""" % (name))
def main(argv):
try:
opts, args = getopt.getopt(argv[1:], "nc", "")
except getopt.GetoptError, err:
print(err)
PrintUsage(argv[0])
sys.exit(2)
if len(opts) == 0:
print("No conversion option specified")
PrintUsage(argv[0])
sys.exit(2)
if len(args) == 0:
print("No input file specified")
PrintUsage(argv[0])
sys.exit(2)
for o, a in opts:
if o == ("-n"):
PrintFileNames(args[0])
sys.exit()
elif o == ("-c"):
PrintCanonicalList(args[0])
sys.exit()
else:
assert False, "Unsupported option"
if name == 'main':
main(sys.argv)

```

这样编译就能支持中文了，验证后中文系统属性显示出来了





