



## 1.前言


  
   在android10.0的系统rom定制化开发中，在系统中开发产品时，会根据客户要求内置第三方app,这时如果内置app过多，或者安装的app过多，在系统开机的过程中  
 在pms扫描安装app的时候，就会比较耗时，这时候就需要优化下pms扫描安装app这块的功能代码，用多线程来实现pms扫描安装app，来加快开机时间，接下来  
 来实现这个功能


## 2.开机启动时PMS扫描apk耗时相关功能优化的核心类



```
frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java
```

## 3.开机启动时PMS扫描apk耗时相关功能优化的核心功能分析和实现


在Android系统开机启动的时候，在开机阶段耗时较多的部分有2个，分别是preload classes和scan packages。而preload classes是在zygote阶段处理的工作，本章节不讨论这个问题，这里主要讨论的是在PMS阶段，扫描app的时候，耗时操作的处理



```
     private void scanDirTracedLI(File scanDir, final int parseFlags, int scanFlags, long currentTime) {
               Trace.traceBegin(TRACE_TAG_PACKAGE_MANAGER, "scanDir [" + scanDir.getAbsolutePath() + "]");
               try {
                   scanDirLI(scanDir, parseFlags, scanFlags, currentTime);
               } finally {
                   Trace.traceEnd(TRACE_TAG_PACKAGE_MANAGER);
               }
           }
       
           private void scanDirLI(File scanDir, int parseFlags, int scanFlags, long currentTime) {
               final File[] files = scanDir.listFiles();
               if (ArrayUtils.isEmpty(files)) {
                   Log.d(TAG, "No files in app dir " + scanDir);
                   return;
               }
       
               if (DEBUG_PACKAGE_SCANNING) {
                   Log.d(TAG, "Scanning app dir " + scanDir + " scanFlags=" + scanFlags
                           + " flags=0x" + Integer.toHexString(parseFlags));
               }
               try (ParallelPackageParser parallelPackageParser = new ParallelPackageParser(
                       mSeparateProcesses, mOnlyCore, mMetrics, mCacheDir,
                       mParallelPackageParserCallback)) {
                   // Submit files for parsing in parallel
                   int fileCount = 0;
                   for (File file : files) {
                       final boolean isPackage = (isApkFile(file) || file.isDirectory())
                               && !PackageInstallerService.isStageName(file.getName());
                       if (!isPackage) {
                           // Ignore entries which are not packages
                           continue;
                       }
                       parallelPackageParser.submit(file, parseFlags);
                       fileCount++;
                   }
       
                   // Process results one by one
                   for (; fileCount > 0; fileCount--) {
                       ParallelPackageParser.ParseResult parseResult = parallelPackageParser.take();
                       Throwable throwable = parseResult.throwable;
                       int errorCode = PackageManager.INSTALL_SUCCEEDED;
       
                       if (throwable == null) {
                           // TODO(toddke): move lower in the scan chain
                           // Static shared libraries have synthetic package names
                           if (parseResult.pkg.applicationInfo.isStaticSharedLibrary()) {
                               renameStaticSharedLibraryPackage(parseResult.pkg);
                           }
                           try {
                               scanPackageChildLI(parseResult.pkg, parseFlags, scanFlags,
                                       currentTime, null);
                           } catch (PackageManagerException e) {
                               errorCode = e.error;
                               Slog.w(TAG, "Failed to scan " + parseResult.scanFile + ": " + e.getMessage());
                           }
                       } else if (throwable instanceof PackageParser.PackageParserException) {
                           PackageParser.PackageParserException e = (PackageParser.PackageParserException)
                                   throwable;
                           errorCode = e.error;
                           Slog.w(TAG, "Failed to parse " + parseResult.scanFile + ": " + e.getMessage());
                       } else {
                           throw new IllegalStateException("Unexpected exception occurred while parsing "
                                   + parseResult.scanFile, throwable);
                       }
       
                       // Delete invalid userdata apps
                       if ((scanFlags & SCAN_AS_SYSTEM) == 0 &&
                               errorCode != PackageManager.INSTALL_SUCCEEDED) {
                           logCriticalInfo(Log.WARN,
                                   "Deleting invalid package at " + parseResult.scanFile);
                           removeCodePathLI(parseResult.scanFile);
                       }
                   }
               }
           }
```

 在PackageManagerService.java的上述代码中，可以看出，在scanDirLI(File scanDir, int parseFlags, int scanFlags, long currentTime)  
 中主要负责扫描system vendor目录下的app，然后安装这些app,通过for (File file : files)遍历路径下的app 扫描安装app而ParallelPackageParser  
 就是一个队列负责我们这里手机所有系统的apk，然后从这些队列里面取出apk，再调用PackageParser解析器进行解析。  
 ParallelPackageParser.java submit(),把扫描路径中的APK等内容，放入队列mQueue，并把parsePackage()赋值给ParseResult，用于后面的调用,


## 3.2 创建多线程扫描app的工具类


  
 在frameworks/base/services/core/java/com/android/server/pm/创建工具类PackageManagerServiceExUtils  
 来实现多线程扫描app功能



```
/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.server.pm;

import static android.content.pm.PackageParser.isApkFile;
import static android.os.Trace.TRACE_TAG_PACKAGE_MANAGER;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.io.FileFilter;
import java.util.regex.Pattern;
import com.android.internal.util.ArrayUtils;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageParser;
import android.content.pm.ResolveInfo;
import android.os.Environment;
import android.os.FileUtils;
import android.os.Trace;
import android.util.Log;
import android.util.Slog;

/* SPRD : Add for bug742368, when WeiChatClone exists, if we login in an app using
 * WeiChat account ,both  WeiChat and WeiChatClone should appear.
import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.Process;
import android.os.UserHandle;
import android.content.pm.UserInfo;
import android.content.pm.AppCloneUserInfo; */
import static android.content.pm.PackageManager.MATCH_SYSTEM_ONLY;
import static android.content.pm.PackageManager.MATCH_DIRECT_BOOT_AWARE;
import static android.content.pm.PackageManager.MATCH_DIRECT_BOOT_UNAWARE;
import static android.content.pm.PackageManager.MATCH_DISABLED_COMPONENTS;

/**
 * Keep track of all those .apks everywhere.
 *
 * This is very central to the platform's security; please run the unit
 * tests whenever making modifications here:
 *
mmm frameworks/base/tests/AndroidTests
adb install -r -f out/target/product/passion/data/app/AndroidTests.apk
adb shell am instrument -w -e class com.android.unit_tests.PackageManagerTests com.android.unit_tests/android.test.InstrumentationTestRunner
 *
 * {@hide}
 */
public class PackageManagerServiceExUtils {
    static final String TAG = "PackageManagerServiceExUtils";
    public boolean debug = false;
    public boolean isOpen = false;
    public final File mPreloadInstallDir;
    public final File mPreloadProductDir;
    public final File mDeleteRecord;
    public static final int THREAD_NUMS = deriveCoreNum();
    public final PackageManagerService mService;
    private static final boolean DEBUG_PACKAGE_SCANNING = false;
    private boolean isAppCloneMode = false;

    public PackageManagerServiceExUtils(PackageManagerService service) {
       mService = service;
       mPreloadInstallDir = new File(Environment.getRootDirectory(), "preloadapp");
       mPreloadProductDir = new File(Environment.getProductDirectory(), "preloadapp");
       mDeleteRecord = new File(new File(Environment.getDataDirectory(),"app"), ".delrecord");
       deriveCoreNum();
    }

    /* SPRD: Add for boot performance with multi-thread and preload scan @{*/
    public boolean isDeleteApp(String packageName){
        BufferedReader br = null;
        try{
          br = new BufferedReader(new FileReader(mDeleteRecord));
          String lineContent = null;
          while( (lineContent = br.readLine()) != null){
              if(packageName.equals(lineContent)){
                   return true;
              }
          }
        }catch(IOException e){
           Log.e(TAG, " isDeleteApp IOException");
        }finally{
           try{
              if(br != null)
                br.close();
           }catch(IOException e){
               Log.e(TAG, " isDeleteApp Close ... IOException");
           }
        }
        return false;
    }

    public boolean delAppRecord(String packageName,int parseFlags){
      OutputStreamWriter writer = null;
      try{
         FileOutputStream fos = new FileOutputStream(mDeleteRecord, true);
         writer = new OutputStreamWriter(fos);
         writer.write(packageName +"\n");
         writer.flush();
         FileUtils.sync(fos);//Need to syncex plicitly
      }catch(IOException e){
           Log.e(TAG, "preloadapp unInstall record:  IOException");
      }finally{
           try{
            if(writer != null)
                writer.close();
           }catch(IOException e){}
      }
       return true;
    }

    public void parallelTakeAndScanPackageTracedLI(File dir, ParallelPackageParser parallelPackageParser, int fileCount,
                                                   int parseFlags, int scanFlags, long currentTime){
        Trace.traceBegin(TRACE_TAG_PACKAGE_MANAGER, "parallelTakeAndScanPackage");
        try {
            parallelTakeAndScanPackageLI(dir, parallelPackageParser, fileCount, parseFlags, scanFlags, currentTime);
        } finally {
            Trace.traceEnd(TRACE_TAG_PACKAGE_MANAGER);
        }
    }

    private void parallelTakeAndScanPackageLI(File dir, ParallelPackageParser parallelPackageParser, int fileCount, int parseFlags,
                                                    int scanFlags, long currentTime){
        Log.d(TAG, "parallelTakeAndScanPackageLI: "+ dir.getAbsolutePath() + " , fileCount = " + fileCount);

        CountDownLatch connectedSignal = new CountDownLatch(THREAD_NUMS);

        int partLength = 0;
        if(fileCount % THREAD_NUMS == 0){
            partLength = fileCount / THREAD_NUMS;
        }else {
            partLength = fileCount / THREAD_NUMS + 1;
        }

        for(int i = 0; i < THREAD_NUMS; i++){
            takeAndScanPackageInThread(connectedSignal, i, partLength, parallelPackageParser, fileCount, parseFlags, scanFlags, currentTime);
        }
        waitForLatch(connectedSignal);
    }

    private void takeAndScanPackageInThread(final CountDownLatch connectedSignal, final int threadId, final int countsByThread , final ParallelPackageParser parallelPackageParser,
                                            final int fileCount, final int parseFlags, final int scanFlags, final long currentTime){
        new Thread("Take-And-Scan-Thread-" + threadId){
            @Override
            public void run(){
                if(debug) Log.d(TAG, Thread.currentThread().getName() + " start!");
                for (int i = threadId * countsByThread; i < (threadId + 1) * countsByThread; i++) {
                    if (i >= fileCount)
                        break;
                    mService.takeAndScanPackageLI(parallelPackageParser, parseFlags, scanFlags, currentTime);
                }
                connectedSignal.countDown();
                if(debug) Log.d(TAG, Thread.currentThread().getName() + " end!");
            }
        }.start();
    }

    private  void waitForLatch(CountDownLatch latch) {
        for (;;) {
            try {
                if (latch.await(5000, TimeUnit.MILLISECONDS)) {
                    Slog.e(TAG, "waitForLatch done!" );
                    return;
                } else {
                    Slog.e(TAG, "Thread " + Thread.currentThread().getName()
                            + " still waiting for ready...");
                }
            } catch (InterruptedException e) {
                Slog.e(TAG, "Interrupt while waiting for scanning package to be ready.");
            }
        }
    }

    public static int deriveCoreNum(){
        int coreNum = 4;
        try {
            File dir = new File("/sys/devices/system/cpu/");
            File[] files = dir.listFiles(new CpuFilter());
            coreNum=files.length;
        } catch(Exception e) {
            e.printStackTrace();
        }
        if(coreNum >= 20 || coreNum <=0) {
            coreNum = 4;
        }
        Log.d(TAG, "CPU core number: "+coreNum);
        return coreNum;
    }
}

 class CpuFilter  implements FileFilter{
    public boolean accept(File pathname) {
        if(Pattern.matches("cpu[0-9]", pathname.getName())) {
            return true;
        }
        return false;
    }
}
```

在PackageManagerServiceExUtils.java中的上述方法中，在CpuFilter内部类，获取/sys/devices/system/cpu/目录下多少核，然后  
 来开启几个线程，通过parallelTakeAndScanPackageTracedLI(File dir, ParallelPackageParser parallelPackageParser, int fileCount,  
                                                    int parseFlags, int scanFlags, long currentTime)中来根据扫描多少个app,来使用多线程来  
 分段扫描app,最后通过mService.takeAndScanPackageLI(parallelPackageParser, parseFlags, scanFlags, currentTime);  
 来执行扫描解析app的功能


## 3.3 pms中具体修改扫描方法如下:



```
   private void scanDirLI(File scanDir, int parseFlags, int scanFlags, long currentTime) {
        final File[] files = scanDir.listFiles();
        if (ArrayUtils.isEmpty(files)) {
            Log.d(TAG, "No files in app dir " + scanDir);
            return;
        }

        if (DEBUG_PACKAGE_SCANNING) {
            Log.d(TAG, "Scanning app dir " + scanDir + " scanFlags=" + scanFlags
                    + " flags=0x" + Integer.toHexString(parseFlags));
        }
        try (ParallelPackageParser parallelPackageParser = new ParallelPackageParser(
                mSeparateProcesses, mOnlyCore, mMetrics, mCacheDir,
                mParallelPackageParserCallback)) {
            // Submit files for parsing in parallel
            int fileCount = 0;
            for (File file : files) {
                final boolean isPackage = (isApkFile(file) || file.isDirectory())
                        && !PackageInstallerService.isStageName(file.getName());
                if (!isPackage) {
                    // Ignore entries which are not packages
                    continue;
                }
                parallelPackageParser.submit(file, parseFlags);
                fileCount++;
            }

//add core start
            // SPRD: Process results parallel {@
            mPackageManagerServiceExUtils.parallelTakeAndScanPackageTracedLI(scanDir, parallelPackageParser, fileCount, parseFlags, scanFlags, currentTime);
            // @}
            parallelPackageParser.close();
//add core end
        }
    }


// add core start
    protected void takeAndScanPackageLI(ParallelPackageParser parallelPackageParser, int parseFlags, int scanFlags, long currentTime){
                // Process results one by one
                ParallelPackageParser.ParseResult parseResult = parallelPackageParser.take();
                Throwable throwable = parseResult.throwable;
                int errorCode = PackageManager.INSTALL_SUCCEEDED;
                if (DEBUG_INSTALL) Slog.d(TAG, "SPRD : takeAndScanPackageLI: " + parseResult.scanFile);
                if (throwable == null) {
                    // TODO(toddke): move lower in the scan chain
                    // Static shared libraries have synthetic package names
                    if (parseResult.pkg.applicationInfo.isStaticSharedLibrary()) {
                        renameStaticSharedLibraryPackage(parseResult.pkg);
                    }
                    try {
                        scanPackageChildLI(parseResult.pkg, parseFlags, scanFlags,
                                currentTime, null);
                    } catch (PackageManagerException e) {
                        errorCode = e.error;
                        Slog.w(TAG, "Failed to scan " + parseResult.scanFile + ": " + e.getMessage());
                    }
                } else if (throwable instanceof PackageParser.PackageParserException) {
                    PackageParser.PackageParserException e = (PackageParser.PackageParserException)
                            throwable;
                    errorCode = e.error;
                    Slog.w(TAG, "Failed to parse " + parseResult.scanFile + ": " + e.getMessage());
                } else {
                    throw new IllegalStateException("Unexpected exception occurred while parsing "
                            + parseResult.scanFile, throwable);
                }

                // Delete invalid userdata apps
                if ((scanFlags & SCAN_AS_SYSTEM) == 0 &&
                        errorCode != PackageManager.INSTALL_SUCCEEDED) {
                    logCriticalInfo(Log.WARN,
                            "Deleting invalid package at " + parseResult.scanFile);
                    removeCodePathLI(parseResult.scanFile);
                }
    }
//add core end
```

在PackageManagerService.java的上述方法中，在 scanDirLI(File scanDir, int parseFlags, int scanFlags, long currentTime) 中这个负责扫描系统内置安装的  
 app的方法中，在把scanPackageChildLI(parseResult.pkg, parseFlags, scanFlags, currentTime, null);这个具体扫描目录子目录下的app的功能，放在  
 多线程中去扫描，调用mPackageManagerServiceExUtils.parallelTakeAndScanPackageTracedLI(scanDir, parallelPackageParser, fileCount, parseFlags, scanFlags, currentTime);  
 来执行，然后增加takeAndScanPackageLI(ParallelPackageParser parallelPackageParser, int parseFlags, int scanFlags, long currentTime)通过在多线程中  
 调用执行扫描子目录下的app，来达到使用多线程来扫描app的功能



