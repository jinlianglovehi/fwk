






### 1.概述


在10.0的系统产品开发中，在进行平板定制化开发中，由于摄像头方向默认是竖屏的，但是平板电脑一般都是要横屏拍摄的  
 所以产品就需要旋转摄像头方向，方便横屏预览画面，旋转摄像头方向可以在驱动层，hal层 framework层，主要就是在Camera中旋转就可以了


### 2.framework层 Camera旋转摄像头方向的核心类



```
frameworks/base/core/java/android/hardware/Camera.java

```

### 3.framework层 Camera旋转摄像头方向的核心功能实现和分析


对于Camera的属性配置和相关方向的旋转可以在framework层也可以在hal层  
 今天来看下在framework层怎么修改  
 Camera.java 位于  
 frameworks/base/core/java/android/hardware/Camera.java


接下来看Camera.java的源码



```
public class Camera {
    private static final String TAG = "Camera";
    /**
     * Camera HAL device API version 1.0
     * @hide
     */
    @UnsupportedAppUsage
    public static final int CAMERA_HAL_API_VERSION_1_0 = 0x100;

    /**
     * A constant meaning the normal camera connect/open will be used.
     */
    private static final int CAMERA_HAL_API_VERSION_NORMAL_CONNECT = -2;

    /**
     * Used to indicate HAL version un-specified.
     */
    private static final int CAMERA_HAL_API_VERSION_UNSPECIFIED = -1;

    /**
     * Hardware face detection. It does not use much CPU.
     */
    private static final int CAMERA_FACE_DETECTION_HW = 0;

    /**
     * Software face detection. It uses some CPU.
     */
    private static final int CAMERA_FACE_DETECTION_SW = 1;

    /**
     * Returns the number of physical cameras available on this device.
     * The return value of this method might change dynamically if the device
     * supports external cameras and an external camera is connected or
     * disconnected.
     *
     * If there is a
     * {@link android.hardware.camera2.CameraCharacteristics#REQUEST\_AVAILABLE\_CAPABILITIES\_LOGICAL\_MULTI\_CAMERA
     * logical multi-camera} in the system, to maintain app backward compatibility, this method will
     * only expose one camera per facing for all logical camera and physical camera groups.
     * Use camera2 API to see all cameras.
     *
     * @return total number of accessible camera devices, or 0 if there are no
     *   cameras or an error was encountered enumerating them.
     */
    public native static int getNumberOfCameras();

    /**
     * Returns the information about a particular camera.
     * If {@link #getNumberOfCameras()} returns N, the valid id is 0 to N-1.
     *
     * @throws RuntimeException if an invalid ID is provided, or if there is an
     *    error retrieving the information (generally due to a hardware or other
     *    low-level failure).
     */
    public static void getCameraInfo(int cameraId, CameraInfo cameraInfo) {
        // SPRD: decouple code, change private to protected
        checkCameraId(cameraId);

        _getCameraInfo(cameraId, cameraInfo);
        IBinder b = ServiceManager.getService(Context.AUDIO_SERVICE);
        IAudioService audioService = IAudioService.Stub.asInterface(b);
        try {
            if (audioService == null){
                Log.w(TAG,"Unable to find IAudioService interface.");
            }else if (audioService.isCameraSoundForced()){
                // Only set this when sound is forced; otherwise let native code
                // decide.
                cameraInfo.canDisableShutterSound = false;
            }
        } catch (RemoteException e) {
            Log.e(TAG, "Audio service is unavailable for queries");
        }
    }
    private native static void _getCameraInfo(int cameraId, CameraInfo cameraInfo);

    /**
     * SPRD: Check camera id, if the id is greater than the return value of {@link android.hardware.Camera#getNumberOfCameras},
     * this will throw a RuntimeException.
     *
     * @param cameraId camera id.
     *
     */
    private static void checkCameraId(int cameraId) {
        if (cameraId >= getNumberOfCameras()) {
            throw new RuntimeException("Unknown camera ID");
        }
    }

public static Camera open(int cameraId) {
        return new Camera(cameraId);
    }

    /**
     * Creates a new Camera object to access the first back-facing camera on the
     * device. If the device does not have a back-facing camera, this returns
     * null. Otherwise acts like the {@link #open(int)} call.
     *
     * @return a new Camera object for the first back-facing camera, or null if there is no
     *  backfacing camera
     * @see #open(int)
     */
    public static Camera open() {
        int numberOfCameras = getNumberOfCameras();
        CameraInfo cameraInfo = new CameraInfo();
        for (int i = 0; i < numberOfCameras; i++) {
            getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == CameraInfo.CAMERA_FACING_BACK) {
                return new Camera(i);
            }
        }
        return null;
    }
    /**
     * Create a legacy camera object.
     *
     * @param cameraId The hardware camera to access, between 0 and
     * {@link #getNumberOfCameras()}-1.
     * @param halVersion The HAL API version this camera device to be opened as.
     */
    private Camera(int cameraId, int halVersion) {
        int err = cameraInitVersion(cameraId, halVersion);
        if (checkInitErrors(err)) {
            if (err == -EACCES) {
                throw new RuntimeException("Fail to connect to camera service");
            } else if (err == -ENODEV) {
                throw new RuntimeException("Camera initialization failed");
            } else if (err == -ENOSYS) {
                throw new RuntimeException("Camera initialization failed because some methods"
                        + " are not implemented");
            } else if (err == -EOPNOTSUPP) {
                throw new RuntimeException("Camera initialization failed because the hal"
                        + " version is not supported by this device");
            } else if (err == -EINVAL) {
                throw new RuntimeException("Camera initialization failed because the input"
                        + " arugments are invalid");
            } else if (err == -EBUSY) {
                throw new RuntimeException("Camera initialization failed because the camera"
                        + " device was already opened");
            } else if (err == -EUSERS) {
                throw new RuntimeException("Camera initialization failed because the max"
                        + " number of camera devices were already opened");
            }
            // Should never hit this.
            throw new RuntimeException("Unknown camera error");
        }
    }


```

在Camera中调用打开摄像头时，每次在调用open的时候 打开摄像头  
 通过查看Camera 的Parameters的setRotation()可以旋转摄像头方向，就是在camera中的  
 open方法中设置旋转方向就可以了  
 所以可以在构造Camera时，设置好旋转方向  
 添加旋转方向如下:



```
 private static Camera rotateCameraDirection(int cameraId) {
        Camera roratecamera = new Camera(cameraId);
        Parameters parameters = roratecamera.getParameters();
        CameraInfo camerainfo = new CameraInfo();
        getCameraInfo(cameraId, camerainfo);
        if (camerainfo.facing == CameraInfo.CAMERA_FACING_BACK) {
            roratecamera.setDisplayOrientation(270);
            parameters.setRotation(270); 
        } else if (cameraInfo.facing == CameraInfo.CAMERA_FACING_FRONT) {
            roratecamera.setDisplayOrientation(90);
            parameters.setRotation(90); 
        }
        roratecamera.setParameters(parameters);
        return camera;
    }

```

旋转方向修改如下:



```
 public static Camera open(int cameraId) {
       - return new Camera(cameraId);
       + return rotateCameraDirection(cameraId);
    }

```

在open(int cameraId)调用rotateCameraDirection(cameraId)设置旋转方向



```
public static Camera open() {
    int numberOfCameras = getNumberOfCameras();
    CameraInfo cameraInfo = new CameraInfo();
    for (int i = 0; i < numberOfCameras; i++) {
        getCameraInfo(i, cameraInfo);
        if (cameraInfo.facing == CameraInfo.CAMERA_FACING_BACK) {
           - return new Camera(i);
           + return rotateCameraDirection(i);
        }
    }
    return null;
}

```

在open()调用rotateCameraDirection(cameraId)设置旋转方向





