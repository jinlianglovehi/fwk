



## 1.概述


在10.0定制化开发中，会遇到一些SystemUI的下拉快捷的定制，需要去掉一些快捷开关，所以针对一些不需要的快捷图标 要进行隐藏，首选隐藏需要知道快捷图标是怎么构造的 然后在不去构造就可以了所有的快捷图标都是通过QSFactoryImpl来构造的


## 2.SystemUI下拉状态栏隐藏下拉快捷开关的相关代码



```
相关核心代码:
  /framework/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
  /framework/base/packages/SystemUI/res/config.xml
  /frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
  /frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSFragment.java
  /frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java

```

## 3.SystemUI下拉状态栏隐藏下拉快捷开关的相关代码分析


####   3.1 StatusBar.java 关于加载状态栏的相关方法



```
 protected void makeStatusBarView(@Nullable RegisterStatusBarResult result) {
final Context context = mContext;
updateDisplaySize(); // populates mDisplayMetrics
updateResources();
updateTheme();

inflateStatusBarWindow(context);
mStatusBarWindow.setService(this);
mStatusBarWindow.setOnTouchListener(getStatusBarWindowTouchListener());

// TODO: Deal with the ugliness that comes from having some of the statusbar broken out
// into fragments, but the rest here, it leaves some awkward lifecycle and whatnot.
mNotificationPanel = mStatusBarWindow.findViewById(R.id.notification_panel);
mStackScroller = mStatusBarWindow.findViewById(R.id.notification_stack_scroller);
mZenController.addCallback(this);
NotificationListContainer notifListContainer = (NotificationListContainer) mStackScroller;
mNotificationLogger.setUpWithContainer(notifListContainer);

mNotificationIconAreaController = SystemUIFactory.getInstance()
createNotificationIconAreaController(context, this, mStatusBarStateController);
inflateShelf();
mNotificationIconAreaController.setupShelf(mNotificationShelf);

Dependency.get(DarkIconDispatcher.class).addDarkReceiver(mNotificationIconAreaController);
// Allow plugins to reference DarkIconDispatcher and StatusBarStateController
Dependency.get(PluginDependencyProvider.class)
allowPluginDependency(DarkIconDispatcher.class);
Dependency.get(PluginDependencyProvider.class)
allowPluginDependency(StatusBarStateController.class);
FragmentHostManager.get(mStatusBarWindow)
addTagListener(CollapsedStatusBarFragment.TAG, (tag, fragment) -> {
CollapsedStatusBarFragment statusBarFragment =
(CollapsedStatusBarFragment) fragment;
statusBarFragment.initNotificationIconArea(mNotificationIconAreaController);
PhoneStatusBarView oldStatusBarView = mStatusBarView;
mStatusBarView = (PhoneStatusBarView) fragment.getView();
mStatusBarView.setBar(this);
mStatusBarView.setPanel(mNotificationPanel);
mStatusBarView.setScrimController(mScrimController);

// CollapsedStatusBarFragment re-inflated PhoneStatusBarView and both of
// mStatusBarView.mExpanded and mStatusBarView.mBouncerShowing are false.
// PhoneStatusBarView's new instance will set to be gone in
// PanelBar.updateVisibility after calling mStatusBarView.setBouncerShowing
// that will trigger PanelBar.updateVisibility. If there is a heads up showing,
// it needs to notify PhoneStatusBarView's new instance to update the correct
// status by calling mNotificationPanel.notifyBarPanelExpansionChanged().
if (mHeadsUpManager.hasPinnedHeadsUp()) {
mNotificationPanel.notifyBarPanelExpansionChanged();
}
mStatusBarView.setBouncerShowing(mBouncerShowing);
if (oldStatusBarView != null) {
float fraction = oldStatusBarView.getExpansionFraction();
boolean expanded = oldStatusBarView.isExpanded();
mStatusBarView.panelExpansionChanged(fraction, expanded);
}

HeadsUpAppearanceController oldController = mHeadsUpAppearanceController;
if (mHeadsUpAppearanceController != null) {
// This view is being recreated, let's destroy the old one
mHeadsUpAppearanceController.destroy();
}
mHeadsUpAppearanceController = new HeadsUpAppearanceController(
mNotificationIconAreaController, mHeadsUpManager, mStatusBarWindow);
mHeadsUpAppearanceController.readFrom(oldController);
mStatusBarWindow.setStatusBarView(mStatusBarView);
updateAreThereNotifications();
checkBarModes();
}).getFragmentManager()
beginTransaction()
replace(R.id.status_bar_container, new CollapsedStatusBarFragment(),
CollapsedStatusBarFragment.TAG)
commit();
mIconController = Dependency.get(StatusBarIconController.class);

mHeadsUpManager = new HeadsUpManagerPhone(context, mStatusBarWindow, mGroupManager, this,
mVisualStabilityManager);
Dependency.get(ConfigurationController.class).addCallback(mHeadsUpManager);
mHeadsUpManager.addListener(this);
mHeadsUpManager.addListener(mNotificationPanel);
mHeadsUpManager.addListener(mGroupManager);
mHeadsUpManager.addListener(mGroupAlertTransferHelper);
mHeadsUpManager.addListener(mVisualStabilityManager);
mAmbientPulseManager.addListener(this);
mAmbientPulseManager.addListener(mGroupManager);
mAmbientPulseManager.addListener(mGroupAlertTransferHelper);
mNotificationPanel.setHeadsUpManager(mHeadsUpManager);
mGroupManager.setHeadsUpManager(mHeadsUpManager);
mGroupAlertTransferHelper.setHeadsUpManager(mHeadsUpManager);
mNotificationLogger.setHeadsUpManager(mHeadsUpManager);
putComponent(HeadsUpManager.class, mHeadsUpManager);

createNavigationBar(result);

if (ENABLE_LOCKSCREEN_WALLPAPER) {
mLockscreenWallpaper = new LockscreenWallpaper(mContext, this, mHandler);
}

mKeyguardIndicationController =
SystemUIFactory.getInstance().createKeyguardIndicationController(mContext,
mStatusBarWindow.findViewById(R.id.keyguard_indication_area),
mStatusBarWindow.findViewById(R.id.lock_icon));
mNotificationPanel.setKeyguardIndicationController(mKeyguardIndicationController);

mAmbientIndicationContainer = mStatusBarWindow.findViewById(
R.id.ambient_indication_container);

// TODO: Find better place for this callback.
mBatteryController.addCallback(new BatteryStateChangeCallback() {
@Override
public void onPowerSaveChanged(boolean isPowerSave) {
mHandler.post(mCheckBarModes);
if (mDozeServiceHost != null) {
mDozeServiceHost.firePowerSaveChanged(isPowerSave);
}
}

@Override
public void onBatteryLevelChanged(int level, boolean pluggedIn, boolean charging) {
// noop
}
});

mAutoHideController = Dependency.get(AutoHideController.class);
mAutoHideController.setStatusBar(this);

mLightBarController = Dependency.get(LightBarController.class);

ScrimView scrimBehind = mStatusBarWindow.findViewById(R.id.scrim_behind);
ScrimView scrimInFront = mStatusBarWindow.findViewById(R.id.scrim_in_front);
mScrimController = SystemUIFactory.getInstance().createScrimController(
scrimBehind, scrimInFront, mLockscreenWallpaper,
(state, alpha, color) -> mLightBarController.setScrimState(state, alpha, color),
scrimsVisible -> {
if (mStatusBarWindowController != null) {
mStatusBarWindowController.setScrimsVisibility(scrimsVisible);
}
if (mStatusBarWindow != null) {
mStatusBarWindow.onScrimVisibilityChanged(scrimsVisible);
}
}, DozeParameters.getInstance(mContext),
mContext.getSystemService(AlarmManager.class));
mNotificationPanel.initDependencies(this, mGroupManager, mNotificationShelf,
mHeadsUpManager, mNotificationIconAreaController, mScrimController);
mDozeScrimController = new DozeScrimController(DozeParameters.getInstance(context));

BackDropView backdrop = mStatusBarWindow.findViewById(R.id.backdrop);
mMediaManager.setup(backdrop, backdrop.findViewById(R.id.backdrop_front),
backdrop.findViewById(R.id.backdrop_back), mScrimController, mLockscreenWallpaper);

// Other icons
mVolumeComponent = getComponent(VolumeComponent.class);

mNotificationPanel.setUserSetupComplete(mUserSetup);
if (UserManager.get(mContext).isUserSwitcherEnabled()) {
createUserSwitcher();
}

mNotificationPanel.setLaunchAffordanceListener(
mStatusBarWindow::onShowingLaunchAffordanceChanged);

// Set up the quick settings tile panel
View container = mStatusBarWindow.findViewById(R.id.qs_frame);
if (container != null) {
FragmentHostManager fragmentHostManager = FragmentHostManager.get(container);
ExtensionFragmentListener.attachExtensonToFragment(container, QS.TAG, R.id.qs_frame,
Dependency.get(ExtensionController.class)
newExtension(QS.class)
withPlugin(QS.class)
withDefault(this::createDefaultQSFragment)
build());
mBrightnessMirrorController = new BrightnessMirrorController(mStatusBarWindow,
(visible) -> {
mBrightnessMirrorVisible = visible;
updateScrimController();
});
fragmentHostManager.addTagListener(QS.TAG, (tag, f) -> {
QS qs = (QS) f;
if (qs instanceof QSFragment) {
mQSPanel = ((QSFragment) qs).getQsPanel();
mQSPanel.setBrightnessMirror(mBrightnessMirrorController);
}
});
}

mReportRejectedTouch = mStatusBarWindow.findViewById(R.id.report_rejected_touch);
if (mReportRejectedTouch != null) {
updateReportRejectedTouchVisibility();
mReportRejectedTouch.setOnClickListener(v -> {
Uri session = mFalsingManager.reportRejectedTouch();
if (session == null) { return; }

StringWriter message = new StringWriter();
message.write("Build info: ");
message.write(SystemProperties.get("ro.build.description"));
message.write("\nSerial number: ");
message.write(SystemProperties.get("ro.serialno"));
message.write("\n");

PrintWriter falsingPw = new PrintWriter(message);
FalsingLog.dump(falsingPw);
falsingPw.flush();

startActivityDismissingKeyguard(Intent.createChooser(new Intent(Intent.ACTION_SEND)
setType("*/*")
putExtra(Intent.EXTRA_SUBJECT, "Rejected touch report")
putExtra(Intent.EXTRA_STREAM, session)
putExtra(Intent.EXTRA_TEXT, message.toString()),
"Share rejected touch report")
addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
true /* onlyProvisioned */, true /* dismissShade */);
});
}

PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
if (!pm.isScreenOn()) {
mBroadcastReceiver.onReceive(mContext, new Intent(Intent.ACTION_SCREEN_OFF));
}
mGestureWakeLock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK,
"GestureWakeLock");
mVibrator = mContext.getSystemService(Vibrator.class);
int[] pattern = mContext.getResources().getIntArray(
R.array.config_cameraLaunchGestureVibePattern);
mCameraLaunchGestureVibePattern = new long[pattern.length];
for (int i = 0; i < pattern.length; i++) {
mCameraLaunchGestureVibePattern[i] = pattern[i];
}

// receive broadcasts
IntentFilter filter = new IntentFilter();
filter.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
filter.addAction(Intent.ACTION_SCREEN_OFF);
filter.addAction(DevicePolicyManager.ACTION_SHOW_DEVICE_MONITORING_DIALOG);
context.registerReceiverAsUser(mBroadcastReceiver, UserHandle.ALL, filter, null, null);

IntentFilter demoFilter = new IntentFilter();
if (DEBUG_MEDIA_FAKE_ARTWORK) {
demoFilter.addAction(ACTION_FAKE_ARTWORK);
}
demoFilter.addAction(ACTION_DEMO);
context.registerReceiverAsUser(mDemoReceiver, UserHandle.ALL, demoFilter,
android.Manifest.permission.DUMP, null);

// listen for USER_SETUP_COMPLETE setting (per-user)
mDeviceProvisionedController.addCallback(mUserSetupObserver);
mUserSetupObserver.onUserSetupChanged();

// disable profiling bars, since they overlap and clutter the output on app windows
ThreadedRenderer.overrideProperty("disableProfileBars", "true");

// Private API call to make the shadows look better for Recents
ThreadedRenderer.overrideProperty("ambientRatio", String.valueOf(1.5f));
}


```

#### QSPanel 创建是通过QSFragment 构建的 接下来看QSFragment的相关代码


#### 3.2 QSFragment关于状态栏构建QSPanel的相关代码



```
private final QSTileHost mHost;

@Inject
public QSFragment(RemoteInputQuickSettingsDisabler remoteInputQsDisabler,
InjectionInflationController injectionInflater,
Context context,
QSTileHost qsTileHost) {
mRemoteInputQuickSettingsDisabler = remoteInputQsDisabler;
mInjectionInflater = injectionInflater;
SysUiServiceProvider.getComponent(context, CommandQueue.class)
observe(getLifecycle(), this);
mHost = qsTileHost;
}

@Override
public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
Bundle savedInstanceState) {
inflater = mInjectionInflater.injectable(
inflater.cloneInContext(new ContextThemeWrapper(getContext(), R.style.qs_theme)));
return inflater.inflate(R.layout.qs_panel, container, false);
}

@Override
public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
super.onViewCreated(view, savedInstanceState);
mQSPanel = view.findViewById(R.id.quick_settings_panel);
mQSDetail = view.findViewById(R.id.qs_detail);
mHeader = view.findViewById(R.id.header);
mFooter = view.findViewById(R.id.qs_footer);
mContainer = view.findViewById(id.quick_settings_container);

mQSDetail.setQsPanel(mQSPanel, mHeader, (View) mFooter);
mQSAnimator = new QSAnimator(this,
mHeader.findViewById(R.id.quick_qs_panel), mQSPanel);

mQSCustomizer = view.findViewById(R.id.qs_customize);
mQSCustomizer.setQs(this);
if (savedInstanceState != null) {
setExpanded(savedInstanceState.getBoolean(EXTRA_EXPANDED));
setListening(savedInstanceState.getBoolean(EXTRA_LISTENING));
setEditLocation(view);
mQSCustomizer.restoreInstanceState(savedInstanceState);
if (mQsExpanded) {
mQSPanel.getTileLayout().restoreInstanceState(savedInstanceState);
}
}
setHost(mHost);
}


```

#### QSTileHost负责下拉快捷图标的构建.通过QSPanel加载显示处理 在QSTileHost的构造函数里，我们主要看tunerService.addTunable(this, TILES\_SETTING);很明显，调用tunerService里的 addTunabe() 方法，跟进去会发现，最终的是调用的 TunerServiceImpl 里面的addTunabe() 而在onTuningChanged(String key, String newValue) 通过loadTileSpecs(mContext, newValue)来加载默认快捷开关


#### 3.3 QSTileHost关于下拉快捷的相关代码



```
@Inject
public QSTileHost(Context context,
StatusBarIconController iconController,
QSFactoryImpl defaultFactory,
@Named(Dependency.MAIN_HANDLER_NAME) Handler mainHandler,
@Named(Dependency.BG_LOOPER_NAME) Looper bgLooper,
PluginManager pluginManager,
TunerService tunerService,
Provider<AutoTileManager> autoTiles,
DumpController dumpController) {
mIconController = iconController;
mContext = context;
mTunerService = tunerService;
mPluginManager = pluginManager;
mDumpController = dumpController;

mServices = new TileServices(this, bgLooper);

defaultFactory.setHost(this);
mQsFactories.add(defaultFactory);
pluginManager.addPluginListener(this, QSFactory.class, true);
mDumpController.addListener(this);

mainHandler.post(() -> {
// This is technically a hack to avoid circular dependency of
// QSTileHost -> XXXTile -> QSTileHost. Posting ensures creation
// finishes before creating any tiles.
tunerService.addTunable(this, TILES_SETTING);
// AutoTileManager can modify mTiles so make sure mTiles has already been initialized.
mAutoTiles = autoTiles.get();
});
}

@Override
public void onTuningChanged(String key, String newValue) {
if (!TILES_SETTING.equals(key)) {
return;
}
if (DEBUG) Log.d(TAG, "Recreating tiles");
if (newValue == null && UserManager.isDeviceInDemoMode(mContext)) {
newValue = mContext.getResources().getString(R.string.quick_settings_tiles_retail_mode);
}
final List<String> tileSpecs = loadTileSpecs(mContext, newValue);
int currentUser = ActivityManager.getCurrentUser();
if (tileSpecs.equals(mTileSpecs) && currentUser == mCurrentUser) return;
mTiles.entrySet().stream().filter(tile -> !tileSpecs.contains(tile.getKey())).forEach(
tile -> {
if (DEBUG) Log.d(TAG, "Destroying tile: " + tile.getKey());
tile.getValue().destroy();
});
final LinkedHashMap<String, QSTile> newTiles = new LinkedHashMap<>();
for (String tileSpec : tileSpecs) {
QSTile tile = mTiles.get(tileSpec);
if (tile != null && (!(tile instanceof CustomTile)
|| ((CustomTile) tile).getUser() == currentUser)) {
if (tile.isAvailable()) {
if (DEBUG) Log.d(TAG, "Adding " + tile);
tile.removeCallbacks();
if (!(tile instanceof CustomTile) && mCurrentUser != currentUser) {
tile.userSwitch(currentUser);
}
newTiles.put(tileSpec, tile);
} else {
tile.destroy();
}
} else {
if (DEBUG) Log.d(TAG, "Creating tile: " + tileSpec);
try {
tile = createTile(tileSpec);
if (tile != null) {
if (tile.isAvailable()) {
tile.setTileSpec(tileSpec);
newTiles.put(tileSpec, tile);
} else {
tile.destroy();
}
}
} catch (Throwable t) {
Log.w(TAG, "Error creating tile for spec: " + tileSpec, t);
}
}
}
mCurrentUser = currentUser;
List<String> currentSpecs = new ArrayList(mTileSpecs);
mTileSpecs.clear();
mTileSpecs.addAll(tileSpecs);
mTiles.clear();
mTiles.putAll(newTiles);
if (newTiles.isEmpty() && !tileSpecs.isEmpty()) {
// If we didn't manage to create any tiles, set it to empty (default)
if (DEBUG) Log.d(TAG, "No valid tiles on tuning changed. Setting to default.");
changeTiles(currentSpecs, loadTileSpecs(mContext, ""));
} else {
for (int i = 0; i < mCallbacks.size(); i++) {
mCallbacks.get(i).onTilesChanged();
}
}
}

@Override
public void removeTile(String spec) {
changeTileSpecs(tileSpecs-> tileSpecs.remove(spec));
}

protected static List<String> loadTileSpecs(Context context, String tileList) {
final Resources res = context.getResources();
final String defaultTileList = res.getString(R.string.quick_settings_tiles_default);
if (TextUtils.isEmpty(tileList)) {
tileList = res.getString(R.string.quick_settings_tiles);
if (DEBUG) Log.d(TAG, "Loaded tile specs from config: " + tileList);
} else {
if (DEBUG) Log.d(TAG, "Loaded tile specs from setting: " + tileList);
}
final ArrayList<String> tiles = new ArrayList<String>();
boolean addedDefault = false;
for (String tile : tileList.split(",")) {
tile = tile.trim();
if (tile.isEmpty()) continue;
if (tile.equals("default")) {
if (!addedDefault) {
tiles.addAll(Arrays.asList(defaultTileList.split(",")));
if (Build.IS_DEBUGGABLE
&& GarbageMonitor.MemoryTile.ADD_TO_DEFAULT_ON_DEBUGGABLE_BUILDS) {
tiles.add(GarbageMonitor.MemoryTile.TILE_SPEC);
}
addedDefault = true;
}
} else {
tiles.add(tile);
}
}
return tiles;
}

```

#### 加载完默认的快捷列表后最终通过QSFactoryImpl.java 构建快捷图标显示处理


#### 3.4 QSFactoryImpl.java关于构建快捷图标的相关代码



```
路径:/framework/base/packages/SystemUI/src/com/android/systemui/qs/tileimpl/QSFactoryImpl.java
public class QSFactoryImpl implements QSFactory {

    private static final String TAG = "QSFactory";
    private static final String RADIO_MODEM_CAPABILITY = "persist.vendor.radio.modem.config";
    private static final String LTE_INDICATOR = "L";

    private final Provider<WifiTile> mWifiTileProvider;
    private final Provider<BluetoothTile> mBluetoothTileProvider;
    private final Provider<CellularTile> mCellularTileProvider;
    private final Provider<DndTile> mDndTileProvider;
    private final Provider<ColorInversionTile> mColorInversionTileProvider;
    private final Provider<AirplaneModeTile> mAirplaneModeTileProvider;
    private final Provider<WorkModeTile> mWorkModeTileProvider;
    private final Provider<RotationLockTile> mRotationLockTileProvider;
    private final Provider<FlashlightTile> mFlashlightTileProvider;
    private final Provider<LongScreenshotTile> mLongScreenshotTileProvider;
    private final Provider<OneHandTile> mOneHandTileProvider;
    private final Provider<LocationTile> mLocationTileProvider;
    private final Provider<CastTile> mCastTileProvider;
    private final Provider<HotspotTile> mHotspotTileProvider;
    private final Provider<UserTile> mUserTileProvider;
    private final Provider<BatterySaverTile> mBatterySaverTileProvider;
    private final Provider<DataSaverTile> mDataSaverTileProvider;
    private final Provider<NightDisplayTile> mNightDisplayTileProvider;
    private final Provider<NfcTile> mNfcTileProvider;
    private final Provider<GarbageMonitor.MemoryTile> mMemoryTileProvider;
    private final Provider<UiModeNightTile> mUiModeNightTileProvider;

    private QSTileHost mHost;

    @Inject
    public QSFactoryImpl(Provider<WifiTile> wifiTileProvider,
            Provider<BluetoothTile> bluetoothTileProvider,
            Provider<CellularTile> cellularTileProvider,
            Provider<DndTile> dndTileProvider,
            Provider<ColorInversionTile> colorInversionTileProvider,
            Provider<AirplaneModeTile> airplaneModeTileProvider,
            Provider<WorkModeTile> workModeTileProvider,
            Provider<RotationLockTile> rotationLockTileProvider,
            Provider<FlashlightTile> flashlightTileProvider,
            Provider<LongScreenshotTile> longScreenshotTileProvider,
            Provider<OneHandTile> oneHandTileProvider,
            Provider<LocationTile> locationTileProvider,
            Provider<CastTile> castTileProvider,
            Provider<HotspotTile> hotspotTileProvider,
            Provider<UserTile> userTileProvider,
            Provider<BatterySaverTile> batterySaverTileProvider,
            Provider<DataSaverTile> dataSaverTileProvider,
            Provider<NightDisplayTile> nightDisplayTileProvider,
            Provider<NfcTile> nfcTileProvider,
            Provider<GarbageMonitor.MemoryTile> memoryTileProvider,
            Provider<UiModeNightTile> uiModeNightTileProvider) {
        mWifiTileProvider = wifiTileProvider;
        mBluetoothTileProvider = bluetoothTileProvider;
        mCellularTileProvider = cellularTileProvider;
        mDndTileProvider = dndTileProvider;
        mColorInversionTileProvider = colorInversionTileProvider;
        mAirplaneModeTileProvider = airplaneModeTileProvider;
        mWorkModeTileProvider = workModeTileProvider;
        mRotationLockTileProvider = rotationLockTileProvider;
        mFlashlightTileProvider = flashlightTileProvider;
        mLongScreenshotTileProvider = longScreenshotTileProvider;
        mOneHandTileProvider = oneHandTileProvider;
        mLocationTileProvider = locationTileProvider;
        mCastTileProvider = castTileProvider;
        mHotspotTileProvider = hotspotTileProvider;
        mUserTileProvider = userTileProvider;
        mBatterySaverTileProvider = batterySaverTileProvider;
        mDataSaverTileProvider = dataSaverTileProvider;
        mNightDisplayTileProvider = nightDisplayTileProvider;
        mNfcTileProvider = nfcTileProvider;
        mMemoryTileProvider = memoryTileProvider;
        mUiModeNightTileProvider = uiModeNightTileProvider;
    }

    public void setHost(QSTileHost host) {
        mHost = host;
    }

    public QSTile createTile(String tileSpec) {
        QSTileImpl tile = createTileInternal(tileSpec);
        if (tile != null) {
            tile.handleStale(); // Tile was just created, must be stale.
        }
        return tile;
    }

    private QSTileImpl createTileInternal(String tileSpec) {
        Log.w(TAG, "createTileInternal tileSpec: " + tileSpec);
        // Stock tiles.
        switch (tileSpec) {
            case "wifi":
                return mWifiTileProvider.get();
            case "volte1":
            case "volte2":
            case "vowifi":
            case "lte": //UNISOC: Modify for bug1263324
            case "lte1":
            case "lte2":
                return createExtraTile(mHost, tileSpec);
            case "bt":
                return null/*mBluetoothTileProvider.get()*/;
            case "cell":
                return mCellularTileProvider.get();
            case "dnd":
                return mDndTileProvider.get();
            case "inversion":
                return mColorInversionTileProvider.get();
            case "airplane":
                return mAirplaneModeTileProvider.get();
            case "work":
                return mWorkModeTileProvider.get();
            case "rotation":
                return mRotationLockTileProvider.get();
            case "flashlight":
                return mFlashlightTileProvider.get();
            case "longscreenshot":
                return mLongScreenshotTileProvider.get();
            case "onehand":
                return mOneHandTileProvider.get();
            case "location":
                return mLocationTileProvider.get();
            case "cast":
                return mCastTileProvider.get();
            case "hotspot":
                return mHotspotTileProvider.get();
            case "user":
                return mUserTileProvider.get();
            case "battery":
                /*UNISOC Bug 1074234, 885650, Super power feature @{ */
                if (SprdPowerManagerUtil.SUPPORT_SUPER_POWER_SAVE) {
                    Log.w(TAG, "SuperBatteryTile " + tileSpec);
                    return new SuperBatteryTile(mHost);
                } else {
                    return mBatterySaverTileProvider.get();
                }
                /* @} */
            case "saver":
                return mDataSaverTileProvider.get();
            case "night":
                return mNightDisplayTileProvider.get();
            case "nfc":
                return mNfcTileProvider.get();
            case "dark":
                return mUiModeNightTileProvider.get();
        }

        // Intent tiles.
        if (tileSpec.startsWith(IntentTile.PREFIX)) return IntentTile.create(mHost, tileSpec);
        if (tileSpec.startsWith(CustomTile.PREFIX)) return CustomTile.create(mHost, tileSpec);

        // Debug tiles.
        /* UNISOC bug 908966 control MemoryTile by ro.systemui.debug_memory @{ */
        boolean debugMemory = SystemProperties.getBoolean("systemui.debug_memory",false);
        if (Build.IS_DEBUGGABLE && debugMemory) {
        /* @} */
            if (tileSpec.equals(GarbageMonitor.MemoryTile.TILE_SPEC)) {
                return mMemoryTileProvider.get();
            }
        }

        // Broken tiles.
        Log.w(TAG, "No stock tile spec: " + tileSpec);
        return null;
    }

    @Override
    public QSTileView createTileView(QSTile tile, boolean collapsedView) {
        Context context = new ContextThemeWrapper(mHost.getContext(), R.style.qs_theme);
        QSIconView icon = tile.createTileView(context);
        if (collapsedView) {
            return new QSTileBaseView(context, icon, collapsedView);
        } else {
            return new com.android.systemui.qs.tileimpl.QSTileView(context, icon);
        }
    }

    public QSTileImpl createExtraTile(QSTileHost host, String tileSpec) {
        Context context = host.getContext();
        if ("volte1".equals(tileSpec)
                && context.getResources().getBoolean(com.android.internal.R.bool.config_device_volte_available)
                && context.getResources().getBoolean(R.bool.config_show_volte_tile)
                && isDeviceSupportLte()) {
            return new VolteTile(mHost,0);
        } else if ("volte2".equals(tileSpec)
                && context.getResources().getBoolean(com.android.internal.R.bool.config_device_volte_available)
                && context.getResources().getBoolean(R.bool.config_show_volte_tile)
                && isDeviceSupportLte()
                && TelephonyManager.from(context).isMultiSimEnabled()) {
            return new VolteTile(mHost,1);
        } else if ("vowifi".equals(tileSpec)
                && context.getResources().getBoolean(com.android.internal.R.bool.config_device_wfc_ims_available)
                && context.getResources().getBoolean(R.bool.config_show_vowifi_tile)){
            return new VoWifiTile(host);
        } else if (("lte1".equals(tileSpec) || "lte".equals(tileSpec)) //UNISOC: Modify for bug1263324
                && context.getResources().getBoolean(R.bool.config_show_lte_tile)
                && isDeviceSupportLte()) {
            return new LteServiceTile(host);
        } else if ("lte2".equals(tileSpec)
                && context.getResources().getBoolean(R.bool.config_show_lte_tile)
                && isDeviceSupportLte()
                && TelephonyManager.from(context).isMultiSimEnabled()) {
            return new LteServiceTile(host,1);
        }
        return null;
    }

    public static boolean isDeviceSupportLte() {
        String prop = SystemProperties.get(RADIO_MODEM_CAPABILITY, "");
        Log.d(TAG, "isDeviceSupportLte prop = " + prop);
        if (!prop.isEmpty() && prop.toUpperCase().contains(LTE_INDICATOR)) {
            Log.d(TAG, "isDeviceSupportLte TRUE");
            return true;
        }
        return false;
    }
}
```

## 4.功能具体实现


第一种方法:



```
在createTileInternal(String tileSpec) 中根据tileSpace 构造相应的快捷图标
所以具体修改为:
            case "bt":
               - return mBluetoothTileProvider.get();
               + return null/*mBluetoothTileProvider.get()*/;
在相应的tile下 返回null就可以了
```

第二种方法:



```
第二种方法可以在config.xml中去掉快捷图标对应的tileSpace 字符
路径:frameworks\base\packages\SystemUI\res\values\config.xml
    <string name="quick_settings_tiles_default" translatable="false">
        volte1,volte2,wifi,bt,dnd,vowifi,onehand,flashlight,battery
    </string>
 所有默认快捷图标都是从quick_settings_tiles_default读取的
去掉蓝牙 图标 就去掉bt 就可以了
修改如下:
    <string name="quick_settings_tiles_default" translatable="false">
      -  volte1,volte2,wifi,bt,dnd,vowifi,onehand,flashlight,battery
      +  volte1,volte2,wifi,dnd,vowifi,onehand,flashlight,battery
    </string>
```



