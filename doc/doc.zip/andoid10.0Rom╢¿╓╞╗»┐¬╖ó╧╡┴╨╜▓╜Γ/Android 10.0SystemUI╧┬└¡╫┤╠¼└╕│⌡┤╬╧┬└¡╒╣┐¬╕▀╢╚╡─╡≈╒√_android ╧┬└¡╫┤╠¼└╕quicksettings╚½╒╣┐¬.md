






### 1.概述


在10.0的系统产品中，在对系统SystemUI定制化开发中，需求要求对系统下拉状态栏展开下拉时，UI界面高度调整，  
 首选要对下拉区域的相关UI布局源码做分析 然后做调整


### 2.SystemUI下拉状态栏初次下拉展开高度的调整的核心类



```
/frameworks/base/packages/SystemUI/res/layout/quick_status_bar_expanded_header.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java

```

### 3.SystemUI下拉状态栏初次下拉展开高度的调整核心功能分析和实现


在系统SystemUI中，对于下拉状态栏的处理，首次下拉状态栏的布局就是  
 quick\_status\_bar\_expanded\_header.xml 布局


### 3.1quick\_status\_bar\_expanded\_header.xml 布局相关源码分析



```
<com.android.systemui.qs.QuickStatusBarHeader
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/header"
    android:layout_width="match\_parent"
    android:layout_height="@\*android:dimen/quick\_qs\_total\_height"
    android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
    android:background="@android:color/transparent"
    android:baselineAligned="false"
    android:clickable="false"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:paddingTop="0dp"
    android:paddingEnd="0dp"
    android:paddingStart="0dp"
    android:elevation="4dp" >

    <include layout="@layout/quick\_status\_bar\_header\_system\_icons" />

    <!-- Status icons within the panel itself (and not in the top-most status bar) -->
    <include layout="@layout/quick\_qs\_status\_icons" />

    <!-- Layout containing tooltips, alarm text, etc. -->
    <include layout="@layout/quick\_settings\_header\_info" />

    <com.android.systemui.qs.QuickQSPanel
        android:id="@+id/quick\_qs\_panel"
        android:layout_width="match\_parent"
        android:layout_height="48dp"
        android:layout_below="@id/quick\_qs\_status\_icons"
        android:layout_marginStart="@dimen/qs\_header\_tile\_margin\_horizontal"
        android:layout_marginEnd="@dimen/qs\_header\_tile\_margin\_horizontal"
        android:accessibilityTraversalAfter="@+id/date\_time\_group"
        android:accessibilityTraversalBefore="@id/expand\_indicator"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:focusable="true"
        android:importantForAccessibility="yes" />

    <com.android.systemui.statusbar.AlphaOptimizedImageView
        android:id="@+id/qs\_detail\_header\_progress"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_alignParentBottom="true"
        android:alpha="0"
        android:background="@color/qs\_detail\_progress\_track"
        android:src="@drawable/indeterminate\_anim"/>

    <TextView
        android:id="@+id/header\_debug\_info"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_vertical"
        android:fontFamily="sans-serif-condensed"
        android:padding="2dp"
        android:textColor="#00A040"
        android:textSize="11dp"
        android:textStyle="bold"
        android:visibility="invisible"/>

</com.android.systemui.qs.QuickStatusBarHeader>

```

从quick\_status\_bar\_expanded\_header.xml 布局中可以看到QuickStatusBarHeader.java 是根布局  
 QuickStatusBarHeader.java的  
 路径为:frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java  
 接下来分析QuickStatusBarHeader.java的相关高度问题


### 3.2QuickStatusBarHeader.java的相关高度的源码分析



```
public class QuickStatusBarHeader extends RelativeLayout implements
        View.OnClickListener, NextAlarmController.NextAlarmChangeCallback,
        ZenModeController.Callback {
        @Override
      protected void onFinishInflate() {
          super.onFinishInflate();
  
          mHeaderQsPanel = findViewById(R.id.quick_qs_panel);
          mSystemIconsView = findViewById(R.id.quick_status_bar_system_icons);
          mQuickQsStatusIcons = findViewById(R.id.quick_qs_status_icons);
          StatusIconContainer iconContainer = findViewById(R.id.statusIcons);
          iconContainer.setShouldRestrictIcons(false);
          mIconManager = new TintedIconManager(iconContainer);
  
          // Views corresponding to the header info section (e.g. ringer and next alarm).
          mHeaderTextContainerView = findViewById(R.id.header_text_container);
          mStatusSeparator = findViewById(R.id.status_separator);
          mNextAlarmIcon = findViewById(R.id.next_alarm_icon);
          mNextAlarmTextView = findViewById(R.id.next_alarm_text);
          mNextAlarmContainer = findViewById(R.id.alarm_container);
          mNextAlarmContainer.setOnClickListener(this::onClick);
          mRingerModeIcon = findViewById(R.id.ringer_mode_icon);
          mRingerModeTextView = findViewById(R.id.ringer_mode_text);
          mRingerContainer = findViewById(R.id.ringer_container);
          mCarrierGroup = findViewById(R.id.carrier_group);
  
  
          updateResources();
  
          Rect tintArea = new Rect(0, 0, 0, 0);
          int colorForeground = Utils.getColorAttrDefaultColor(getContext(),
                  android.R.attr.colorForeground);
          float intensity = getColorIntensity(colorForeground);
          int fillColor = mDualToneHandler.getSingleColor(intensity);
  
          // Set light text on the header icons because they will always be on a black background
          applyDarkness(R.id.clock, tintArea, 0, DarkIconDispatcher.DEFAULT_ICON_TINT);
  
          // Set the correct tint for the status icons so they contrast
          mIconManager.setTint(fillColor);
          mNextAlarmIcon.setImageTintList(ColorStateList.valueOf(fillColor));
          mRingerModeIcon.setImageTintList(ColorStateList.valueOf(fillColor));
  
          mClockView = findViewById(R.id.clock);
          mClockView.setOnClickListener(this);
          mDateView = findViewById(R.id.date);
  
          // Tint for the battery icons are handled in setupHost()
          mBatteryRemainingIcon = findViewById(R.id.batteryRemainingIcon);
          // Don't need to worry about tuner settings for this icon
 mBatteryRemainingIcon.setIgnoreTunerUpdates(true);
 // QS will always show the estimate, and BatteryMeterView handles the case where
 // it's unavailable or charging
          mBatteryRemainingIcon.setPercentShowMode(BatteryMeterView.MODE_ESTIMATE);
          mRingerModeTextView.setSelected(true);
          mNextAlarmTextView.setSelected(true);
      }
  
    private void updateResources() {
        Resources resources = mContext.getResources();
        updateMinimumHeight();

        // Update height for a few views, especially due to landscape mode restricting space.
        mHeaderTextContainerView.getLayoutParams().height =
                resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
        mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

        mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
                com.android.internal.R.dimen.quick_qs_offset_height);
        mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        if (mQsDisabled) {
            lp.height = resources.getDimensionPixelSize(
                    com.android.internal.R.dimen.quick_qs_offset_height);
        } else {
            lp.height = Math.max(getMinimumHeight(),
                    resources.getDimensionPixelSize(
                            com.android.internal.R.dimen.quick_qs_total_height));
        }

        setLayoutParams(lp);

        updateStatusIconAlphaAnimator();
        updateHeaderTextContainerAlphaAnimator();
    }
}

```

在QuickStatusBarHeader的初始化完成后，在onFinishInflate()加载布局的相关参数，然后调用  
 updateResources() 都会更新布局相关参数，在这里设置QuickStatusBarHeader布局的高度，  
 所以说修改QuickStatusBarHeader的高度可以在updateResources()做调整，  
 具体修改为：



```
         StatusIconContainer iconContainer = findViewById(R.id.statusIcons);
         iconContainer.setShouldRestrictIcons(false);
         mIconManager = new TintedIconManager(iconContainer);
-
         // Views corresponding to the header info section (e.g. ringer and next alarm).
         mHeaderTextContainerView = findViewById(R.id.header_text_container);
         mStatusSeparator = findViewById(R.id.status_separator);
@@ -312,12 +310,9 @@ public class QuickStatusBarHeader extends RelativeLayout implements
 
         FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
         if (mQsDisabled) {
-            lp.height = resources.getDimensionPixelSize(
-                    com.android.internal.R.dimen.quick_qs_offset_height);
+            lp.height = resources.getDimensionPixelSize(R.dimen.quick_qs_height);
         } else {
-            lp.height = Math.max(getMinimumHeight(),
-                    resources.getDimensionPixelSize(
-                            com.android.internal.R.dimen.quick_qs_total_height));
+            lp.height = Math.max(getMinimumHeight(),resources.getDimensionPixelSize(R.dimen.quick_qs_height));
         }

```

quick\_qs\_height 为自定义的高度值





