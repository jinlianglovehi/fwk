



## 1.前言


  
  在10.0的产品开发中，在对于一些产品开发需求中，对系统截屏和录屏功能 要求去掉这些功能，不让用户截屏和录屏 保护  
 一个app的资源，所以就需要在系统中做限制不让截屏录屏


## 2.系统禁用截屏和录屏功能的核心类



```
frameworks\native\services\surfaceflinger\Layer.cpp
frameworks\base\core\java\android\app\ActivityThread.java
```

## 3.系统禁用截屏和录屏功能的核心功能分析和实现


  
  在系统中可以在app中禁用录屏和截屏功能，同时也可以通过在系统源码中禁止截屏和录屏的功能，首先我们看下如何在app应用中禁止截屏录屏的的功能，app中禁止录屏和截屏功能的相关源码如下



```
        @Override
        protected void onCreate(Bundle savedInstanceState) {
     
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
     
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_layout);
        }
```

通过在单个应用中禁止截屏录屏功能，系统提供了对应的接口，如上代码添加 FLAG\_SECURE 即可。  
 设置后，在此 activity 界面，截图时会提示无法截图，录屏时界面是全黑的。通过上面的实现方法  
 可以得知就是给activity的窗口的window窗口添加WindowManager.LayoutParams.FLAG\_SECURE  
 属性就可以了，所以可以在ActivityThread.java启动activity的时候添加flags属性就可以了


## 3.1 ActivityThread.java相关源码分析



在上述的分析中，可以得知，在系统app应用开发中，可以通过在oncreate中启动activity中，设置window窗口的flag属性来禁用录屏截屏功能，就是设置WindowManager.LayoutParams.FLAG\_SECURE这个属性，所以也同时可以在ActivityThread.java中,构建activity窗口的时候设置这个flag属性来实现功能



```
    @Override
    public void handleResumeActivity(IBinder token, boolean finalStateRequest, boolean isForward,
            String reason) {
        // If we are getting ready to gc after going to the background, well
        // we are back active so skip it.
        unscheduleGcIdler();
        mSomeActivitiesChanged = true;

        // TODO Push resumeArgs into the activity for consideration
        final ActivityClientRecord r = performResumeActivity(token, finalStateRequest, reason);
        if (r == null) {
            // We didn't actually resume the activity, so skipping any follow-up actions.
            return;
        }
        if (mActivitiesToBeDestroyed.containsKey(token)) {
            // Although the activity is resumed, it is going to be destroyed. So the following
            // UI operations are unnecessary and also prevents exception because its token may
            // be gone that window manager cannot recognize it. All necessary cleanup actions
            // performed below will be done while handling destruction.
            return;
        }

        final Activity a = r.activity;
        clearDisplayCacheIfNeeded(r);//add code
        if (localLOGV) {
            Slog.v(TAG, "Resume " + r + " started activity: " + a.mStartedActivity
                    + ", hideForNow: " + r.hideForNow + ", finished: " + a.mFinished);
        }

        final int forwardBit = isForward
                ? WindowManager.LayoutParams.SOFT_INPUT_IS_FORWARD_NAVIGATION : 0;

        // If the window hasn't yet been added to the window manager,
        // and this guy didn't finish itself or start another activity,
        // then go ahead and add the window.
        boolean willBeVisible = !a.mStartedActivity;
        if (!willBeVisible) {
            try {
                willBeVisible = ActivityTaskManager.getService().willActivityBeVisible(
                        a.getActivityToken());
            } catch (RemoteException e) {
                throw e.rethrowFromSystemServer();
            }
        }
        if (r.window == null && !a.mFinished && willBeVisible) {
            r.window = r.activity.getWindow();
            View decor = r.window.getDecorView();
            decor.setVisibility(View.INVISIBLE);
            ViewManager wm = a.getWindowManager();
            WindowManager.LayoutParams l = r.window.getAttributes();
            a.mDecor = decor;
            l.type = WindowManager.LayoutParams.TYPE_BASE_APPLICATION;

//add core start
            ComponentName comptname = r.activity.getComponentName();
			if(comptname!=null){
			 String pkg = comptname.getPackageName();
			 String cls = comptname.getClassName();
			 android.util.Log.e("ActivityThread","pkg:"+pkg+"--cls:"+cls);
			 if(!TextUtils.isEmpty(pkg)&&!pkg.equals("android")&&!pkg.equals("com.android.launcher3")){
			    l.flags = WindowManager.LayoutParams.FLAG_SECURE;
			 }
			}

//add core end 


            l.softInputMode |= forwardBit;
            if (r.mPreserveWindow) {
                a.mWindowAdded = true;
                r.mPreserveWindow = false;
                // Normally the ViewRoot sets up callbacks with the Activity
                // in addView->ViewRootImpl#setView. If we are instead reusing
                // the decor view we have to notify the view root that the
                // callbacks may have changed.
                ViewRootImpl impl = decor.getViewRootImpl();
                if (impl != null) {
                    impl.notifyChildRebuilt();
                }
            }
            if (a.mVisibleFromClient) {
                if (!a.mWindowAdded) {
                    a.mWindowAdded = true;
                    wm.addView(decor, l);
                } else {
                    // The activity will get a callback for this {@link LayoutParams} change
                    // earlier. However, at that time the decor will not be set (this is set
                    // in this method), so no action will be taken. This call ensures the
                    // callback occurs with the decor set.
                    a.onWindowAttributesChanged(l);
                }
            }

            // If the window has already been added, but during resume
            // we started another activity, then don't yet make the
            // window visible.
        } else if (!willBeVisible) {
            if (localLOGV) Slog.v(TAG, "Launch " + r + " mStartedActivity set");
            r.hideForNow = true;
        }

        // Get rid of anything left hanging around.
        cleanUpPendingRemoveWindows(r, false /* force */);
...
}
```

在上述ActivityThread.java的源码中，可以在handleResumeActivity(IBinder token, boolean finalStateRequest, boolean isForward,  
             String reason) 中这个构建activity的方法中，在绑定PhoneWindow的窗口的时候  
 添加flags属性WindowManager.LayoutParams.FLAG\_SECURE;  
 这样就可以禁用截屏功能了


## 3.2 Layer.cpp中实现禁用录屏功能



```
Hwc2::IComposerClient::Composition Layer::getCompositionType(const DisplayDevice& display) const {
    const auto outputLayer = findOutputLayerForDisplay(&display);
    if (outputLayer == nullptr) {
        return Hwc2::IComposerClient::Composition::INVALID;
    }
    if (outputLayer->getState().hwc) {
        return (*outputLayer->getState().hwc).hwcCompositionType;
    } else {
        return Hwc2::IComposerClient::Composition::CLIENT;
    }
}

bool Layer::addSyncPoint(const std::shared_ptr<SyncPoint>& point) {
    if (point->getFrameNumber() <= mCurrentFrameNumber) {
        // Don't bother with a SyncPoint, since we've already latched the
        // relevant frame
        return false;
    }
    if (isRemovedFromCurrentState()) {
        return false;
    }

    Mutex::Autolock lock(mLocalSyncPointMutex);
    mLocalSyncPoints.push_back(point);
    return true;
}

// ----------------------------------------------------------------------------
// local state
// ----------------------------------------------------------------------------

bool Layer::isSecure() const {
    const State& s(mDrawingState);
    return (s.flags & layer_state_t::eLayerSecure);
}
```

在Layer.cpp中的上述源码中，在通过分析得知，在这里构建视图的时候，会首先通过在这里处理录屏的方法中，主要是根据isSecure()来判断  
 当前是否是SECURE模式，如果是SECURE模式就不能录屏，所以可以修改这个isSecure()的返回值，直接返回false就表示禁止录屏，所以可以具体修改为:



```
bool Layer::isSecure() const {
    /*const State& s(mDrawingState);*/
    return true/*(s.flags & layer_state_t::eLayerSecure)*/;
}
```



