






android 6.0系统中保活机制，所以在系统内存不够的时候，后台运行的app有可能会被系统杀掉  
 所以为了让app不能系统杀掉保持永久运行 就必须要增加权限，把app 添加到保活白名单里面  
 或者授予后台运行的权限


接下来看Settings的源码  
 REQUEST\_IGNORE\_BATTERY\_OPTIMIZATIONS 权限就是忽略被电池优化的权限 在普通app里面也可以申请这个权限  
 申请完这个权限后就不会被优化 可以一直在后台运行  
 在Settings的源码中  
 RequestIgnoreBatteryOptimizations.java 就负责管理电池优化的类  
 路径:  
 packages/apps/Settings/src/com/android/settings/fuelgauge/RequestIgnoreBatteryOptimizations.java  
 接下来看下源码



```
public class RequestIgnoreBatteryOptimizations extends AlertActivity implements
        DialogInterface.OnClickListener {
    static final String TAG = "RequestIgnoreBatteryOptimizations";

    private static final String DEVICE_IDLE_SERVICE = "deviceidle";

    IDeviceIdleController mDeviceIdleService;
    String mPackageName;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mDeviceIdleService = IDeviceIdleController.Stub.asInterface(
                ServiceManager.getService(DEVICE_IDLE_SERVICE));

        Uri data = getIntent().getData();
        if (data == null) {
            Log.w(TAG, "No data supplied for IGNORE\_BATTERY\_OPTIMIZATION\_SETTINGS in: "
                    + getIntent());
            finish();
            return;
        }
        mPackageName = data.getSchemeSpecificPart();
        if (mPackageName == null) {
            Log.w(TAG, "No data supplied for IGNORE\_BATTERY\_OPTIMIZATION\_SETTINGS in: "
                    + getIntent());
            finish();
            return;
        }
        
        // add code start
        if(true){
            try {
                mDeviceIdleService.addPowerSaveWhitelistApp(mPackageName);
            } catch (Exception e) {
                    Log.w(TAG, "Unable to reach IDeviceIdleController", e);
            }                      
        }
        // add code end 
        
        PowerManager power = getSystemService(PowerManager.class);
        if (power.isIgnoringBatteryOptimizations(mPackageName)) {
            Log.i(TAG, "Not should prompt, already ignoring optimizations: " + mPackageName);
            finish();
            return;
        }

        ApplicationInfo ai;
        try {
            ai = getPackageManager().getApplicationInfo(mPackageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.w(TAG, "Requested package doesn't exist: " + mPackageName);
            finish();
            return;
        }

        if (getPackageManager().checkPermission(
                Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, mPackageName)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Requested package " + mPackageName + " does not hold permission "
                    + Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            finish();
            return;
        }

        final AlertController.AlertParams p = mAlertParams;
        p.mTitle = getText(R.string.high_power_prompt_title);
        p.mMessage = getString(R.string.high_power_prompt_body, ai.loadLabel(getPackageManager()));
        p.mPositiveButtonText = getText(R.string.allow);
        p.mNegativeButtonText = getText(R.string.deny);
        p.mPositiveButtonListener = this;
        p.mNegativeButtonListener = this;
        setupAlert();
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (which) {
            case BUTTON_POSITIVE:
                try {
                    mDeviceIdleService.addPowerSaveWhitelistApp(mPackageName);
                } catch (RemoteException e) {
                    Log.w(TAG, "Unable to reach IDeviceIdleController", e);
                }
                setResult(RESULT_OK);
                break;
            case BUTTON_NEGATIVE:
                break;
        }
    }
}

```

特别增加了这个DeviceIdleController，来控制设备的Idle状态。而当设备在idle状态时，它会忽略cpu的wakelock，Alarm等。  
 因此DeviceIdleController在power中的地位也是相当重要


mDeviceIdleService.addPowerSaveWhitelistApp 方法可以把app 添加到避免被优化的白名单里面 所以添加此方法就可以了


修改如下:  
 在 onCreate(Bundle savedInstanceState) 添加



```
  if(true){
            try {
                mDeviceIdleService.addPowerSaveWhitelistApp(mPackageName);
            } catch (Exception e) {
                    Log.w(TAG, "Unable to reach IDeviceIdleController", e);
            }                      
        }

```




