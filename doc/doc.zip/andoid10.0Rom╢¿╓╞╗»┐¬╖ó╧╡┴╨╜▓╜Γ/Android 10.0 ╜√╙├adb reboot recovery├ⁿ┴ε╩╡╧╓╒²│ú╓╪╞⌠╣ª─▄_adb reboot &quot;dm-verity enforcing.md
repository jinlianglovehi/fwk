



## 1.前言


  
   在10.0的系统开发中，在定制recovery模块的时候，由于产品开发需要要求禁用recovery的相关功能，比如在通过adb命令的  
 adb reboot recovery的方式进入recovery也需要实现禁用，所以就需要了解相关进入recovery流程来禁用该功能


## 2.禁用adb reboot recovery命令实现正常重启功能的核心类



```
system\core\adb\daemon\services.cpp
system\core\adb\daemon\reboot_service.cpp
```

## 3.禁用adb reboot recovery命令实现正常重启功能的核心功能分析和实现


  
  在10.0的产品中，在通过adb reboot recovery 进入 recovery 模式后正常可以进行recovery的相关操作，而  
 adb 是pc端工具，adbd是服务端，运行在手机 adbd 读取 socket 解析由 adb 传过来的命令串，解析相关的  
 命令执行相关功能，所以在pc端输入adb 相关命令 就会在system\core\adb 模块解析相关命令  
 所以说在services.cpp中来作为服务端来执行相关功能


## 3.1 services.cpp中关于服务端的相关代码分析


在系统system\core\adb 模块中，而services.cpp在开机过程中就会启动，作为一个守护进程，来处理adb模块和pc端通讯的相关命令处理的核心bin文件，在这里处理各种各样的adb命令，所有接下来具体分析下它的adb相关的通讯命令源码



```
asocket* daemon_service_to_socket(std::string_view name) {
    if (name == "jdwp") {
        return create_jdwp_service_socket();
    } else if (name == "track-jdwp") {
        return create_jdwp_tracker_service_socket();
    } else if (ConsumePrefix(&name, "sink:")) {
        uint64_t byte_count = 0;
        if (!ParseUint(&byte_count, name)) {
            return nullptr;
        }
        return new SinkSocket(byte_count);
    } else if (ConsumePrefix(&name, "source:")) {
        uint64_t byte_count = 0;
        if (!ParseUint(&byte_count, name)) {
            return nullptr;
        }
        return new SourceSocket(byte_count);
    }

    return nullptr;
}

unique_fd daemon_service_to_fd(std::string_view name, atransport* transport) {
#if defined(__ANDROID__) && !defined(__ANDROID_RECOVERY__)
    if (name.starts_with("abb:") || name.starts_with("abb_exec:")) {
        return execute_abb_command(name);
    }
#endif

#if defined(__ANDROID__)
    if (name.starts_with("framebuffer:")) {
        return create_service_thread("fb", framebuffer_service);
    } else if (ConsumePrefix(&name, "remount:")) {
        std::string arg(name);
        return create_service_thread("remount",
                                     std::bind(remount_service, std::placeholders::_1, arg));
    } else if (ConsumePrefix(&name, "reboot:")) {
        std::string arg(name);
        return create_service_thread("reboot",
                                     std::bind(reboot_service, std::placeholders::_1, arg));
    } else if (name.starts_with("root:")) {
        return create_service_thread("root", restart_root_service);
    } else if (name.starts_with("unroot:")) {
        return create_service_thread("unroot", restart_unroot_service);
    } else if (ConsumePrefix(&name, "backup:")) {
        std::string cmd = "/system/bin/bu backup ";
        cmd += name;
        return StartSubprocess(cmd, nullptr, SubprocessType::kRaw, SubprocessProtocol::kNone);
    } else if (name.starts_with("restore:")) {
        return StartSubprocess("/system/bin/bu restore", nullptr, SubprocessType::kRaw,
                               SubprocessProtocol::kNone);
    } else if (name.starts_with("disable-verity:")) {
        return create_service_thread("verity-on", std::bind(set_verity_enabled_state_service,
                                                            std::placeholders::_1, false));
    } else if (name.starts_with("enable-verity:")) {
        return create_service_thread("verity-off", std::bind(set_verity_enabled_state_service,
                                                             std::placeholders::_1, true));
    } else if (ConsumePrefix(&name, "tcpip:")) {
        std::string str(name);

        int port;
        if (sscanf(str.c_str(), "%d", &port) != 1) {
            return unique_fd{};
        }
        return create_service_thread("tcp",
                                     std::bind(restart_tcp_service, std::placeholders::_1, port));
    } else if (name.starts_with("usb:")) {
        return create_service_thread("usb", restart_usb_service);
    }
#endif

    if (ConsumePrefix(&name, "dev:")) {
        return unique_fd{unix_open(name, O_RDWR | O_CLOEXEC)};
    } else if (ConsumePrefix(&name, "jdwp:")) {
        pid_t pid;
        if (!ParseUint(&pid, name)) {
            return unique_fd{};
        }
        return create_jdwp_connection_fd(pid);
    } else if (ConsumePrefix(&name, "shell")) {
        return ShellService(name, transport);
    } else if (ConsumePrefix(&name, "exec:")) {
        return StartSubprocess(std::string(name), nullptr, SubprocessType::kRaw,
                               SubprocessProtocol::kNone);
    } else if (name.starts_with("sync:")) {
        return create_service_thread("sync", file_sync_service);
    } else if (ConsumePrefix(&name, "reverse:")) {
        return reverse_service(name, transport);
    } else if (name == "reconnect") {
        return create_service_thread(
                "reconnect", std::bind(reconnect_service, std::placeholders::_1, transport));
    } else if (name == "spin") {
        return create_service_thread("spin", spin_service);
    }

    return unique_fd{};
}

```

在services.cpp中的上述相关源码中分析得知，在daemon\_service\_to\_fd(std::string\_view name, atransport\* transport)  
 中负责解析adb reboot adb remount等相关命令，所以在  
 else if (ConsumePrefix(&name, "reboot:")) {  
         std::string arg(name);  
         return create\_service\_thread("reboot",  
                                      std::bind(reboot\_service, std::placeholders::\_1, arg));  
     }  
 这段代码中表示需要在reboot\_service.cpp中的reboot\_service方法中执行reboot的相关功能，接下来  
 分析下reboot\_service的相关源码


## 3.2 reboot\_service.cpp的相关源码分析


在系统system\core\adb 模块中，而reboot\_service.cpp主要处理reboot recovery等相关命令的核心服务文件，所以说也可以在这里查询下关于adb recovery的相关响应源码分析



```
void reboot_service(unique_fd fd, const std::string& arg) {
    std::string reboot_arg = arg;
    sync();

    if (reboot_arg.empty()) reboot_arg = "adb";

//core modify start
   std::string reboot_string ="";
   if (strcmp("recovery", reboot_arg) != 0){
            reboot_string = android::base::StringPrintf("reboot,%s", reboot_arg.c_str());
   }else{
     reboot_string ="reboot";
   }
//core modify end

    if (reboot_arg == "fastboot" &&
        android::base::GetBoolProperty("ro.boot.dynamic_partitions", false) &&
        access("/dev/socket/recovery", F_OK) == 0) {
        LOG(INFO) << "Recovery specific reboot fastboot";
        /*
         * The socket is created to allow switching between recovery and
         * fastboot.
         */
        android::base::unique_fd sock(socket(AF_UNIX, SOCK_STREAM, 0));
        if (sock < 0) {
            WriteFdFmt(fd, "reboot (%s) create\n", strerror(errno));
            PLOG(ERROR) << "Creating recovery socket failed";
            return;
        }

        sockaddr_un addr = {.sun_family = AF_UNIX};
        strncpy(addr.sun_path, "/dev/socket/recovery", sizeof(addr.sun_path) - 1);
        if (connect(sock, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == -1) {
            WriteFdFmt(fd, "reboot (%s) connect\n", strerror(errno));
            PLOG(ERROR) << "Couldn't connect to recovery socket";
            return;
        }
        const char msg_switch_to_fastboot = 'f';
        auto ret = adb_write(sock, &msg_switch_to_fastboot, sizeof(msg_switch_to_fastboot));
        if (ret != sizeof(msg_switch_to_fastboot)) {
            WriteFdFmt(fd, "reboot (%s) write\n", strerror(errno));
            PLOG(ERROR) << "Couldn't write message to recovery socket to switch to fastboot";
            return;
        }
    } else {
        if (!android::base::SetProperty(ANDROID_RB_PROPERTY, reboot_string)) {
            WriteFdFmt(fd.get(), "reboot (%s) failed\n", reboot_string.c_str());
            return;
        }
    }
    // Don't return early. Give the reboot command time to take effect
    // to avoid messing up scripts which do "adb reboot && adb wait-for-device"
    while (true) {
        pause();
    }
}
```

在reboot\_service.cpp的相关源码分析得知，在adb reboot的相关参数arg 就是相关的具体操作，  
 比如recovery 等，所以可以判断arg是否等于recovery,然后如果等于recovery，就 reboot\_string ="reboot";  
 值负责重启就可以了，然后就实现相关的功能



