






### 1.概述


在10.0系统产品开发中，进行Recovery 恢复出厂设置时 发现 真正清理的 字体小了 产品不满意 所以要求改大一点字体 于是 就只能去看Recovery部分的源码 这部分都是C 语言的代码，字体设置不可能像上层一样，就可以了  
 于是就找资源 但是博客 参差不齐 有些就寥寥数语


### 2. 修改Recovery字体图片的大小(正在清理)文字大小的核心类



```
build/make/core/Makefile
bootable/recovery/tools/image_generator/ImageGenerator.java

```

### 3. 修改Recovery字体图片的大小(正在清理)文字大小核心功能实现和分析


根据相关源码发现，相关recovery的图片格式会在Makefile中，根据变量会生成相应的jar  
 所以就从build/make/core/Makefile 看看能不能找到使用的字体格式，接下来看下Makefile的相关源码


### 3.1Makefile的相关源码分析



```
resource_dir := $(call include-path-for, recovery)/tools/recovery_l10n/res/
image_generator_jar := $(HOST\_OUT\_JAVA\_LIBRARIES)/RecoveryImageGenerator.jar
zopflipng := $(HOST\_OUT\_EXECUTABLES)/zopflipng
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_SOURCE_FONTS := $(recovery\_noto-fonts\_dep) $(recovery\_roboto-fonts\_dep)
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_RECOVERY_FONT_FILES_DIR := $(call intermediates-dir-for,PACKAGING,recovery\_font\_files)
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_RESOURCE_DIR := $(resource\_dir)
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_IMAGE_GENERATOR_JAR := $(image\_generator\_jar)
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_ZOPFLIPNG := $(zopflipng)
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_RECOVERY_IMAGE_WIDTH := $(recovery\_image\_width)
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_RECOVERY_BACKGROUND_TEXT_LIST := \
  recovery_installing \
  recovery_installing_security \
  recovery_erasing \
  recovery_error \
  recovery_no_command
$(RECOVERY\_INSTALLING\_TEXT\_FILE): PRIVATE_RECOVERY_WIPE_DATA_TEXT_LIST := \
  recovery_cancel_wipe_data \
  recovery_factory_data_reset \
  recovery_try_again \
  recovery_wipe_data_menu_header \
  recovery_wipe_data_confirmation
$(RECOVERY\_INSTALLING\_TEXT\_FILE): .KATI_IMPLICIT_OUTPUTS := $(filter-out $(RECOVERY\_INSTALLING\_TEXT\_FILE),$(generated\_recovery\_text\_files))
$(RECOVERY\_INSTALLING\_TEXT\_FILE): $(image\_generator\_jar) $(resource\_dir) $(recovery\_noto-fonts\_dep) $(recovery\_roboto-fonts\_dep) $(zopflipng)
	# Prepares the font directory.
	@rm -rf $(PRIVATE\_RECOVERY\_FONT\_FILES\_DIR)
	@mkdir -p $(PRIVATE\_RECOVERY\_FONT\_FILES\_DIR)
	$(foreach filename,$(PRIVATE\_SOURCE\_FONTS), cp $(filename) $(PRIVATE\_RECOVERY\_FONT\_FILES\_DIR) &&) true
	@rm -rf $(dir $@)
	@mkdir -p $(dir $@)
	$(foreach text\_name,$(PRIVATE\_RECOVERY\_BACKGROUND\_TEXT\_LIST) $(PRIVATE\_RECOVERY\_WIPE\_DATA\_TEXT\_LIST), \
 $(eval output\_file := $(dir $@)/$(patsubst recovery\_%,%\_text.png,$(text\_name))) \
	  $(eval center\_alignment := $(if $(filter $(text\_name),$(PRIVATE\_RECOVERY\_BACKGROUND\_TEXT\_LIST)), --center_alignment)) \
	  java -jar $(PRIVATE\_IMAGE\_GENERATOR\_JAR) \
	    --image_width $(PRIVATE\_RECOVERY\_IMAGE\_WIDTH) \
	    --text_name $(text\_name) \
	    --font_dir $(PRIVATE\_RECOVERY\_FONT\_FILES\_DIR) \
	    --resource_dir $(PRIVATE\_RESOURCE\_DIR) \
	    --output_file $(output\_file) $(center\_alignment) && \
	  $(PRIVATE\_ZOPFLIPNG) -y --iterations=1 --filters=0 $(output\_file) $(output\_file) > /dev/null &&) true
else
RECOVERY_INSTALLING_TEXT_FILE :=
RECOVERY_INSTALLING_SECURITY_TEXT_FILE :=
RECOVERY_ERASING_TEXT_FILE :=
RECOVERY_ERROR_TEXT_FILE :=
RECOVERY_NO_COMMAND_TEXT_FILE :=
RECOVERY_CANCEL_WIPE_DATA_TEXT_FILE :=
RECOVERY_FACTORY_DATA_RESET_TEXT_FILE :=
RECOVERY_TRY_AGAIN_TEXT_FILE :=
RECOVERY_WIPE_DATA_CONFIRMATION_TEXT_FILE :=
RECOVERY_WIPE_DATA_MENU_HEADER_TEXT_FILE :=
endif # TARGET\_RECOVERY\_UI\_SCREEN\_WIDTH

主要是这段代码
ava -jar $(PRIVATE\_IMAGE\_GENERATOR\_JAR) \
	    --image_width $(PRIVATE\_RECOVERY\_IMAGE\_WIDTH) \
	    --text_name $(text\_name) \
	    --font_dir $(PRIVATE\_RECOVERY\_FONT\_FILES\_DIR) \
	    --resource_dir $(PRIVATE\_RESOURCE\_DIR) \
	    --output_file $(output\_file) $(center\_alignment) && \
	  $(PRIVATE\_ZOPFLIPNG) -y --iterations=1 --filters=0 $(output\_file) $(output\_file) > /dev/null &&) true

PRIVATE_IMAGE_GENERATOR_JAR := $(image\_generator\_jar)

image_generator_jar := $(HOST\_OUT\_JAVA\_LIBRARIES)/RecoveryImageGenerator.jar

```

在Makefile中的相关源码发现，在对于PRIVATE\_IMAGE\_GENERATOR\_JAR的image的相关配置参数都是会编译成  
 RecoveryImageGenerator.jar的jar文件供调用的  
 在 out/host 下生成的 jar 包路径 out/host/linux-x86/framework/RecoveryImageGenerator.jar


查找 RecoveryImageGenerator 模块在源码中对应的路径



```
pathmod RecoveryImageGenerator

bootable/recovery/tools/image_generator

```

所以就来看bootable/recovery/tools/image\_generator/ImageGenerator.java的源码就可以了


### 3.2 ImageGenerator.java的相关源码分析



```
public static void main(String[] args)
            throws NumberFormatException, IOException, FontFormatException,
                    LocalizedStringNotFoundException {
        Options options = createOptions();
        CommandLine cmd;
        try {
            cmd = new GnuParser().parse(options, args);
        } catch (ParseException e) {
            System.err.println(e.getMessage());
            printUsage(options);
            return;
        }

        int imageWidth = Integer.parseUnsignedInt(cmd.getOptionValue("image\_width"));

        if (cmd.hasOption("verbose")) {
            LOGGER.setLevel(Level.INFO);
        } else {
            LOGGER.setLevel(Level.WARNING);
        }

        ImageGenerator imageGenerator =
                new ImageGenerator(
                        imageWidth,
                        cmd.getOptionValue("text\_name"),
                        DEFAULT_FONT_SIZE,
                        cmd.getOptionValue("font\_dir"),
                        cmd.hasOption("center\_alignment"));

        Set<String> localesSet = null;
        if (cmd.hasOption("locales")) {
            String[] localesList = cmd.getOptionValue("locales").split(",");
            localesSet = new HashSet<>(Arrays.asList(localesList));
            // Ensures that we have the default locale, all english translations are identical.
            localesSet.add("en-rAU");
        }
        Map<Locale, String> localizedStringMap =
                imageGenerator.readLocalizedStringFromXmls(cmd.getOptionValue("resource\_dir"),
                        localesSet);
        imageGenerator.generateImage(localizedStringMap, cmd.getOptionValue("output\_file"));
    }

```

在构造ImageGenerator中DEFAULT\_FONT\_SIZE 就是默认字体的大小  
 private static final float DEFAULT\_FONT\_SIZE =40;  
 在recovery页面的字体大小都是40px,所以想修改字体大小 就修改这里就可以了  
 默认是40px的  
 所以 修改为60 编译查看果然大小已经改变了





