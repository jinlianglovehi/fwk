



## 1.前言


在10.0的系统rom产品定制化开发中，在对Launcher3的folder文件夹功能定制中，要求folder文件夹跨行显示，就是 2x2布局显示，默认的都是占1格的，现在要求占4格显示，系统默认是不支持显示4格的，所以接下来需要分析相关的 功能，然后来实现这个功能


![](https://img-blog.csdnimg.cn/direct/158dde39fe974b9c883a43bf0d253c90.png)


## 2.Launcher3定制folder文件夹2x2布局之四foldericon的2x2的布局后拖拽其他app进不去这个文件夹功能实现的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\Workspace.java
```

## 3.Launcher3定制folder文件夹2x2布局之四foldericon的2x2的布局后拖拽其他app进不去这个文件夹功能实现的核心功能分析和实现


在launcher3中初始化数据的时候，初始化创建launcher.db数据库，数据库里创建了两张表，分别是favorites，workspace 在数据库表中，\_id:用于标识区分各个应用图标，是表favorites的主键，当添加数据时通过generateNewId使\_id值增加。 title:在WorkSpace(HotSeat中一般会隐藏掉)中展示的应用快捷图标的标题。 intent:当点击桌面图标时的负责启动应用的intent，它通过Intent.toUri()转换为String存储，在使用时通过Intent.parseUri()转换为intent。 container:指的是当前数据所在的容器类型，在Launcher中有两种container类型：1.CONTAINER\_DESKTOP(-100)， 2.CONTAINER\_HOTSEAT(-101)。 screen:用于标识当前数据所在的页。当container为-100时，则screen的值表现为我们桌面的页数的值，当container为-101即当前快捷图标处于HotSeat时，则指快捷图标所在的第X个位置。 cellX:当前快捷图标所在页(CellLayout)的X位置，即快捷图标在当前页横向的第X个位置。 cellY:当前快捷图标所在页(CellLayout)的Y位置，即快捷图标在当前页纵向的第Y个位置。 spanX:当前快捷图标的在所在页(CellLayout)的横向范围信息，如果当前图标为application、shortcut、folder则为1，表示图标横向上占据一个cell的位置范围。如果当前图标为Widget，则横向占据范围可能为多个cell。 spanY:当前快捷图标的在所在页(CellLayout)的纵向范围信息，如果当前图标为application、shortcut、folder则为1，表示图标纵向上占据一个cell的位置范围。如果当前图标为Widget，则纵向占据范围可能为多个cell。 在Launcher3 中,工作区(Workspace)是指桌面上显示应用程序和小部件的区域 Workspace.java: 抽象的桌面。由N个cellLayout组成,从cellLayout更高一级的层面上对事件的处理。


## 3.1 Workspace.java中相关拖拽的功能分析


Launcher3定制folder文件夹2x2布局之四foldericon的2x2的布局后拖拽其他app进不去这个文件夹功能实现的核心功能中，通过上述的分析得知，在 Workspace.java中的相关源码中，关于长按图标拖拽的时候，具体在workspace中会执行相关的拖拽动作，接下来分析下 相关的拖拽功能实现



```
public void startDrag(CellLayout.CellInfo cellInfo, DragOptions options) {
        View child = cellInfo.cell;

        mDragInfo = cellInfo;
        child.setVisibility(INVISIBLE);

        if (options.isAccessibleDrag) {
            mDragController.addDragListener(
                    new AccessibleDragListenerAdapter(this, WorkspaceAccessibilityHelper::new) {
                        @Override
                        protected void enableAccessibleDrag(boolean enable) {
                            super.enableAccessibleDrag(enable);
                            setEnableForLayout(mLauncher.getHotseat(), enable);
                        }
                    });
        }

        beginDragShared(child, this, options);
    }

    public void beginDragShared(View child, DragSource source, DragOptions options) {
        Object dragObject = child.getTag();
        if (!(dragObject instanceof ItemInfo)) {
            String msg = "Drag started with a view that has no tag set. This "
                    + "will cause a crash (issue 11627249) down the line. "
                    + "View: " + child + "  tag: " + child.getTag();
            throw new IllegalStateException(msg);
        }
        beginDragShared(child, null, source, (ItemInfo) dragObject,
                new DragPreviewProvider(child), options);
    }
```

在实现Launcher3定制folder文件夹2x2布局之四foldericon的2x2的布局后拖拽其他app进不去这个文件夹功能实现的核心功能中，通过上述的分析得知，在 Workspace.java中的相关源码中，在长按拖拽的流程中，会在startDrag(CellLayout.CellInfo cellInfo, DragOptions options) 中开始执行 拖拽流程，然后在beginDragShared(View child, DragSource source, DragOptions options) 中继续调用执行拖拽功能， 然后在beginDragShared(View child, DraggableView draggableView, DragSource source, ItemInfo dragObject, DragPreviewProvider previewProvider, DragOptions dragOptions) 然后在不停的拖拽过程中继续调用onDragOver(DragObject d)来继续拖拽过程中的相关功能



```
    public void onDragOver(DragObject d) {
        // Skip drag over events while we are dragging over side pages
        if (!transitionStateShouldAllowDrop()) return;

        ItemInfo item = d.dragInfo;
        if (item == null) {
            if (FeatureFlags.IS_STUDIO_BUILD) {
                throw new NullPointerException("DragObject has null info");
            }
            return;
        }

        // Ensure that we have proper spans for the item that we are dropping
        if (item.spanX < 0 || item.spanY < 0) throw new RuntimeException("Improper spans found");
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);

        final View child = (mDragInfo == null) ? null : mDragInfo.cell;
        if (setDropLayoutForDragObject(d, mDragViewVisualCenter[0], mDragViewVisualCenter[1])) {
            if (mLauncher.isHotseatLayout(mDragTargetLayout)) {
                mSpringLoadedDragController.cancel();
            } else {
                mSpringLoadedDragController.setAlarm(mDragTargetLayout);
            }
        }

        // Handle the drag over
        if (mDragTargetLayout != null) {
            // We want the point to be mapped to the dragTarget.
            mapPointFromDropLayout(mDragTargetLayout, mDragViewVisualCenter);

            int minSpanX = item.spanX;
            int minSpanY = item.spanY;
            if (item.minSpanX > 0 && item.minSpanY > 0) {
                minSpanX = item.minSpanX;
                minSpanY = item.minSpanY;
            }

            mTargetCell = findNearestArea((int) mDragViewVisualCenter[0],
                    (int) mDragViewVisualCenter[1], minSpanX, minSpanY,
                    mDragTargetLayout, mTargetCell);
            int reorderX = mTargetCell[0];
            int reorderY = mTargetCell[1];

            setCurrentDropOverCell(mTargetCell[0], mTargetCell[1]);

            float targetCellDistance = mDragTargetLayout.getDistanceFromCell(
                    mDragViewVisualCenter[0], mDragViewVisualCenter[1], mTargetCell);

            manageFolderFeedback(targetCellDistance, d);

    .....
        }
    }
    private void manageFolderFeedback(float distance, DragObject dragObject) {
//add core start
        /*if (distance > mMaxDistanceForFolderCreation) {
            if ((mDragMode == DRAG_MODE_ADD_TO_FOLDER
                    || mDragMode == DRAG_MODE_CREATE_FOLDER)) {
                setDragMode(DRAG_MODE_NONE);
            }
            return;
        }*/
//add core end
....
        boolean willAddToFolder = willAddToExistingUserFolder(info, dragOverView);
        if (willAddToFolder && mDragMode == DRAG_MODE_NONE) {
            mDragOverFolderIcon = ((FolderIcon) dragOverView);
            mDragOverFolderIcon.onDragEnter(info);
            if (mDragTargetLayout != null) {
                mDragTargetLayout.clearDragOutlines();
            }
            setDragMode(DRAG_MODE_ADD_TO_FOLDER);

            if (dragObject.stateAnnouncer != null) {
                dragObject.stateAnnouncer.announce(WorkspaceAccessibilityHelper
                        .getDescriptionForDropOver(dragOverView, getContext()));
            }
            return;
        }

        if (mDragMode == DRAG_MODE_ADD_TO_FOLDER && !willAddToFolder) {
            setDragMode(DRAG_MODE_NONE);
        }
        if (mDragMode == DRAG_MODE_CREATE_FOLDER && !userFolderPending) {
            setDragMode(DRAG_MODE_NONE);
        }
    }

```

在实现Launcher3定制folder文件夹2x2布局之四foldericon的2x2的布局后拖拽其他app进不去这个文件夹功能实现的核心功能中，通过上述的分析得知，在 Workspace.java中的相关源码中，在长按拖拽的流程中，在onDragOver(DragObject d) 中会调用manageFolderFeedback(float distance, DragObject dragObject) 不断计算当前距离，然后判断当前的拖拽模式，所以当distance > mMaxDistanceForFolderCreation时会在2x2的布局中，会返回所以当前 模式就不是拖拽进文件夹模式，所以这段代码需要注释掉，



```
@Override
    public void onDrop(final DragObject d, DragOptions options) {
        mDragViewVisualCenter = d.getVisualCenter(mDragViewVisualCenter);
        CellLayout dropTargetLayout = mDropToLayout;

        // We want the point to be mapped to the dragTarget.
        if (dropTargetLayout != null) {
            mapPointFromDropLayout(dropTargetLayout, mDragViewVisualCenter);
        }

        boolean droppedOnOriginalCell = false;

        int snapScreen = -1;
        boolean resizeOnDrop = false;
        if (d.dragSource != this || mDragInfo == null) {
            final int[] touchXY = new int[] { (int) mDragViewVisualCenter[0],
                    (int) mDragViewVisualCenter[1] };
            onDropExternal(touchXY, dropTargetLayout, d);
        } else {
            final View cell = mDragInfo.cell;
            boolean droppedOnOriginalCellDuringTransition = false;
            Runnable onCompleteRunnable = null;

            if (dropTargetLayout != null && !d.cancelled) {
                // Move internally
                boolean hasMovedLayouts = (getParentCellLayoutForView(cell) != dropTargetLayout);
                boolean hasMovedIntoHotseat = mLauncher.isHotseatLayout(dropTargetLayout);
                int container = hasMovedIntoHotseat ?
                        LauncherSettings.Favorites.CONTAINER_HOTSEAT :
                        LauncherSettings.Favorites.CONTAINER_DESKTOP;
                int screenId = (mTargetCell[0] < 0) ?
                        mDragInfo.screenId : getIdForScreen(dropTargetLayout);
                int spanX = mDragInfo != null ? mDragInfo.spanX : 1;
                int spanY = mDragInfo != null ? mDragInfo.spanY : 1;
                // First we find the cell nearest to point at which the item is
                // dropped, without any consideration to whether there is an item there.

                mTargetCell = findNearestArea((int) mDragViewVisualCenter[0], (int)
                        mDragViewVisualCenter[1], spanX, spanY, dropTargetLayout, mTargetCell);
                float distance = dropTargetLayout.getDistanceFromCell(mDragViewVisualCenter[0],
                        mDragViewVisualCenter[1], mTargetCell);

                // If the item being dropped is a shortcut and the nearest drop
                // cell also contains a shortcut, then create a folder with the two shortcuts.
                if (createUserFolderIfNecessary(cell, container,
                        dropTargetLayout, mTargetCell, distance, false, d)
                        || addToExistingFolderIfNecessary(cell, dropTargetLayout, mTargetCell,
                                distance, d, false)) {
                    mLauncher.getStateManager().goToState(NORMAL, SPRING_LOADED_EXIT_DELAY);
                    return;
                }

    boolean addToExistingFolderIfNecessary(View newView, CellLayout target, int[] targetCell,
            float distance, DragObject d, boolean external) {    
//        if (distance > mMaxDistanceForFolderCreation) return false;
        View dropOverView = target.getChildAt(targetCell[0], targetCell[1]);
        if (!mAddToExistingFolderOnDrop) return false;
        mAddToExistingFolderOnDrop = false;
        if (dropOverView instanceof FolderIcon) {
            FolderIcon fi = (FolderIcon) dropOverView;
            if (fi.acceptDrop(d.dragInfo)) {
                mStatsLogManager.logger().withItemInfo(fi.mInfo).withInstanceId(d.logInstanceId)
                        .log(LauncherEvent.LAUNCHER_ITEM_DROP_COMPLETED);
                fi.onDrop(d, false /* itemReturnedOnFailedDrop */);

                // if the drag started here, we need to remove it from the workspace
                if (!external) {
                    getParentCellLayoutForView(mDragInfo.cell).removeView(mDragInfo.cell);
                }
                return true;
            }
        }
        return false;
    }



```

在实现Launcher3定制folder文件夹2x2布局之四foldericon的2x2的布局后拖拽其他app进不去这个文件夹功能实现的核心功能中，通过上述的分析得知，在  
 Workspace.java中的相关源码中，在长按拖拽的流程中，在onDrop(final DragObject d, DragOptions options)手势松开判断是否进入  
 文件夹的过程中，同样需要注释掉相关的distance > mMaxDistanceForFolderCreation这个判断条件，当2x2的布局中，会拖拽的距离大，导致满足条件  
 就会导致进不去文件夹中，所以同样需要注释掉//        if (distance > mMaxDistanceForFolderCreation) return false;这段代码  
 这样就会可以拖拽app进入文件夹里面了，这样就实现了功能的开发



