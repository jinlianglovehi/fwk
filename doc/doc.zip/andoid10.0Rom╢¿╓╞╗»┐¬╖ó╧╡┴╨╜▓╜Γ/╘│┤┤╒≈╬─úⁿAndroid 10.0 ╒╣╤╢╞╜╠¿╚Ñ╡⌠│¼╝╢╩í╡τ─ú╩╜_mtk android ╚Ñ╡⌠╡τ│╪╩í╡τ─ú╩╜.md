



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.核心代码分析](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 SprdBatterySaverSettings中省电模式选择中去掉省电模式](#%C2%A03.1%20SprdBatterySaverSettings%E4%B8%AD%E7%9C%81%E7%94%B5%E6%A8%A1%E5%BC%8F%E9%80%89%E6%8B%A9%E4%B8%AD%E5%8E%BB%E6%8E%89%E7%9C%81%E7%94%B5%E6%A8%A1%E5%BC%8F)


[3.2 SprdSchedulePowerFragment中 关于定时省电 中的 省电模式中 超级省电模式的处理](#3.2%20SprdSchedulePowerFragment%E4%B8%AD%20%E5%85%B3%E4%BA%8E%E5%AE%9A%E6%97%B6%E7%9C%81%E7%94%B5%20%E4%B8%AD%E7%9A%84%20%E7%9C%81%E7%94%B5%E6%A8%A1%E5%BC%8F%E4%B8%AD%20%E8%B6%85%E7%BA%A7%E7%9C%81%E7%94%B5%E6%A8%A1%E5%BC%8F%E7%9A%84%E5%A4%84%E7%90%86)




---



## 1.概述


  在10.0展讯开发中，展讯自带的有超级省电模式，在电量低于15%弹出省电模式的通知，这时候如果选择超级省电模式会对产品其他功能有影响，所以根据功能需求去掉省电模式的功能


## 2.核心代码



```
vendor/sprd/platform/packages/apps/Settings/src/com/android/settings/fuelgauge/SprdSchedulePowerFragment.java
vendor/sprd/platform/packages/apps/Settings/src/com/android/settings/fuelgauge/SprdBatterySaverSettings.java
frameworks/base/services/core/java/com/android/server/power/sprdpower/PowerController.java
vendor/sprd/platform/packages/apps/Settings/res/xml/sprd_battery_saver_settings.xml
vendor/sprd/platform/packages/apps/Settings/res/xml/schedule_power_saver.xml
```

## 3.核心代码分析


###  3.1 SprdBatterySaverSettings中省电模式选择中去掉省电模式



```
     /**
 * Fragment used for showing smart power saving mode, lowe power mode and super power saving mode.
 */
public class SprdBatterySaverSettings extends SettingsPreferenceFragment {

    private static final String TAG = "BatterySaverSettings";

    private static final String KEY_SMART_POWER_SAVING = "smart_power_saving_mode";
    private static final String KEY_SUPER_POWER_SAVING = "super_power_saving_mode";
    private static final String KEY_LOW_POWER_SAVING = "low_power_mode";
    private static final boolean UlTRA_SAVING_ENABLED = SystemProperties.getBoolean(
            "ro.sys.pwctl.ultrasaving", false);

    public static final int MODE_PERFORMANCE = 0;
    public static final int MODE_SMART = 1;
    public static final int MODE_POWERSAVING = 2;
    public static final int MODE_LOWPOWER = 3;
    public static final int MODE_ULTRASAVING = 4;

    private Context mContext;
    private IPowerManagerEx mPowerManagerEx;
    private String mCurrentSelectedKey;
    private String mLastedSelectedKey;
    private int mMode;
    private boolean mIsChargeExitLow;
    private PreferenceScreen mPreferenceScreen;
    private RadioButtonPreference mSuperPowerModePreference;
    private RadioButtonPreference mLowPowerModePreference;

    @Override
    public int getMetricsCategory() {
        return MetricsEvent.FUELGAUGE_BATTERY_SAVER;
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        addPreferencesFromResource(R.xml.sprd_battery_saver_settings);
        mContext = getActivity();
        mPreferenceScreen = getPreferenceScreen();

        mSuperPowerModePreference = (RadioButtonPreference) findPreference(
                KEY_SUPER_POWER_SAVING);
        if (mSuperPowerModePreference != null && !UlTRA_SAVING_ENABLED) {
            mPreferenceScreen.removePreference(mSuperPowerModePreference);
        }
        mLowPowerModePreference = (RadioButtonPreference) findPreference(
                KEY_LOW_POWER_SAVING);
        mPowerManagerEx = IPowerManagerEx.Stub.asInterface(ServiceManager.getService("power_ex"));
    }

    @Override
    public void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(PowerManagerEx.ACTION_POWEREX_SAVE_MODE_CHANGED);
        mContext.registerReceiver(mIntentReceiver, filter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshUI();
        try {
            mMode = mPowerManagerEx.getPowerSaveMode();
        } catch (RemoteException e) {
            // Not much we can do here
        }
        mCurrentSelectedKey = powerModeToKey(mMode);
        Log.d(TAG, " mCurrent = " + mCurrentSelectedKey + " mLast = "
                + mLastedSelectedKey + " mMode = " + mMode);
        RadioButtonPreference pref = (RadioButtonPreference) findPreference(
                mCurrentSelectedKey);
        if (pref != null) {
            pref.setChecked(true);
            Log.d(TAG,"pref key = " + pref.getKey());
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        mContext.unregisterReceiver(mIntentReceiver);
    }

    private void refreshUI() {
        int count = mPreferenceScreen.getPreferenceCount();
        RadioButtonPreference pref;
        for (int i = 0; i < count; i++) {
            pref = (RadioButtonPreference) mPreferenceScreen.getPreference(i);
            if (pref != null) {
                pref.setChecked(false);
                Log.d(TAG, "pref key = " + pref.getKey());
            }
        }
    }

    private String powerModeToKey(int mode) {
        String key;
        switch (mode) {
            case MODE_SMART:
                key = KEY_SMART_POWER_SAVING;
                break;
            case MODE_ULTRASAVING:
                key = KEY_SUPER_POWER_SAVING;
                break;
            case MODE_LOWPOWER:
                key = KEY_LOW_POWER_SAVING;
                break;
             default:
                key = KEY_SMART_POWER_SAVING;
        }
        return key;
    }

    private void updateSelectedState(String key) {
        mLastedSelectedKey = mCurrentSelectedKey;
        RadioButtonPreference pref = (RadioButtonPreference) findPreference(
                mLastedSelectedKey);
        if (pref != null) {
            pref.setChecked(false);
            Log.d(TAG,"updateSelectedState last pref key = " + pref.getKey());
        }
        mCurrentSelectedKey = key;
        pref = (RadioButtonPreference) findPreference(mCurrentSelectedKey);
        if (pref != null) {
            pref.setChecked(true);
            Log.d(TAG,"updateSelectedState current pref key = " + pref.getKey());
        }
    }

    private void setPowerSavingMode(String key) {
        int mode;
        switch (key) {
            case KEY_SMART_POWER_SAVING:
                mode = MODE_SMART;
                break;
            case KEY_SUPER_POWER_SAVING:
                mode = MODE_ULTRASAVING;
                break;
            case KEY_LOW_POWER_SAVING:
                mode = MODE_LOWPOWER;
                break;
            default:
                mode = MODE_POWERSAVING;
        }
        Log.d(TAG, "setPowerSavingMode: " + key + " mode:" + mode);
        try {
            mPowerManagerEx.setPowerSaveMode(mode);
        } catch (RemoteException e) {
            // Not much we can do here
        }
    }

     @Override
    public boolean onPreferenceTreeClick(Preference pref) {
        final String key = pref.getKey();
        //customized mode not support currently.
        //if (KEY_CUSTOMIZED_MODE.equals(key)) return true;
        if (pref instanceof RadioButtonPreference) {
            final RadioButtonPreference radioPref = (RadioButtonPreference) pref;
            Log.d(TAG ,"onPreferenceTreeClick pref = " + pref + "checked:"+ radioPref.isChecked());
            if (radioPref.isChecked()) {
                return true;
            }
            /*bug 911188 : Select super power saver or smart power saver and press back, choose wrong mode@{*/
            setPowerSavingMode(key);
            /*@}*/
            return true;
        }
        return false;
     }

    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_BATTERY_CHANGED)) {
                //low power mode should be disable when not charge
                int plugged = intent.getIntExtra("plugged", 0);
                try {
                    mIsChargeExitLow = mPowerManagerEx.getSmartSavingModeWhenCharging();
                } catch (RemoteException e) {
                    // Not much we can do here
                }
                Log.d(TAG,"plugged = " + plugged + " mIsChargeExitLow= " + mIsChargeExitLow);
                if (mIsChargeExitLow && plugged != 0) {
                    mLowPowerModePreference.setEnabled(false);
                    mSuperPowerModePreference.setEnabled(false);
                } else {
                    mLowPowerModePreference.setEnabled(true);
                    mSuperPowerModePreference.setEnabled(true);
                }
            } else if (intent.getAction().equals(
                PowerManagerEx.ACTION_POWEREX_SAVE_MODE_CHANGED)) {
                mMode = intent.getIntExtra(PowerManagerEx.EXTRA_POWEREX_SAVE_MODE,
                        MODE_POWERSAVING);
                Log.d(TAG, " mMode = " + mMode);
                String key = powerModeToKey(mMode);
                RadioButtonPreference pref = (RadioButtonPreference) findPreference(key);
                if (!pref.isChecked()) {
                    updateSelectedState(key);
                }
            }
        }
    };
}



    /**
     * set the current power save mode
     * @param mode link {@PowerManagerEx#MODE_LOWPOWER, #MODE_SMART, #MODE_ULTRASAVING}
     * @return Returns true for success, false for fail.
     */
    public boolean setPowerSaveMode(int mode) {
        return mPowerControllerInternal.setPowerSaveMode(mode);
    }




 


```

在 onPreferenceTreeClick(Preference pref) 中通过获取选择省电模式的key 来同时而通过调用setPowerSavingMode(key)设置省电模式  
 最终调用 PowerManagerExService.setPowerSaveMode(mode);来设置当前省电模式


在PowerController.java 中的 setPowerSaveMode(int mode) 设置省电模式



```
     
        //called by setting from powermanagerex
        boolean setPowerSaveMode(int mode) {
            if (DEBUG) Slog.d(TAG, "setPowerSaveMode(" + mode + "), user mode: " + mModeConfigArray[MODECONFIG_USER].mMode);

            if ((mode < PowerManagerEx.MODE_PERFORMANCE) || (mode > PowerManagerEx.MODE_MAX)) {
                Slog.e(TAG, "invalid mode: " + mode);
                return false;
            }

            if ((mode == PowerManagerEx.MODE_ULTRASAVING) && !mUltraSavingEnabled) {
                Slog.e(TAG, "ULTRASAVING mode is disabled");
                return false;
            }
            msgHandler.removeMessages(MSG_SET_POWERSAVE_MODE);
            return msgHandler.sendMessage(msgHandler.obtainMessage(MSG_SET_POWERSAVE_MODE, mode, 0));
        }

            case MSG_SET_POWERSAVE_MODE:
                setPowerSaveModeInternal(msg.arg1);
                break;

    //called by setting from powermanagerex
    //update mModeConfigArray[MODECONFIG_USER].mMode
    private void setPowerSaveModeInternal(int mode) {
        if (DEBUG) Slog.d(TAG, "setPowerSaveModeInternal() E, new mode: " + mode + ", old mode: " + mPowerSaveMode + ", [" + ModeConfig2Str(mModeConfigIndex) + "]");
        // exit force low power
        if (mForcePowerSave) {
            if (mPowerSaveMode != mode) {
                mForcePowerSave = false;

                mModeConfigArray[MODECONFIG_USER].mMode = mode;
                updatePowerSaveMode();
                msgHandler.removeMessages(MSG_SET_POWERSAVE_MODE);
                msgHandler.sendMessage(msgHandler.obtainMessage(MSG_SET_POWERSAVE_MODE, mode, 0));
                return;
            }
        }

        if (mModeConfigArray[mModeConfigIndex].mMode != mode) {
            if (showAlert(mode)) return;
        }

        mModeConfigArray[MODECONFIG_USER].mMode = mode;
        updatePowerSaveMode();
    }

```

在可以在mModeConfigArray[MODECONFIG\_USER].mMode 就是省电模式的类型  
 所以可以修改为0 为智能省电模式


最终修改如下:



```

             case MSG_SET_POWERSAVE_MODE:
-                setPowerSaveModeInternal(msg.arg1);
+                setPowerSaveModeInternal(0);
                 break;

/**
     * Show power switch or ultra powersaving alert dialog
     *
     * @return Returns whether need to show alert
     */
    private boolean showAlert(int mode) {
        String summaryStr = null;
        String modeStr = null;
        String titleStr = null;
        int layoutId = 0;

        boolean modeSwitch = false;
        boolean enterUltrasaving = false;
        boolean exitUltrasaving = false;
        int themeResId = AlertDialog.THEME_DEVICE_DEFAULT_LIGHT;

        mModeSwitch = false;
        // if in auto lowpower or schedule mode, should show dialog to user
        if ((mModeConfigIndex != MODECONFIG_USER)
                && (mModeConfigArray[mModeConfigIndex].mMode != mode)) {
            mModeSwitch = modeSwitch = true;
        }
        if (mode == PowerManagerEx.MODE_ULTRASAVING) {
            enterUltrasaving = true;
        }
        if (mModeConfigArray[mModeConfigIndex].mMode == PowerManagerEx.MODE_ULTRASAVING) {
            exitUltrasaving = true;
        }

        if (DEBUG) Slog.d(TAG, "showAlert(), modeSwitch: " + modeSwitch + ", enterUltrasaving: " + enterUltrasaving + ", exitUltrasaving: " + exitUltrasaving);

        if (!modeSwitch && !enterUltrasaving && !exitUltrasaving)
            return false;

        if ((mUiModeManager.getNightMode() == UiModeManager.MODE_NIGHT_YES) || exitUltrasaving
            || (mModeConfigArray[mModeConfigIndex].mMode == PowerManagerEx.MODE_LOWPOWER)) {

            if (DEBUG) Slog.d(TAG, "showAlert(), this is dark theme: uimode is " + mUiModeManager.getNightMode()
                                + "power mode is " + mModeConfigArray[mModeConfigIndex].mMode);

            themeResId = AlertDialog.THEME_DEVICE_DEFAULT_DARK;
        } else {
            if (DEBUG) Slog.d(TAG, "showAlert(), this is light theme");
        }

        // decide title
        if (modeSwitch) {
            titleStr = mContext.getString(R.string.pwctl_switchmode_title);
        }
        if (enterUltrasaving || exitUltrasaving) {
            titleStr = mContext.getString(R.string.pwctl_ultrasaving_title);
        }

        // decide layout
        if (enterUltrasaving) {
            layoutId = R.layout.layout_pwctl_dialog;
        }
        // decide summary
        if (modeSwitch) {
            if (mModeConfigIndex == MODECONFIG_AUTOLOWPOWER)
                modeStr = mContext.getString(R.string.pwctl_autolowpower_saving);
            else
                modeStr = mContext.getString(R.string.pwctl_schedule_power_saving);

            if (enterUltrasaving) {
                summaryStr = mContext.getString(R.string.pwctl_switchmode_enter_ultrasaving_summary, modeStr);
            } else if (exitUltrasaving) {
                summaryStr = mContext.getString(R.string.pwctl_switchmode_exit_ultrasaving_summary, modeStr);
            } else {
                summaryStr = mContext.getString(R.string.pwctl_switchmode_summary, modeStr);
            }
        } else {
            if (enterUltrasaving) {
                summaryStr = mContext.getString(R.string.pwctl_enter_ultrasaving_summary);
            } else if (exitUltrasaving) {
                summaryStr = mContext.getString(R.string.pwctl_exit_ultrasaving_summary);
            }
        }

        if (summaryStr != null) {
            // for bug#771563 to exit when receive home key
            final CloseDialogReceiver closer = new CloseDialogReceiver(mContext);
            if (sConfirmDialog != null) {
                sConfirmDialog.dismiss();
            }
            if (layoutId != 0) {
            // with "dont remimd" checkbox
            //Note: Bug 805226 Dialog interval narrow -->BEG
           
                sConfirmDialog = new AlertDialog.Builder(mContext)
                    .setView(layoutId)
                    .setTitle(titleStr)
                    .setMessage(summaryStr)
                    .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // update settings focus
                            // postModeChangeBroadcast(mPowerSaveMode, mPrePowerSaveMode); // modify for bug#756870
                        }
                    })
                    .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        CheckBox ckView = (CheckBox)sConfirmDialog.findViewById(R.id.ck_dontremind);
                        if (ckView != null) {
                            mDontRemind = ckView.isChecked();
                            if (mDontRemind) writeConfig();
                        }
                        //disable current auto-mode, update current powersaving mode
                        if ((mModeConfigIndex != MODECONFIG_USER)
                                && (mModeConfigArray[mModeConfigIndex].mMode != mode)) {
                            mModeConfigArray[mModeConfigIndex].mEnable = false;
                        }
                        mModeConfigArray[MODECONFIG_USER].mMode = mode;
                        updatePowerSaveMode();
                    }})
                    .create();
                    
                UltraSavingAlertDialog.Builder builder = new UltraSavingAlertDialog.Builder(mContext, themeResId);
                sConfirmDialog = builder.setTitle(titleStr)
                        .setMessage(summaryStr)
                        .setPositiveButton(R.string.yes, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //disable current auto-mode, update current powersaving mode
								if ((mModeConfigIndex != MODECONFIG_USER)
									&& (mModeConfigArray[mModeConfigIndex].mMode != mode)) {
									mModeConfigArray[mModeConfigIndex].mEnable = false;
								}
                                                                                                                -              mModeConfigArray[MODECONFIG_USER].mMode = mode;
							+	mModeConfigArray[MODECONFIG_USER].mMode = 0;
								updatePowerSaveMode();
								builder.dialog.dismiss();
								sConfirmDialog = null;
                            }
                        })
                        .setNegativeButton(R.string.no, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // update settings focus
                                // postModeChangeBroadcast(mPowerSaveMode, mPrePowerSaveMode); // modify for bug#756870
                                builder.dialog.dismiss();
                                sConfirmDialog = null;
                            }
                        }).create(themeResId);
            // Note: Bug 805226 Dialog interval narrow <--END
            } else {
            // without "dont remimd" checkbox
                sConfirmDialog = new AlertDialog.Builder(mContext, themeResId)
                    .setTitle(titleStr)
                    .setMessage(summaryStr)
                    .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // update settings focus
                            // postModeChangeBroadcast(mPowerSaveMode, mPrePowerSaveMode); // modify for bug#756870
                            sConfirmDialog = null;
                        }
                    })
                    .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //disable current auto-mode, update current powersaving mode
                        if ((mModeConfigIndex != MODECONFIG_USER)
                                && (mModeConfigArray[mModeConfigIndex].mMode != mode)) {
                            mModeConfigArray[mModeConfigIndex].mEnable = false;
                        }
                        -              mModeConfigArray[MODECONFIG_USER].mMode = mode;
	        +	mModeConfigArray[MODECONFIG_USER].mMode = 0;
                        updatePowerSaveMode();
                        sConfirmDialog = null;
                    }})
                    .create();
            }

            closer.dialog = sConfirmDialog;
            sConfirmDialog.setOnDismissListener(closer);

            //SPRD: fixBug 802114: dialog can not be displayed.
            sConfirmDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG);
            //fix bug1015968: Hide Super Power Save Confirmation Dialog.
            sConfirmDialog.setCancelable(true);
            sConfirmDialog.setCanceledOnTouchOutside(true);
            sConfirmDialog.show();
            closer.registerBroadcastReceiver();
        }
        return true;
    }
```

### 3.2 SprdSchedulePowerFragment中 关于定时省电 中的 省电模式中 超级省电模式的处理



```
 public class SprdSchedulePowerFragment extends SettingsPreferenceFragment
        implements Preference.OnPreferenceChangeListener,TimePickerDialog.OnTimeSetListener {

    private static final String TAG = "SchedulePowerMode";

    private static final String KEY_SCHEDULE_SAVER = "schedule_mode";
    private static final String KEY_TURN_ON = "schedule_turn_on_time";
    private static final String KEY_TURN_OFF = "schedule_turn_off_time";
    private static final String KEY_POWER_MODE = "schedule_power_mode";
    private static final String M12 = "h:mm aa";
    private static final String M24 = "kk:mm";
    private static final int START_TIME_TYPE = 1;
    private static final int END_TIME_TYPE = 2;
    private static final int DIALOG_START_TIME = 0;
    private static final int DIALOG_END_TIME = 1;
    private static final boolean UlTRA_SAVING_ENABLED = SystemProperties.getBoolean(
            "ro.sys.pwctl.ultrasaving", false);

    private Context mContext;
    private IPowerManagerEx mPowerManagerEx;
    private RestrictedSwitchPreference mSchedulePowerSaverPre;
    private Preference mScheduleStartPre;
    private Preference mScheduleEndPre;
    private ListPreference mSchedulePowerModePre;
    private boolean mIsScheduleSaverEnable;
    private boolean mplugged;
    private boolean mIsChargeExitLow;
    private int mScheduleStartTime;
    private int mScheduleEndTime;
    private int mScheduleMode;
    private int mStartHour;
    private int mStartMinutes;
    private int mEndHour;
    private int mEndMinutes;
    private int mTimeType;

    @Override
    public int getMetricsCategory() {
        return MetricsEvent.FUELGAUGE_BATTERY_SAVER;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.schedule_power_saver);

        mContext = getActivity();
        mSchedulePowerSaverPre = (RestrictedSwitchPreference) findPreference(KEY_SCHEDULE_SAVER);
        mSchedulePowerSaverPre.setOnPreferenceChangeListener(this);

        mScheduleStartPre = (Preference) findPreference(KEY_TURN_ON);
        mScheduleStartPre.setOnPreferenceChangeListener(this);

        mScheduleEndPre = (Preference) findPreference(KEY_TURN_OFF);
        mScheduleEndPre.setOnPreferenceChangeListener(this);

        mSchedulePowerModePre = (ListPreference) findPreference(KEY_POWER_MODE);
        Log.d(TAG, "UlTRA_SAVING_ENABLED = " + UlTRA_SAVING_ENABLED);
        if (UlTRA_SAVING_ENABLED) {
            mSchedulePowerModePre.setEntries(R.array.schedule_mode_switch_entries);
            mSchedulePowerModePre.setEntryValues(R.array.schedule_mode_switch_entries_values);
        } else {
            mSchedulePowerModePre.setEntries(R.array.schedule_mode_switch_entries_without_ultrasaving);
            mSchedulePowerModePre.setEntryValues(R.array.schedule_mode_switch_entries_values_without_ultrasaving);
        }
        mSchedulePowerModePre.setOnPreferenceChangeListener(this);

        mPowerManagerEx = IPowerManagerEx.Stub.asInterface(ServiceManager.getService("power_ex"));

        mContext = getActivity();
    }

    @Override
    public void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(PowerManagerEx.ACTION_POWEREX_SAVE_MODE_CHANGED);
        mContext.registerReceiver(mIntentReceiver, filter);
    }

    @Override
    public void onResume() {
        super.onResume();
        updatePrefState(null);
        updatePrefValue();
    }

    @Override
    public void onStop() {
        super.onStop();
        mContext.unregisterReceiver(mIntentReceiver);
    }

    @Override
    public boolean onPreferenceTreeClick(Preference pref) {
        Log.d(TAG, "onPreferenceTreeClick(): key-" + pref.getKey() );
        if (pref == mScheduleStartPre) {
            showTimePicker(START_TIME_TYPE);
        } else if (pref == mScheduleEndPre) {
            showTimePicker(END_TIME_TYPE);
        }
        return true;
    }

    @Override
    public int getDialogMetricsCategory(int dialogId) {
        return MetricsEvent.DIALOG_TIME_PICKER;
    }

    @Override
    public Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_START_TIME:
                mTimeType = START_TIME_TYPE;
                return new TimePickerDialog(mContext, this, mStartHour, mStartMinutes,
                    DateFormat.is24HourFormat(mContext));
            case DIALOG_END_TIME:
                mTimeType = END_TIME_TYPE;
                return new TimePickerDialog(mContext, this, mEndHour, mEndMinutes,
                    DateFormat.is24HourFormat(mContext));
            default:
                throw new IllegalArgumentException();
        }
    }

    public void showTimePicker(int type) {
        switch (type) {
            case START_TIME_TYPE:
                removeDialog(DIALOG_START_TIME);
                showDialog(DIALOG_START_TIME);
                return;
            case END_TIME_TYPE:
                removeDialog(DIALOG_END_TIME);
                showDialog(DIALOG_END_TIME);
                return;
            default:
                return;
        }
    }

    @Override
    public void onTimeSet(TimePicker view, int hour, int minute) {
        // bug 948347 : power saving optimization should not be set when charging and the switch of ChargeExitLow is opened.
        if (mIsChargeExitLow && mplugged) {
            return;
        }

        try {
            if (mTimeType == START_TIME_TYPE) {
                Log.d(TAG, "onTimeSet() START_TIME_TYPE() hour: " + hour);
                if (hour == mEndHour && minute == mEndMinutes) {
                    Toast.makeText(mContext, getString(R.string.schedule_time_exist), Toast.LENGTH_LONG).show();
                    return;
                }
                mPowerManagerEx.setSchedulePowerMode_StartTime(hour, minute);
                mScheduleStartPre.setSummary(formatTime(hour, minute));
                mStartHour = hour;
                mStartMinutes = minute;
            } else if (mTimeType == END_TIME_TYPE) {
                Log.d(TAG, "onTimeSet() END_TIME_TYPE()");
                if (hour == mStartHour && minute == mStartMinutes) {
                    Toast.makeText(mContext, getString(R.string.schedule_time_exist), Toast.LENGTH_LONG).show();
                    return;
                }
                mPowerManagerEx.setSchedulePowerMode_EndTime(hour, minute);
                mScheduleEndPre.setSummary(formatTime(hour, minute));
                mEndHour = hour;
                mEndMinutes = minute;
            }
        } catch (RemoteException e) {
            // Not much we can do here
        }

    }

    private String formatTime(int hour, int minute) {
        Calendar c = Calendar.getInstance();
        if (c == null) return "";
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        String format = DateFormat.is24HourFormat(mContext) ? M24 : M12;
        return (String)DateFormat.format(format, c);
    }

     @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        Log.d(TAG, "onPreferenceChange(): key-" + preference.getKey() + " newValue - " + newValue);
        // bug 948347 : power saving optimization should not be set when charging and the switch of ChargeExitLow is opened.
        if (mIsChargeExitLow && mplugged) {
            return true;
        }

        if (KEY_SCHEDULE_SAVER.equals(preference.getKey())) {
            final boolean enabled = (Boolean) newValue;
            try {
                mPowerManagerEx.setSchedule_Enable(enabled);
            } catch (RemoteException e) {
                // Not much we can do here
            }
            updatePrefValue();
            return true;
        } else if (KEY_POWER_MODE.equals(preference.getKey())) {
            final int value = Integer.parseInt((String) newValue);
            try {
                mPowerManagerEx.setSchedule_Mode(value);
                mSchedulePowerModePre.setValue((String) newValue);
                mSchedulePowerModePre.setSummary(mSchedulePowerModePre.getEntry());
            } catch (RemoteException e) {
                // Not much we can do here
            }
            return true;
        }
        return true;
    }

    private void updatePrefValue() {
        try {
            mIsScheduleSaverEnable = mPowerManagerEx.getSchedule_Enable();
            mScheduleStartTime = mPowerManagerEx.getSchedulePowerMode_StartTime();
            mScheduleEndTime = mPowerManagerEx.getSchedulePowerMode_EndTime();
            mScheduleMode = mPowerManagerEx.getSchedule_Mode();
        } catch (RemoteException e) {
            // Not much we can do here
        }
        mSchedulePowerSaverPre.setChecked(mIsScheduleSaverEnable);

        mStartHour = mScheduleStartTime / 100;
        mStartMinutes = mScheduleStartTime % 100;
        mEndHour = mScheduleEndTime / 100;
        mEndMinutes = mScheduleEndTime % 100;
        Log.d(TAG,"mScheduleMode: " + mScheduleMode
                + " mStartHour: " + mStartHour + " mStartMinutes: " + mStartMinutes);
        mScheduleStartPre.setSummary(formatTime(mStartHour, mStartMinutes));
        mScheduleEndPre.setSummary(formatTime(mEndHour, mEndMinutes));
        mSchedulePowerModePre.setValue(Integer.toString(mScheduleMode));
        mSchedulePowerModePre.setSummary(mSchedulePowerModePre.getEntry());
    }

    public void updatePrefState(Intent intent) {
        if (null != intent) {
            mplugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) != 0;
        }
        try {
            mIsChargeExitLow = mPowerManagerEx.getSmartSavingModeWhenCharging();
        } catch (RemoteException e) {
            // Not much we can do here
        }
         Log.d(TAG,"mplugged = " + mplugged + " mIsChargeExitLow= " + mIsChargeExitLow );
        if (mIsChargeExitLow && mplugged) {
            mSchedulePowerSaverPre.setEnabled(false);
            mScheduleStartPre.setEnabled(false);
            mScheduleEndPre.setEnabled(false);
            mSchedulePowerModePre.setEnabled(false);
        } else {
            mSchedulePowerSaverPre.setEnabled(true);
            mScheduleStartPre.setEnabled(true);
            mScheduleEndPre.setEnabled(true);
            mSchedulePowerModePre.setEnabled(true);
        }
    }

    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive (Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_BATTERY_CHANGED)) {
                updatePrefState(intent);
                updatePrefValue();
            } else if (intent.getAction().equals(PowerManagerEx.ACTION_POWEREX_SAVE_MODE_CHANGED)) {
                updatePrefValue();
            }
        }
    };
}

else if (KEY_POWER_MODE.equals(preference.getKey())) {
            final int value = Integer.parseInt((String) newValue);
            try {
                mPowerManagerEx.setSchedule_Mode(value);
                mSchedulePowerModePre.setValue((String) newValue);
                mSchedulePowerModePre.setSummary(mSchedulePowerModePre.getEntry());
            } catch (RemoteException e) {
                // Not much we can do here
            }


最终调用PowerControll.java中的setSchedule_Mode(mode);

        boolean setSchedule_Mode(int mode) {
            if (DEBUG) Slog.d(TAG, "setScheduleMode(" + mode + "), schedule mode: " + mModeConfigArray[MODECONFIG_SCHEDULE].mMode);

            if ((mode < PowerManagerEx.MODE_PERFORMANCE) || (mode > PowerManagerEx.MODE_ULTRASAVING)) {
                Slog.e(TAG, "invalid mode: " + mode);
                return false;
            }

            if (mode == mModeConfigArray[MODECONFIG_SCHEDULE].mMode) {
                return true;
            }
            msgHandler.removeMessages(MSG_SET_SCHEDULE_MODE);
            return msgHandler.sendMessage(msgHandler.obtainMessage(MSG_SET_SCHEDULE_MODE, mode, 0));
        }


            case MSG_SET_SCHEDULE_MODE:
                // if current mode is SCHEDULE, while save mode changes, don't change the mPrePowerSaveMode
                 // for bug#913238 --> start
                if (mModeConfigArray[MODECONFIG_SCHEDULE].mEnable
                        && mModeConfigIndex == MODECONFIG_SCHEDULE) {
                    mModeSwitch = true;
                }
                // for bug#913238 <-- end
                mModeConfigArray[MODECONFIG_SCHEDULE].mMode = msg.arg1;
                writeConfig();
                updateScheduleAlarm();
                break;


```

处理切换省电模式  
 mPowerManagerEx.setSchedule\_Mode(value); 就是切换省电模式


    /\*\*  
      \* set the target power save mode of schedule power mode setting  
      \* @param mode The target power save mode  
      \* @return Returns true for success, false for fail.  
      \*/  
     public boolean setSchedule\_Mode(int mode) {  
         return mPowerControllerInternal.setSchedule\_Mode(mode);  
     }


最终调用PowerControll.java中的setSchedule\_Mode(mode);


所以可以得出分析结论


mModeConfigArray[MODECONFIG\_SCHEDULE].mMode 就是省电模式设置


修改这个mMode的值就可以了


修改如下:



```
最终修改为:
  case MSG_SET_SCHEDULE_MODE:
                // if current mode is SCHEDULE, while save mode changes, don't change the mPrePowerSaveMode
                 // for bug#913238 --> start
                if (mModeConfigArray[MODECONFIG_SCHEDULE].mEnable
                        && mModeConfigIndex == MODECONFIG_SCHEDULE) {
                    mModeSwitch = true;
                }
                // for bug#913238 <-- end
             -   mModeConfigArray[MODECONFIG_SCHEDULE].mMode = msg.arg1;
             +   mModeConfigArray[MODECONFIG_SCHEDULE].mMode = 0;
                writeConfig();
                updateScheduleAlarm();
                break;
```




