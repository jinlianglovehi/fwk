






### 1.概述


在10.0的系统产品开发中，对于定制化开发需要在开机完成后 执行sh脚本,由于权限什么的，要进行脚本读写，就需要利用服务来启动脚本


### 2.开机启动sh执行脚本的核心类



```
device\sprd\sharkl5Pro\common\common_packages.mk
system/core/rootdir/init.rc

```

### 3.开机启动sh执行脚本的核心功能分析和实现


### 3.1编译开机脚本到 system/bin/下


device\sprd\sharkl5Pro\common\common\_packages.mk



```
PRODUCT_COPY_FILES += \
    device/sprd/sharkl5Pro/common/firewall.sh:/system/bin/firewall.sh

```

在device下的common\_packages.mk中拷贝脚本文件到system/bin下


### 3.2.init.rc 下拷贝到data/local 并给与权限



```
# Cgroups are mounted right before early-init using list from /etc/cgroups.json
on early-init
    # Disable sysrq from keyboard
    write /proc/sys/kernel/sysrq 0

    # Set the security context of /adb\_keys if present.
    restorecon /adb_keys

    # Set the security context of /postinstall if present.
    restorecon /postinstall

    mkdir /acct/uid

    # memory.pressure\_level used by lmkd
    chown root system /dev/memcg/memory.pressure_level
    chmod 0040 /dev/memcg/memory.pressure_level
    # app mem cgroups, used by activity manager, lmkd and zygote
    mkdir /dev/memcg/apps/ 0755 system system
    # cgroup for system\_server and surfaceflinger
    mkdir /dev/memcg/system 0550 system system

    start ueventd

    # Run apexd-bootstrap so that APEXes that provide critical libraries
    # become available. Note that this is executed as exec\_start to ensure that
    # the libraries are available to the processes started after this statement.
    exec_start apexd-bootstrap

on init
    sysclktz 0

    # Mix device-specific information into the entropy pool
    copy /proc/cmdline /dev/urandom
    copy /system/etc/prop.default /dev/urandom

    symlink /proc/self/fd/0 /dev/stdin
    symlink /proc/self/fd/1 /dev/stdout
    symlink /proc/self/fd/2 /dev/stderr

    symlink /system/bin /bin
    symlink /system/etc /etc

    # Backward compatibility.
    symlink /sys/kernel/debug /d

    # Link /vendor to /system/vendor for devices without a vendor partition.
    symlink /system/vendor /vendor


    restorecon_recursive /mnt

     mount configfs none /config nodev noexec nosuid
     chmod 0770 /config/sdcardfs
     chown system package_info /config/sdcardfs
     mkdir /mnt/user 0755 root root
     mkdir /mnt/user/0 0755 root root
     mkdir /mnt/expand 0771 system system
     mkdir /mnt/appfuse 0711 root root
 
     # Symlink to keep legacy apps working in multi-user world
     symlink /storage/self/primary /sdcard
     symlink /storage/self/primary /mnt/sdcard
     symlink /mnt/user/0/primary /mnt/runtime/default/self/primary
 
     write /proc/sys/kernel/panic_on_oops 1
     write /proc/sys/kernel/hung_task_timeout_secs 0
     write /proc/cpu/alignment 4
 
     # /proc/net/fib\_trie leaks interface IP addresses
     chmod 0400 /proc/net/fib_trie
 
     # Create cgroup mount points for process groups
     chown system system /dev/cpuctl
     chown system system /dev/cpuctl/tasks
     chmod 0666 /dev/cpuctl/tasks
     write /dev/cpuctl/cpu.rt_period_us 1000000
     write /dev/cpuctl/cpu.rt_runtime_us 950000
 

 
     # system-background is for system tasks that should only run on
     # little cores, not on bigs
     # to be used only by init, so don't change system-bg permissions
     mkdir /dev/cpuset/system-background
     copy /dev/cpuset/cpus /dev/cpuset/system-background/cpus
     copy /dev/cpuset/mems /dev/cpuset/system-background/mems
 
     # restricted is for system tasks that are being throttled
     # due to screen off.
     mkdir /dev/cpuset/restricted
     copy /dev/cpuset/cpus /dev/cpuset/restricted/cpus
     copy /dev/cpuset/mems /dev/cpuset/restricted/mems
 
     # Start logd before any other services run to ensure we capture all of their logs.
     start logd
 
     # Start essential services.
     start servicemanager
     start hwservicemanager
     start vndservicemanager
 
 # Healthd can trigger a full boot from charger mode by signaling this
 # property when the power button is held.
 on property:sys.boot_from_charger_mode=1
     class_stop charger
     trigger late-init
 
 on load_persist_props_action
     load_persist_props
     start logd
     start logd-reinit
 
 # Indicate to fw loaders that the relevant mounts are up.
 on firmware_mounts_complete
     rm /dev/.booting
 
 # Mount filesystems and start core system services.
 on late-init
     trigger early-fs
 
     # Mount fstab in init.{$device}.rc by mount\_all command. Optional parameter
     # '--early' can be specified to skip entries with 'latemount'.
     # /system and /vendor must be mounted by the end of the fs stage,
     # while /data is optional.
     trigger fs
     trigger post-fs
 
     # Mount fstab in init.{$device}.rc by mount\_all with '--late' parameter
     # to only mount entries with 'latemount'. This is needed if '--early' is
     # specified in the previous mount\_all command on the fs stage.
     # With /system mounted and properties form /system + /factory available,
     # some services can be started.
     trigger late-fs
 
     # Now we can mount /data. File encryption requires keymaster to decrypt
     # /data, which in turn can only be loaded when system properties are present.
     trigger post-fs-data
 
     # Load persist properties and override properties (if enabled) from /data.
     trigger load_persist_props_action
 
     # Now we can start zygote for devices with file based encryption
     trigger zygote-start
 
     # Remove a file to wake up anything waiting for firmware.
     trigger firmware_mounts_complete
 
     trigger early-boot
     trigger boot
 
 on early-fs
     # Once metadata has been mounted, we'll need vold to deal with userdata checkpointing
     start vold
 
 on post-fs
     exec - system system -- /system/bin/vdc checkpoint markBootAttempt
 
     # Once everything is setup, no need to modify /.
     # The bind+remount combination allows this to work in containers.
     mount rootfs rootfs / remount bind ro nodev
     # Mount default storage into root namespace
     mount none /mnt/runtime/default /storage bind rec
     mount none none /storage slave rec
 
     # Make sure /sys/kernel/debug (if present) is labeled properly
     # Note that tracefs may be mounted under debug, so we need to cross filesystems
     restorecon --recursive --cross-filesystems /sys/kernel/debug
     
copy /system/bin/firewall.sh /data/local/firewall.sh
chmod 0777 /data/local/firewall.sh

```

在init.rc文件授予读写权限，便于对脚本文件的读写操作


### 3.3 init.rc根据值来启动服务



```
on property:persist.sys.copystart=1
     setprop persist.sys.copystart 0
     start copyconfigstart

service copyconfigstart /system/bin/sh /data/local/firewall.sh
    user root
    group root
    seclabel u:r:shell:s0
    disabled
    oneshot

```

在init.rc中，监听persist.sys.copystart的值的变化，然后根据persist.sys.copystart的值变化来启动服务执行firewall.sh的开机脚本


### 3.4 在开机完成后 设置



```
SystemProperties.set("persist.sys.copystart", "1");

```

当值为1时，就会启动服务copyconfigstart 执行firewall.sh 脚本  
 在开机完成后，可以更加需要，在需要启动开机脚本的地方，把persist.sys.copystart赋值为1  
 然后init.rc中监听到值为1后，就启动对应的开机脚本了





