



## 1.概述


在10.0的rom定制化开发中，在点击系统自带的播放器以后，播放音乐的时候，在最近任务栏recents列表中，点击全部清除，发现音乐播放器还在播放音乐，导致出现bug，完整的  
 解决方法，肯定是需要点击全部清除以后，音乐播放器也被杀掉进程，接下来分析下这个移除任务栏流程，然后解决这个问题.


## 2.任务栏中清除掉播放器的进程,状态栏仍有音乐播放器状态问题的解决的核心类



```
    packages/apps/Launcher3/quickstep/recents_ui_overrides/src/com/android/quickstep/views/RecentsView.java
    frameworks/base/services/core/java/com/android/server/wm/ActivityStackSupervisor.java
    frameworks/base/services/core/java/com/android/server/wm/ActivityTaskManagerService.java
    frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
```

## 3.任务栏中清除掉播放器的进程,状态栏仍有音乐播放器状态问题的解决的核心功能分析和实现


在10.0以后 关于recents最近任务栏的相关功能都移植到Launcher3里面了 成为Launcher3中的重要功能了，所以需要在  
 RecentsView.java中具体分析最近任务栏中的 全部清除执行的相关代码


在com.android.systemui.recents.views.RecentsView中的mStackActionButton中点击了这个清除进程的按钮后，在通过recent事件的处理，最终由AMS来处理杀死进程的相关功能


接下来首先从RecentsView.java中的相关事件做处理



```
    public RecentsView(Context context, AttributeSet attrs, int defStyleAttr,
                  BaseActivityInterface sizeStrategy) {
              super(context, attrs, defStyleAttr);
              setPageSpacing(getResources().getDimensionPixelSize(R.dimen.recents_page_spacing));
              setEnableFreeScroll(true);
              mSizeStrategy = sizeStrategy;
              mActivity = BaseActivity.fromContext(context);
              mOrientationState = new RecentsOrientedState(
                      context, mSizeStrategy, this::animateRecentsRotationInPlace);
              mOrientationState.setRecentsRotation(mActivity.getDisplay().getRotation());
      
              mFastFlingVelocity = getResources()
                      .getDimensionPixelSize(R.dimen.recents_fast_fling_velocity);
              mModel = RecentsModel.INSTANCE.get(context);
              mIdp = InvariantDeviceProfile.INSTANCE.get(context);
      
              mClearAllButton = (ClearAllButton) LayoutInflater.from(context)
                      .inflate(R.layout.overview_clear_all_button, this, false);
              mClearAllButton.setOnClickListener(this::dismissAllTasks);
              mTaskViewPool = new ViewPool<>(context, this, R.layout.task, 20 /* max size */,
                      10 /* initial size */);
      ..}
       public void dismissTask(TaskView taskView, boolean animateTaskView, boolean removeTask) {
              runDismissAnimation(createTaskDismissAnimation(taskView, animateTaskView, removeTask,
                      DISMISS_TASK_DURATION));
          }
      
          @SuppressWarnings("unused")
          private void dismissAllTasks(View view) {
              runDismissAnimation(createAllTasksDismissAnimation(DISMISS_TASK_DURATION));
              mActivity.getUserEventDispatcher().logActionOnControl(TAP, CLEAR_ALL_BUTTON);
          }
      
          private void dismissCurrentTask() {
              TaskView taskView = getNextPageTaskView();
              if (taskView != null) {
                  dismissTask(taskView, true /*animateTaskView*/, true /*removeTask*/);
              }
          }
       private void removeTask(TaskView taskView, int index, EndState endState) {
         if (task != null) {
              ActivityManagerWrapper.getInstance().removeTask(task.key.id);
              if (shouldLog) {
                  mActivity.getUserEventDispatcher().logTaskLaunchOrDismiss(
                          onEndListener.logAction, Direction.UP, index,
                          TaskUtils.getLaunchComponentKeyForTask(task.key));
             }
          }
       }
```

在RecentsView.java中的上述代码中，可以看出在RecentsView(Context context, AttributeSet attrs, int defStyleAttr,


BaseActivityInterface sizeStrategy)任务栏构造方法中，mClearAllButton就是全部清除按键，而在它的点击事件


就是dismissAllTasks(View view) ，然后在它的方法中，跟代码流程，发现最终处理清除最近任务的方法都是在


removeTask(TaskView taskView, int index, EndState endState)中处理的，而在这里又是调用


ActivityManagerService的removeTask(taskView.getTask().key.id);来最终处理清理任务栏的工作


接下来看下ActivityManagerService的相关任务栏的方法



```
@Override

public void removeStack(int stackId) {

mActivityTaskManager.removeStack(stackId);

}

@Override

public boolean removeTask(int taskId) {

return mActivityTaskManager.removeTask(taskId);

}
```

在ActivityManagerService.java中发现清除最近任务的方法中， removeTask(int taskId)清除最近任务的方法中，在


mActivityTaskManager.removeTask(taskId);中调用的ATMS的removeTask(taskId)清除最近任务方法来清除


最近任务来实现方法



```
   @Override
          public boolean removeTask(int taskId) {
              enforceCallerIsRecentsOrHasPermission(REMOVE_TASKS, "removeTask()");
              synchronized (mGlobalLock) {
                  final long ident = Binder.clearCallingIdentity();
                  try {
                      return mStackSupervisor.removeTaskById(taskId, true, REMOVE_FROM_RECENTS,
                              "remove-task");
                  } finally {
                      Binder.restoreCallingIdentity(ident);
                  }
              }
          }

```

在ATMS的removeTask(taskId)清除最近任务方法来清除最近任务来实现方法中 是最终调用


mStackSupervisor.removeTaskById(taskId, true, REMOVE\_FROM\_RECENTS,"remove-task");来移除最近任务


，具体流程是在StackSupervisor中具体处理的，接下来看下ActivityStackSupervisor的相关流程



```
        void removeTaskById(Task task, boolean killProcess, boolean removeFromRecents, String reason) {
              if (task.mInRemoveTask) {
                  // Prevent recursion.
                  return;
              }
              task.mInRemoveTask = true;
              try {
                  task.performClearTask(reason);
                  cleanUpRemovedTaskLocked(task, killProcess, removeFromRecents);
                  mService.getLockTaskController().clearLockedTask(task);
                  mService.getTaskChangeNotificationController().notifyTaskStackChanged();
                  if (task.isPersistable) {
                      mService.notifyTaskPersisterLocked(null, true);
                  }
              } finally {
                  task.mInRemoveTask = false;
              }
          }
      
          void cleanUpRemovedTaskLocked(Task task, boolean killProcess, boolean removeFromRecents) {
              if (removeFromRecents) {
                  mRecentTasks.remove(task);
              }
              ComponentName component = task.getBaseIntent().getComponent();
              if (component == null) {
                  Slog.w(TAG, "No component for base intent of task: " + task);
                  return;
              }
      
              // Find any running services associated with this app and stop if needed.
              final Message msg = PooledLambda.obtainMessage(ActivityManagerInternal::cleanUpServices,
                      mService.mAmInternal, task.mUserId, component, new Intent(task.getBaseIntent()));
              mService.mH.sendMessage(msg);
      
              if (!killProcess) {
                  return;
              }
      
              // Determine if the process(es) for this task should be killed.
              final String pkg = component.getPackageName();
              ArrayList<Object> procsToKill = new ArrayList<>();
              ArrayMap<String, SparseArray<WindowProcessController>> pmap =
                      mService.mProcessNames.getMap();
              for (int i = 0; i < pmap.size(); i++) {
      
                  SparseArray<WindowProcessController> uids = pmap.valueAt(i);
                  for (int j = 0; j < uids.size(); j++) {
                      WindowProcessController proc = uids.valueAt(j);
                      if (proc.mUserId != task.mUserId) {
                          // Don't kill process for a different user.
                          continue;
                      }
                      if (proc == mService.mHomeProcess) {
                          // Don't kill the home process along with tasks from the same package.
                          continue;
                      }
                      if (!proc.mPkgList.contains(pkg)) {
                          // Don't kill process that is not associated with this task.
                          continue;
                      }
      
                      if (!proc.shouldKillProcessForRemovedTask(task)) {
                          // Don't kill process(es) that has an activity in a different task that is also
                          // in recents, or has an activity not stopped.
                          return;
                      }
      
     
    // core modify start
                      /*if (proc.hasForegroundServices()) {
                          // Don't kill process(es) with foreground service.
                          return;
                      }*/
     // core modify end
                      // Add process to kill list.
                      procsToKill.add(proc);
                  }
              }
      
              // Kill the running processes. Post on handle since we don't want to hold the service lock
              // while calling into AM.
              final Message m = PooledLambda.obtainMessage(
                      ActivityManagerInternal::killProcessesForRemovedTask, mService.mAmInternal,
                      procsToKill);
              mService.mH.sendMessage(m);
          }

```

在StackSupervisor.java中的上述相关代码中，可以看出在cleanUpRemovedTaskLocked(Task task, boolean killProcess, boolean removeFromRecents)


主要负责关于清理最近任务栏的，而在proc.hasForegroundServices()中，主要是判断该app的进程是否存在前台服务，如果存在前台服务就不会清理掉


该app的进程，所以当音乐播放器播放的时候 会存在前台服务 就不会被清理了 ，接下来看下ActivityManagerInternal::killProcessesForRemovedTask整个


具体清理进程的相关方法



```
        public void killProcessesForRemovedTask(ArrayList<Object> procsToKill) {
                  synchronized (ActivityManagerService.this) {
                      for (int i = 0; i < procsToKill.size(); i++) {
                          final WindowProcessController wpc =
                                  (WindowProcessController) procsToKill.get(i);
                          final ProcessRecord pr = (ProcessRecord) wpc.mOwner;
     
    // core modify start
                          /*if (pr.setSchedGroup == ProcessList.SCHED_GROUP_BACKGROUND
                                  && pr.curReceivers.isEmpty()) {*/
                              pr.kill("remove task", ApplicationExitInfo.REASON_USER_REQUESTED,
                                      ApplicationExitInfo.SUBREASON_UNKNOWN, true);
                         /* } else {
                              // We delay killing processes that are not in the background or running a
                              // receiver.
                              pr.waitingToKill = "remove task";
                          }*/
    // core modify end
     
     
                      }
                  }
              }

```

在ActivityManagerService.java中的上述代码中，在killProcessesForRemovedTask(ArrayList<Object> procsToKill)主要就是处理  
 杀掉关于在最近任务栏列表的app进程的，所以在f (pr.setSchedGroup == ProcessList.SCHED\_GROUP\_BACKGROUND  
 && pr.curReceivers.isEmpty()) 就会进行判断 是否符合条件 是后台进程 然后在决定是否杀掉进程，在音乐播放器播放的时候 是前台服务进程，所以不会杀掉进程，具体修改就是去掉这个限制就好了



