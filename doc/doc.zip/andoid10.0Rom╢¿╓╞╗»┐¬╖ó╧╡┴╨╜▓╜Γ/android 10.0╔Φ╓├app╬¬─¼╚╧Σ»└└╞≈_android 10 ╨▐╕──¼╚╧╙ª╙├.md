






### 1.概述


在10.0的系统产品开发中，当出现多个浏览器时，该如何设置默认浏览器呢,其实在Settings 默认应用->浏览器应用 当点击选择浏览器时会调用 /package/app/PermissionController的代码  
 点击 Preference 切换是最终调用的代码走到 setRoleHolderAsUser()


### 2.设置app为默认浏览器的核心类



```
packages\apps\PermissionController\src\com\android\packageinstaller\role\ui\ManageRoleHolderStateLiveData.java
/frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java

```

### 3.设置app为默认浏览器的核心功能实现和分析


首先分析ManageRoleHolderStateLiveData.java中关于设置默认浏览器的方法



```
public void setRoleHolderAsUser(@NonNull String roleName, @NonNull String packageName,
            boolean add, int flags, @NonNull UserHandle user, @NonNull Context context) {
        if (getValue() != STATE_IDLE) {
            Log.e(LOG_TAG, "Already (tried) managing role holders, requested role: " + roleName
                    + ", requested package: " + packageName);
            return;
        }
        if (DEBUG) {
            Log.i(LOG_TAG, (add ? "Adding" : "Removing") + " package as role holder, role: "
                    + roleName + ", package: " + packageName);
        }
        mLastPackageName = packageName;
        mLastAdd = add;
        mLastFlags = flags;
        mLastUser = user;
        setValue(STATE_WORKING);

        RoleManager roleManager = context.getSystemService(RoleManager.class);
        Executor executor = context.getMainExecutor();
        Consumer<Boolean> callback = successful -> {
            if (successful) {
                if (DEBUG) {
                    Log.i(LOG_TAG, "Package " + (add ? "added" : "removed")
                            + " as role holder, role: " + roleName + ", package: " + packageName);
                }
                setValue(STATE_SUCCESS);
            } else {
                if (DEBUG) {
                    Log.i(LOG_TAG, "Failed to " + (add ? "add" : "remove")
                            + " package as role holder, role: " + roleName + ", package: "
                            + packageName);
                }
                setValue(STATE_FAILURE);
            }
        };
        if (add) {
            roleManager.addRoleHolderAsUser(roleName, packageName, flags, user, executor, callback);
        } else {
            roleManager.removeRoleHolderAsUser(roleName, packageName, flags, user, executor,
                    callback);
        }
    }

```

各默认应用对应的 roleName 如下，改造一下 setRoleHolderAsUser(),传递 roleName 和 packageName  
 电话  
 role: android.app.role.DIALER, package: com.android.dialer  
 短信  
 role: android.app.role.SMS, package: com.android.mms  
 主屏幕  
 role: android.app.role.HOME, package: com.android.launcher3  
 浏览器  
 role: android.app.role.BROWSER, package: com.android.browser


### 3.2PhoneWindowManager.java设置默认浏览器的分析


首先对PhoneWindowManager.java的系统开机调用方法分析



```
       @Override
      public void onSystemUiStarted() {
          bindKeyguard();
      }
  
      /** {@inheritDoc} */
      @Override
      public void systemReady() {
          // In normal flow, systemReady is called before other system services are ready.
          // So it is better not to bind keyguard here.
          mKeyguardDelegate.onSystemReady();
  
          mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
          if (mVrManagerInternal != null) {
              mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
          }
  
          readCameraLensCoverState();
          updateUiMode();
          mDefaultDisplayRotation.updateOrientationListener();
          synchronized (mLock) {
              mSystemReady = true;
              mHandler.post(new Runnable() {
                  @Override
                  public void run() {
                      updateSettings();
                  }
              });
              // If this happens, for whatever reason, systemReady came later than systemBooted.
              // And keyguard should be already bound from systemBooted
              if (mSystemBooted) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
  
          mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
      }
  
      /** {@inheritDoc} */
      @Override
      public void systemBooted() {
          bindKeyguard();
          synchronized (mLock) {
              mSystemBooted = true;
              if (mSystemReady) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
          startedWakingUp(ON_BECAUSE_OF_UNKNOWN);
          finishedWakingUp(ON_BECAUSE_OF_UNKNOWN);
          screenTurningOn(null);
          screenTurnedOn();
      }

```

在系统启动准备完毕后，会调用PhoneWindowManager的systemBooted() 和systemReady()来调用  
 准备其他在开机完成后要实现的功能，所以可以在这两个方法中来增加设置默认浏览器的方法


增加默认浏览器的方法如下:



```
import android.app.role.RoleManager;
import android.os.UserHandle;
import android.os.Process;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
    
    public void setDefaultBrowser(Context context, String packageName) {
        String roleName = "android.app.role.BROWSER";
        boolean add = true;
        int flags = 0;
        UserHandle user = Process.myUserHandle();
        Log.i("permission", (add ? "Adding" : "Removing") + " package as role holder, role: "
                + roleName + ", package: " + packageName);
        RoleManager roleManager = context.getSystemService(RoleManager.class);
        Executor executor = context.getMainExecutor();
        Consumer<Boolean> callback = successful -> {
            if (successful) {
                Log.d("permission", "Package " + (add ? "added" : "removed")
                        + " as role holder, role: " + roleName + ", package: " + packageName);
            } else {
                Log.d("permission", "Failed to " + (add ? "add" : "remove")
                        + " package as role holder, role: " + roleName + ", package: "
                        + packageName);
            }
        };
        roleManager.addRoleHolderAsUser(roleName, packageName, flags, user, executor, callback);
    }

```

通过上述对于RoleManager的相关api的调用设置默认浏览器的方法实现设置浏览器，  
 这样我们就可以在 PhoneWindowManager 的systemReady()方法调用 setDefaultBrowser就可以了  
 实现如下:



```
      public void systemReady() {
          // In normal flow, systemReady is called before other system services are ready.
          // So it is better not to bind keyguard here.
          mKeyguardDelegate.onSystemReady();
  
          mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
          if (mVrManagerInternal != null) {
              mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
          }
  
          readCameraLensCoverState();
          updateUiMode();
          mDefaultDisplayRotation.updateOrientationListener();
          synchronized (mLock) {
              mSystemReady = true;
              mHandler.post(new Runnable() {
                  @Override
                  public void run() {
                      updateSettings();
                  }
              });
              // If this happens, for whatever reason, systemReady came later than systemBooted.
              // And keyguard should be already bound from systemBooted
              if (mSystemBooted) {
                  mKeyguardDelegate.onBootCompleted();
              }
          }
  
          mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
+    setDefaultBrowser(mContext, "浏览器包名");
      }

```




