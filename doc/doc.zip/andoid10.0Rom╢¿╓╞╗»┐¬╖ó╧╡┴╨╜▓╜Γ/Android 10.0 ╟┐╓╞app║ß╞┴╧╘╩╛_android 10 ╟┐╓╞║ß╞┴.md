






### 1.概述


10.0中处理屏幕旋转方向，首先有kernel底层处理，是靠从底层驱动gsensor 中获取数据，从而判断屏幕方向的，  
 然后事件上报后 有framework 层调用windowManagerService 来处理旋转的相关事件


### 2.强制app横屏显示的核心类



```
/framework/base/services/java/com/android/server/wm/DisplayRotation.java

```

### 3.强制app横屏显示的核心功能分析和实现


在10.0的系统中由DisplayRotation.java 里负责处理相关屏幕旋转的工作  
 在进行屏幕旋转的时候，根据相关日志发现mPolicy.rotationForOrientation的相关参数做了改变  
 接下来看下DisplayRotation.java的相关处理旋转的方法  
 路径为:/framework/base/services/java/com/android/server/wm/DisplayRotation.java



```
int rotationForOrientation(int orientation, int lastRotation) {
    if (DEBUG_ORIENTATION) {
         Slog.v(TAG, "rotationForOrientation(orient="
           + orientation + ", last=" + lastRotation
           + "); user=" + mUserRotation + " "
           + (mUserRotationMode == WindowManagerPolicy.USER_ROTATION_LOCKED
           ? "USER\_ROTATION\_LOCKED" : "")
          );
     }     
      if (isFixedToUserRotation()) {
          return mUserRotation;
      }

      int sensorRotation = mOrientationListener != null
              ? mOrientationListener.getProposedRotation() // may be -1
              : -1;
      if (sensorRotation < 0) {
          sensorRotation = lastRotation;
      }

      final int lidState = mDisplayPolicy.getLidState();
      final int dockMode = mDisplayPolicy.getDockMode();
      final boolean hdmiPlugged = mDisplayPolicy.isHdmiPlugged();
      final boolean carDockEnablesAccelerometer =
              mDisplayPolicy.isCarDockEnablesAccelerometer();
      final boolean deskDockEnablesAccelerometer =
              mDisplayPolicy.isDeskDockEnablesAccelerometer();

      final int preferredRotation;
      if (!isDefaultDisplay) {
          // For secondary displays we ignore things like displays sensors, docking mode and
          // rotation lock, and always prefer user rotation.
          preferredRotation = mUserRotation;
      } else if (lidState == LID_OPEN && mLidOpenRotation >= 0) {
          // Ignore sensor when lid switch is open and rotation is forced.
         preferredRotation = mLidOpenRotation;
      } else if (dockMode == Intent.EXTRA_DOCK_STATE_CAR
              && (carDockEnablesAccelerometer || mCarDockRotation >= 0)) {
          // Ignore sensor when in car dock unless explicitly enabled.
          // This case can override the behavior of NOSENSOR, and can also
          // enable 180 degree rotation while docked.
          preferredRotation = carDockEnablesAccelerometer ? sensorRotation : mCarDockRotation;
      } else if ((dockMode == Intent.EXTRA\_DOCK\_STATE\_DESK
 || dockMode == Intent.EXTRA\_DOCK\_STATE\_LE\_DESK
 || dockMode == Intent.EXTRA\_DOCK\_STATE\_HE\_DESK)
 && (deskDockEnablesAccelerometer || mDeskDockRotation >= 0)) {
          // Ignore sensor when in desk dock unless explicitly enabled.
          // This case can override the behavior of NOSENSOR, and can also
          // enable 180 degree rotation while docked.
          preferredRotation = deskDockEnablesAccelerometer ? sensorRotation : mDeskDockRotation;
      } else if (hdmiPlugged && mDemoHdmiRotationLock) {
          // Ignore sensor when plugged into HDMI when demo HDMI rotation lock enabled.
          // Note that the dock orientation overrides the HDMI orientation.
          preferredRotation = mDemoHdmiRotation;
          .....
      } else if ((mUserRotationMode == WindowManagerPolicy.USER\_ROTATION\_FREE
 && (orientation == ActivityInfo.SCREEN\_ORIENTATION\_USER
 || orientation == ActivityInfo.SCREEN\_ORIENTATION\_UNSPECIFIED
 || orientation == ActivityInfo.SCREEN\_ORIENTATION\_USER\_LANDSCAPE
 || orientation == ActivityInfo.SCREEN\_ORIENTATION\_USER\_PORTRAIT
 || orientation == ActivityInfo.SCREEN\_ORIENTATION\_FULL\_USER))
              || orientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR
              || orientation == ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
              || orientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
              || orientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) {
          // Otherwise, use sensor only if requested by the application or enabled
          // by default for USER or UNSPECIFIED modes.  Does not apply to NOSENSOR.
          if (mAllowAllRotations < 0) {
              // Can't read this during init() because the context doesn't
              // have display metrics at that time so we cannot determine
              // tablet vs. phone then.
              mAllowAllRotations = mContext.getResources().getBoolean(
                      com.android.internal.R.bool.config_allowAllRotations) ? 1 : 0;
          }
          if (sensorRotation != Surface.ROTATION_180
                  || mAllowAllRotations == 1
                  || orientation == ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                  || orientation == ActivityInfo.SCREEN_ORIENTATION_FULL_USER) {
              preferredRotation = sensorRotation;
          } else {
              preferredRotation = lastRotation;
          }
      } else if (mUserRotationMode == WindowManagerPolicy.USER_ROTATION_LOCKED
              && orientation != ActivityInfo.SCREEN_ORIENTATION_NOSENSOR) {
          // Apply rotation lock.  Does not apply to NOSENSOR.
          // The idea is that the user rotation expresses a weak preference for the direction
          // of gravity and as NOSENSOR is never affected by gravity, then neither should
          // NOSENSOR be affected by rotation lock (although it will be affected by docks).
          preferredRotation = mUserRotation;
      } else {
          // No overriding preference.
          // We will do exactly what the application asked us to do.
          preferredRotation = -1;
      }

      switch (orientation) {
          case ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:
              // Return portrait unless overridden.
              if (isAnyPortrait(preferredRotation)) {
                  return preferredRotation;
              }
              return mPortraitRotation;

          case ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:
              // Return landscape unless overridden.
              if (isLandscapeOrSeascape(preferredRotation)) {
                  return preferredRotation;
              }
              return mLandscapeRotation;

          case ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT:
              // Return reverse portrait unless overridden.
              if (isAnyPortrait(preferredRotation)) {
                  return preferredRotation;
              }
              return mUpsideDownRotation;

          case ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE:
              // Return seascape unless overridden.
              if (isLandscapeOrSeascape(preferredRotation)) {
                  return preferredRotation;
              }
              return mSeascapeRotation;

          case ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:
          case ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE:
              // Return either landscape rotation.
              if (isLandscapeOrSeascape(preferredRotation)) {
                  return preferredRotation;
              }
              if (isLandscapeOrSeascape(lastRotation)) {
                  return lastRotation;
              }
              return mLandscapeRotation;

          case ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT:
          case ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT:
              // Return either portrait rotation.
              if (isAnyPortrait(preferredRotation)) {
                  return preferredRotation;
              }
              if (isAnyPortrait(lastRotation)) {
                  return lastRotation;
              }
              return mPortraitRotation;

          default:
              // For USER, UNSPECIFIED, NOSENSOR, SENSOR and FULL_SENSOR,
              // just return the preferred orientation we already calculated.
              if (preferredRotation >= 0) {
                  return preferredRotation;
              }
              return Surface.ROTATION_0;
      }
  }

```

在rotationForOrientation(int orientation, int lastRotation) 中处理屏幕方向，主要是switch (orientation) 这段代码  
 根据orientation的参数，返回屏幕旋转的角度值  
 rotationForOrientation()在屏幕旋转时处理旋转方向  
 如下代码:



```
case ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:
              // Return portrait unless overridden.
              if (isAnyPortrait(preferredRotation)) {
                  return preferredRotation;
              }
              return mPortraitRotation;

```

这里主要处理当app是横屏方向时返回的屏幕方向  
 所以强制app横屏做如下修改:



```
case ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:
    // Return portrait unless overridden.
    if (isAnyPortrait(preferredRotation)) {
        return preferredRotation;
    }
     - return mPortraitRotation;
     + return Surface.ROTATION_90;
  case ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:
      // Return landscape unless overridden.
      if (isLandscapeOrSeascape(preferredRotation)) {
          return preferredRotation;
      }
     - return mLandscapeRotation;
     + return Surface.ROTATION_90;

```




