






### 1.概述


在10.0的系统产品开发中，进行网络模块开发中，根据客户要求设置某些app可以上网，某些app不可以上网，就是所谓的网络白名单功能，而系统整个网络模块都是由NMS服务负责通讯的


### 2.设置上网应用白名单(上网app白名单)的核心类



```
frameworks/base/core/java/android/os/INetworkManagementService.aidl
frameworks/base/services/core/java/com/android/server/NetworkManagementService.java

```

### 3.设置上网应用白名单(上网app白名单)的核心功能分析和实现


通过上述分析得知系统关于网络的管理都是在NetworkManagementService.java 中  
 接下来先看下NetworkManagementService.java



```
@Override
public void setFirewallEnabled(boolean enabled) {
    enforceSystemUid();
    try {
        mNetdService.firewallSetFirewallType(
                enabled ? INetd.FIREWALL_WHITELIST : INetd.FIREWALL_BLACKLIST);
        mFirewallEnabled = enabled;
    } catch (RemoteException | ServiceSpecificException e) {
        throw new IllegalStateException(e);
    }
}

```

通过setFirewallEnabled(boolean enabled)来调用ntdservices 设置防火墙功能  
 通过读代码可以发现这是个设置防火墙的方法



```
@Override
public void setFirewallUidRules(int chain, int[] uids, int[] rules) {
    enforceSystemUid();
    synchronized (mQuotaLock) {
        synchronized (mRulesLock) {
            SparseIntArray uidFirewallRules = getUidFirewallRulesLR(chain);
            SparseIntArray newRules = new SparseIntArray();
            // apply new set of rules
            for (int index = uids.length - 1; index >= 0; --index) {
                int uid = uids[index];
                int rule = rules[index];
                updateFirewallUidRuleLocked(chain, uid, rule);
                newRules.put(uid, rule);
            }
            // collect the rules to remove.
            SparseIntArray rulesToRemove = new SparseIntArray();
            for (int index = uidFirewallRules.size() - 1; index >= 0; --index) {
                int uid = uidFirewallRules.keyAt(index);
                if (newRules.indexOfKey(uid) < 0) {
                    rulesToRemove.put(uid, FIREWALL_RULE_DEFAULT);
                }
            }
            // remove dead rules
            for (int index = rulesToRemove.size() - 1; index >= 0; --index) {
                int uid = rulesToRemove.keyAt(index);
                updateFirewallUidRuleLocked(chain, uid, FIREWALL_RULE_DEFAULT);
            }
        }
        try {
            switch (chain) {
                case FIREWALL_CHAIN_DOZABLE:
                    mNetdService.firewallReplaceUidChain("fw\_dozable", true, uids);
                    break;
                case FIREWALL_CHAIN_STANDBY:
                    mNetdService.firewallReplaceUidChain("fw\_standby", false, uids);
                    break;
                case FIREWALL_CHAIN_POWERSAVE:
                    mNetdService.firewallReplaceUidChain("fw\_powersave", true, uids);
                    break;
                case FIREWALL_CHAIN_NONE:
                default:
                    Slog.d(TAG, "setFirewallUidRules() called on invalid chain: " + chain);
            }
        } catch (RemoteException e) {
            Slog.w(TAG, "Error flushing firewall chain " + chain, e);
        }
    }
}

```

通过代码可以了解 这个方法是根据app的 uid设置访问网络  
 所以通过nms 就可以实现上网应用白名单的功能，只是需要添加接口就好了


### 3.1 INetworkManagementService.aidl 添加网络白名单接口


如下:



```
diff --git a/frameworks/base/core/java/android/os/INetworkManagementService.aidl b/frameworks/base/core/java/android/os/INetworkManagementService.aidl
old mode 100644
new mode 100755
index 0ba77be03d..a947881dd7
--- a/frameworks/base/core/java/android/os/INetworkManagementService.aidl
+++ b/frameworks/base/core/java/android/os/INetworkManagementService.aidl
@@ -406,4 +406,6 @@ interface INetworkManagementService
      * destory Sockets by Uid
      */
     void destorySocketByUid(int uid);
+       void setWhiteNetApp(in List<String> packageNames);
+       List<String> getWhiteNetApp();
 }

```

通过INetworkManagementService.aidl增加设置网络白名单和获取网络白名单的接口


### 3.2 NetworkManagementService.java 实现这些接口 然后设置上网app


在NMS中实现白名单接口，以及设置上网白名单的功能



```
diff --git a/frameworks/base/services/core/java/com/android/server/NetworkManagementService.java b/frameworks/base/services/core/java/com/android/server/NetworkManagementService.java
old mode 100644
new mode 100755
index 606dab13e4..a8e2e8509a
--- a/frameworks/base/services/core/java/com/android/server/NetworkManagementService.java
+++ b/frameworks/base/services/core/java/com/android/server/NetworkManagementService.java
@@ -40,7 +40,8 @@ import static android.net.NetworkStats.UID_ALL;
 import static android.net.TrafficStats.UID_TETHERING;
 
 import static com.android.server.NetworkManagementSocketTagger.PROP_QTAGUID_ENABLED;
-
+import android.content.pm.PackageManager;
+import android.content.pm.ApplicationInfo;
 import android.annotation.NonNull;
 import android.app.ActivityManager;
 import android.content.Context;
@@ -85,7 +86,7 @@ import android.util.Slog;
 import android.util.SparseBooleanArray;
 import android.util.SparseIntArray;
 import android.util.StatsLog;
-
+import android.provider.Settings;
 import com.android.internal.annotations.GuardedBy;
 import com.android.internal.annotations.VisibleForTesting;
 import com.android.internal.app.IBatteryStats;
@@ -1637,7 +1638,8 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
 
     @Override
     public void setFirewallEnabled(boolean enabled) {
-        enforceSystemUid();
+        //enforceSystemUid();
         try {
             mNetdService.firewallSetFirewallType(
                     enabled ? INetd.FIREWALL_WHITELIST : INetd.FIREWALL_BLACKLIST);
@@ -1649,7 +1651,8 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
 
     @Override
     public boolean isFirewallEnabled() {
-        enforceSystemUid();
+        //enforceSystemUid();
         return mFirewallEnabled;
     }
 
@@ -1664,7 +1667,95 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
             throw new IllegalStateException(e);
         }
     }
-
+       private List<String> blackpackageNames;
+       private List<Integer> blackpackageNames_uid;

+       @Override
+       public void setWhiteNetApp( List<String> packageNames){
+               PackageManager pm = mContext.getPackageManager();
+               List<String> packageNames\_old= this.blackpackageNames;
+               this.blackpackageNames=packageNames;
+               this.blackpackageNames_uid=null;
+
+               if(packageNames_old!=null || packageNames_old.size()>0){
+                           for (String pkgName : packageNames_old) {
+                                        int uid = getUidFromPackageName(pm, pkgName);
+                if (uid > 0) {
+                    setFirewallUidRule( FIREWALL_CHAIN_DOZABLE, uid, 0);
+                }
+            }
+               }
+               if(packageNames==null || packageNames.size()==0){
+                       return ;
+               }
+               blackpackageNames\_uid=  new ArrayList<>();
+            for (String pkgName : packageNames) {
+                int uid = getUidFromPackageName(pm, pkgName); //??app?uid
+                               blackpackageNames_uid.add(uid);
+                if (uid > 0) {
+                    setFirewallUidRule( FIREWALL_CHAIN_DOZABLE, uid, 0); //?? uid rule
+                    setFirewallUidRule( FIREWALL_CHAIN_DOZABLE, uid, 1); //??uid????
+                }
+            }
+       }
+       private int getUidFromPackageName(PackageManager pm, String pkgName) {
+        try {
+            ApplicationInfo appInfo = pm.getApplicationInfo(pkgName, PackageManager.MATCH_ALL);
+            if (appInfo != null) {
+                return appInfo.uid;
+            }
+        } catch (PackageManager.NameNotFoundException e) {
+            //e.printStackTrace();
+        }
+        return -1;
+    }
+       @Override
+       public List<String> getWhiteNetApp(){
+               return this.blackpackageNames;
+       }
     private void closeSocketsForFirewallChainLocked(int chain, String chainName) {
         // UID ranges to close sockets on.
         UidRangeParcel[] ranges;
@@ -1685,7 +1776,22 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
                 final SparseIntArray rules = getUidFirewallRulesLR(chain);
                 exemptUids = new int[rules.size()];
                 for (int i = 0; i < exemptUids.length; i++) {
+                                       int uid=rules.keyAt(i);
                     if (rules.valueAt(i) == FIREWALL_RULE_ALLOW) {
+                                               if(this.blackpackageNames_uid!=null && blackpackageNames_uid.size()>0){
+                                                       if(blackpackageNames_uid.contains(uid)){
+                                                               continue;
+                                                       }
+                                               }
                         exemptUids[numUids] = rules.keyAt(i);
                         numUids++;
                     }
@@ -1709,6 +1815,7 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
                 for (int i = 0; i < ranges.length; i++) {
                     if (rules.valueAt(i) == FIREWALL_RULE_DENY) {
                         int uid = rules.keyAt(i);
                         ranges[numUids] = makeUidRangeParcel(uid, uid);
                         numUids++;
                     }
@@ -1763,7 +1870,7 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
 
     @Override
     public void setFirewallChainEnabled(int chain, boolean enable) {
-        enforceSystemUid();
+        //enforceSystemUid();
         synchronized (mQuotaLock) {
             synchronized (mRulesLock) {
                 if (getFirewallChainState(chain) == enable) {
@@ -1879,6 +1986,7 @@ public class NetworkManagementService extends INetworkManagementService.Stub {
     }
 
     private void setFirewallUidRuleLocked(int chain, int uid, int rule) {
         if (updateFirewallUidRuleLocked(chain, uid, rule)) {
             final int ruleType = getFirewallRuleType(chain, rule);
             try {

```

通过在上述设置上网白名单中的方法调用，就实现了对上网白名单的设置，从而实现了只有在上网白名单内的app可以上网，其他的app都不可以上网


### 3.3在自定义服务中设置白名单app列表



```
public void setWhiteNetApp(List<String> packageNames) throws RemoteException {
		INetworkManagementService networkService = INetworkManagementService.Stub.asInterface(ServiceManager.getService(Context.NETWORKMANAGEMENT_SERVICE));
//        networkService.setFirewallChainEnabled(1, on);
		boolean firewallEnabled = networkService.isFirewallEnabled();
		if (packageNames==null || packageNames.size()==0){
			Settings.System.putString(mContext.getContentResolver(), "WhiteNetApp", "");
			try {
				networkService.setWhiteNetApp(packageNames);
			} catch (Exception e) {
				e.printStackTrace();
			}
			setNetFirwall(false);
			return;
		}else {
			setNetFirwall(true);
		}
		String s="";
		for (int i =0;i<packageNames.size();i++){
			String str = packageNames.get(i);
			if(i<packageNames.size()-1)s=s+str+",";
			else s=s+str;
		}
		Settings.System.putString(mContext.getContentResolver(), "WhiteNetApp", s);
		try {
			    networkService.setWhiteNetApp(packageNames);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
}
public void setNetFirwall(boolean on) throws RemoteException {
        try {
             INetworkManagementService networkService = INetworkManagementService.Stub.asInterface(ServiceManager.getService(Context.NETWORKMANAGEMENT_SERVICE));
            networkService.setFirewallChainEnabled(1, on);
              boolean firewallEnabled = networkService.isFirewallEnabled();
         } catch (Exception e){
             e.printStackTrace();
         }
     }

```

在自定义服务中，通过setWhiteNetApp的调用设置app列表就可以实现上网白名单的相关功能





