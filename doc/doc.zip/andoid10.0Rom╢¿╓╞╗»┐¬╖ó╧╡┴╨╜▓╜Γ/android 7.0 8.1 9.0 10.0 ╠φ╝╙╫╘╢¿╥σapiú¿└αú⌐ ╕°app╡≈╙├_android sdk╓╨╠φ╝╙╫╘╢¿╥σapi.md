






在做定制化开发过程中，需要提供自定义接口供app调用 自定义步骤如下  
 1.自定义包名为android.mom在 frameworks/base/core/java/android下创建  
 mom文件夹 然后创建自定义java类



```
package android.mom;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.MdmManager;
import java.util.List;

public class MyPower {
    private Context mContext;
    private MyManager mdmApiManager;
    public SuperPower(){

    }
    /**
     *
     * @param context
     * @see
     */
    public MyPower(Context context){
        this.mContext = context;
        mdmApiManager = (MyManager) mContext.getSystemService("api");
    }

    /**
     *
     * @param packageName
     * @param className
     * @see
     */
    public void setDefaultLauncher(String packageName, String className){
        mdmApiManager.setDefaultLauncher(packageName,className);
    }

    /**
     * @see
     */
    public void clearLauncher(){
        mdmApiManager.clearLauncher();
    }

    /**
     *
     * @return
     * @see
     */
    public Bitmap captureScreen(){
        return mdmApiManager.captureScreen();
    }
}

```

2.给每一个方法添加注释 @see 表示app 可以调用 @hide 表示隐藏 app不能调用  
 3.编译步骤  
 source build/envsetup.sh  
 lunch  
 make update-api  
 4. app调用  
 import android.mom.MyPower;  
 如果没问题就表示成功





