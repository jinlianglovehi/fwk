






### 1.概述


在10.0的系统产品开发中，对于产品开发中，对于一些重要进程，是不想被系统在低内存的情况下，杀掉进程，  
 所以需要把进程加入白名单，在系统杀进程的时候，不去杀掉进程


### 2.进程加入白名单,避免被杀掉的核心类



```
bsp/kernel/kernel4.14/drivers/staging/android/lowmemorykiller.c

```

### 3.进程加入白名单,避免被杀掉核心功能分析和实现


功能分析：  
 Android底层还是基于Linux，在Linux中低内存是会有oom  
 killer去杀掉一些进程去释放内存，而Android中的lowmemorykiller就是在此基础上做了一些调整来的。因为手机上的内存毕竟比较有限，而Android中APP在不使用之后并不是马上被杀掉，虽然上层ActivityManagerService中也有很多关于进程的调度以及杀进程的手段，但是毕竟还需要考虑手机剩余内存的实际情况，  
 lowmemorykiller的作用就是当内存比较紧张的时候去及时杀掉一些ActivityManagerService还没来得及杀掉但是对用户来说不那么重要的进程，回收一些内存，保证手机的正常运行。  
 所以来看下lowmemorykiller.c的源码了  
 路径:bsp/kernel/kernel4.14/drivers/staging/android/lowmemorykiller.c


当内存紧张时，会根据当前剩余内存，来查看对应的minfree的等级 来调用long lowmem\_scan搜索符合的进程 来杀掉进程



```
static unsigned long lowmem_scan(struct shrinker *s, struct shrink_control *sc)
{
	struct task_struct *tsk;
	struct task_struct *selected = NULL;
	unsigned long rem = 0;
	int selected_process_uid = 0;
	int selected_process_pid = 0;
	int selected_process_adj = 0;
	int tasksize;
	int i;
	int ret = 0;
	int pressure = 0;
	short min_score_adj = OOM_SCORE_ADJ_MAX + 1;
	int minfree = 0;
	int selected_tasksize = 0;
	short selected_oom_score_adj;
	int array_size = ARRAY_SIZE(lowmem_adj);
	int other_free;
	int other_file;
	struct sysinfo si;
	int other_file_orig;

	/* work around for antutu */
	struct task_struct *selected_antutu = NULL;
	int selected_antutu_tasksize = 0;
	short selected_antutu_adj = -1000;
	bool has_antutu_3D = false;

#ifdef CONFIG\_ANDROID\_LOW\_MEMORY\_KILLER\_MEMINFO
	static DEFINE_RATELIMIT_STATE(lmk_rs, DEFAULT_RATELIMIT_INTERVAL, 1);
#endif

#ifdef CONFIG\_E\_SHOW\_MEM
	/* 600s */
	static DEFINE_RATELIMIT_STATE(lmk_mem_rs,
		DEFAULT_RATELIMIT_INTERVAL * 12 * 10, 1);
	static DEFINE_RATELIMIT_STATE(lmk_meminfo_rs,
		DEFAULT_RATELIMIT_INTERVAL * 12, 1);
#endif
	if (!mutex_trylock(&scan_mutex))
		return 0;

#ifdef CONFIG\_LOWMEM\_NOTIFY\_KOBJ
	lowmem_notif_sc.gfp_mask = sc->gfp_mask;
	if (get_free_ram(&other_free, &other_file_orig, &other_file, sc)) {
		if (mutex_is_locked(&kernfs_mutex))
			msleep(1);

		if (!mutex_is_locked(&kernfs_mutex))
			lowmem_notify_killzone_approach();
		else
			lowmem_print(1, "skip as kernfs\_mutex is locked.");
	}
#else
	get_current_ram(&other_free, &other_file_orig, &other_file, sc);
#endif

	if (lowmem_adj_size < array_size)
		array_size = lowmem_adj_size;
	if (lowmem_minfree_size < array_size)
		array_size = lowmem_minfree_size;
	for (i = 0; i < array_size; i++) {
		minfree = lowmem_minfree[i];
		if (other_free < minfree && other_file < minfree) {
			min_score_adj = lowmem_adj[i];
			break;
		}
	}

	ret = adjust_minadj(&min_score_adj, &pressure);

	lowmem_print(3, "lowmem\_scan %lu, %x, ofree %d %d, ma %hd\n",
			sc->nr_to_scan, sc->gfp_mask, other_free,
			other_file, min_score_adj);

	if (min_score_adj == OOM_SCORE_ADJ_MAX + 1) {
		trace_almk_shrink(0, ret, other_free, other_file, 0);
		lowmem_print(5, "lowmem\_scan %lu, %x, return 0\n",
			     sc->nr_to_scan, sc->gfp_mask);
		mutex_unlock(&scan_mutex);
		return 0;
	}

	selected_oom_score_adj = min_score_adj;

	rcu_read_lock();
       // 查询每一个进程
	for_each_process(tsk) {
		struct task_struct *p;
		short oom_score_adj;

+        //lowmem_print(1,“mtk jump lowmemorykiller_1 tsk->comm=%s”,tsk->comm);
+        /* begin  查找到进程名称相同的就continue /  
+        if((strstr(tsk->comm,“app:mainprocess”)!=NULL)
+ {
+ lowmem\_print(1,“lowmemorykiller jump kill ‘emui:screenshot’ \n”);
+ continue;
+ }
+ / end \*/
+ 
 if (tsk->flags & PF\_KTHREAD)
 continue;

 if (time\_before\_eq(jiffies, lowmem\_deathpending\_timeout)) {
			if (test_task_flag(tsk, TIF_MEMDIE)) {
				rcu_read_unlock();
				mutex_unlock(&scan_mutex);
				return 0;
			}
		}

		/* workaround for cts case:CtsMediaTestCases
		 * vmpressure is disable in GMS version when run cts.
		 * so this is for gsi version.
		 */
		if (pressure > 0 && strstr(tsk->comm, "decTestProcess"))
			continue;

		p = find_lock_task_mm(tsk);
		if (!p)
			continue;

		if (p->signal->flags & SIGNAL_GROUP_EXIT) {
			lowmem_print(2, "'%s' (%d:%d) group exit, skip.\n",
				     p->comm, p->pid, p->tgid);
			task_unlock(p);
			continue;
		}

		/* workaround for antutu */
		if (strstr("com.antutu.benchmark.full", p->comm))
			has_antutu_3D = true;

		oom_score_adj = p->signal->oom_score_adj;
		if (oom_score_adj < min_score_adj) {
			task_unlock(p);
			continue;
		}
		tasksize = get_mm_rss(p->mm);
		task_unlock(p);
		if (tasksize <= 0)
			continue;
		if (selected) {
			if (oom_score_adj < selected_oom_score_adj)
				continue;
			if (oom_score_adj == selected_oom_score_adj &&
			    tasksize <= selected_tasksize)
				continue;
		}
		/* workaround for antutu */
		if (!selected_antutu &&
		    strstr("com.antutu.ABenchMark", p->comm)) {
			selected_antutu = p;
			selected_antutu_tasksize = tasksize;
			selected_antutu_adj = oom_score_adj;
			continue;
		}
		selected = p;
		selected_tasksize = tasksize;
		selected_oom_score_adj = oom_score_adj;
		lowmem_print(2, "select '%s' (%d), adj %hd, size %d, to kill\n",
			     p->comm, p->pid, oom_score_adj, tasksize);
	}
	/* workaround for antutu:
	 * if 3D task is not exist, check if the antutu task is more suited
	 * to be killed
	 */
	if (selected && selected_antutu && !has_antutu_3D) {
		if (selected_antutu_adj > selected_oom_score_adj ||
		    (selected_antutu_adj == selected_oom_score_adj &&
		    selected_antutu_tasksize > selected_tasksize)) {
			selected = selected_antutu;
			selected_tasksize = selected_antutu_tasksize;
			selected_oom_score_adj = selected_antutu_adj;
		}
	}
	if (selected) {
		long cache_size = other_file * (long)(PAGE_SIZE / 1024);
		long cache_size_orig = other_file_orig * (long)(PAGE_SIZE / 1024);
		long cache_limit = minfree * (long)(PAGE_SIZE / 1024);
		long free = other_free * (long)(PAGE_SIZE / 1024);

		if (test_task_flag(selected, TIF_MEMDIE) &&
		    (test_task_state(selected, TASK_UNINTERRUPTIBLE))) {
			lowmem_print(2, "'%s' (%d) is already killed\n",
				     selected->comm,
				     selected->pid);
			rcu_read_unlock();
			mutex_unlock(&scan_mutex);
			return 0;
		}

		task_lock(selected);
		/* add for lmfs */
		selected_process_uid = from_kuid(&init_user_ns,
						 selected->cred->uid);
		selected_process_pid = selected->pid;
		selected_process_adj = selected_oom_score_adj;

		send_sig(SIGKILL, selected, 0);
		/*
		 * FIXME: lowmemorykiller shouldn't abuse global OOM killer
 \* infrastructure. There is no real reason why the selected
 \* task should have access to the memory reserves.
 \*/
 if (selected->mm)
 mark\_oom\_victim(selected);
 task\_unlock(selected);
 trace\_lowmemory\_kill(selected, cache\_size, cache\_limit, free);
 si\_swapinfo(&si);
 lowmem\_print(1, "Killing '%s' (%d:%d), adj %hd,\n"
 " to free %ldkB on behalf of '%s' (%d) because\n"
 "   cache is %ldkB , limit is %ldkB for oom_score_adj %hd\n"
 "   Free memory is %ldkB above reserved\n"
 "   swaptotal is %ldkB, swapfree is %ldkB, pressure is %d\n"
 "   cache_orig is %ldkB\n",
 selected->comm, selected->pid, selected->tgid,
 selected\_oom\_score\_adj,
 selected\_tasksize \* (long)(PAGE\_SIZE / 1024),
 current->comm, current->pid,
 cache\_size, cache\_limit,
 min\_score\_adj, free,
 si.totalswap \* (long)(PAGE\_SIZE / 1024),
 si.freeswap \* (long)(PAGE\_SIZE / 1024),
 pressure, cache\_size\_orig);
 lowmem\_deathpending\_timeout = jiffies + HZ;
 rem += selected\_tasksize;
 trace\_almk\_shrink(selected\_tasksize, ret,
 other\_free, other\_file, selected\_oom\_score\_adj);
 } else {
 trace\_almk\_shrink(1, ret, other\_free, other\_file, 0);
 }
 rcu\_read\_unlock();
 mutex\_unlock(&scan\_mutex);

 if (selected) {
 send\_killing\_app\_info\_to\_user(selected\_process\_uid,
 selected\_process\_pid,
 selected\_process\_adj);

#ifdef CONFIG\_ANDROID\_LOW\_MEMORY\_KILLER\_MEMINFO
 if (\_\_ratelimit(&lmk\_rs))
 dump\_tasks\_info();
#endif

#ifdef CONFIG\_E\_SHOW\_MEM
 if ((0 == min\_score\_adj)
 && (\_\_ratelimit(&lmk\_meminfo\_rs))) {
 enhanced\_show\_mem(E\_SHOW\_MEM\_ALL);
 } else if (\_\_ratelimit(&lmk\_mem\_rs)) {
 if ((!si.freeswap)
 || ((si.totalswap / (si.freeswap + 1)) >= 10))
 enhanced\_show\_mem(E\_SHOW\_MEM\_CLASSIC);
 else
 enhanced\_show\_mem(E\_SHOW\_MEM\_BASIC);
 } else if (process\_need\_show\_memory(selected->comm)) {
 enhanced\_show\_mem(E\_SHOW\_MEM\_ALL);
 }
#endif
 }
 lowmem\_print(4, "lowmem_scan %lu, %x, return %lu\n",
		     sc->nr_to_scan, sc->gfp_mask, rem);
	return rem;
}

```

在lowmemorykiller.c中的lowmem\_scan(struct shrinker \*s, struct shrink\_control \*sc)主要是当系统的内存在不足的情况下  
 根据对应的minfree的等级 来先杀掉等级低的进程，所以可以在  
 在for\_each\_process(tsk)中过滤掉进程名称就可以了 编译验证发现功能实现了


在app的activity中设置进程名称



```
<activity android:name=".MainActivity"
            android:process="app:mainprocess">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

```

在app中设置进程属性android:process=“app:mainprocess” 来设置进程名称，





