



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.Settings主页面去掉FocusRecyclerView相关功能的核心代码](#%C2%A02.Settings%E4%B8%BB%E9%A1%B5%E9%9D%A2%E5%8E%BB%E6%8E%89FocusRecyclerView%E7%9B%B8%E5%85%B3%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.Settings主页面去掉FocusRecyclerView相关功能的核心代码功能分析](#3.Settings%E4%B8%BB%E9%A1%B5%E9%9D%A2%E5%8E%BB%E6%8E%89FocusRecyclerView%E7%9B%B8%E5%85%B3%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 ContextualCardsFragment.java关于FocusRecyclerView的相关代码](#%C2%A0%C2%A0%203.1%20ContextualCardsFragment.java%E5%85%B3%E4%BA%8EFocusRecyclerView%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.2 settings\_homepage.xml的代码](#3.2%20settings_homepage.xml%E7%9A%84%E4%BB%A3%E7%A0%81)


[3.3 SettingsHomepageActivity.java关于FocusRecyclerView的相关布局](#3.3%20SettingsHomepageActivity.java%E5%85%B3%E4%BA%8EFocusRecyclerView%E7%9A%84%E7%9B%B8%E5%85%B3%E5%B8%83%E5%B1%80)


[4.根据上述分析功能实现](#4.%E6%A0%B9%E6%8D%AE%E4%B8%8A%E8%BF%B0%E5%88%86%E6%9E%90%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)




---



## 1.概述


  在Settings主页面一级菜单中，在开启护眼模式和改变系统密度会在网络菜单头部增加 自定义您的设备和设置护眼模式时间安排 等等相关的设置模块 这对于菜单布局显示相当不美观，所以根据系统定制要求需要去掉这部分功能，这就需要根据显示流程来分析这部分功能


效果图:


![](https://img-blog.csdnimg.cn/ba1a5953f0f14b3abf631b24e9cdd2a2.png)


##  2.Settings主页面去掉FocusRecyclerView相关功能的核心代码



```
   packages/apps/Settings/src/com/android/settings/homepage/contextualcards/ContextualCardsFragment.java
   packages/apps/Settings/res/layout/settings_homepage.xml
   packages/apps/Settings/src/com/android/settings/homepage/SettingsHomepageActivity.java
```

## 3.Settings主页面去掉FocusRecyclerView相关功能的核心代码功能分析



在系统Settings的开发中，在通过系统源码发现  
 Android系统设置的主界面是com.android.settings.Settings, 但是它只是一个activity-alias,  
 指向的是com.android.settings.Settings.homepage.SettingsHomepageActivity  
 从清单文件AndroidManifest.xml可以发现targetActivity属性，实质应是SettingsHomepageActivity.java。  
 Settings应用UI布局主要是在SettingsHomepageActivity中加载的  
 DEFAULT LAUNCHER属性就说明SettingsHomepageActivity正是设置apk启动的主页activity  
 onCreate()方法中，我们可以看出是有两部分组成：1、头部搜索框。2、一级菜单选项  
 在可以看到主界面的layout为settings\_homepage\_container.xml中  
 一级菜单选项滑动主要是采用NestedScrollView控件。顶部搜索框则采用AppBarLayout控件


##    3.1 ContextualCardsFragment.java关于FocusRecyclerView的相关代码



```
   public class ContextualCardsFragment extends InstrumentedFragment implements
        FocusRecyclerView.FocusListener {

    private FocusRecyclerView mCardsContainer;
    private GridLayoutManager mLayoutManager;
    private ContextualCardsAdapter mContextualCardsAdapter;
    private ContextualCardManager mContextualCardManager;
    private ItemTouchHelper mItemTouchHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Context context = getContext();
        if (savedInstanceState == null) {
            FeatureFactory.getFactory(context).getSlicesFeatureProvider().newUiSession();
        }
        mContextualCardManager = new ContextualCardManager(context, getSettingsLifecycle(),
                savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();
        ContextualWifiScanWorker.newVisibleUiSession();
        mContextualCardManager.loadContextualCards(LoaderManager.getInstance(this));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        final Context context = getContext();
        final View rootView = inflater.inflate(R.layout.settings_homepage, container, false);
        mCardsContainer = rootView.findViewById(R.id.card_container);
        mLayoutManager = new GridLayoutManager(getActivity(), SPAN_COUNT,
                GridLayoutManager.VERTICAL, false /* reverseLayout */);
        mCardsContainer.setLayoutManager(mLayoutManager);
        mContextualCardsAdapter = new ContextualCardsAdapter(context, this /* lifecycleOwner */,
                mContextualCardManager);
        mCardsContainer.setAdapter(mContextualCardsAdapter);
        mContextualCardManager.setListener(mContextualCardsAdapter);
        mCardsContainer.setListener(this);
        closeDefaultAnimator();
        mItemTouchHelper = new ItemTouchHelper(new SwipeDismissalDelegate(mContextualCardsAdapter));
        mItemTouchHelper.attachToRecyclerView(mCardsContainer);

        return rootView;
    }

    //Close animations of RecycleView
    private void closeDefaultAnimator() {
        mCardsContainer.getItemAnimator().setAddDuration(0);
        mCardsContainer.getItemAnimator().setChangeDuration(0);
        mCardsContainer.getItemAnimator().setMoveDuration(0);
        mCardsContainer.getItemAnimator().setRemoveDuration(0);
        ((SimpleItemAnimator)mCardsContainer.getItemAnimator()).setSupportsChangeAnimations(false);
        mCardsContainer.setLayoutAnimation(null);
        mCardsContainer.setLayoutTransition(null);
        mCardsContainer.clearAnimation();
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        mContextualCardManager.onWindowFocusChanged(hasWindowFocus);
    }

    @Override
    public int getMetricsCategory() {
        return SettingsEnums.SETTINGS_HOMEPAGE;
    }
}
```

在ContextualCardsFragment.java代码中的



```
@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        final Context context = getContext();
        final View rootView = inflater.inflate(R.layout.settings_homepage, container, false);
        mCardsContainer = rootView.findViewById(R.id.card_container);
        mLayoutManager = new GridLayoutManager(getActivity(), SPAN_COUNT,
                GridLayoutManager.VERTICAL, false /* reverseLayout */);
        mCardsContainer.setLayoutManager(mLayoutManager);
        mContextualCardsAdapter = new ContextualCardsAdapter(context, this /* lifecycleOwner */,
                mContextualCardManager);
        mCardsContainer.setAdapter(mContextualCardsAdapter);
        mContextualCardManager.setListener(mContextualCardsAdapter);
        mCardsContainer.setListener(this);
        closeDefaultAnimator();
        mItemTouchHelper = new ItemTouchHelper(new SwipeDismissalDelegate(mContextualCardsAdapter));
        mItemTouchHelper.attachToRecyclerView(mCardsContainer);

        return rootView;
    }
```

  
 onCreateView中，会把FocusRecyclerView的相关布局添加到settings\_homepage中,从而在Settings主页一级菜单中展现出来，所以说系统Settings的主要核心布局就是在


SettingsHomepageActivity中，接下来分析下SettingsHomepageActivity的核心布局页面


settings\_homepage.xml的相关源码


##  3.2 settings\_homepage.xml的代码



```
   <LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical">

    <com.android.settings.homepage.contextualcards.FocusRecyclerView
        android:id="@+id/card_container"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layoutAnimation="@anim/layout_animation_fade_in"
        android:importantForAccessibility="no"/>

</LinearLayout>
```

从settings\_homepage.xml的布局代码发现在com.android.settings.homepage.contextualcards.FocusRecyclerView就是上图中的显示多出来的提醒条目，当系统需要展示其他菜单的时候，就会从FocusRecyclerView的布局中，添加


对应的布局，然后显示出其他菜单布局就可以了


## 3.3 SettingsHomepageActivity.java关于FocusRecyclerView的相关布局



```
   public class SettingsHomepageActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_homepage_container);
        final View root = findViewById(R.id.settings_homepage_container);
        root.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        setHomepageContainerPaddingTop();

        final Toolbar toolbar = findViewById(R.id.search_action_bar);
        FeatureFactory.getFactory(this).getSearchFeatureProvider()
                .initSearchToolbar(this /* activity */, toolbar, SettingsEnums.SETTINGS_HOMEPAGE);

        final ImageView avatarView = findViewById(R.id.account_avatar);
        getLifecycle().addObserver(new AvatarViewMixin(this, avatarView));
        getLifecycle().addObserver(new HideNonSystemOverlayMixin(this));
        findViewById(R.id.search_bar).setVisibility(View.GONE);
        if (!getSystemService(ActivityManager.class).isLowRamDevice()) {
            // Only allow contextual feature on high ram devices.
            showFragment(new ContextualCardsFragment(), R.id.contextual_cards_content);
        }
        showFragment(new TopLevelSettings(), R.id.main_content);
        ((FrameLayout) findViewById(R.id.main_content))
                .getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
    }

    private void showFragment(Fragment fragment, int id) {
        final FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        final Fragment showFragment = fragmentManager.findFragmentById(id);

        if (showFragment == null) {
            fragmentTransaction.add(id, fragment);
        } else {
            fragmentTransaction.show(showFragment);
        }
        fragmentTransaction.commit();
    }
```

在onCreate()中会判断是否开启护眼模式等相关操作来显示FocusRecyclerView布局  
         if (!getSystemService(ActivityManager.class).isLowRamDevice()) {  
             // Only allow contextual feature on high ram devices.  
             showFragment(new ContextualCardsFragment(), R.id.contextual\_cards\_content);  
         }


## 4.根据上述分析功能实现



```
 在settings_homepage.xml中修改
  <LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical">

    <com.android.settings.homepage.contextualcards.FocusRecyclerView
        android:id="@+id/card_container"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
     + android:visibility="gone"
        android:layoutAnimation="@anim/layout_animation_fade_in"
        android:importantForAccessibility="no"/>

</LinearLayout>
```



