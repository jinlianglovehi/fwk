



## 1.前言


在10.0的系统rom产品定制化开发中，在定制化开发中，需要在锁屏页面弹窗功能，当收到某些信息的时候，需要添加 悬浮窗锁屏页面也同样需要弹窗功能，接下来就分析下相关功能，然后实现功能


![](https://img-blog.csdnimg.cn/direct/f849230ea5b6460f92b82cd15aa48382.png)


## 2.锁屏页面弹窗功能实现的核心类



```
frameworks\base\core\java\android\view\WindowManager.java
frameworks\base\packages\SystemUI\src\com\android\systemui\globalactions\GlobalActionsDialog.java

```

## 3.锁屏页面弹窗功能实现的核心功能分析和实现


WindowManager是Android系统中的关键系统服务，它管理应用程序窗口的显示、布局、位置、大小和层级等属性。 WindowManager的作用 WindowManager在Android系统中扮演了以下关键角色： 窗口管理：WindowManager管理所有应用程序窗口的显示和布局，确保窗口按正确顺序叠放，以便用户与它们交互。 位置和大小控制：WindowManager允许您控制窗口的位置和大小，这对于创建自定义窗口、悬浮窗口或弹出对话框非常有用。 窗口类型和层级：通过使用窗口类型和层级，WindowManager控制窗口的属性，例如指定窗口是应用程序窗口、系统窗口还是子窗口，并设置其显示层级 在Android应用中,弹窗(Dialog)是一种常用的界面元素,用于在用户操作过程中提供信息、警示、确认等功能 在systemui中，关机弹窗也就是在GlobalActionsDialog.java中实现的


## 3.1 WindowManager.java关于弹窗属性的相关分析


在实现锁屏页面弹窗功能实现的核心功能中，通过上述的分析得知， 在WindowManager.java中的相关源码中，核心功能负责窗口属性的管理，包括悬浮窗的相关属性设置 接下来分析下相关的源码



```
 public static class LayoutParams extends ViewGroup.LayoutParams implements Parcelable {

        /**
         * Start of system-specific window types.  These are not normally
         * created by applications.
         */
        public static final int FIRST_SYSTEM_WINDOW     = 2000;

        /**
         * Window type: the status bar.  There can be only one status bar
         * window; it is placed at the top of the screen, and all other
         * windows are shifted down so they are below it.
         * In multiuser systems shows on all users' windows.
         */
        public static final int TYPE_STATUS_BAR         = FIRST_SYSTEM_WINDOW;

        /**
         * Window type: the search bar.  There can be only one search bar
         * window; it is placed at the top of the screen.
         * In multiuser systems shows on all users' windows.
         */
        public static final int TYPE_SEARCH_BAR         = FIRST_SYSTEM_WINDOW+1;

        /**
         * Window type: phone.  These are non-application windows providing
         * user interaction with the phone (in particular incoming calls).
         * These windows are normally placed above all applications, but behind
         * the status bar.
         * In multiuser systems shows on all users' windows.
         * @deprecated for non-system apps. Use {@link #TYPE_APPLICATION_OVERLAY} instead.
         */
        @Deprecated
        public static final int TYPE_PHONE              = FIRST_SYSTEM_WINDOW+2;

        /**
         * Window type: system window, such as low power alert. These windows
         * are always on top of application windows.
         * In multiuser systems shows only on the owning user's window.
         * @deprecated for non-system apps. Use {@link #TYPE_APPLICATION_OVERLAY} instead.
         */
        @Deprecated
        public static final int TYPE_SYSTEM_ALERT       = FIRST_SYSTEM_WINDOW+3;

        /**
         * Window type: keyguard window.
         * In multiuser systems shows on all users' windows.
         * @removed
         */
        public static final int TYPE_KEYGUARD           = FIRST_SYSTEM_WINDOW+4;

        /**
         * Window type: transient notifications.
         * In multiuser systems shows only on the owning user's window.
         * @deprecated for non-system apps. Use {@link #TYPE_APPLICATION_OVERLAY} instead.
         */
        @Deprecated
        public static final int TYPE_TOAST              = FIRST_SYSTEM_WINDOW+5;

        /**
         * Window type: the drag-and-drop pseudowindow.  There is only one
         * drag layer (at most), and it is placed on top of all other windows.
         * In multiuser systems shows only on the owning user's window.
         * @hide
         */
        public static final int TYPE_DRAG               = FIRST_SYSTEM_WINDOW+16;

        /**
         * Window type: panel that slides out from over the status bar
         * In multiuser systems shows on all users' windows. These windows
         * are displayed on top of the stauts bar and any {@link #TYPE_STATUS_BAR_PANEL}
         * windows.
         * @hide
         */
        public static final int TYPE_STATUS_BAR_SUB_PANEL = FIRST_SYSTEM_WINDOW+17;

        /**
         * Window type: (mouse) pointer
         * In multiuser systems shows on all users' windows.
         * @hide
         */
        public static final int TYPE_POINTER = FIRST_SYSTEM_WINDOW+18;

        /**
         * Window type: Navigation bar (when distinct from status bar)
         * In multiuser systems shows on all users' windows.
         * @hide
         */
        public static final int TYPE_NAVIGATION_BAR = FIRST_SYSTEM_WINDOW+19;

        /**
         * Window type: The volume level overlay/dialog shown when the user
         * changes the system volume.
         * In multiuser systems shows on all users' windows.
         * @hide
         */
        public static final int TYPE_VOLUME_OVERLAY = FIRST_SYSTEM_WINDOW+20;

        /**
         * Window type: The boot progress dialog, goes on top of everything
         * in the world.
         * In multiuser systems shows on all users' windows.
         * @hide
         */
        public static final int TYPE_BOOT_PROGRESS = FIRST_SYSTEM_WINDOW+21;
```

在实现锁屏页面弹窗功能实现的核心功能中，通过上述的分析得知， 在WindowManager.java中的相关源码中，关于在使用window.setType(WindowManager.LayoutParams.TYPE\_APPLICATION\_OVERLAY); 的类型中，悬浮窗弹窗的类型设置，上述的这些类型都是可以作为悬浮窗类型的， 有些由于@hide所以就只有系统级别的app可以调用到，普通app是调用不到的，


## 3.2 GlobalActionsDialog.java中相关锁屏页面关机弹窗相关功能的分析


在实现锁屏页面弹窗功能实现的核心功能中，通过上述的分析得知， 在GlobalActionsDialog.java中的相关源码中，通过分析得知，在这个类里面主要就是 当收到长按电源键的事件后弹出关机对话框，在锁屏页面同样也是可以弹出关机对话框的 接下来分析下相关源码



```
  ActionsDialog(Context context, MyAdapter adapter, MyOverflowAdapter overflowAdapter,
                GlobalActionsPanelPlugin.PanelViewController walletViewController,
                NotificationShadeDepthController depthController,
                SysuiColorExtractor sysuiColorExtractor, IStatusBarService statusBarService,
                NotificationShadeWindowController notificationShadeWindowController,
                boolean controlsAvailable, @Nullable ControlsUiController controlsUiController,
                SysUiState sysuiState, Runnable onRotateCallback, boolean keyguardShowing,
                MyPowerOptionsAdapter powerAdapter) {
            super(context, com.android.systemui.R.style.Theme_SystemUI_Dialog_GlobalActions);
            mContext = context;
            mAdapter = adapter;
            mOverflowAdapter = overflowAdapter;
            mPowerOptionsAdapter = powerAdapter;
            mDepthController = depthController;
            mColorExtractor = sysuiColorExtractor;
            mStatusBarService = statusBarService;
            mNotificationShadeWindowController = notificationShadeWindowController;
            mControlsAvailable = controlsAvailable;
            mControlsUiController = controlsUiController;
            mSysUiState = sysuiState;
            mOnRotateCallback = onRotateCallback;
            mKeyguardShowing = keyguardShowing;

            // Window initialization
            Window window = getWindow();
            window.requestFeature(Window.FEATURE_NO_TITLE);
            // Inflate the decor view, so the attributes below are not overwritten by the theme.
            window.getDecorView();
            window.getAttributes().systemUiVisibility |= View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.setLayout(MATCH_PARENT, MATCH_PARENT);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                            | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
            window.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            window.getAttributes().setFitInsetsTypes(0 /* types */);
            setTitle(R.string.global_actions);

            mWalletViewController = walletViewController;
            initializeLayout();
        }
```

在实现锁屏页面弹窗功能实现的核心功能中，通过上述的分析得知， 在GlobalActionsDialog.java中的相关源码中，通过分析得知，在ActionsDialog 的构造方法中，主要处理弹关机对话框的功能，在这里也主要是通过悬浮窗的形式 弹出关机对话框的，在构造方法中，在window.addFlags中添加WindowManager.LayoutParams.FLAG\_SHOW\_WHEN\_LOCKED 和在window.setType(WindowManager.LayoutParams.TYPE\_APPLICATION\_OVERLAY);这两个核心属性 就可以保证在锁屏页面长按电源键同时也可以弹出关机对话框功能，所以锁屏页面弹出悬浮窗功能，同样 也可以参照这样的方法来实现功能



