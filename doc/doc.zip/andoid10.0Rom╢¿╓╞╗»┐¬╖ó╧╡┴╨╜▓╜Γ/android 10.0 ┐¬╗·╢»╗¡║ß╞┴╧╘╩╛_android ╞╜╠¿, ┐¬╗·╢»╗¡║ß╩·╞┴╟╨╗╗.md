






### 1.概述


在10.0的产品开发中，系统一般都是竖屏显示的，所以开机动画一般也是竖屏，但是对横屏的产品来说，就需要  
 把开机动画调成横屏显示的，在android 中开机动画这部分主要是bootanimation模块负责处理 开机动画主要由  
 BootAnimation.cpp来负责处理，所以从BootAnimation.cpp查找相关动画方向的源码做修改就好了


### 2.开机动画横屏显示核心类



```
frameworks\base\cmds\bootanimation\BootAnimation.cpp

```

### 3.开机动画横屏显示的核心功能分析


接下来就来看BootAnimation.cpp的相关源码  
 路径:frameworks\base\cmds\bootanimation\BootAnimation.cpp



```

  BootAnimation::BootAnimation(sp<Callbacks> callbacks)
          : Thread(false), mClockEnabled(true), mTimeIsAccurate(false), mTimeFormat12Hour(false),
          mTimeCheckThread(nullptr), mCallbacks(callbacks), mLooper(new Looper(false)) {
      mSession = new SurfaceComposerClient();
  
      std::string powerCtl = android::base::GetProperty("sys.powerctl", "");
      if (powerCtl.empty()) {
          mShuttingDown = false;
      } else {
          mShuttingDown = true;
      }
      ALOGD("%sAnimationStartTiming start time: %" PRId64 "ms", mShuttingDown ? "Shutdown" : "Boot",
              elapsedRealtime());
  }
  
  BootAnimation::~BootAnimation() {
      if (mAnimation != nullptr) {
          releaseAnimation(mAnimation);
          mAnimation = nullptr;
      }
      ALOGD("%sAnimationStopTiming start time: %" PRId64 "ms", mShuttingDown ? "Shutdown" : "Boot",
              elapsedRealtime());
  }
  
  void BootAnimation::onFirstRef() {
      status_t err = mSession->linkToComposerDeath(this);
      SLOGE_IF(err, "linkToComposerDeath failed (%s) ", strerror(-err));
      if (err == NO_ERROR) {
          // Load the animation content -- this can be slow (eg 200ms)
          // called before waitForSurfaceFlinger() in main() to avoid wait
          ALOGD("%sAnimationPreloadTiming start time: %" PRId64 "ms",
                  mShuttingDown ? "Shutdown" : "Boot", elapsedRealtime());
          preloadAnimation();
          ALOGD("%sAnimationPreloadStopTiming start time: %" PRId64 "ms",
                  mShuttingDown ? "Shutdown" : "Boot", elapsedRealtime());
      }
  }
  
  sp<SurfaceComposerClient> BootAnimation::session() const {
      return mSession;
  }
  
  
  status_t BootAnimation::initTexture(Texture* texture, AssetManager& assets,
          const char* name) {
      Asset* asset = assets.open(name, Asset::ACCESS_BUFFER);
      if (asset == nullptr)
          return NO_INIT;
      SkBitmap bitmap;
      sk_sp<SkData> data = SkData::MakeWithoutCopy(asset->getBuffer(false),
              asset->getLength());
      sk_sp<SkImage> image = SkImage::MakeFromEncoded(data);
      image->asLegacyBitmap(&bitmap, SkImage::kRO_LegacyBitmapMode);
      asset->close();
      delete asset;
  
      const int w = bitmap.width();
      const int h = bitmap.height();
      const void* p = bitmap.getPixels();
  
      GLint crop[4] = { 0, h, w, -h };
      texture->w = w;
      texture->h = h;
  
      glGenTextures(1, &texture->name);
      glBindTexture(GL_TEXTURE_2D, texture->name);
  
      switch (bitmap.colorType()) {
          case kAlpha_8_SkColorType:
              glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, w, h, 0, GL_ALPHA,
                      GL_UNSIGNED_BYTE, p);
              break;
          case kARGB_4444_SkColorType:
              glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                      GL_UNSIGNED_SHORT_4_4_4_4, p);
              break;
          case kN32_SkColorType:
              glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                      GL_UNSIGNED_BYTE, p);
              break;
          case kRGB_565_SkColorType:
              glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                      GL_UNSIGNED_SHORT_5_6_5, p);
              break;
          default:
              break;
      }
  
      glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
      glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
      glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
      glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  
      return NO_ERROR;
  }
  
status_t BootAnimation::readyToRun() {
mAssets.addDefaultAssets();
mDisplayToken = SurfaceComposerClient::getInternalDisplayToken();
if (mDisplayToken == nullptr)
return -1;
DisplayInfo dinfo;
status_t status = SurfaceComposerClient::getDisplayInfo(mDisplayToken, &dinfo);
if (status)
return -1;
// create the native surface
sp<SurfaceControl> control = session()->createSurface(String8("BootAnimation"),
dinfo.h, dinfo.w, PIXEL_FORMAT_RGB_565);
SurfaceComposerClient::Transaction t;
t.setLayer(control, 0x40000000)
.apply();
sp<Surface> s = control->getSurface();
// initialize opengl and egl
const EGLint attribs[] = {
EGL_RED_SIZE,   8,
EGL_GREEN_SIZE, 8,
EGL_BLUE_SIZE,  8,
EGL_DEPTH_SIZE, 0,
EGL_NONE
};
EGLint w, h;
EGLint numConfigs;
EGLConfig config;
EGLSurface surface;
EGLContext context;
EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
eglInitialize(display, nullptr, nullptr);
eglChooseConfig(display, attribs, &config, 1, &numConfigs);
surface = eglCreateWindowSurface(display, config, s.get(), nullptr);
context = eglCreateContext(display, config, nullptr, nullptr);
eglQuerySurface(display, surface, EGL_WIDTH, &w);
eglQuerySurface(display, surface, EGL_HEIGHT, &h);
if (eglMakeCurrent(display, surface, surface, context) == EGL_FALSE)
return NO_INIT;
mDisplay = display;
mContext = context;
mSurface = surface;
mWidth = w;
mHeight = h;
mFlingerSurfaceControl = control;
mFlingerSurface = s;
mTargetInset = -1;
SLOGD("Get Surface mWidth is %d,mHeight is %d",mWidth,mHeight);
return NO_ERROR;
}

```

而在BootAnimation.cpp中启动开机动画后，会在readyToRun(）中绘制开机动画显示在屏幕上，而  
 sp control = session()->createSurface(String8(“BootAnimation”),  
 dinfo.h, dinfo.w, PIXEL\_FORMAT\_RGB\_565);  
 就是负责绘制开机动画的相关参数，宽高和rgb值  
 而readyToRun() 负责构建开机动画 createSurface()负责绘制开机动画页面  
 所以修改开机动画横屏就要在这里修改如下:  
 sp control = session()->createSurface(String8(“BootAnimation”),  
 dinfo.h, dinfo.w, PIXEL\_FORMAT\_RGB\_565);  
 修改为：



```
//比较屏幕宽和高
sp<SurfaceControl> control;
if(dinfo.w < dinfo.h)
    control = session()->createSurface(String8("BootAnimation"),
        dinfo.h, dinfo.w, PIXEL_FORMAT_RGB_565);
else
control = session()->createSurface(String8("BootAnimation"),
        dinfo.w, dinfo.h, PIXEL_FORMAT_RGB_565);

```




