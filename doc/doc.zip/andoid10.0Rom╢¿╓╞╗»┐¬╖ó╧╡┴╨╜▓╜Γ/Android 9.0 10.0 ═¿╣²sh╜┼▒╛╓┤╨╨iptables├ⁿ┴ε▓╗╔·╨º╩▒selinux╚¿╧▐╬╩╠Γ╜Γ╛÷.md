






在开发网络白名单用iptables命令时，会涉及到selinux权限的问题，会让命令失效不起作用  
 例如:在init.rc中通过监听属性值变化来执行sh 脚本



```
on property:persist.sys.runstart=1
     setprop persist.sys.runstart 0
     start runcommandstart

service runcommandstart /system/bin/sh /data/local/command.sh
    user root
    group root
    seclabel u:r:shell :s0
    disabled
    oneshot

```

当设置persist.sys.runstart为1时 执行command.sh脚本


command.sh脚本：



```
#!/system/bin/sh
iptables -F
iptables -t nat -F
ipset flush
iptables -P OUTPUT ACCEPT
ipset -N iplist iphash
iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -s 127.0.0.1 -d 127.0.0.1 -j ACCEPT
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT
iptables -A OUTPUT -m set --match-set iplist dst -j ACCEPT
iptables -A OUTPUT -m string --string Host: --algo bm -j MARK --set-mark 1

```

但是通过iptables -L 发现iptables命令并没有生成  
 最后通过  
 adb shell Command：  
 cat /proc/kmsg | grep avc 或 dmesg | grep avc  
 通过查询log得知:  
 avc: denied { open } for pid=8600 comm=“sh” path=“/data/local/firewall.sh” dev=“mmcblk0p42” ino=184 scontext=u:r:shell :s0 tcontext=u:object\_r:system\_data\_file:s0 tclass=file permissive=0


分析过程：  
 缺少什么权限： { open }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:object\_r:system\_data\_file:s0  
 什么类型的文件： tclass=file


解决方法：在shell.te中添加权限



```
allow shell system_data_file:file open;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


avc: denied { net\_raw } for pid=8829 comm=“iptables” capability=13 scontext=u:r:shell :s0 tcontext=u:r:shell :s0 tclass=capability permissive=0  
 分析过程：  
 缺少什么权限： { net\_raw }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:r:shell :s0  
 什么类型的文件： tclass=capability  
 解决方法：在shell.te中添加权限



```
allow shell shell:capability net_raw;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


avc: denied { create } for pid=8799 comm=“ipset” scontext=u:r:shell :s0 tcontext=u:r:shell :s0 tclass=netlink\_netfilter\_socket permissive=0  
 分析过程：  
 缺少什么权限： { create }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:r:shell :s0  
 什么类型的文件： tclass=netlink\_netfilter\_socket  
 解决方法：在shell.te中添加权限



```
allow shell shell:netlink_netfilter_socket create;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


avc: denied { bind } for pid=8799 comm=“ipset” scontext=u:r:shell :s0 tcontext=u:r:shell :s0 tclass=netlink\_netfilter\_socket permissive=0  
 分析过程：  
 缺少什么权限： { bind }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:r:shell :s0  
 什么类型的文件： tclass=netlink\_netfilter\_socket  
 解决方法：在shell.te中添加权限



```
allow shell shell:netlink_netfilter_socket bind;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


avc: denied { getattr } for pid=8799 comm=“ipset” scontext=u:r:shell :s0 tcontext=u:r:shell :s0 tclass=netlink\_netfilter\_socket permissive=0  
 分析过程：  
 缺少什么权限： { getattr }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:r:shell :s0  
 什么类型的文件： tclass=netlink\_netfilter\_socket  
 解决方法：在shell.te中添加权限



```
allow shell shell:netlink_netfilter_socket getattr;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


avc: denied { write } for pid=8799 comm=“ipset” scontext=u:r:shell :s0 tcontext=u:r:shell :s0 tclass=netlink\_netfilter\_socket permissive=0  
 分析过程：  
 缺少什么权限： { write }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:r:shell :s0  
 什么类型的文件： tclass=netlink\_netfilter\_socket  
 解决方法：在shell.te中添加权限



```
allow shell shell:netlink_netfilter_socket write;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


avc: denied { read } for pid=8799 comm=“ipset” scontext=u:r:shell :s0 tcontext=u:r:shell :s0 tclass=netlink\_netfilter\_socket permissive=0  
 分析过程：  
 缺少什么权限： { read }权限，  
 谁缺少权限： scontext=u:r:shell :s0，  
 对哪个文件缺少权限：tcontext=u:r:shell :s0  
 什么类型的文件： tclass=netlink\_netfilter\_socket  
 解决方法：在shell.te中添加权限



```
allow shell shell:netlink_netfilter_socket read;

```

system\sepolicy\public\shell.te  
 和system\sepolicy\prebuilts\api\29.0\public\shell.te


system/sepolicy/public/shell.te和system\sepolicy\prebuilts\api\29.0\public\shell.te  
 最终修改



```
+allow shell system_data_file:file open;
+allow shell shell:netlink_netfilter_socket { create bind getattr write read };
+allow shell shell:capability { net_raw net_admin };

```

添加上面的所需要的selinux的权限  
 然后编译发现报错如下:



```
libsepol.report_failure: neverallow on line 371 of system/sepolicy/public/app.te (or line 9437 of policy.conf) violated by allow shell shell:capability { net_admin net_raw };
libsepol.check_assertions: 1 neverallow failures occurred
Error while expanding policy

```

发现neverallow { appdomain -bluetooth -network\_stack } self:capability\_class\_set \* 与 allow shell shell:capability { net\_raw net\_admin };冲突  
 当app.te与shell.te的 capablity发生冲突时，修改neverallow 添加-shell 去掉不允许的权限


system/sepolicy/public/app.te和system/sepolicy/prebuilts/api/29.0/public/app.te最终修改



```
-neverallow { appdomain -bluetooth -network_stack } self:capability_class_set *;
+neverallow { appdomain -bluetooth -network_stack -shell} self:capability_class_set *;

```

最后编译通过，可以正常使用了 iptables命令也生效了 顺利解决问题





