



**目录**



[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.关机对话框UI定制的核心功能](#2.%E5%85%B3%E6%9C%BA%E5%AF%B9%E8%AF%9D%E6%A1%86UI%E5%AE%9A%E5%88%B6%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD)




---


## 1.概述


在10.0的定制化开发中，需要对关机对话框的UI界面进行定制化开发，需要对话框全屏，去掉多余项 保留关机 重启 飞行模式 静音模式等选项 现在开始定制化 首选去掉 截图和紧急呼救选项 实现全屏


![](https://img-blog.csdnimg.cn/a8ad3ae688584cd1818c161552544810.png)



## 2.关机对话框UI定制的核心功能



Android开机的流程,今天简单看下关机的流程。 在长按power键时系统会弹出对话框,让用户选择关机, 重启或者其他模式,关机就从这里开始。 长按Power键调用shutdown()方法


在长按电源开关后会出现一个对话框：静音模式，数据网络模式(数据流开关)，飞行模式，关机


等关键对话框，显示在右边居中的位置，在这个页面中，由于利用Android studio的开发工具等


查询布局的相关java的源码的就是在SystemUI的GlobalActionsDialog.java，在初始化的时候，


首先创建GlobalActions， 然后在showDialog出来，主要的功能实在showDialog中完成的，  
 关机对话框就是GlobalActionsDialog.java  
 路径:frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java



```
/**
     * Create the global actions dialog.
     *
     * @return A new dialog.
     */
    private ActionsDialog createDialog() {
        // Simple toggle style if there's no vibrator, otherwise use a tri-state
        if (!mHasVibrator) {
            mSilentModeAction = new SilentModeToggleAction();
        } else {
            mSilentModeAction = new SilentModeTriStateAction(mAudioManager, mHandler);
        }
        mAirplaneModeOn = new ToggleAction(
                R.drawable.ic_lock_airplane_mode,
                R.drawable.ic_lock_airplane_mode_off,
                R.string.global_actions_toggle_airplane_mode,
                R.string.global_actions_airplane_mode_on_status,
                R.string.global_actions_airplane_mode_off_status) {

            void onToggle(boolean on) {
                if (mHasTelephony && Boolean.parseBoolean(
                        SystemProperties.get(TelephonyProperties.PROPERTY_INECM_MODE))) {
                    mIsWaitingForEcmExit = true;
                    // Launch ECM exit dialog
                    Intent ecmDialogIntent =
                            new Intent(TelephonyIntents.ACTION_SHOW_NOTICE_ECM_BLOCK_OTHERS, null);
                    ecmDialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(ecmDialogIntent);
                } else {
                    changeAirplaneModeSystemSetting(on);
                }
            }

            @Override
            protected void changeStateFromPress(boolean buttonOn) {
                if (!mHasTelephony) return;

                // In ECM mode airplane state cannot be changed
                if (!(Boolean.parseBoolean(
                        SystemProperties.get(TelephonyProperties.PROPERTY_INECM_MODE)))) {
                    mState = buttonOn ? State.TurningOn : State.TurningOff;
                    mAirplaneState = mState;
                }
            }

            public boolean showDuringKeyguard() {
                return true;
            }

            public boolean showBeforeProvisioning() {
                return false;
            }
        };
        onAirplaneModeChanged();

        mItems = new ArrayList<Action>();
        String[] defaultActions = mContext.getResources().getStringArray(
                R.array.config_globalActionsList);

       
            } else if (GLOBAL_ACTION_KEY_VOICEASSIST.equals(actionKey)) {
                mItems.add(getVoiceAssistAction());
            } else if (GLOBAL_ACTION_KEY_ASSIST.equals(actionKey)) {
                mItems.add(getAssistAction());
            } else if (GLOBAL_ACTION_KEY_RESTART.equals(actionKey)) {
                mItems.add(new RestartAction());
            } else if (GLOBAL_ACTION_KEY_SCREENSHOT.equals(actionKey)) {

                //UNISOC: fix for bug 1104146
                if(KeyguardUpdateMonitor.getInstance(mContext).isSecure()
                        && !KeyguardUpdateMonitor.getInstance(mContext).getStrongAuthTracker().hasUserAuthenticatedSinceBoot()) {
                    Log.e(TAG, "Not add screenshot because user hasn't authenticated.");
                    continue;
                }

                /* UNISOC Bug 1074234,939142 remove screenshot when pressing power,in powersave mode @{ */
                if (SprdPowerManagerUtil.SUPPORT_SUPER_POWER_SAVE) {
                   if (!SprdPowerManagerUtil.isSuperPower()) {
                       mItems.add(new ScreenshotAction());
                     }
                } else {
                       mItems.add(new ScreenshotAction());
                }
                /* @} */
            } else if (GLOBAL_ACTION_KEY_LOGOUT.equals(actionKey)) {
                if (mDevicePolicyManager.isLogoutEnabled()
                        && getCurrentUser().id != UserHandle.USER_SYSTEM) {
                    mItems.add(new LogoutAction());
                    mHasLogoutButton = true;
                }
            } else if (GLOBAL_ACTION_KEY_EMERGENCY.equals(actionKey)) {
                if (!mEmergencyAffordanceManager.needsEmergencyAffordance()) {
                    mItems.add(new EmergencyDialerAction());
                }
            } else {
                Log.e(TAG, "Invalid global action key " + actionKey);
            }
            // Add here so we don't add more than one.
            addedKeys.add(actionKey);
        }

        if (mEmergencyAffordanceManager.needsEmergencyAffordance()) {
            mItems.add(new EmergencyAffordanceAction());
        }

        mAdapter = new MyAdapter();

        ....

        ActionsDialog dialog = new ActionsDialog(mContext, mAdapter, panelViewController);
        dialog.setCanceledOnTouchOutside(false); // Handled by the custom class.
        dialog.setKeyguardShowing(mKeyguardShowing);

        dialog.setOnDismissListener(this);
        dialog.setOnShowListener(this);

        return dialog;
    }
```

在createDialog()中构建关机dialog弹窗的内容而通过R.array.config\_globalActionsList来获取哪些Item添加到关机对话框弹窗中，所以去掉截图和紧急呼救选项就从这里面去除


当弹出关机对话框时，加载选项ScreenshotAction截图选项 和 EmergencyAffordanceAction紧急呼救选项  
 所以去掉这两项 修改为:



```
/**
     * Create the global actions dialog.
     *
     * @return A new dialog.
     */
    private ActionsDialog createDialog() {
        // Simple toggle style if there's no vibrator, otherwise use a tri-state
        if (!mHasVibrator) {
            mSilentModeAction = new SilentModeToggleAction();
        } else {
            mSilentModeAction = new SilentModeTriStateAction(mAudioManager, mHandler);
        }
        mAirplaneModeOn = new ToggleAction(
                R.drawable.ic_lock_airplane_mode,
                R.drawable.ic_lock_airplane_mode_off,
                R.string.global_actions_toggle_airplane_mode,
                R.string.global_actions_airplane_mode_on_status,
                R.string.global_actions_airplane_mode_off_status) {

            void onToggle(boolean on) {
                if (mHasTelephony && Boolean.parseBoolean(
                        SystemProperties.get(TelephonyProperties.PROPERTY_INECM_MODE))) {
                    mIsWaitingForEcmExit = true;
                    // Launch ECM exit dialog
                    Intent ecmDialogIntent =
                            new Intent(TelephonyIntents.ACTION_SHOW_NOTICE_ECM_BLOCK_OTHERS, null);
                    ecmDialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(ecmDialogIntent);
                } else {
                    changeAirplaneModeSystemSetting(on);
                }
            }

            @Override
            protected void changeStateFromPress(boolean buttonOn) {
                if (!mHasTelephony) return;

                // In ECM mode airplane state cannot be changed
                if (!(Boolean.parseBoolean(
                        SystemProperties.get(TelephonyProperties.PROPERTY_INECM_MODE)))) {
                    mState = buttonOn ? State.TurningOn : State.TurningOff;
                    mAirplaneState = mState;
                }
            }

            public boolean showDuringKeyguard() {
                return true;
            }

            public boolean showBeforeProvisioning() {
                return false;
            }
        };
        onAirplaneModeChanged();

        mItems = new ArrayList<Action>();
        String[] defaultActions = mContext.getResources().getStringArray(
                R.array.config_globalActionsList);

        ArraySet<String> addedKeys = new ArraySet<String>();
        mHasLogoutButton = false;
        mHasLockdownButton = false;
        for (int i = 0; i < defaultActions.length; i++) {
            String actionKey = defaultActions[i];
             else if (GLOBAL_ACTION_KEY_VOICEASSIST.equals(actionKey)) {
                mItems.add(getVoiceAssistAction());
            } else if (GLOBAL_ACTION_KEY_ASSIST.equals(actionKey)) {
                mItems.add(getAssistAction());
            } else if (GLOBAL_ACTION_KEY_RESTART.equals(actionKey)) {
                mItems.add(new RestartAction());
            } else if (GLOBAL_ACTION_KEY_SCREENSHOT.equals(actionKey)) {

                //UNISOC: fix for bug 1104146
                if(KeyguardUpdateMonitor.getInstance(mContext).isSecure()
                        && !KeyguardUpdateMonitor.getInstance(mContext).getStrongAuthTracker().hasUserAuthenticatedSinceBoot()) {
                    Log.e(TAG, "Not add screenshot because user hasn't authenticated.");
                    continue;
                }
                 //注释截图功能选项
                /* UNISOC Bug 1074234,939142 remove screenshot when pressing power,in powersave mode @{ */
                /*if (SprdPowerManagerUtil.SUPPORT_SUPER_POWER_SAVE) {
                   if (!SprdPowerManagerUtil.isSuperPower()) {
                       mItems.add(new ScreenshotAction());
                     }
                } else {
                       mItems.add(new ScreenshotAction());
                }*/
                /* @} */
            } else if (GLOBAL_ACTION_KEY_LOGOUT.equals(actionKey)) {
                if (mDevicePolicyManager.isLogoutEnabled()
                        && getCurrentUser().id != UserHandle.USER_SYSTEM) {
                    mItems.add(new LogoutAction());
                    mHasLogoutButton = true;
                }
            } else if (GLOBAL_ACTION_KEY_EMERGENCY.equals(actionKey)) {
                //注释紧急呼救功能选项
               /*if (!mEmergencyAffordanceManager.needsEmergencyAffordance()) {
                    mItems.add(new EmergencyDialerAction());
                }*/

            } else {
                Log.e(TAG, "Invalid global action key " + actionKey);
            }
            // Add here so we don't add more than one.
            addedKeys.add(actionKey);
        }

        if (mEmergencyAffordanceManager.needsEmergencyAffordance()) {
            mItems.add(new EmergencyAffordanceAction());
        }

        mAdapter = new MyAdapter();

       ......

        ActionsDialog dialog = new ActionsDialog(mContext, mAdapter, panelViewController);
        dialog.setCanceledOnTouchOutside(false); // Handled by the custom class.
        dialog.setKeyguardShowing(mKeyguardShowing);

        dialog.setOnDismissListener(this);
        dialog.setOnShowListener(this);

        return dialog;
    }


```

在上述的GlobalActionsDialog.java的相关源码中，在createDialog()中构建关机dialog弹窗的内容


中，去掉不需要的item就可以了，所以这里就


注释掉截图和紧急呼救加载项也是可以实现功能的


接下来实现关机对话框全屏显示功能


##  3.实现关机对话框全屏ActionsDialog 构造方法中实现


看构造方法的参数设置



```
ActionsDialog(Context context, MyAdapter adapter,
                GlobalActionsPanelPlugin.PanelViewController plugin) {
            super(context, com.android.systemui.R.style.Theme_SystemUI_Dialog_GlobalActions);
            mContext = context;
            mAdapter = adapter;
            mColorExtractor = Dependency.get(SysuiColorExtractor.class);
            mStatusBarService = Dependency.get(IStatusBarService.class);

            // Window initialization
            Window window = getWindow();
            window.requestFeature(Window.FEATURE_NO_TITLE);
            // Inflate the decor view, so the attributes below are not overwritten by the theme.
            window.getDecorView();
            window.getAttributes().systemUiVisibility |= View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.setLayout(MATCH_PARENT, MATCH_PARENT);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
            window.setType(WindowManager.LayoutParams.TYPE_VOLUME_OVERLAY);
            setTitle(R.string.global_actions);
            Drawable drawable = mContext.getResources().getDrawable(com.android.systemui.R.drawable.bg_action);
            window.setBackgroundDrawable(drawable);
            mPanelController = plugin;
            initializeLayout();
        }
```

要实现全屏需要添加window flag的关于全屏的属性


+                                       | View.SYSTEM\_UI\_FLAG\_HIDE\_NAVIGATION  
 +                                       | View.SYSTEM\_UI\_FLAG\_FULLSCREEN  
 +                                       | View.SYSTEM\_UI\_FLAG\_IMMERSIVE\_STICKY



具体修改如下:



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
@@ -105,7 +105,7 @@ import static com.android.systemui.screenshot.CommonUtils.isInRegionOrLongshotMo
 
 import java.util.ArrayList;
 import java.util.List;
-
+import android.graphics.Color;
 import com.sprd.systemui.util.SprdPowerManagerUtil;
 
 /**
@@ -509,7 +509,7 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
 
         @Override
@@ -1195,13 +1195,13 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
                 Context context, View convertView, ViewGroup parent, LayoutInflater inflater) {
             View v = inflater.inflate(getActionLayoutId(context), parent,
                     false);
-
             ImageView icon = (ImageView) v.findViewById(R.id.icon);
             TextView messageView = (TextView) v.findViewById(R.id.message);
             messageView.setSelected(true); // necessary for marquee to work
 
             TextView statusView = (TextView) v.findViewById(R.id.status);
             final String status = getStatus();
+
             if (!TextUtils.isEmpty(status)) {
                 statusView.setText(status);
             } else {
@@ -1587,6 +1587,9 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
             window.getDecorView();
             window.getAttributes().systemUiVisibility |= View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                     | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
+                                       | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
+                                       | View.SYSTEM_UI_FLAG_FULLSCREEN
+                                       | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                     | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
             window.setLayout(MATCH_PARENT, MATCH_PARENT);
             window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
@@ -1596,8 +1599,12 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
                     | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                     | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                     | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
+                                       | WindowManager.LayoutParams.FLAG_FULLSCREEN
                     | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
             window.setType(WindowManager.LayoutParams.TYPE_VOLUME_OVERLAY);
+
+            Drawable drawable = mContext.getResources().getDrawable(com.android.systemui.R.drawable.bg_action);
+            window.setBackgroundDrawable(drawable);
             setTitle(R.string.global_actions);
 
             mPanelController = plugin;
@@ -1681,7 +1688,7 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
                 mBackgroundDrawable = new ScrimDrawable();
                 mScrimAlpha = ScrimController.GRADIENT_SCRIM_ALPHA;
             }
-            getWindow().setBackgroundDrawable(mBackgroundDrawable);
+
         }
```

在GlobalActionsDialog.java的上述源码中，在构建关机对话框中的，方法中，在通过ActionsDialog(Context context, MyAdapter adapter,  
                 GlobalActionsPanelPlugin.PanelViewController plugin)


这个构造方法中，添加全屏的属性，就实现了关机对话框的功能实现


 



