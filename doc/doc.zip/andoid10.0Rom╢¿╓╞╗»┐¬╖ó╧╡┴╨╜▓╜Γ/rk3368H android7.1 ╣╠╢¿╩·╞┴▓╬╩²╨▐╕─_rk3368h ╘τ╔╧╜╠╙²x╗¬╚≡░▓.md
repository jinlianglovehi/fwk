






1.WindowManagerService.java 固定竖屏修改



```
frameworks/base/services/core/java/com/android/server/wm/WindowManagerService.java
@@ -3876,7 +3876,8 @@ public class WindowManagerService extends IWindowManager.Stub
     boolean updateOrientationFromAppTokensLocked(boolean inTransaction) {
         long ident = Binder.clearCallingIdentity();
         try {
-            int req = getOrientationLocked();
+// int req = getOrientationLocked();
+            int req = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
             if (req != mLastOrientation) {
                 mLastOrientation = req;
                 //send a message to Policy indicating orientation change to take

```

2.system.prop参数修改



```
device\rockchip\rk3368\rk3368H_64\system.prop
ro.sf.hwrotation=90

```




