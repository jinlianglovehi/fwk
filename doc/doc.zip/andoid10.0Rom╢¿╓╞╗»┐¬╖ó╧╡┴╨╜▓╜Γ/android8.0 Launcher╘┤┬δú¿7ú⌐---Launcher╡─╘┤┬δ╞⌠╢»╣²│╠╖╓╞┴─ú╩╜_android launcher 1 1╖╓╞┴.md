






前面我们讲解了Launcher的源码启动过程第一步，获取硬件参数确认布局，接下来第二步就是判断是否是分屏模式，分屏模式下如何显示布局。


那么什么是分屏模式  
 分屏模式就是在两个或两个以上支持分屏模式的应用在前后台的时候，我们长按recent按钮，会出现屏幕一分为二的现象，这样就会有两个应用出现在前台运行。


第二步流程的源码如下：



```
  if (isInMultiWindowModeCompat()) {
            Display display = getWindowManager().getDefaultDisplay();
            Point mwSize = new Point();
            display.getSize(mwSize);
            mDeviceProfile = mDeviceProfile.getMultiWindowProfile(this, mwSize);
        }
isInMultiWindowModeCompat()

```

首先进行分屏模式的判断是通过这个方法



```
isInMultiWindowModeCompat()，

  public boolean isInMultiWindowModeCompat() {
        return Utilities.ATLEAST_NOUGAT && isInMultiWindowMode();
    }

```

其中isInMultiWindowMode()为Activity的公共方法，任何一个activity在8.0平台中均可通过本方法判断是否处于分屏状态。如果是分屏模式那么就要进行分屏模式下的处理。  
 获取屏幕参数，由于屏幕的变化所以布局文件也要发生变化，那么就要获取新的布局文件mDeviceProfile =mDeviceProfile.getMultiWindowProfile。


mDeviceProfile.getMultiWindowProfile（）  
 分屏模式下的不同就是宽度和原来的一样，只是高度发生了变化。根据分屏模式下的宽高创建新的DeviceProfile。



```
   DeviceProfile getMultiWindowProfile(Context context, Point mwSize) {
        
        mwSize.set(Math.min(availableWidthPx, mwSize.x), Math.min(availableHeightPx, mwSize.y));
        DeviceProfile profile = new DeviceProfile(context, inv, mwSize, mwSize, mwSize.x, mwSize.y,
                isLandscape);

        // Hide labels on the workspace.
        profile.adjustToHideWorkspaceLabels();
//icontext消失，导致每个icon的高度变晓，每一行的高度变小，于是也会导致widget变小，所以需要把widget的空间也同步缩小。也就是这段代码的作用
        float appWidgetScaleX = (float) profile.getCellSize().x / getCellSize().x;
        float appWidgetScaleY = (float) profile.getCellSize().y / getCellSize().y;
        profile.appWidgetScale.set(appWidgetScaleX, appWidgetScaleY);

        return profile;
    }

```

接着调用profile.adjustToHideWorkspaceLabels();方法，在这个方法里面,iconTextSizePx 为0意味着，不显示图标的文字。且图标和图标之间的间距也缩小为0。确实，不显示图标的文字和icon之间的间距为0，是让高度变小的最好方法。



```
 private void adjustToHideWorkspaceLabels() {
        iconTextSizePx = 0;
        iconDrawablePaddingPx = 0;
        cellHeightPx = iconSizePx;

        // In normal cases, All Apps cell height should equal the Workspace cell height.
        // Since we are removing labels from the Workspace, we need to manually compute the
        // All Apps cell height.
        int topBottomPadding = allAppsIconDrawablePaddingPx * (isVerticalBarLayout() ? 2 : 1);
        allAppsCellHeightPx = allAppsIconSizePx + allAppsIconDrawablePaddingPx
                + Utilities.calculateTextHeight(allAppsIconTextSizePx)
                + topBottomPadding * 2;
    }

```

icontext消失，导致每个icon的高度变晓，每一行的高度变小，于是也会导致widget变小，所以需要把widget的空间也同步缩小。也就是这段代码的作用.


到这里第二步就分析完了，主要是判断是否在分屏模式下，如果在分屏模式下，图标文字就不显示，缩小控件的快高，来实现屏幕的高度变化。获得新的布局文件profile。





