






一 、Android.mk 简介  
 Android.mk 是Android 提供的一种makefile 文件,注意用来编译生成（exe，so，a，jar，apk）等文件。  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20200803090200441.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)  
 二、Android.mk 的基本格式


Android.mk 基本格式如下



```
# 定义模块当前路径
LOCAL_PATH := $(call my-dir)  
#清空当前环境变量
include $(CLEAR\_VARS)
 # 引入头文件等
 LOCAL_xxx       := xxx
 #编译生成的文件名 
 LOCAL_MODULE    := hello  
 #编译该模块所需的源码
 LOCAL_SRC_FILES := hello.c  
 #引入jar包等
 LOCAL_xxx       := xxx  
#编译生成文件的类型 #LOCAL\_MODULE\_CLASS 、JAVA\_LIBRARIES#APPS 、 SHARED\_LIBRARIES#EXECUTABLES 、 ETCinclude $(BUILD\_EXECUTABLE) 

```

三、Android.mk 深入学习一


使用Android.mk 可以编译多个目标文件：  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20200803090403929.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)


Android.mk 编译多个目标文件


编译动态库



```
C/C++ 文件编译生成静态库.so文件参考如下

LOCAL_PATH := $(call my-dir)    include $(CLEAR\_VARS)    # 生成libhell.soLOCAL\_MODULE = libhello 

LOCAL_CFLAGS = $(L\_CFLAGS)    
LOCAL_SRC_FILES = hello.c  
LOCAL_C_INCLUDES = $(INCLUDES) 
LOCAL_SHARED_LIBRARIES := libcutils    
LOCAL_COPY_HEADERS_TO := libhello   
LOCAL_COPY_HEADERS := hello.h   

#编译动态库 BUILD\_SHARED\_LIBRARYinclude $(BUILD\_SHARED\_LIBRARY) 

```

编译静态库



```
C/C++ 文件编译生成静态库.a文件参考如下

#编译静态库 LOCAL\_PATH := $(call my-dir) include $(CLEAR\_VARS) # 生成libhell.aLOCAL\_MODULE = libhello

LOCAL_CFLAGS = $(L\_CFLAGS)    
LOCAL_SRC_FILES = hello.c    
LOCAL_C_INCLUDES = $(INCLUDES)    
LOCAL_SHARED_LIBRARIES := libcutils    
LOCAL_COPY_HEADERS_TO := libhello   
LOCAL_COPY_HEADERS := hellos.h   

 # 编译 静态库 BUILD\_STATIC\_LIBRARYinclude $(BUILD\_STATIC\_LIBRARY) 

```

四、 Android.mk 深入学习二


Android.mk 引用资源  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/2020080309062951.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)


引用静态库



```
LOCAL_STATIC_LIBRARIES += libxxxxx

LOCAL_STATIC_LIBRARIES := \
    ...
    libxxx2 \
    libxxx \

```

引用动态库



```
LOCAL_SHARED_LIBRARIES += libxxxxx

LOCAL_SHARED_LIBRARIES := liblog libnativehelper libGLESv2

```

引用第三方库文件



```
LOCAL_LDFLAGS:=-L/PATH -Lxxx

LOCAL_LDFLAGS := $(LOCAL\_PATH)/lib/libtest.a

```

引用第三方头文件



```
LOCAL_C_INCLUDES :=path

eg:

LOCAL_C_INCLUDES = $(INCLUDES)

```

五、 Android.mk 深入学习三


Android.mk 深入学习三  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20200803090736150.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JhaWR1XzQxNjY2Mjk1,size_16,color_FFFFFF,t_70)


编译apk



```
 LOCAL_PATH := $(call my-dir)  include $(CLEAR\_VARS)
  LOCAL_SRC_FILES := $(call all-subdir-java-files)  # 生成hello apk
  LOCAL_PACKAGE_NAME := hello  include $(BUILD\_PACKAGE)

```

编译jar包



```
  LOCAL_PATH := $(call my-dir)  include $(CLEAR\_VARS)
  LOCAL_SRC_FILES := $(call all-subdir-java-files)  # 生成 hello
  LOCAL_MODULE := hello  # 编译生成静态jar包
  include $(BUILD\_STATIC\_JAVA\_LIBRARY)  #编译生成共享jar
  include $(BUILD\_JAVA\_LIBRARY)

```

静态jar包：



```
include $(BUILD\_STATIC\_JAVA\_LIBRARY)
使用.class文件打包而成的JAR文件，可以在任何java虚拟机运行

```

动态jar包：



```
include $(BUILD\_JAVA\_LIBRARY)
在静态jar包基础之上使用.dex打包而成的jar文件，.dex是android系统使用的文件格式。

```

APK 依赖jar



```
LOCAL_PATH := $(call my-dir)include $(CLEAR\_VARS)# 静态jar包LOCAL\_STATIC\_JAVA\_LIBRARIES := static-library#动态jar包LOCAL\_JAVA\_LIBRARIES := share-library

LOCAL_SRC_FILES := $(call all-subdir-java-files)
LOCAL_PACKAGE_NAME := helloinclude $(BUILD\_PACKAGE)

```

预编译jar包



```
LOCAL_PATH := $(call my-dir)include $(CLEAR\_VARS)#指定编译生成的文件类型LOCAL\_MODULE\_CLASS := JAVA\_LIBRARIES
LOCAL_MODULE := hello
LOCAL_SRC_FILES :=  $(call all-subdir-java-files)# 预编译include $(BUILD\_PREBUILT)

```

预编译文件类型如下：



```
   1.LOCAL_MODULE_CLASS：
    编译文件类型
    2.JAVA_LIBRARIES：
    dex归档文件
    3.APPS：
    APK文件
    4.SHARED_LIBRARIES：
    动态库文件
    5.EXECUTABLES：
    二进制文件
    6.ETC：
    其他文件格式

```

六、 Android.mk 判断语句


Android.mk 中的判断语句



```
ifeq($(VALUE), x)   #ifneq
  do_yeselse
  do_noendif

```

ifeq/ifneq：根据判断条件执行相关编译





