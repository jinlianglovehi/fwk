






### 1.概述


在10.0的产品定制化开发中,客户需求要实现应用安装白名单功能，在白名单之中的应用可以安装，PMS就是负责管理app安装的，功能就添加在这里就可以了，


### 2.app应用安装白名单的核心类



```
frameworks/base/core/java/android/content/pm/IPackageManager.aidl
frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java 

```

### 3.app应用安装白名单的核心功能分析和实现


### 3.1 IPackageManager.aidl添加接口供app调用



```
diff --git a/frameworks/base/core/java/android/content/pm/IPackageManager.aidl b/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

old mode 100644

new mode 100755

index a369cc89a3..90fafe5a8f

--- a/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

+++ b/frameworks/base/core/java/android/content/pm/IPackageManager.aidl

@@ -798,4 +798,7 @@ interface IPackageManager {

     */

     int restoreAppData(String sourceDir, String pkgName);

    /* @} */

+   

+       void setInstallPackageWhiteList(in List<String> packageNames);

+       List<String> getInstallPackageWhiteList();

 }

```

在IPackageManager.aidl中增加设置安装和获取白名单的方法，方便在安装app的时候调用  
 看安装的app是否在安装的白名单之内，然后决定是否安装


### 3.2 在PMS中实现app安装白名单接口



```
diff --git a/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java b/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

index 45289f2e39..6727b10e35 100755

--- a/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

+++ b/frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java

@@ -111,7 +111,13 @@ import static com.android.server.pm.PackageManagerServiceUtils.getCompressedFile

 import static com.android.server.pm.PackageManagerServiceUtils.getLastModifiedTime;

 import static com.android.server.pm.PackageManagerServiceUtils.logCriticalInfo;

 import static com.android.server.pm.PackageManagerServiceUtils.verifySignatures;

-

+import java.io.BufferedReader;

+import java.io.File;

+import java.io.FileInputStream;

+import java.io.FileOutputStream;

+import java.io.InputStreamReader;

+import java.io.LineNumberReader;

+import java.io.PrintWriter;

 import android.Manifest;

 import android.annotation.IntDef;

 import android.annotation.NonNull;

@@ -2141,7 +2147,16 @@ public class PackageManagerService extends PackageManagerServiceExAbs

             }

         }

     }

-

+       private List<String> installwhitepackageNames;

+           @Override

+    public void setInstallPackageWhiteList( List<String> packageNames) {

+               this.installwhitepackageNames=packageNames;

+    }

+       

+       @Override

+    public List<String> getInstallPackageWhiteList(){

+               return this.installwhitepackageNames;

+    }

     private void notifyInstallObserver(String packageName) {

         Pair<PackageInstalledInfo, IPackageInstallObserver2> pair =

                 mNoKillInstallObservers.remove(packageName);

```

在PackageManagerService 中实现IPackageManager.aidl中安装app白名单接口和获取应用白名单接口的方法，以便在安装app中调用getInstallPackageWhiteList()查询是否在安装白名单列表之内，判断是否可以安装


### 3. 3安装白名单功能具体实现


在PMS中  
 无论是adb shell安装或者是 代码安装 都会走preparePackageLI 所以在这里添加判断包名是否在白名单即可



```
@@ -17482,7 +17497,13 @@ public class PackageManagerService extends PackageManagerServiceExAbs
 @GuardedBy("mInstallLock")
      private void installPackagesLI(List<InstallRequest> requests) {
          final Map<String, ScanResult> preparedScans = new ArrayMap<>(requests.size());
          final Map<String, InstallArgs> installArgs = new ArrayMap<>(requests.size());
          final Map<String, PackageInstalledInfo> installResults = new ArrayMap<>(requests.size());
          final Map<String, PrepareResult> prepareResults = new ArrayMap<>(requests.size());
          final Map<String, VersionInfo> versionInfos = new ArrayMap<>(requests.size());
          final Map<String, PackageSetting> lastStaticSharedLibSettings =
                  new ArrayMap<>(requests.size());
          final Map<String, Boolean> createdAppId = new ArrayMap<>(requests.size());
          boolean success = false;
          try {
              Trace.traceBegin(TRACE_TAG_PACKAGE_MANAGER, "installPackagesLI");
              for (InstallRequest request : requests) {
                  // TODO(b/109941548): remove this once we've pulled everything from it and into
 // scan, reconcile or commit.
 final PrepareResult prepareResult;
 try {
 Trace.traceBegin(TRACE\_TAG\_PACKAGE\_MANAGER, "preparePackage");
 prepareResult = preparePackageLI(request.args, request.installResult);
 } catch (PrepareFailure prepareFailure) {
 request.installResult.setError(prepareFailure.error,
 prepareFailure.getMessage());
 request.installResult.origPackage = prepareFailure.conflictingPackage;
 request.installResult.origPermission = prepareFailure.conflictingPermission;
 return;
 } finally {
 Trace.traceEnd(TRACE\_TAG\_PACKAGE\_MANAGER);
 }
 .....
 
@GuardedBy("mInstallLock")
 private PrepareResult preparePackageLI(InstallArgs args, PackageInstalledInfo res)
 throws PrepareFailure { 
try {
 // either use what we've been given or parse directly from the APK
            if (args.signingDetails != PackageParser.SigningDetails.UNKNOWN) {
                pkg.setSigningDetails(args.signingDetails);
            } else {
                PackageParser.collectCertificates(pkg, false /* skipVerify */);
            }
        } catch (PackageParserException e) {
            throw new PrepareFailure("Failed collect during installPackageLI", e);
        }

-

+               if(!isWhiteListApp(pkg.packageName)){

+            Log.d("TAG","--isWhiteListApp--");

+                       

+                       throw new PrepareFailure(INSTALL_FAILED_INSTANT_APP_INVALID,

+                    "app is not in the whitelist. packageName");

+           

+        }

         if (instantApp && pkg.mSigningDetails.signatureSchemeVersion

                 < SignatureSchemeVersion.SIGNING_BLOCK_V2) {

             Slog.w(TAG, "Instant app package " + pkg.packageName

@@ -18039,7 +18060,21 @@ public class PackageManagerService extends PackageManagerServiceExAbs

             }

         }

     }

+    private boolean isWhiteListApp(String packagename){

 

+               if(this.installwhitepackageNames ==null || this.installwhitepackageNames.size()==0){

+                       return true;

+               }

+               

+        Iterator<String> it = this.installwhitepackageNames.iterator();

+        while (it.hasNext()) {

+            String whitelistItem = it.next();

+            if (whitelistItem.equals(packagename)) {

+                return true;

+            }

+        }

+        return false;

+    }

```

在PMS中安装app时，首先调用installPackagesLI然后在调用preparePackageLI进行安装app,在安装app的过程中，会首先判断这个app在不在安装白名单之内，不在就不允许安装这个app





