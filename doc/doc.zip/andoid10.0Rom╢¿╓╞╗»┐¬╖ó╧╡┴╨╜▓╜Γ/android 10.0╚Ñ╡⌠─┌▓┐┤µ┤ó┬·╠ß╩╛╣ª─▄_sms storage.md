






### 1.概述


在10.0的系统产品开发中,产品需求需要去掉当内部存储满时,不提醒清理系统数据,屏蔽掉这个功能,如下图


![在这里插入图片描述](https://img-blog.csdnimg.cn/ae879f95f7f94e29839ca84fcc6e0bc5.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_20,color_FFFFFF,t_70,g_se,x_16#pic_center)


### 2.去掉内部存储满提示功能核心类



```
frameworks/base/services/core/java/com/android/server/storage/DeviceStorageMonitorService.java
packages/apps/Messaging/src/com/android/messaging/sms/SmsStorageStatusManager.java
SmsStorageStatusManager.java

```

### 3.去掉内部存储满提示功能核心功能分析和实现


通过查询frameworks中的源码发现这个提示是在DeviceStorageMonitorService.java中的  
 需要去掉这个提示  
 所以就要从管理存储的服务类入手


frameworks/base/services/core/java/com/android/server/storage/DeviceStorageMonitorService.java


先看源码部分:


### 3.1 DeviceStorageMonitorService.java中关于存储的源码分析



```
private static final long NOTIFICATION_LEVEL_THRESHOLD = DataUnit.MEBIBYTES.toBytes(200);
private static final long DIALOG_LEVEL_THRESHOLD = DataUnit.MEBIBYTES.toBytes(100);

/**
 * Core logic that checks the storage state of every mounted private volume.
 * Since this can do heavy I/O, callers should invoke indirectly using
 * {@link #MSG\_CHECK}.
 */
@WorkerThread
private void check() {
    final StorageManager storage = getContext().getSystemService(StorageManager.class);
    final int seq = mSeq.get();

    // Check every mounted private volume to see if they're low on space
 for (VolumeInfo vol : storage.getWritablePrivateVolumes()) {
 final File file = vol.getPath();
 final long fullBytes = storage.getStorageFullBytes(file);
 final long lowBytes = storage.getStorageLowBytes(file);

 // Automatically trim cached data when nearing the low threshold;
 // when it's within 150% of the threshold, we try trimming usage
        // back to 200% of the threshold.
        if (file.getUsableSpace() < (lowBytes * 3) / 2) {
            final PackageManagerService pms = (PackageManagerService) ServiceManager
                    .getService("package");
            try {
                pms.freeStorage(vol.getFsUuid(), lowBytes * 2, 0);
            } catch (IOException e) {
                Slog.w(TAG, e);
            }
        }

        // Send relevant broadcasts and show notifications based on any
        // recently noticed state transitions.
        final UUID uuid = StorageManager.convert(vol.getFsUuid());
        final State state = findOrCreateState(uuid);
        final long totalBytes = file.getTotalSpace();
        final long usableBytes = file.getUsableSpace();

        int oldLevel = state.level;
        int newLevel;
        if (mForceLevel != State.LEVEL_UNKNOWN) {
            // When in testing mode, use unknown old level to force sending
            // of any relevant broadcasts.
            oldLevel = State.LEVEL_UNKNOWN;
            newLevel = mForceLevel;
        } else if (usableBytes <= fullBytes) {
            newLevel = State.LEVEL_FULL;
        } else if (usableBytes <= lowBytes) {
            newLevel = State.LEVEL_LOW;
        } else if (StorageManager.UUID_DEFAULT.equals(uuid) && !isBootImageOnDisk()
                && usableBytes < BOOT_IMAGE_STORAGE_REQUIREMENT) {
            newLevel = State.LEVEL_LOW;
        } else {
            newLevel = State.LEVEL_NORMAL;
        }

        // Log whenever we notice drastic storage changes
        if ((Math.abs(state.lastUsableBytes - usableBytes) > DEFAULT\_LOG\_DELTA\_BYTES)
 || oldLevel != newLevel) {
 EventLogTags.writeStorageState(uuid.toString(), oldLevel, newLevel,
 usableBytes, totalBytes);
 state.lastUsableBytes = usableBytes;
 }
 // only overide UUID\_DEFAULT data
 if(!StorageManager.UUID\_DEFAULT.equals(uuid))
            updateNotifications(vol, oldLevel, newLevel);
        updateBroadcasts(vol, oldLevel, newLevel, seq);

        state.level = newLevel;

        if(StorageManager.UUID_DEFAULT.equals(uuid) && mBootCompleted) {
            String debugFreeMem = SystemProperties.get("debug.freemem");
            long debugUsableBytes = 0;
            if (!"".equals(debugFreeMem)) {
                debugUsableBytes = Long.parseLong(debugFreeMem);
            }
            long minUsableBytes = (debugUsableBytes != 0 && debugUsableBytes < usableBytes) ? debugUsableBytes : usableBytes;
            String decryptState = SystemProperties.get("vold.decrypt");
            if(!decryptState.equals("trigger\_restart\_min\_framework")){
                updateStateEx(minUsableBytes);
            } else {
                Slog.d(TAG, "enable fde, and now data is mounted with tempfs, skip check!");
            }
        }
    }

    // Loop around to check again in future; we don't remove messages since
    // there might be an immediate request pending.
    if (!mHandler.hasMessages(MSG_CHECK)) {
        mHandler.sendMessageDelayed(mHandler.obtainMessage(MSG_CHECK),
                DEFAULT_CHECK_INTERVAL);
    }
}

private void updateStateEx(long usableBytes) {
      int oldLevel = mStateEx.level;
     int newLevel;
     if (usableBytes <= DIALOG_LEVEL_THRESHOLD) {
         newLevel = StateEx.LEVEL_FULL;
     } else if (usableBytes <= NOTIFICATION_LEVEL_THRESHOLD) {
        newLevel = StateEx.LEVEL_LOW;
      } else {
         newLevel = StateEx.LEVEL_NORMAL;
     }
     mStateEx.newLevel = newLevel;
     Slog.d(TAG, "updateStateEx oldLevel = " + oldLevel + ", newLevel = " + newLevel);
     updateExtremLowStorageNotification(oldLevel, newLevel);
     updateLowStorageNotification(oldLevel, newLevel);
     updateStateExBroadcasts(oldLevel, newLevel);
      mStateEx.level = newLevel;
}

```

在check()中在  
 每次内部存储有变化 都会检测当前是否是存储满或不足的状态 当低于200M时 提示内存满  
 低于100M会提示存储不足  
 所以去掉这些提示 就需要改成如下：



```
   private void updateStateEx(long usableBytes) {
          int oldLevel = mStateEx.level;
         int newLevel;
         if (usableBytes <= DIALOG_LEVEL_THRESHOLD) {
          -newLevel = StateEx.LEVEL_FULL;
          +newLevel = StateEx.LEVEL_NORMAL;

         } else if (usableBytes <= NOTIFICATION_LEVEL_THRESHOLD) {
           - newLevel = StateEx.LEVEL_LOW;
           +newLevel = StateEx.LEVEL_NORMAL;
          } else {
             newLevel = StateEx.LEVEL_NORMAL;
         }
         mStateEx.newLevel = newLevel;
         Slog.d(TAG, "updateStateEx oldLevel = " + oldLevel + ", newLevel = " + newLevel);
         - updateExtremLowStorageNotification(oldLevel, newLevel);
         - updateLowStorageNotification(oldLevel, newLevel);
         updateStateExBroadcasts(oldLevel, newLevel);
          mStateEx.level = newLevel;
    }

```

在updateStateEx(long usableBytes) 中去掉提示弹窗的功能标准


### 3.2 Messings app中 关于低存储的提醒


路径：  
 packages/apps/Messaging/src/com/android/messaging/sms/SmsStorageStatusManager.java  
 SmsStorageStatusManager.java



```
/**
     * Handles storage low signal for SMS
     */
    public static void handleStorageLow() {
        if (!PhoneUtils.getDefault().isSmsEnabled()) {
            return;
        }

        // TODO: Auto-delete messages, when that setting exists and is enabled

        // Notify low storage for SMS
        postStorageLowNotification();
    }


     */
    private static void postStorageLowNotification() {
        final Context context = Factory.get().getApplicationContext();
        final Resources resources = context.getResources();
        final PendingIntent pendingIntent = UIIntents.get()
                .getPendingIntentForLowStorageNotifications(context);

        final NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
        builder.setContentTitle(resources.getString(R.string.sms_storage_low_title))
                .setTicker(resources.getString(R.string.sms_storage_low_notification_ticker))
                .setSmallIcon(R.drawable.ic_failed_light)
                .setPriority(Notification.PRIORITY_DEFAULT)
                .setOngoing(true)      // Can't be swiped off
 .setAutoCancel(false) // Don't auto cancel
                .setContentIntent(pendingIntent);

        final NotificationCompat.BigTextStyle bigTextStyle =
                new NotificationCompat.BigTextStyle(builder);
        bigTextStyle.bigText(resources.getString(R.string.sms_storage_low_text));
        final Notification notification = bigTextStyle.build();

        final NotificationManagerCompat notificationManager =
                NotificationManagerCompat.from(Factory.get().getApplicationContext());

        notificationManager.notify(getNotificationTag(),
                PendingIntentConstants.SMS_STORAGE_LOW_NOTIFICATION_ID, notification);
    }

```

在handleStorageLow()中当存储低的时候调用postStorageLowNotification()弹出弹窗提醒存储低需清理


修改如下:  
 去掉提醒功能



```
  */
    private static void postStorageLowNotification() {
        final Context context = Factory.get().getApplicationContext();
        final Resources resources = context.getResources();
        final PendingIntent pendingIntent = UIIntents.get()
                .getPendingIntentForLowStorageNotifications(context);

        final NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
        builder.setContentTitle(resources.getString(R.string.sms_storage_low_title))
                .setTicker(resources.getString(R.string.sms_storage_low_notification_ticker))
                .setSmallIcon(R.drawable.ic_failed_light)
                .setPriority(Notification.PRIORITY_DEFAULT)
                .setOngoing(true)      // Can't be swiped off
 .setAutoCancel(false) // Don't auto cancel
                .setContentIntent(pendingIntent);

        final NotificationCompat.BigTextStyle bigTextStyle =
                new NotificationCompat.BigTextStyle(builder);
        bigTextStyle.bigText(resources.getString(R.string.sms_storage_low_text));
        final Notification notification = bigTextStyle.build();

        final NotificationManagerCompat notificationManager =
                NotificationManagerCompat.from(Factory.get().getApplicationContext());

        -notificationManager.notify(getNotificationTag(),
                -PendingIntentConstants.SMS_STORAGE_LOW_NOTIFICATION_ID, notification);
    }

```




