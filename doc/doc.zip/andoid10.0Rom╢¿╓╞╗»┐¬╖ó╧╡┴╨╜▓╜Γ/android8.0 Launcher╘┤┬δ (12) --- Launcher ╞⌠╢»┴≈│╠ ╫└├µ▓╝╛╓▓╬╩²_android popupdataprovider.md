







```
这篇主要是讲各布局的细节参数的计算。

```

我们来看一下这一步的具体代码。



```
mDeviceProfile.layout(this, false /* notifyListeners */);
        loadExtractedColorsAndColorItems();

        mPopupDataProvider = new PopupDataProvider(this);

        ((AccessibilityManager) getSystemService(ACCESSIBILITY\_SERVICE))
                .addAccessibilityStateChangeListener(this);

        restoreState(savedInstanceState);

        // We only load the page synchronously if the user rotates (or triggers a
        // configuration change) while launcher is in the foreground
        int currentScreen = PagedView.INVALID_RESTORE_PAGE;
        if (savedInstanceState != null) {
            currentScreen = savedInstanceState.getInt(RUNTIME_STATE_CURRENT_SCREEN, currentScreen);
        }

1.mDeviceProfile.layout(this, false /* notifyListeners */);

```

在该方法中有一些具体的注释，主要是桌面具体控件布局的位置放置，包括searchbar，allapps，workspace，hotseat，indicators，等等。  
 // Layout the search bar space  
 //Layout the all apps  
 // Layout the workspace  
 // Layout the hotseat  
 // Layout the page indicators  
 //layout the arrow tips  
 Layout the flat menu page indicators  
 // Layout the Overview Mode  
 // Layout the snack tips  
 // Layout the AllAppsRecyclerView  
 2.loadExtractedColorsAndColorItems();


此方法中是设置控件的颜色



```
private void loadExtractedColorsAndColorItems() {
        // TODO: do this in pre-N as well, once the extraction part is complete.
        if (Utilities.ATLEAST_NOUGAT) {
            mExtractedColors.load(this);
            mHotseat.updateColor(mExtractedColors, !mPaused);
            mWorkspace.getPageIndicator().updateColor(mExtractedColors);
        }
    }

```

会根据壁纸的颜色，来调节Hotseat，pageIndicator的颜色。workspace图标文字的颜色。  
 3.mPopupDataProvider = new PopupDataProvider(this);


当你长按桌面图片，或者allapps里面的图标的时候会弹出来一个窗口，窗口里面有几个选项可供选择。  
 4.((AccessibilityManager) getSystemService(ACCESSIBILITY\_SERVICE))



```
        .addAccessibilityStateChangeListener(this);

```

监听桌面的变化，进行事件分发，AccessibilityManager是系统级别的服务,用来管理AccessibilityService服务,比如分发事件,查询系统中服务的状态等等。  
 5.对界面，以及数据进行恢复



```
restoreState(savedInstanceState);

        if (LauncherAppState.PROFILE_STARTUP) {
            Trace.endSection();
        }

        // We only load the page synchronously if the user rotates (or triggers a
        // configuration change) while launcher is in the foreground
        int currentScreen = PagedView.INVALID_RESTORE_PAGE;
        if (savedInstanceState != null) {
            currentScreen = savedInstanceState.getInt(RUNTIME_STATE_CURRENT_SCREEN, currentScreen);
        }

```

这里进行数据的保存与恢复。这里运用了安卓的数据储存恢复机制，对保存在savedInstanceState里面的数据进行恢复。





