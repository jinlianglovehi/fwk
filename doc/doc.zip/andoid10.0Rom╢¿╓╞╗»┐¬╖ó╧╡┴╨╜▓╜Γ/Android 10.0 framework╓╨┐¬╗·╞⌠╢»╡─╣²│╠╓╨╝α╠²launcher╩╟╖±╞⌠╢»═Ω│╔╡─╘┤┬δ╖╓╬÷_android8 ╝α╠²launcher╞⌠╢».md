



## 1.前言


  
  在10.0的系统开发中，在系统开机启动阶段，对于首次开机动画播放完毕后，有些产品会出现黑屏的情况，这时候就需要判断当前Launcher是否启动完毕，然后  
 在做相关的处理，接下来就来分析下关于判断launcher是否启动完毕的源码分析


## 2.framework中开机启动的过程中监听launcher是否启动完成的源码分析的核心类



```
frameworks/base/core/java/android/app/ActivityThread.java
frameworks/base/services/core/java/com/android/server/am/ActivityTaskManagerService.java
frameworks/base/services/core/java/com/android/server/am/ActivityStackSupervisor.java
frameworks/base/core/java/android/os/MessageQueue.java
```

## 3.framework中开机启动的过程中监听launcher是否启动完成的源码分析的功能分析和实现


  
 在系统中，是在AMS即ActivityManagerService.java中负责启动Launcher，在Launcher启动完成后即Activity onResume之后，就会发送开机完成广播，表示当前  
 系统启动完毕。而在Launcher的Activity 在onResume的方法中，  
 执行了handleResumeActivity方法，在handleResumeActivity中加载完window之后将自己实现的IdleHandler添加到自己的消息队列中。


## 3.1 ActivityThread.java的启动activity的方法如下:



```
    @Override
    public void handleResumeActivity(IBinder token, boolean finalStateRequest, boolean isForward,
            String reason) {
        // If we are getting ready to gc after going to the background, well
        // we are back active so skip it.
        unscheduleGcIdler();
        mSomeActivitiesChanged = true;
//执行onResume方法
        // TODO Push resumeArgs into the activity for consideration
        final ActivityClientRecord r = performResumeActivity(token, finalStateRequest, reason);
        if (r == null) {
            // We didn't actually resume the activity, so skipping any follow-up actions.
            return;
        }
.......

        r.nextIdle = mNewActivities;
        mNewActivities = r;
        if (localLOGV) Slog.v(TAG, "Scheduling idle handler for " + r);
//将IdleHandler加入到消息队列
        Looper.myQueue().addIdleHandler(new Idler());

        // UNISOC: USIM notifier feature
        if (UsimNotifier.isNotifyEnabled(getApplication())) {
            UsimNotifier.getInstance().startNotify(r.activity);
        }
    }
```

在上述的ActivityThread.java的相关源码中，可以看出在handleResumeActivity(IBinder token, boolean finalStateRequest, boolean isForward,  
             String reason)中，主要是执行Activity的onResume相关流程，  
 另外一个重要功能就是将IdleHandler加入到消息队列中，当消息队列空闲的时候执行idler.queueIdle()的回调



```
   private class Idler implements MessageQueue.IdleHandler {
        @Override
        public final boolean queueIdle() {
            ActivityClientRecord a = mNewActivities;
            boolean stopProfiling = false;
            if (mBoundApplication != null && mProfiler.profileFd != null
                    && mProfiler.autoStopProfiler) {
                stopProfiling = true;
            }
            if (a != null) {
                mNewActivities = null;
                IActivityTaskManager am = ActivityTaskManager.getService();
                ActivityClientRecord prev;
                do {
                    if (localLOGV) Slog.v(
                        TAG, "Reporting idle of " + a +
                        " finished=" +
                        (a.activity != null && a.activity.mFinished));
                    if (a.activity != null && !a.activity.mFinished) {
                        try {
                            am.activityIdle(a.token, a.createdConfig, stopProfiling);
                            a.createdConfig = null;
                        } catch (RemoteException ex) {
                            throw ex.rethrowFromSystemServer();
                        }
                    }
                    prev = a;
                    a = a.nextIdle;
                    prev.nextIdle = null;
                } while (a != null);
            }
            if (stopProfiling) {
                mProfiler.stopProfiling();
            }
            applyPendingProcessState();
            return false;
        }
    }
```

在ActivityThread.java的Idler中，在消息队列空闲的时候，会调用queueIdle()进行消息的处理  
 而在queueIdle()中，首选是获取到 IActivityTaskManager am = ActivityTaskManager.getService();  
 这个atms的对象，然后调用am.activityIdle(a.token, a.createdConfig, stopProfiling);  
 来进行具体的activity组件空闲的时候 进行的相关流程处理



```
   @Override
    public final void activityIdle(IBinder token, Configuration config, boolean stopProfiling) {
        final long origId = Binder.clearCallingIdentity();
        try {
            WindowProcessController proc = null;
            synchronized (mGlobalLock) {
                ActivityStack stack = ActivityRecord.getStackLocked(token);
                if (stack == null) {
                    return;
                }
                final ActivityRecord r = mStackSupervisor.activityIdleInternalLocked(token,
                        false /* fromTimeout */, false /* processPausingActivities */, config);
                if (r != null) {
                    proc = r.app;
                }
                if (stopProfiling && proc != null) {
                    proc.clearProfilerIfNeeded();
                }
            }
        } finally {
            Binder.restoreCallingIdentity(origId);
        }
    }
```

在ActivityTaskManagerService.java的上述源码中，可以看出在activityIdle(IBinder token, Configuration config, boolean stopProfiling)  
 中处理activity组件空闲的时候，主要是调用mStackSupervisor.activityIdleInternalLocked(token,  
                         false /\* fromTimeout \*/, false /\* processPausingActivities \*/, config)  
 来处理具体的流程



```
  @GuardedBy("mService")
    final ActivityRecord activityIdleInternalLocked(final IBinder token, boolean fromTimeout,
            boolean processPausingActivities, Configuration config) {
        if (DEBUG_ALL) Slog.v(TAG, "Activity idle: " + token);

        ArrayList<ActivityRecord> finishes = null;
        ArrayList<UserState> startingUsers = null;
        int NS = 0;
        int NF = 0;
        boolean booting = false;
        boolean activityRemoved = false;

        ActivityRecord r = ActivityRecord.forTokenLocked(token);
        if (r != null) {
            if (DEBUG_IDLE) Slog.d(TAG_IDLE, "activityIdleInternalLocked: Callers="
                    + Debug.getCallers(4));
            mHandler.removeMessages(IDLE_TIMEOUT_MSG, r);
//add core start
			String boot_completed = android.os.SystemProperties.get("sys.boot_completed");
			android.util.Log.e("ASS","activityIdleInternalLocked--packageName="+r.packageName+"--boot_completed:"+boot_completed);
 //add core end          
            r.finishLaunchTickingLocked();
            if (fromTimeout) {
                reportActivityLaunchedLocked(fromTimeout, r, INVALID_DELAY,
                        -1 /* launchState */);
            }

            // This is a hack to semi-deal with a race condition
            // in the client where it can be constructed with a
            // newer configuration from when we asked it to launch.
            // We'll update with whatever configuration it now says
            // it used to launch.
            if (config != null) {
                r.setLastReportedGlobalConfiguration(config);
            }

            // We are now idle.  If someone is waiting for a thumbnail from
            // us, we can now deliver.
            r.idle = true;

            //Slog.i(TAG, "IDLE: mBooted=" + mBooted + ", fromTimeout=" + fromTimeout);

            // Check if able to finish booting when device is booting and all resumed activities
            // are idle.
            if ((mService.isBooting() && mRootActivityContainer.allResumedActivitiesIdle())
                    || fromTimeout) {
                booting = checkFinishBootingLocked();
            }

            // When activity is idle, we consider the relaunch must be successful, so let's clear
            // the flag.
            r.mRelaunchReason = RELAUNCH_REASON_NONE;
        }
...

}
```

在ActivityStackSupervisor.java中的activityIdleInternalLocked(）中，在  
   r.finishLaunchTickingLocked();中就是判断当前Launcher是否启动完毕的，  
 然后可以在这里判断包名，调用r.packageName来获取当前页面的包名



