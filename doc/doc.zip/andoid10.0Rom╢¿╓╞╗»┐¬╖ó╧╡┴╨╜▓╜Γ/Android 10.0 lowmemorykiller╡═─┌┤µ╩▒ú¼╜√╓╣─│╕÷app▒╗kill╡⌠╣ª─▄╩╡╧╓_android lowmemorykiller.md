



## 1.前言


在10.0的系统定制化开发中，在对于系统lowmemorykiller低内存的时候，应用保活功能是非常重要的，就是在低内存的情况下 禁止某个app被杀掉，所以就需要从lowmemorykiller机制入手，在杀进程的相关流程中进行分析来实现进程避免被杀掉，接下来 就来实现这个功能


## 2.lowmemorykiller低内存时，禁止某个app被kill掉功能实现的核心类



```
system\core\lmkd\lmkd.c
```

## 3.lowmemorykiller低内存时，禁止某个app被kill掉功能实现的核心功能分析和实现


Android系统中在app的应用中，当页面被遮挡或者当Activity切换到后台，activity所在进程并不会马上退出被系统杀掉进程，还是会继续存在内存中，便于再次启动activity时， 快速启动来提高响应速度（热启动），当内存达到一定极限值，lmkd会根据策略来杀掉一些优先级较低的进程来保障系统内存的正常运行。 lowmemorykiller的低内存机制中，关于在低内存时杀掉一些优先级低的进程，这部分功能在Android8.0之前主要实现在kernel中，8.0以后主要在lmkd中实现，kernel使用vmpressure机制， 达到和kernel解耦的目的 对于Android 系统来说，希望将这种 OOM killer 放在用户空间，例如这里的 lmkd，用户空间的 OOM killer 在希望释放内存的时候，必须要依靠 kill() 或者是 pidfd\_send\_signal()，这种方式杀死一个进程并不能使 OOM reaper 接受来发挥作用 所以说lmkd的主要源码功能就是在system\core\lmkd这个模块，接下来看下相关的源码分析


## 3.1 lmkd.c关于kill进程的相关核心源码功能分析


在lowmemorykiller低内存时，禁止某个app被kill掉功能实现中，在通过上述的源码分析得知，在这个lmkd机制来管理低内存时 杀掉某些进程的功能实现，主要就是在lmkd.c中进行进程的管理的，接下来分析下核心功能的实现



```
static int find_and_kill_multi_processes(int min_score_adj, const char *reason, bool kill_all) {
    int i;
    int killed_size = 0;

#ifdef LMKD_LOG_STATS
    bool lmk_state_change_start = false;
#endif

    for (i = OOM_SCORE_ADJ_MAX; i >= min_score_adj; i--) {
        struct proc *procp;

        while (true) {
            procp = kill_heaviest_task ?
                proc_get_heaviest(i) : proc_adj_lru_skip(i);

            if (!procp)
                break;

            killed_size += kill_one_process(procp, min_score_adj, reason);
            if (killed_size >= 0) {
#ifdef LMKD_LOG_STATS
                if (enable_stats_log && !lmk_state_change_start) {
                    lmk_state_change_start = true;
                    stats_write_lmk_state_changed(log_ctx, LMK_STATE_CHANGED,
                                                  LMK_STATE_CHANGE_START);
                }
#endif
            }
        }
        if (!kill_all && killed_size > 0)
            break;
    }

out:
#ifdef LMKD_LOG_STATS
    if (enable_stats_log && lmk_state_change_start) {
        stats_write_lmk_state_changed(log_ctx, LMK_STATE_CHANGED, LMK_STATE_CHANGE_STOP);
    }
#endif

    return killed_size;
}
static int find_and_kill_process(int min_score_adj, const char *reason) {
    int i;
    int killed_size = 0;

#ifdef LMKD_LOG_STATS
    bool lmk_state_change_start = false;
#endif

    for (i = OOM_SCORE_ADJ_MAX; i >= min_score_adj; i--) {
        struct proc *procp;

        while (true) {
            procp = kill_heaviest_task ?
                proc_get_heaviest(i) : proc_adj_lru_skip(i);

            if (!procp)
                break;

            killed_size = kill_one_process(procp, min_score_adj, reason);
            if (killed_size >= 0) {
#ifdef LMKD_LOG_STATS
                if (enable_stats_log && !lmk_state_change_start) {
                    lmk_state_change_start = true;
                    stats_write_lmk_state_changed(log_ctx, LMK_STATE_CHANGED,
                                                  LMK_STATE_CHANGE_START);
                }
#endif
                break;
            }
        }
        if (killed_size) {
            break;
        }
    }
....

    return killed_size;
}
int find_and_kill_process_adj_locked(int adj, bool is_critical) {
    int i;
    int killed_size = 0;
    int min_score_adj = adj;

    is_critical = 0;
    for (i = OOM_SCORE_ADJ_MAX; i >= min_score_adj; i--) {
        struct proc *procp;

retry:
        procp = proc_adj_lru(i);

        if (procp) {
            killed_size = kill_one_process(procp, adj, NULL);
            if (killed_size < 0) {
                goto retry;
            } else {
                return killed_size;
            }
        }
    }

    return 0;
}
/* Kill one process specified by procp.  Returns the size of the process killed */
static int kill_one_process(struct proc* procp, int min_oom_score, const char *reason) {
    int pid = procp->pid;
    uid_t uid = procp->uid;
    int tgid;
    char *taskname;
    int tasksize;
    int r;
    int result = -1;
#ifdef LMKD_LOG_STATS
    struct memory_stat mem_st = {};
    int memory_stat_parse_result = -1;
#else
    /* To prevent unused parameter warning */
    (void)(min_oom_score);
#endif
    char buf[LINE_MAX];

    tgid = proc_get_tgid(pid);
    if (tgid >= 0 && tgid != pid) {
        ALOGE("Possible pid reuse detected (pid %d, tgid %d)!", pid, tgid);
        goto out;
    }

    taskname = proc_get_name(pid, buf, sizeof(buf));
    if (!taskname) {
        goto out;
    }

    tasksize = proc_get_size(pid);
    if (tasksize <= 0) {
        goto out;
    }

//add core start
   char packageName[20] = {""};
    strncpy(packageName, taskname, sizeof("com.android.test"));
    ALOGE("packageName=%s,taskname=%s,strcmp=%d",packageName,taskname,strcmp(packageName,"com.android.test"));
    if(!strcmp(packageName,"com.android.test")){
    return -1000;
    }
//add core end

#ifdef LMKD_LOG_STATS
    if (enable_stats_log) {
        if (per_app_memcg) {
            memory_stat_parse_result = memory_stat_from_cgroup(&mem_st, pid, uid);
        } else {
            memory_stat_parse_result = memory_stat_from_procfs(&mem_st, pid);
        }
    }
#endif

    TRACE_KILL_START(pid);

    /* CAP_KILL required */
    r = kill(pid, SIGKILL);

    TRACE_KILL_END();

    if (r) {
        ALOGE("kill(%d): errno=%d", pid, errno);
        /* Delete process record even when we fail to kill so that we don't get stuck on it */
        goto out;
    }

    set_process_group_and_prio(pid, SP_FOREGROUND, ANDROID_PRIORITY_HIGHEST);

    inc_killcnt(procp->oomadj);
    if (reason) {
        ALOGI("Kill '%s' (%d), uid %d, oom_adj %d to free %ldkB; reason: %s", taskname, pid,
              uid, procp->oomadj, tasksize * page_k, reason);
    } else {
        ALOGI("Kill '%s' (%d), uid %d, oom_adj %d to free %ldkB", taskname, pid,
              uid, procp->oomadj, tasksize * page_k);
    }
.....
    return result;
}
```

在lowmemorykiller低内存时，禁止某个app被kill掉功能实现中，在通过上述的源码分析得知，在lkmd机制中关于杀进程的相关 方法中，在find\_and\_kill\_multi\_processes(int min\_score\_adj, const char \*reason, bool kill\_all)和find\_and\_kill\_process\_adj\_locked(int adj, bool is\_critical) 和find\_and\_kill\_process(int min\_score\_adj, const char \*reason)的一些相关的lkmd机制的杀进程的方法中，这样就是调用 kill\_one\_process(struct proc\* procp, int min\_oom\_score, const char \*reason)来根据uid gid等参数来杀进程，所以就可以在 这个方法中，来通过获取当前的进程包名来判断是否来杀进程，来实现禁止杀掉某些进程的功能，所以通过上述添加 strcmp(packageName,"com.android.test")来判断当前包名是否为禁止杀进程的应用，然后返回-1000，禁止走 下面的杀掉进程的流程来实现禁止某个app进程被杀的功能



