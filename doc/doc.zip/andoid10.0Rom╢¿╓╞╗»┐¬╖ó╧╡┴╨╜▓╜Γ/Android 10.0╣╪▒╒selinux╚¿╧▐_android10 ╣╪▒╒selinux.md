



在开发中，我们经常会遇到由于SELinux造成的各种权限不足，即使拥有“万能的root权限”，也不能获取全部的权限，所以怎么样关闭selinux权限呢



```

system/core/init/selinux.cpp

bool IsEnforcing() {
    {
        int fd(open("/mboot/selinux", O_RDONLY | O_CLOEXEC | O_BINARY));
        if (fd != -1) {
            char v = 0xff;
            if (read(fd, &v, 1) < 0)
                PLOG(ERROR) << "Failed to read /mboot/selinux";
            close(fd);
            LOG(WARNING) << "/mboot/selinux is " << v;
            return v == '1';
        }
    }
    if (ALLOW_PERMISSIVE_SELINUX) {
        return StatusFromCmdline() == SELINUX_ENFORCING;
    }
    return true;
}
```

直接return true;就表示关闭selinux权限


2. selinux.cpp isenfocing 强制设置为0



```

void SelinuxInitialize() {
    Timer t;

    LOG(INFO) << "Loading SELinux policy";
    if (!LoadPolicy()) {
        LOG(FATAL) << "Unable to load SELinux policy";
    }

    bool kernel_enforcing = (security_getenforce() == 1);
    bool is_enforcing = IsEnforcing();
	is_enforcing = 0;
    if (kernel_enforcing != is_enforcing) {
        if (security_setenforce(is_enforcing)) {
            PLOG(FATAL) << "security_setenforce(%s) failed" << (is_enforcing ? "true" : "false");
        }
    }

    if (auto result = WriteFile("/sys/fs/selinux/checkreqprot", "0"); !result) {
        LOG(FATAL) << "Unable to write to /sys/fs/selinux/checkreqprot: " << result.error();
    }

    // init's first stage can't set properties, so pass the time to the second stage.
    setenv("INIT_SELINUX_TOOK", std::to_string(t.duration().count()).c_str(), 1);
}
```

3.验证是否关闭


adb shell setenforce 0


adb shell getenforce 如果返回 Permissive 表示关闭了selinux权限



