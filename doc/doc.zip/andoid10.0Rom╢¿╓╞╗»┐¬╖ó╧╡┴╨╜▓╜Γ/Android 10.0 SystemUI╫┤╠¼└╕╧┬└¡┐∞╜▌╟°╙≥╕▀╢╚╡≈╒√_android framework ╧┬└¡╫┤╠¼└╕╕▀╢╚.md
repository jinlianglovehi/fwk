






### 1.概述


在10.0的产品开发中，对SystemUI定制化开发的需求也是挺多的，在SystemUI定制化过程中，产品需求要求对QuickQSPanel的设置固定高度，然后好在QuickQSPanel增加控件，实现对QuickQSPanel的定制化功能


### 2.SystemUI状态栏下拉快捷区域高度调整的核心类



```
frameworks/base/packages/SystemUI/res/layout/quick_status_bar_expanded_header.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java

```

### 3.SystemUI状态栏下拉快捷区域高度调整的核心功能分析和实现


在SystemUI下拉状态栏布局，找到相关的QuickQSPanel的设置高度的类分析，从而看到  
 相关加载布局的时候是怎么设置的，来完成功能  
 在下拉状态栏后第一次展开的布局其实是quick\_status\_bar\_expanded\_header.xml  
 而它的布局为：



```
<com.android.systemui.qs.QuickStatusBarHeader
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/header"
    android:layout_width="match\_parent"
    android:layout_height="@\*android:dimen/quick\_qs\_total\_height"
    android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
    android:background="@android:color/transparent"
    android:baselineAligned="false"
    android:clickable="false"
    android:clipChildren="false"
    android:clipToPadding="false"
    android:paddingTop="0dp"
    android:paddingEnd="0dp"
    android:paddingStart="0dp"
    android:elevation="4dp" >

    <include layout="@layout/quick\_status\_bar\_header\_system\_icons" />

    <!-- Status icons within the panel itself (and not in the top-most status bar) -->
    <include layout="@layout/quick\_qs\_status\_icons" />

    <!-- Layout containing tooltips, alarm text, etc. -->
    <include layout="@layout/quick\_settings\_header\_info" />

    <com.android.systemui.qs.QuickQSPanel
        android:id="@+id/quick\_qs\_panel"
        android:layout_width="match\_parent"
        android:layout_height="48dp"
        android:layout_below="@id/quick\_qs\_status\_icons"
        android:layout_marginStart="@dimen/qs\_header\_tile\_margin\_horizontal"
        android:layout_marginEnd="@dimen/qs\_header\_tile\_margin\_horizontal"
        android:accessibilityTraversalAfter="@+id/date\_time\_group"
        android:accessibilityTraversalBefore="@id/expand\_indicator"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:focusable="true"
        android:importantForAccessibility="yes" />

    <com.android.systemui.statusbar.AlphaOptimizedImageView
        android:id="@+id/qs\_detail\_header\_progress"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_alignParentBottom="true"
        android:alpha="0"
        android:background="@color/qs\_detail\_progress\_track"
        android:src="@drawable/indeterminate\_anim"/>

    <TextView
        android:id="@+id/header\_debug\_info"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_vertical"
        android:fontFamily="sans-serif-condensed"
        android:padding="2dp"
        android:textColor="#00A040"
        android:textSize="11dp"
        android:textStyle="bold"
        android:visibility="invisible"/>

</com.android.systemui.qs.QuickStatusBarHeader>

```

从quick\_status\_bar\_expanded\_header.xml的布局文件看出其实在下拉状态栏中是由  
 QuickStatusBarHeader 负责管理的，设置下拉状态栏高度  
 所以就要从这里来设定固定高度


首选看它的源码



```
  private void updateResources() {
        Resources resources = mContext.getResources();
        updateMinimumHeight();

        // Update height for a few views, especially due to landscape mode restricting space.
        mHeaderTextContainerView.getLayoutParams().height =
                resources.getDimensionPixelSize(R.dimen.qs_header_tooltip_height);
        mHeaderTextContainerView.setLayoutParams(mHeaderTextContainerView.getLayoutParams());

        mSystemIconsView.getLayoutParams().height = resources.getDimensionPixelSize(
                com.android.internal.R.dimen.quick_qs_offset_height);
        mSystemIconsView.setLayoutParams(mSystemIconsView.getLayoutParams());

        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        if (mQsDisabled) {
            lp.height = resources.getDimensionPixelSize(
                    com.android.internal.R.dimen.quick_qs_offset_height);
        } else {
            lp.height = Math.max(getMinimumHeight(),
                    resources.getDimensionPixelSize(
                            com.android.internal.R.dimen.quick_qs_total_height));
        }

        setLayoutParams(lp);

        updateStatusIconAlphaAnimator();
        updateHeaderTextContainerAlphaAnimator();
    }

```

在QuickStatusBarHeader.java的onFinishInflate() 来负责给页面的加载数据，也会在updateResources();  
 中负责绘制状态栏的高度  
 这里来负责计算高度，然后设置其高度  
 所以具体修改就是在这里



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java

+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QuickStatusBarHeader.java

@@ -69,7 +69,6 @@ import com.android.systemui.statusbar.policy.ZenModeController;

 

 import java.util.Locale;

 import java.util.Objects;

-

 import javax.inject.Inject;

 import javax.inject.Named;

 

@@ -162,7 +161,6 @@ public class QuickStatusBarHeader extends RelativeLayout implements

         StatusIconContainer iconContainer = findViewById(R.id.statusIcons);

         iconContainer.setShouldRestrictIcons(false);

         mIconManager = new TintedIconManager(iconContainer);

-

         // Views corresponding to the header info section (e.g. ringer and next alarm).

         mHeaderTextContainerView = findViewById(R.id.header_text_container);

         mStatusSeparator = findViewById(R.id.status_separator);

@@ -312,12 +310,9 @@ public class QuickStatusBarHeader extends RelativeLayout implements

 

         FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();

         if (mQsDisabled) {

-            lp.height = resources.getDimensionPixelSize(

-                    com.android.internal.R.dimen.quick_qs_offset_height);

+            lp.height = resources.getDimensionPixelSize(R.dimen.quick_qs_height);

         } else {

-            lp.height = Math.max(getMinimumHeight(),

-                    resources.getDimensionPixelSize(

-                            com.android.internal.R.dimen.quick_qs_total_height));

+            lp.height = Math.max(getMinimumHeight(),resources.getDimensionPixelSize(R.dimen.quick_qs_height));

         }

 

         setLayoutParams(lp);

```

quick\_qs\_height 就是定义在dimens.xml中的高度，设置为lp.height就可以了





