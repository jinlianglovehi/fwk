



## 1.前言


在10.0的系统产品开发中，在关于mtk的8788的相关芯片开发中，发现在横屏的时候，camera2摄像头的预览方向旋转90度，所以 就需要校准下关于摄像头的方向，让横屏也能正常预览


## 2. mt8788关于摄像头方向旋转功能实现的核心类



```
vendor\mediatek\proprietary\custom\mt6771\hal\imgsensor_src\cfg_setting_imgsensor.cpp
vendor/mediatek/proprietary/custom/mt6771/hal/inc/camera_custom_imgsensor_cfg.h

```

## 3. mt8788关于摄像头方向旋转功能实现的核心功能分析和实现


在实际的camera摄像头功能开发中，在当我们旋转屏幕默认为竖屏的时候，进行摄像头旋转采集的数据一般是横向的，而人预览的方向一般为竖向的。摄像头的采集方向是固定的，不管我们怎么旋转手机，它都沿固定方向进行采集 如果我们想要采集数据能够被正确预览，就需要根据采集方向和屏幕旋转角度，对预览画面进行旋转，所以会出现预览方向和 实现显示方向不同的问题 摄像头感器的取景方向与手机正常方向成90度夹角，此时我们要考虑将摄像头旋转90度，以实现正常的取景方向。按理来说，当我们旋转摄像头之后，以正常的手机方向来打开相机时，看到的预览图像是竖向的，实际图像也应该和预览一致。但是，当拍照后，当我们打开系统图库，看到的实际图像却是横向的，即预览图像与手机方向不一致。 这是因为系统自带的相机在Android系统底层根据当前手机屏幕的方向对图像传感器采集到的数据进行了旋转，所以无论我们怎么旋转手机屏幕，看到的相机预览图片始终是“不正常”的。而对于自定义的相机，如果没有对图像传感器的图片进行旋转处理，那么看到的实际图片就是横向 在通过相关分析得知，在关于修改camera2的旋转方向，一种方法就是通过修改驱动，然后在驱动中通过寄存器来控制 sensor的输出方向，另外一种方法就是通过修改摄像头的方向,可以在这里面旋转摄像头的方向 路径:vendor\mediatek\proprietary\custom\平台\hal\imgsensor\_src\cfg\_setting\_imgsensor.cpp 修改.orientation 中的值



```

#ifndef _CAMERA_CUSTOM_IMGSENSOR_CFG_
#define _CAMERA_CUSTOM_IMGSENSOR_CFG_

#include "kd_camera_feature.h"

namespace NSCamCustomSensor
{
/*******************************************************************************
* Sensor mclk usage
*******************************************************************************/
typedef enum {
    CUSTOM_CFG_MCLK_1 = 0x0,    //mclk1
    CUSTOM_CFG_MCLK_2,    //mclk2
    CUSTOM_CFG_MCLK_3,    //mclk3
    CUSTOM_CFG_MCLK_4,
    CUSTOM_CFG_MCLK_5,
    CUSTOM_CFG_MCLK_MAX_NUM,
    CUSTOM_CFG_MCLK_NONE
} CUSTOM_CFG_MCLK;

/*******************************************************************************
* MIPI sensor pad usage
*******************************************************************************/
typedef enum {
    CUSTOM_CFG_CSI_PORT_0 = 0x0,// 4D1C
    CUSTOM_CFG_CSI_PORT_1,         // 4D1C
    CUSTOM_CFG_CSI_PORT_2,         // 4D1C
    CUSTOM_CFG_CSI_PORT_0A,      // 2D1C
    CUSTOM_CFG_CSI_PORT_0B,      // 2D1C
    CUSTOM_CFG_CSI_PORT_MAX_NUM,
    CUSTOM_CFG_CSI_PORT_NONE     //for non-MIPI sensor
} CUSTOM_CFG_CSI_PORT;

/*******************************************************************************
* Sensor Placement Facing Direction
*
*   CUSTOM_CFG_DIR_REAR  : Back side
*   CUSTOM_CFG_DIR_FRONT : Front side (LCD side)
*******************************************************************************/
typedef enum {
    CUSTOM_CFG_DIR_REAR,
    CUSTOM_CFG_DIR_FRONT,
    CUSTOM_CFG_DIR_MAX_NUM,
    CUSTOM_CFG_DIR_NONE
} CUSTOM_CFG_DIR;

/*******************************************************************************
* Sensor Input Data Bit Order
*
*   CUSTOM_CFG_BITORDER_9_2 : raw data input [9:2]
*   CUSTOM_CFG_BITORDER_7_0 : raw data input [7:0]
*******************************************************************************/
typedef enum {
    CUSTOM_CFG_BITORDER_9_2,
    CUSTOM_CFG_BITORDER_7_0,
    CUSTOM_CFG_BITORDER_MAX_NUM,
    CUSTOM_CFG_BITORDER_NONE
} CUSTOM_CFG_BITORDER;

typedef enum {
    CUSTOM_CFG_SECURE_NONE,
    CUSTOM_CFG_SECURE_M0
} CUSTOM_CFG_SECURE;

typedef struct {
    IMGSENSOR_SENSOR_IDX sensorIdx;
    CUSTOM_CFG_MCLK      mclk;
    CUSTOM_CFG_CSI_PORT  port;
    CUSTOM_CFG_DIR       dir;
    CUSTOM_CFG_BITORDER  bitOrder;
    unsigned int         orientation;
    unsigned int         horizontalFov;
    unsigned int         verticalFov;
    CUSTOM_CFG_SECURE    secure;
} CUSTOM_CFG;

/*******************************************************************************
* Get Custom Configuration
*******************************************************************************/
CUSTOM_CFG* getCustomConfig(IMGSENSOR_SENSOR_IDX const sensorIdx);

};  //NSCamCustomSensor
#endif  //  _CAMERA_CUSTOM_IMGSENSOR_CFG_
```

在实现mt8788关于摄像头方向旋转功能实现的核心功能中，在通过上述的分析得知，在 cfg\_setting\_imgsensor.h中主要就是定义一些关于摄像头sensor的相关旋转方向的定制，最关键的实现部分 就是在cfg\_setting\_imgsensor.cpp中的核心方法来定义roration等属性来定义摄像头camera2的旋转方向 接下来就来分析下相关的功能实现


## 3.2 cfg\_setting\_imgsensor.cpp中关于摄像头方向的旋转功能实现


在实现mt8788关于摄像头方向旋转功能实现的核心功能中，在通过上述的分析得知，在 cfg\_setting\_imgsensor.cpp中 具体实现了关于摄像头旋转方向的定义，核心属性roration决定旋转方向，接下来具体实现相关功能



```
#include "camera_custom_imgsensor_cfg.h"

namespace NSCamCustomSensor {

static CUSTOM_CFG gCustomCfg[] = {
    {
        .sensorIdx     = IMGSENSOR_SENSOR_IDX_MAIN,
        .mclk          = CUSTOM_CFG_MCLK_1,
        .port          = CUSTOM_CFG_CSI_PORT_0,
        .dir           = CUSTOM_CFG_DIR_REAR,
        .bitOrder      = CUSTOM_CFG_BITORDER_9_2,
-        .orientation   = 90,
+        .orientation   = 180,
        .horizontalFov = 67,
        .verticalFov   = 49
    },
    {
        .sensorIdx     = IMGSENSOR_SENSOR_IDX_SUB,
        .mclk          = CUSTOM_CFG_MCLK_2,
        .port          = CUSTOM_CFG_CSI_PORT_1,
        .dir           = CUSTOM_CFG_DIR_FRONT,
        .bitOrder      = CUSTOM_CFG_BITORDER_9_2,
        .orientation   = 270,
        .horizontalFov = 63,
        .verticalFov   = 40,
        .secure        = CUSTOM_CFG_SECURE_M0
    },
    {
        .sensorIdx     = IMGSENSOR_SENSOR_IDX_MAIN2,
        .mclk          = CUSTOM_CFG_MCLK_3,
        .port          = CUSTOM_CFG_CSI_PORT_2,
        .dir           = CUSTOM_CFG_DIR_REAR,
        .bitOrder      = CUSTOM_CFG_BITORDER_9_2,
        .orientation   = 90,
        .horizontalFov = 75,
        .verticalFov   = 60
        },
    {
        .sensorIdx     = IMGSENSOR_SENSOR_IDX_SUB2,
        .mclk          = CUSTOM_CFG_MCLK_3,
        .port          = CUSTOM_CFG_CSI_PORT_2,
        .dir           = CUSTOM_CFG_DIR_FRONT,
        .bitOrder      = CUSTOM_CFG_BITORDER_9_2,
        .orientation   = 90,
        .horizontalFov = 75,
        .verticalFov   = 60,
        .secure        = CUSTOM_CFG_SECURE_M0
        },

    /* Add custom configuration before this line */
    {
        .sensorIdx     = IMGSENSOR_SENSOR_IDX_NONE,
        .mclk          = CUSTOM_CFG_MCLK_NONE,
        .port          = CUSTOM_CFG_CSI_PORT_NONE,
        .dir           = CUSTOM_CFG_DIR_NONE,
        .bitOrder      = CUSTOM_CFG_BITORDER_NONE,
        .orientation   = 0,
        .horizontalFov = 0,
        .verticalFov   = 0
    }
};

CUSTOM_CFG* getCustomConfig(IMGSENSOR_SENSOR_IDX const sensorIdx)
{
    CUSTOM_CFG *pCustomCfg = &gCustomCfg[IMGSENSOR_SENSOR_IDX_MIN_NUM];

    if (sensorIdx >= IMGSENSOR_SENSOR_IDX_MAX_NUM || sensorIdx < IMGSENSOR_SENSOR_IDX_MIN_NUM)
        return 0;

    while(pCustomCfg->sensorIdx != IMGSENSOR_SENSOR_IDX_NONE && pCustomCfg->sensorIdx != sensorIdx)
        pCustomCfg++;

    if (pCustomCfg->sensorIdx == IMGSENSOR_SENSOR_IDX_NONE)
        return 0;

    return pCustomCfg;
}

};
```

在实现mt8788关于摄像头方向旋转功能实现的核心功能中，在通过上述的分析得知，在 cfg\_setting\_imgsensor.cpp中 的核心源码中，经过分析得知gCustomCfg[]就是关于定义camera的相关旋转方向的功能，所以就需要在第一组默认的配置 sensor参数的旋转属性 .orientation = 90,改成 .orientation = 180就可以在横屏的时候 sensor旋转90度，然后预览方向 就可以和摄像头方向一致了 实现了摄像头方向旋转功能



