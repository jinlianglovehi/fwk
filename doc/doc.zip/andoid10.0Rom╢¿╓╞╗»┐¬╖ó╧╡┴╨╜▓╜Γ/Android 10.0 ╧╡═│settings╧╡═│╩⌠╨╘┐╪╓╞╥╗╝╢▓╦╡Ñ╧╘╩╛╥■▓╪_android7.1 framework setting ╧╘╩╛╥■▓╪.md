



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.系统Settings一级菜单显示隐藏的核心代码](#2.%E7%B3%BB%E7%BB%9FSettings%E4%B8%80%E7%BA%A7%E8%8F%9C%E5%8D%95%E6%98%BE%E7%A4%BA%E9%9A%90%E8%97%8F%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.系统Settings一级菜单显示隐藏的核心代码功能分析](#3.%E7%B3%BB%E7%BB%9FSettings%E4%B8%80%E7%BA%A7%E8%8F%9C%E5%8D%95%E6%98%BE%E7%A4%BA%E9%9A%90%E8%97%8F%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 SettingsHomepageActivity.java关于加载菜单的相关代码分析](#%C2%A03.1%20SettingsHomepageActivity.java%E5%85%B3%E4%BA%8E%E5%8A%A0%E8%BD%BD%E8%8F%9C%E5%8D%95%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 TopLevelSettings的关于一级菜单的相关代码分析](#3.2%20TopLevelSettings%E7%9A%84%E5%85%B3%E4%BA%8E%E4%B8%80%E7%BA%A7%E8%8F%9C%E5%8D%95%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)




---



## 1.概述


 在进行定制化开发中，系统settings的一级菜单有些在客户需求中，要求通过系统属性来控制显示隐藏，从而达到控制一级菜单的显示的目的，而系统settings是通过静态加载的方式负责显示隐藏


## 2.系统Settings一级菜单显示隐藏的核心代码



```
  packages\apps\Settings\src\com\android\settings\homepage\SettingsHomepageActivity.java
  packages\apps\Settings\src\com\android\settings\homepage\TopLevelSettings.java
  packages\apps\Settings\res\xml\top_level_settings.xml
```

## 3.系统Settings一级菜单显示隐藏的核心代码功能分析


在系统Settings的开发中，在通过系统源码发现  
 Android系统设置的主界面是com.android.settings.Settings, 但是它只是一个activity-alias,  
 指向的是com.android.settings.Settings.homepage.SettingsHomepageActivity  
 从清单文件AndroidManifest.xml可以发现targetActivity属性，实质应是SettingsHomepageActivity.java。  
 Settings应用UI布局主要是在SettingsHomepageActivity中加载的  
 DEFAULT LAUNCHER属性就说明SettingsHomepageActivity就是系统设置apk启动的主页activity  
 在com.android.settings.Settings.homepage.SettingsHomepageActivity中的相关方法中，  
 onCreate()方法中，我们可以看出是有两部分组成：1、头部搜索框。2、一级菜单选项  
 在可以看到主界面的layout为settings\_homepage\_container.xml中  
 一级菜单选项滑动主要是采用NestedScrollView控件。顶部搜索框则采用AppBarLayout控件  
 接下来就分析下com.android.settings.Settings.homepage.SettingsHomepageActivity的相关方法



###  3.1 SettingsHomepageActivity.java关于加载菜单的相关代码分析



```
 public class SettingsHomepageActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_homepage_container);
        final View root = findViewById(R.id.settings_homepage_container);
        root.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        setHomepageContainerPaddingTop();

        final Toolbar toolbar = findViewById(R.id.search_action_bar);
        FeatureFactory.getFactory(this).getSearchFeatureProvider()
                .initSearchToolbar(this /* activity */, toolbar, SettingsEnums.SETTINGS_HOMEPAGE);

        final ImageView avatarView = findViewById(R.id.account_avatar);
        getLifecycle().addObserver(new AvatarViewMixin(this, avatarView));
        getLifecycle().addObserver(new HideNonSystemOverlayMixin(this));

        if (!getSystemService(ActivityManager.class).isLowRamDevice()) {
            // Only allow contextual feature on high ram devices.
            //showFragment(new ContextualCardsFragment(), R.id.contextual_cards_content);
        }
        showFragment(new TopLevelSettings(), R.id.main_content);
        ((FrameLayout) findViewById(R.id.main_content))
                .getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
        findViewById(R.id.search_bar).setVisibility(View.GONE);
    }

    private void showFragment(Fragment fragment, int id) {
        final FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        final Fragment showFragment = fragmentManager.findFragmentById(id);

        if (showFragment == null) {
            fragmentTransaction.add(id, fragment);
        } else {
            fragmentTransaction.show(showFragment);
        }
        fragmentTransaction.commit();
    }

    @VisibleForTesting
    void setHomepageContainerPaddingTop() {
        final View view = this.findViewById(R.id.homepage_container);

        final int searchBarHeight = getResources().getDimensionPixelSize(R.dimen.search_bar_height);
        final int searchBarMargin = getResources().getDimensionPixelSize(R.dimen.search_bar_margin);

        // The top padding is the height of action bar(48dp) + top/bottom margins(16dp)
        final int paddingTop = searchBarHeight + searchBarMargin * 2;
        //if(settings_custom ==1)view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
	    view.setPadding(0 /* left */, 0, 0 /* right */, 0 /* bottom */);
    }
}
```

从onCreate(Bundle savedInstanceState)中showFragment(new TopLevelSettings(), R.id.main\_content);  
 可以看出一级菜单是在TopLevelSettings()中构建的  
 接下来看TopLevelSettings的相关代码


### 3.2 TopLevelSettings的关于一级菜单的相关代码分析



```
public class TopLevelSettings extends DashboardFragment implements
        PreferenceFragmentCompat.OnPreferenceStartFragmentCallback {

    private static final String TAG = "TopLevelSettings";
    public TopLevelSettings() {
        final Bundle args = new Bundle();
        // Disable the search icon because this page uses a full search view in actionbar.
        args.putBoolean(NEED_SEARCH_ICON_IN_ACTION_BAR, false);
        setArguments(args);
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
		int settings_custom = Settings.Global.getInt(getContext().getContentResolver(),"settings_custom",1);
		PreferenceScreen preferenceScreen = getPreferenceScreen();
	}

    @Override
    protected int getPreferenceScreenResId() {
   // 核心部分代码
		int settings_custom = Settings.Global.getInt(getContext().getContentResolver(),"settings_cus",1);
        Log.e("Settings","getPreferenceScreenResId---settings_custom:"+settings_custom);
        if(settings_custom==1){
           return R.xml.top_level_settings;
		}else{
           return R.xml.top_level_settings_cus;
		}
    }

    @Override
    protected String getLogTag() {
        return TAG;
    }

    @Override
    public int getMetricsCategory() {
        return SettingsEnums.DASHBOARD_SUMMARY;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        use(SupportPreferenceController.class).setActivity(getActivity());
    }

    @Override
    public int getHelpResource() {
        // Disable the help icon because this page uses a full search view in actionbar.
        return 0;
    }

    @Override
    public Fragment getCallbackFragment() {
        return this;
    }

    @Override
    public boolean onPreferenceStartFragment(PreferenceFragmentCompat caller, Preference pref) {
        new SubSettingLauncher(getActivity())
                .setDestination(pref.getFragment())
                .setArguments(pref.getExtras())
                .setSourceMetricsCategory(caller instanceof Instrumentable
                        ? ((Instrumentable) caller).getMetricsCategory()
                        : Instrumentable.METRICS_CATEGORY_UNKNOWN)
                .setTitleRes(-1)
                .launch();
        return true;
    }


}
```

而 protected int getPreferenceScreenResId()负责加载一级菜单的xml文件  
 接下来看下top\_level\_settings.xml



```
<PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:key="top_level_settings">

    <Preference
        android:key="top_level_network"
        android:title="@string/network_dashboard_title"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_network"
        android:order="-120"
        android:fragment="com.android.settings.network.NetworkDashboardFragment"
        settings:controller="com.android.settings.network.TopLevelNetworkEntryPreferenceController"/>

    <Preference
        android:key="top_level_connected_devices"
        android:title="@string/connected_devices_dashboard_title"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_connected_device"
        android:order="-110"
        android:fragment="com.android.settings.connecteddevice.ConnectedDeviceDashboardFragment"
        settings:controller="com.android.settings.connecteddevice.TopLevelConnectedDevicesPreferenceController"/>

    <Preference
        android:key="top_level_apps_and_notifs"
        android:title="@string/app_and_notification_dashboard_title"
        android:summary="@string/app_and_notification_dashboard_summary"
        android:icon="@drawable/ic_homepage_apps"
        android:order="-100"
        android:fragment="com.android.settings.applications.AppAndNotificationDashboardFragment"/>

    <Preference
        android:key="top_level_battery"
        android:title="@string/power_usage_summary_title"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_battery"
        android:fragment="com.android.settings.fuelgauge.PowerUsageSummary"
        android:order="-90"
        settings:controller="com.android.settings.fuelgauge.TopLevelBatteryPreferenceController"/>

    <Preference
        android:key="top_level_display"
        android:title="@string/display_settings"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_display"
        android:order="-80"
        android:fragment="com.android.settings.DisplaySettings"
        settings:controller="com.android.settings.display.TopLevelDisplayPreferenceController"/>

     <Preference
        android:key="top_level_timerpower"
        android:title="@string/swtichmachine"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_timerpower"
        android:order="-75"
        android:fragment="com.sprd.settings.timerpower.TimerPower"
        settings:controller="com.sprd.settings.timerpower.TopLevelTimerPowerPreferenceController"/>

    <Preference
        android:key="top_level_sound"
        android:title="@string/sound_settings"
        android:summary="@string/sound_dashboard_summary"
        android:icon="@drawable/ic_homepage_sound"
        android:order="-70"
        android:fragment="com.android.settings.notification.SoundSettings"/>

    <Preference
        android:key="top_level_storage"
        android:title="@string/storage_settings"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_storage"
        android:order="-60"
        android:fragment="com.android.settings.deviceinfo.StorageSettings"
        settings:controller="com.android.settings.deviceinfo.TopLevelStoragePreferenceController"/>

    <Preference
        android:key="top_level_privacy"
        android:title="@string/privacy_dashboard_title"
        android:summary="@string/privacy_dashboard_summary"
        android:icon="@drawable/ic_homepage_privacy"
        android:order="-55"
        android:fragment="com.android.settings.privacy.PrivacyDashboardFragment"/>

    <Preference
        android:key="top_level_location"
        android:title="@string/location_settings_title"
        android:summary="@string/location_settings_loading_app_permission_stats"
        android:icon="@drawable/ic_homepage_location"
        android:order="-50"
        android:fragment="com.android.settings.location.LocationSettings"
        settings:controller="com.android.settings.location.TopLevelLocationPreferenceController"/>

  

    <Preference
        android:key="top_level_system"
        android:title="@string/header_category_system"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_system_dashboard"
        android:order="10"
        android:fragment="com.android.settings.system.SystemDashboardFragment"
        settings:controller="com.android.settings.system.TopLevelSystemPreferenceController"/>

    <Preference
        android:key="top_level_about_device"
        android:title="@string/about_settings"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_about"
        android:order="20"
        android:fragment="com.android.settings.deviceinfo.aboutphone.MyDeviceInfoFragment"
        settings:controller="com.android.settings.deviceinfo.aboutphone.TopLevelAboutDevicePreferenceController"/>

    <Preference
        android:key="top_level_support"
        android:summary="@string/support_summary"
        android:title="@string/page_tab_title_support"
        android:icon="@drawable/ic_homepage_support"
        android:order="100"
        settings:controller="com.android.settings.support.SupportPreferenceController"/>

</PreferenceScreen>
```

这里控件就是所有的一级菜单  
 所以可以自己自定义一个xml作为裁剪后的一级菜单然后在加载的时候可以根据系统属性值来判断加载哪个xml文件



```
top_level_settings_cus.xml
<PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:key="top_level_settings">

    <Preference
        android:key="top_level_network"
        android:title="@string/network_dashboard_title"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_network"
        android:order="-120"
        android:fragment="com.android.settings.network.NetworkDashboardFragment"
        settings:controller="com.android.settings.network.TopLevelNetworkEntryPreferenceController"/>

    <!--Preference
        android:key="top_level_connected_devices"
        android:title="@string/connected_devices_dashboard_title"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_connected_device"
        android:order="-110"
        android:fragment="com.android.settings.connecteddevice.ConnectedDeviceDashboardFragment"
        settings:controller="com.android.settings.connecteddevice.TopLevelConnectedDevicesPreferenceController"/-->

    <!--Preference
        android:key="top_level_apps_and_notifs"
        android:title="@string/app_and_notification_dashboard_title"
        android:summary="@string/app_and_notification_dashboard_summary"
        android:icon="@drawable/ic_homepage_apps"
        android:order="-100"
        android:fragment="com.android.settings.applications.AppAndNotificationDashboardFragment"/-->

    <!--Preference
        android:key="top_level_battery"
        android:title="@string/power_usage_summary_title"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_battery"
        android:fragment="com.android.settings.fuelgauge.PowerUsageSummary"
        android:order="-90"
        settings:controller="com.android.settings.fuelgauge.TopLevelBatteryPreferenceController"/-->

    <Preference
        android:key="top_level_display"
        android:title="@string/display_settings"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_display"
        android:order="-80"
        android:fragment="com.android.settings.DisplaySettings"
        settings:controller="com.android.settings.display.TopLevelDisplayPreferenceController"/>

     <!--Preference
        android:key="top_level_timerpower"
        android:title="@string/swtichmachine"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_timerpower"
        android:order="-75"
        android:fragment="com.sprd.settings.timerpower.TimerPower"
        settings:controller="com.sprd.settings.timerpower.TopLevelTimerPowerPreferenceController"/-->

    <!--Preference
        android:key="top_level_sound"
        android:title="@string/sound_settings"
        android:summary="@string/sound_dashboard_summary"
        android:icon="@drawable/ic_homepage_sound"
        android:order="-70"
        android:fragment="com.android.settings.notification.SoundSettings"/-->

    <!--Preference
        android:key="top_level_storage"
        android:title="@string/storage_settings"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_storage"
        android:order="-60"
        android:fragment="com.android.settings.deviceinfo.StorageSettings"
        settings:controller="com.android.settings.deviceinfo.TopLevelStoragePreferenceController"/-->

   

    <!--Preference
        android:key="top_level_system"
        android:title="@string/header_category_system"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_system_dashboard"
        android:order="10"
        android:fragment="com.android.settings.system.SystemDashboardFragment"
        settings:controller="com.android.settings.system.TopLevelSystemPreferenceController"/-->

    <Preference
        android:key="top_level_about_device"
        android:title="@string/about_settings"
        android:summary="@string/summary_placeholder"
        android:icon="@drawable/ic_homepage_about"
        android:order="20"
        android:fragment="com.android.settings.deviceinfo.aboutphone.MyDeviceInfoFragment"
        settings:controller="com.android.settings.deviceinfo.aboutphone.TopLevelAboutDevicePreferenceController"/>

    <Preference
        android:key="top_level_support"
        android:summary="@string/support_summary"
        android:title="@string/page_tab_title_support"
        android:icon="@drawable/ic_homepage_support"
        android:order="100"
        settings:controller="com.android.settings.support.SupportPreferenceController"/>

</PreferenceScreen>
```

 然后可以通过接口设置settings\_cus的值来退出设置后重新进入settings后看到裁剪后的一级菜单



