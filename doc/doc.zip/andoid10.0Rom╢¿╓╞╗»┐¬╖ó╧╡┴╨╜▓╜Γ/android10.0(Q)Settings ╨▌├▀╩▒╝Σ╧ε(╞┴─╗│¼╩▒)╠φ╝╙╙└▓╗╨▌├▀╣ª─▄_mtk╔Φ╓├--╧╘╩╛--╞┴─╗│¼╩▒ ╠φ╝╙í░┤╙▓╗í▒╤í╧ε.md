






### 1.概述


在10.0的产品开发中，产品需求需要在Settings 的 屏幕超时（休眠时间）项 添加永不休眠选项 通过看TimeoutPreferenceController.java 可知需要在 screen\_timeout\_entries 添加 永不休眠项


### 2.Settings 休眠时间项(屏幕超时)添加永不休眠功能的核心类



```
packages/apps/Settings/res/values-zh-rCN/arrays.xml
packages/apps/Settings/src/com/android/settings/display/TimeoutPreferenceController.java

```

### 3.Settings 休眠时间项(屏幕超时)添加永不休眠功能的核心功能分析和实现


功能分析以及实现思路:


1. 在资源文件 arrays.xml添加 永不休眠项  
 2.在TimeoutPreferenceController切换选项时，添加永不休眠功能


### 3.1 Settings中 添加永不休眠项的相关资源



```
diff --git a/packages/apps/Settings/res/values-zh-rCN/arrays.xml b/packages/apps/Settings/res/values-zh-rCN/arrays.xml
old mode 100644
new mode 100755
index 34ac5a5130..8d54f814a1
--- a/packages/apps/Settings/res/values-zh-rCN/arrays.xml
+++ b/packages/apps/Settings/res/values-zh-rCN/arrays.xml
  <string-array name="screen\_timeout\_entries">
    <item msgid="3342301044271143016">"15 秒"</item>
    <item msgid="8881760709354815449">"30 秒"</item>
    <item msgid="7589406073232279088">"1 分钟"</item>
    <item msgid="7001195990902244174">"2 分钟"</item>
    <item msgid="7489864775127957179">"5 分钟"</item>
    <item msgid="2314124409517439288">"10 分钟"</item>
    <item msgid="6864027152847611413">"30 分钟"</item>
+       <item msgid="1781492122915870416">"永不休眠"</item>
   </string-array>
   <string-array name="dream\_timeout\_entries">
     <item msgid="3149294732238283185">"永不"</item>
diff --git a/packages/apps/Settings/res/values/arrays.xml b/packages/apps/Settings/res/values/arrays.xml
old mode 100644
new mode 100755
index b1fdf4bc5e..78dbd4f311
--- a/packages/apps/Settings/res/values/arrays.xml
+++ b/packages/apps/Settings/res/values/arrays.xml
@@ -48,6 +48,7 @@
   <string-array name="screen\_timeout\_entries">
        <item>15 seconds</item>
        <item>30 seconds</item>
        <item>1 minute</item>
        <item>2 minutes</item>
        <item>5 minutes</item>
        <item>10 minutes</item>
        <item>30 minutes</item>
+               <item>Never</item>
     </string-array>
 
    <string-array name="screen\_timeout\_values" translatable="false">
        <!-- Do not translate. -->
        <item>15000</item>
        <!-- Do not translate. -->
        <item>30000</item>
        <!-- Do not translate. -->
        <item>60000</item>
        <!-- Do not translate. -->
        <item>120000</item>
        <!-- Do not translate. -->
        <item>300000</item>
        <!-- Do not translate. -->
        <item>600000</item>
        <!-- Do not translate. -->
        <item>1800000</item>
+               <!-- Do not translate. -->
+               <item>2147483647</item>
     </string-array>

```

通过上述资源文件中添加对应的永不休眠选项的资源来实现添加永不休眠的功能


### 3.2 TimeoutPreferenceController.java添加实现永不休眠功能


TimeoutPreferenceController把永不休眠的休眠时间设置为最大值 2147483647 然后保存到数据库里面就可以了



```
    <!-- Display settings.  The delay in inactivity before the dream is shown. These are shown in a list dialog. -->
diff --git a/packages/apps/Settings/src/com/android/settings/display/TimeoutPreferenceController.java b/packages/apps/Settings/src/com/android/settings/d
isplay/TimeoutPreferenceController.java
old mode 100644
new mode 100755
index 3849889feb..189a278fe5
--- a/packages/apps/Settings/src/com/android/settings/display/TimeoutPreferenceController.java
+++ b/packages/apps/Settings/src/com/android/settings/display/TimeoutPreferenceController.java
@@ -88,9 +88,11 @@ public class TimeoutPreferenceController extends AbstractPreferenceController im
    @Override
      public void updateState(Preference preference) {
          final TimeoutListPreference timeoutListPreference = (TimeoutListPreference) preference;
          final long currentTimeout = Settings.System.getLong(mContext.getContentResolver(),
                  SCREEN_OFF_TIMEOUT, FALLBACK_SCREEN_TIMEOUT_VALUE);
          timeoutListPreference.setValue(String.valueOf(currentTimeout));
          final DevicePolicyManager dpm =
                  (DevicePolicyManager) mContext.getSystemService(Context.DEVICE_POLICY_SERVICE);
          if (dpm != null) {
              final RestrictedLockUtils.EnforcedAdmin admin =
                      RestrictedLockUtilsInternal.checkIfMaximumTimeToLockIsSet(mContext);
              final long maxTimeout =
                      dpm.getMaximumTimeToLock(null /* admin */, UserHandle.myUserId());
              timeoutListPreference.removeUnusableTimeouts(maxTimeout, admin);
          }
          updateTimeoutPreferenceDescription(timeoutListPreference,
                  Long.parseLong(timeoutListPreference.getValue()));
  
          final EnforcedAdmin admin = RestrictedLockUtilsInternal.checkIfRestrictionEnforced(
                  mContext, UserManager.DISALLOW_CONFIG_SCREEN_TIMEOUT,
                  UserHandle.myUserId());
          if (admin != null) {
              timeoutListPreference.removeUnusableTimeouts(0/* disable all*/, admin);
          }
      }
  
     @Override
     public boolean onPreferenceChange(Preference preference, Object newValue) {
         try {
-            int value = Integer.parseInt((String) newValue);
- Settings.System.putInt(mContext.getContentResolver(), SCREEN\_OFF\_TIMEOUT, value);
- updateTimeoutPreferenceDescription((TimeoutListPreference) preference, value);
+ //int value = Integer.parseInt((String) newValue);
+ //Settings.System.putInt(mContext.getContentResolver(), SCREEN\_OFF\_TIMEOUT, value);
+ long value = Integer.parseInt((String) newValue);
+ Settings.System.putLong(mContext.getContentResolver(), SCREEN\_OFF\_TIMEOUT, value);
+ updateTimeoutPreferenceDescription((TimeoutListPreference) preference, value);
 } catch (NumberFormatException e) {
 Log.e(TAG, "could not persist screen timeout setting", e);
 }
@@ -123,10 +125,14 @@ public class TimeoutPreferenceController extends AbstractPreferenceController im
 private void updateTimeoutPreferenceDescription(TimeoutListPreference preference,
 long currentTimeout) {
 final CharSequence[] entries = preference.getEntries();
 final CharSequence[] values = preference.getEntryValues();
 final String summary;
 if (preference.isDisabledByAdmin()) {
            summary = mContext.getString(com.android.settings.R.string.disabled_by_policy_title);

         } else {
             final CharSequence timeoutDescription = getTimeoutDescription(
                     currentTimeout, entries, values);
-            summary = timeoutDescription == null
+            if(currentTimeout == 2147483647){
+                summary = timeoutDescription.toString();
+            } else {
+                summary = timeoutDescription == null
                     ? ""
                     : mContext.getString(R.string.screen_timeout_summary, timeoutDescription);
-        }
+            }
+               }
         preference.setSummary(summary);
     }

```

通过上述的TimeoutPreferenceController 中通过对onPreferenceChange中屏幕超时选项的修改，判断当是永不休眠的时候，讲设置永不休眠的事件添加到系统数据库中的屏幕超时的属性中去，达到永不休眠功能





