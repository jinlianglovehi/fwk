






### 1.概述


在10.0的系统产品开发中，系统Settings的主页默认带有搜索框，由于产品需求需要去掉所有的搜索框，去掉系统Settings的搜索功能，所以需要去掉首页的搜索框


### 2.Settings去掉搜索框的核心类



```
packages/apps/Settings/src/com/android/settings/homepage/SettingsHomepageActivity.java
packages/apps/Settings/res/layout/settings_homepage_container.xml

```

### 3.Settings去掉搜索框的核心功能实现和分析


首页的布局就是settings\_homepage\_container.xml 而搜索框 就是search\_bar.xml  
 接下来看下settings\_homepage\_container.xml的相关源码



```
<androidx.coordinatorlayout.widget.CoordinatorLayout
     xmlns:android="http://schemas.android.com/apk/res/android"
     xmlns:app="http://schemas.android.com/apk/res-auto"
     android:id="@+id/settings\_homepage\_container"
     android:fitsSystemWindows="true"
     android:layout_width="match\_parent"
     android:layout_height="match\_parent">
 
     <androidx.core.widget.NestedScrollView
         android:id="@+id/main\_content\_scrollable\_container"
         android:layout_width="match\_parent"
         android:layout_height="match\_parent"
         app:layout_behavior="com.android.settings.widget.FloatingAppBarScrollingViewBehavior">
 
         <LinearLayout
             android:id="@+id/homepage\_container"
             android:layout_width="match\_parent"
             android:layout_height="wrap\_content"
             android:orientation="vertical"
             android:descendantFocusability="blocksDescendants">
 
             <FrameLayout
                 android:id="@+id/main\_content"
                 android:layout_width="match\_parent"
                 android:layout_height="wrap\_content"
                 android:animateLayoutChanges="true"
                 android:background="?android:attr/windowBackground"/>
 
         </LinearLayout>
     </androidx.core.widget.NestedScrollView>
 
     <com.google.android.material.appbar.AppBarLayout
         android:layout_width="match\_parent"
         android:layout_height="wrap\_content">
         <include layout="@layout/search\_bar"/>
     </com.google.android.material.appbar.AppBarLayout>
 </androidx.coordinatorlayout.widget.CoordinatorLayout>

```

在settings\_homepage\_container.xml的相关源码可以发现在search\_bar就是主页的搜索框布局  
 接下来看下SettingsHomepageActivity.java系统设置的主页的相关源码



```
public class SettingsHomepageActivity extends FragmentActivity {
  
      @Override
      protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
  
          setContentView(R.layout.settings_homepage_container);
          final View root = findViewById(R.id.settings_homepage_container);
          root.setSystemUiVisibility(
                  View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  
          setHomepageContainerPaddingTop();
  
          final Toolbar toolbar = findViewById(R.id.search_action_bar);
          showFragment(new TopLevelSettings(), R.id.main_content);
          ((FrameLayout) findViewById(R.id.main\_content))
                  .getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
      }
  
      @VisibleForTesting
      void setHomepageContainerPaddingTop() {
          final View view = this.findViewById(R.id.homepage_container);
  
          final int searchBarHeight = getResources().getDimensionPixelSize(R.dimen.search_bar_height);
          final int searchBarMargin = getResources().getDimensionPixelSize(R.dimen.search_bar_margin);
  
          // The top padding is the height of action bar(48dp) + top/bottom margins(16dp)
          final int paddingTop = searchBarHeight + searchBarMargin * 2;
          view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
      }
  }

```

在SettingsHomepageActivity.java中的源码中的onCreate中，findViewById(R.id.search\_action\_bar)中就是获取主页的搜索框，然后去掉搜索框就从这里设置就好，  
 具体实现为：



```
--- a/packages/apps/Settings/src/com/android/settings/homepage/SettingsHomepageActivity.java
+++ b/packages/apps/Settings/src/com/android/settings/homepage/SettingsHomepageActivity.java
@@ -40,9 +40,9 @@ import com.android.settings.accounts.AvatarViewMixin;
 import com.android.settings.core.HideNonSystemOverlayMixin;
 import com.android.settings.homepage.contextualcards.ContextualCardsFragment;
 import com.android.settings.overlay.FeatureFactory;
-
+import android.provider.Settings;
 public class SettingsHomepageActivity extends FragmentActivity {
-
+    private int settings\_display=-1;
     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
@@ -51,7 +51,7 @@ public class SettingsHomepageActivity extends FragmentActivity {
         final View root = findViewById(R.id.settings_homepage_container);
         root.setSystemUiVisibility(
                 View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
-
+        settings_display = Settings.Global.getInt(getContentResolver(),"settings\_display",1);
         setHomepageContainerPaddingTop();
 
         final Toolbar toolbar = findViewById(R.id.search_action_bar);
@@ -64,11 +64,13 @@ public class SettingsHomepageActivity extends FragmentActivity {
 
         if (!getSystemService(ActivityManager.class).isLowRamDevice()) {
             // Only allow contextual feature on high ram devices.
            showFragment(new ContextualCardsFragment(), R.id.contextual_cards_content);
         }
         showFragment(new TopLevelSettings(), R.id.main_content);
         ((FrameLayout) findViewById(R.id.main\_content))
                 .getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);
          //隐藏搜索框       
+        findViewById(R.id.search_bar).setVisibility(
+                settings\_display==0 ? View.GONE: View.VISIBLE);
     }
 
     private void showFragment(Fragment fragment, int id) {
@@ -93,7 +95,8 @@ public class SettingsHomepageActivity extends FragmentActivity {
 
         // The top padding is the height of action bar(48dp) + top/bottom margins(16dp)
         final int paddingTop = searchBarHeight + searchBarMargin * 2;
-        view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
-          //设置置顶距离
+        if(settings_display ==1)view.setPadding(0 /* left */, paddingTop, 0 /* right */, 0 /* bottom */);
+             else view.setPadding(0 /* left */, searchBarMargin, 0 /* right */, 0 /* bottom */);
     }

```

在上述代码中settings\_display的值来判断是否需要隐藏search\_bar，然后设置view的padding的间距





