



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.导航栏横屏固定在底部功能分析](#2.%E5%AF%BC%E8%88%AA%E6%A0%8F%E6%A8%AA%E5%B1%8F%E5%9B%BA%E5%AE%9A%E5%9C%A8%E5%BA%95%E9%83%A8%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.导航栏横屏固定在底部功能代码分析](#3.%E5%AF%BC%E8%88%AA%E6%A0%8F%E6%A8%AA%E5%B1%8F%E5%9B%BA%E5%AE%9A%E5%9C%A8%E5%BA%95%E9%83%A8%E5%8A%9F%E8%83%BD%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 DisplayPolicy.java关于导航栏NavigationBar的方向相关主要代码分析](#%C2%A0%203.1%20DisplayPolicy.java%E5%85%B3%E4%BA%8E%E5%AF%BC%E8%88%AA%E6%A0%8FNavigationBar%E7%9A%84%E6%96%B9%E5%90%91%E7%9B%B8%E5%85%B3%E4%B8%BB%E8%A6%81%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 导航栏横屏固定在底部功能的具体解决方案](#3.2%20%E5%AF%BC%E8%88%AA%E6%A0%8F%E6%A8%AA%E5%B1%8F%E5%9B%BA%E5%AE%9A%E5%9C%A8%E5%BA%95%E9%83%A8%E5%8A%9F%E8%83%BD%E7%9A%84%E5%85%B7%E4%BD%93%E8%A7%A3%E5%86%B3%E6%96%B9%E6%A1%88)




---



## 1.概述


在开发10.0的产品时，在一些横屏的产品中，会发现导航栏不是在顶部，而是出现在右侧，有点不美观，还是和竖屏一样，显示在  
 底部会比较好一些，由于产品美观的需要，需要导航栏在横竖屏的时候都是在底部显示


## 2.导航栏横屏固定在底部功能分析


  在10.0中处理屏幕方向和导航栏NavigationBar的方向都是在DisplayPolicy.java中具体处理的，所以就需要从DisplayPolicy.java中找到  
 具体的解决方案


## 3.导航栏横屏固定在底部功能代码分析


####   3.1 DisplayPolicy.java关于导航栏NavigationBar的方向相关主要代码分析



```
DisplayPolicy(WindowManagerService service, DisplayContent displayContent) {
mService = service;
mContext = displayContent.isDefaultDisplay ? service.mContext
: service.mContext.createDisplayContext(displayContent.getDisplay());
mDisplayContent = displayContent;
mLock = service.getWindowManagerLock();

final int displayId = displayContent.getDisplayId();
mStatusBarController = new StatusBarController(displayId);
mNavigationBarController = new BarController("NavigationBar",
displayId,
View.NAVIGATION_BAR_TRANSIENT,
View.NAVIGATION_BAR_UNHIDE,
View.NAVIGATION_BAR_TRANSLUCENT,
StatusBarManager.WINDOW_NAVIGATION_BAR,
FLAG_TRANSLUCENT_NAVIGATION,
View.NAVIGATION_BAR_TRANSPARENT);

final Resources r = mContext.getResources();
mCarDockEnablesAccelerometer = r.getBoolean(R.bool.config_carDockEnablesAccelerometer);
mDeskDockEnablesAccelerometer = r.getBoolean(R.bool.config_deskDockEnablesAccelerometer);
mForceShowSystemBarsFromExternal = r.getBoolean(R.bool.config_forceShowSystemBars);

mAccessibilityManager = (AccessibilityManager) mContext.getSystemService(
Context.ACCESSIBILITY_SERVICE);
if (!displayContent.isDefaultDisplay) {
mAwake = true;
mScreenOnEarly = true;
mScreenOnFully = true;
}

final Looper looper = UiThread.getHandler().getLooper();
mHandler = new PolicyHandler(looper);
mSystemGestures = new SystemGesturesPointerEventListener(mContext, mHandler,
new SystemGesturesPointerEventListener.Callbacks() {
@Override
public void onSwipeFromTop() {
if (mStatusBar != null) {
requestTransientBars(mStatusBar);
}
}

@Override
public void onSwipeFromBottom() {
if (mNavigationBar != null && mNavigationBarPosition == NAV_BAR_BOTTOM) {
requestTransientBars(mNavigationBar);
}
}

@Override
public void onSwipeFromRight() {
final Region excludedRegion;
synchronized (mLock) {
excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
}
final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
|| mNavigationBarPosition == NAV_BAR_RIGHT;
if (mNavigationBar != null && sideAllowed
&& !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
requestTransientBars(mNavigationBar);
}
}

@Override
public void onSwipeFromLeft() {
final Region excludedRegion;
synchronized (mLock) {
excludedRegion = mDisplayContent.calculateSystemGestureExclusion();
}
final boolean sideAllowed = mNavigationBarAlwaysShowOnSideGesture
|| mNavigationBarPosition == NAV_BAR_LEFT;
if (mNavigationBar != null && sideAllowed
&& !mSystemGestures.currentGestureStartedInRegion(excludedRegion)) {
requestTransientBars(mNavigationBar);
}
}

@Override
public void onFling(int duration) {
if (mService.mPowerManagerInternal != null) {
mService.mPowerManagerInternal.powerHint(
PowerHint.INTERACTION, duration);
}
}

@Override
public void onDebug() {
// no-op
}

private WindowOrientationListener getOrientationListener() {
final DisplayRotation rotation = mDisplayContent.getDisplayRotation();
return rotation != null ? rotation.getOrientationListener() : null;
}

@Override
public void onDown() {
final WindowOrientationListener listener = getOrientationListener();
if (listener != null) {
listener.onTouchStart();
}
}

@Override
public void onUpOrCancel() {
final WindowOrientationListener listener = getOrientationListener();
if (listener != null) {
listener.onTouchEnd();
}
}

@Override
public void onMouseHoverAtTop() {
mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
Message msg = mHandler.obtainMessage(MSG_REQUEST_TRANSIENT_BARS);
msg.arg1 = MSG_REQUEST_TRANSIENT_BARS_ARG_STATUS;
mHandler.sendMessageDelayed(msg, 500 /* delayMillis */);
}

@Override
public void onMouseHoverAtBottom() {
mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
Message msg = mHandler.obtainMessage(MSG_REQUEST_TRANSIENT_BARS);
msg.arg1 = MSG_REQUEST_TRANSIENT_BARS_ARG_NAVIGATION;
mHandler.sendMessageDelayed(msg, 500 /* delayMillis */);
}

@Override
public void onMouseLeaveFromEdge() {
mHandler.removeMessages(MSG_REQUEST_TRANSIENT_BARS);
}
});
displayContent.registerPointerEventListener(mSystemGestures);
displayContent.mAppTransition.registerListenerLocked(
mStatusBarController.getAppTransitionListener());
mImmersiveModeConfirmation = new ImmersiveModeConfirmation(mContext, looper,
mService.mVrModeEnabled);
mAcquireSleepTokenRunnable = () -> {
if (mWindowSleepToken != null) {
return;
}
mWindowSleepToken = service.mAtmInternal.acquireSleepToken(
"WindowSleepTokenOnDisplay" + displayId, displayId);
};
mReleaseSleepTokenRunnable = () -> {
if (mWindowSleepToken == null) {
return;
}
mWindowSleepToken.release();
mWindowSleepToken = null;
};

// TODO: Make it can take screenshot on external display
mScreenshotHelper = displayContent.isDefaultDisplay
? new ScreenshotHelper(mContext) : null;

if (mDisplayContent.isDefaultDisplay) {
mHasStatusBar = true;
mHasNavigationBar = mContext.getResources().getBoolean(R.bool.config_showNavigationBar);

// Allow a system property to override this. Used by the emulator.
// See also hasNavigationBar().
String navBarOverride = SystemProperties.get("qemu.hw.mainkeys");
if ("1".equals(navBarOverride)) {
mHasNavigationBar = false;
} else if ("0".equals(navBarOverride)) {
mHasNavigationBar = true;
}
} else {
mHasStatusBar = false;
mHasNavigationBar = mDisplayContent.supportsSystemDecorations();
}

mRefreshRatePolicy = new RefreshRatePolicy(mService,
mDisplayContent.getDisplayInfo(),
mService.mHighRefreshRateBlacklist);
}

void systemReady() {
mSystemGestures.systemReady();
if (mService.mPointerLocationEnabled) {
setPointerLocationEnabled(true);
}
}
   private int getDisplayId() {
          return mDisplayContent.getDisplayId();
      }
public boolean hasNavigationBar() {
return mHasNavigationBar;
}

public boolean hasStatusBar() {
return mHasStatusBar;
}

public boolean navigationBarCanMove() {
return mNavigationBarCanMove;
}
@NavigationBarPosition
int navigationBarPosition(int displayWidth, int displayHeight, int displayRotation) {
if (navigationBarCanMove() && displayWidth > displayHeight) {
if (displayRotation == Surface.ROTATION_270) {
return NAV_BAR_LEFT;
} else if (displayRotation == Surface.ROTATION_90) {
return NAV_BAR_RIGHT;
}
}
return NAV_BAR_BOTTOM;
}
boolean canNavigationBarMove() {
    return mNavigationBarCanMove;
}

void updateConfigurationAndScreenSizeDependentBehaviors() {
    final Resources res = getCurrentUserResources();
    mNavigationBarCanMove =
            mDisplayContent.mBaseDisplayWidth != mDisplayContent.mBaseDisplayHeight
                    && res.getBoolean(R.bool.config_navBarCanMove);
    mAllowSeamlessRotationDespiteNavBarMoving =
            res.getBoolean(R.bool.config_allowSeamlessRotationDespiteNavBarMoving);
}

从上述代码可以看出
在navigationBarPosition(int displayWidth, int displayHeight, int displayRotation)中
来判断导航栏显示的方向 当navigationBarCanMove()为false的时候 就会显示在底部
所以就是
boolean canNavigationBarMove() {
    return mNavigationBarCanMove;
}
就是mNavigationBarCanMove的参数值
mNavigationBarCanMove =
            mDisplayContent.mBaseDisplayWidth != mDisplayContent.mBaseDisplayHeight
                    && res.getBoolean(R.bool.config_navBarCanMove);
就是由config_navBarCanMove 属性值决定的 查看config.xml
路径：framework/base/core/res/res/values/config.xml
<bool name="config_navBarCanMove">true</bool>
在config中为true 
```

####  3.2 导航栏横屏固定在底部功能的具体解决方案



```
路径：framework/base/core/res/res/values/config.xml
-<bool name="config_navBarCanMove">true</bool>
+<bool name="config_navBarCanMove">false</bool>
```



