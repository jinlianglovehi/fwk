






在系统日历源码中，有个bug 就是头部显示日期是一个图标，所以客户提出是有问题的.结果看源码才发现是图片写死了的原因  
 所以接下来分析下修改


1. 日历主页面AllInOneActivity.java 代码分析  
 查看源码发现：



```
 private void configureActionBar(int viewType) {
     createButtonsSpinner(viewType, mIsTabletConfig);
     if (mIsMultipane) {           
        mActionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM
              | ActionBar.DISPLAY_SHOW_HOME); //motify
     } else {
         mActionBar.setDisplayOptions(0);
     }

```

这里定义了 ActionBar 显示默认的图标 所以需要注释掉 采用文字显示


修改如下:



```
diff --git a/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/AllInOneActivity.java b/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/AllInOneActivity.java
old mode 100644
new mode 100755
index fa7df3636a..1da23ba4ed
--- a/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/AllInOneActivity.java
+++ b/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/AllInOneActivity.java
@@ -626,8 +626,8 @@ public class AllInOneActivity extends AbstractCalendarActivity implements
     private void configureActionBar(int viewType) {
         createButtonsSpinner(viewType, mIsTabletConfig);
         if (mIsMultipane) {
-            mActionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM
-                    | ActionBar.DISPLAY_SHOW_HOME);
+            //mActionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM
+            //        | ActionBar.DISPLAY_SHOW_HOME); //motify
         } else {
             mActionBar.setDisplayOptions(0);
         }

```

2. 针对日期 星期 选择适配CalendarViewAdapter.java的修改



```
@Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v;
        if (mShowDate) {
            // Check if can recycle the view
            if (convertView == null
                    || ((Integer) convertView.getTag()).intValue() != R.layout.actionbar_pulldown_menu_top_button) {
                v = mInflater.inflate(
                        R.layout.actionbar_pulldown_menu_top_button, parent,
                        false);
                // Set the tag to make sure you can recycle it when you get it
                // as a convert view
                v.setTag(new Integer(
                        R.layout.actionbar_pulldown_menu_top_button));
            } else {
                v = convertView;
            }
            TextView weekDay = (TextView) v
                    .findViewById(R.id.top_button_weekday);
            TextView date = (TextView) v.findViewById(R.id.top_button_date);

            /* SPRD: Add 20141128 of bug374836, add lunar info @{ */
            /* SPRD: Add for bug467636, add foreign festival info. @{ */
            /* UNISOC: Modify for bug1232825
             * TextView lunaryear = (TextView) v.findViewById(R.id.lunaryear);
             * if (Utils.mLunarFlag && !Utils.mSupportForeignFestivalCalendar) {
             *      lunaryear.setVisibility(View.VISIBLE);
             * } else {
             *      lunaryear.setVisibility(View.GONE);
             * }
             */

            /* UNISOC: Modify for bug 454655,1030121,limit date to 1970.1.1~2037.12.31 @{ */
            mMilliTime = Utils.limitDate(mTimeZone, mMilliTime);
            /* @} */

            /* UNISOC: Modify for bug1232825  {@ */
            switch (mCurrentMainView) {
            case ViewType.DAY:
                weekDay.setVisibility(View.VISIBLE);
                date.setText(buildFullDate());
                /* SPRD: Add for bug467636, add foreign festival info. @{ */
                if (Utils.mLunarFlag && !Utils.mSupportForeignFestivalCalendar) {
                    weekDay.setText(buildDayOfWeek() + updateLunaryear());
                } else {
                    weekDay.setText(buildDayOfWeek());
                }
                break;
            case ViewType.WEEK:
                if (Utils.getShowWeekNumber(mContext)) {
                    weekDay.setVisibility(View.VISIBLE);
                    weekDay.setText(buildWeekNum());
                } else {
                    weekDay.setVisibility(View.GONE);
                }
                date.setText(buildMonthYearDate());
                if (Utils.mLunarFlag && !Utils.mSupportForeignFestivalCalendar) {
                    weekDay.setVisibility(View.VISIBLE);
                    weekDay.setText(updateLunaryear());
                }
                break;
            case ViewType.MONTH:
                weekDay.setVisibility(View.VISIBLE);
                weekDay.setText(buildMonthOfWeek());
                date.setText(buildMonthYearDate());
                /* SPRD: Add 20141128 of bug374836, add lunar info @{ */
                /* SPRD: Add for bug467636, add foreign festival info. @{ */
                if (Utils.mLunarFlag && !Utils.mSupportForeignFestivalCalendar) {
                    weekDay.setText(buildMonthOfWeek() + updateLunaryear());
                } else {
                    weekDay.setText(buildMonthOfWeek());
                }
                /* @} */
                break;
            case ViewType.AGENDA:
                weekDay.setVisibility(View.VISIBLE);
                weekDay.setText(buildDayOfWeek());
                date.setText(buildFullDate());
               /* SPRD: Add for bug467636, add foreign festival info. @{ */
                if (Utils.mLunarFlag && !Utils.mSupportForeignFestivalCalendar) {
                    weekDay.setText(buildDayOfWeek() + updateLunaryear());
                } else {
                    weekDay.setText(buildDayOfWeek());
                }
                /* @} */
                break;
            default:
                v = null;
                break;
            }
            /* }@ */
        } else {
            if (convertView == null
                    || ((Integer) convertView.getTag()).intValue() != R.layout.actionbar_pulldown_menu_top_button_no_date) {
                v = mInflater.inflate(
                        R.layout.actionbar_pulldown_menu_top_button_no_date,
                        parent, false);
                // Set the tag to make sure you can recycle it when you get it
                // as a convert view
                v.setTag(new Integer(
                        R.layout.actionbar_pulldown_menu_top_button_no_date));
            } else {
                v = convertView;
            }
            TextView title = (TextView) v;
            switch (mCurrentMainView) {
            case ViewType.DAY:
                title.setText(mButtonNames[DAY_BUTTON_INDEX]);
                break;
            case ViewType.WEEK:
                title.setText(mButtonNames[WEEK_BUTTON_INDEX]);
                break;
            case ViewType.MONTH:
                title.setText(mButtonNames[MONTH_BUTTON_INDEX]);
                break;
            case ViewType.AGENDA:
                title.setText(mButtonNames[AGENDA_BUTTON_INDEX]);
                break;
            default:
                v = null;
                break;
            }
        }
        return v;
    }

```

针对适配修改如下:



```
diff --git a/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/CalendarViewAdapter.java b/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/CalendarViewAdapter.java
old mode 100644
new mode 100755
index c6b2769d95..608c1f0eae
--- a/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/CalendarViewAdapter.java
+++ b/vendor/sprd/platform/packages/apps/SprdCalendar/src/com/android/calendar/CalendarViewAdapter.java
@@ -29,7 +29,7 @@ import android.view.View;
 import android.view.ViewGroup;
 import android.widget.BaseAdapter;
 import android.widget.TextView;
-
+import java.util.Calendar;
 import java.util.Formatter;
 import java.util.Locale;
 
@@ -279,13 +279,13 @@ public class CalendarViewAdapter extends BaseAdapter {
             TextView title = (TextView) v;
             switch (mCurrentMainView) {
             case ViewType.DAY:
-                title.setText(mButtonNames[DAY_BUTTON_INDEX]);
+                title.setText(getDay()+" "+mButtonNames[DAY_BUTTON_INDEX]);
                 break;
             case ViewType.WEEK:
-                title.setText(mButtonNames[WEEK_BUTTON_INDEX]);
+                title.setText(mButtonNames[WEEK_BUTTON_INDEX]+" "+getWeek());
                 break;
             case ViewType.MONTH:
-                title.setText(mButtonNames[MONTH_BUTTON_INDEX]);
+                title.setText(getMonth()+" "+mButtonNames[MONTH_BUTTON_INDEX]);
                 break;
             case ViewType.AGENDA:
                 title.setText(mButtonNames[AGENDA_BUTTON_INDEX]);
@@ -601,5 +601,46 @@ public class CalendarViewAdapter extends BaseAdapter {
                 + lunarInfo.animalsYear(lunarInfo.mLunarYear) + ")";
     }
     /* @} */
+       //add code start
+    private int getMonth() {
+        Calendar cd = Calendar.getInstance();
+        return cd.get(Calendar.MONTH) + 1;
+    }
+
+    private int getDay() {
+        Calendar cd = Calendar.getInstance();
+        return cd.get(Calendar.DATE);
+    }
+
+    private String getWeek() {
+        String week = "";
+        Calendar c = Calendar.getInstance();
+
+        int wek = c.get(Calendar.DAY_OF_WEEK);
+
+        if (wek == 1) {
+            week = "日";
+        }
+        if (wek == 2) {
+            week = "一";
+        }
+        if (wek == 3) {
+            week = "二";
+        }
+        if (wek == 4) {
+            week = "三";
+        }
+        if (wek == 5) {
+            week = "四";
+        }
+        if (wek == 6) {
+            week = "五";
+        }
+        if (wek == 7) {
+            week = "六";
+        }
+        return week;
+    }
+    //add code end
 }

```




