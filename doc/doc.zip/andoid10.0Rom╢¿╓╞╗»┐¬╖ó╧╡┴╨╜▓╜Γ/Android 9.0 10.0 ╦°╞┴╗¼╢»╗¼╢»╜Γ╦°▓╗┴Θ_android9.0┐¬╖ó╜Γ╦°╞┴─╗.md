






系统默认锁屏需要滑动才能解锁，但是在一些大屏，滑动解锁确有问题，通常是滑动距离设置的过大导致解不了锁


解决方案：  
 修改系统默认滑动解锁的值，来方便滑动解锁


首选看源码 PanelView.java 这里专门处理滑动解锁的部分  
 路径: frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\PanelView.java



```
    public PanelView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mFlingAnimationUtils = new FlingAnimationUtils(context, 0.6f /* maxLengthSeconds */,
                0.6f /* speedUpFactor */);
        mFlingAnimationUtilsClosing = new FlingAnimationUtils(context, 0.5f /* maxLengthSeconds */,
                0.6f /* speedUpFactor */);
        mFlingAnimationUtilsDismissing = new FlingAnimationUtils(context,
                0.5f /* maxLengthSeconds */, 0.2f /* speedUpFactor */, 0.6f /* x2 */,
                0.84f /* y2 */);
        mBounceInterpolator = new BounceInterpolator();
        mFalsingManager = FalsingManagerFactory.getInstance(context);
        mNotificationsDragEnabled =
                getResources().getBoolean(R.bool.config_enableNotificationShadeDrag);
        mVibratorHelper = Dependency.get(VibratorHelper.class);
        mVibrateOnOpening = mContext.getResources().getBoolean(
                R.bool.config_vibrateOnIconAnimation);
    }

    protected void loadDimens() {
        final Resources res = getContext().getResources();
        final ViewConfiguration configuration = ViewConfiguration.get(getContext());
        mTouchSlop = configuration.getScaledTouchSlop();
        mHintDistance = res.getDimension(R.dimen.hint_move_distance);
        mUnlockFalsingThreshold = res.getDimensionPixelSize(R.dimen.unlock_falsing_threshold);
    }

初始化 构造一些参数 
 
在看看处理手势事件
 @Override
    public boolean onTouchEvent(MotionEvent event) {
        /* UNISOC: Modify for bug1191373 {@ */
        if (DEBUG) {
            Log.d(TAG,"onTouchEvent enter");
        }

        if (mInstantExpanding
                || (mTouchDisabled && event.getActionMasked() != MotionEvent.ACTION_CANCEL)
                || (mMotionAborted && event.getActionMasked() != MotionEvent.ACTION_DOWN)) {
            if (DEBUG) {
                Log.d(TAG,"onTouchEvent mInstantExpanding:" + mInstantExpanding + " mTouchDisabled:" + mTouchDisabled
                          + " mMotionAborted:" + mMotionAborted + " mask: " + event.getActionMasked());
            }
            return false;
        }

        // If dragging should not expand the notifications shade, then return false.
        if (!mNotificationsDragEnabled) {
            if (mTracking) {
                // Turn off tracking if it's on or the shade can get stuck in the down position.
 onTrackingStopped(true /\* expand \*/);
 }
 if (DEBUG) {
 Log.d(TAG,"onTouchEvent mTracking:" + mTracking);
 }
 return false;
 }

 // On expanding, single mouse click expands the panel instead of dragging.
 if (isFullyCollapsed() && event.isFromSource(InputDevice.SOURCE\_MOUSE)) {
 if (event.getAction() == MotionEvent.ACTION\_UP) {
 expand(true);
 }
 if (DEBUG) {
 Log.d(TAG,"onTouchEvent action:" + event.getAction());
 }
 return true;
 }

 /\*
 \* We capture touch events here and update the expand height here in case according to
 \* the users fingers. This also handles multi-touch.
 \*
 \* If the user just clicks shortly, we show a quick peek of the shade.
 \*
 \* Flinging is also enabled in order to open or close the shade.
 \*/

 int pointerIndex = event.findPointerIndex(mTrackingPointer);
 if (pointerIndex < 0) {
 pointerIndex = 0;
 mTrackingPointer = event.getPointerId(pointerIndex);
 }
 final float x = event.getX(pointerIndex);
 final float y = event.getY(pointerIndex);

 if (event.getActionMasked() == MotionEvent.ACTION\_DOWN) {
 mGestureWaitForTouchSlop = isFullyCollapsed() || hasConflictingGestures();
 mIgnoreXTouchSlop = isFullyCollapsed() || shouldGestureIgnoreXTouchSlop(x, y);
 }

 switch (event.getActionMasked()) {
 case MotionEvent.ACTION\_DOWN:
 startExpandMotion(x, y, false /\* startTracking \*/, mExpandedHeight);
 mJustPeeked = false;
 mMinExpandHeight = 0.0f;
 mPanelClosedOnDown = isFullyCollapsed();
 mHasLayoutedSinceDown = false;
 mUpdateFlingOnLayout = false;
 mMotionAborted = false;
 mPeekTouching = mPanelClosedOnDown;
 mDownTime = SystemClock.uptimeMillis();
 mTouchAboveFalsingThreshold = false;
 mCollapsedAndHeadsUpOnDown = isFullyCollapsed()
 && mHeadsUpManager.hasPinnedHeadsUp();
 addMovement(event);
 if (!mGestureWaitForTouchSlop || (mHeightAnimator != null && !mHintAnimationRunning)
 || mPeekAnimator != null) {
 mTouchSlopExceeded = (mHeightAnimator != null && !mHintAnimationRunning)
 || mPeekAnimator != null;
 cancelHeightAnimator();
 cancelPeek();
 onTrackingStarted();
 }
 if (isFullyCollapsed() && !mHeadsUpManager.hasPinnedHeadsUp()
 && !mStatusBar.isBouncerShowing()) {
 startOpening(event);
 }
 break;

 case MotionEvent.ACTION\_POINTER\_UP:
 final int upPointer = event.getPointerId(event.getActionIndex());
 if (mTrackingPointer == upPointer) {
 // gesture is ongoing, find a new pointer to track
 final int newIndex = event.getPointerId(0) != upPointer ? 0 : 1;
 final float newY = event.getY(newIndex);
 final float newX = event.getX(newIndex);
 mTrackingPointer = event.getPointerId(newIndex);
 startExpandMotion(newX, newY, true /\* startTracking \*/, mExpandedHeight);
 }
 break;
 case MotionEvent.ACTION\_POINTER\_DOWN:
 if (mStatusBarStateController.getState() == StatusBarState.KEYGUARD) {
 mMotionAborted = true;
 endMotionEvent(event, x, y, true /\* forceCancel \*/);
 if (DEBUG) {
 Log.d(TAG,"onTouchEvent down false");
 }
 return false;
 }
 break;
 case MotionEvent.ACTION\_MOVE:
 addMovement(event);
 float h = y - mInitialTouchY;

 // If the panel was collapsed when touching, we only need to check for the
 // y-component of the gesture, as we have no conflicting horizontal gesture.
 if (Math.abs(h) > mTouchSlop
 && (Math.abs(h) > Math.abs(x - mInitialTouchX)
 || mIgnoreXTouchSlop)) {
 mTouchSlopExceeded = true;
 if (mGestureWaitForTouchSlop && !mTracking && !mCollapsedAndHeadsUpOnDown) {
 if (!mJustPeeked && mInitialOffsetOnTouch != 0f) {
 startExpandMotion(x, y, false /\* startTracking \*/, mExpandedHeight);
 h = 0;
 }
 cancelHeightAnimator();
 onTrackingStarted();
 }
 }
 float newHeight = Math.max(0, h + mInitialOffsetOnTouch);
 if (newHeight > mPeekHeight) {
 if (mPeekAnimator != null) {
 mPeekAnimator.cancel();
 }
 mJustPeeked = false;
 } else if (mPeekAnimator == null && mJustPeeked) {
 // The initial peek has finished, but we haven't dragged as far yet, lets
                    // speed it up by starting at the peek height.
                    mInitialOffsetOnTouch = mExpandedHeight;
                    mInitialTouchY = y;
                    mMinExpandHeight = mExpandedHeight;
                    mJustPeeked = false;
                }
                newHeight = Math.max(newHeight, mMinExpandHeight);
                if (-h >= getFalsingThreshold()) {
                    mTouchAboveFalsingThreshold = true;
                    mUpwardsWhenTresholdReached = isDirectionUpwards(x, y);
                }
                if (!mJustPeeked && (!mGestureWaitForTouchSlop || mTracking) &&
                        !isTrackingBlocked()) {
                    /* UNISOC: Modify for bug1183434 {@ */
                    if (newHeight > getMaxPanelHeight()) {
                        Log.d(TAG,"the newHeight greater than max height of the panel：" + newHeight);
                        newHeight = mExpandedHeight;
                    }
                    /* @} */
                    setExpandedHeightInternal(newHeight);
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                addMovement(event);
                endMotionEvent(event, x, y, false /* forceCancel */);
                break;
        }
        if (DEBUG) {
            Log.d(TAG,"onTouchEvent exit mTracking:" + mTracking + " slop:" + mGestureWaitForTouchSlop);
        }
        /* @} */
        return !mGestureWaitForTouchSlop || mTracking;
    }

```

抬起手指，产生touch up事件，会走endMotionEvent()，其中有 boolean expand的判断，这个就是控制是否expand逻辑，解锁false, 无法解锁true.


在MotionEvent.ACTION\_UP 事件中  
 endMotionEvent(event, x, y, false /\* forceCancel \*/);


具体看endMotionEvent();



```
   private void endMotionEvent(MotionEvent event, float x, float y, boolean forceCancel) {
        mTrackingPointer = -1;
        if ((mTracking && mTouchSlopExceeded)
 || Math.abs(x - mInitialTouchX) > mTouchSlop
 || Math.abs(y - mInitialTouchY) > mTouchSlop
 || event.getActionMasked() == MotionEvent.ACTION\_CANCEL
 || forceCancel) {
 mVelocityTracker.computeCurrentVelocity(1000);
 float vel = mVelocityTracker.getYVelocity();
 float vectorVel = (float) Math.hypot(
 mVelocityTracker.getXVelocity(), mVelocityTracker.getYVelocity());

            boolean expand = flingExpands(vel, vectorVel, x, y)
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL
                    || forceCancel;
            DozeLog.traceFling(expand, mTouchAboveFalsingThreshold,
                    mStatusBar.isFalsingThresholdNeeded(),
                    mStatusBar.isWakeUpComingFromTouch());
                    // Log collapse gesture if on lock screen.
                    if (!expand && mStatusBarStateController.getState() == StatusBarState.KEYGUARD) {
                        float displayDensity = mStatusBar.getDisplayDensity();
                        int heightDp = (int) Math.abs((y - mInitialTouchY) / displayDensity);
 int velocityDp = (int) Math.abs(vel / displayDensity);
 mLockscreenGestureLogger.write(
 MetricsEvent.ACTION\_LS\_UNLOCK,
 heightDp, velocityDp);
 }
 fling(vel, expand, isFalseTouch(x, y));
            onTrackingStopped(expand);
            mUpdateFlingOnLayout = expand && mPanelClosedOnDown && !mHasLayoutedSinceDown;
            if (mUpdateFlingOnLayout) {
                mUpdateFlingVelocity = vel;
            }
        } else if (mPanelClosedOnDown && !mHeadsUpManager.hasPinnedHeadsUp() && !mTracking
                && !mStatusBar.isBouncerShowing() && !mKeyguardMonitor.isKeyguardFadingAway()) {
            long timePassed = SystemClock.uptimeMillis() - mDownTime;
            if (timePassed < ViewConfiguration.getLongPressTimeout()) {
                // Lets show the user that he can actually expand the panel
                runPeekAnimation(PEEK_ANIMATION_DURATION, getPeekHeight(), true /* collapseWhenFinished */);
            } else {
                // We need to collapse the panel since we peeked to the small height.
                postOnAnimation(mPostCollapseRunnable);
            }
        } else if (!mStatusBar.isBouncerShowing()) {
            boolean expands = onEmptySpaceClick(mInitialTouchX);
            onTrackingStopped(expands);
        }

        mVelocityTracker.clear();
        mPeekTouching = false;
    }

```

代码执行流程:  
 isFalseTouch(x, y) -> mFalsingManager.isFalseTouch()


再看fling(vel, expand, isFalseTouch(x, y))  
 中的isFlaseTouch(x.y);



```
/**
 * @param x the final x-coordinate when the finger was lifted
 * @param y the final y-coordinate when the finger was lifted
 * @return whether this motion should be regarded as a false touch
 */
private boolean isFalseTouch(float x, float y) {
    if (!mStatusBar.isFalsingThresholdNeeded()) {
        return false;
    }
    if (mFalsingManager.isClassiferEnabled()) {
        return mFalsingManager.isFalseTouch();
    }
    if (!mTouchAboveFalsingThreshold) {
        return true;
    }
    if (mUpwardsWhenTresholdReached) {
        return false;
    }
    return !isDirectionUpwards(x, y);
}

```

其实就是由 if (mFalsingManager.isClassiferEnabled()) {  
 return mFalsingManager.isFalseTouch();  
 } 返回true引起的问题  
 所以修改方法就是注释掉



```
  private boolean isFalseTouch(float x, float y) {
        if (!mStatusBar.isFalsingThresholdNeeded()) {
            return false;
        }
        /*if (mFalsingManager.isClassiferEnabled()) {
            return mFalsingManager.isFalseTouch();
        }*/
        if (!mTouchAboveFalsingThreshold) {
            return true;
        }
        if (mUpwardsWhenTresholdReached) {
            return false;
        }
        return !isDirectionUpwards(x, y);
    }

```

在从新编译发现问题已经解决了





