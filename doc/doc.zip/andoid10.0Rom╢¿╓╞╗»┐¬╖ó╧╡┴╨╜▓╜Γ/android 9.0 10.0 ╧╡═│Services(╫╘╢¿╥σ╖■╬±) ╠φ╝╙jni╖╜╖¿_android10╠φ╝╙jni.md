






在开发中由于与底层进行通讯，涉及到jni方法添加，本篇讲解正确在系统服务中添加jni的方法详解


1.在aidl文件中 增加调用native方法接口



```
--- a/frameworks/base/core/java/android/os/IMdmManager.aidl
+++ b/frameworks/base/core/java/android/os/IMdmManager.aidl
@@ -80,4 +80,6 @@ interface IMdmManager {
     void allowAccessUsageDetails(String pkg);
     void turnOnEyeComfort(boolean on);
     boolean isEyeComfortTurnedOn();
+       void setVal(int val);
+    int getVal();
 }

```

2.在MdmManager.java中实现接口



```
+    public void setVal_native(int val){
+        try {
+            mMdmManagerSerivce.setVal(val);
+        } catch (RemoteException e) {
+            e.printStackTrace();
+        }
+    }
+
+    public int getValue(){
+        try {
+            return mMdmManagerSerivce.getVal();
+        } catch (RemoteException e) {
+            e.printStackTrace();
+        }
+        return -1;
+    }

```

3.在MdmManagerServices.java 系统服务中 添加native方法的调用



```
    @Override
    public void setVal(int val) throws RemoteException {
        setVal_native(val);
    }

    @Override
    public int getVal() throws RemoteException {
        return getVal_native();
    }

    public native void setVal_native(int val);
    public native int getVal_native();

4. 在添加提供app调用的自定义SuperPower.java 添加调用接口
    /**
     * @see
     * @param value
     */
    public void setValue(int value){
        mdmApiManager.setVal_native(value);
    }
    /**
     * @see
     * @return
     */
    public int getValue(){
        return mdmApiManager.getValue();
    }	

```

5.接下来 绑定MdmManagerServices.java 和 com\_android\_server\_MdmManagerService.cpp  
 在frameworks\base\services\core\jni 目录下  
 新建 com\_android\_server\_MdmManagerService.cpp 文件  
 新建cpp名称要和MdmManagerService的包名对应



```
/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
 #define LOG\_TAG "MdmManagerServiceJNI"
 
 #include "jni.h"
 #include "android\_runtime/AndroidRuntime.h"
 
 #include <utils/misc.h>
 #include <utils/Log.h>
 #include <stdio.h>
 
 namespace android
 {
	static int jniData = 1;
	
	static void mdmManager_setVal(JNIEnv* env, jobject clazz, jint val)
	{
		jniData = val;
		ALOGI("mdmManager\_setVal......jniData=%d\n",jniData);
	}
	
	static jint mdmManager_getVal(JNIEnv* env, jobject clazz)
	{
		ALOGI("mdmManager\_getVal......jniData=%d\n",jniData);
		return jniData+3;
	}
	
	/*Java本地接口方法表*/
	static const JNINativeMethod method_table[] = {
		{"setVal\_native", "(I)V",(void*)mdmManager_setVal},
		{"getVal\_native", "()I",(void*)mdmManager_getVal},
	};
	
	/*注册Java本地接口方法*/
	int register_android_server_MdmManagerService(JNIEnv *env)
	{
		return AndroidRuntime::registerNativeMethods(env, "com/android/server/MdmManagerService", method_table, NELEM(method_table));
	}
 };

```

6.添加cpp文件到 frameworks\base\services\core\jni\Android.bp文件中



```
srcs: [
        "BroadcastRadio/JavaRef.cpp",
        "BroadcastRadio/NativeCallbackThread.cpp",
        "BroadcastRadio/BroadcastRadioService.cpp",
        "BroadcastRadio/Tuner.cpp",
        "BroadcastRadio/TunerCallback.cpp",
        "BroadcastRadio/convert.cpp",
        "BroadcastRadio/regions.cpp",
        "com\_android\_server\_AlarmManagerService.cpp",
        "com\_android\_server\_am\_BatteryStatsService.cpp",
        "com\_android\_server\_connectivity\_Vpn.cpp",
        "com\_android\_server\_connectivity\_tethering\_OffloadHardwareInterface.cpp",
        "com\_android\_server\_ConsumerIrService.cpp",
        "com\_android\_server\_devicepolicy\_CryptoTestHelper.cpp",
        "com\_android\_server\_HardwarePropertiesManagerService.cpp",
        "com\_android\_server\_hdmi\_HdmiCecController.cpp",
        "com\_android\_server\_input\_InputManagerService.cpp",
        "com\_android\_server\_lights\_LightsService.cpp",
        "com\_android\_server\_location\_GnssLocationProvider.cpp",
        "com\_android\_server\_locksettings\_SyntheticPasswordManager.cpp",
        "com\_android\_server\_net\_NetworkStatsService.cpp",
        "com\_android\_server\_power\_PowerManagerService.cpp",
        "com\_android\_server\_security\_VerityUtils.cpp",
        "com\_android\_server\_SerialService.cpp",
        "com\_android\_server\_storage\_AppFuseBridge.cpp",
        "com\_android\_server\_SystemServer.cpp",
        "com\_android\_server\_TestNetworkService.cpp",
        "com\_android\_server\_tv\_TvUinputBridge.cpp",
        "com\_android\_server\_tv\_TvInputHal.cpp",
        "com\_android\_server\_vr\_VrManagerService.cpp",
        "com\_android\_server\_UsbAlsaJackDetector.cpp",
        "com\_android\_server\_UsbDeviceManager.cpp",
        "com\_android\_server\_UsbDescriptorParser.cpp",
        "com\_android\_server\_UsbMidiDevice.cpp",
        "com\_android\_server\_UsbHostManager.cpp",
        "com\_android\_server\_VibratorService.cpp",
        "com\_android\_server\_PersistentDataBlockService.cpp",
        "com\_android\_server\_GraphicsStatsService.cpp",
        "com\_android\_server\_am\_AppCompactor.cpp",
        "com\_android\_server\_am\_LowMemDetector.cpp",
	+ "com\_android\_server\_MdmManagerService.cpp",
        "onload.cpp",
        ":lib\_networkStatsFactory\_native",
    ],

```

7.到frameworks\base\services\core\jni\onload.cpp中注册com\_android\_server\_MdmManagerService.cpp中的navite方法  
 这个onload.cpp文件实现在libandroid\_servers模块中，当系统加载libandroid\_servers模块时，就会调用实现在onload.cpp文件中的JNI\_OnLoad函数，这样就把前面定义的三个JNI方法注册到Java虚拟机中去了。  
 添加如下：



```
namespace android {
........
int register_android_server_MdmManagerService(JNIEnv *env);
};
 
..............
extern "C" jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    .....................
    register_android_server_MdmManagerService(env);
    return JNI_VERSION_1_4;
}

```

这样重新编译得到的libandroid\_servers.so文件就包含了上面注册的JNI方法，通过全编译验证后，通过调用系统服务接口验证





