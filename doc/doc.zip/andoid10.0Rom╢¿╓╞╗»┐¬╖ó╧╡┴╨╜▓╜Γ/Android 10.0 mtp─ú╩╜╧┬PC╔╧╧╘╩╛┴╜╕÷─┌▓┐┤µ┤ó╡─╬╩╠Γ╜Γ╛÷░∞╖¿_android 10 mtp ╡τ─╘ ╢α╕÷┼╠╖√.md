



## 1. 前言


 在10.0的系统产品开发中，在mtp模式下，有些时候会在pc端显示两个手机内部存储空间，所以这时候显得特别不友好，出于对产品  
 的完善，所以要求解决这个问题，接下来分析下这个问题


## 2.mtp模式下PC上显示两个内部存储的问题解决办法的核心类



```
frameworks\base\media\java\android\mtp\MtpDatabase.java
frameworks\av\media\mtp\MtpServer.cpp
```

## 3.mtp模式下PC上显示两个内部存储的问题解决办法的核心功能分析和实现


MTP，全称是Media Transfer Protocol（媒体传输协议）。它是微软的一个为计算机和便携式设备之间传输图像、音乐等所定制的协议。  
 Android从3.0开始支持MTP。MTP的应用分两种角色，一个是作为Initiator，另一个作为Responder。  
 在Kernel层，USB驱动负责数据交换，而MTP驱动负责和上层进行通信，同时也和USB驱动进行通信。  
 在JNI层，MtpServer会不断地监听Kernel的消息"MTP请求"，并对相应的消息进行相关处理。同时，MTP的Event事件也是通过MtpServer发送给MTP驱动的。 MtpStorage对应一个"存储单元"；例如，SD卡就对应一个MtpStorage。 MtpPacket和MtpEventPacket负 责对MTP消息进行打包。  
 android\_mtp\_MtpServer是一个JNI类，它是"JNI层的MtpServer 和 Java层的MtpServer"沟通的桥梁。android\_mtp\_MtpDatabase也是一个JNI类，JNI层通过它实现了对 MtpDatabase(Framework层)的操作。  
 在Framework层，MtpServer相 当于一个服务器，它通过和底层进行通信从而提供了MTP的相关服务。MtpDatabase充当着数据库的功能，但它本身并没有数据库对数据进行保存，本 质上是通过MediaProvider数据库获取所需要的数据。MtpStorage对应一个"存储单元"，它和"JNI层的MtpStorage"相对 应。  
 在Application层，MtpReceiver负责接收广播，接收到广播后会启动/关闭MtpService；例如，MtpReceiver收到"Android设备 和 PC连上"的消息时，会启动MtpService。 MtpService的作用是提供管理MTP的服务，它会启动MtpServer，以及将本地存储内容和MTP的内容同步。  
  MediaProvider在MTP中的角色，是本地存储内容查找和本地内容同步；例如，本地新增一个文件时，MediaProvider会通知MtpServer从而进行MTP数据同步。


## 3.1 MtpServer.cpp相关源码分析


MtpServer.cpp中主要提供了一些对文件操作的接口方法，例如：添加，删除，重命名文件，MtpServier.java 中也是提供了此方法  
 MtpService.java中主要就是提供管理MTP 的服务，它会启动MtpSercer,以及将本地存储内容和MTP 的内容同步，初始化MTP 设备名称等



```
namespace android {

static const MtpOperationCode kSupportedOperationCodes[] = {
    MTP_OPERATION_GET_DEVICE_INFO,
    MTP_OPERATION_OPEN_SESSION,
    MTP_OPERATION_CLOSE_SESSION,
    MTP_OPERATION_GET_STORAGE_IDS,
    MTP_OPERATION_GET_STORAGE_INFO,
    MTP_OPERATION_GET_NUM_OBJECTS,
    MTP_OPERATION_GET_OBJECT_HANDLES,
    MTP_OPERATION_GET_OBJECT_INFO,
    MTP_OPERATION_GET_OBJECT,
    MTP_OPERATION_GET_THUMB,
    MTP_OPERATION_DELETE_OBJECT,
    MTP_OPERATION_SEND_OBJECT_INFO,
    MTP_OPERATION_SEND_OBJECT,
//    MTP_OPERATION_INITIATE_CAPTURE,
//    MTP_OPERATION_FORMAT_STORE,
    MTP_OPERATION_RESET_DEVICE,
//    MTP_OPERATION_SELF_TEST,
//    MTP_OPERATION_SET_OBJECT_PROTECTION,
//    MTP_OPERATION_POWER_DOWN,
    MTP_OPERATION_GET_DEVICE_PROP_DESC,
    MTP_OPERATION_GET_DEVICE_PROP_VALUE,
    MTP_OPERATION_SET_DEVICE_PROP_VALUE,
    MTP_OPERATION_RESET_DEVICE_PROP_VALUE,
//    MTP_OPERATION_TERMINATE_OPEN_CAPTURE,
    MTP_OPERATION_MOVE_OBJECT,
    MTP_OPERATION_COPY_OBJECT,
    MTP_OPERATION_GET_PARTIAL_OBJECT,
//    MTP_OPERATION_INITIATE_OPEN_CAPTURE,
    MTP_OPERATION_GET_OBJECT_PROPS_SUPPORTED,
    MTP_OPERATION_GET_OBJECT_PROP_DESC,
    MTP_OPERATION_GET_OBJECT_PROP_VALUE,
    MTP_OPERATION_SET_OBJECT_PROP_VALUE,
    MTP_OPERATION_GET_OBJECT_PROP_LIST,
//    MTP_OPERATION_SET_OBJECT_PROP_LIST,
//    MTP_OPERATION_GET_INTERDEPENDENT_PROP_DESC,
//    MTP_OPERATION_SEND_OBJECT_PROP_LIST,
    MTP_OPERATION_GET_OBJECT_REFERENCES,
    MTP_OPERATION_SET_OBJECT_REFERENCES,
//    MTP_OPERATION_SKIP,
    // Android extension for direct file IO
    MTP_OPERATION_GET_PARTIAL_OBJECT_64,
    MTP_OPERATION_SEND_PARTIAL_OBJECT,
    MTP_OPERATION_TRUNCATE_OBJECT,
    MTP_OPERATION_BEGIN_EDIT_OBJECT,
    MTP_OPERATION_END_EDIT_OBJECT,
};

static const MtpEventCode kSupportedEventCodes[] = {
    MTP_EVENT_OBJECT_ADDED,
    MTP_EVENT_OBJECT_REMOVED,
    MTP_EVENT_STORE_ADDED,
    MTP_EVENT_STORE_REMOVED,
    MTP_EVENT_DEVICE_PROP_CHANGED,
    MTP_EVENT_OBJECT_INFO_CHANGED,
};
MtpServer::MtpServer(IMtpDatabase* database, int controlFd, bool ptp,
                    const char *deviceInfoManufacturer,
                    const char *deviceInfoModel,
                    const char *deviceInfoDeviceVersion,
                    const char *deviceInfoSerialNumber)
    :   mDatabase(database),
        mPtp(ptp),
        mDeviceInfoManufacturer(deviceInfoManufacturer),
        mDeviceInfoModel(deviceInfoModel),
        mDeviceInfoDeviceVersion(deviceInfoDeviceVersion),
        mDeviceInfoSerialNumber(deviceInfoSerialNumber),
        mSessionID(0),
        mSessionOpen(false),
        mSendObjectHandle(kInvalidObjectHandle),
        mSendObjectFormat(0),
        mSendObjectFileSize(0),
        mSendObjectModifiedTime(0)
{
    bool ffs_ok = access(FFS_MTP_EP0, W_OK) == 0;
    if (ffs_ok) {
        bool aio_compat = android::base::GetBoolProperty("sys.usb.ffs.aio_compat", false);
        mHandle = aio_compat ? new MtpFfsCompatHandle(controlFd) : new MtpFfsHandle(controlFd);
    } else {
        mHandle = new MtpDevHandle();
    }
}
```

在mtp模式下PC上显示两个内部存储的问题核心功能实现中，在上述MtpServer.cpp中的相关源码分析中得知，在  
 MtpServer.cpp的文件中MtpServer(IMtpDatabase\* database, int controlFd, bool ptp,  
                     const char \*deviceInfoManufacturer,  
                     const char \*deviceInfoModel,  
                     const char \*deviceInfoDeviceVersion,  
                     const char \*deviceInfoSerialNumber)表示在mtp初始化相关参数



```
void MtpServer::addStorage(MtpStorage* storage) {
    std::lock_guard<std::mutex> lg(mMutex);
//add core start
    if(hasStorage(storage->getStorageID())) {
        ALOGE("this storage id has been added");
        return;
    }
//add core end
    mStorages.push_back(storage);
    sendStoreAdded(storage->getStorageID());
}

void MtpServer::removeStorage(MtpStorage* storage) {
    std::lock_guard<std::mutex> lg(mMutex);
    auto iter = std::find(mStorages.begin(), mStorages.end(), storage);
    if (iter != mStorages.end()) {
        sendStoreRemoved(storage->getStorageID());
        mStorages.erase(iter);
    }
}

MtpStorage* MtpServer::getStorage(MtpStorageID id) {
    if (id == 0)
        return mStorages[0];
    for (MtpStorage *storage : mStorages) {
        if (storage->getStorageID() == id)
            return storage;
    }
    return nullptr;
}
```

在mtp模式下PC上显示两个内部存储的问题核心功能实现中，在上述MtpServer.cpp中的相关源码分析中得知，在  
 MtpServer.cpp的文件中 在上述的addStorage(MtpStorage\* storage) 表示在添加在mtp模式下显示在pc端的内部存储  
 的根文件，removeStorage(MtpStorage\* storage)表示移除在mtp模式下显示在pc端的内部存储  
 的根文件，getStorage(MtpStorageID id)表示在mtp模式下根据id找到显示的MtpStorage，所以根据上述的分析  
 重复显示内部存储，就是需要在addStorage(MtpStorage\* storage)中，添加hasStorage(storage->getStorageID()  
 这个判断，如果存在就return掉就可以了


## 3.2 MtpDatabase.java的相关源码分析


MtpService启动后会创建MtpDatabase；之后，还会创建MtpServer，MtpServer会和MtpDatabase关联。然后，MtpService会遍历本地的存储设备，并建立相应的MtpStorage，  
 并将该MtpStorage添加到MtpDatabase和MtpServer中。最后，MtpService会启动MtpServer，所以可以看出MtpDatabase会存储  
 mtp模式下的一些数据



```
    public void addStorage(StorageVolume storage) {
        MtpStorage mtpStorage = mManager.addMtpStorage(storage);
//add core start
        removeStorage(storage);
//add core end
        mStorageMap.put(storage.getPath(), mtpStorage);
        if (mServer != null) {
            mServer.addStorage(mtpStorage);
        }
    }

    public void removeStorage(StorageVolume storage) {
        MtpStorage mtpStorage = mStorageMap.get(storage.getPath());
        if (mtpStorage == null) {
            return;
        }
        if (mServer != null) {
            mServer.removeStorage(mtpStorage);
        }
        mManager.removeMtpStorage(mtpStorage);
        mStorageMap.remove(storage.getPath());
    }
```

在mtp模式下PC上显示两个内部存储的问题核心功能实现中，在上述MtpDatabase.java中的相关源码分析中得知，  
 在上述的方法中，addStorage(StorageVolume storage)表示在添加在mtp模式下显示在pc端的内部存储的根文件，removeStorage(StorageVolume storage)表示移除在mtp模式下显示在pc端的内部存储  
 的根文件，所以说在addStorage(StorageVolume storage)添加removeStorage(storage);在mtp模式下pc端重复显示内部存储，移除掉就可以了




