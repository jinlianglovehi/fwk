






在对SystemUI的定制中，当对通知栏每条通知背景实现圆角背景时，会发现有灰色的背景很不美观，所以就要想办法去掉这个灰色背景  
 如下图这样的灰色背景  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/ebc11ed40ad645e194d7d7a5e8a6ecf0.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBA5a6J5Y2T5YW86IGMZnJhbWV3b3Jr5bqU55So5bel56iL5biI,size_19,color_FFFFFF,t_70,g_se,x_16#pic_center)


现在先看通知的布局从布局文件着手看问题


status\_bar\_notification\_row.xml



```
<com.android.systemui.statusbar.notification.row.ExpandableNotificationRow
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match\_parent"
    android:layout_height="wrap\_content"
    android:focusable="true"
    android:clickable="true"
    >

    <!-- Menu displayed behind notification added here programmatically -->

    <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
        android:id="@+id/backgroundNormal"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent" />

    <com.android.systemui.statusbar.notification.row.NotificationBackgroundView
        android:id="@+id/backgroundDimmed"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent" />

    <com.android.systemui.statusbar.notification.row.NotificationContentView
        android:id="@+id/expanded"
       android:layout_width="match\_parent"
       android:layout_height="wrap\_content"/>

    <com.android.systemui.statusbar.notification.row.NotificationContentView
        android:id="@+id/expandedPublic"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"/>

    <Button
        android:id="@+id/veto"
        android:layout_width="48dp"
        android:layout_height="0dp"
        android:gravity="end"
        android:layout_marginEnd="-80dp"
        android:background="@null"
        android:paddingEnd="8dp"
        android:paddingStart="8dp"
        />

    <ViewStub
        android:layout="@layout/notification\_children\_container"
        android:id="@+id/child\_container\_stub"
        android:inflatedId="@+id/notification\_children\_container"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        />

    <ViewStub
        android:layout="@layout/notification\_guts"
        android:id="@+id/notification\_guts\_stub"
        android:inflatedId="@+id/notification\_guts"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        />

    <com.android.systemui.statusbar.notification.FakeShadowView
        android:id="@+id/fake\_shadow"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent" />

</com.android.systemui.statusbar.notification.row.ExpandableNotificationRow>

```

可以看到NotificationBackgroundView 就是Notification每条消息设置圆角背景,然后出现的灰色背景  
 而



```
<com.android.systemui.statusbar.notification.row.NotificationBackgroundView
    android:id="@+id/backgroundNormal"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent" />

<com.android.systemui.statusbar.notification.row.NotificationBackgroundView
    android:id="@+id/backgroundDimmed"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent" />

```

设置背景都是在ActivatableNotificationView.java 中设置的  
 它继承于ExpandableOutlineView.java  
 在这里面设置背景的灰色透明度  
 路径:/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/row/ExpandableOutlineView.java  
 接下来看ExpandableOutlineView.java 中关于透明度的设置



```
protected void setOutlineAlpha(float alpha) {
	mOutlineAlpha=0.0f;
    /*if (alpha != mOutlineAlpha) {
        mOutlineAlpha = alpha;
        applyRoundness();
    }*/
}

```

然后把系统透明度改为0.0f 验证发现灰色圆角已经消失了





