






### 1.概述


在10.0系统产品开发中，在下拉状态栏第二次展开的QSPanel的界面时，原生下拉状态栏界面会有亮度条SeekBar当拖动的时候，亮度会改变但是同时整个QSPanel下拉状态栏也隐藏掉了 客户要求去掉这个拖动亮度条时隐藏下拉状态栏的功能


### 2.SystemUI去掉拖动亮度条QSPanel界面隐藏功能的核心类



```
/frameworks/base/packages/SystemUI/res/layout/quick_settings_brightness_dialog.xml

```

### 3.SystemUI去掉拖动亮度条QSPanel界面隐藏功能的核心功能实现和分析


### 3.1quick\_settings\_brightness\_dialog.xml关于亮度条的布局


在SystemUI的下拉状态栏中，亮度条布局就是quick\_settings\_brightness\_dialog.xml  
 接下来看下quick\_settings\_brightness\_dialog.xml的布局  
 通过查看相关布局文件  
 quick\_settings\_brightness\_dialog.xml



```
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:systemui="http://schemas.android.com/apk/res-auto"
    android:layout_height="wrap\_content"
    android:layout_width="match\_parent"
    android:layout_gravity="center\_vertical"
    style="@style/BrightnessDialogContainer">

    <com.android.systemui.settings.ToggleSliderView
        android:id="@+id/brightness\_slider"
        android:layout_width="match\_parent"
        android:layout_height="wrap\_content"
        android:layout_gravity="center\_vertical"
        android:layout_weight="1"
        android:contentDescription="@string/accessibility\_brightness"
        android:importantForAccessibility="no"
        systemui:text="@string/status\_bar\_settings\_auto\_brightness\_label" />

</LinearLayout>

```

在quick\_settings\_brightness\_dialog.xml的com.android.systemui.settings.ToggleSliderView  
 就是关于下拉状态栏的亮度条  
 从布局文件看ToggleSliderView.java来处理亮度条的功能  
 接了下来看ToggleSliderView.java


### 3.2ToggleSliderView 关于进度条拖拽的相关代码分析



```
public class ToggleSliderView extends RelativeLayout implements ToggleSlider {
     private Listener mListener;
     private boolean mTracking;
 
     private CompoundButton mToggle;
     private ToggleSeekBar mSlider;
     private TextView mLabel;
 
     private ToggleSliderView mMirror;
     private BrightnessMirrorController mMirrorController;
 
     public ToggleSliderView(Context context) {
         this(context, null);
     }
 
     public ToggleSliderView(Context context, AttributeSet attrs) {
         this(context, attrs, 0);
     }
 
     public ToggleSliderView(Context context, AttributeSet attrs, int defStyle) {
         super(context, attrs, defStyle);
 
         View.inflate(context, R.layout.status_bar_toggle_slider, this);
 
         final Resources res = context.getResources();
         final TypedArray a = context.obtainStyledAttributes(
                 attrs, R.styleable.ToggleSliderView, defStyle, 0);
 
         mToggle = findViewById(R.id.toggle);
         mToggle.setOnCheckedChangeListener(mCheckListener);
 
         mSlider = findViewById(R.id.slider);
         mSlider.setOnSeekBarChangeListener(mSeekListener);
 
         mLabel = findViewById(R.id.label);
         mLabel.setText(a.getString(R.styleable.ToggleSliderView_text));
 
         mSlider.setAccessibilityLabel(getContentDescription().toString());
 
         a.recycle();
     }
 
     public void setMirror(ToggleSliderView toggleSlider) {
         mMirror = toggleSlider;
         if (mMirror != null) {
             mMirror.setChecked(mToggle.isChecked());
             mMirror.setMax(mSlider.getMax());
             mMirror.setValue(mSlider.getProgress());
         }
     }
 
     public void setMirrorController(BrightnessMirrorController c) {
         mMirrorController = c;
     }
 
     @Override
     protected void onAttachedToWindow() {
         super.onAttachedToWindow();
         if (mListener != null) {
             mListener.onInit(this);
         }
     }
private final OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener() {
          @Override
          public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
              if (mListener != null) {
                  mListener.onChanged(
                          ToggleSliderView.this, mTracking, mToggle.isChecked(), progress, false);
              }
          }
  
          @Override
          public void onStartTrackingTouch(SeekBar seekBar) {
              mTracking = true;
  
              if (mListener != null) {
                  mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
                          mSlider.getProgress(), false);
              }
  
              mToggle.setChecked(false);
  
              if (mMirrorController != null) {
                  mMirrorController.showMirror();
                  mMirrorController.setLocation((View) getParent());
              }
          }
  
          @Override
          public void onStopTrackingTouch(SeekBar seekBar) {
              mTracking = false;
  
              if (mListener != null) {
                  mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
                          mSlider.getProgress(), true);
              }
  
              if (mMirrorController != null) {
                  mMirrorController.hideMirror();
              }
          }
      };

```

在上述的ToggleSliderView 的相关源码中发现，在OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener()中可以看出这就是拖拽进度条的回调接口  
 在onStartTrackingTouch(SeekBar seekBar)和onStopTrackingTouch(SeekBar seekBar)就是拖拽开始和拖拽结束的相关回调方法  
 具体修改如下：



```
public class ToggleSliderView extends RelativeLayout implements ToggleSlider {

 private final OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			android.util.Log.e("mSeekListener","onProgressChanged---progress:"+progress);
            if (mListener != null) {
                mListener.onChanged(
                        ToggleSliderView.this, mTracking, mToggle.isChecked(), progress, false);
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            mTracking = true;
			android.util.Log.e("mSeekListener","onStartTrackingTouch");
            if (mListener != null) {
                mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
                        mSlider.getProgress(), false);
            }

            mToggle.setChecked(false);

            /*if (mMirrorController != null) {
                mMirrorController.showMirror();
                mMirrorController.setLocation((View) getParent());
            }*/
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            mTracking = false;
			android.util.Log.e("mSeekListener","onStopTrackingTouch");
            if (mListener != null) {
                mListener.onChanged(ToggleSliderView.this, mTracking, mToggle.isChecked(),
                        mSlider.getProgress(), true);
            }

            /*if (mMirrorController != null) {
                mMirrorController.hideMirror();
            }*/
        }
    };
}

```

OnSeekBarChangeListener 处理拖动进度条的一些功能



```
 /*if (mMirrorController != null) {
                mMirrorController.showMirror();
                mMirrorController.setLocation((View) getParent());
            }*/

  /*if (mMirrorController != null) {
                mMirrorController.hideMirror();
            }*/

```

经上述的处理发现功能实现了拖拽没有影藏当前页面  
 处理显示和隐藏下拉状态栏的功能





