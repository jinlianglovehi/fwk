



## 1.前言


  
  在10.0的系统rom定制化开发中，系统中recovery模式功能也是很重要的一部分，而在原生系统中，对于debug模式的产品，可以通过电源键和音量+键进入recovery模式，  
 但是在user模式下的产品，对于通过这种方式，进入recovery模式就受限制了，防止用户无操作为了产品安全等，不让进入recovery模式，某些特殊产品的需要，要求在  
 user模式下的产品也需要进入recovery ,所以就需要分析下系统进入recovery模式的流程来分析功能实现


## 2.user模式下解除系统进入recovery功能的限制的核心类



```
bootable/recovery/recovery.cpp
bootable/recovery/recovery.h
```

## 3.user模式下解除系统进入recovery功能的限制的核心功能分析和实现


  
  首选需要分析下系统进入recovery模式的相关执行流程，然后来分析相关代码，当我们通过按键或者命令进入recovery模式，实质是系统在加载完kernel后  
 在加载recovery.img,kernel起来后执行的第一个进程就 是init，此进程会读入init.rc启动相应的服务。在recovery模式中，启动的服务是执行recovery可执行文件，此文件是  
 bootable/recovery/recovery.cpp文件生成，我们就从recovery.cpp文件开始分析相关的recovery模式执行流程，



```
Device::BuiltinAction start_recovery(Device* device, const std::vector<std::string>& args) {
  static constexpr struct option OPTIONS[] = {
    { "fastboot", no_argument, nullptr, 0 },
    { "fsck_unshare_blocks", no_argument, nullptr, 0 },
    { "just_exit", no_argument, nullptr, 'x' },
    { "locale", required_argument, nullptr, 0 },
    { "prompt_and_wipe_data", no_argument, nullptr, 0 },
    { "reason", required_argument, nullptr, 0 },
    { "rescue", no_argument, nullptr, 0 },
    { "retry_count", required_argument, nullptr, 0 },
    { "security", no_argument, nullptr, 0 },
    { "show_text", no_argument, nullptr, 't' },
    { "shutdown_after", no_argument, nullptr, 0 },
    { "sideload", no_argument, nullptr, 0 },
    { "sideload_auto_reboot", no_argument, nullptr, 0 },
    { "update_package", required_argument, nullptr, 0 },
    { "wipe_ab", no_argument, nullptr, 0 },
    { "wipe_cache", no_argument, nullptr, 0 },
    { "wipe_data", no_argument, nullptr, 0 },
    { "wipe_package_size", required_argument, nullptr, 0 },
    { nullptr, 0, nullptr, 0 },
  };

  const char* update_package = nullptr;
  bool should_wipe_data = false;
  bool should_prompt_and_wipe_data = false;
  bool should_wipe_cache = false;
  bool should_wipe_ab = false;
  size_t wipe_package_size = 0;
  bool sideload = false;
  bool sideload_auto_reboot = false;
  bool rescue = false;
  bool just_exit = false;
  bool shutdown_after = false;
  bool fsck_unshare_blocks = false;
  int retry_count = 0;
  bool security_update = false;
  std::string locale;

  auto args_to_parse = StringVectorToNullTerminatedArray(args);

  int arg;
  int option_index;
  // Parse everything before the last element (which must be a nullptr). getopt_long(3) expects a
  // null-terminated char* array, but without counting null as an arg (i.e. argv[argc] should be
  // nullptr).
  while ((arg = getopt_long(args_to_parse.size() - 1, args_to_parse.data(), "", OPTIONS,
                            &option_index)) != -1) {
    switch (arg) {
      case 't':
        // Handled in recovery_main.cpp
        break;
      case 'x':
        just_exit = true;
        break;
      case 0: {
        std::string option = OPTIONS[option_index].name;
        if (option == "fsck_unshare_blocks") {
          fsck_unshare_blocks = true;
        } else if (option == "locale" || option == "fastboot") {
          // Handled in recovery_main.cpp
        } else if (option == "prompt_and_wipe_data") {
          should_prompt_and_wipe_data = true;
        } else if (option == "reason") {
          reason = optarg;
        } else if (option == "rescue") {
          rescue = true;
        } else if (option == "retry_count") {
          android::base::ParseInt(optarg, &retry_count, 0);
        } else if (option == "security") {
          security_update = true;
        } else if (option == "sideload") {
          sideload = true;
        } else if (option == "sideload_auto_reboot") {
          sideload = true;
          sideload_auto_reboot = true;
        } else if (option == "shutdown_after") {
          shutdown_after = true;
        } else if (option == "update_package") {
          update_package = optarg;
        } else if (option == "wipe_ab") {
          should_wipe_ab = true;
        } else if (option == "wipe_cache") {
          should_wipe_cache = true;
        } else if (option == "wipe_data") {
          should_wipe_data = true;
        } else if (option == "wipe_package_size") {
          android::base::ParseUint(optarg, &wipe_package_size);
        }
        break;
      }
      case '?':
        LOG(ERROR) << "Invalid command argument";
        continue;
    }
  }
  optind = 1;

  printf("stage is [%s]\n", stage.c_str());
  printf("reason is [%s]\n", reason);

  // Set background string to "installing security update" for security update,
  // otherwise set it to "installing system update".
  ui->SetSystemUpdateText(security_update);

  int st_cur, st_max;
  if (!stage.empty() && sscanf(stage.c_str(), "%d/%d", &st_cur, &st_max) == 2) {
    ui->SetStage(st_cur, st_max);
  }

  std::vector<std::string> title_lines =
      android::base::Split(android::base::GetProperty("ro.bootimage.build.fingerprint", ""), ":");
  title_lines.insert(std::begin(title_lines), "Android Recovery");
  ui->SetTitle(title_lines);

  ui->ResetKeyInterruptStatus();
  device->StartRecovery();

  printf("Command:");
  for (const auto& arg : args) {
    printf(" \"%s\"", arg.c_str());
  }
  printf("\n\n");

  if (update_package) {
	//adupsfota start for replace sdcard path
    #ifdef ADUPS_FOTA_SUPPORT
    static const char *SDCARD_ROOT = "/storage/sdcard0";
    if (strncmp(update_package, "/storage/", 9) == 0) {
      int len = strlen(update_package) + 12;
      char* modified_path = (char*)malloc(len);
      strlcpy(modified_path, SDCARD_ROOT, len);
      if(strstr(update_package, "/Android/data/com.adups.fota/files/adupsfota/update.zip") != NULL){
        char const *SDCARD_PATH = "/Android/data/com.adups.fota/files/adupsfota/update.zip";
        strlcat(modified_path, SDCARD_PATH, len);
      }else if(strstr(update_package, "/Android/data/com.adups.fota/files/LocalSdUpdate.zip") != NULL){
        char const *SDCARD_PATH = "/Android/data/com.adups.fota/files/LocalSdUpdate.zip";
        strlcat(modified_path, SDCARD_PATH, len);
      }
    printf("(replacing path \"%s\" with \"%s\")\n",update_package, modified_path);
    update_package = modified_path;
    }
    #endif
    //adupsfota end
  }
  printf("\n");


  property_list(print_property, nullptr);
  printf("\n");
....

  // Determine the next action.
  //  - If the state is INSTALL_REBOOT, device will reboot into the target as specified in
  //    `next_action`.
  //  - If the recovery menu is visible, prompt and wait for commands.
  //  - If the state is INSTALL_NONE, wait for commands (e.g. in user build, one manually boots
  //    into recovery to sideload a package or to wipe the device).
  //  - In all other cases, reboot the device. Therefore, normal users will observe the device
  //    rebooting a) immediately upon successful finish (INSTALL_SUCCESS); or b) an "error" screen
  //    for 5s followed by an automatic reboot.
  if (status != INSTALL_REBOOT) {
    if (status == INSTALL_NONE || ui->IsTextVisible()) {
      Device::BuiltinAction temp = prompt_and_wait(device, status);
      if (temp != Device::NO_ACTION) {
        next_action = temp;
      }
    }
  }

  // Save logs and clean up before rebooting or shutting down.
  finish_recovery();

  return next_action;
}

```

在启动recovery程序，首先进入recovery\_main.cpp中的main()方法，在对recovery的相关参数解析后，判断继续执行哪些方法，最终是调用  
 recovery.cpp–> start\_recovery(Device\* device, const std::vector<std::string>& args) 来进行recovery流程处理，  
 根据args的参数，进入到不同的recovery模式，而最终在这个方法中，会在



```
else if (!just_exit) {
    // If this is an eng or userdebug build, automatically turn on the text display if no command
    // is specified. Note that this should be called before setting the background to avoid
    // flickering the background image.
    if (is_ro_debuggable()) {
      ui->ShowText(true);
    }
    status = INSTALL_NONE;  // No command specified
    ui->SetBackground(RecoveryUI::NO_COMMAND);
  }
```

中，这段代码中，就是根据判断当前是否是debug模式，来判断是否显示recovery菜单选择项等页面，所以  
 就是说在user模式下，就不会有recovery菜单项显示，而是会有一张无命令的背景显示，所以就需要修改为:



```
else if (!just_exit) {
    // If this is an eng or userdebug build, automatically turn on the text display if no command
    // is specified. Note that this should be called before setting the background to avoid
    // flickering the background image.
    //if (is_ro_debuggable()) {
      ui->ShowText(true);
    //}
    status = INSTALL_NONE;  // No command specified
    //ui->SetBackground(RecoveryUI::NO_COMMAND);
  }
```

去掉debug模式的判断，然后注释掉设置无命令的背景就可以了



