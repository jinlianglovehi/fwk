






在os定制化开发中，对wifi做定制化也是常有的事情，而在10.0中，开发网络白名单的时候，由于对网络做了部分限制，所以  
 可能在刚连接网络的时候，会出现wifi图标出现感叹或者叉的情况  
 借鉴别人的博客发现 Wifi在连接的时候，会检测网络是否通，当刚开始连接的时候有时候会误认为不通其实网络是通的


某个NetworkFactory连接上网络时，就会创建NetworkAgent对象，然后注册到ConnectivityService，而在注册过程中，ConnectivityService将会利用NetworkAgent传递过来的NetworkInfo、Messenger、分值等信息创建NetworkAgentInfo对象。而在该对象的创建过程中，将会创建一个网络监听器NetworkMonitor


接下来我们看下NetworkMonitor的源码


10.0的路径为:packages/modules/NetworkStack/src/com/android/server/connectivity/NetworkMonitor.java


9.0的路径为: frameworks\base\services\core\java\com\android\server\connectivity\NetworkMonitor.java


NetworkMonitor.java 就是一个观察者模式来监听网络变化情况



```
mIsCaptivePortalCheckEnabled = false;
@VisibleForTesting
    protected NetworkMonitor(Context context, INetworkMonitorCallbacks cb, Network network,
            IpConnectivityLog logger, SharedLog validationLogs,
            Dependencies deps, DataStallStatsUtils detectionStatsUtils) {
        // Add suffix indicating which NetworkMonitor we're talking about.
        super(TAG + "/" + network.toString());

        // Logs with a tag of the form given just above, e.g.
        //     <timestamp>   862  2402 D NetworkMonitor/NetworkAgentInfo [WIFI () - 100]: ...
        setDbg(VDBG);

        mContext = context;
        mMetricsLog = logger;
        mValidationLogs = validationLogs;
        mCallback = cb;
        mCallbackVersion = getCallbackVersion(cb);
        mDependencies = deps;
        mDetectionStatsUtils = detectionStatsUtils;
        mNetwork = network;
        mCleartextDnsNetwork = deps.getPrivateDnsBypassNetwork(network);
        mTelephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        mWifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        mCm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        // CHECKSTYLE:OFF IndentationCheck
        addState(mDefaultState);
        addState(mMaybeNotifyState, mDefaultState);
            addState(mEvaluatingState, mMaybeNotifyState);
                addState(mProbingState, mEvaluatingState);
                addState(mWaitingForNextProbeState, mEvaluatingState);
            addState(mCaptivePortalState, mMaybeNotifyState);
        addState(mEvaluatingPrivateDnsState, mDefaultState);
        addState(mValidatedState, mDefaultState);
        setInitialState(mDefaultState);
        // CHECKSTYLE:ON IndentationCheck

```


```
   // 定义变量来是否检测网络

```


```
mIsCaptivePortalCheckEnabled = getIsCaptivePortalCheckEnabled();

```


```
    mUseHttps = getUseHttpsValidation();
    mCaptivePortalUserAgent = getCaptivePortalUserAgent();
    mCaptivePortalHttpsUrl = makeURL(getCaptivePortalServerHttpsUrl());
    mCaptivePortalHttpUrl = makeURL(getCaptivePortalServerHttpUrl());
    mCaptivePortalFallbackUrls = makeCaptivePortalFallbackUrls();
    mCaptivePortalFallbackSpecs = makeCaptivePortalFallbackProbeSpecs();
    mRandom = deps.getRandom();
    // TODO: Evaluate to move data stall configuration to a specific class.
    mConsecutiveDnsTimeoutThreshold = getConsecutiveDnsTimeoutThreshold();
    mDnsStallDetector = new DnsStallDetector(mConsecutiveDnsTimeoutThreshold);
    mDataStallMinEvaluateTime = getDataStallMinEvaluateTime();
    mDataStallValidDnsTimeThreshold = getDataStallValidDnsTimeThreshold();
    mDataStallEvaluationType = getDataStallEvaluationType();

    // Provide empty LinkProperties and NetworkCapabilities to make sure they are never null,
    // even before notifyNetworkConnected.
    mLinkProperties = new LinkProperties();
    mNetworkCapabilities = new NetworkCapabilities(null);
}

```

getIsCaptivePortalCheckEnabled();就是返回是否需要检测网络



```
 @VisibleForTesting
    protected CaptivePortalProbeResult isCaptivePortal() {
        if (!mIsCaptivePortalCheckEnabled) {
            validationLog("Validation disabled.");
            return CaptivePortalProbeResult.SUCCESS;
        }

        URL pacUrl = null;
        URL httpsUrl = mCaptivePortalHttpsUrl;
        URL httpUrl = mCaptivePortalHttpUrl;

        // On networks with a PAC instead of fetching a URL that should result in a 204
        // response, we instead simply fetch the PAC script.  This is done for a few reasons:
        // 1. At present our PAC code does not yet handle multiple PACs on multiple networks
        //    until something like https://android-review.googlesource.com/#/c/115180/ lands.
        //    Network.openConnection() will ignore network-specific PACs and instead fetch
        //    using NO_PROXY.  If a PAC is in place, the only fetch we know will succeed with
        //    NO_PROXY is the fetch of the PAC itself.
        // 2. To proxy the generate_204 fetch through a PAC would require a number of things
        //    happen before the fetch can commence, namely:
        //        a) the PAC script be fetched
        //        b) a PAC script resolver service be fired up and resolve the captive portal
        //           server.
        //    Network validation could be delayed until these prerequisities are satisifed or
        //    could simply be left to race them.  Neither is an optimal solution.
        // 3. PAC scripts are sometimes used to block or restrict Internet access and may in
        //    fact block fetching of the generate_204 URL which would lead to false negative
        //    results for network validation.
        final ProxyInfo proxyInfo = mLinkProperties.getHttpProxy();
        if (proxyInfo != null && !Uri.EMPTY.equals(proxyInfo.getPacFileUrl())) {
            pacUrl = makeURL(proxyInfo.getPacFileUrl().toString());
            if (pacUrl == null) {
                return CaptivePortalProbeResult.FAILED;
            }
        }

        if ((pacUrl == null) && (httpUrl == null || httpsUrl == null)) {
            return CaptivePortalProbeResult.FAILED;
        }

        long startTime = SystemClock.elapsedRealtime();

        final CaptivePortalProbeResult result;
        if (pacUrl != null) {
            result = sendDnsAndHttpProbes(null, pacUrl, ValidationProbeEvent.PROBE_PAC);
            reportHttpProbeResult(NETWORK_VALIDATION_PROBE_HTTP, result);
        } else if (mUseHttps) {
            // Probe results are reported inside sendParallelHttpProbes.
            result = sendParallelHttpProbes(proxyInfo, httpsUrl, httpUrl);
        } else {
            result = sendDnsAndHttpProbes(proxyInfo, httpUrl, ValidationProbeEvent.PROBE_HTTP);
            reportHttpProbeResult(NETWORK_VALIDATION_PROBE_HTTP, result);
        }

        long endTime = SystemClock.elapsedRealtime();

        sendNetworkConditionsBroadcast(true /* response received */,
                result.isPortal() /* isCaptivePortal */,
                startTime, endTime);

        log("isCaptivePortal: isSuccessful()=" + result.isSuccessful()
                + " isPortal()=" + result.isPortal()
                + " RedirectUrl=" + result.redirectUrl
                + " isPartialConnectivity()=" + result.isPartialConnectivity()
                + " Time=" + (endTime - startTime) + "ms");

        return result;
    }

```

在连接成功以后的 isCaptivePortal()的回调中



```
 if (!mIsCaptivePortalCheckEnabled) {
            validationLog("Validation disabled.");
            return CaptivePortalProbeResult.SUCCESS;
        }

```

如果不需要检测网络 就直接返回SUCCESS:


所以就需要



```
getIsCaptivePortalCheckEnabled();做修改
    private boolean getIsCaptivePortalCheckEnabled() {
        String symbol = CAPTIVE_PORTAL_MODE;
        int defaultValue = CAPTIVE_PORTAL_MODE_PROMPT;
        int mode = mDependencies.getSetting(mContext, symbol, defaultValue);
        return mode != CAPTIVE_PORTAL_MODE_IGNORE;
}

```

可以看出 是从数据库中获取值是否等于CAPTIVE\_PORTAL\_MODE\_IGNORE  
 packages\modules\NetworkStack\src\android\net\util\NetworkStackUtils.java



```
public static final String CAPTIVE_PORTAL_MODE = "captive\_portal\_mode";
public static final int CAPTIVE_PORTAL_MODE_PROMPT = 1;

```

这两个默认值其实就是Settings.Global.CAPTIVE\_PORTAL\_MODE, Settings.Global.CAPTIVE\_PORTAL\_MODE\_PROMPT;  
 可以看出 默认是打开网络检测的


所以修改方案：  
 1.第一种方案:getIsCaptivePortalCheckEnabled()直接返回false 表示不需要检测网络



```
    private boolean getIsCaptivePortalCheckEnabled() {
        String symbol = CAPTIVE_PORTAL_MODE;
        int defaultValue = CAPTIVE_PORTAL_MODE_PROMPT;
        int mode = mDependencies.getSetting(mContext, symbol, defaultValue);
       - return mode != CAPTIVE_PORTAL_MODE_IGNORE;
      + return false;
}

```

2.第二种方案:


在frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java  
 对数据库做修改 默认值为不检查  
 Settings.java



```
    /**
     * Don't attempt to detect captive portals.
     *
     * @hide
     */
    public static final int CAPTIVE_PORTAL_MODE_IGNORE = 0;
   /**
     * When detecting a captive portal, display a notification that
     * prompts the user to sign in.
     *
     * @hide
     */
    public static final int CAPTIVE_PORTAL_MODE_PROMPT = 1;

    /**
     * When detecting a captive portal, immediately disconnect from the
     * network and do not reconnect to that network in the future.
     *
     * @hide
     */
    public static final int CAPTIVE_PORTAL_MODE_AVOID = 2;

    /**
     * What to do when connecting a network that presents a captive portal.
     * Must be one of the CAPTIVE_PORTAL_MODE_* constants above.
     *
     * The default for this setting is CAPTIVE_PORTAL_MODE_PROMPT.
     * @hide
     */
    public static final String CAPTIVE_PORTAL_MODE = "captive\_portal\_mode";

```

CAPTIVE\_PORTAL\_MODE\_IGNORE 即为不检查网络


所以具体修改如下:



```
--- a/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
+++ b/frameworks/base/packages/SettingsProvider/src/com/android/providers/settings/DatabaseHelper.java
@@ -2644,7 +2644,7 @@ class DatabaseHelper extends SQLiteOpenHelper {
                 defaultLidBehavior = 0;
             }
             loadSetting(stmt, Settings.Global.LID_BEHAVIOR, defaultLidBehavior);
-
+            loadSetting(stmt, Settings.Global.CAPTIVE_PORTAL_MODE, Settings.Global.CAPTIVE_PORTAL_MODE_IGNORE);
             /*
              * IMPORTANT: Do not add any more upgrade steps here as the global,
              * secure, and system settings are no longer stored in a database

```

在数据库里面默认不检查网络


编译验证即可发现不会出现wifi图标带叉或感叹号的情况





