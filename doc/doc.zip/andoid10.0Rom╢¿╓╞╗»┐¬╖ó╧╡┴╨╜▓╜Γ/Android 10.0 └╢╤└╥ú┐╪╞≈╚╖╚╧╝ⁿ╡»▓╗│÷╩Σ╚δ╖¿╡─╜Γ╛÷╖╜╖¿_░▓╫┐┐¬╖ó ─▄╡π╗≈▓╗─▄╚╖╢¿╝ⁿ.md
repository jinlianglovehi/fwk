






在做android设备定制化开发时，有使用红外遥控器，也有使用蓝牙遥控器的,所以出现的问题不一定相同，今天遇到个问题就是蓝牙  
 遥控器弹不出输入法的问题  
 首选排除输入法的问题，安装其他的输入法，也是同样的问题，这样就确定是系统控件相关的问题了，接下来就从系统输入框控件  
 来寻找原因了


解决方案:  
 EditText的父类是TextView 所以最终需要从TextView.java中查询问题所在了  
 路径:framework/base/core/java/android/widget/TextView.java


蓝牙遥控器的确定按键对应的Android keycode事件是KeyEvent.KEYCODE\_DPAD\_CENTER  
 接下来查看源码中的KeyEvent.KEYCODE\_DPAD\_CENTER 处理事件



```
 @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (!isEnabled()) {
            return super.onKeyUp(keyCode, event);
        }

        if (!KeyEvent.isModifierKey(keyCode)) {
            mPreventDefaultMovement = false;
        }

        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_CENTER:
                if (event.hasNoModifiers()) {
                    /*
                     * If there is a click listener, just call through to
                     * super, which will invoke it.
                     *
                     * If there isn't a click listener, try to show the soft
 \* input method. (It will also
 \* call performClick(), but that won't do anything in
                     * this case.)
                     */
                    if (!hasOnClickListeners()) {
                        if (mMovement != null && mText instanceof Editable
                                && mLayout != null && onCheckIsTextEditor()) {
                            InputMethodManager imm = getInputMethodManager();
                            viewClicked(imm);
                            if (imm != null && getShowSoftInputOnFocus()) {
                                imm.showSoftInput(this, 0);
                            }
                        }
                    }
                }
                return super.onKeyUp(keyCode, event);

            case KeyEvent.KEYCODE_ENTER:
                if (event.hasNoModifiers()) {
                    if (mEditor != null && mEditor.mInputContentType != null
                            && mEditor.mInputContentType.onEditorActionListener != null
                            && mEditor.mInputContentType.enterDown) {
                        mEditor.mInputContentType.enterDown = false;
                        if (mEditor.mInputContentType.onEditorActionListener.onEditorAction(
                                this, EditorInfo.IME_NULL, event)) {
                            return true;
                        }
                    }

                    if ((event.getFlags() & KeyEvent.FLAG\_EDITOR\_ACTION) != 0
 || shouldAdvanceFocusOnEnter()) {
                        /*
                         * If there is a click listener, just call through to
                         * super, which will invoke it.
                         *
                         * If there isn't a click listener, try to advance focus,
 \* but still call through to super, which will reset the
 \* pressed state and longpress state. (It will also
 \* call performClick(), but that won't do anything in
                         * this case.)
                         */
                        if (!hasOnClickListeners()) {
                            View v = focusSearch(FOCUS_DOWN);

                            if (v != null) {
                                if (!v.requestFocus(FOCUS_DOWN)) {
                                    throw new IllegalStateException("focus search returned a view "
                                            + "that wasn't able to take focus!");
                                }

                                /*
                                 * Return true because we handled the key; super
                                 * will return false because there was no click
                                 * listener.
                                 */
                                super.onKeyUp(keyCode, event);
                                return true;
                            } else if ((event.getFlags()
 & KeyEvent.FLAG\_EDITOR\_ACTION) != 0) {
 // No target for next focus, but make sure the IME
 // if this came from it.
 InputMethodManager imm = getInputMethodManager();
 if (imm != null && imm.isActive(this)) {
                                    imm.hideSoftInputFromWindow(getWindowToken(), 0);
                                }
                            }
                        }
                    }
                    return super.onKeyUp(keyCode, event);
                }
                break;
        }

        if (mEditor != null && mEditor.mKeyListener != null) {
            if (mEditor.mKeyListener.onKeyUp(this, (Editable) mText, keyCode, event)) {
                return true;
            }
        }

        if (mMovement != null && mLayout != null) {
            if (mMovement.onKeyUp(this, mSpannable, keyCode, event)) {
                return true;
            }
        }

        return super.onKeyUp(keyCode, event);
    }

```

从onKeyUp中可以看出  
 if (!hasOnClickListeners()) {  
 if (mMovement != null && mText instanceof Editable  
 && mLayout != null && onCheckIsTextEditor()) {  
 InputMethodManager imm = getInputMethodManager();  
 viewClicked(imm);  
 if (imm != null && getShowSoftInputOnFocus()) {  
 imm.showSoftInput(this, 0);  
 }  
 }  
 }  
 调用输入法  
 就是说没有设置OnClickListeners 事件才会被调用  
 所以找到问题所在了  
 解决方法就是去掉这个条件判断 修改为:



```
case KeyEvent.KEYCODE_DPAD_CENTER:
                if (event.hasNoModifiers()) {
                    /*
                     * If there is a click listener, just call through to
                     * super, which will invoke it.
                     *
                     * If there isn't a click listener, try to show the soft
 \* input method. (It will also
 \* call performClick(), but that won't do anything in
                     * this case.)
                     */
                    //if (!hasOnClickListeners()) {
                        if (mMovement != null && mText instanceof Editable
                                && mLayout != null && onCheckIsTextEditor()) {
                            InputMethodManager imm = getInputMethodManager();
                            viewClicked(imm);
                            if (imm != null && getShowSoftInputOnFocus()) {
                                imm.showSoftInput(this, 0);
                            }
                        }
                   // }
                }
                return super.onKeyUp(keyCode, event);

```




