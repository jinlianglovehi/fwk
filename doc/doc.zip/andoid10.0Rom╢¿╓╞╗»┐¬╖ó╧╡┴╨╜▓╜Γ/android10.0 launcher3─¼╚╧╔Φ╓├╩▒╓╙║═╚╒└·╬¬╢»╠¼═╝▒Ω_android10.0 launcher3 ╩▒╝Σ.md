






### 1.概述


在10.0的系统产品开发中，在Launcher3长按屏幕 弹出的弹窗中 点击 主屏幕设置 在下面的下拉列表中 可以看到 动态图标 点击动态图标  
 可以看到 有 时钟 和 日历的 开关 但是发现默认是关闭的  
 打开开关后 发现时钟和日历图标开始变成动态图标了


### 2.launcher3默认设置时钟和日历为动态图标的核心类



```
package/app/Launcher3/com/sprd/ext/dynamicicon/DynamicIconSettings.java

```

### 3.launcher3默认设置时钟和日历为动态图标的核心功能分析和实现


用adb 命令 发现 所在的页面为 DynamicIconSettings.java  
 源码路径为:  
 package/app/Launcher3/com/sprd/ext/dynamicicon/DynamicIconSettings.java


进入源码



```
@Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            getPreferenceManager().setSharedPreferencesName(LauncherFiles.SHARED_PREFERENCES_KEY);
            setPreferencesFromResource(R.xml.dynamic_icon_settings, rootKey);

            mContext = getActivity();
            mDIController = LauncherAppMonitor.getInstance(mContext).getDynamicIconController();
            ArrayList<String> installedPkgs = mDIController.getInstalledDynamicPkgs();

            if (FeatureOption.SPRD_DYNAMIC_ICON_CALENDAR_SUPPORT) {
                verifyAndInitPref(PREF_KEY_ORIGINAL_CALENDAR,
                        getResources().getBoolean(R.bool.dynamic_calendar_default_state), installedPkgs);
                verifyAndInitPref(PREF_KEY_GOOGLE_CALENDAR,
                        getResources().getBoolean(R.bool.dynamic_calendar_default_state), installedPkgs);
            } else {
                getPreferenceScreen().removePreference(findPreference(PREF_KEY_ORIGINAL_CALENDAR));
                getPreferenceScreen().removePreference(findPreference(PREF_KEY_GOOGLE_CALENDAR));
            }

            if (FeatureOption.SPRD_DYNAMIC_ICON_CLOCK_SUPPORT) {
                verifyAndInitPref(PREF_KEY_ORIGINAL_CLOCK,
                        getResources().getBoolean(R.bool.dynamic_clock_default_state), installedPkgs);
                verifyAndInitPref(PREF_KEY_GOOGLE_CLOCK,
                        getResources().getBoolean(R.bool.dynamic_clock_default_state), installedPkgs);
            } else {
                getPreferenceScreen().removePreference(findPreference(PREF_KEY_ORIGINAL_CLOCK));
                getPreferenceScreen().removePreference(findPreference(PREF_KEY_GOOGLE_CLOCK));
            }
        }

       private void verifyAndInitPref(String key, boolean def, ArrayList<String> installedPkgs) {
            SwitchPreference pref = (SwitchPreference) findPreference(key);
            String pkg = mDIController.getPackageNameByPrefKey(key);

            if (installedPkgs.contains(pkg)) {
                Bundle bundle = pref.getExtras();
                bundle.putString(PKG_NAME, pkg);

                pref.setIcon(UtilitiesExt.getAppIcon(mContext, pkg, Process.myUserHandle()));
                CharSequence title = UtilitiesExt.getAppLabelByPackageName(mContext, pkg);
                if (!TextUtils.isEmpty(title)) {
                    pref.setTitle(title);
                }
               //获取默认值 def
                boolean isChecked = DynamicIconUtils.getAppliedValue(mContext, key, def);
                pref.setChecked(isChecked);
                pref.setOnPreferenceChangeListener(this);
            } else {
                getPreferenceScreen().removePreference(pref);
            }
        }

```

从源码可以看到 def 的值是由getResources().getBoolean(R.bool.dynamic\_calendar\_default\_state)的dynamic\_calendar\_default\_state


在 config\_ext.xml中



```
<bool name="dynamic\_calendar\_default\_state">false</bool>
<bool name="dynamic\_clock\_default\_state">false</bool>

```

所以这两个开关默认是关闭的


修改如下:



```
<bool name="dynamic\_calendar\_default\_state">true</bool>
<bool name="dynamic\_clock\_default\_state">true</bool>

```

将默认值修改为true 就可以了 这样就会看到动态的日历和时钟图标了





