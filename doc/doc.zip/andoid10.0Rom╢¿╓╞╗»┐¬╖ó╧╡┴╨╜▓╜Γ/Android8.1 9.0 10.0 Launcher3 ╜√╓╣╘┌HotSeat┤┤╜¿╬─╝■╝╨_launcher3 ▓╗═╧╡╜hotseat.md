






### 1.概述


在10.0的产品定制化开发中，在laucher3中拖拽item时 靠近某个图标时会形成文件夹（folder）,而根据客户需求不想再hotseat形成文件夹， 这就要从workspace.java从来寻找解决方案了


### 2.Launcher3 禁止在HotSeat创建文件夹的核心类



```
/packages/apps/Launcher3/src/com/android/launcher3/Workspace.java

```

### 3.Launcher3 禁止在HotSeat创建文件夹的核心功能分析和实现


功能分析：  
 Launcher3中形成文件夹，是在Workspace.java中的 onDrop()方法里面实现的，拖动图标落点处可以合成一个Folder，如果不满足文件夹的条件，则调用CellLayout.java的performReorder方法  
 createUserFolderIfNecessary()方法  
 接下来看下createUserFolderIfNecessary()方法的相关源码



```
boolean createUserFolderIfNecessary(View newView, long container, CellLayout target,
            int[] targetCell, float distance, boolean external, DragView dragView,
            Runnable postAnimationRunnable) {
if (distance > mMaxDistanceForFolderCreation) return false;
        View v = target.getChildAt(targetCell[0], targetCell[1]);

        boolean hasntMoved = false;
        if (mDragInfo != null && mDragInfo.cell.getParent() != null) {
            CellLayout cellParent = getParentCellLayoutForView(mDragInfo.cell);
            hasntMoved = (mDragInfo.cellX == targetCell[0] &&
                    mDragInfo.cellY == targetCell[1]) && (cellParent == target);
        }

        if (v == null || hasntMoved || !mCreateUserFolderOnDrop) return false;
        mCreateUserFolderOnDrop = false;
        final int screenId = getIdForScreen(target);

        boolean aboveShortcut = (v.getTag() instanceof WorkspaceItemInfo);
        boolean willBecomeShortcut = (newView.getTag() instanceof WorkspaceItemInfo);

        if (aboveShortcut && willBecomeShortcut) {
            WorkspaceItemInfo sourceInfo = (WorkspaceItemInfo) newView.getTag();
            WorkspaceItemInfo destInfo = (WorkspaceItemInfo) v.getTag();
            // if the drag started here, we need to remove it from the workspace
            if (!external && mDragInfo.cell.getParent() != null) {
                getParentCellLayoutForView(mDragInfo.cell).removeView(mDragInfo.cell);
            }

            Rect folderLocation = new Rect();
            float scale = mLauncher.getDragLayer().getDescendantRectRelativeToSelf(v, folderLocation);
            target.removeView(v);

            FolderIcon fi =
                mLauncher.addFolder(target, container, screenId, targetCell[0], targetCell[1]);
            destInfo.cellX = -1;
            destInfo.cellY = -1;
            sourceInfo.cellX = -1;
            sourceInfo.cellY = -1;

            // If the dragView is null, we can't animate
            boolean animate = dragView != null;
            if (animate) {
                // In order to keep everything continuous, we hand off the currently rendered
                // folder background to the newly created icon. This preserves animation state.
                fi.setFolderBackground(mFolderCreateBg);
                mFolderCreateBg = new PreviewBackground();
                fi.performCreateAnimation(destInfo, v, sourceInfo, dragView, folderLocation, scale
                );
            } else {
                fi.prepareCreateAnimation(v);
                fi.addItem(destInfo);
                fi.addItem(sourceInfo);
            }
            return true;
        }
        return false;
    }

```

在workspace中调用createUserFolderIfNecessary就是形成文件夹的功能，  
 所以不想再hotseat形成文件夹  
 就做如下修改:



```
boolean createUserFolderIfNecessary(View newView, long container, CellLayout target,
            int[] targetCell, float distance, boolean external, DragView dragView,
            Runnable postAnimationRunnable) {
        //core begin
        if (container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
            return false;
        }
        //core end
if (distance > mMaxDistanceForFolderCreation) return false;
        View v = target.getChildAt(targetCell[0], targetCell[1]);

```

根据container判断类型是文件夹就返回  
 运行一下，发现确实有效果 但是在HotSeat中拖动一个APP放到目标APP上方仍然会有一个文件夹的虚影  
 继续在workspace.java中看到了manageFolderFeedback()，管理文件夹 进入方法看下：



```
private void manageFolderFeedback(CellLayout targetLayout,
            int[] targetCell, float distance, DragObject dragObject) {
        if (distance > mMaxDistanceForFolderCreation) {
            if (mDragMode != DRAG_MODE_NONE) {
                setDragMode(DRAG_MODE_NONE);
            }
            return;
        }

        final View dragOverView = mDragTargetLayout.getChildAt(mTargetCell[0], mTargetCell[1]);
        ItemInfo info = dragObject.dragInfo;
        boolean userFolderPending = willCreateUserFolder(info, dragOverView, false);
        if (mDragMode == DRAG_MODE_NONE && userFolderPending &&
                !mFolderCreationAlarm.alarmPending()) {

            FolderCreationAlarmListener listener = new
                    FolderCreationAlarmListener(targetLayout, targetCell[0], targetCell[1]);

            if (!dragObject.accessibleDrag) {
                mFolderCreationAlarm.setOnAlarmListener(listener);
                mFolderCreationAlarm.setAlarm(FOLDER_CREATION_TIMEOUT);
            } else {
                listener.onAlarm(mFolderCreationAlarm);
            }

            if (dragObject.stateAnnouncer != null) {
                dragObject.stateAnnouncer.announce(WorkspaceAccessibilityHelper
                        .getDescriptionForDropOver(dragOverView, getContext()));
            }
            return;
        }

        boolean willAddToFolder = willAddToExistingUserFolder(info, dragOverView) && !mLauncher.isHotseatLayout(targetLayout);
        if (willAddToFolder && mDragMode == DRAG_MODE_NONE) {
            mDragOverFolderIcon = ((FolderIcon) dragOverView);
 mDragOverFolderIcon.onDragEnter(info);
 if (targetLayout != null) {
 targetLayout.clearDragOutlines();
 }
 setDragMode(DRAG\_MODE\_ADD\_TO\_FOLDER);

 if (dragObject.stateAnnouncer != null) {
 dragObject.stateAnnouncer.announce(WorkspaceAccessibilityHelper
 .getDescriptionForDropOver(dragOverView, getContext()));
            }
            return;
        }

        if (mDragMode == DRAG_MODE_ADD_TO_FOLDER && !willAddToFolder) {
            setDragMode(DRAG_MODE_NONE);
        }
        if (mDragMode == DRAG_MODE_CREATE_FOLDER && !userFolderPending) {
            setDragMode(DRAG_MODE_NONE);
        }
    }

```

从manageFolderFeedback的willCreateUserFolder源码发现这里就是虚影的生存方法，  
 改完后 测试发现找到解决方法:  
 修改如下:



```
private void manageFolderFeedback(CellLayout targetLayout,
            int[] targetCell, float distance, DragObject dragObject) {
        if (distance > mMaxDistanceForFolderCreation) return;

        final View dragOverView = mDragTargetLayout.getChildAt(mTargetCell[0], mTargetCell[1]);
        ItemInfo info = dragObject.dragInfo;

      -  boolean userFolderPending = willCreateUserFolder(info, dragOverView, false);





      + boolean userFolderPending = willCreateUserFolder(info, dragOverView, false)
                && !mLauncher.isHotseatLayout(targetLayout);

```

在willCreateUserFolder加上不是hotseat的判断就可以实现功能了





