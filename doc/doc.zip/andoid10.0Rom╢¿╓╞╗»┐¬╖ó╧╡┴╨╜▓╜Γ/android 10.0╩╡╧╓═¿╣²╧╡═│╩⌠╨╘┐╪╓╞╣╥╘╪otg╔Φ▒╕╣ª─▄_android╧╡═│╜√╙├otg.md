






### 1.概述


在10.0的系统产品定制开发中，产品有需求要实现挂载otg设备开关功能，在挂载otg设备的时候，通过判断系统数据标志位实现是否挂载,


### 2.实现卸载otg设备功能的核心类



```
frameworks/base/services/core/java/com/android/server/StorageManagerService.java

```

### 3.实现卸载otg设备功能的核心功能分析和实现


功能分析:  
 在系统中StorageManagerService 负责管理otg设备挂载和卸载的相关功能，所以需要实现通过系统属性来控制挂载otg的功能，在StorageManagerService里通过分析相关的挂载卸载流程就可以实现需求  
 功能的实现  
 接下来看下StorageManagerService中相关源码分析



```

  class StorageManagerService extends IStorageManager.Stub
          implements Watchdog.Monitor, ScreenObserver {
  class StorageManagerServiceHandler extends Handler {
          public StorageManagerServiceHandler(Looper looper) {
              super(looper);
          }
  
          @Override
          public void handleMessage(Message msg) {
              switch (msg.what) {
                ....
                  case H_SHUTDOWN: {
                      final IStorageShutdownObserver obs = (IStorageShutdownObserver) msg.obj;
                      boolean success = false;
                      try {
                          mVold.shutdown();
                          success = true;
                      } catch (Exception e) {
                          Slog.wtf(TAG, e);
                      }
                      if (obs != null) {
                          try {
                              obs.onShutDownComplete(success ? 0 : -1);
                          } catch (Exception ignored) {
                          }
                      }
                      break;
                  }
                  case H_VOLUME_MOUNT: {
                      final VolumeInfo vol = (VolumeInfo) msg.obj;
                      if (isMountDisallowed(vol)) {
                          Slog.i(TAG, "Ignoring mount " + vol.getId() + " due to policy");
                          break;
                      }
                      mount(vol);
                      break;
                  }
                  case H_VOLUME_UNMOUNT: {
                      final VolumeInfo vol = (VolumeInfo) msg.obj;
                      unmount(vol);
                      break;
                  }
                  case H_VOLUME_BROADCAST: {
                      final StorageVolume userVol = (StorageVolume) msg.obj;
                      final String envState = userVol.getState();
                      Slog.d(TAG, "Volume " + userVol.getId() + " broadcasting " + envState + " to "
                              + userVol.getOwner());
  
                      final String action = VolumeInfo.getBroadcastForEnvironment(envState);
                      if (action != null) {
                          final Intent intent = new Intent(action,
                                  Uri.fromFile(userVol.getPathFile()));
                          intent.putExtra(StorageVolume.EXTRA_STORAGE_VOLUME, userVol);
                          intent.addFlags(Intent.FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT
                                  | Intent.FLAG_RECEIVER_INCLUDE_BACKGROUND);
                          mContext.sendBroadcastAsUser(intent, userVol.getOwner());
                      }
                      break;
                  }
          }
      }

```

在StorageManagerServiceHandler中通过接收otg挂载的handler信息，从而实现调用挂载的相关方法，otg挂载会调用isMountDisallowed(vol)来判断调用挂载的相关准备功能


接下来看其他的方法



```
     private final IVoldListener mListener = new IVoldListener.Stub() {
          @Override
          public void onDiskCreated(String diskId, int flags) {
              synchronized (mLock) {
                  final String value = SystemProperties.get(StorageManager.PROP_ADOPTABLE);
                  switch (value) {
                      case "force\_on":
                          flags |= DiskInfo.FLAG_ADOPTABLE;
                          break;
                      case "force\_off":
                          flags &= ~DiskInfo.FLAG_ADOPTABLE;
                          break;
                  }
                  mDisks.put(diskId, new DiskInfo(diskId, flags));
              }
          }
  
          @Override
          public void onDiskScanned(String diskId) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.get(diskId);
                  if (disk != null) {
                      onDiskScannedLocked(disk);
                  }
              }
          }
  
          @Override
          public void onDiskMetadataChanged(String diskId, long sizeBytes, String label,
                  String sysPath) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.get(diskId);
                  if (disk != null) {
                      disk.size = sizeBytes;
                      disk.label = label;
                      disk.sysPath = sysPath;
                  }
              }
          }
  
          @Override
          public void onDiskDestroyed(String diskId) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.remove(diskId);
                  if (disk != null) {
                      mCallbacks.notifyDiskDestroyed(disk);
                  }
              }
          }
  
          @Override
          public void onVolumeCreated(String volId, int type, String diskId, String partGuid) {
              synchronized (mLock) {
                  final DiskInfo disk = mDisks.get(diskId);
                  final VolumeInfo vol = new VolumeInfo(volId, type, disk, partGuid);
                  mVolumes.put(volId, vol);
                  onVolumeCreatedLocked(vol);
              }
          }
  
          @Override
          public void onVolumeStateChanged(String volId, int state) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      final int oldState = vol.state;
                      final int newState = state;
                      vol.state = newState;
                      onVolumeStateChangedLocked(vol, oldState, newState);
                  }
              }
          }
  
          @Override
          public void onVolumeMetadataChanged(String volId, String fsType, String fsUuid,
                  String fsLabel) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      vol.fsType = fsType;
                      vol.fsUuid = fsUuid;
                      vol.fsLabel = fsLabel;
                  }
              }
          }
  
          @Override
          public void onVolumePathChanged(String volId, String path) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      vol.path = path;
                  }
              }
          }
  
          @Override
          public void onVolumeInternalPathChanged(String volId, String internalPath) {
              synchronized (mLock) {
                  final VolumeInfo vol = mVolumes.get(volId);
                  if (vol != null) {
                      vol.internalPath = internalPath;
                  }
              }
          }
  
          @Override
          public void onVolumeDestroyed(String volId) {
              synchronized (mLock) {
                  mVolumes.remove(volId);
              }
          }
      };

```

在StorageManagerService.java启动服务后，在IVoldListener 中监听vold的otg挂载和卸载事件，当需要挂载时，调用onVolumeCreated开始otg挂载流程，然后发送挂载的handler消息，最后通过  
 isMountDisallowed来判断是否需要挂载，所以控制otg设备的挂载可以在这里实现判断是否需要挂载



```
--- a/frameworks/base/services/core/java/com/android/server/StorageManagerService.java
+++ b/frameworks/base/services/core/java/com/android/server/StorageManagerService.java
@@ -126,7 +126,7 @@ import android.util.Xml;
 /* SPRD: add some log for debug @{ */
 import android.util.Log;
 /* @} */
-
+import android.provider.Settings;
 import com.android.internal.annotations.GuardedBy;
 import com.android.internal.app.IAppOpsCallback;
 import com.android.internal.app.IAppOpsService;
@@ -1527,6 +1527,17 @@ class StorageManagerService extends StorageManagerServiceEx

     private boolean isMountDisallowed(VolumeInfo vol) {
+               boolean sdcardEnabled = (Settings.Global.getInt(mContext.getContentResolver(),
+               "disable\_sdcard", 0) == 1);
+               boolean otgEnabled=(Settings.Global.getInt(mContext.getContentResolver(),"disable\_otg", 0) == 1);
+               DiskInfo disk=vol.disk;
+               if(sdcardEnabled && !"/storage/emulated/0".equals(vol.getPath()) && !(vol.disk != null && vol.disk.isUsb())){
+                       return true;   
+               }
+               if(otgEnabled && !"/storage/emulated/0".equals(vol.getPath()) && (vol.disk != null && vol.disk.isUsb())){
+                       return true;   
+               }
         UserManager userManager = mContext.getSystemService(UserManager.class);
 
         boolean isUsbRestricted = false;

```

在isMountDisallowed（）在这里处理是否挂载otg设备，根据disable\_otg和disable\_sdcard来决定是否需要挂载sdcard和otg，根据值来判断是否需要挂载，然后  
 可以在相应的api中设置这两个值是否为1，1表示禁用





