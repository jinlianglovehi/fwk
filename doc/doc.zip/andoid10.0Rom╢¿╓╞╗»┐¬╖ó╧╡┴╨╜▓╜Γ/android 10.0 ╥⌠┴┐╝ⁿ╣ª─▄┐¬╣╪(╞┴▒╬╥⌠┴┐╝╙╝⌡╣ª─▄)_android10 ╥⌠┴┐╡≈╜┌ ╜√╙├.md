



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.音量键功能开关(屏蔽音量加减功能)的核心类](#2.%E9%9F%B3%E9%87%8F%E9%94%AE%E5%8A%9F%E8%83%BD%E5%BC%80%E5%85%B3%28%E5%B1%8F%E8%94%BD%E9%9F%B3%E9%87%8F%E5%8A%A0%E5%87%8F%E5%8A%9F%E8%83%BD%29%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.音量键功能开关(屏蔽音量加减功能)的核心功能分析和实现](#3.%E9%9F%B3%E9%87%8F%E9%94%AE%E5%8A%9F%E8%83%BD%E5%BC%80%E5%85%B3%28%E5%B1%8F%E8%94%BD%E9%9F%B3%E9%87%8F%E5%8A%A0%E5%87%8F%E5%8A%9F%E8%83%BD%29%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0)




---



## 1.概述


在10.0的系统产品开发中，关于产品的主要按键的响应都是在PhoneWindowManager.java中处理的,电源键 音量加减键也是在这里处理的，所以在音量键事件响应的地方加上标志位就可以了


## 2.音量键功能开关(屏蔽音量加减功能)的核心类



```
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
```

## 3.音量键功能开关(屏蔽音量加减功能)的核心功能分析和实现


在系统关于对与功能按键的分析都是在PhoneWindowManager.java中管理的，所以屏蔽音量键也是在这里分析的，接下来看PhoneWindowManager.java的相关源码



```
@Override
      public int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
          if (!mSystemBooted) {
              // If we have not yet booted, don't let key events do anything.
              return 0;
          }
  
          final boolean interactive = (policyFlags & FLAG_INTERACTIVE) != 0;
          final boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
          final boolean canceled = event.isCanceled();
          final int keyCode = event.getKeyCode();
          final int displayId = event.getDisplayId();
  
          final boolean isInjected = (policyFlags & WindowManagerPolicy.FLAG_INJECTED) != 0;
  
          // If screen is off then we treat the case where the keyguard is open but hidden
          // the same as if it were open and in front.
          // This will prevent any keys other than the power button from waking the screen
          // when the keyguard is hidden by another activity.
          final boolean keyguardActive = (mKeyguardDelegate == null ? false :
                                              (interactive ?
                                                  isKeyguardShowingAndNotOccluded() :
                                                  mKeyguardDelegate.isShowing()));
  
          if (DEBUG_INPUT) {
              Log.d(TAG, "interceptKeyTq keycode=" + keyCode
                      + " interactive=" + interactive + " keyguardActive=" + keyguardActive
                      + " policyFlags=" + Integer.toHexString(policyFlags));
          }
  
          // Basic policy based on interactive state.
          int result;
          boolean isWakeKey = (policyFlags & WindowManagerPolicy.FLAG_WAKE) != 0
                  || event.isWakeKey();
          if (interactive || (isInjected && !isWakeKey)) {
              // When the device is interactive or the key is injected pass the
              // key to the application.
              result = ACTION_PASS_TO_USER;
              isWakeKey = false;
  
              if (interactive) {
                  // If the screen is awake, but the button pressed was the one that woke the device
                  // then don't pass it to the application
                  if (keyCode == mPendingWakeKey && !down) {
                      result = 0;
                  }
                  // Reset the pending key
                  mPendingWakeKey = PENDING_KEY_NULL;
              }
          } else if (!interactive && shouldDispatchInputWhenNonInteractive(displayId, keyCode)) {
              // If we're currently dozing with the screen on and the keyguard showing, pass the key
              // to the application but preserve its wake key status to make sure we still move
              // from dozing to fully interactive if we would normally go from off to fully
              // interactive.
              result = ACTION_PASS_TO_USER;
              // Since we're dispatching the input, reset the pending key
              mPendingWakeKey = PENDING_KEY_NULL;
          } else {
              // When the screen is off and the key is not injected, determine whether
              // to wake the device but don't pass the key to the application.
              result = 0;
              if (isWakeKey && (!down || !isWakeKeyWhenScreenOff(keyCode))) {
                  isWakeKey = false;
              }
              // Cache the wake key on down event so we can also avoid sending the up event to the app
              if (isWakeKey && down) {
                  mPendingWakeKey = keyCode;
              }
          }
.....
  
          // Handle special keys.
          switch (keyCode) {
              case KeyEvent.KEYCODE_BACK: {
                  if (down) {
                      interceptBackKeyDown();
                  } else {
                      boolean handled = interceptBackKeyUp(event);
  
                      // Don't pass back press to app if we've already handled it via long press
                      if (handled) {
                          result &= ~ACTION_PASS_TO_USER;
                      }
                  }
                  break;
              }
  
              case KeyEvent.KEYCODE_VOLUME_DOWN:
              case KeyEvent.KEYCODE_VOLUME_UP:
              case KeyEvent.KEYCODE_VOLUME_MUTE: {
                  if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                      if (down) {
                          // Any activity on the vol down button stops the ringer toggle shortcut
                          cancelPendingRingerToggleChordAction();
  
                          if (interactive && !mScreenshotChordVolumeDownKeyTriggered
                                  && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
                              mScreenshotChordVolumeDownKeyTriggered = true;
                              mScreenshotChordVolumeDownKeyTime = event.getDownTime();
                              mScreenshotChordVolumeDownKeyConsumed = false;
                              cancelPendingPowerKeyAction();
                              interceptScreenshotChord();
                              interceptAccessibilityShortcutChord();
                          }
                      } else {
                          mScreenshotChordVolumeDownKeyTriggered = false;
                          cancelPendingScreenshotChordAction();
                          cancelPendingAccessibilityShortcutAction();
                      }
                  } else if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                      if (down) {
                          if (interactive && !mA11yShortcutChordVolumeUpKeyTriggered
                                  && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
                              mA11yShortcutChordVolumeUpKeyTriggered = true;
                              mA11yShortcutChordVolumeUpKeyTime = event.getDownTime();
                              mA11yShortcutChordVolumeUpKeyConsumed = false;
                              cancelPendingPowerKeyAction();
                              cancelPendingScreenshotChordAction();
                              cancelPendingRingerToggleChordAction();
  
                              interceptAccessibilityShortcutChord();
                              interceptRingerToggleChord();
                          }
                      } else {
                          mA11yShortcutChordVolumeUpKeyTriggered = false;
                          cancelPendingScreenshotChordAction();
                          cancelPendingAccessibilityShortcutAction();
                          cancelPendingRingerToggleChordAction();
                      }
                  }

 ....
  
              
          return result;
      }
```

在PhoneWindowManager.java中的interceptKeyBeforeQueueing(KeyEvent event, int policyFlags)中在这里负责音量的处理，在keyCode == KeyEvent.KEYCODE\_VOLUME\_UP事件就是关于音量的事件可以根据系统属性值判断是否允许音量键起作用


例如：



```
              case KeyEvent.KEYCODE_VOLUME_DOWN:
              case KeyEvent.KEYCODE_VOLUME_UP:
```

这类在interceptKeyBeforeQueueing的处理音量键的音量加和音量减的处理keycode的相关源码



```
--- a/frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
+++ b/frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
@@ -246,6 +246,13 @@ import java.io.IOException;
 import java.io.PrintWriter;
 import java.util.HashSet;
 import java.util.List;
 

@@ -663,6 +670,7 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
     private static final int MSG_NOTIFY_USER_ACTIVITY = 26;
     private static final int MSG_RINGER_TOGGLE_CHORD = 27;
     private static final int MSG_MOVE_DISPLAY_TO_TOP = 28;
 
     private class PolicyHandler extends Handler {
         @Override
@@ -756,10 +764,53 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
                     mWindowManagerFuncs.moveDisplayToTop(msg.arg1);
                     mMovingDisplayToTopKeyTriggered = false;
                     break;    
         if (count == 2) {
             powerMultiPressAction(eventTime, interactive, mDoublePressOnPowerBehavior);
         } else if (count == 3) {
@@ -1264,6 +1319,11 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
     }
 
     private void powerLongPress() {
         final int behavior = getResolvedLongPressOnPowerBehavior();
         switch (behavior) {
             case LONG_PRESS_POWER_NOTHING:
@@ -2876,12 +2936,23 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
         if (mPendingCapsLockToggle && !KeyEvent.isMetaKey(keyCode) && !KeyEvent.isAltKey(keyCode)) {
             mPendingCapsLockToggle = false;
         }

             DisplayHomeButtonHandler handler = mDisplayHomeButtonHandlers.get(displayId);
             if (handler == null) {
                 handler = new DisplayHomeButtonHandler(displayId);
@@ -2999,6 +3070,11 @@ public class PhoneWindowManager extends AbsPhoneWindowManager implements WindowM
         } else if (keyCode == KeyEvent.KEYCODE_VOLUME_UP
                 || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
                 || keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) {
+                       String aTrue = SystemProperties.get("persist.sys.volumekey.enable", "true");
+                               if(!"true".equals(aTrue)){
+                               return -1;
+                       }
             if (mUseTvRouting || mHandleVolumeKeysInWM) {
                 // On TVs or when the configuration is enabled, volume keys never
                 // go to the foreground app.

public int interceptKeyBeforeQueueing(KeyEvent event, int policyFlags) {
    case KeyEvent.KEYCODE_VOLUME_DOWN:
              case KeyEvent.KEYCODE_VOLUME_UP:
              case KeyEvent.KEYCODE_VOLUME_MUTE: {
+                       String aTrue = SystemProperties.get("persist.sys.volumekey.enable", "true");
+                               if(!"true".equals(aTrue)){
+                               return -1;
+                       }

  
```

通过 PhoneWindowManager.java中的源码发现在powerLongPress()和interceptKeyBeforeQueueing(KeyEvent event, int policyFlags)的两处处理音量键的地方，根据系统属性判断是否执行音量键操作




