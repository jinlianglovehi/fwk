






### １.概述


在１０.０的产品定制化开发过程中，对launcher3进行定制化也是常用的功能，根据产品需求要求 首页Item不能拖动，所以要去掉长按事件然后就不会拖动了


### ２．launcher3 workspace 第一页去掉长按事件的核心类



```
packages/apps/Launcher3/src/com/android/launcher3/WorkspaceLayoutManager.java
packages/apps/Launcher3/src/com/android/launcher3/touch/WorkspaceTouchListener.java

```

### ３.launcher3 workspace 第一页去掉长按事件的核心功能分析和实现


在Ｌａｕｎｃｈｅｒ３中关于对ｗｏｒｋｓｐａｃｅ的屏幕长按事件的处理都是在  
 WorkspaceTouchListener.java中处理的，接下来看下它的源码分析  
 接下来我们来分析源码 而长按事件都是有workspacetouchlistener处理的



```
 @Override
    public boolean onTouch(View view, MotionEvent ev) {
        mGestureDetector.onTouchEvent(ev);

        int action = ev.getActionMasked();
        if (action == ACTION_DOWN) {
            // Check if we can handle long press.
            boolean handleLongPress = canHandleLongPress();

            if (handleLongPress) {
                // Check if the event is not near the edges
                DeviceProfile dp = mLauncher.getDeviceProfile();
                DragLayer dl = mLauncher.getDragLayer();
                Rect insets = dp.getInsets();

                mTempRect.set(insets.left, insets.top, dl.getWidth() - insets.right,
                        dl.getHeight() - insets.bottom);
                mTempRect.inset(dp.edgeMarginPx, dp.edgeMarginPx);
                handleLongPress = mTempRect.contains((int) ev.getX(), (int) ev.getY());
            }

            if (handleLongPress) {
                mLongPressState = STATE_REQUESTED;
                mTouchDownPoint.set(ev.getX(), ev.getY());
            }

            mWorkspace.onTouchEvent(ev);
            // Return true to keep receiving touch events
            return true;
        }

        if (mLongPressState == STATE_PENDING_PARENT_INFORM) {
            // Inform the workspace to cancel touch handling
            ev.setAction(ACTION_CANCEL);
            mWorkspace.onTouchEvent(ev);

            ev.setAction(action);
            mLongPressState = STATE_COMPLETED;
        }

        final boolean result;
        if (mLongPressState == STATE_COMPLETED) {
            // We have handled the touch, so workspace does not need to know anything anymore.
            result = true;
        } else if (mLongPressState == STATE_REQUESTED) {
            mWorkspace.onTouchEvent(ev);
            if (mWorkspace.isHandlingTouch()) {
                cancelLongPress();
            } else if (action == ACTION_MOVE && PointF.length(
                    mTouchDownPoint.x - ev.getX(), mTouchDownPoint.y - ev.getY()) > mTouchSlop) {
                cancelLongPress();
            }

            result = true;
        } else {
            // We don't want to handle touch, let workspace handle it as usual.
            result = false;
        }

        if (action == ACTION_UP || action == ACTION_POINTER_UP) {
            if (!mWorkspace.isHandlingTouch()) {
                final CellLayout currentPage =
                        (CellLayout) mWorkspace.getChildAt(mWorkspace.getCurrentPage());
                if (currentPage != null) {
                    mWorkspace.onWallpaperTap(ev);
                }
            }
        }

        if (action == ACTION_UP || action == ACTION_CANCEL) {
            cancelLongPress();
        }

        return result;
    }

```

在WorkspaceTouchListener.java的事件中  
 onTouch 事件处理所有的按键事件 而canHandleLongPress() 就是处理长按事件的


所以去掉首页长按事件就从canHandleLongPress()来处理就行了  
 修改如下:  
 1.整个workspace 不响应长按事件



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/touch/WorkspaceTouchListener.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/touch/WorkspaceTouchListener.java
@@ -156,7 +156,7 @@ public class WorkspaceTouchListener extends GestureDetector.SimpleOnGestureListe
 
     private boolean canHandleLongPress() {
         return AbstractFloatingView.getTopOpenView(mLauncher) == null
-                && mLauncher.isInState(NORMAL) && !mWorkspace.isPageInTransition();
+                && mLauncher.isInState(NORMAL) && !mWorkspace.isPageInTransition()&&(mWorkspace.getCurrentPage()!=0);
     }

```

而首页的Item的长按事件的处理 也需要去掉，那么就需要看Item的点击事件在哪里了，通过读取源码 得知在 WorkspaceLayoutManager.java 处理 所以就在这里处理就行了  
 修改如下:


2.WorkspaceLayoutManager中的Item 不响应长按事件的处理  
 首先看WorkspaceLayoutManager的源码



```
public interface WorkspaceLayoutManager {
 
     String TAG = "Launcher.Workspace";
 
     // The screen id used for the empty screen always present to the right.
     int EXTRA_EMPTY_SCREEN_ID = -201;
     // The is the first screen. It is always present, even if its empty.
     int FIRST_SCREEN_ID = 0;
 
     /**
      * At bind time, we use the rank (screenId) to compute x and y for hotseat items.
      * See {@link #addInScreen}.
      */
     default void addInScreenFromBind(View child, ItemInfo info) {
         int x = info.cellX;
         int y = info.cellY;
         if (info.container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
             int screenId = info.screenId;
             x = getHotseat().getCellXFromOrder(screenId);
             y = getHotseat().getCellYFromOrder(screenId);
         }
         addInScreen(child, info.container, info.screenId, x, y, info.spanX, info.spanY);
     }
 
     /**
      * Adds the specified child in the specified screen based on the {@param info}
      * See {@link #addInScreen(View, int, int, int, int, int, int)}.
      */
     default void addInScreen(View child, ItemInfo info) {
         addInScreen(child, info.container, info.screenId, info.cellX, info.cellY,
                 info.spanX, info.spanY);
     }
 
     /**
      * Adds the specified child in the specified screen. The position and dimension of
      * the child are defined by x, y, spanX and spanY.
      *
      * @param child The child to add in one of the workspace's screens.
 \* @param screenId The screen in which to add the child.
 \* @param x The X position of the child in the screen's grid.
      * @param y The Y position of the child in the screen's grid.
      * @param spanX The number of cells spanned horizontally by the child.
      * @param spanY The number of cells spanned vertically by the child.
      */
     default void addInScreen(View child, int container, int screenId, int x, int y,
             int spanX, int spanY) {
         if (container == LauncherSettings.Favorites.CONTAINER_DESKTOP) {
             if (getScreenWithId(screenId) == null) {
                 Log.e(TAG, "Skipping child, screenId " + screenId + " not found");
                 // DEBUGGING - Print out the stack trace to see where we are adding from
                 new Throwable().printStackTrace();
                 return;
             }
         }
         if (screenId == EXTRA_EMPTY_SCREEN_ID) {
             // This should never happen
             throw new RuntimeException("Screen id should not be EXTRA\_EMPTY\_SCREEN\_ID");
         }
 
         final CellLayout layout;
         if (container == LauncherSettings.Favorites.CONTAINER_HOTSEAT) {
             layout = getHotseat();
 
             // Hide folder title in the hotseat
             if (child instanceof FolderIcon) {
                 ((FolderIcon) child).setTextVisible(false);
 }
 } else {
 // Show folder title if not in the hotseat
 if (child instanceof FolderIcon) {
 ((FolderIcon) child).setTextVisible(true);
 }
 layout = getScreenWithId(screenId);
 }
 
 ViewGroup.LayoutParams genericLp = child.getLayoutParams();
 CellLayout.LayoutParams lp;
 if (genericLp == null || !(genericLp instanceof CellLayout.LayoutParams)) {
              lp = new CellLayout.LayoutParams(x, y, spanX, spanY);
          } else {
              lp = (CellLayout.LayoutParams) genericLp;
              lp.cellX = x;
              lp.cellY = y;
              lp.cellHSpan = spanX;
              lp.cellVSpan = spanY;
          }
  
          if (spanX < 0 && spanY < 0) {
              lp.isLockedToGrid = false;
          }
  
          // Get the canonical child id to uniquely represent this view in this screen
          ItemInfo info = (ItemInfo) child.getTag();
          int childId = info.getViewId();
  
          boolean markCellsAsOccupied = !(child instanceof Folder);
          if (!layout.addViewToCellLayout(child, -1, childId, lp, markCellsAsOccupied)) {
              // TODO: This branch occurs when the workspace is adding views
              // outside of the defined grid
              // maybe we should be deleting these items from the LauncherModel?
              Log.e(TAG, "Failed to add to item at (" + lp.cellX + "," + lp.cellY + ") to CellLayout");
          }
  
          child.setHapticFeedbackEnabled(false);
          child.setOnLongClickListener(ItemLongClickListener.INSTANCE_WORKSPACE);
          if (child instanceof DropTarget) {
              onAddDropTarget((DropTarget) child);
          }
      }
  
      Hotseat getHotseat();
  
      CellLayout getScreenWithId(int screenId);
  
      default void onAddDropTarget(DropTarget target) { }
  }

```

在WorkspaceLayoutManager中的addInScreen负责绑定每一屏的ｉｔｅｍ数据  
 所以在给每一个ｉｔｅｍ绑定数据的同时也设置了长按事件，所以可以从这里去掉长按事件



```
--- a/packages/apps/Launcher3/src/com/android/launcher3/WorkspaceLayoutManager.java
+++ b/packages/apps/Launcher3/src/com/android/launcher3/WorkspaceLayoutManager.java
@@ -127,7 +127,9 @@ public interface WorkspaceLayoutManager {
         }
 
         child.setHapticFeedbackEnabled(false);
-        child.setOnLongClickListener(ItemLongClickListener.INSTANCE_WORKSPACE);
+               if(screenId > 0){
+                       child.setOnLongClickListener(ItemLongClickListener.INSTANCE_WORKSPACE);
+               }
         if (child instanceof DropTarget) {
             onAddDropTarget((DropTarget) child);
         }

```

在设置长按事件时判断当前屏幕不等于０就是第一屏就可以了





