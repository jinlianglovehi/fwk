






概述  
 说道Launcher，想必大家也都不陌生，很多人感觉很深奥的一个东西，其实他就是一个，launcher其实就是一个app，从功能上说，是对手机上其他app的一个管理和启动，从代码上说比其他app多了一个属性，就是在AndroidManifest.xml文件中多了一个“”属性 和，考虑的方面比较多，逻辑处理和代码规范性比较强，安卓各方面知识的应用比较多。如果系统只安装了一个launcher，就会直接开启此launcher，如果装有多个Launcher，运行的时候会弹出对话框供我们选择。接下来我们就一步步来进行研究吧。


桌面结构  
 我们来看一下桌面结构图  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20191128090350837.png)


最外层，也就是手机显示层是一个叫做Workspace的控件。  
 其实在Workspace外层还有一个DragLayer层。  
 searchDropTargetView为顶部搜索栏。  
 CellLayout为中间主题屏幕，有一个或者多个，主要用来装快捷方式或者一些小部件，（负一屏一般是一个独立的View，不是CellLayout）。  
 中间的知识点叫做PageIndicator，用来指示当前处在哪个CellLayout。  
 Hotseat是底部的四个小图标主要放电话，短信等常用应用图标。左右滑动屏幕时，Hotseat不做滑动处理。


具体的框架图就是这样的  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20191128090425131.png)


当用户长安桌面时，中间的CellLayout会缩小，下面的Hotseat，pageIndicator和上面的搜索栏SearchDropTargetView会隐藏，显示出隐藏的三个菜单按钮（壁纸，小部件，设置 即：WALLPAPERS,WIDGETS,SETTINGS）此布局叫做Overviewpanel。三个菜单按钮点进去都有一个View。


![在这里插入图片描述](https://img-blog.csdnimg.cn/20191128090443626.png)


这就是桌面的基本结构，接下来会讲解Launcher的启动过程，数据的绑定，拖拽，等等的一些源码知识。





