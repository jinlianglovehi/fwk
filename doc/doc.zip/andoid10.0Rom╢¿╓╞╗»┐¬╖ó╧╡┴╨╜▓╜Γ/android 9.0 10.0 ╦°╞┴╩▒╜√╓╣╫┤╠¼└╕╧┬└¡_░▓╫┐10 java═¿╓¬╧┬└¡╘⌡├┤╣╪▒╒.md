






定制化开发中，锁屏时禁止状态栏下拉的需求，这时要从SystemUI锁屏页分析源码  
 1.状态栏的下拉事件处理  
 2.状态栏下滑事件处理


第一步:  
 状态栏栏下滑事件处理：


通知栏下滑事件  
 先看 NotificationStackScrollLayout.java的源码



```
  @ShadeViewRefactor(RefactorComponent.INPUT)
    private final DragDownCallback mDragDownCallback = new DragDownCallback() {

        /* Only ever called as a consequence of a lockscreen expansion gesture. */
        @Override
        public boolean onDraggedDown(View startingChild, int dragLengthY) {
            if (mStatusBarState == StatusBarState.KEYGUARD
                    && hasActiveNotifications()) {
                mLockscreenGestureLogger.write(
                        MetricsEvent.ACTION_LS_SHADE,
                        (int) (dragLengthY / mDisplayMetrics.density),
                        0 /* velocityDp - N/A */);

                if (!mAmbientState.isDark() || startingChild != null) {
                    // We have notifications, go to locked shade.
                    mShadeController.goToLockedShade(startingChild);
                    if (startingChild instanceof ExpandableNotificationRow) {
                        ExpandableNotificationRow row = (ExpandableNotificationRow) startingChild;
                        row.onExpandedByGesture(true /* drag down is always an open */);
                    }
                }

                return true;
            } else {
                // abort gesture.
                return false;
            }
        }

        @Override
        public void onDragDownReset() {
            setDimmed(true /* dimmed */, true /* animated */);
            resetScrollPosition();
            resetCheckSnoozeLeavebehind();
        }

        @Override
        public void onCrossedThreshold(boolean above) {
            setDimmed(!above /* dimmed */, true /* animate */);
        }

        @Override
        public void onTouchSlopExceeded() {
            cancelLongPress();
            checkSnoozeLeavebehind();
        }

        @Override
        public void setEmptyDragAmount(float amount) {
            mNotificationPanel.setEmptyDragAmount(amount);
        }

        @Override
        public boolean isFalsingCheckNeeded() {
            return mStatusBarState == StatusBarState.KEYGUARD;
        }
    };

```


```
可以看出 下滑callback事件就是在这里处理的

```

1.NotificationStackScrollLayout.java的修改  
 下拉事件就是在这里处理的



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/notification/stack/NotificationStackScrollLayout.java
@@ -6405,6 +6405,9 @@ public class NotificationStackScrollLayout extends ViewGroup implements ScrollAd
         /* Only ever called as a consequence of a lockscreen expansion gesture. */
         @Override
         public boolean onDraggedDown(View startingChild, int dragLengthY) {
+                       if (mStatusBarState == StatusBarState.KEYGUARD) {
+                return false;
+            }
             if (mStatusBarState == StatusBarState.KEYGUARD
                     && hasActiveNotifications()) {
                 mLockscreenGestureLogger.write(

```

状态栏下拉事件处理：


2.PhoneStatusBarView.java的修改


PhoneStatusBarView的 onTouchEvent触摸事件处理



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/PhoneStatusBarView.java
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean barConsumedEvent = mBar.interceptTouchEvent(event);

        if (DEBUG_GESTURES) {
            if (event.getActionMasked() != MotionEvent.ACTION_MOVE) {
                EventLog.writeEvent(EventLogTags.SYSUI_PANELBAR_TOUCH,
                        event.getActionMasked(), (int) event.getX(), (int) event.getY(),
                        barConsumedEvent ? 1 : 0);
            }
        }
        // return barConsumedEvent || super.onTouchEvent(event);
        //在这里直接return true;屏蔽所有事件
         return true;
    }

```

3.KeyguardViewMediator.java的修改


对下拉StatusBarManager下拉属性设置为禁止下拉



```
frameworks/base/packages/SystemUI/src/com/android/systemui/keyguard/KeyguardViewMediator.java

@@ -2179,7 +2179,7 @@ public class KeyguardViewMediator extends SystemUI {
                         + " isSecure=" + isSecure() + " force=" + forceHideHomeRecentsButtons
                         +  " --> flags=0x" + Integer.toHexString(flags));
             }
-
+            flags = StatusBarManager.DISABLE_EXPAND;//禁止状态栏下拉
             mStatusBarManager.disable(flags);
         }
     }

```




