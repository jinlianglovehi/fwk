



## 1.前言


在10.0的系统产品开发中，在产品关机的情况下，长按power电源键和音量减的情况下，会在开机过程中然后进入recovery流程中， 在产品开发需要的情况下，要求去掉power电源键和音量减键组合键操作，所以就需要从kernel中来分析下power电源键和音量减的相关操作 的相关源码来分析下实现相关的功能


## 2.展讯平台去掉长按power电源键+音量减进入recovery模式的核心类



```
bsp\bootloader\u-boot15\common\cmd_cboot.c
bsp\bootloader\u-boot15\board\spreadtrum\ums512_1h10\sprd_kp.c
```

## 3.展讯平台去掉长按power电源键+音量减进入recovery模式的核心功能分析和实现


在整个系统开机流程中，首选会从u\_boot开始启动，我们从U-boot在上电后被SPL从NAND中拷贝至SDRAM, 然后执行board\_init\_f 跳转到board\_init\_r开始。 接下来就会启动cmd\_cboot.c中的相关关于开机流程的 核心代码流程，会在这里判断当前的系统启动模式，android的启动模式会在u-boot中进行判断和处理 然后进入不同的启动模式中，接下来具体分析下相关的流程


## 3.1 cmd\_cboot.c关于启动模式的相关判断


在展讯平台去掉长按power电源键+音量减进入recovery模式的核心功能的实现中，在通过上述的开机流程的简单分析， 得知在cmd\_cboot.c中的相关源码分析得知，这里会根据当前的启动模式，来进入相关的系统模式， 接下来分析下相关功能



```
int boot_pwr_check(void)
{
    static int total_cnt = 0;

    if (!power_button_pressed())
        total_cnt ++;
    return total_cnt;
}

boot_mode_enum_type get_mode_from_arg(char* mode_name)
{

    debugf("cboot:get mode from argument:%s\n",mode_name);
    if(!strcmp(mode_name,"normal"))
        return CMD_NORMAL_MODE;

    if(!strcmp(mode_name,"recovery"))
        return CMD_RECOVERY_MODE;

    if(!strcmp(mode_name,"fastboot"))
        return CMD_FASTBOOT_MODE;

    if(!strcmp(mode_name,"charge"))
        return CMD_CHARGE_MODE;

    if(!strcmp(mode_name,"sprdisk"))
        return CMD_SPRDISK_MODE;

    /*just for debug*/
#ifdef CONFIG_SPRD_SYSDUMP
    if(!strcmp(mode_name,"sysdump"))
        write_sysdump_before_boot(CMD_UNKNOW_REBOOT_MODE);
#endif
    return CMD_UNDEFINED_MODE;

}


unsigned reboot_mode_check(void)
{
      static unsigned rst_mode = 0;
       static unsigned check_times = 0;
       if(!check_times)
      {
          rst_mode = check_reboot_mode();
          check_times++;
      }
      debugf("reboot_mode_check rst_mode=0x%x\n",rst_mode);
      return rst_mode;
  }


  // 0 get mode from pc tool
boot_mode_enum_type get_mode_from_pctool(void)
{
    int ret = pctool_mode_detect();
    if (ret < 0)
        return CMD_UNDEFINED_MODE;
    else
        return ret;
}

boot_mode_enum_type get_mode_from_bat_low(void)
{
#ifndef CONFIG_FPGA       //jump loop
    while(is_bat_low()) {
#ifdef CONFIG_TARGET_SP9853I_10C10
      if(1) {
#else
      if(charger_connected()) {
#endif
          debugf("cboot:low battery,charging...\n");
          sprdbat_show_chglogo();
          sprdbat_lowbat_chg();
          mdelay(SPRDBAT_CHG_POLLING_T);
      }else{
          debugf("cboot:low battery and shutdown\n");
           sprdbat_show_lowlogo(); 
           mdelay(3000);
          return CMD_POWER_DOWN_DEVICE;
      }
    }
#endif
    sprdbat_chg_led(0);
    return CMD_UNDEFINED_MODE;
}
```

在展讯平台去掉长按power电源键+音量减进入recovery模式的核心功能的实现中，在通过上述的开机流程的简单分析， 得知在cmd\_cboot.c中的相关源码分析得知，boot\_pwr\_check(void)是具体判断当前电源键按键长按的时间多久， 而在reboot\_mode\_check(void)判断是否是重启模式，而在get\_mode\_from\_bat\_low(void)判断在低电量模式下 如果是插电源的情况下 就进入充电模式，而如果没充电，就进入关机状态，



```
// 3 get mode from alarm register
boot_mode_enum_type  get_mode_from_alarm_register(void)
{
    int flag;

    if (alarm_triggered() && (flag = alarm_flag_check())) {
        debugf("get_mode_from_alarm_register flag=%d\n", flag);
        if (flag == 1) {
            return CMD_ALARM_MODE;
        }
        else if (flag == 2) {
            return CMD_NORMAL_MODE;
        }
    } else {
        return CMD_UNDEFINED_MODE;
    }
}

/* 4 get mode from charger*/
boot_mode_enum_type  get_mode_from_charger(void)
{
    if (charger_connected()) {
        debugf("get mode from charger\n");
        sprdbat_show_chglogo();
        return CMD_CHARGE_MODE;
    } else {
        return CMD_UNDEFINED_MODE;
    }
}

/*5 get mode from keypad*/
boot_mode_enum_type  get_mode_from_keypad(void)
{
    uint32_t key_mode = 0;
    uint32_t key_code = 0;
    volatile int i;
    if (boot_pwr_check() >= PWR_KEY_DETECT_CNT) {
        mdelay(50);
        for (i = 0; i < 10; i++) {
            key_code = board_key_scan();
            if(key_code != KEY_RESERVED)
              break;
        }
        key_mode = check_key_boot(key_code);
        debugf("cboot:get mode from keypad:0x%x\n",key_code);
        switch(key_mode) {
          case CMD_FASTBOOT_MODE:
              return  CMD_FASTBOOT_MODE;
          case CMD_RECOVERY_MODE:
              return CMD_RECOVERY_MODE;
          case CMD_FACTORYTEST_MODE:
              return CMD_FACTORYTEST_MODE;
          default:
              return CMD_NORMAL_MODE;
        }
    }else {
        return CMD_UNDEFINED_MODE;
    }
}
```

在展讯平台去掉长按power电源键+音量减进入recovery模式的核心功能的实现中，在通过上述的开机流程的简单分析， 得知在cmd\_cboot.c中的相关源码分析得知，在上述的源码中，在get\_mode\_from\_alarm\_register(void) 来判断当前会不会进入警报模式，在get\_mode\_from\_charger(void)中判断当前是否是充电模式，而在 get\_mode\_from\_keypad(void)就是判断当前是否是物理按键的处理流程，在这里就会判断power电源键 是否是长按状态，在boot\_pwr\_check() >= PWR\_KEY\_DETECT\_CNT就是判断长按power电源键的时间 是否超过了PWR\_KEY\_DETECT\_CNT的时间，就是2秒钟，如果超过2秒 就会接着判断，是否同时按下 音量+和音量-等按键，然后进入对应的开机模式，在 check\_key\_boot(key\_code);中来判断当前除了 电源键之外还有哪个按键形成组合键，进入对应的启动模式，在上述的sprd\_kp.c中的check\_key\_boot(key\_code); 对按键做了启动模式的区别



```
unsigned int check_key_boot(unsigned char key)
{
    if(KEY_VOLUMEUP == key)
      return CMD_FACTORYTEST_MODE;
    else if(KEY_HOME == key)
      return CMD_FASTBOOT_MODE;
    else if(KEY_VOLUMEDOWN== key)
      return CMD_RECOVERY_MODE;
    else
      return 0;
}
```

通过上述的sprd\_kp.c中的check\_key\_boot(key\_code);的代码可以看出，在音量减的组合键 返回的就是 CMD\_RECOVERY\_MODE恢复出厂设置模式，就是说在开机过程中长按power电源键和音量减键组合就是 恢复出厂设置，所以可以做以下的修改 禁用恢复出厂设置模式



```
        switch(key_mode) {
          case CMD_FASTBOOT_MODE:
              return  CMD_FASTBOOT_MODE;
          case CMD_RECOVERY_MODE:
            -  return CMD_RECOVERY_MODE;
                                    + return CMD_NORMAL_MODE;
          case CMD_FACTORYTEST_MODE:
              return CMD_FACTORYTEST_MODE;
          default:
              return CMD_NORMAL_MODE;
        }
```

展讯平台去掉长按power电源键+音量减进入recovery模式的功能实现中，通过上述的分析，最终需要在 CMD\_RECOVERY\_MODE这个recovery模式，换成CMD\_NORMAL\_MODE正常启动模式就可以实现 当前的功能



