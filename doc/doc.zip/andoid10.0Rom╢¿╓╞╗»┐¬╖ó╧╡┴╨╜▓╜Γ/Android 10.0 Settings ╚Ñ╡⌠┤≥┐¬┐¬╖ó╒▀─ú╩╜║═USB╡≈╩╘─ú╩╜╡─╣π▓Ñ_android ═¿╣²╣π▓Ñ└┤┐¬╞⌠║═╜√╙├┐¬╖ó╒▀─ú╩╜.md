



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2. Settings 去掉打开开发者模式和USB调试模式的广播相关核心代码](#2.%20Settings%20%E5%8E%BB%E6%8E%89%E6%89%93%E5%BC%80%E5%BC%80%E5%8F%91%E8%80%85%E6%A8%A1%E5%BC%8F%E5%92%8CUSB%E8%B0%83%E8%AF%95%E6%A8%A1%E5%BC%8F%E7%9A%84%E5%B9%BF%E6%92%AD%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3. Settings 去掉打开开发者模式和USB调试模式的广播相关核心代码功能分析](#3.%20Settings%20%E5%8E%BB%E6%8E%89%E6%89%93%E5%BC%80%E5%BC%80%E5%8F%91%E8%80%85%E6%A8%A1%E5%BC%8F%E5%92%8CUSB%E8%B0%83%E8%AF%95%E6%A8%A1%E5%BC%8F%E7%9A%84%E5%B9%BF%E6%92%AD%E7%9B%B8%E5%85%B3%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.1 DevelopmentSettingsDashboardFragment.java关于开发者模式的相关功能分析](#%C2%A0%203.1%20DevelopmentSettingsDashboardFragment.java%E5%85%B3%E4%BA%8E%E5%BC%80%E5%8F%91%E8%80%85%E6%A8%A1%E5%BC%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.2 DevelopmentSettingsEnabler设置开发者模式的相关代码](#3.2%20DevelopmentSettingsEnabler%E8%AE%BE%E7%BD%AE%E5%BC%80%E5%8F%91%E8%80%85%E6%A8%A1%E5%BC%8F%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)


[3.3 AdbPreferenceController关于usb调试模式的代码](#3.3%20AdbPreferenceController%E5%85%B3%E4%BA%8Eusb%E8%B0%83%E8%AF%95%E6%A8%A1%E5%BC%8F%E7%9A%84%E4%BB%A3%E7%A0%81)


[3.4 AbstractEnableAdbPreferenceController相关代码](#3.4%20AbstractEnableAdbPreferenceController%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81)




---



## 1.概述


  在系统Settings的开发者模式中，打开开发者模式和usb调试模式都会发出开发者模式改变广播和usb调试模式改变广播，项目开发功能需要要求去掉这两个广播以免影响其他功能，所以就要看哪里发出广播来屏蔽掉就可以了


## 2. Settings 去掉打开开发者模式和USB调试模式的广播相关核心代码



```
  packages\apps\Settings\res\xml\development_settings.xml
   packages\apps\Settings\src\com\android\settings\development\DevelopmentSettingsDashboardFragment.java
   frameworks\base\packages\SettingsLib\src\com\android\settingslib\development\DevelopmentSettingsEnabler.java
   frameworks\base\packages\SettingsLib\src\com\android\settingslib\development\AbstractEnableAdbPreferenceController.java
```

## 3. Settings 去掉打开开发者模式和USB调试模式的广播相关核心代码功能分析


##   3.1 DevelopmentSettingsDashboardFragment.java关于开发者模式的相关功能分析



```
   public class DevelopmentSettingsDashboardFragment extends RestrictedDashboardFragment
        implements SwitchBar.OnSwitchChangeListener, OemUnlockDialogHost, AdbDialogHost,
        AdbClearKeysDialogHost, LogPersistDialogHost,
        BluetoothA2dpHwOffloadRebootDialog.OnA2dpHwDialogConfirmedListener {

    private static final String TAG = "DevSettingsDashboard";

    private final BluetoothA2dpConfigStore mBluetoothA2dpConfigStore =
            new BluetoothA2dpConfigStore();

    private boolean mIsAvailable = true;
    private SwitchBar mSwitchBar;
    private DevelopmentSwitchBarController mSwitchBarController;
    private List<AbstractPreferenceController> mPreferenceControllers = new ArrayList<>();
    private BluetoothA2dp mBluetoothA2dp;

    private final BroadcastReceiver mEnableAdbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            for (AbstractPreferenceController controller : mPreferenceControllers) {
                if (controller instanceof AdbOnChangeListener) {
                    ((AdbOnChangeListener) controller).onAdbSettingChanged();
                }
            }
        }
    };

......

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        registerReceivers();

        final BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter != null) {
            adapter.getProfileProxy(getActivity(), mBluetoothA2dpServiceListener,
                    BluetoothProfile.A2DP);
        }
        return super.onCreateView(inflater, container, savedInstanceState);
    }
private void enableDeveloperOptions() {
        if (Utils.isMonkeyRunning()) {
            return;
        }
        DevelopmentSettingsEnabler.setDevelopmentSettingsEnabled(getContext(), true);
        for (AbstractPreferenceController controller : mPreferenceControllers) {
            if (controller instanceof DeveloperOptionsPreferenceController) {
                ((DeveloperOptionsPreferenceController) controller).onDeveloperOptionsEnabled();
            }
        }
    }

    private void disableDeveloperOptions() {
        if (Utils.isMonkeyRunning()) {
            return;
        }
        DevelopmentSettingsEnabler.setDevelopmentSettingsEnabled(getContext(), false);
        final SystemPropPoker poker = SystemPropPoker.getInstance();
        poker.blockPokes();
        for (AbstractPreferenceController controller : mPreferenceControllers) {
            if (controller instanceof DeveloperOptionsPreferenceController) {
                ((DeveloperOptionsPreferenceController) controller)
                        .onDeveloperOptionsDisabled();
            }
        }
        poker.unblockPokes();
        poker.poke();
    }
}
```

enableDeveloperOptions()和disableDeveloperOptions()就是开启和关闭开发者模式执行的代码  
 通过DevelopmentSettingsEnabler.setDevelopmentSettingsEnabled(）设置功能  
 而AdbPreferenceController就是usb调试模式的管理类


## 3.2 DevelopmentSettingsEnabler设置开发者模式的相关代码



```
    public class DevelopmentSettingsEnabler {

    public static final String DEVELOPMENT_SETTINGS_CHANGED_ACTION =
            "com.android.settingslib.development.DevelopmentSettingsEnabler.SETTINGS_CHANGED";

    private DevelopmentSettingsEnabler() {
    }

    public static void setDevelopmentSettingsEnabled(Context context, boolean enable) {
        Settings.Global.putInt(context.getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, enable ? 1 : 0);
       // 发送开发者模式改变广播 所以注释掉就可以了
        /*LocalBroadcastManager.getInstance(context)
                .sendBroadcast(new Intent(DEVELOPMENT_SETTINGS_CHANGED_ACTION));*/
    }

    public static boolean isDevelopmentSettingsEnabled(Context context) {
        final UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
        final boolean settingEnabled = Settings.Global.getInt(context.getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                Build.TYPE.equals("eng") ? 1 : 0) != 0;
        final boolean hasRestriction = um.hasUserRestriction(
                UserManager.DISALLOW_DEBUGGING_FEATURES);
        final boolean isAdmin = um.isAdminUser();
        Log.d("DevelopmentSettingsEnabler", "settingEnabled : " + settingEnabled + " hasRestriction : " + hasRestriction);
        return isAdmin && !hasRestriction && settingEnabled;
    }
}
```

在DevelopmentSettingsEnabler.java中的setDevelopmentSettingsEnabled(Context context, boolean enable)的来启动开发者模式的时候，通过LocalBroadcastManager.getInstance(context)  
                 .sendBroadcast(new Intent(DEVELOPMENT\_SETTINGS\_CHANGED\_ACTION));


来发送开发者模式的广播，所以可以注释掉这部分的发送广播


## 3.3 AdbPreferenceController关于usb调试模式的代码



```
  public class AdbPreferenceController extends AbstractEnableAdbPreferenceController implements
        PreferenceControllerMixin {

    private final DevelopmentSettingsDashboardFragment mFragment;

    public AdbPreferenceController(Context context, DevelopmentSettingsDashboardFragment fragment) {
        super(context);
        mFragment = fragment;
    }

    public void onAdbDialogConfirmed() {
        writeAdbSetting(true);
    }

    public void onAdbDialogDismissed() {
        updateState(mPreference);
    }

    @Override
    public void showConfirmationDialog(@Nullable Preference preference) {
        EnableAdbWarningDialog.show(mFragment);
    }

    @Override
    public void dismissConfirmationDialog() {
        // intentional no-op
    }

    @Override
    public boolean isConfirmationDialogShowing() {
        // intentional no-op
        return false;
    }

    @Override
    protected void onDeveloperOptionsSwitchDisabled() {
        super.onDeveloperOptionsSwitchDisabled();
        writeAdbSetting(false);
        mPreference.setChecked(false);
    }
}
```

在AdbPreferenceController.java中的上述代码中发现在onDeveloperOptionsSwitchDisabled()


中就是处理开启关闭开发者模式的switch开关的相关代码


## 3.4 AbstractEnableAdbPreferenceController相关代码



```
   public abstract class AbstractEnableAdbPreferenceController extends
        DeveloperOptionsPreferenceController implements ConfirmationDialogController {
    private static final String KEY_ENABLE_ADB = "enable_adb";
    public static final String ACTION_ENABLE_ADB_STATE_CHANGED =
            "com.android.settingslib.development.AbstractEnableAdbController."
                    + "ENABLE_ADB_STATE_CHANGED";

    public static final int ADB_SETTING_ON = 1;
    public static final int ADB_SETTING_OFF = 0;


    protected SwitchPreference mPreference;

    public AbstractEnableAdbPreferenceController(Context context) {
        super(context);
    }

    @Override
    public void displayPreference(PreferenceScreen screen) {
        super.displayPreference(screen);
        if (isAvailable()) {
            mPreference = (SwitchPreference) screen.findPreference(KEY_ENABLE_ADB);
        }
    }

    @Override
    public boolean isAvailable() {
        return mContext.getSystemService(UserManager.class).isAdminUser();
    }

    @Override
    public String getPreferenceKey() {
        return KEY_ENABLE_ADB;
    }

    private boolean isAdbEnabled() {
        final ContentResolver cr = mContext.getContentResolver();
        return Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, ADB_SETTING_OFF)
                != ADB_SETTING_OFF;
    }

    @Override
    public void updateState(Preference preference) {
        ((TwoStatePreference) preference).setChecked(isAdbEnabled());
    }

    public void enablePreference(boolean enabled) {
        if (isAvailable()) {
            mPreference.setEnabled(enabled);
        }
    }

....


    // 执行usb调试模式开关代码
    @Override
    public boolean handlePreferenceTreeClick(Preference preference) {
        if (isUserAMonkey()) {
            return false;
        }

        if (TextUtils.equals(KEY_ENABLE_ADB, preference.getKey())) {
            if (!isAdbEnabled()) {
                showConfirmationDialog(preference);
            } else {
                writeAdbSetting(false);
            }
            return true;
        } else {
            return false;
        }
    }

    protected void writeAdbSetting(boolean enabled) {
        Settings.Global.putInt(mContext.getContentResolver(),
                Settings.Global.ADB_ENABLED, enabled ? ADB_SETTING_ON : ADB_SETTING_OFF);
        notifyStateChanged();
    }

    private void notifyStateChanged() {
        // 发送usb调试模式改变代码 所以注释掉就可以了
        /*LocalBroadcastManager.getInstance(mContext)
                .sendBroadcast(new Intent(ACTION_ENABLE_ADB_STATE_CHANGED));*/
    }

    @VisibleForTesting
    boolean isUserAMonkey() {
        return ActivityManager.isUserAMonkey();
    }
```

在AbstractEnableAdbPreferenceController.java中的writeAdbSetting(boolean enabled)是打开关闭adb的时候，设置Settings.Global.ADB\_ENABLED的系统属性值，而在notifyStateChanged()更新


adb状态时，发送adb改变的广播，所以需要在notifyStateChanged()中注释掉发送的广播



