



在定制化开发中，设置wifi白名单和wifi黑名单这样的需求也是常见的，那么怎么设置呢，首先从WifiManager.java来跟wifi搜索流程 解决问题 首先看wifiManager.java代码


addNetwork(WifiConfiguration config) 添加一个config描述的WIFI网络，默认情况下，这个WIFI网络是DISABLE状态的。  
 calculateSignalLevel(int rssi , int numLevels) 计算信号的等级  
 compareSignalLevel(int rssiA, int rssiB) 对比网络A和网络B的信号强度  
 createWifiLock(int lockType, String tag) 创建一个WIFI 锁，锁定当前的WIFI连接  
 disableNetwork(int netId) 让一个网络连接失效  
 disconnect() 断开当前的WIFI连接  
 enableNetwork(int netId, Boolean disableOthers) 连接netId所指的WIFI网络，并是其他的网络都被禁用  
 getConfiguredNetworks() 获取网络连接的状态  
 getConnectionInfo() 获取当前连接的信息  
 getDhcpInfo() 获取DHCP 的信息  
 getScanResulats() 获取扫描测试的结果  
 getWifiState() 获取当前WIFI设备的状态  
 isWifiEnabled() 判断WIFI设备是否打开  
 pingSupplicant() ping操作，和PC的ping操作相同作用  
 ressociate() 重新连接WIFI网络，即使该网络是已经被连接上的  
 reconnect() 重新连接一个未连接上的WIFI网络  
 removeNetwork() 移除某一个网络  
 saveConfiguration() 保留一个配置信息  
 setWifiEnabled() 让一个连接有效  
 startScan() 开始扫描  
 updateNetwork(WifiConfiguration config) 更新一个网络连接  
 2.常用的wifi状态  
 WIFI\_STATE\_DISABLED WIFI网卡不可用   
 WIFI\_STATE\_DISABLING WIFI网卡正在关闭   
 WIFI\_STATE\_ENABLED WIFI网卡可用   
 WIFI\_STATE\_ENABLING WIFI网卡正在打开   
 WIFI\_STATE\_UNKNOWN WIFI网卡状态不可知  
 3.列表查看有连接信号的wifi热点  
 ScanResult对象就是用来表示附近wifi热点的属性的，可以通过WifiManager.getScanResults()返回一个ScanResult列表，后面我附上查看附近wifi热点的demo，ScanResult的重要属性有一下几个：  
 BSSID 接入点的地址  
 SSID 网络的名字，唯一区别WIFI网络的名字  
 Capabilities 网络接入的性能  
 Frequency 当前WIFI设备附近热点的频率(MHz)  
 Level 所发现的WIFI网络信号强度  
 4.连接wifi热点  
 通过WifiManager.getConfiguredNetworks()方法会返回WifiConfiguration对象的列表，然后再调用WifiManager.enableNetwork();方法就可以连接上指定的热点。  
 5.查看已经连接上的wifi信息  
 WifiInfo是专门用来表示连接的对象，这个对象可以通过WifiManager.getConnectionInfo()来获取。WifiInfo中包含了当前连接中的相关信息。  
    
 getBSSID() 获取BSSID属性  
 getDetailedStateOf() 获取客户端的连通性  
 getHiddenSSID() 获取SSID 是否被隐藏  
 getIpAddress() 获取IP 地址  
 getLinkSpeed() 获取连接的速度  
 getMacAddress() 获取Mac 地址  
 getRssi() 获取802.11n 网络的信号  
 getSSID() 获取SSID  
 getSupplicanState() 获取具体客户端状态的信息


从以上方法可以看出 WifiManager.getScanResults() 来获取wifi列表


而wifimanager是通过 wifiservice 来进行通讯的


所以我们来看 wifiservice 而它是在


SystemServer.java 中启动的 ，而 WifiService在构造方法中新建了一个WifiServiceImpl实例，它是Wifi管理服务真正的实现者


所以解决方案就是在 WifiServiceImpl中的 getScanResults（）中返回白名单里的ssid  
  



```
 /**
     * Return the results of the most recent access point scan, in the form of
     * a list of {@link ScanResult} objects.
     * @return the list of results
     */
    @Override
    public List<ScanResult> getScanResults(String callingPackage) {
        enforceAccessPermission();
        int uid = Binder.getCallingUid();
        long ident = Binder.clearCallingIdentity();
        if (mVerboseLoggingEnabled) {
            mLog.info("getScanResults uid=%").c(uid).flush();
        }
        try {
            mWifiPermissionsUtil.enforceCanAccessScanResults(callingPackage, uid);
            final List<ScanResult> scanResults = new ArrayList<>();
            boolean success = mWifiInjector.getClientModeImplHandler().runWithScissors(() -> {
                scanResults.addAll(mScanRequestProxy.getScanResults());
            }, RUN_WITH_SCISSORS_TIMEOUT_MILLIS);
            if (!success) {
                Log.e(TAG, "Failed to post runnable to fetch scan results");
                return new ArrayList<ScanResult>();
            }
            return scanResults;
        } catch (SecurityException e) {
            Slog.e(TAG, "Permission violation - getScanResults not allowed for uid="
                    + uid + ", packageName=" + callingPackage + ", reason=" + e);
            return new ArrayList<ScanResult>();
        } finally {
            Binder.restoreCallingIdentity(ident);
        }
    }
```

具体实现步骤如下:


1. IWifiManager.aidi增加白名单接口



```
--- a/frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
+++ b/frameworks/base/wifi/java/android/net/wifi/IWifiManager.aidl
@@ -262,4 +262,7 @@ interface IWifiManager
     boolean registerWifiRssiLinkSpeedAndFrequencyObserver(IWifiRssiLinkSpeedAndFrequencyObserver observer);
     boolean unregisterWifiRssiLinkSpeedAndFrequencyObserver(IWifiRssiLinkSpeedAndFrequencyObserver observer);
     //<-- Add for Wifi Rssi LinkSpeed And Frequency Observer
+       void setWiFiWhiteList(in List<String> blackList);
+       List<String> getWiFiWhiteList();
 }

```

2. WifiManager.java增加白名单接口



```
diff --git a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
index a55dbde9c0..4bdc586e9b 100755
--- a/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
+++ b/frameworks/base/wifi/java/android/net/wifi/WifiManager.java
@@ -1764,7 +1764,28 @@ public class WifiManager {
             throw e.rethrowFromSystemServer();
         }
     }
+       public void setWiFiWhiteList(List<String> blackList){
+               try {
+            mService.setWiFiWhiteList(blackList); 
+        } catch (RemoteException e) {
+            throw e.rethrowFromSystemServer();
+        }
+    }
 
+    public List<String> getWiFiWhiteList(){
+               try {
+            return mService.getWiFiWhiteList();
+        } catch (RemoteException e) {
+            throw e.rethrowFromSystemServer();
+        }
+    }
 
```

  
 3.BaseWifiService.java 增加接口



```
diff --git a/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java b/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.j
ava
old mode 100644
new mode 100755
index 8ca3753b7b..d826f33a25
--- a/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
+++ b/frameworks/base/wifi/java/com/android/server/wifi/BaseWifiService.java
@@ -565,4 +565,19 @@ public class BaseWifiService extends IWifiManager.Stub {
         throw new UnsupportedOperationException();
 
     }
+       @Override
+       public void setWiFiWhiteList( List<String> blackList){
+                throw new UnsupportedOperationException();
+               
+       };
+       @Override
+       public List<String> getWiFiWhiteList(){
+                throw new UnsupportedOperationException();
+               
+       };
 }
 
```

4. WifiServiceImpl.java 适配白名单



```
diff --git a/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java b/frameworks/opt/net/wifi/service/java/com/android/server/
wifi/WifiServiceImpl.java
old mode 100644
new mode 100755
index c429630db2..561e03a49b
--- a/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java
+++ b/frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java
@@ -2423,6 +2423,16 @@ public class WifiServiceImpl extends BaseWifiService {
                 Log.e(TAG, "Failed to post runnable to fetch scan results");
                 return new ArrayList<ScanResult>();
             }
+                       if(this.ssid_whiteList!=null && this.ssid_whiteList.size()!=0){
+                                    List<ScanResult> result1 =new ArrayList<>();
+                for (ScanResult resultbean : scanResults){
+                    if(!this.ssid_whiteList.contains(resultbean.SSID)){
+                        continue;
+                    }
+                    result1.add(resultbean);
+                           }
+                               return  result1;
+                       }
             return scanResults;
         } catch (SecurityException e) {
             Slog.e(TAG, "Permission violation - getScanResults not allowed for uid="
@@ -2432,7 +2442,27 @@ public class WifiServiceImpl extends BaseWifiService {
             Binder.restoreCallingIdentity(ident);
         }
     }
-
+       private List<String> ssid_whiteList;
+       @Override
+       public void setWiFiWhiteList(List<String> whiteList){
+               this.ssid_whiteList=whiteList;
+               
+       }
+       @Override
+       public List<String> getWiFiwhiteList(){
+               return this.ssid_whiteList;
+               
+       }
 

```



