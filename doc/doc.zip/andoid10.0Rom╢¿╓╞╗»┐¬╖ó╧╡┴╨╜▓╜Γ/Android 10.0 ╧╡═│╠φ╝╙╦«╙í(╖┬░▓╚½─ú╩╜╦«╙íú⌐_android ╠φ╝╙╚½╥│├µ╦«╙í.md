






由于项目需要，要添加商标的水印，所以功能差不多和安全模式的水印相同，进入安全模式的时候 左下角就有 安全模式 的水印  
 所以按照安全模式 添加水印 完成功能即可


1.查看SystemServer的相关代码找到安全模式的显示入口  
 路径:/frameworks/base/services/java/com/android/server/SystemServer.java



```
private void startOtherServices() 中是启动其他服务的
而       
 if (safeMode) {
        mActivityManagerService.showSafeModeOverlay();
 }

```

这里就是显示安全模式的水印


所以就需要在这里添加 自定义系统水印



```
boolean debugMode = SystemProperties.getBoolean("persist.sys.debug.mode", false); // 属性
        if (safeMode) {
            mActivityManagerService.showSafeModeOverlay();
        }

	if (debugMode) { // 水印显示入口
           mActivityManagerService.showWaterMarksOverlay();
        }

```

在device 下 buildinfo.sh 中定义属性persist.sys.debug.mode=true;


然后在AMS中添加showWaterMarksOverlay()  
 路径为:frameworks\base\services\core\java\com\android\server\am\ActivityManagerService.java  
 在window窗口 添加自定义View 当做水印



```
 public final void showWaterMarksOverlay() {
		android.util.Log.e("WaterMarks","showWaterMarksOverlay");
        int resorce = com.android.internal.R.layout.water_marks;
        View waterMarksView = android.view.LayoutInflater.from(mContext).inflate(resorce, null);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.type = WindowManager.LayoutParams.TYPE_SECURE_SYSTEM_OVERLAY;
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.BOTTOM;
        lp.format = waterMarksView.getBackground().getOpacity();
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        lp.privateFlags |= WindowManager.LayoutParams.PRIVATE_FLAG_SHOW_FOR_ALL_USERS;
        ((WindowManager)mContext.getSystemService(
 Context.WINDOW\_SERVICE)).addView(waterMarksView, lp);
    }

```

然后在framework/base/core/res/res/layout 下添加water\_marks.xml



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2006 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at
  
          http://www.apache.org/licenses/LICENSE-2.0
  
     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<TextView xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="wrap\_content" 
	android:layout_height="wrap\_content"
    android:gravity="center"
    android:padding="3dp"
    android:background="@android:color/transparent"
    android:text="pnr"
	android:textSize="16sp"
    android:textColor="@android:color/black"
    android:alpha="0.5"
/>

```

最后在frameworks/base/core/res/res/values/symbols.xml 注册water\_marks.xml



```
<java-symbol type="layout" name="water\_marks" />

```

编译发现底部有添加的水印 完成功能由于项目需要，要添加商标的水印，所以功能差不多和安全模式的水印相同，进入安全模式的时候 左下角就有 安全模式 的水印  
 所以按照安全模式 添加水印 完成功能即可





