






1.控制系统打开camera，通过CameraManager来实现控制打开camera



```
--- a/frameworks/base/core/java/android/hardware/camera2/CameraManager.java
+++ b/frameworks/base/core/java/android/hardware/camera2/CameraManager.java
@@ -52,7 +52,7 @@ import java.util.concurrent.Executors;
 import java.util.concurrent.RejectedExecutionException;
 import java.util.concurrent.ScheduledExecutorService;
 import java.util.concurrent.TimeUnit;
-
+import android.os.SystemProperties;
 //SPRD import
 import android.app.ActivityThread;
 import android.hardware.Camera;
@@ -378,7 +378,11 @@ public final class CameraManager {
             throws CameraAccessException {
         CameraCharacteristics characteristics = getCameraCharacteristics(cameraId);
         CameraDevice device = null;
-
+               String flag = SystemProperties.get("persist.sys.disableCamera", "false");
+               Log.d("dong","setBluetoothEnabled:"+flag);
+               if("true".equals(flag)){
+                       return null;
+               }
         synchronized (mLock) {
 
             ICameraDeviceUser cameraUser = null;

```

2.控制第三方app 打开camera  
 第三方app 是通过调用open方法来打开camera



```
--- a/frameworks/base/core/java/android/hardware/Camera.java
+++ b/frameworks/base/core/java/android/hardware/Camera.java
@@ -52,13 +52,12 @@ import android.view.SurfaceHolder;
 import com.android.internal.annotations.GuardedBy;
 import com.android.internal.app.IAppOpsCallback;
 import com.android.internal.app.IAppOpsService;
-
+import android.os.SystemProperties;
 import java.io.IOException;
 import java.lang.ref.WeakReference;
 import java.util.ArrayList;
 import java.util.LinkedHashMap;
 import java.util.List;
-
 /**
  * The Camera class is used to set image capture settings, start/stop preview,
  * snap pictures, and retrieve frames for encoding for video.  This class is a
@@ -411,6 +410,11 @@ public class Camera {
      * @see android.app.admin.DevicePolicyManager#getCameraDisabled(android.content.ComponentName)
      */
     public static Camera open(int cameraId) {
+               String flag = SystemProperties.get("persist.sys.disableCamera", "false");
+               Log.d("dong","setBluetoothEnabled:"+flag);
+               if("true".equals(flag)){
+                       return null;
+               }
         return new Camera(cameraId);
     }
 
@@ -424,6 +428,11 @@ public class Camera {
      * @see #open(int)
      */
     public static Camera open() {
+               String flag = SystemProperties.get("persist.sys.disableCamera", "false");
+               Log.d("dong","setBluetoothEnabled:"+flag);
+               if("true".equals(flag)){
+                       return null;
+               }
         int numberOfCameras = getNumberOfCameras();
         CameraInfo cameraInfo = new CameraInfo();
         for (int i = 0; i < numberOfCameras; i++) {
@@ -478,7 +487,11 @@ public class Camera {
         if (halVersion < CAMERA_HAL_API_VERSION_1_0) {
             throw new IllegalArgumentException("Invalid HAL version " + halVersion);
         }
-
+               String flag = SystemProperties.get("persist.sys.disableCamera", "false");
+               Log.d("dong","setBluetoothEnabled:"+flag);
+               if("true".equals(flag)){
+                       return null;
+               }
         return new Camera(cameraId, halVersion);
     }
 
@@ -600,6 +613,11 @@ public class Camera {
      * @hide
      */
     public static Camera openUninitialized() {
+               String flag = SystemProperties.get("persist.sys.disableCamera", "false");
+               Log.d("dong","setBluetoothEnabled:"+flag);
+               if("true".equals(flag)){
+                       return null;
+               }
         return new Camera();
     }

```

3.DevicePolicyManagerService控制



```
--- a/frameworks/base/services/devicepolicy/java/com/android/server/devicepolicy/DevicePolicyManagerService.java
+++ b/frameworks/base/services/devicepolicy/java/com/android/server/devicepolicy/DevicePolicyManagerService.java
@@ -393,7 +393,16 @@ public class DevicePolicyManagerService extends BaseIDevicePolicyManager {
             DELEGATION_NETWORK_LOGGING,
             DELEGATION_CERT_SELECTION,
     });
+       private List<String> KeepAliveList;     
+       public void setKeepAliveList(List<String> List){
+        this.KeepAliveList=List;
 
+    }
+
+    public List<String> getKeepAliveList(){
+        return this.KeepAliveList;
+
+    }
     /**
      *  System property whose value is either "true" or "false", indicating whether
      *  device owner is present.
@@ -7632,6 +7641,13 @@ public class DevicePolicyManagerService extends BaseIDevicePolicyManager {
         if (!mHasFeature) {
             return false;
         }
+               if(SystemProperties.get("persist.sys.disablecamera").equals("true")){
+            return true;
+         }
+                
+               if(SystemProperties.get("persist.sys.disablecamera").equals("false")){
+            return false;
+         }
         synchronized (getLockObject()) {
             if (who != null) {
                 ActiveAdmin admin = getActiveAdminUncheckedLocked(who, userHandle);

```




