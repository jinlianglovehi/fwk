






### 1.概述


在10.0的系统产品开发中，在对SystemUI下拉展开时，原生SystemUI会对下拉快捷功能键顺序排序，而  
 产品需求要求在QSPanel的功能开关顺序需要做调整，也就是要修改config.xml中的显示顺序，然后在加载QSPanel的功能开关就会按照顺序排列


### 2.修改SystemUI下拉QSPanel功能开关的显示顺序核心类



```
frameworks/base/packages/SystemUI/res/values/config.xml
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java 	

```

### 3.修改SystemUI下拉QSPanel功能开关的显示顺序核心功能分析和实现


在系统SystemUI的下拉状态栏中显示的快捷功能键对应的字符串属性，都是从SystemUI的res下的  
 config.xml的相关属性中读取的字符串，然后在加载对应的Tile文件，实现下拉功能键的功能


### 3.1第一步首选修改config.xml中的quick\_settings\_tiles\_default的排列顺序


具体路径为：



```
frameworks/base/packages/SystemUI/res/values/config.xml
@@ -93,7 +93,7 @@
     <bool name="config\_navigation\_bar\_enable\_auto\_dim\_no\_visible\_wallpaper">true</bool>
 
     <!-- The maximum number of tiles in the QuickQSPanel -->
-    <integer name="quick\_qs\_panel\_max\_columns">6</integer>
+    <integer name="quick\_qs\_panel\_max\_columns">9</integer>
 
     <!-- Whether QuickSettings is in a phone landscape -->
     <bool name="quick\_settings\_wide">false</bool>
@@ -109,11 +109,11 @@
     <!-- The number of columns that the top level tiles span in the QuickSettings -->
     <integer name="quick\_settings\_user\_time\_settings\_tile\_span">1</integer>
 
-    <!-- The default tiles to display in QuickSettings rotation cast lte1,lte2,cell,airplane-->
+    <!-- The default tiles to display in QuickSettings -->
     <string name="quick\_settings\_tiles\_default" translatable="false">
-        volte1,volte2,wifi,bt,dnd,vowifi,onehand,flashlight,battery
+        volte1,volte2,wifi,bt,vowifi,onehand,ring,screenshot,cast,rotation,night,airplane,flashlight
     </string>
-
+    <string name="quick\_config\_icon\_mask" translatable="false">"M50,50m-50,0a50,50 0,1 1,100 0a50,50 0,1 1,-100 0"</string>
     <!-- The minimum number of tiles to display in QuickSettings -->
     <integer name="quick\_settings\_min\_num\_tiles">6</integer>

```

在通过config.xml中的quick\_settings\_tiles\_default的属性分析，这个就是SystemUI下拉状态栏的  
 显示的快捷功能键对应的字符串属性，所以可以从quick\_settings\_tiles\_default中从新排序，改变  
 SystemUI的下拉状态栏中显示的快捷功能键的顺序  
 修改功能开关对应的字符串的排列顺序


### 3.2第二步 看哪里加载QSTile 然后看是否按照顺序加载


在QSPanel 加载的时候，会通过QSTileHost.java的loadTileSpecs 来加载quick\_settings\_tiles\_default的QSTile功能开关  
 路径为:frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java



```
protected List<String> loadTileSpecs(Context context, String tileList ,boolean is_special_request) {
        final Resources res = context.getResources();
        String defaultTileList = res.getString(R.string.quick_settings_tiles_default);
        if (TextUtils.isEmpty(tileList)) {
            tileList = res.getString(R.string.quick_settings_tiles);
            if (DEBUG) Log.d(TAG, "Loaded tile specs from config: " + tileList);
        } else {
            if (DEBUG) Log.d(TAG, "Loaded12 tile specs from setting: " + tileList);
        }
        if (!mIsEnableWifiDisplay) {
            tileList = tileList.replaceAll( ",cast|cast,|cast","");
            defaultTileList = defaultTileList.replaceAll( ",cast|cast,|cast","");
        }

        /* UNISOC: Bug 1074234,885650,Super power feature*/
        if (!is_special_request) {
            if(SprdPowerManagerUtil.isSuperPower()) {
                tileList = "wifi,cell,battery";
            }
        }
        /*@}*/
        /* UNISOC: Bug 1074234,895419,780848,remove battery quick setting label under guest mode */
        if (ActivityManager.getCurrentUser() != UserHandle.USER_OWNER) {
            tileList = tileList.replaceAll("battery","");
            defaultTileList = defaultTileList.replaceAll("battery","");
        }
        /* @} */
        /* UNISOC: Bug 1073208,1127438,longscreenshot feature @{ */
        if (ActivityManager.getCurrentUser() != UserHandle.USER_OWNER) {
            tileList = tileList.replaceAll("longscreenshot","");
            defaultTileList = defaultTileList.replaceAll("longscreenshot","");
        }
        /* @} */
        if (ActivityManager.getCurrentUser() != UserHandle.USER_OWNER) {
            tileList = tileList.replaceAll("lte","");
            defaultTileList = defaultTileList.replaceAll("lte","");
            tileList = tileList.replaceAll("volte","");
            defaultTileList = defaultTileList.replaceAll("volte","");
            tileList = tileList.replaceAll("vowifi","");
            defaultTileList = defaultTileList.replaceAll("vowifi","");
        }

        final ArrayList<String> tiles = new ArrayList<String>();
        boolean addedDefault = false;
        
        // 遍历tileList的集合 添加功能开关 但发现这里不是默认的quick_settings_tiles_default的内容
        for (String tile : tileList.split(",")) {
            tile = tile.trim();
            if (tile.isEmpty()) continue;
            if (tile.equals("default")) {
                if (!addedDefault) {
                    tiles.addAll(Arrays.asList(defaultTileList.split(",")));
                    if (Build.IS_DEBUGGABLE
                            && GarbageMonitor.MemoryTile.ADD_TO_DEFAULT_ON_DEBUGGABLE_BUILDS) {
                        tiles.add(GarbageMonitor.MemoryTile.TILE_SPEC);
                    }
                    addedDefault = true;
                }
            } else {
                tiles.add(tile);
            }
        }
        return tiles;
    }

```

从上述QSTileHost.java的loadTileSpecs的方法中可以看出，这里的默认值是会从quick\_settings\_tiles\_default  
 中读取下拉快捷的属性值，就是在第一次开机会读取这里的数值，所以在修改后不生效的情况下可以  
 恢复出厂设置清除掉缓存 或者修改for循环添加数据的地方  
 // 遍历tileList的集合 添加功能开关 但发现这里不是默认的quick\_settings\_tiles\_default的内容  
 for (String tile : tileList.split(“,”)) {  
 所以需要修改成默认的资源集合为defaultTileList


具体修改为：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/QSTileHost.java
@@ -458,7 +458,7 @@ public class QSTileHost implements QSHost, Tunable, PluginListener<QSFactory>, D
             tileList = res.getString(R.string.quick_settings_tiles);
             if (DEBUG) Log.d(TAG, "Loaded tile specs from config: " + tileList);
         } else {
-            if (DEBUG) Log.d(TAG, "Loaded tile specs from setting: " + tileList);
+            if (DEBUG) Log.d(TAG, "Loaded12 tile specs from setting: " + tileList);
         }
         if (!mIsEnableWifiDisplay) {
             tileList = tileList.replaceAll( ",cast|cast,|cast","");
@@ -495,7 +495,7 @@ public class QSTileHost implements QSHost, Tunable, PluginListener<QSFactory>, D
 
         final ArrayList<String> tiles = new ArrayList<String>();
         boolean addedDefault = false;
-        for (String tile : tileList.split(",")) {
+        for (String tile : defaultTileList.split(",")) {
             tile = tile.trim();
             if (tile.isEmpty()) continue;
             if (tile.equals("default")) {

```




