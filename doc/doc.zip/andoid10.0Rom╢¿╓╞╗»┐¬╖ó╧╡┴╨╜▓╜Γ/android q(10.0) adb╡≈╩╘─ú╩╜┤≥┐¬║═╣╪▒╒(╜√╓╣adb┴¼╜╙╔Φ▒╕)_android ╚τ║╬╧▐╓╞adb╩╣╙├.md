






1.Android.bp中修改



```
diff --git a/system/core/adb/Android.bp b/system/core/adb/Android.bp
old mode 100644
new mode 100755
index 01e00dd1cd..8eda5faddf
--- a/system/core/adb/Android.bp
+++ b/system/core/adb/Android.bp
@@ -76,7 +76,14 @@ cc_defaults {
     name: "adbd\_defaults",
     defaults: ["adb\_defaults"],
 
-    cflags: ["-UADB\_HOST", "-DADB\_HOST=0"],
+    cflags: [
+               "-UADB\_HOST",
+               "-DADB\_HOST=0",
+               "-UALLOW\_ADBD\_ROOT",
+               "-DALLOW\_ADBD\_ROOT=1",
+               "-DALLOW\_ADBD\_DISABLE\_VERITY",
+               "-DALLOW\_ADBD\_NO\_AUTH",
+       ],
     product_variables: {
         debuggable: {
             cflags: [
@@ -411,7 +418,7 @@ cc_library {
             ],
         },
     },
-
+       required: [ "remount",],
     target: {
         android: {
             srcs: [
diff --git a/system/core/adb/daemon/main.cpp b/system/core/adb/daemon/main.cpp
old mode 100644
new mode 100755
index e5a49171bc..65ab0f2279
--- a/system/core/adb/daemon/main.cpp
+++ b/system/core/adb/daemon/main.cpp
@@ -63,15 +63,16 @@ static inline bool is\_device\_unlocked() {
 }
 
 static bool should\_drop\_capabilities\_bounding\_set() {
-    if (ALLOW_ADBD_ROOT || is_device_unlocked()) {
+    /*if (ALLOW_ADBD_ROOT || is_device_unlocked()) {
         if (__android_log_is_debuggable()) {
             return false;
         }
-    }
-    return true;
+    }*/
+    return false;
 }
 
 static bool should\_drop\_privileges() {
+       return 0;
     // "adb root" not allowed, always drop privileges.
     if (!ALLOW_ADBD_ROOT && !is_device_unlocked()) return true;

```

2. 代码  
 通过变量on 控制adb开启关闭



```
Settings.Global.putInt(mContext.getContentResolver(), Settings.Global.ADB_ENABLED, on ? 1 : 0);

```

3.禁止通知状态栏usb显示



```
/device/产品/xxxx/system.prop 
添加 字段persist.adb.notify=0

```




