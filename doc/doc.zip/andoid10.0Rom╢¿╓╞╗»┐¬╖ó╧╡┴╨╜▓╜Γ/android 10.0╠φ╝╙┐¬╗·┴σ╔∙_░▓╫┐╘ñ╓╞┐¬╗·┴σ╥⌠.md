






在定制化系统中，默认是没有开机铃声的，有客户提出需要要添加开机铃声，所以为了  
 完成需求，就来实现这一个功能


关于开机铃声 都是在bootanimation\_main.cpp 这里面负责管理



```
frameworks\base\cmds\bootanimation\bootanimation_main.cpp

int main()
{
    setpriority(PRIO_PROCESS, 0, ANDROID_PRIORITY_DISPLAY);

    bool noBootAnimation = bootAnimationDisabled();
    ALOGI_IF(noBootAnimation,  "boot animation disabled");
    if (!noBootAnimation) {

        sp<ProcessState> proc(ProcessState::self());
        ProcessState::self()->startThreadPool();

        // create the boot animation object (may take up to 200ms for 2MB zip)
#ifdef BOOTANIMATION\_EXT
        sp<BootAnimation> boot = new BootAnimation(audioplay::createAnimationCallbacks(),true);
#else
        sp<BootAnimation> boot = new BootAnimation(audioplay::createAnimationCallbacks());
#endif
        waitForSurfaceFlinger();

        boot->run("BootAnimation", PRIORITY_DISPLAY);

        ALOGV("Boot animation set up. Joining pool.");

        IPCThreadState::self()->joinThreadPool();
    }
    return 0;
}

```

从代码中可以看到 是由BootAnimation来处理 开机铃声


frameworks\base\cmds\bootanimation\BootAnimation.cpp



```
//add core start
static const char OEM_BOOTSOUND_FILE[] = "/oem/media/bootsound.mp3";
static const char PRODUCT_BOOTSOUND_FILE[] = "/product/media/bootsound.mp3";
static const char SYSTEM_BOOTSOUND_FILE[] = "/system/media/bootsound.mp3";
static const char OEM_SHUTDOWNSOUND_FILE[] = "/oem/media/shutdownsound.mp3";
static const char PRODUCT_SHUTDOWNSOUND_FILE[] = "/product/media/shutdownsound.mp3";
static const char SYSTEM_SHUTDOWNSOUND_FILE[] = "/system/media/shutdownsound.mp3";
class MPlayerListener : public MediaPlayerListener
{
    void notify(int msg, int /*ext1*/, int /*ext2*/, const Parcel * /*obj*/)
    {
        switch (msg) {
        case MEDIA_PLAYBACK_COMPLETE:
            ALOGD("shutdown media finished, quit");
            if (property_set("service.bootanim.end", "1") != 0) {
                ALOGD("set property failed!");
            }
            break;
        default:
            break;
        }
    }
};
//add core end
void BootAnimation::findBootAnimationFile() {
    // If the device has encryption turned on or is in process
    // of being encrypted we show the encrypted boot animation.
    char decrypt[PROPERTY_VALUE_MAX];
    property_get("vold.decrypt", decrypt, "");

    bool encryptedAnimation = atoi(decrypt) != 0 ||
        !strcmp("trigger\_restart\_min\_framework", decrypt);

    if (!mShuttingDown && encryptedAnimation) {
        static const char* encryptedBootFiles[] =
            {PRODUCT_ENCRYPTED_BOOTANIMATION_FILE, SYSTEM_ENCRYPTED_BOOTANIMATION_FILE};
        for (const char* f : encryptedBootFiles) {
            if (access(f, R_OK) == 0) {
                mZipFileName = f;
                return;
            }
        }
    }

    const bool playDarkAnim = android::base::GetIntProperty("ro.boot.theme", 0) == 1;
    static const char* bootFiles[] =
        {APEX_BOOTANIMATION_FILE, playDarkAnim ? PRODUCT_BOOTANIMATION_DARK_FILE : PRODUCT_BOOTANIMATION_FILE,
         OEM_BOOTANIMATION_FILE, SYSTEM_BOOTANIMATION_FILE};
    static const char* shutdownFiles[] =
        {PRODUCT_SHUTDOWNANIMATION_FILE, OEM_SHUTDOWNANIMATION_FILE, SYSTEM_SHUTDOWNANIMATION_FILE, ""};

    for (const char* f : (!mShuttingDown ? bootFiles : shutdownFiles)) {
        if (access(f, R_OK) == 0) {
            mZipFileName = f;

           + break;
            //return;
        }
    }

// add core start
    static const char* bootSoundFiles[] =
        {PRODUCT_BOOTSOUND_FILE, OEM_BOOTSOUND_FILE, SYSTEM_BOOTSOUND_FILE};
    static const char* shutdownSoundFiles[] =
        {PRODUCT_SHUTDOWNSOUND_FILE, OEM_SHUTDOWNSOUND_FILE, SYSTEM_SHUTDOWNSOUND_FILE};
    for (const char* f : (!mShuttingDown ? bootSoundFiles : shutdownSoundFiles)) {
        if (access(f, R_OK) == 0) {
            mSoundFileName = f;
            SLOGD("mSoundFileName string is %s,length is %zu",mSoundFileName.string(),mSoundFileName.length());
            return;
        }
    }
    SLOGD("set mSoundFileName null");
    mSoundFileName = "";

    return;
    // add core end
}

```

获取播放开机音乐路径：PRODUCT\_BOOTSOUND\_FILE, OEM\_BOOTSOUND\_FILE, SYSTEM\_BOOTSOUND\_FILE 中的一个  
 所以系统默认的路径为SYSTEM\_BOOTSOUND\_FILE 即为 /system/media/bootsound.mp3


也就是说和开机动画放在同一个目录就可



```
bool BootAnimation::parseAnimationDesc(Animation& animation)
{
    String8 desString;

    if (!readFile(animation.zip, "desc.txt", desString)) {
        return false;
    }
    char const* s = desString.string();

//add core start
    ALOGE("before allowed, soundplay");
    if (playSoundsAllowed()) {
        ALOGE("soundplay called");
        soundplay();
    }

    sp<IBinder> displayToken = SurfaceComposerClient::getInternalDisplayToken();
    if (displayToken == nullptr) {
        SLOGE("get display token err");
        return -1;
    }

    DisplayInfo dinfo;
    status_t status = SurfaceComposerClient::getDisplayInfo(displayToken, &dinfo);
    if (status) {
        SLOGE("get display info err,status is %d",status);
        return -1;
    }

    Vector<DisplayInfo> configs;
    status_t result = SurfaceComposerClient::getDisplayConfigs(displayToken, &configs);
    if (result) {
        SLOGE("get display configs err,result is %d",result);
        return -1;
    }
    int displayIdNum = configs.size();
// add core end


    // Parse the description file
    for (;;) {
        const char* endl = strstr(s, "\n");
        if (endl == nullptr) break;
        String8 line(s, endl - s);
        const char* l = line.string();
        int fps = 0;
        int width = 0;
        int height = 0;
        int count = 0;
        int pause = 0;
        char path[ANIM_ENTRY_NAME_MAX];
        char color[7] = "000000"; // default to black if unspecified
        char clockPos1[TEXT_POS_LEN_MAX + 1] = "";
        char clockPos2[TEXT_POS_LEN_MAX + 1] = "";

        char pathType;
        if (sscanf(l, "%d %d %d", &width, &height, &fps) == 3) {
            // SLOGD("> w=%d, h=%d, fps=%d", width, height, fps);

//add core start
            if (DEFAULT_SUPPORT_RESOLUTION_NUM == displayIdNum) {
                animation.width = width;
                animation.height = height;
            } else if (DEFAULT_SUPPORT_RESOLUTION_NUM < displayIdNum) {
                animation.width = dinfo.w;
                animation.height = dinfo.h;
            } else {
                SLOGE("display id num is wrong, displayIdNum is %d",displayIdNum);
            }
            animation.fps = fps;
//add core end



bool BootAnimation::playAnimation(const Animation& animation)
{
....
// add core start
    // SPRD: stop soundplay
    if (playSoundsAllowed()) {
        soundstop();
    }
// add core end
    return true;
}

    String8     mSoundFileName;
    sp<MediaPlayer> mp;
    int         mfd;
    bool        mSystemCalled;
    bool        mWaitForComplete;
bool BootAnimation::soundplay() {
    mp = NULL;
    if (mSoundFileName.length() == 0) {
        __android_log_print(ANDROID_LOG_WARN, LOG_TAG, "no bootanimation sound resource....");
        return false;
    }
    mfd = open(mSoundFileName.string(), O_RDONLY);
    if(mfd == -1){
        __android_log_print(ANDROID_LOG_WARN, LOG_TAG, "can not find bootanimation sound resource....");
        return false;
    }

    mp = new MediaPlayer();
    SLOGE("new MediaPlayer");
    if (mShuttingDown && mWaitForComplete) {
        sp<MPlayerListener> mListener = new MPlayerListener();
        mp->setListener(mListener);
    }
    mp->setDataSource(mfd, 0, 0x7ffffffffffffffLL);
    mp->setAudioStreamType(/*AUDIO_STREAM_MUSIC*/AUDIO_STREAM_SYSTEM);
    mp->prepare();
    ALOGD("%sAnimation start MediaPlayer,play sound time: %" PRId64 "ms",
        mShuttingDown ? "Shutdown" : "Boot", elapsedRealtime());
    mp->start();
    return false;
}

bool BootAnimation::soundstop()
{
    if (mSoundFileName.length() == 0) {
        __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "no sound resource ");
        return false;
    }

    ALOGD("%sAnimation stop MediaPlayer time: %" PRId64 "ms",
        mShuttingDown ? "Shutdown" : "Boot", elapsedRealtime());
    if (mp != NULL)mp->stop();
    return false;
}

```

2. persist.sys.bootanim.play\_sound 属性的设置



```
static const char PLAY_SOUND_PROP_NAME[] = "persist.sys.bootanim.play\_sound";
bool BootAnimation::playSoundsAllowed() {
    // Compatible with Android Things
    // only system called will play sounds in system/media/
    if (!mSystemCalled) {
        return false;
    }

    // Read the system property to see if we should play the sound.
    // If it's not present, default to allowed.
 if (!property\_get\_bool(PLAY\_SOUND\_PROP\_NAME, 1)) {
 return false;
 }

 // Don't play sounds if this is a reboot due to an error.
    char bootreason[PROPERTY_VALUE_MAX];
    if (property_get(BOOTREASON_PROP_NAME, bootreason, nullptr) > 0) {
        for (const auto& str : PLAY_SOUND_BOOTREASON_BLACKLIST) {
            if (strcasecmp(str.c_str(), bootreason) == 0) {
                return false;
            }
        }
    }
    return true;
}

```

是否允许播放中 会判断persist.sys.bootanim.play\_sound 是否为1 如果不能播放 请查看这个值是否为1


展讯开机铃声添加路径为：  
 路径：device/sprd/common/elink/customer/system/media/bootsound.mp3


就是找到和开机动画放在同一个路径就可以了 然后编译开机验证





