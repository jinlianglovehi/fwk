



## 1.前言


  
   在10.0的产品定制化开发中，在usb模块otg连接电脑，调整为mtp文件传输模式的时候，这时可以在电脑看到手机的内部存储  
 显示在电脑的盘符中，会有一个mtp名称做盘符，所以为了统一这个名称，就需要修改这个名称，接下来分析下处理的  
 方法来解决这个问题


![](https://img-blog.csdnimg.cn/10c1c8bd8d7646be9385e70118c6458c.png)


## 2.系统修改usb连接电脑mtp和PTP的显示名称的核心代码



```
frameworks\base\media\java\android\mtp\MtpDatabase.java
frameworks\av\media\mtp\MtpServer.cpp
```

## 3.系统修改usb连接电脑mtp和PTP的显示名称的核心功能分析和实现


MTP的全称是Media Transfer Protocol（媒体传输协议），它是微软公司提出的一套媒体文件传输协议。Android从3.0开始支持MTP


在android系统中，在关于mtp模式下usb文件传输过程中，在对mtp的数据库的管理就是在MtpDatabase.java中负责保存数据，  
 mtp在文件的拷贝，删除，重命名等这些操作强制判定操作不允许或者文件写保护，用到的属性为MtpConstants.RESPONSE\_ACCESS\_DENIED，  
 MtpConstants.RESPONSE\_OBJECT\_WRITE\_PROTECTED。


MtpRequestPacke负责从USB驱动读取数据，并结构化命令格式及其参数、MtpDataPacket负责结构化手机要返回给PC的数据包、MtpResponsePacket负责结构化手机要给PC返回的response。MtpServer负责解析来自PC的命令并调用相应的接口函数进行处理。  
 Java层包括UsbReceiver、MtpService、MtpServer等对象。其中UsbReceiver用来监视USB事件，判断何时启动或停止MtpService。MtpService负责启动MtpServer和加载存储设备的信息到数据库。MtpServer负责通过jni接口去启动/  
 停止C++层中MtpServer以及处理Storage的添加和删除。MediaProvider则负责查询和更新数据库。MtpDatabase名字虽然叫Database，但实际功能用于在MediaProvider和MtpServer之间转换数据格式。  
 例如把MTP传递过来的信息（如文件大小、文件路径等）转换成MediaProvider需要的格式以方便其更新数据库。


## 3.1 mtp显示名称的相关代码分析



创建一个*MtpDatabase*对象,MtpDatabase简单来说就是framework操作*mtp*的接口。它通过MtpStorageManager管理存储,并监听了文件系统



```
   @VisibleForNative
    private int beginCopyObject(int handle, int newParent, int newStorage) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        MtpStorageManager.MtpObject parent = newParent == 0 ?
                mManager.getStorageRoot(newStorage) : mManager.getObject(newParent);
        if (obj == null || parent == null)
            return MtpConstants.RESPONSE_INVALID_OBJECT_HANDLE;
        return mManager.beginCopyObject(obj, parent);
    }

    @VisibleForNative
    private void endCopyObject(int handle, boolean success) {
        MtpStorageManager.MtpObject obj = mManager.getObject(handle);
        if (obj == null || !mManager.endCopyObject(obj, success)) {
            Log.e(TAG, "Failed to end copy object");
            return;
        }
        if (!success) {
            return;
        }
        MediaStore.scanFile(mContext, obj.getPath().toFile());
    }

    @VisibleForNative
    private int setObjectProperty(int handle, int property,
            long intValue, String stringValue) {
        switch (property) {
            case MtpConstants.PROPERTY_OBJECT_FILE_NAME:
                return renameFile(handle, stringValue);

            default:
                return MtpConstants.RESPONSE_OBJECT_PROP_NOT_SUPPORTED;
        }
    }

   @VisibleForNative
    private int getDeviceProperty(int property, long[] outIntValue, char[] outStringValue) {
        switch (property) {
            case MtpConstants.DEVICE_PROPERTY_SYNCHRONIZATION_PARTNER:
            case MtpConstants.DEVICE_PROPERTY_DEVICE_FRIENDLY_NAME:
                // writable string properties kept in shared preferences
                String value = mDeviceProperties.getString(Integer.toString(property), "");
          -       value = "MID";
         +       value = "T505";
                int length = value.length();
                if (length > 255) {
                    length = 255;
                }
                value.getChars(0, length, outStringValue, 0);
                outStringValue[length] = 0;
                return MtpConstants.RESPONSE_OK;
            case MtpConstants.DEVICE_PROPERTY_IMAGE_SIZE:
                // use screen size as max image size
                Display display = ((WindowManager) mContext.getSystemService(
                        Context.WINDOW_SERVICE)).getDefaultDisplay();
                int width = display.getMaximumSizeDimension();
                int height = display.getMaximumSizeDimension();
                String imageSize = Integer.toString(width) + "x" + Integer.toString(height);
                imageSize.getChars(0, imageSize.length(), outStringValue, 0);
                outStringValue[imageSize.length()] = 0;
                return MtpConstants.RESPONSE_OK;
            case MtpConstants.DEVICE_PROPERTY_PERCEIVED_DEVICE_TYPE:
                outIntValue[0] = mDeviceType;
                return MtpConstants.RESPONSE_OK;
            case MtpConstants.DEVICE_PROPERTY_BATTERY_LEVEL:
                outIntValue[0] = mBatteryLevel;
                outIntValue[1] = mBatteryScale;
                return MtpConstants.RESPONSE_OK;
            default:
                return MtpConstants.RESPONSE_DEVICE_PROP_NOT_SUPPORTED;
        }
    }

    @VisibleForNative
    private int setDeviceProperty(int property, long intValue, String stringValue) {
        switch (property) {
            case MtpConstants.DEVICE_PROPERTY_SYNCHRONIZATION_PARTNER:
            case MtpConstants.DEVICE_PROPERTY_DEVICE_FRIENDLY_NAME:
                // writable string properties kept in shared prefs
                SharedPreferences.Editor e = mDeviceProperties.edit();
                e.putString(Integer.toString(property), stringValue);
                return (e.commit() ? MtpConstants.RESPONSE_OK
                        : MtpConstants.RESPONSE_GENERAL_ERROR);
        }

        return MtpConstants.RESPONSE_DEVICE_PROP_NOT_SUPPORTED;
    }
```

在上述的MtpDatabase.java的相关源码中，分析得知，在beginCopyObject(int handle, int newParent, int newStorage)  
 这个方法中，开始拷贝mtp的相关信息到数据库里面，在endCopyObject(int handle, boolean success) 就表示  
 mtp拷贝数据结束，在setObjectProperty(int handle, int property,long intValue, String stringValue)中，就是设置  
 mtp相关的数据，在 getDeviceProperty(int property, long[] outIntValue, char[] outStringValue)中就是主要是  
 获取相关的mtp的显示数据，所以主要就是在这里通过上面的            case MtpConstants.DEVICE\_PROPERTY\_SYNCHRONIZATION\_PARTNER:  
             case MtpConstants.DEVICE\_PROPERTY\_DEVICE\_FRIENDLY\_NAME查询显示mtp盘符显示数据是  
 String value = mDeviceProperties.getString(Integer.toString(property), "");从系统属性中获取，  
 获取显示名称，然后在通过value修改对应的值，所以在上述的修改完成后，就可以看到  
 在电脑上mtp盘符就是自己想要的名称了，


## 3.2 在MtpServer.cpp中修改PTP显示的名称



*android*\_*mtp\_MtpServer*是一个JNI类,它是"JNI层的MtpServer 和 Java层的MtpServer"沟通的桥梁。android\_mtp\_MtpDatabase也是一个JNI类,JNI层通过它实现了对MtpDatabase(Framework层)的操作



```
MtpResponseCode MtpServer::doGetDeviceInfo() {
    MtpStringBuffer   string;

    MtpObjectFormatList* playbackFormats = mDatabase->getSupportedPlaybackFormats();
    MtpObjectFormatList* captureFormats = mDatabase->getSupportedCaptureFormats();
    MtpDevicePropertyList* deviceProperties = mDatabase->getSupportedDeviceProperties();

    // fill in device info
    mData.putUInt16(MTP_STANDARD_VERSION);
    if (mPtp) {
        mData.putUInt32(0);
    } else {
        // MTP Vendor Extension ID
        mData.putUInt32(6);
    }
    mData.putUInt16(MTP_STANDARD_VERSION);
    if (mPtp) {
        // no extensions


// modify code start
   -     string.set("");
   +     string.set("T505");
//modify code end


    } else {
        // MTP extensions
        string.set("microsoft.com: 1.0; android.com: 1.0;");
    }
    mData.putString(string); // MTP Extensions
    mData.putUInt16(0); //Functional Mode
    mData.putAUInt16(kSupportedOperationCodes,
            sizeof(kSupportedOperationCodes) / sizeof(uint16_t)); // Operations Supported
    mData.putAUInt16(kSupportedEventCodes,
            sizeof(kSupportedEventCodes) / sizeof(uint16_t)); // Events Supported
    mData.putAUInt16(deviceProperties); // Device Properties Supported
    mData.putAUInt16(captureFormats); // Capture Formats
    mData.putAUInt16(playbackFormats);  // Playback Formats

    mData.putString(mDeviceInfoManufacturer); // Manufacturer
    mData.putString(mDeviceInfoModel); // Model
    mData.putString(mDeviceInfoDeviceVersion); // Device Version
    mData.putString(mDeviceInfoSerialNumber); // Serial Number

    delete playbackFormats;
    delete captureFormats;
    delete deviceProperties;

    return MTP_RESPONSE_OK;
}

```

在上述的MtpServer.cpp中的相关源码中，分析得知在MtpServer::doGetDeviceInfo()  
 这里获取PTP的相关数据的时候，在放到数据库里面，所以在  
     if (mPtp) {  
         // no extensions  
 // modify code start  
    -     string.set("");  
    +     string.set("T505");  
 //modify code end


    } else {  
         // MTP extensions  
         string.set("microsoft.com: 1.0; android.com: 1.0;");  
     }


这里负责保存关于ptp的显示名称数据，所以就把string.set("T505");修改为  
 自己需要显示的名称就可以了



