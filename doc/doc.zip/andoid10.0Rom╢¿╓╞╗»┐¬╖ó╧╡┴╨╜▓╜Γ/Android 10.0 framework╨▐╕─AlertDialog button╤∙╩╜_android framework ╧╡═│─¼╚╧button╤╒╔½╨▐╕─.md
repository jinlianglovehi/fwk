






### 1.概述


在10.0的系统产品开发中,在系统的对话框AlertDialog对话框 由于布局的确定和取消 两个button 字体默认颜色  
 不太符合产品要求，所以要求对这两个Button做颜色的修改换种字体颜色


### 2.framework修改AlertDialog button样式的核心类



```
frameworks\base\core\res\res\layout\alert_dialog.xml
frameworks/base/core/res/res/values/styles_device_defaults.xml

```

### 3.framework修改AlertDialog button样式核心功能分析和实现


对于系统AlertDialog对话框的布局button颜色做修改功能，首选先看布局文件是哪个，然后对布局文件字体样式做修改  
 而在AlertDialog的布局是alert\_dialog.xml 中采用的哪个布局样式  
 布局为:frameworks\base\core\res\res\layout\alert\_dialog.xml


### 3.1alert\_dialog.xml的布局分析



```
<?xml version="1.0" encoding="utf-8"?>
<!--
/* //device/apps/common/res/layout/alert_dialog.xml
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/
-->
<LinearLayout
xmlns:android="http://schemas.android.com/apk/res/android"
android:id="@+id/parentPanel"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:orientation="vertical"
android:paddingTop="9dip"
android:paddingBottom="3dip"
android:paddingStart="3dip"
android:paddingEnd="1dip">
<LinearLayout android:id="@+id/topPanel"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:minHeight="54dip"
android:orientation="vertical">
<LinearLayout android:id="@+id/title\_template"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:orientation="horizontal"
android:gravity="center\_vertical"
android:layout_marginTop="6dip"
android:layout_marginBottom="9dip"
android:layout_marginStart="10dip"
android:layout_marginEnd="10dip">
<ImageView android:id="@+id/icon"
android:layout_width="wrap\_content"
android:layout_height="wrap\_content"
android:layout_gravity="top"
android:paddingTop="6dip"
android:paddingEnd="10dip"
android:src="@drawable/ic\_dialog\_info" />
<com.android.internal.widget.DialogTitle android:id="@+id/alertTitle"
style="?android:attr/textAppearanceLarge"
android:singleLine="true"
android:ellipsize="end"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:textAlignment="viewStart" />
</LinearLayout>
<ImageView android:id="@+id/titleDivider"
android:layout_width="match\_parent"
android:layout_height="1dip"
android:visibility="gone"
android:scaleType="fitXY"
android:gravity="fill\_horizontal"
android:src="@android:drawable/divider\_horizontal\_dark" />
<!-- If the client uses a customTitle, it will be added here. -->
</LinearLayout>
<LinearLayout android:id="@+id/contentPanel"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:layout_weight="1"
android:orientation="vertical">
<ScrollView android:id="@+id/scrollView"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:paddingTop="2dip"
android:paddingBottom="12dip"
android:paddingStart="14dip"
android:paddingEnd="10dip"
android:overScrollMode="ifContentScrolls">
<TextView android:id="@+id/message"
style="?android:attr/textAppearanceMedium"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:padding="5dip" />
</ScrollView>
</LinearLayout>
<FrameLayout android:id="@+id/customPanel"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:layout_weight="1">
<FrameLayout android:id="@+android:id/custom"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:paddingTop="5dip"
android:paddingBottom="5dip" />
</FrameLayout>
<LinearLayout android:id="@+id/buttonPanel"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:minHeight="54dip"
android:orientation="vertical" >
<LinearLayout
style="?android:attr/buttonBarStyle"
android:layout_width="match\_parent"
android:layout_height="wrap\_content"
android:orientation="horizontal"
android:paddingTop="4dip"
android:paddingStart="2dip"
android:paddingEnd="2dip"
android:measureWithLargestChild="true">
<LinearLayout android:id="@+id/leftSpacer"
android:layout_weight="0.25"
android:layout_width="0dip"
android:layout_height="wrap\_content"
android:orientation="horizontal"
android:visibility="gone" />
<Button android:id="@+id/button1"
android:layout_width="0dip"
android:layout_gravity="start"
android:layout_weight="1"
style="?android:attr/buttonBarButtonStyle"
android:maxLines="2"
android:layout_height="wrap\_content" />
<Button android:id="@+id/button3"
android:layout_width="0dip"
android:layout_gravity="center\_horizontal"
android:layout_weight="1"
style="?android:attr/buttonBarButtonStyle"
android:maxLines="2"
android:layout_height="wrap\_content" />
<Button android:id="@+id/button2"
android:layout_width="0dip"
android:layout_gravity="end"
android:layout_weight="1"
style="?android:attr/buttonBarButtonStyle"
android:maxLines="2"
android:layout_height="wrap\_content" />
<LinearLayout android:id="@+id/rightSpacer"
android:layout_width="0dip"
android:layout_weight="0.25"
android:layout_height="wrap\_content"
android:orientation="horizontal"
android:visibility="gone" />
</LinearLayout>
</LinearLayout>
</LinearLayout>

```

通过布局文件中的@+id/button3和@+id/button2等button的空间可以  
 看到样式为 style="?android:attr/buttonBarButtonStyle"而这个样式定义在  
 在themes\_device\_defaults.xml 中  
 所以继续看themes\_device\_defaults.xml的源码


### 3.2 themes\_device\_defaults.xml的源码布局分析


路径：framework/base/core/res/res/values/themes\_device\_defaults.xml:1663:



```
 <item name="buttonBarButtonStyle">@style/Widget.DeviceDefault.Button.ButtonBar.AlertDialog</item>

```

而它的样式又是Widget.DeviceDefault.Button.ButtonBar.AlertDialog样式在styles\_device\_defaults.xml中  
 所以需要看下Widget.DeviceDefault.Button.ButtonBar.AlertDialog样式的相关代码  
 路径frameworks/base/core/res/res/values/styles\_device\_defaults.xml  
 所以具体修改如下



```
--- a/frameworks/base/core/res/res/values/styles_device_defaults.xml
+++ b/frameworks/base/core/res/res/values/styles_device_defaults.xml
@@ -103,6 +103,7 @@ easier.
<style name="Widget.DeviceDefault.Button.ButtonBar.AlertDialog" parent="Widget.DeviceDefault.Button.Borderless.Colored">
<item name="minWidth">@dimen/alert_dialog_button_bar_width</item>
<item name="minHeight">@dimen/alert_dialog_button_bar_height</item>
+ <item name="textColor">#E8E8E8</item> <!--add code -->
</style>
<style name="Widget.DeviceDefault.Tab" parent="Widget.Material.Tab"/>
<style name="Widget.DeviceDefault.CalendarView" parent="Widget.Material.CalendarView"/>

```

增加字体默认颜色





