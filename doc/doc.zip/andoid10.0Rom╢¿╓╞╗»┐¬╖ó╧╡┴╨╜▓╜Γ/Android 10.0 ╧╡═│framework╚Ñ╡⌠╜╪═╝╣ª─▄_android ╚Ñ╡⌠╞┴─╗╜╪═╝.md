



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.去掉截图功能的核心代码](#2.%E5%8E%BB%E6%8E%89%E6%88%AA%E5%9B%BE%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.去掉截图功能的核心代码分析和实现功能](#3.%E5%8E%BB%E6%8E%89%E6%88%AA%E5%9B%BE%E5%8A%9F%E8%83%BD%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90%E5%92%8C%E5%AE%9E%E7%8E%B0%E5%8A%9F%E8%83%BD)


[3.1 PhoneWindowManager.java关于截图功能分析](#3.1%20PhoneWindowManager.java%E5%85%B3%E4%BA%8E%E6%88%AA%E5%9B%BE%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.2 GlobalScreenshot.java截图代码分析](#3.2%20GlobalScreenshot.java%E6%88%AA%E5%9B%BE%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.3 去掉截图功能最终修改为:](#3.3%20%E5%8E%BB%E6%8E%89%E6%88%AA%E5%9B%BE%E5%8A%9F%E8%83%BD%E6%9C%80%E7%BB%88%E4%BF%AE%E6%94%B9%E4%B8%BA%3A)


[3.4 关于屏蔽截图命令的功能修改](#3.4%20%E5%85%B3%E4%BA%8E%E5%B1%8F%E8%94%BD%E6%88%AA%E5%9B%BE%E5%91%BD%E4%BB%A4%E7%9A%84%E5%8A%9F%E8%83%BD%E4%BF%AE%E6%94%B9)




---



## 1.概述


 在定制化10.0产品中，由于是教育类的产品，为了不让资料外传，要求去掉截图功能，屏蔽掉系统截图的接口，不管是命令还是代码都不让截图


## 2.去掉截图功能的核心代码



```
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
frameworks/base/core/java/com/android/internal/util/ScreenshotHelper.java
frameworks/base/packages/SystemUI/src/com/android/systemui/screenshot/TakeScreenshotService.java
frameworks/base/packages/SystemUI/src/com/android/systemui/screenshot/GlobalScreenshot.java
```

## 3.去掉截图功能的核心代码分析和实现功能


Power按键的上报流程与其余的按键处理流程一致，在按下power按键后驱动上报按键经InputManagerService处理按键事件，最终将会传递到PhoneWindowManager的interceptKeyBeforeQueueing函数来做具体的业务逻辑。（具体处理 Input system 做详细介绍）本篇侧重power的业务逻辑处理，这里简单介绍下power 按键的上报流程如下图：


在power 按键按下时驱动会上报按键事件，EventHub读取到事件后转给InputReader来做处理。  
 InputReader根据上报的事件类型（此处是按键事件），交给KeyBoardInputMapper来做按键映射，根据驱动上报的按键值来映射为android framework的按键值（即KeyEvent.KEYCODE\_POWER 和相应的flag），并通知上层。  
 经过层调用最后到PhoneWindowManager的interceptKeyBeforeQueueing（）函数来做具体的业务处理。这是本文的重点，下面具体分析。  
 通过PowerManagerService来唤醒系统。


Power 按键处理  
 PhoneWindowManager的interceptKeyBeforeQueueing（）函数处理具体的业务逻辑，从这个函数开始进行分析。  
 按键的事件分为按下和抬起两个，framework的处理也是分为按下和抬起来不同的事件分别由不同的函数来处理。  
 在PhoneWindowManager中处理power键的事件及音量下键的事件,  
 截图时Power键为按下状态,所以去看power键的按下事件处理



### 3.1 PhoneWindowManager.java关于截图功能分析



```
 private void interceptPowerKeyDown(KeyEvent event, boolean interactive) {
        // Hold a wake lock until the power key is released.
        if (!mPowerKeyWakeLock.isHeld()) {
            mPowerKeyWakeLock.acquire();
        }

        // Cancel multi-press detection timeout.
        if (mPowerKeyPressCounter != 0) {
            mHandler.removeMessages(MSG_POWER_DELAYED_PRESS);
        }

        mWindowManagerFuncs.onPowerKeyDown(interactive);
        // 截图功能
        // Latch power key state to detect screenshot chord.
        if (interactive && !mScreenshotChordPowerKeyTriggered
                && (event.getFlags() & KeyEvent.FLAG_FALLBACK) == 0) {
            mScreenshotChordPowerKeyTriggered = true;
            mScreenshotChordPowerKeyTime = event.getDownTime();
            interceptScreenshotChord();
            interceptRingerToggleChord();
        }

        // Stop ringing or end call if configured to do so when power is pressed.
        TelecomManager telecomManager = getTelecommService();
        boolean hungUp = false;
        if (telecomManager != null) {
            if (telecomManager.isRinging()) {
                // Pressing Power while there's a ringing incoming
                // call should silence the ringer.
                telecomManager.silenceRinger();
            } else if ((mIncallPowerBehavior
                    & Settings.Secure.INCALL_POWER_BUTTON_BEHAVIOR_HANGUP) != 0
                    && telecomManager.isInCall() && interactive) {
                // Otherwise, if "Power button ends call" is enabled,
                // the Power button will hang up any current active call.
                hungUp = telecomManager.endCall();
            }
        }

interceptScreenshotChord();就是具体的截图功能
    private void interceptScreenshotChord() {
        if (mScreenshotChordEnabled
                && mScreenshotChordVolumeDownKeyTriggered && mScreenshotChordPowerKeyTriggered
                && !mA11yShortcutChordVolumeUpKeyTriggered) {
            final long now = SystemClock.uptimeMillis();
            if (now <= mScreenshotChordVolumeDownKeyTime + SCREENSHOT_CHORD_DEBOUNCE_DELAY_MILLIS
                    && now <= mScreenshotChordPowerKeyTime
                            + SCREENSHOT_CHORD_DEBOUNCE_DELAY_MILLIS) {
                mScreenshotChordVolumeDownKeyConsumed = true;
                if(hasInPowerUtrlSavingMode()){
                    Slog.d(TAG,"In power ULTRA saving mode: Do not allow to take screen shot");
                    return;
                }
                cancelPendingPowerKeyAction();
                mScreenshotRunnable.setScreenshotType(TAKE_SCREENSHOT_FULLSCREEN);
                mHandler.postDelayed(mScreenshotRunnable, getScreenshotChordLongPressDelay());
            }
        }
    }
    private class ScreenshotRunnable implements Runnable {
        private int mScreenshotType = TAKE_SCREENSHOT_FULLSCREEN;

        public void setScreenshotType(int screenshotType) {
            mScreenshotType = screenshotType;
        }

        @Override
        public void run() {
            mDefaultDisplayPolicy.takeScreenshot(mScreenshotType);
        }
    }

//向下调用至DisplayPolicy.java
public void takeScreenshot(int screenshotType, int source) {
        if (mScreenshotHelper != null) {
            mScreenshotHelper.takeScreenshot(screenshotType,
                    getStatusBar() != null && getStatusBar().isVisibleLw(),
                    getNavigationBar() != null && getNavigationBar().isVisibleLw(),
                    source, mHandler, null /* completionConsumer */);
        }
}
```

在上述的PhoneWindowManager.java的相关源码分析，得知在 interceptPowerKeyDown(KeyEvent event, boolean interactive)中，


这里通过ScreenshotHelper的takeScreenshot(）来截图 然后  
 通过TakeScreenshotService.java 截图最终由TakeScreenshotService调用GlobalScreenshot.java的takeScreenshot(）来完成截图功能


### 3.2 GlobalScreenshot.java截图代码分析



```
  /**
     * Takes a screenshot of the current display and shows an animation.
     */
    private void takeScreenshot(Runnable finisher, boolean statusBarVisible, boolean navBarVisible,
            Rect crop) {
        Log.d(TAG, "takeScreenshot");
        if (isInRegionOrLongshotMode(mResolver)) {
            Toast.makeText(mContext, R.string.long_screen_shot_tips, Toast.LENGTH_SHORT).show();
            finisher.run();
            return;
        }
        int rot = mDisplay.getRotation();
        int width = crop.width();
        int height = crop.height();

        // Take the screenshot
        mScreenBitmap = SurfaceControl.screenshot(crop, width, height, rot);
        if (mScreenBitmap == null) {
            notifyScreenshotError(mContext, mNotificationManager,
                    R.string.screenshot_failed_to_capture_text);
            finisher.run();
            return;
        }

        // Optimizations
        mScreenBitmap.setHasAlpha(false);
        mScreenBitmap.prepareToDraw();

        // Start the post-screenshot animation
        startAnimation(finisher, mDisplayMetrics.widthPixels, mDisplayMetrics.heightPixels,
                statusBarVisible, navBarVisible);
    }

    /* UNISOC: Modify for bug1418859 @{ */
    void takeScreenshot(Runnable finisher, boolean statusBarVisible, boolean navBarVisible) {
        mDisplay.getRealMetrics(mDisplayMetrics);
        int left = 0;
        int top = 0;
        int right = mDisplayMetrics.widthPixels;
        int bottom = mDisplayMetrics.heightPixels;
        if (OneHandModeUtil.isOneHandMode(mContext)) {
            Log.d(TAG, "takeScreenshot oneHand mDisplayMetrics = " + mDisplayMetrics);
            float scale = OneHandModeUtil.getOneHandModeScale();
            if (scale <= 0) {
                notifyScreenshotError(mContext, mNotificationManager,
                        R.string.screenshot_failed_to_capture_text);
                finisher.run();
                return;
            }
            top = (int) ((1 - scale) * bottom);
            if (OneHandModeUtil.isRightOneHandModeOrientation()) {
                left = (int) ((1 - scale) * right);
            } else {
                right = (int) (scale * right);
            }
            Log.d(TAG, "takeScreenshot oneHand left,top,right,bottom,scale = " + left + "," + right
                    + "," + top + "," + bottom + "," + scale);
        }
        takeScreenshot(finisher, statusBarVisible, navBarVisible,
                new Rect(left, top, right, bottom));
    }
```

在GlobalScreenshot.java的上述源码中分析得知，在对于屏幕截图的相关功能分析得知


最终由takeScreenshot(finisher, statusBarVisible, navBarVisible,  
                 new Rect(left, top, right, bottom)); 完成屏幕的截图功能，所以说


要去掉系统的截图功能，就需要从这里分析相关的截图代码来实现功能


### 3.3 去掉截图功能最终修改为:



```
 private void takeScreenshot(Runnable finisher, boolean statusBarVisible, boolean navBarVisible,
            Rect crop) {
        Log.d(TAG, "takeScreenshot");
        /*if (isInRegionOrLongshotMode(mResolver)) {
            Toast.makeText(mContext, R.string.long_screen_shot_tips, Toast.LENGTH_SHORT).show();
            finisher.run();
            return;
        }
        int rot = mDisplay.getRotation();
        int width = crop.width();
        int height = crop.height();

        // Take the screenshot
        mScreenBitmap = SurfaceControl.screenshot(crop, width, height, rot);
        if (mScreenBitmap == null) {
            notifyScreenshotError(mContext, mNotificationManager,
                    R.string.screenshot_failed_to_capture_text);
            finisher.run();
            return;
        }

        // Optimizations
        mScreenBitmap.setHasAlpha(false);
        mScreenBitmap.prepareToDraw();

        // Start the post-screenshot animation
        startAnimation(finisher, mDisplayMetrics.widthPixels, mDisplayMetrics.heightPixels,
                statusBarVisible, navBarVisible);*/
    }
注释掉整个代码

```

### 3.4 关于屏蔽截图命令的功能修改


   adb shell screencap -p 截图命令  
    在frameworks\base\cmds\screencap 文件夹下的screencap.cpp 就是执行截图命令的相关代码  
    它在系统编译后会在system/bin下会生成screencap 的bin文件  
   所以去掉这块代码 其实就是在screencap.cpp中的main方法注释掉即可



