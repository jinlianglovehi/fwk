



## 1.概述


在10.0的系统rom定制化开发中，在原生系统默认是三键导航，也可以切换到手势导航，当默认设置为手势导航时，底部导航栏home键布局就是一条黑线， 并且有一块黑色区域，app显示不能全屏显示，所以这就需要找到手势导航时导航栏布局相关的代码，来设置导航栏高度


## 2. 系统默认手势导航时设置导航栏高度为1dp功能实现的核心代码



```
    frameworks\base\packages\SystemUI\res\layout\home_handle.xml
     frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\phone\NavigationHandle.java
     frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java
     frameworks\base\packages\overlays\NavigationBarModeGesturalOverlay\res\values\dimens.xml

```

## 3.系统默认手势导航时设置导航栏高度为1dp功能实现以及功能分析


导航视图(NavigationView)通常与抽屉布局(DrawerLayout)结合使用,实现了良好的侧滑交互体验 NavigationBar 和 StatusBar 都属于 SystemBar，也叫做 decor，就是说给 App 装饰的意思。一般的 window 的 布局是在 PhoneWindowManager 的 layoutWindowLw() 方法中，而 SystemBar 是在 beginLayoutLw() 方法中布局。 在系统中，关于导航栏布局主要就是NavigationBarView.java，来实现相关的导航栏布局功能实现的 在NavigationBarView.java这个导航栏布局中，关于系统手势导航底部导航栏布局就是在NavigationHandle.java 中进行绘制的


## 3.1NavigationBarView.java关于手势导航的布局代码分析


在系统默认手势导航时设置导航栏高度为1dp功能实现中，通过上述的分析得知，在 NavigationBarView.java的核心源码主要就是通过构建导航栏布局来实现相关的导航栏功能的实现 接下来具体看下是如何构建导航栏布局的



```
  public class NavigationBarView extends FrameLayout implements
    NavigationModeController.ModeChangedListener {
    private final Region mTmpRegion = new Region();
    private final int[] mTmpPosition = new int[2];
    private Rect mTmpBounds = new Rect();
     
    private KeyButtonDrawable mBackIcon;
    private KeyButtonDrawable mHomeDefaultIcon;
    private KeyButtonDrawable mRecentIcon;
    private KeyButtonDrawable mDockedIcon;
     
  ....
     
    private NavigationBarInflaterView mNavigationInflaterView;
    private RecentsOnboarding mRecentsOnboarding;
    private NotificationPanelViewController mPanelView;
    private FloatingRotationButton mFloatingRotationButton;
    private RotationButtonController mRotationButtonController;
    private ScreenPinningNotify mScreenPinningNotify;
    private Rect mSamplingBounds = new Rect();

    @Nullable
    private Rect mOrientedHandleSamplingRegion;
     
    public NavigationBarView(Context context, AttributeSet attrs) {
    super(context, attrs);
     
    mIsVertical = false;
    mLongClickableAccessibilityButton = false;
    mNavBarMode = Dependency.get(NavigationModeController.class).addListener(this);
    boolean isGesturalMode = isGesturalMode(mNavBarMode);
     
    mSysUiFlagContainer = Dependency.get(SysUiState.class);
    mPluginManager = Dependency.get(PluginManager.class);
    // Set up the context group of buttons
    mContextualButtonGroup = new ContextualButtonGroup(R.id.menu_container);
    final ContextualButton imeSwitcherButton = new ContextualButton(R.id.ime_switcher,
    R.drawable.ic_ime_switcher_default);
    final RotationContextButton rotateSuggestionButton = new RotationContextButton(
    R.id.rotate_suggestion, R.drawable.ic_sysbar_rotate_button);
    final ContextualButton accessibilityButton =
    new ContextualButton(R.id.accessibility_button,
    R.drawable.ic_sysbar_accessibility_button);
    mContextualButtonGroup.addButton(imeSwitcherButton);
    if (!isGesturalMode) {
    mContextualButtonGroup.addButton(rotateSuggestionButton);
    }
    mContextualButtonGroup.addButton(accessibilityButton);
     
    mOverviewProxyService = Dependency.get(OverviewProxyService.class);
    mRecentsOnboarding = new RecentsOnboarding(context, mOverviewProxyService);
    mFloatingRotationButton = new FloatingRotationButton(context);
    mRotationButtonController = new RotationButtonController(context,
    R.style.RotateButtonCCWStart90,
    isGesturalMode ? mFloatingRotationButton : rotateSuggestionButton,
    mRotationButtonListener);
     
    mConfiguration = new Configuration();
    mTmpLastConfiguration = new Configuration();
    mConfiguration.updateFrom(context.getResources().getConfiguration());
     
    mScreenPinningNotify = new ScreenPinningNotify(mContext);
    mBarTransitions = new NavigationBarTransitions(this, Dependency.get(CommandQueue.class));
     
    mButtonDispatchers.put(R.id.back, new ButtonDispatcher(R.id.back));
    mButtonDispatchers.put(R.id.home, new ButtonDispatcher(R.id.home));
    mButtonDispatchers.put(R.id.home_handle, new ButtonDispatcher(R.id.home_handle));
    mButtonDispatchers.put(R.id.recent_apps, new ButtonDispatcher(R.id.recent_apps));
    mButtonDispatchers.put(R.id.ime_switcher, imeSwitcherButton);
    mButtonDispatchers.put(R.id.accessibility_button, accessibilityButton);
    mButtonDispatchers.put(R.id.rotate_suggestion, rotateSuggestionButton);
    mButtonDispatchers.put(R.id.menu_container, mContextualButtonGroup);
    mDeadZone = new DeadZone(this);
     
....
    }
```

在系统默认手势导航时设置导航栏高度为1dp功能实现中，通过上述的分析得知，在 NavigationBarView.java的核心源码中， 通过查看代码发现mButtonDispatchers.put(R.id.home\_handle, new ButtonDispatcher(R.id.home\_handle)); 就是手势导航时的底部home布局


## 3.2 查看home\_handle.xml的相关代码


在系统默认手势导航时设置导航栏高度为1dp功能实现中，通过上述的分析得知，在 NavigationBarView.java的核心源码中，home\_handle.xml主要就是构建手势导航底部home键的布局， 其实就是NavigationHandle中构建布局的



```
 <com.android.systemui.statusbar.phone.NavigationHandle
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/home_handle"
    android:layout_width="@dimen/navigation_home_handle_width"
    android:layout_height="match_parent"
    android:layout_weight="0"
    android:contentDescription="@string/accessibility_home"
    android:paddingStart="@dimen/navigation_key_padding"
    android:paddingEnd="@dimen/navigation_key_padding"
    />
```

从布局中看到正在的绘制在NavigationHandle中


## 3.3 NavigationHandle中关于Home布局的相关代码


在系统默认手势导航时设置导航栏高度为1dp功能实现中，通过上述的分析得知，在 NavigationHandle.java的核心源码中，核心功能就是构建手势导航底部home键的布局，接下来具体看构建的 导航栏布局源码分析



```
 public class NavigationHandle extends View implements ButtonInterface {
     
    protected final Paint mPaint = new Paint();
    private @ColorInt final int mLightColor;
    private @ColorInt final int mDarkColor;
    protected final int mRadius;
    protected final int mBottom;
    private boolean mRequiresInvalidate;
     
    public NavigationHandle(Context context) {
    this(context, null);
    }
     
    public NavigationHandle(Context context, AttributeSet attr) {
    super(context, attr);
    final Resources res = context.getResources();
    mRadius = res.getDimensionPixelSize(R.dimen.navigation_handle_radius);
    mBottom = res.getDimensionPixelSize(R.dimen.navigation_handle_bottom);
     
    final int dualToneDarkTheme = Utils.getThemeAttr(context, R.attr.darkIconTheme);
    final int dualToneLightTheme = Utils.getThemeAttr(context, R.attr.lightIconTheme);
    Context lightContext = new ContextThemeWrapper(context, dualToneLightTheme);
    Context darkContext = new ContextThemeWrapper(context, dualToneDarkTheme);
    mLightColor = Utils.getColorAttrDefaultColor(lightContext, R.attr.homeHandleColor);
    mDarkColor = Utils.getColorAttrDefaultColor(darkContext, R.attr.homeHandleColor);
    mPaint.setAntiAlias(true);
    setFocusable(false);
    }
     
    @Override
    public void setAlpha(float alpha) {
    super.setAlpha(alpha);
    if (alpha > 0f && mRequiresInvalidate) {
    mRequiresInvalidate = false;
    invalidate();
    }
    }
     
    @Override
    protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
     
    // Draw that bar
    int navHeight = getHeight();
    int height = mRadius * 2;
    int width = getWidth();
    int y = (navHeight - mBottom - height);
    canvas.drawRoundRect(0, y, width, y + height, mRadius, mRadius, mPaint);
    }
```

在系统默认手势导航时设置导航栏高度为1dp功能实现中，通过上述的分析得知，在 NavigationHandle.java的核心源码中， 代码中发现protected void onDraw(Canvas canvas)负责绘制手势导航Home布局 而具体的导航栏高度设置就是在 frameworks\base\packages\overlays\NavigationBarModeGesturalOverlay\res\values\dimens.xml 中，而对于导航栏底部高度就是mBottom的值，所以具体修改为:



```
--- a/frameworks/base/packages/apps/SystemUI/res/values/dimens.xml
+++ b/frameworks/base/packages/apps/SystemUI/res/values/dimens.xml
@@ -36,7 +36,7 @@
 
     <!-- dimensions for the navigation bar handle -->
     <dimen name="navigation_handle_radius">1dp</dimen>
-    <dimen name="navigation_handle_bottom">6dp</dimen>
+    <dimen name="navigation_handle_bottom">1dp</dimen>
     <dimen name="navigation_handle_horizontal_margin">30dp</dimen>
     <dimen name="navigation_handle_sample_horizontal_margin">10dp</dimen>
     <dimen name="navigation_home_handle_width">72dp</dimen>
--- a/frameworks/base/packages/overlays/NavigationBarModeGesturalOverlay/res/values/dimens.xml
+++ b/frameworks/base/packages/overlays/NavigationBarModeGesturalOverlay/res/values/dimens.xml
@@ -18,9 +18,9 @@
 -->
 <resources>
     <!-- Height of the bottom navigation / system bar. -->
-    <dimen name="navigation_bar_height">16dp</dimen>
+    <dimen name="navigation_bar_height">1dp</dimen>
     <!-- Height of the bottom navigation bar in portrait; often the same as @dimen/navigation_bar_height -->
-    <dimen name="navigation_bar_height_landscape">16dp</dimen>
+    <dimen name="navigation_bar_height_landscape">1dp</dimen>
     <!-- Width of the navigation bar when it is placed vertically on the screen -->
     <dimen name="navigation_bar_width">16dp</dimen>
     <!-- Height of the bottom navigation / system bar. -->
```

在系统默认手势导航时设置导航栏高度为1dp功能实现中，通过上述的分析得知，在 NavigationHandle.java的核心源码中，通过上述的修改navigation\_bar\_height和 navigation\_handle\_bottom来最终实现手势导航高度为1dp的功能，就是上述图片的效果



