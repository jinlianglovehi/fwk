






对于SystemUI 状态栏的定制也是非常多的，最近有需求要求在下拉状态栏时，背景去掉原来的灰色，改为透明色  
 所以就要从状态栏下拉中，找到灰色背景是怎么生成的


接下来先看下  
 StatusBar  
 从相关的布局文件xml中可以找到状态栏主要的Layout：  
 SystemUI下拉通知栏的布局为super\_status\_bar.xml



```
<!-- This is the combined status bar / notification panel window. -->
<com.android.systemui.statusbar.phone.StatusBarWindowView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:fitsSystemWindows="true">

    <com.android.systemui.statusbar.BackDropView
            android:id="@+id/backdrop"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent"
            android:visibility="gone"
            >
        <ImageView android:id="@+id/backdrop\_back"
                   android:layout_width="match\_parent"
                   android:scaleType="centerCrop"
                   android:layout_height="match\_parent" />
        <ImageView android:id="@+id/backdrop\_front"
                   android:layout_width="match\_parent"
                   android:layout_height="match\_parent"
                   android:scaleType="centerCrop"
                   android:visibility="invisible" />
    </com.android.systemui.statusbar.BackDropView>

    <com.android.systemui.statusbar.ScrimView android:id="@+id/scrim\_behind"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:importantForAccessibility="no" />

    <include layout="@layout/status\_bar"
        android:layout_width="match\_parent"
        android:layout_height="@dimen/status\_bar\_height" />

    <FrameLayout android:id="@+id/brightness\_mirror"
                 android:layout_width="@dimen/notification\_panel\_width"
                 android:layout_height="wrap\_content"
                 android:layout_gravity="@integer/notification\_panel\_layout\_gravity"
                 android:paddingLeft="@dimen/notification\_side\_padding"
                 android:paddingRight="@dimen/notification\_side\_padding"
                 android:visibility="gone">
        <FrameLayout
                android:layout_width="match\_parent"
                android:layout_height="match\_parent"
                android:elevation="2dp"
                android:background="@drawable/brightness\_mirror\_background">
            <include layout="@layout/quick\_settings\_brightness\_dialog"
                     android:layout_width="match\_parent"
                     android:layout_height="wrap\_content" />
        </FrameLayout>
    </FrameLayout>

    <com.android.systemui.statusbar.phone.PanelHolder
        android:id="@+id/panel\_holder"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:background="@color/transparent" >
        <include layout="@layout/status\_bar\_expanded"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent"
            android:visibility="gone" />
    </com.android.systemui.statusbar.phone.PanelHolder>

    <com.android.systemui.statusbar.ScrimView android:id="@+id/scrim\_in\_front"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:importantForAccessibility="no" />

</com.android.systemui.statusbar.phone.StatusBarWindowView>

```

分析如下:  
 1 StatusBarWindowView是状态栏根布局  
 2 BackDropView  
 3 ScrimView是状态栏下拉后，背景，半透明灰色  
 4 status\_bar状态栏的布局  
 5 PanelHolder，下拉通知栏布局


所以说具体来看ScrimView.java  
 路径为: /framework/base/packages/SystemUI/src/com/android/systemui/statusbar/ScrimView.java



```
    @Override
    protected void onDraw(Canvas canvas) {
        if (mDrawable.getAlpha() > 0) {
            mDrawable.draw(canvas);
        }
    }
 绘制背景

    /**
     * It might look counterintuitive to have another method to set the alpha instead of
     * only using {@link #setAlpha(float)}. In this case we're in a hardware layer
     * optimizing blend modes, so it makes sense.
     *
     * @param alpha Gradient alpha from 0 to 1.
     */
    public void setViewAlpha(float alpha) {
        if (alpha != mViewAlpha) {
            mViewAlpha = alpha;

            mDrawable.setAlpha((int) (255 \* alpha));
            if (mChangeRunnable != null) {
                mChangeRunnable.run();
            }
        }
    }

```

public void setViewAlpha(float alpha) 即为设置透明度


所以要设置无透明就在这里修改就可以了 修改为:



```
     public void setViewAlpha(float alpha) {
         if (alpha != mViewAlpha) {
-            mViewAlpha = alpha;
+            alpha = 0;
+            mViewAlpha = 0;
+           //mViewAlpha = alpha;
             if (mAlphaAnimator != null) {
                 mAlphaAnimator.cancel();
             } 

```




