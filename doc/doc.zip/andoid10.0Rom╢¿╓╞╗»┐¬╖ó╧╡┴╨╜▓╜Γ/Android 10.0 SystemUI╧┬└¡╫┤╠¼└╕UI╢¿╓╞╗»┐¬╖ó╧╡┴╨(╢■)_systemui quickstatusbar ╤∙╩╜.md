






定制化开发系列(二) 接下来对下拉状态栏中的 日期时间显示的定制  
 由于客户需求只显示日期和时间，其他图标就不需要显示了


从上篇文章中可以得知quick\_qs\_status\_icons.xml 就是日期和状态栏其他图标的显示布局  
 而时间是在quick\_status\_bar\_header\_system\_icons.xml中时钟控件显示的  
 所以就需要把原生的时间控件隐藏掉 在quick\_qs\_status\_icons.xml 中的 DateView控件来负责  
 显示日期和时间


布局文件修改为:



```
--- a/frameworks/base/packages/SystemUI/res/layout/quick_status_bar_header_system_icons.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/quick_status_bar_header_system_icons.xml
@@ -19,10 +19,11 @@
     xmlns:systemui="http://schemas.android.com/apk/res-auto"
     android:id="@+id/quick\_status\_bar\_system\_icons"
     android:layout_width="match\_parent"
-    android:layout_height="@\*android:dimen/quick\_qs\_offset\_height"
+    android:layout_height="0dp"
     android:clipChildren="false"
     android:clipToPadding="false"
     android:orientation="horizontal"
+       android:visibility="gone"
     android:clickable="true"
     android:paddingStart="@dimen/status\_bar\_padding\_start"
     android:paddingEnd="@dimen/status\_bar\_padding\_end" >

--- a/frameworks/base/packages/SystemUI/res/layout/quick_qs_status_icons.xml
+++ b/frameworks/base/packages/SystemUI/res/layout/quick_qs_status_icons.xml
@@ -19,26 +19,25 @@
     android:id="@+id/quick\_qs\_status\_icons"
     android:layout_width="match\_parent"
     android:layout_height="wrap\_content"
-    android:paddingTop="@dimen/qs\_header\_top\_padding"
-    android:paddingBottom="@dimen/qs\_header\_bottom\_padding"
+    android:layout_marginTop="@\*android:dimen/quick\_qs\_offset\_height"
+    android:paddingTop="0dp"
+    android:paddingBottom="0dp"
     android:paddingStart="@dimen/status\_bar\_padding\_start"
     android:paddingEnd="@dimen/status\_bar\_padding\_end"
-    android:layout_below="@id/quick\_status\_bar\_system\_icons"
     android:clipChildren="false"
     android:clipToPadding="false"
-    android:minHeight="20dp"
+    android:minHeight="15dp"
     android:clickable="false"
     android:focusable="true"
     android:theme="@style/QSHeaderTheme">
-
     <com.android.systemui.statusbar.policy.DateView
         android:id="@+id/date"
         android:layout_width="wrap\_content"
         android:layout_height="wrap\_content"
         android:layout_gravity="start|center\_vertical"
-        android:gravity="center\_vertical"
-        android:singleLine="true"
-        android:textAppearance="@style/TextAppearance.QS.Status"
+               android:layout_marginTop="1dp"
+               android:layout_marginLeft="@dimen/navigation\_bar\_deadzone\_size"
+        android:gravity="left|center\_vertical"
         systemui:datePattern="@string/abbrev\_wday\_month\_day\_no\_year\_alarm" />
 
     <com.android.systemui.statusbar.phone.StatusIconContainer
@@ -46,12 +45,14 @@
         android:layout_width="0dp"
         android:layout_height="match\_parent"
         android:layout_weight="1"
+        android:visibility="gone"
         android:paddingEnd="@dimen/signal\_cluster\_battery\_padding" />
 
     <com.android.systemui.BatteryMeterView
         android:id="@+id/batteryRemainingIcon"
         android:layout_height="match\_parent"
         android:layout_width="wrap\_content"
+        android:visibility="gone"
         systemui:textAppearance="@style/TextAppearance.QS.Status"
         android:paddingEnd="2dp" />

```

接下来针对com.android.systemui.statusbar.policy.DateView 的时间日期样式做修改



```
   <com.android.systemui.statusbar.policy.DateView
        android:id="@+id/date"
        android:layout_width="wrap\_content"
        android:layout_height="wrap\_content"
        android:layout_gravity="start|center\_vertical"
        android:gravity="center\_vertical"
        android:singleLine="true"
        android:textAppearance="@style/TextAppearance.QS.Status"
        systemui:datePattern="@string/abbrev\_wday\_month\_day\_no\_year\_alarm" />

```

systemui:datePattern=“@string/abbrev\_wday\_month\_day\_no\_year\_alarm” 就是显示时间的格式  
 而他定义在donottranslate.xml  
 路径:frameworks\base\packages\SystemUI\res-keyguard\values\donottranslate.xml



```
<resources xmlns:xliff="urn:oasis:names:tc:xliff:document:1.2">
    <!-- Skeleton string format for displaying the date. -->
    <string name="abbrev\_wday\_month\_day\_no\_year">EEEEMMMMd</string>

    <!-- Skeleton string format for displaying the date when an alarm is set. -->
    <string name="abbrev\_wday\_month\_day\_no\_year\_alarm">eeeMMMMd</string>

    <!-- Skeleton string format for displaying the time in 12-hour format. -->
    <string name="clock\_12hr\_format">hm</string>

    <!-- Skeleton string format for displaying the time in 24-hour format. -->
    <string name="clock\_24hr\_format">Hm</string>
</resources>

```

修改时间格式为:



```
 <string name="abbrev\_wday\_month\_day\_no\_year\_alarm">YYYYeeeMMMMd HH:mm</string>

```

接下来看更新时间DateView.java的相关源码



```
frameworks\base\packages\SystemUI\src\com\android\systemui\statusbar\policy\DateView.java
private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (Intent.ACTION_TIME_TICK.equals(action)
                    || Intent.ACTION_TIME_CHANGED.equals(action)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                    || Intent.ACTION_LOCALE_CHANGED.equals(action)) {
                if (Intent.ACTION_LOCALE_CHANGED.equals(action)
                        || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
                    // need to get a fresh date format
                    getHandler().post(() -> mDateFormat = null);
 }
 getHandler().post(() -> updateClock());
            }
        }
    };

    public DateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.DateView,
                0, 0);

        try {
            mDatePattern = a.getString(R.styleable.DateView_datePattern);
        } finally {
            a.recycle();
        }
        if (mDatePattern == null) {
            mDatePattern = getContext().getString(R.string.abbrev_wday_month_day_no_year_alarm);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_TIME_TICK);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        filter.addAction(Intent.ACTION_LOCALE_CHANGED);
        getContext().registerReceiver(mIntentReceiver, filter, null,
                Dependency.get(Dependency.TIME_TICK_HANDLER));

        updateClock();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mDateFormat = null; // reload the locale next time
        getContext().unregisterReceiver(mIntentReceiver);
    }

    protected void updateClock() {
        if (mDateFormat == null) {
            final Locale l = Locale.getDefault();
            DateFormat format = DateFormat.getInstanceForSkeleton(mDatePattern, l);
            format.setContext(DisplayContext.CAPITALIZATION_FOR_STANDALONE);
            mDateFormat = format;
        }

        mCurrentTime.setTime(System.currentTimeMillis());

        final String text = mDateFormat.format(mCurrentTime);
        if (!text.equals(mLastText)) {
            setText(text);
            mLastText = text;
        }
    }

```

在updateClock()的时间格式是由mDatePattern来决定的 mDatePattern是在构造方法中定义的  
 所以修改mDatePattern 为:



```
if (mDatePattern == null) {
 -   mDatePattern = getContext().getString(R.string.system_ui_date_pattern);
 +   mDatePattern = getContext().getString(R.string.abbrev_wday_month_day_no_year_alarm);
}

```

由于需求要求时间和日期分两行显示 所以要借助SpannableString的相关api来实现



```
 SpannableString ss = new SpannableString(text);
    //设置显示字体大小

    AbsoluteSizeSpan ass = new AbsoluteSizeSpan(20,true);
   //从哪个文字开始设置字体大小

    ss.setSpan(ass, 0, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

               AbsoluteSizeSpan ass2 = new AbsoluteSizeSpan(14,true);
    ss.setSpan(ass2, 5, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    setText(ss, TextView.BufferType.SPANNABLE);



而DateView 中updateClock() 来负责更新时间

protected void updateClock() {
        if (mDateFormat == null) {
            final Locale l = Locale.getDefault();
            DateFormat format = DateFormat.getInstanceForSkeleton(mDatePattern, l);
            format.setContext(DisplayContext.CAPITALIZATION_FOR_STANDALONE);
            mDateFormat = format;
        }

        mCurrentTime.setTime(System.currentTimeMillis());
        String text = mDateFormat.format(mCurrentTime);
        if (!text.equals(mLastText)) {
            setText(text);
            mLastText = text;
        }
    }



所以具体修改显示时间的样式 就是在这里修改即可

--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/DateView.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/DateView.java
@@ -26,13 +26,16 @@ import android.icu.text.DisplayContext;
 import android.text.TextUtils;
 import android.util.AttributeSet;
 import android.widget.TextView;
-
+import android.content.res.Configuration;
 import com.android.systemui.Dependency;
 import com.android.systemui.R;
-
+import android.widget.RelativeLayout;
 import java.util.Date;
 import java.util.Locale;
-
+import android.text.SpannableString;
+import android.text.Spanned;
+import android.text.SpannedString;
+import android.text.style.AbsoluteSizeSpan;
 public class DateView extends TextView {
     private static final String TAG = "DateView";
 
@@ -73,8 +76,9 @@ public class DateView extends TextView {
             a.recycle();
         }
         if (mDatePattern == null) {
-            mDatePattern = getContext().getString(R.string.system_ui_date_pattern);
+            mDatePattern = getContext().getString(R.string.abbrev_wday_month_day_no_year_alarm);
         }
+
     }
 
     @Override
@@ -110,9 +114,18 @@ public class DateView extends TextView {
 
         mCurrentTime.setTime(System.currentTimeMillis());
 
-        final String text = mDateFormat.format(mCurrentTime);
+        String text = mDateFormat.format(mCurrentTime);
+        String [] date_txt = text.split(" ");
+        if(date_txt!=null&&date_txt.length>=2){
+                   text = date_txt[1]+"\n"+date_txt[0].replace("周"," 星期");
+        }
         if (!text.equals(mLastText)) {
-            setText(text);
+                   SpannableString ss = new SpannableString(text);
+            AbsoluteSizeSpan ass = new AbsoluteSizeSpan(20,true);
+            StyleSpan styleSpan_B  = new StyleSpan(Typeface.BOLD);
+            ss.setSpan(styleSpan_B, 0, 5, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
+            ss.setSpan(ass, 0, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
+                       AbsoluteSizeSpan ass2 = new AbsoluteSizeSpan(14,true);
+            ss.setSpan(ass2, 5, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
+            setText(ss, TextView.BufferType.SPANNABLE);
             mLastText = text;
         }
     }

```




