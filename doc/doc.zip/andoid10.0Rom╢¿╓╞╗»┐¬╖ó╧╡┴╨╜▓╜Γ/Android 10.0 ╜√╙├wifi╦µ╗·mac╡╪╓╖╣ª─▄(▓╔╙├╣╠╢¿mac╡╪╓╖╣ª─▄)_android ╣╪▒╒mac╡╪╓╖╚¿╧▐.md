






### 1.概述


Android 8.0 开始，Android 设备在未连接到网络的情况下探测新网络时会使用随机 MAC 地址，但是这样会导致在ota升级时，由于wifi的mac地址不固定导致会升级失败的风险 所以产品需求要求wifi的mac地址固定，不让mac地址变动，防止ota升级失败


### 2.禁用wifi随机mac地址功能(采用固定mac地址功能)核心类



```
frameworks/base/core/res/res/values/config.xml
packages/apps/Settings/src/com/android/settings/wifi/WifiConfigController.java

```

### 3.禁用wifi随机mac地址功能(采用固定mac地址功能)核心功能实现和分析


此标志用于控制是否启用客户端模式随机分配 MAC 地址功能。  
 在“设置”config.xml 中，将 config\_wifi\_p2p\_mac\_randomization\_supported 设置为 true(此步骤可在设备自定义叠加层中完成)。  
 此标志用于控制是否启用 WLAN 直连随机分配 MAC 地址功能。  
 根据文档发现是由config\_wifi\_support\_connected\_mac\_randomization 这个config.xml的属性值来设置是否随机产生mac地址


所以搜索framework/base 下发现



```
core/res/res/values/config.xml:750:    <bool translatable="false" name="config\_wifi\_connected\_mac\_randomization\_supported">true</bool>

```

默认为ture 修改为false  
 编译以后发现 还是会随机产生mac地址 应该是被覆盖掉了


所以就全局搜索发现:



```
device/google/wahoo/overlay/frameworks/base/core/res/res/values/config.xml:370:    <bool name="config\_wifi\_connected\_mac\_randomization\_supported">true</bool>
device/google/crosshatch/overlay/frameworks/base/core/res/res/values/config.xml:449:    <bool name="config\_wifi\_connected\_mac\_randomization\_supported">true</bool>
device/google/bonito/overlay/frameworks/base/core/res/res/values/config.xml:412:    <bool name="config\_wifi\_connected\_mac\_randomization\_supported">true</bool>

```

发现这里也是有这个属性  
 于是把这几个全部设置为false；发现wifi 的mac地址就不会在随机生成了


2.在Settings中代码具体修改部分为:  
 对于像mac地址这里的config管理都是在WifiConfigController.java中进行管理的  
 接下来看下相关的代码分析问题



```
public class WifiConfigController implements TextWatcher,
          AdapterView.OnItemSelectedListener, OnCheckedChangeListener,
          TextView.OnEditorActionListener, View.OnKeyListener {
		  public WifiConfigController(WifiConfigUiBase parent, View view, AccessPoint accessPoint,
              int mode) {
          mConfigUi = parent;
  
          mView = view;
          mAccessPoint = accessPoint;
          mContext = mConfigUi.getContext();
  
          // Init Wi-Fi manager
          mWifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
          initWifiConfigController(accessPoint, mode);
      }
  
      @VisibleForTesting
      public WifiConfigController(WifiConfigUiBase parent, View view, AccessPoint accessPoint,
              int mode, WifiManager wifiManager) {
          mConfigUi = parent;
  
          mView = view;
          mAccessPoint = accessPoint;
          mContext = mConfigUi.getContext();
          mWifiManager = wifiManager;
          initWifiConfigController(accessPoint, mode);
      }
  
      private void initWifiConfigController(AccessPoint accessPoint, int mode) {
  
          mAccessPointSecurity = (accessPoint == null) ? AccessPoint.SECURITY_NONE :
                  accessPoint.getSecurity();
          mMode = mode;
  
          final Resources res = mContext.getResources();
  
          mLevels = res.getStringArray(R.array.wifi_signal);
          if (Utils.isWifiOnly(mContext) || !mContext.getResources().getBoolean(
                  com.android.internal.R.bool.config_eap_sim_based_auth_supported)) {
              mPhase2PeapAdapter = new ArrayAdapter<String>(
                      mContext, android.R.layout.simple_spinner_item,
                      res.getStringArray(R.array.wifi_peap_phase2_entries));
          } else {
              mPhase2PeapAdapter = new ArrayAdapter<String>(
                      mContext, android.R.layout.simple_spinner_item,
                      res.getStringArray(R.array.wifi_peap_phase2_entries_with_sim_auth));
          }
          mPhase2PeapAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  
          mPhase2FullAdapter = new ArrayAdapter<String>(
                  mContext, android.R.layout.simple_spinner_item,
                  res.getStringArray(R.array.wifi_phase2_entries));
          mPhase2FullAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  ...
          if (mContext.getResources().getBoolean(
                  com.android.internal.R.bool.config_wifi_connected_mac_randomization_supported)) {
              View privacySettingsLayout = mView.findViewById(R.id.privacy_settings_fields);
              privacySettingsLayout.setVisibility(View.VISIBLE);
          }
          mHiddenSettingsSpinner.setOnItemSelectedListener(this);
          mHiddenWarningView = mView.findViewById(R.id.hidden_settings_warning);
          mHiddenWarningView.setVisibility(
                  mHiddenSettingsSpinner.getSelectedItemPosition() == NOT_HIDDEN_NETWORK
                          ? View.GONE
                          : View.VISIBLE);
          mSecurityInPosition = new Integer[AccessPoint.SECURITY_MAX_VAL];
  
          if (mAccessPoint == null) { // new network
              configureSecuritySpinner();
              mConfigUi.setSubmitButton(res.getString(R.string.wifi_save));
              mPasswordScanButton.setVisibility(View.GONE);
          } else {
              mConfigUi.setTitle(mAccessPoint.getTitle());
  
              ViewGroup group = (ViewGroup) mView.findViewById(R.id.info);
  
              boolean showAdvancedFields = false;
              if (mAccessPoint.isSaved()) {
                  WifiConfiguration config = mAccessPoint.getConfig();
                  mMeteredSettingsSpinner.setSelection(config.meteredOverride);
                  mHiddenSettingsSpinner.setSelection(config.hiddenSSID
                          ? HIDDEN_NETWORK
                          : NOT_HIDDEN_NETWORK);
  
                  final int prefMacValue =
                          WifiPrivacyPreferenceController.translateMacRandomizedValueToPrefValue(
                                  config.macRandomizationSetting);
                  mPrivacySettingsSpinner.setSelection(prefMacValue);
  ....
              }
           }
      }

```

在Wifi详情页面的wifi的mac地址部分有随机mac地址和固定mac地址的选择，所以需要默认设置为固定  
 mac地址，在WifiConfigController.java的 initWifiConfigController中初始化的时候设置选择为默认1  
 然后在选择改变的时候同样也是设置为1，具体修改为:



```
diff --git a/packages/apps/Settings/src/com/android/settings/wifi/WifiConfigController.java b/packages/apps/Settings/src/com/android/settings/wifi/WifiConfigController.java
old mode 100644 (file)
new mode 100755 (executable)
index 88f6c3e..9baa158
--- a/packages/apps/Settings/src/com/android/settings/wifi/WifiConfigController.java
+++ b/packages/apps/Settings/src/com/android/settings/wifi/WifiConfigController.java
@@ -449,7 +449,7 @@ public class WifiConfigController implements TextWatcher,
         if (!isSplitSystemUser()) {
             mSharedCheckBox.setVisibility(View.GONE);
         }
-
+        mPrivacySettingsSpinner.setSelection(1);
         mConfigUi.setCancelButton(res.getString(R.string.wifi_cancel));
         if (mConfigUi.getSubmitButton() != null) {
             enableSubmitIfAppropriate();

--- a/packages/apps/Settings/src/com/android/settings/wifi/details/WifiPrivacyPreferenceController.java
+++ b/packages/apps/Settings/src/com/android/settings/wifi/details/WifiPrivacyPreferenceController.java
@@ -92,8 +92,9 @@ public class WifiPrivacyPreferenceController extends BasePreferenceController im
 
     @Override
     public boolean onPreferenceChange(Preference preference, Object newValue) {
+               android.util.Log.e("privacy","newValue："+(String) newValue);
         if (mWifiConfiguration != null) {
-            mWifiConfiguration.macRandomizationSetting = Integer.parseInt((String) newValue);
+ mWifiConfiguration.macRandomizationSetting = 1/\*Integer.parseInt((String) newValue)\*/;
 mWifiManager.updateNetwork(mWifiConfiguration);
 
 // To activate changing, we need to reconnect network. WiFi will auto connect to
@@ -103,7 +104,7 @@ public class WifiPrivacyPreferenceController extends BasePreferenceController im
 mWifiManager.disconnect();
 }
 }
- updateSummary((DropDownPreference) preference, Integer.parseInt((String) newValue));
+        updateSummary((DropDownPreference) preference, 1/*Integer.parseInt((String) newValue)*/);
         return true;
     }
 
@@ -125,8 +126,8 @@ public class WifiPrivacyPreferenceController extends BasePreferenceController im
      * @return index value of preference
      */
     public static int translateMacRandomizedValueToPrefValue(int macRandomized) {
-        return (macRandomized == WifiConfiguration.RANDOMIZATION_PERSISTENT)
-            ? PREF_RANDOMIZATION_PERSISTENT : PREF_RANDOMIZATION_NONE;
+        return 1/*(macRandomized == WifiConfiguration.RANDOMIZATION_PERSISTENT)
+            ? PREF_RANDOMIZATION_PERSISTENT : PREF_RANDOMIZATION_NONE*/;
     }
 
     /**

```




