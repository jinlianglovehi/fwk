






### 1.概述


在10.0的系统产品开发中，关于SystemUI导航栏的布局，增加新的虚拟按键功能,所以就来看SystemUI中如何添加导航栏的流程，然后在添加虚拟按键


### 2.SystemUI导航栏 添加虚拟按键(一)的核心类



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarInflaterView.java
frameworks/base/packages/SystemUI/res/values/config_ex.xml

```

### 3.SystemUI导航栏 添加虚拟按键(一)的核心功能分析和实现


在SystemUI导航栏中，关于导航栏的布局就是在NavigationBarInflaterView.java中布局的，接下来看下NavigationBarInflaterView.java的相关源码  
 路径:  
 frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarInflaterView.java


### 3.1 导航栏布局资源



```
    private String readLNavigationLayoutSettings() {
        String navLayoutSetting;
        /*UNISOC: add for bug 1001981 @{*/
        int lastNavBarMode = Settings.System.getIntForUser(
                mContext.getContentResolver(), "navigationbar\_config", 0, ActivityManager.getCurrentUser());
        /*}@*/
        switch (lastNavBarMode & 0x0F) {
        case NAVIGATION_RIGHT:
            navLayoutSetting = mContext
                    .getString(R.string.config_navBarLayout_right);
            break;
        case NAVIGATION_LEFT:
            navLayoutSetting = mContext
                    .getString(R.string.config_navBarLayout_left);
            break;
        case NAVIGATION_RIGHT_NOTI:
            navLayoutSetting = mContext
                    .getString(R.string.config_navBarLayout_right_noti);
            break;
        case NAVIGATION_LEFT_NOTI:
            navLayoutSetting = mContext
                    .getString(R.string.config_navBarLayout_left_noti);
            break;
        default:
            navLayoutSetting = mContext
                    .getString(R.string.config_navBarLayout_default);
            break;
        }
        Log.d(TAG, "navLayoutSetting = " + navLayoutSetting);
        return navLayoutSetting;
    }

```

通过readLNavigationLayoutSettings()这个导航栏布局的相关打印 navLayoutSetting 得知 布局文件是R.string.config\_navBarLayout\_right  
 即:frameworks/base/packages/SystemUI/res/values/config\_ex.xml 的hide[.5W],back[1WC];home;recent[1WC],menu\_ime[.5W]


### 3.2 SystemUI状态栏布局虚拟按键的加载


接下来对加载导航栏虚拟按键的对应布局分析



```
protected void inflateLayout(String newLayout) {
        mCurrentLayout = newLayout;
        if (newLayout == null) {
            newLayout = getDefaultLayout();
        }
        String[] sets = newLayout.split(GRAVITY_SEPARATOR, 3);
        if (sets.length != 3) {
            Log.d(TAG, "Invalid layout.");
            newLayout = getDefaultLayout();
            sets = newLayout.split(GRAVITY_SEPARATOR, 3);
        }
        String[] start = sets[0].split(BUTTON_SEPARATOR);
        String[] center = sets[1].split(BUTTON_SEPARATOR);
        String[] end = sets[2].split(BUTTON_SEPARATOR);
        // Inflate these in start to end order or accessibility traversal will be messed up.
        inflateButtons(start, mHorizontal.findViewById(R.id.ends_group),
                false /* landscape */, true /* start */);
        inflateButtons(start, mVertical.findViewById(R.id.ends_group),
                true /* landscape */, true /* start */);

        inflateButtons(center, mHorizontal.findViewById(R.id.center_group),
                false /* landscape */, false /* start */);
        inflateButtons(center, mVertical.findViewById(R.id.center_group),
                true /* landscape */, false /* start */);

        addGravitySpacer(mHorizontal.findViewById(R.id.ends_group));
        addGravitySpacer(mVertical.findViewById(R.id.ends_group));

        inflateButtons(end, mHorizontal.findViewById(R.id.ends_group),
                false /* landscape */, false /* start */);
        inflateButtons(end, mVertical.findViewById(R.id.ends_group),
                true /* landscape */, false /* start */);

        updateButtonDispatchersCurrentView();
    }

```

在inflateLayout(String newLayout)中  
 这里会根据navLayoutSetting中，对应的虚拟按键的字符代表的布局来加载 导航栏的虚拟按键图标



```
@Nullable
    protected View inflateButton(String buttonSpec, ViewGroup parent, boolean landscape,
            boolean start) {
        LayoutInflater inflater = landscape ? mLandscapeInflater : mLayoutInflater;
        View v = createView(buttonSpec, parent, inflater);
        if (v == null) return null;
        v = applySize(v, buttonSpec, landscape, start);
        parent.addView(v);
        addToDispatchers(v);
        View lastView = landscape ? mLastLandscape : mLastPortrait;
        View accessibilityView = v;
        if (v instanceof ReverseRelativeLayout) {
            accessibilityView = ((ReverseRelativeLayout) v).getChildAt(0);
 }
 if (lastView != null) {
 accessibilityView.setAccessibilityTraversalAfter(lastView.getId());
        }
        if (landscape) {
            mLastLandscape = accessibilityView;
        } else {
            mLastPortrait = accessibilityView;
        }
        return v;
    }
  // 计算导航栏图标的大小
    private View applySize(View v, String buttonSpec, boolean landscape, boolean start) {
        String sizeStr = extractSize(buttonSpec);
        if (sizeStr == null) return v;

        if (sizeStr.contains(WEIGHT_SUFFIX) || sizeStr.contains(ABSOLUTE_SUFFIX)) {
            // To support gravity, wrap in RelativeLayout and apply gravity to it.
            // Children wanting to use gravity must be smaller then the frame.
            ReverseRelativeLayout frame = new ReverseRelativeLayout(mContext);
            LayoutParams childParams = new LayoutParams(v.getLayoutParams());

            // Compute gravity to apply
            int gravity = (landscape) ? (start ? Gravity.TOP : Gravity.BOTTOM)
                    : (start ? Gravity.START : Gravity.END);
            if (sizeStr.endsWith(WEIGHT_CENTERED_SUFFIX)) {
                gravity = Gravity.CENTER;
            } else if (sizeStr.endsWith(ABSOLUTE_VERTICAL_CENTERED_SUFFIX)) {
                gravity = Gravity.CENTER_VERTICAL;
            }

            // Set default gravity, flipped if needed in reversed layouts (270 RTL and 90 LTR)
            frame.setDefaultGravity(gravity);
            frame.setGravity(gravity); // Apply gravity to root

            frame.addView(v, childParams);
          
   //根据 config_navBarLayout_right 的值 来计算每个图标的宽度 如果为 W或WC 则表示为weight 如果为AC 则表示是像素值
            if (sizeStr.contains(WEIGHT_SUFFIX)) {
                // Use weighting to set the width of the frame
                float weight = Float.parseFloat(
                        sizeStr.substring(0, sizeStr.indexOf(WEIGHT_SUFFIX)));
                frame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH_PARENT, weight));
            } else {
                int width = (int) convertDpToPx(mContext,
                        Float.parseFloat(sizeStr.substring(0, sizeStr.indexOf(ABSOLUTE_SUFFIX))));
                frame.setLayoutParams(new LinearLayout.LayoutParams(width, MATCH_PARENT));
            }

            // Ensure ripples can be drawn outside bounds
            frame.setClipChildren(false);
            frame.setClipToPadding(false);

            return frame;
        }

        float size = Float.parseFloat(sizeStr);
        ViewGroup.LayoutParams params = v.getLayoutParams();
        params.width = (int) (params.width * size);
        return v;
    }

```

inflateButton中的虚拟按键的布局占比会根据navLayoutSetting中的占比来设置导航栏虚拟按键的占比，根据比例布局虚拟按键在导航栏的布局


### 3.4如果需要添加自定义图标 可以在config\_navBarLayout\_right 添加



```
如:<string name="config\_navBarLayout\_right" translatable="false">back[70AC],home[70AC],recent[70AC];hide;bluetooth[50AC],volume[50AC],brightness[50AC],keyboard[50AC],wifi[50AC],clock[50AC],battery[15AC]</string>

```




