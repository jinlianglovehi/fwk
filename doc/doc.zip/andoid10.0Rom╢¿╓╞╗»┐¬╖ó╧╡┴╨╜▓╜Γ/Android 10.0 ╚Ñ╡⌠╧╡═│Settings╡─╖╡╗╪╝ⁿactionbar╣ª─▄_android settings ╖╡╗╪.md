



## 1.前言


在10.0的系统产品定制化开发中，在原生系统Settings的主菜单进入二级菜单中的页面中，最上面都有一个ActionBar的返回键，在 某种情况下进行产品定制的时候，不需要这个返回键，所以接下来分析下这个返回键布局，来实现功能


## 2.去掉系统Settings的返回键actionbar功能的核心类



```
packages\apps\Settings\src\com\android\settings\SettingsActivity.java
packages\apps\Settings\res\layout\settings_main_prefs.xml
```

## 3.去掉系统Settings的返回键actionbar功能的核心功能分析和实现


Action Bar也是一个非常重要的交互元素，Action Bar取代了传统的tittle bar和menu，在程序运行中一直置于顶部，对于Android平板设备来说屏幕 更大它的标题使用Action Bar来设计可以展示更多丰富的内容，方便操控。 ActionBar的功能 1.ActionBar的图标，可显示软件图标，也可用其他图标代替。当软件不在最高级页面时，图标左侧会显示一个左箭头，用户可以通过这个箭头向上导航； 2. 如果你的应用要在不同的View中显示数据，这部分允许用户来切换视图。一般的作法是用一个下拉菜单或者是Tab选项卡。如果只有一个界面，那这里可以显示应用程序的标题或者是更长一点的商标信息； 3.两个action按钮，这里放重要的按钮功能，为用户进行某项操作提供直接的访问； 4.overflow按钮，放不下的按钮会被置于“更多...”菜单项中，“更多...”菜单项是以下拉形式实现的。 Settings，包括手机各项属性的基本调整和功能的开关，是用户根据个人喜好对手机进行定制的最方便的入口，也是用户在日常生活中使用频率最高的模块之一。因此，它的稳定性、修改定制，对于开发者来说尤为重要。 在目前的移动设备中，Settings界面除过主题定制的颜色图标等差别外，存在两种形式：单页形式和分页形式。单页形式为主要形式，而在平板等大屏设备中，则会采用分页形式


## 3.1 settings\_main\_prefs.xml中相关布局分析


在实现去掉系统Settings的返回键actionbar功能中，通过上述源码分析得知，在Settings的启动页类中， Settings.java就是启动入口，而它是SettingsActivity.java的子类，其实主要的布局是在settings\_main\_prefs.xml中 接下来看下核心布局的相关源码分析



```
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
              android:orientation="vertical"
              android:layout_height="match_parent"
              android:layout_width="match_parent">

    <com.android.settings.widget.SwitchBar
        android:id="@+id/switch_bar"
        android:layout_height="?android:attr/actionBarSize"
        android:layout_width="match_parent"
        android:theme="?attr/switchBarTheme"/>

    <FrameLayout
        android:id="@+id/main_content"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"/>

    <RelativeLayout android:id="@+id/button_bar"
                    android:layout_height="wrap_content"
                    android:layout_width="match_parent"
                    android:layout_weight="0"
                    android:visibility="gone">

        <Button android:id="@+id/back_button"
                android:layout_width="150dip"
                android:layout_height="wrap_content"
                android:layout_margin="5dip"
                android:layout_alignParentStart="true"
                android:text="@*android:string/back_button_label"/>

        <LinearLayout
                android:orientation="horizontal"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentEnd="true">

            <Button android:id="@+id/skip_button"
                    android:layout_width="150dip"
                    android:layout_height="wrap_content"
                    android:layout_margin="5dip"
                    android:text="@*android:string/skip_button_label"
                    android:visibility="gone"/>

            <Button android:id="@+id/next_button"
                    android:layout_width="150dip"
                    android:layout_height="wrap_content"
                    android:layout_margin="5dip"
                    android:text="@*android:string/next_button_label"/>

        </LinearLayout>

    </RelativeLayout>

</LinearLayout>
```

在实现去掉系统Settings的返回键actionbar功能中，通过上述源码分析得知，在settings\_main\_prefs.xml中 相关源码发现在+id/back\_button 就是settings的主菜单点进去每个二级菜单顶部actionbar的返回菜单按钮， 所以可以从这个整体的布局中，找到一个在SettingsActivity.java的类中，找到一个获取这个控件的方法，然后 屏蔽掉显示布局的方法，就可以实现去掉actionbar返回的功能了，接下来分析下关于SettingsActivity.java的类中 相关的源码分析来实现这个功能


## 3.2 SettingsActivity.java中相关actionbar的源码分析


在实现去掉系统Settings的返回键actionbar功能中，通过上述源码分析得知，在Settings的启动页类中， Settings.java就是启动入口，而它是SettingsActivity.java的子类，同样的获取actionbar返回键的功能布局 也可以在这里实现，然后屏蔽掉就可以了，接下来分析下相关源码



```
@Override
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        Log.d(LOG_TAG, "Starting onCreate");
        long startTime = System.currentTimeMillis();

        final FeatureFactory factory = FeatureFactory.getFactory(this);

        mDashboardFeatureProvider = factory.getDashboardFeatureProvider(this);

        // Should happen before any call to getIntent()
        getMetaData();

        final Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_UI_OPTIONS)) {
            getWindow().setUiOptions(intent.getIntExtra(EXTRA_UI_OPTIONS, 0));
        }

        // Getting Intent properties can only be done after the super.onCreate(...)
        final String initialFragmentName = intent.getStringExtra(EXTRA_SHOW_FRAGMENT);

        final boolean isSubSettings = this instanceof SubSettings ||
                intent.getBooleanExtra(EXTRA_SHOW_FRAGMENT_AS_SUBSETTING, false);

        if (isSubSettings && !WizardManagerHelper.isAnySetupWizard(getIntent())) {
            setTheme(R.style.Theme_SubSettings);
        }

        setContentView(R.layout.settings_main_prefs);

        getSupportFragmentManager().addOnBackStackChangedListener(this);

        if (savedState != null) {
            setTitleFromIntent(intent);

            ArrayList<DashboardCategory> categories =
                    savedState.getParcelableArrayList(SAVE_KEY_CATEGORIES);
            if (categories != null) {
                mCategories.clear();
                mCategories.addAll(categories);
                setTitleFromBackStack();
            }
        } else {
            launchSettingFragment(initialFragmentName, intent);
        }

        final boolean isInSetupWizard = WizardManagerHelper.isAnySetupWizard(getIntent());

        final ActionBar actionBar = getActionBar();
        if (actionBar != null) {
             - actionBar.setDisplayHomeAsUpEnabled(deviceProvisioned);
             - actionBar.setHomeButtonEnabled(deviceProvisioned);
           -  actionBar.setDisplayShowTitleEnabled(true);
         +   actionBar.setDisplayHomeAsUpEnabled(false);
         +   actionBar.setHomeButtonEnabled(false);
         +   actionBar.setDisplayShowTitleEnabled(false);
        }
        mSwitchBar = findViewById(R.id.switch_bar);
        if (mSwitchBar != null) {
            mSwitchBar.setMetricsTag(getMetricsTag());
        }

        // see if we should show Back/Next buttons
        if (intent.getBooleanExtra(EXTRA_PREFS_SHOW_BUTTON_BAR, false)) {

            View buttonBar = findViewById(R.id.button_bar);
            if (buttonBar != null) {
                buttonBar.setVisibility(View.VISIBLE);

                Button backButton = findViewById(R.id.back_button);
                backButton.setOnClickListener(v -> {
                    setResult(RESULT_CANCELED, null);
                    finish();
                });
                Button skipButton = findViewById(R.id.skip_button);
                skipButton.setOnClickListener(v -> {
                    setResult(RESULT_OK, null);
                    finish();
                });
                mNextButton = findViewById(R.id.next_button);
                mNextButton.setOnClickListener(v -> {
                    setResult(RESULT_OK, null);
                    finish();
                });

                // set our various button parameters
                if (intent.hasExtra(EXTRA_PREFS_SET_NEXT_TEXT)) {
                    String buttonText = intent.getStringExtra(EXTRA_PREFS_SET_NEXT_TEXT);
                    if (TextUtils.isEmpty(buttonText)) {
                        mNextButton.setVisibility(View.GONE);
                    } else {
                        mNextButton.setText(buttonText);
                    }
                }
                if (intent.hasExtra(EXTRA_PREFS_SET_BACK_TEXT)) {
                    String buttonText = intent.getStringExtra(EXTRA_PREFS_SET_BACK_TEXT);
                    if (TextUtils.isEmpty(buttonText)) {
                        backButton.setVisibility(View.GONE);
                    } else {
                        backButton.setText(buttonText);
                    }
                }
                if (intent.getBooleanExtra(EXTRA_PREFS_SHOW_SKIP, false)) {
                    skipButton.setVisibility(View.VISIBLE);
                }
            }
        }

        if (DEBUG_TIMING) {
            Log.d(LOG_TAG, "onCreate took " + (System.currentTimeMillis() - startTime) + " ms");
        }
    }
```

在实现去掉系统Settings的返回键actionbar功能中，通过上述源码分析得知，在SettingsActivity.java中相关源码中， 在onCreate(Bundle savedState)的相关方法中，就是加载SettingsActivity.java的相关源码核心布局，在这个类里面


final ActionBar actionBar = getActionBar();


if (actionBar != null) {


- actionBar.setDisplayHomeAsUpEnabled(deviceProvisioned);


- actionBar.setHomeButtonEnabled(deviceProvisioned);


- actionBar.setDisplayShowTitleEnabled(true);


+ actionBar.setDisplayHomeAsUpEnabled(false);


+ actionBar.setHomeButtonEnabled(false);


+ actionBar.setDisplayShowTitleEnabled(false);


} 就是关于顶部actionbar布局的返回键的相关核心功能分析，所以在这个类里面，重点就是设置ActionBar actionBar的 隐藏功能，所以就设置 actionBar.setDisplayHomeAsUpEnabled(false); actionBar.setHomeButtonEnabled(false); actionBar.setDisplayShowTitleEnabled(false);这三个核心方法为false 就实现了去掉actionbar返回键功能



