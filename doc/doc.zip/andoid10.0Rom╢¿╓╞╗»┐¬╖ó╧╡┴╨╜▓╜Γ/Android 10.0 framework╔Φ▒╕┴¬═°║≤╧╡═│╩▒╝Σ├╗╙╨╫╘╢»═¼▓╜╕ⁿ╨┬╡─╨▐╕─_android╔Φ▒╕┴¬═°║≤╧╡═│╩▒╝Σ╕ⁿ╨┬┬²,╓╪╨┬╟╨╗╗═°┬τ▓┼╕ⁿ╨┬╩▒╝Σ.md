






### 1.概述


在定制化10.0的产品开发中，在产品联网后系统都会自动同步时间，但在一些产品中，会出现即使联网了也不会同步时间的情况，开始以为是设备的网络问题，咨询同事和百度发现谷歌服务器会出现在大陆时间同步更新延迟的情况 所以需要增加一些国内的域名来更新系统时间，来解决这个问题


### 2.framework设备联网后系统时间没有自动同步更新的修改的核心类



```
/frameworks/base/core/java/android/util/NtpTrustedTime.java

```

### 3.framework设备联网后系统时间没有自动同步更新的修改的核心功能分析和实现


在系统中使用的是ntp服务器来联网获取当前的时间，然后更新系统时间的，在系统源码中NtpTrustedTime.java中 专门负责在联网后更新系统时间  
 所以具体的时间处理需要在这里面找相关代码来实现  
 首选看下它的源码  
 路径: /frameworks/base/core/java/android/util/NtpTrustedTime.java



```
public class NtpTrustedTime implements TrustedTime {
     private static final String TAG = "NtpTrustedTime";
     private static final boolean LOGD = false;
 
     private static NtpTrustedTime sSingleton;
     private static Context sContext;
 
     private final String mServer;
     private final long mTimeout;
 
     private ConnectivityManager mCM;
 
     private boolean mHasCache;
     private long mCachedNtpTime;
     private long mCachedNtpElapsedRealtime;
     private long mCachedNtpCertainty;
 
     private NtpTrustedTime(String server, long timeout) {
         if (LOGD) Log.d(TAG, "creating NtpTrustedTime using " + server);
         mServer = server;
         mTimeout = timeout;
     }
 
     @UnsupportedAppUsage
     public static synchronized NtpTrustedTime getInstance(Context context) {
         if (sSingleton == null) {
             final Resources res = context.getResources();
             final ContentResolver resolver = context.getContentResolver();
 
             final String defaultServer = res.getString(
                     com.android.internal.R.string.config_ntpServer);
             final long defaultTimeout = res.getInteger(
                     com.android.internal.R.integer.config_ntpTimeout);
 
             final String secureServer = Settings.Global.getString(
                     resolver, Settings.Global.NTP_SERVER);
             final long timeout = Settings.Global.getLong(
                     resolver, Settings.Global.NTP_TIMEOUT, defaultTimeout);
 
             final String server = secureServer != null ? secureServer : defaultServer;
             sSingleton = new NtpTrustedTime(server, timeout);
             sContext = context;
         }
 
         return sSingleton;
     }
 
     @Override
     @UnsupportedAppUsage
     public boolean forceRefresh() {
         // We can't do this at initialization time: ConnectivityService might not be running yet.
 synchronized (this) {
 if (mCM == null) {
 mCM = sContext.getSystemService(ConnectivityManager.class);
 }
 }
 
 final Network network = mCM == null ? null : mCM.getActiveNetwork();
 return forceRefresh(network);
 }
 
 public boolean forceRefresh(Network network) {
 if (TextUtils.isEmpty(mServer)) {
 // missing server, so no trusted time available
 return false;
 }
 
 // We can't do this at initialization time: ConnectivityService might not be running yet.
          synchronized (this) {
              if (mCM == null) {
                  mCM = sContext.getSystemService(ConnectivityManager.class);
              }
          }
  
          final NetworkInfo ni = mCM == null ? null : mCM.getNetworkInfo(network);
          if (ni == null || !ni.isConnected()) {
              if (LOGD) Log.d(TAG, "forceRefresh: no connectivity");
              return false;
          }
  
  
          if (LOGD) Log.d(TAG, "forceRefresh() from cache miss");
          final SntpClient client = new SntpClient();
          if (client.requestTime(mServer, (int) mTimeout, network)) {
              mHasCache = true;
              mCachedNtpTime = client.getNtpTime();
              mCachedNtpElapsedRealtime = client.getNtpTimeReference();
              mCachedNtpCertainty = client.getRoundTripTime() / 2;
              return true;
          } else {
              return false;
          }
      }

```

在client.requestTime(mServer, (int) mTimeout, network)中主要是来判断获取ntp服务器时间是否超时  
 如果超时可以获取国内ntp服务器时间  
 所以在获取失败时重新获取国内服务器时间  
 具体修改为:  
 增加国内ntp服务器地址  
 private String[] mCachedNtpServers = {“ntp1.aliyun.com”, “ntp2.aliyun.com”, “cn.ntp.org.cn”, “edu.ntp.org.cn”, “cn.pool.ntp.org” };  
 // 这里就是获取谷歌服务器的当前时区时间



```
if (client.requestTime(mServer, (int) mTimeout, network)) {
mHasCache = true;
mCachedNtpTime = client.getNtpTime();
mCachedNtpElapsedRealtime = client.getNtpTimeReference();
mCachedNtpCertainty = client.getRoundTripTime() / 2;
return true;
} else {
//获取失败
      //add code start       
       for (String ntpServer : mCachedNtpServers) {

           if (client.requestTime(ntpServer, (int) mTimeout, network)) {

               mHasCache = true;

               mCachedNtpTime = client.getNtpTime();

               mCachedNtpElapsedRealtime = client.getNtpTimeReference();

               mCachedNtpCertainty = client.getRoundTripTime() / 2;

               return true;

           }

       }

       //add code end
      return false;
  }

```

TrustedTime 关于ntp时间的接口如下：



```
public interface TrustedTime {
      /**
       * Force update with an external trusted time source, returning {@code true}
       * when successful.
       *
       * @deprecated Only kept for UnsupportedAppUsage. Do not use. See {@link NtpTrustedTime}
       */
      @Deprecated
      @UnsupportedAppUsage
      public boolean forceRefresh();
  
      /**
       * Check if this instance has cached a response from a trusted time source.
       *
       * @deprecated Only kept for UnsupportedAppUsage. Do not use. See {@link NtpTrustedTime}
       */
      @Deprecated
      @UnsupportedAppUsage
      boolean hasCache();
  
      /**
       * Return time since last trusted time source contact, or
       * {@link Long#MAX\_VALUE} if never contacted.
       *
       * @deprecated Only kept for UnsupportedAppUsage. Do not use. See {@link NtpTrustedTime}
       */
      @Deprecated
      @UnsupportedAppUsage
      public long getCacheAge();
  
      /**
       * Return current time similar to {@link System#currentTimeMillis()},
       * possibly using a cached authoritative time source.
       *
       * @deprecated Only kept for UnsupportedAppUsage. Do not use. See {@link NtpTrustedTime}
       */
      @Deprecated
      @UnsupportedAppUsage
      long currentTimeMillis();
  }

```

通过这些接口来更新时间





