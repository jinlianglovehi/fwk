






### 1.概述


### 2.Settings 显示 去掉二级菜单 壁纸的核心类



```
packages/apps/Settings/src/com/android/settings/DisplaySettings.java
packages/apps/Settings/res/xml/display_settings.xml
packages\apps\Settings\src\com\android\settings\display\TopLevelDisplayPreferenceController.java


```

### 3.Settings 显示 去掉二级菜单 壁纸的核心功能分析和实现


在系统Setting中的显示菜单的，下一个二级菜单其中就有壁纸菜单  
 而它的一级菜单显示 就是DisplaySettings.java类  
 接下来看下DisplaySettings.java类的相关源码



```
--- a/packages/apps/Settings/src/com/android/settings/DisplaySettings.java
+++ b/packages/apps/Settings/src/com/android/settings/DisplaySettings.java
@@ -24,6 +24,8 @@ import android.content.IntentFilter;
 import android.os.Bundle;
 import android.os.sprdpower.PowerManagerEx;
 import android.provider.SearchIndexableResource;
+import androidx.preference.Preference;
+import androidx.preference.PreferenceScreen;
 
 import com.android.settings.dashboard.DashboardFragment;
 import com.android.settings.display.BrightnessLevelPreferenceController;
@@ -44,7 +46,7 @@ import com.android.settings.search.Indexable;
 import com.android.settingslib.core.AbstractPreferenceController;
 import com.android.settingslib.core.lifecycle.Lifecycle;
 import com.android.settingslib.search.SearchIndexable;
-
+import android.provider.Settings;
 import java.util.ArrayList;
 import java.util.List;
 
@@ -53,7 +55,7 @@ public class DisplaySettings extends DashboardFragment {
     private static final String TAG = "DisplaySettings";
 
     private static final String KEY_SCREEN_TIMEOUT = "screen\_timeout";
-
+       private static final String KEY_WALLPAPER = "wallpaper";
     @Override
     public int getMetricsCategory() {
         return SettingsEnums.DISPLAY;
@@ -73,6 +75,14 @@ public class DisplaySettings extends DashboardFragment {
     public void onCreate(Bundle icicle) {
         super.onCreate(icicle);
         use(DarkUIPreferenceController.class).setParentFragment(this);
+               PreferenceScreen preferenceScreen = getPreferenceScreen();
+               Preference pref = preferenceScreen.findPreference(KEY_WALLPAPER);
+               int settings_custom = Settings.Global.getInt(getContext().getContentResolver(),"settings\_custom",1);
+               if(settings_custom==0){
+                       if (pref != null) {
+                          preferenceScreen.removePreference(pref);
+            }
+               }
     }

```

在DisplaySettings.java中的onCreate(Bundle icicle)的方法中，用PreferenceScreen 的removePreference方法来去掉壁纸菜单


### 3.2 display\_settings.xml 中 壁纸的布局



```
<PreferenceScreen
     xmlns:android="http://schemas.android.com/apk/res/android"
     xmlns:settings="http://schemas.android.com/apk/res-auto"
     android:key="display\_settings\_screen"
     android:title="@string/display\_settings"
     settings:keywords="@string/keywords\_display"
     settings:initialExpandedChildrenCount="5">
 
     <com.android.settingslib.RestrictedPreference
         android:key="brightness"
         android:title="@string/brightness"
         settings:keywords="@string/keywords\_display\_brightness\_level"
         settings:useAdminDisabledSummary="true"
         settings:userRestriction="no\_config\_brightness">
         <intent android:action="com.android.intent.action.SHOW\_BRIGHTNESS\_DIALOG" />
     </com.android.settingslib.RestrictedPreference>
 
     <com.android.settings.display.NightDisplayPreference
         android:key="night\_display"
         android:title="@string/night\_display\_title"
         android:fragment="com.android.settings.display.NightDisplaySettings"
         android:widgetLayout="@null"
         settings:widgetLayout="@null"
         settings:searchable="false" />
 
     <Preference
         android:key="auto\_brightness\_entry"
         android:title="@string/auto\_brightness\_title"
         android:summary="@string/summary\_placeholder"
         android:fragment="com.android.settings.display.AutoBrightnessSettings"
         settings:controller="com.android.settings.display.AutoBrightnessPreferenceController"/>
 <com.android.settingslib.RestrictedPreference
        android:key="wallpaper"
        android:title="@string/wallpaper\_settings\_title"
        settings:keywords="@string/keywords\_display\_wallpaper"
        settings:useAdminDisabledSummary="true"
        settings:controller="com.android.settings.display.WallpaperPreferenceController">

```

在display\_settings.xml中可以看出key="wallpaper"就是壁纸的二级菜单


### 3.3修改Summary的值 TopLevelDisplayPreferenceController中修改


显示菜单中的Summary中去掉壁纸的相关字眼



```
packages\apps\Settings\src\com\android\settings\display\TopLevelDisplayPreferenceController.java
public class TopLevelDisplayPreferenceController extends BasePreferenceController {

    public TopLevelDisplayPreferenceController(Context context, String preferenceKey) {
        super(context, preferenceKey);
    }

    @Override
    public int getAvailabilityStatus() {
        return mContext.getResources().getBoolean(R.bool.config_show_top_level_display)
        ? AVAILABLE
        : UNSUPPORTED_ON_DEVICE;
    }

    @Override
    public CharSequence getSummary() {
        final WallpaperPreferenceController controller =
                new WallpaperPreferenceController(mContext, "dummy\_key");
        if (controller.isAvailable()) {
        	//此处修改Summary的值
            int settings_custom = Settings.Global.getInt(mContext.getContentResolver(),"settings\_custom",1);
            if(settings_custom==1){
               return mContext.getText(
                    controller.areStylesAvailable()
                    ? R.string.display_dashboard_summary_with_style
                    : R.string.display_dashboard_summary);
            }else{
               return mContext.getText(
                    controller.areStylesAvailable()
                    ? R.string.display_dashboard_summary_with_style
                    : R.string.display_custom_dashboard_summary);
            }
        } else {
            return mContext.getText(R.string.display_dashboard_nowallpaper_summary);
        }
    }
}

```

在TopLevelDisplayPreferenceController中的getSummary() 就是关于对一级菜单显示的Summary的设置，所以需要根据settings\_custom来设置是否去掉壁纸的显示，如果需要去掉壁纸，那么这里就需要去掉壁纸，在display\_custom\_dashboard\_summary中去掉壁纸的显示





