



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.去掉系统安全模式（SAFE MODE）的核心类](#2.%E5%8E%BB%E6%8E%89%E7%B3%BB%E7%BB%9F%E5%AE%89%E5%85%A8%E6%A8%A1%E5%BC%8F%EF%BC%88SAFE%20MODE%EF%BC%89%E7%9A%84%E6%A0%B8%E5%BF%83%E7%B1%BB)


[3.去掉系统安全模式（SAFE MODE）的核心功能实现和分析](#3.%E5%8E%BB%E6%8E%89%E7%B3%BB%E7%BB%9F%E5%AE%89%E5%85%A8%E6%A8%A1%E5%BC%8F%EF%BC%88SAFE%20MODE%EF%BC%89%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E5%92%8C%E5%88%86%E6%9E%90)


[3.1SystemServer.java中关于对是否启动系统安全模式的分析](#3.1SystemServer.java%E4%B8%AD%E5%85%B3%E4%BA%8E%E5%AF%B9%E6%98%AF%E5%90%A6%E5%90%AF%E5%8A%A8%E7%B3%BB%E7%BB%9F%E5%AE%89%E5%85%A8%E6%A8%A1%E5%BC%8F%E7%9A%84%E5%88%86%E6%9E%90)


[3.2 WindowManagerService.java的detectSafeMode()来看相关代码的分析实现](#3.2%20WindowManagerService.java%E7%9A%84detectSafeMode%28%29%E6%9D%A5%E7%9C%8B%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E7%9A%84%E5%88%86%E6%9E%90%E5%AE%9E%E7%8E%B0)


[3.3 长按电源键 弹出 关机 重新启动 屏幕截屏 对话框进入安全模式的分析](#3.3%20%E9%95%BF%E6%8C%89%E7%94%B5%E6%BA%90%E9%94%AE%20%E5%BC%B9%E5%87%BA%20%E5%85%B3%E6%9C%BA%20%E9%87%8D%E6%96%B0%E5%90%AF%E5%8A%A8%20%E5%B1%8F%E5%B9%95%E6%88%AA%E5%B1%8F%20%E5%AF%B9%E8%AF%9D%E6%A1%86%E8%BF%9B%E5%85%A5%E5%AE%89%E5%85%A8%E6%A8%A1%E5%BC%8F%E7%9A%84%E5%88%86%E6%9E%90)




---



## 1.概述


在10.0的android 系统产品开发中。开机时通过长按按音量减就会进入安全模式 ，而产品不需要安全模式，所以就要去掉安全模式，通过查询资料发现，安全模式在WMS中有设置 接下来看下源码


## 2.去掉系统安全模式（SAFE MODE）的核心类



```
/frameworks/base/services/java/com/android/server/SystemServer.java
frameworks/base/services/core/java/com/android/server/wm/WindowManagerService.java
frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
```

## 3.去掉系统安全模式（SAFE MODE）的核心功能实现和分析


### 3.1SystemServer.java中关于对是否启动系统安全模式的分析


在systemserver的startOtherServices()中在启动其他服务的时候，在调用wm的detectSafeMode();来判断系统要不要进入安全模式，所以需要继续看WindowManagerService.java的detectSafeMode()来看相关代码的分析



```
       /**
       * Starts a miscellaneous grab bag of stuff that has yet to be refactored and organized.
       */
      private void startOtherServices() {
          final Context context = mSystemContext;
          VibratorService vibrator = null;
          DynamicSystemService dynamicSystem = null;
          IStorageManager storageManager = null;
          NetworkManagementService networkManagement = null;
          IpSecService ipSecService = null;
          NetworkStatsService networkStats = null;
             // Before things start rolling, be sure we have decided whether
          // we are in safe mode.
          final boolean safeMode = wm.detectSafeMode();
          if (safeMode) {
              // If yes, immediately turn on the global setting for airplane mode.
              // Note that this does not send broadcasts at this stage because
              // subsystems are not yet up. We will send broadcasts later to ensure
              // all listeners have the chance to react with special handling.
              Settings.Global.putInt(context.getContentResolver(),
                      Settings.Global.AIRPLANE_MODE_ON, 1);
          }
```

### 3.2 WindowManagerService.java的detectSafeMode()来看相关代码的分析实现



```
public boolean detectSafeMode() {
        if (!mInputManagerCallback.waitForInputDevicesReady(
                INPUT_DEVICES_READY_FOR_SAFE_MODE_DETECTION_TIMEOUT_MILLIS)) {
            Slog.w(TAG_WM, "Devices still not ready after waiting "
                   + INPUT_DEVICES_READY_FOR_SAFE_MODE_DETECTION_TIMEOUT_MILLIS
                   + " milliseconds before attempting to detect safe mode.");
        }

        if (Settings.Global.getInt(
                mContext.getContentResolver(), Settings.Global.SAFE_BOOT_DISALLOWED, 0) != 0) {
            return false;
        }

        int menuState = mInputManager.getKeyCodeState(-1, InputDevice.SOURCE_ANY,
                KeyEvent.KEYCODE_MENU);
        int sState = mInputManager.getKeyCodeState(-1, InputDevice.SOURCE_ANY, KeyEvent.KEYCODE_S);
        int dpadState = mInputManager.getKeyCodeState(-1, InputDevice.SOURCE_DPAD,
                KeyEvent.KEYCODE_DPAD_CENTER);
        int trackballState = mInputManager.getScanCodeState(-1, InputDevice.SOURCE_TRACKBALL,
                InputManagerService.BTN_MOUSE);
        int volumeDownState = mInputManager.getKeyCodeState(-1, InputDevice.SOURCE_ANY,
                KeyEvent.KEYCODE_VOLUME_DOWN);
        mSafeMode = menuState > 0 || sState > 0 || dpadState > 0 || trackballState > 0
                || volumeDownState > 0;
        try {
            if (SystemProperties.getInt(ShutdownThread.REBOOT_SAFEMODE_PROPERTY, 0) != 0
                    || SystemProperties.getInt(ShutdownThread.RO_SAFEMODE_PROPERTY, 0) != 0) {
                mSafeMode = true;
                SystemProperties.set(ShutdownThread.REBOOT_SAFEMODE_PROPERTY, "");
            }
        } catch (IllegalArgumentException e) {
        }
        if (mSafeMode) {
            Log.i(TAG_WM, "SAFE MODE ENABLED (menu=" + menuState + " s=" + sState
                    + " dpad=" + dpadState + " trackball=" + trackballState + ")");
            // May already be set if (for instance) this process has crashed
            if (SystemProperties.getInt(ShutdownThread.RO_SAFEMODE_PROPERTY, 0) == 0) {
                SystemProperties.set(ShutdownThread.RO_SAFEMODE_PROPERTY, "1");
            }
        } else {
            Log.i(TAG_WM, "SAFE MODE not enabled");
        }
        mPolicy.setSafeMode(mSafeMode);
        return mSafeMode;
    }

```


从WindowManagerService.java的detectSafeMode()上面源码看出判断是否进入安全模式最后 return mSafeMode;根据mSafeMode判断是否进入安全模式 然后进入安全模式 不进入


安全模式返回false 就进不到安全模式


具体修改如下:



```
--- a/frameworks/base/services/core/java/com/android/server/wm/WindowManagerService.java
+++ b/frameworks/base/services/core/java/com/android/server/wm/WindowManagerService.java
@@ -4502,7 +4502,7 @@ public class WindowManagerService extends AbsWindowManagerService
             Log.i(TAG_WM, "SAFE MODE not enabled");
         }
         mPolicy.setSafeMode(mSafeMode);
-        return mSafeMode;
+        return false;
     }
 
     public void displayReady() {
```


### 3.3 长按电源键 弹出 关机 重新启动 屏幕截屏 对话框进入安全模式的分析


在SystemUI长按电源键进入关机对话框中，然后 长按关机和重新启动 进入安全模式的分析



```
private final class PowerAction extends SinglePressAction implements LongPressAction {
         private PowerAction() {
             super(R.drawable.ic_lock_power_off,
                     R.string.global_action_power_off);
         }
 
         @Override
         public boolean onLongPress() {
             UserManager um = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
             if (!um.hasUserRestriction(UserManager.DISALLOW_SAFE_BOOT)) {
                 mWindowManagerFuncs.reboot(true);
                 return true;
             }
             return false;
         }
 
         @Override
         public void onPress() {
             // shutdown by making sure radio and power are handled accordingly.
             mWindowManagerFuncs.shutdown();
         }
		 
		  private final class RestartAction extends SinglePressAction implements LongPressAction {
          private RestartAction() {
              super(R.drawable.ic_restart, R.string.global_action_restart);
          }
  
          @Override
          public boolean onLongPress() {
              UserManager um = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
              if (!um.hasUserRestriction(UserManager.DISALLOW_SAFE_BOOT)) {
                  mWindowManagerFuncs.reboot(true);
                  return true;
              }
              return false;
          }
  
          @Override
          public void onPress() {
              mWindowManagerFuncs.reboot(false);
          }
      }
  
```

从PowerAction和RestartAction这两个事件发现在长按事件中，调用



```
if (!um.hasUserRestriction(UserManager.DISALLOW_SAFE_BOOT)) {
                 mWindowManagerFuncs.reboot(true);
                 return true;
             }
```

来设置长按进入重启进入安全模式，所以需要在长按事件中去掉这种模式，修改为短按事件


进入相关的重启关机模式


具体修改为：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/globalactions/GlobalActionsDialog.java
@@ -503,11 +503,12 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
 
         @Override
         public boolean onLongPress() {
-            UserManager um = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
+            /*UserManager um = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
             if (!um.hasUserRestriction(UserManager.DISALLOW_SAFE_BOOT)) {
                 mWindowManagerFuncs.reboot(true);
                 return true;
-            }
+            }*/
+                       mWindowManagerFuncs.shutdown();
             return false;
         }
 
@@ -608,11 +609,12 @@ public class GlobalActionsDialog implements DialogInterface.OnDismissListener,
 
         @Override
         public boolean onLongPress() {
-            UserManager um = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
+            /*UserManager um = (UserManager) mContext.getSystemService(Context.USER_SERVICE);
             if (!um.hasUserRestriction(UserManager.DISALLOW_SAFE_BOOT)) {
                 mWindowManagerFuncs.reboot(true);
                 return true;
-            }
+            }*/
+                       mWindowManagerFuncs.reboot(false);
             return false;
         }
```



