






在定制设备开发中，由于设备仅支持前置摄像头 所以要在源码中去掉后置摄像头 进入相机默认调用前置摄像头


所以就需要研究Camera2的源码


源码路径为:  
 vendor\sprd\platform\packages\apps\DreamCamera2  
 展讯的用DreamCamera2代替了Camera2


由于进入Camera2 就会打开摄像头 所以要看打开摄像头 openCamera的源码部分


在vendor/sprd/platform/packages/apps/DreamCamera2/src/com/android/camera/CameraActivity.java  
 中



```
private CameraController mCameraController;
// oncreate - request open camera
    private Runnable mOncreateOpencamera = new Runnable() {
        @Override
        public void run() {
            mCounterOncreateOpenCamera.waitCount();
            mOnCreateTime = System.currentTimeMillis();
            int cameraid = mDataModuleManager.getInstance(CameraActivity.this).getTempCameraModule().getInt(Keys.KEY_CAMERA_ID);
            if (!isKeyguardLocked()
                    /*&& mCurrentModeIndex == SettingsScopeNamespaces.AUTO_PHOTO*/
                    && !isRefocusModeOn(cameraid)
                    && checkAllCameraAvailable()) {
                mIsCameraRequestedOnCreate = true;
                /* SPRD: w+t module just for back camrea and auto photo module@{ */
                if (CameraUtil.isWPlusTEnable() && !isCaptureIntent()){
                    CameraUtil.resetWPlusTThreshold(CameraPictureSizesCacher.getSizesForCamera(CameraUtil.BACK_W_PLUS_T_PHOTO_ID, mAppContext));
                }

                if (CameraUtil.isWPlusTAbility(mAppContext,true) && !isCaptureIntent()){
                    cameraid = CameraUtil.BACK_W_PLUS_T_PHOTO_ID;
                }
                /*@}*/
                if (CameraUtil.isTcamAbility(mAppContext,cameraid) && !isCaptureIntent()) {
                    cameraid = CameraUtil.BACK_TRI_CAMERA_ID;
                }

                Log.e(TAG , "UltraWideAngle Enable = " + CameraUtil.isUltraWideAngleEnabled());
                if (mHasCriticalPermissions) {
                    mCameraController.requestCamera(cameraid,
                            mCurrentModule == null ? true : mCurrentModule.useNewApi());
                }
            }
        }
    };

```

mOncreateOpencamera 在onCreateTask中启动打开摄像头  
 mCameraController.requestCamera(cameraid,  
 mCurrentModule == null ? true : mCurrentModule.useNewApi());  
 来请求打开摄像头  
 接下来看 CameraController.java的代码  
 路径为:  
 vendor/sprd/platform/packages/apps/DreamCamera2/src/com/android/camera/app/CameraController.java



```
@Override
    public void requestCamera(int id, boolean useNewApi) {
        Log.i(TAG, "requestCamera id="+id);
        // Based on
        // (mRequestingCameraId == id, mRequestingCameraId == EMPTY_REQUEST),
        // we have (T, T), (T, F), (F, T), (F, F).
        // (T, T): implies id == EMPTY_REQUEST. We don't allow this to happen
 // here. Return.
 // (F, F): A previous request hasn't been fulfilled yet. Return.
        // (T, F): Already requested the same camera. No-op. Return.
        // (F, T): Nothing is going on. Continue.
        Log.i(TAG, "mRequestingCameraId = " + mRequestingCameraId + "mInfo = " + mInfo);
        if (mRequestingCameraId != EMPTY_REQUEST || mRequestingCameraId == id) {
            return;
        }
//        if (mInfo == null) {
//            return;
//        }

        mRequestingCameraId = id;
        mActiveCameraDeviceTracker.onCameraOpening(CameraId.fromLegacyId(id));

        // Only actually use the new API if it's supported on this device.
        useNewApi = mCameraAgentNg != null && useNewApi;
        CameraAgent cameraManager = useNewApi ? mCameraAgentNg : mCameraAgent;

        if (mCameraProxy == null) {
            // No camera yet.
            checkAndOpenCamera(cameraManager, id, mCallbackHandler, this);
        } else if (mCameraProxy.getCameraId() != id || mUsingNewApi != useNewApi) {
            boolean syncClose = GservicesHelper.useCamera2ApiThroughPortabilityLayer(mContext
                        .getContentResolver());
            Log.v(TAG, "different camera already opened, closing then reopening");
            mCameraProxy = null;
            // Already has camera opened, and is switching cameras and/or APIs.
            if (mUsingNewApi) {
                if (mCameraAgentNg != null)
                    mCameraAgentNg.closeCamera(mCameraProxy, true);
            } else {
                // if using API2 ensure API1 usage is also synced
                mCameraAgent.closeCamera(mCameraProxy, syncClose);
            }
            checkAndOpenCamera(cameraManager, id, mCallbackHandler, this);
        } else {
            // The same camera, just do a reconnect.
            Log.v(TAG, "reconnecting to use the existing camera");
            mCameraProxy.reconnect(mCallbackHandler, this);
            mCameraProxy = null;
        }

        mUsingNewApi = useNewApi;
        /**
         * SPRD: Fix bug 572631, optimize camera launch time @{
         * Original Code
         *
        mInfo = cameraManager.getCameraDeviceInfo();
         */
    }

```

checkAndOpenCamera(cameraManager, id, mCallbackHandler, this);  
 由这个方法负责打开摄像头



```
private static void checkAndOpenCamera(CameraAgent cameraManager,
            final int cameraId, Handler handler, final CameraAgent.CameraOpenCallback cb) {
        Log.i(TAG, "checkAndOpenCamera");
        try {
            CameraUtil.throwIfCameraDisabled();
            cameraManager.openCamera(handler, cameraId, cb);
        } catch (CameraDisabledException ex) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    cb.onCameraDisabled(cameraId);
                }
            });
        }
    }

```

上面可以看出 cameraManager.openCamera(handler, cameraId, cb); 来调用摄像头  
 所以修改为



```
private static void checkAndOpenCamera(CameraAgent cameraManager,
            final int cameraId, Handler handler, final CameraAgent.CameraOpenCallback cb) {
        Log.i(TAG, "checkAndOpenCamera");
        try {
            CameraUtil.throwIfCameraDisabled();
           - cameraManager.openCamera(handler, cameraId, cb);
          + cameraManager.openCamera(handler, 1, cb);
         // 固定打开前置摄像头就可以了
        } catch (CameraDisabledException ex) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    cb.onCameraDisabled(cameraId);
                }
            });
        }
    }

```

2. 隐藏切换摄像头 MultiToggleImageButton;


在vendor/sprd/platform/packages/apps/DreamCamera2/src/com/dream/camera/ButtonManagerDream.java  
 中



```
mButtonCameraDream = (MultiToggleImageButton) root
                .findViewById(R.id.camera_toggle_button_dream);	

```

就代表切换摄像头的button



```
protected MultiToggleImageButton getButtonOrError(int buttonId) {
        switch (buttonId) {
            case BUTTON_FLASH_DREAM:
                checkButtonNull(mButtonFlashDream , "Flash button could not be found.");
                return mButtonFlashDream;
            case BUTTON_TORCH_DREAM:
                checkButtonNull(mButtonFlashDream , "Torch button could not be found.");
                return mButtonFlashDream;
            case BUTTON_CAMERA_DREAM:
                checkButtonNull(mButtonCameraDream , "Camera button could not be found.");
                return mButtonCameraDream;
}

```

在getButtonOrError中  
 BUTTON\_CAMERA\_DREAM 就代表是他的id



```
public void initializeButton(int buttonId, ButtonCallback cb,
            ButtonCallback preCb, int resId) {
        MultiToggleImageButton button = null;
        try {
            button = getButtonOrError(buttonId);
        } catch (Exception e) {
            Log.w(TAG, " button find error", e);
        }
        if (button == null) return;
        OrientationManager orientationManager = mAppController
                .getOrientationManager();
        if (orientationManager != null) {
            int degree = orientationManager.getDeviceOrientation().getDegrees();
            button.setTargetDegree(degree);
        } else {
            Log.d(TAG,"OrientationManager is null and can not set degree");
        }
        switch (buttonId) {
            case BUTTON_FLASH_DREAM:
                initializeFlashButton(button, cb, preCb, resId);
                break;
            // case BUTTON_TORCH_DREAM:
            // initializeTorchButton(button, cb, preCb,
            // R.array.video_flashmode_icons);
            // break;

            case BUTTON_CAMERA_DREAM:
                initializeCameraButton(button, cb, preCb, resId);
                break;
}

```

initializeCameraButton(button, cb, preCb, resId);  
 初始化button



```
public void initializeButton(int buttonId, ButtonCallback cb,
            ButtonCallback preCb) {
        MultiToggleImageButton button = null;
        try {
            button = getButtonOrError(buttonId);
        } catch (Exception e) {
            Log.w(TAG, " button find error", e);
        }
        if (button == null) return;
        OrientationManager orientationManager = mAppController
                .getOrientationManager();
        if (orientationManager != null) {
            int degree = orientationManager.getDeviceOrientation().getDegrees();
            button.setTargetDegree(degree);
        } else {
            Log.d(TAG,"OrientationManager is null and can not set degree");
        }
        switch (buttonId) {
            case BUTTON_FLASH_DREAM:
                initializeFlashButton(button, cb, preCb,
                		getFlashResID(BUTTON_FLASH_DREAM));
                break;
            // case BUTTON_TORCH_DREAM:
            // initializeTorchButton(button, cb, preCb,
            // R.array.video_flashmode_icons);
            // break;
            case BUTTON_CAMERA_DREAM:
                 if (!mIsTogglable) {
                     setButtonVisibility(buttonId,View.GONE);
                 } else {
                     setButtonVisibility(buttonId,View.VISABILITY);
                 }
                initializeCameraButton(button, cb, preCb,
                        R.array.dream_camera_id_icons);
                break;
}

```

setButtonVisibility 设置button的隐藏和显示


所以修改为:



```
public void initializeButton(int buttonId, ButtonCallback cb,
            ButtonCallback preCb) {
        MultiToggleImageButton button = null;
        try {
            button = getButtonOrError(buttonId);
        } catch (Exception e) {
            Log.w(TAG, " button find error", e);
        }
        if (button == null) return;
        OrientationManager orientationManager = mAppController
                .getOrientationManager();
        if (orientationManager != null) {
            int degree = orientationManager.getDeviceOrientation().getDegrees();
            button.setTargetDegree(degree);
        } else {
            Log.d(TAG,"OrientationManager is null and can not set degree");
        }
        switch (buttonId) {
            case BUTTON_FLASH_DREAM:
                initializeFlashButton(button, cb, preCb,
                		getFlashResID(BUTTON_FLASH_DREAM));
                break;
            // case BUTTON_TORCH_DREAM:
            // initializeTorchButton(button, cb, preCb,
            // R.array.video_flashmode_icons);
            // break;
            case BUTTON_CAMERA_DREAM:
                 if (!mIsTogglable) {
                     setButtonVisibility(buttonId,View.GONE);
                 } else {
                   -  setButtonVisibility(buttonId,View.VISABILITY);
                  +  setButtonVisibility(buttonId,View.GONE);
                 }
                initializeCameraButton(button, cb, preCb,
                        R.array.dream_camera_id_icons);
                break;
}

```

编译发现button隐藏了 默认打开前置摄像头 完美解决问题





