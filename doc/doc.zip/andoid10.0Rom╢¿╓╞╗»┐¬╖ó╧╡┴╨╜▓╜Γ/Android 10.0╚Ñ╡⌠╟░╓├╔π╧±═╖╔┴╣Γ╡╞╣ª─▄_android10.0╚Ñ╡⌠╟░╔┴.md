






在做展讯平板开发的时候，突然发现前置摄像头闪光灯打开时，拍照会白屏一下，然后拍照保存到相册 ，应该是闪光灯的bug.鉴于Camera2有点难调  
 所以就觉得前置摄像头去掉闪光灯功能


Camera2 app的路径为:  
 vendor\sprd\platform\packages\apps\DreamCamera2


而PhotoModule.java作为拍照的Module类 就先从这里寻找解决入口  
 vendor/sprd/platform/packages/apps/DreamCamera2/src/com/android/camera/PhotoModule.java


先看代码分析问题先:



```
/**
     * The start/stop preview should only run on the UI thread.
     */
    protected void startPreview(boolean optimize) {
        if (mCameraDevice == null) {
            Log.i(TAG, "attempted to start preview before camera device");
            // do nothing
            return;
        }

        if (!checkPreviewPreconditions()) {
            updateSettingAfterOpencamera(true);
            settingchange = true;
            return;
        }

        // ui
        /* SPRD: add for bug 380597: switch camera preview has a frame error @{ */
        mActivity.getCameraAppUI().resetPreview();
        /* @} */

        if(settingchange){
            settingchange = false;
        } else {
            updateSettingAfterOpencamera(optimize);
        }

        dosetPreviewDisplayspecial();

        if (isUseSurfaceView()) {
            if (optimize) {
                mCameraDevice.setPreviewDisplay(mActivity.getCameraAppUI().getSurfaceHolder());
            } else {
                mCameraDevice.setPreviewDisplayWithoutOptimize(mActivity.getCameraAppUI().getSurfaceHolder());
            }
        } else {
            if (optimize) {
                mCameraDevice.setPreviewTexture(mActivity.getCameraAppUI().getSurfaceTexture());
            } else {
                mCameraDevice.setPreviewTextureWithoutOptimize(mActivity.getCameraAppUI()
                        .getSurfaceTexture());
            }
        }

        if (CameraUtil.isSensorSelfShotEnable()
                || CameraUtil.getCurrentBackBlurRefocusVersion() == CameraUtil.BLUR_REFOCUS_VERSION_3
                || isBackRealDualCamVersion()
                || CameraUtil.getCurrentBlurCoveredId() != CameraUtil.BLUR_COVERED_ID_OFF) {
            mCameraDevice.setSensorSelfShotCallback(mHandler, this);
        }

        // SPRD: Fix bug 677589 black preview occurs when we switch to video module from photo
        // no need to handle surface update in process of the second onPreviewStarted()
        final boolean handleSurfaceUpdate = !mPreviewing;

        // If we're using API2 in portability layers, don't use
        // startPreviewWithCallback()
        // b/17576554
        CameraAgent.CameraStartPreviewCallback startPreviewCallback = new CameraAgent.CameraStartPreviewCallback() {
            @Override
            public void onPreviewStarted() {
                mHandler.post(new Runnable() {
                    public void run() {
                        mFocusManager.onPreviewStarted();
                        PhotoModule.this.onPreviewStarted();
                    }
                });
                if (mSnapshotOnIdle) {
                    mHandler.post(mDoSnapRunnable);
                }
                if(!isUseSurfaceView() || mHandler == null) {
                    return;
                }
                if (!handleSurfaceUpdate) {
                    return;
                }
                final Runnable hideModeCoverRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!mPaused) {
                            final CameraAppUI cameraAppUI = mActivity.getCameraAppUI();
                            cameraAppUI.onSurfaceTextureUpdated(cameraAppUI.getSurfaceTexture());
                            cameraAppUI.pauseTextureViewRendering();
                        }
                    }
                };
                final Runnable takePictureRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!mPaused) {
                            if (mActivity.getVoiceIntentCamera() && !mActivity.getOpenCameraOnly()) {
                                mDataModuleCurrent
                                        .set(Keys.KEY_VOICE_COUNTDOWN_DURATION,mActivity.getTimeDurationS());
                                onShutterButtonClick();
                                setCaptureCount(0);
                            }
                        }
                    }
                };
                if (useNewApi()) {
                    mCameraDevice.setSurfaceViewPreviewCallback(
                            new CameraAgent.CameraSurfaceViewPreviewCallback() {
                                @Override
                                public void onSurfaceUpdate() {
                                    Log.d(TAG, "SurfaceView: CameraSurfaceViewPreviewCallback");
                                    if (mPaused || mCameraDevice == null) {//SPRD:fix bug681598
                                        return;
                                    }
                                    mActivity.getCameraAppUI().hideModeCover();
                                    mHandler.post(hideModeCoverRunnable);
                                    Log.d(TAG,"Keys.KEY\_VOICE\_CAMERA\_DONE is "+mDataModuleCurrent.getInt(Keys.KEY_VOICE_CAMERA_DONE,0));
                                    if (mActivity.getVoiceIntentCamera() && mDataModuleCurrent.getInt(Keys.KEY_VOICE_CAMERA_DONE,0) != 1) {
                                        mHandler.post(takePictureRunnable);
                                    }
                                    // set callback to null
                                    mCameraDevice.setSurfaceViewPreviewCallback(null);
                                }
                            });
                } else {
                    mHandler.postDelayed(hideModeCoverRunnable, 450);
                }
            }
        };

        doStartPreviewSpecial(isCameraIdle(), isHdr(), mActivity, mCameraDevice, mHandler,
                mDisplayOrientation, isCameraFrontFacing(), mUI.getRootView(), mCameraSettings);//SPRD:fix bug624871
        doStartPreview(startPreviewCallback, mCameraDevice);
        if(getModuleTpye() != DreamModule.AUDIOPICTURE_MODULE||!isShutterClicked())
        mAppController.getCameraAppUI().setBottomPanelLeftRightClickable(true);
        Log.i(TAG, "startPreview end!");
    }

```

从上面代码中可以看到 在摄像头预览中回调中调用 doStartPreview(）;  
 这方法 接下来看doStartPreview();



```
   protected void doStartPreview(CameraAgent.CameraStartPreviewCallback startPreviewCallback, CameraAgent.CameraProxy cameraDevice) {
        if (useNewApi()) {
            mCameraDevice.startPreview();
            startPreviewCallback.onPreviewStarted();
        } else {
            mCameraDevice.startPreviewWithCallback(new Handler(Looper.getMainLooper()),
                    startPreviewCallback);
        }
        mPreviewing = true;

        // SPRD: Fix bug 659315, optimize camera launch time
        mUI.onPreviewStarted();
        //SPRD: Fix bug 1200379
        if(mUI instanceof ManualPhotoUI){
            ((ManualPhotoUI) mUI).setManualControlEnable(true);
 }
 mActivity.getButtonManager().enableCameraButton();// SPRD: Fix bug839922, switch icon is disabled
 OrientationManager orientationManager = mAppController
 .getOrientationManager();
 orientationManager.addOnOrientationChangeListener(this);
 mUI.onOrientationChanged(orientationManager,
 orientationManager.getDeviceOrientation());
    }

```

而这里有调用了 PhotoUI 的onPreviewStarted()方法  
 路径为 ：vendor/sprd/platform/packages/apps/DreamCamera2/src/com/android/camera/PhotoUI.java



```
public void onPreviewStarted() {
    long start = System.currentTimeMillis();
    if (mHasDelayWorkOnInit) {
        mHasDelayWorkOnInit = false;

        mActivity.getCameraAppUI().inflateStub();

        inflateLayout();
        updateLayout();
        waitInflateEnd();

        updateTopPanel();
    }
    showZoomProcessorIfNeeded();
    long end = System.currentTimeMillis();
    Log.i(TAG, "onPreviewStarted cost: " + (end - start));
}

```

接下来看下 inflateLayout();方法



```
public void inflateLayout(){
    ViewGroup extendPanelParent =mActivity.getCameraAppUI().getExtendPanelParent();
    extendPanelParent.removeAllViews();

    ViewGroup topPanelParent = (ViewGroup) mRootView
            .findViewById(R.id.top_panel_parent);
    topPanelParent.removeAllViews();

    CameraActivity.THREAD_POOL_EXECUTOR.execute(new Runnable() {
        public void run() {
            fitExtendPanel(extendPanelParent);

            fitTopPanel(topPanelParent);
            ((TopPanelListener)mController).updateTopPanel();

            latch.countDown();
        }
    });
    initializeViewByIntent();//SPRD:fix bug926165

}

```

而这里又会调用 ((TopPanelListener)mController).updateTopPanel();  
 来更新摄像头界面第一行的图标


实际上调用到PhoneModule.java 的updateTopPanel（）方法 因为此类实现了 TopPanelListener.java的updateTopPanel（）



```
 @Override
    public void updateTopPanel(){
        if (!mCameraDevice.getCapabilities().supports(CameraCapabilities.SceneMode.HDR)) {
            mUI.setButtonVisibility(ButtonManagerDream.BUTTON_HDR_DREAM,View.GONE);
        } else {
            mUI.setButtonVisibility(ButtonManagerDream.BUTTON_HDR_DREAM,View.VISIBLE);
        }

        if(CameraUtil.isIsMotionPhotoEnabled()){
            mUI.setButtonVisibility(ButtonManagerDream.BUTTON_MONTIONPHOTO_DREAM,View.VISIBLE);
            mUI.setButtonVisibility(ButtonManagerDream.BUTTON_HDR_DREAM,View.GONE);
        } else {
            mUI.setButtonVisibility(ButtonManagerDream.BUTTON_MONTIONPHOTO_DREAM,View.GONE);
        }

        if(isUpdateFlashTopButton()){
            updateFlashTopButton();
            if(CameraUtil.isFlashSupported(mCameraCapabilities, isCameraFrontFacing())){
                mActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateBatteryLevel(mActivity.getCurrentBattery());
                    }
                });
            }
        }
        updateRefocusTopButton();
        updateFilterTopButton();

        ButtonManager buttonManager = mActivity.getButtonManager();
        buttonManager.enableCameraButton();
    }

```

而在这里又会调用updateFlashTopButton();方法



```
protected void updateFlashTopButton() {
    if(CameraUtil.isFlashSupported(mCameraCapabilities, isCameraFrontFacing())){
        if(mDataModuleCurrent.isEnableSettingConfig(Keys.KEY_FLASH_MODE)){
            mUI.setButtonVisibility(ButtonManagerDream.BUTTON_FLASH_DREAM,View.VISIBLE);
            return;
        }
    }
    Log.i(TAG, "Flash is not supported");
    mUI.setButtonVisibility(ButtonManagerDream.BUTTON_FLASH_DREAM,View.GONE);
}

```

会通过CameraUtil.isFlashSupported(mCameraCapabilities, isCameraFrontFacing()来判断是否支持前置摄像头的闪光灯功能  
 如果不支持就把前置闪光灯给隐藏掉


所以修改就在这里  
 vendor/sprd/platform/packages/apps/DreamCamera2/src/com/android/camera/util/CameraUtil.java



```
public static boolean isFlashSupported(CameraCapabilities capabilities, boolean isFront) {
    Log.i(TAG, " capabilities = " + capabilities + " isFront = " + isFront);
    if(capabilities == null){
        return false;
    } else if (isFront){
        return mFrontFlashMode==VALUE_FRONT_FLASH_MODE_LCD;
    } else {
        return capabilities.isSupportFlash();//SPRD:fix bug1221519
    }
}

```

在判断是前置摄像头时isFront满足时 return false;


修改如下 ：



```
public static boolean isFlashSupported(CameraCapabilities capabilities, boolean isFront) {
    Log.i(TAG, " capabilities = " + capabilities + " isFront = " + isFront);
    if(capabilities == null){
        return false;
    } else if (isFront){
        - return mFrontFlashMode==VALUE_FRONT_FLASH_MODE_LCD;
        + return false;
    } else {
        return capabilities.isSupportFlash();//SPRD:fix bug1221519
    }
}

```




