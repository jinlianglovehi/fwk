



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.核心代码](#2.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.核心代码分析](#3.%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1AppInfoDashboardFragment.java 代码分析](#%C2%A0%203.1AppInfoDashboardFragment.java%20%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 app\_info\_settings.xml代码分析](#%C2%A0%203.2%20app_info_settings.xml%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.3 string.xml的值](#3.3%20string.xml%E7%9A%84%E5%80%BC)


[4. 增加功能实现显示使用时长](#4.%20%E5%A2%9E%E5%8A%A0%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E6%98%BE%E7%A4%BA%E4%BD%BF%E7%94%A8%E6%97%B6%E9%95%BF)




---



## 1.概述


在定制化系统Settings开发中，有需求要求统计每个app的详情页，增加app使用时长的统计功能，


## 2.核心代码



```
packages\apps\Settings\src\com\android\settings\applications\appinfo\AppInfoDashboardFragment.java
packages\apps\Settings\res\xml\app_info_settings.xml
```

## 3.核心代码分析


###   3.1AppInfoDashboardFragment.java 代码分析


通过搜索关键词在系统源码发现 app应用详情页 具体代码就是在AppInfoDashboardFragment.java的相关代码，接下来看下AppInfoDashboardFragment.java代码来实现具体的功能



```
  
   public class AppInfoDashboardFragment extends DashboardFragment
        implements ApplicationsState.Callbacks,
        ButtonActionDialogFragment.AppButtonsDialogListener {

    private static final String TAG = "AppInfoDashboard";

    // Menu identifiers
    @VisibleForTesting
    static final int UNINSTALL_ALL_USERS_MENU = 1;
    @VisibleForTesting
    static final int UNINSTALL_UPDATES = 2;
    static final int INSTALL_INSTANT_APP_MENU = 3;

    // Result code identifiers
    @VisibleForTesting
    static final int REQUEST_UNINSTALL = 0;
    private static final int REQUEST_REMOVE_DEVICE_ADMIN = 5;

    static final int SUB_INFO_FRAGMENT = 1;

    static final int LOADER_CHART_DATA = 2;
    static final int LOADER_STORAGE = 3;
    static final int LOADER_BATTERY = 4;

    public static final String ARG_PACKAGE_NAME = "package";
    public static final String ARG_PACKAGE_UID = "uid";

    private static final boolean localLOGV = false;

    private EnforcedAdmin mAppsControlDisallowedAdmin;
    private boolean mAppsControlDisallowedBySystem;

    private ApplicationsState mState;
    private ApplicationsState.Session mSession;
    private ApplicationsState.AppEntry mAppEntry;
    private PackageInfo mPackageInfo;
    private int mUserId;
    private String mPackageName;

    private DevicePolicyManager mDpm;
    private UserManager mUserManager;
    private PackageManager mPm;

    @VisibleForTesting
    boolean mFinishing;
    private boolean mListeningToPackageRemove;


    private boolean mInitialized;
    private boolean mShowUninstalled;
    private boolean mUpdatedSysApp = false;

    private List<Callback> mCallbacks = new ArrayList<>();

    private InstantAppButtonsPreferenceController mInstantAppButtonPreferenceController;
    private AppButtonsPreferenceController mAppButtonsPreferenceController;

    /**
     * Callback to invoke when app info has been changed.
     */
    public interface Callback {
        void refreshUi();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        final String packageName = getPackageName();
        use(TimeSpentInAppPreferenceController.class).setPackageName(packageName);

        use(AppDataUsagePreferenceController.class).setParentFragment(this);
        final AppInstallerInfoPreferenceController installer =
                use(AppInstallerInfoPreferenceController.class);
        installer.setPackageName(packageName);
        installer.setParentFragment(this);
        use(AppInstallerPreferenceCategoryController.class).setChildren(Arrays.asList(installer));
        use(AppNotificationPreferenceController.class).setParentFragment(this);
        use(AppOpenByDefaultPreferenceController.class).setParentFragment(this);
        use(AppPermissionPreferenceController.class).setParentFragment(this);
        use(AppPermissionPreferenceController.class).setPackageName(packageName);
        use(AppSettingPreferenceController.class)
                .setPackageName(packageName)
                .setParentFragment(this);
        use(AppStoragePreferenceController.class).setParentFragment(this);
        use(AppVersionPreferenceController.class).setParentFragment(this);
        use(InstantAppDomainsPreferenceController.class).setParentFragment(this);

        final WriteSystemSettingsPreferenceController writeSystemSettings =
                use(WriteSystemSettingsPreferenceController.class);
        writeSystemSettings.setParentFragment(this);

        final DrawOverlayDetailPreferenceController drawOverlay =
                use(DrawOverlayDetailPreferenceController.class);
        drawOverlay.setParentFragment(this);

        final PictureInPictureDetailPreferenceController pip =
                use(PictureInPictureDetailPreferenceController.class);
        pip.setPackageName(packageName);
        pip.setParentFragment(this);
        final ExternalSourceDetailPreferenceController externalSource =
                use(ExternalSourceDetailPreferenceController.class);
        externalSource.setPackageName(packageName);
        externalSource.setParentFragment(this);

        use(AdvancedAppInfoPreferenceCategoryController.class).setChildren(Arrays.asList(
                writeSystemSettings, drawOverlay, pip, externalSource));
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        mFinishing = false;
        final Activity activity = getActivity();
        mDpm = (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
        mUserManager = (UserManager) activity.getSystemService(Context.USER_SERVICE);
        mPm = activity.getPackageManager();
        if (!ensurePackageInfoAvailable(activity)) {
            return;
        }
        if (!ensureDisplayableModule(activity)) {
            return;
        }
        startListeningToPackageRemove();

        setHasOptionsMenu(true);
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        if (!ensurePackageInfoAvailable(getActivity())) {
            return;
        }
        super.onCreatePreferences(savedInstanceState, rootKey);
    }

    @Override
    public void onDestroy() {
        stopListeningToPackageRemove();
        super.onDestroy();
    }

    @Override
    public int getMetricsCategory() {
        return SettingsEnums.APPLICATIONS_INSTALLED_APP_DETAILS;
    }

    @Override
    public void onResume() {
        super.onResume();
        final Activity activity = getActivity();
        mAppsControlDisallowedAdmin = RestrictedLockUtilsInternal.checkIfRestrictionEnforced(
                activity, UserManager.DISALLOW_APPS_CONTROL, mUserId);
        mAppsControlDisallowedBySystem = RestrictedLockUtilsInternal.hasBaseUserRestriction(
                activity, UserManager.DISALLOW_APPS_CONTROL, mUserId);

        if (!refreshUi()) {
            setIntentAndFinish(true, true);
        }
    }

    @Override
    protected int getPreferenceScreenResId() {
        return R.xml.app_info_settings;
    }

    @Override
    protected String getLogTag() {
        return TAG;
    }

    @Override
    protected List<AbstractPreferenceController> createPreferenceControllers(Context context) {
        retrieveAppEntry();
        if (mPackageInfo == null) {
            return null;
        }
        final String packageName = getPackageName();
        final List<AbstractPreferenceController> controllers = new ArrayList<>();
        final Lifecycle lifecycle = getSettingsLifecycle();

        // The following are controllers for preferences that needs to refresh the preference state
        // when app state changes.
        controllers.add(
                new AppHeaderViewPreferenceController(context, this, packageName, lifecycle));

        for (AbstractPreferenceController controller : controllers) {
            mCallbacks.add((Callback) controller);
        }

        // The following are controllers for preferences that don't need to refresh the preference
        // state when app state changes.
        mInstantAppButtonPreferenceController =
                new InstantAppButtonsPreferenceController(context, this, packageName, lifecycle);
        controllers.add(mInstantAppButtonPreferenceController);
        mAppButtonsPreferenceController = new AppButtonsPreferenceController(
                (SettingsActivity) getActivity(), this, lifecycle, packageName, mState,
                REQUEST_UNINSTALL, REQUEST_REMOVE_DEVICE_ADMIN);
        controllers.add(mAppButtonsPreferenceController);
        controllers.add(new AppBatteryPreferenceController(context, this, packageName, lifecycle));
        controllers.add(new AppMemoryPreferenceController(context, this, lifecycle));
        controllers.add(new DefaultHomeShortcutPreferenceController(context, packageName));
        controllers.add(new DefaultBrowserShortcutPreferenceController(context, packageName));
        controllers.add(new DefaultPhoneShortcutPreferenceController(context, packageName));
        controllers.add(new DefaultEmergencyShortcutPreferenceController(context, packageName));
        controllers.add(new DefaultSmsShortcutPreferenceController(context, packageName));

        return controllers;
    }

    void addToCallbackList(Callback callback) {
        if (callback != null) {
            mCallbacks.add(callback);
        }
    }

    ApplicationsState.AppEntry getAppEntry() {
        return mAppEntry;
    }

    void setAppEntry(ApplicationsState.AppEntry appEntry) {
        mAppEntry = appEntry;
    }

    public PackageInfo getPackageInfo() {
        return mPackageInfo;
    }

    @Override
    public void onPackageSizeChanged(String packageName) {
        if (!TextUtils.equals(packageName, mPackageName)) {
            Log.d(TAG, "Package change irrelevant, skipping");
            return;
        }
        refreshUi();
    }

    /**
     * Ensures the {@link PackageInfo} is available to proceed. If it's not available, the fragment
     * will finish.
     *
     * @return true if packageInfo is available.
     */
    @VisibleForTesting
    boolean ensurePackageInfoAvailable(Activity activity) {
        if (mPackageInfo == null) {
            mFinishing = true;
            Log.w(TAG, "Package info not available. Is this package already uninstalled?");
            activity.finishAndRemoveTask();
            return false;
        }
        return true;
    }

    /**
     * Ensures the package is displayable as directed by {@link AppUtils#isHiddenSystemModule}.
     * If it's not, the fragment will finish.
     *
     * @return true if package is displayable.
     */
    @VisibleForTesting
    boolean ensureDisplayableModule(Activity activity) {
        if (AppUtils.isHiddenSystemModule(activity.getApplicationContext(), mPackageName)) {
            mFinishing = true;
            Log.w(TAG, "Package is hidden module, exiting: " + mPackageName);
            activity.finishAndRemoveTask();
            return false;
        }
        return true;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.add(0, UNINSTALL_UPDATES, 0, R.string.app_factory_reset)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        menu.add(0, UNINSTALL_ALL_USERS_MENU, 1, R.string.uninstall_all_users_text)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        if (mFinishing) {
            return;
        }
        super.onPrepareOptionsMenu(menu);
        menu.findItem(UNINSTALL_ALL_USERS_MENU).setVisible(shouldShowUninstallForAll(mAppEntry));
        mUpdatedSysApp = (mAppEntry.info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
        final MenuItem uninstallUpdatesItem = menu.findItem(UNINSTALL_UPDATES);
        final boolean uninstallUpdateDisabled = getContext().getResources().getBoolean(
                R.bool.config_disable_uninstall_update);
        uninstallUpdatesItem.setVisible(mUserManager.isAdminUser()
                && mUpdatedSysApp
                && !mAppsControlDisallowedBySystem
                && !uninstallUpdateDisabled);
        if (uninstallUpdatesItem.isVisible()) {
            RestrictedLockUtilsInternal.setMenuItemAsDisabledByAdmin(getActivity(),
                    uninstallUpdatesItem, mAppsControlDisallowedAdmin);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case UNINSTALL_ALL_USERS_MENU:
                uninstallPkg(mAppEntry.info.packageName, true, false);
                return true;
            case UNINSTALL_UPDATES:
                uninstallPkg(mAppEntry.info.packageName, false, false);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_UNINSTALL) {
            // Refresh option menu
            getActivity().invalidateOptionsMenu();
        }
        if (mAppButtonsPreferenceController != null) {
            mAppButtonsPreferenceController.handleActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void handleDialogClick(int id) {
        if (mAppButtonsPreferenceController != null) {
            mAppButtonsPreferenceController.handleDialogClick(id);
        }
    }

    @VisibleForTesting
    boolean shouldShowUninstallForAll(AppEntry appEntry) {
        boolean showIt = true;
        if (mUpdatedSysApp) {
            showIt = false;
        } else if (appEntry == null) {
            showIt = false;
        } else if ((appEntry.info.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
            showIt = false;
        } else if (mPackageInfo == null || mDpm.packageHasActiveAdmins(mPackageInfo.packageName)) {
            showIt = false;
        } else if (UserHandle.myUserId() != 0) {
            showIt = false;
        } else if (mUserManager.getUsers().size() < 2) {
            showIt = false;
        } else if (getNumberOfUserWithPackageInstalled(mPackageName) < 2
                && (appEntry.info.flags & ApplicationInfo.FLAG_INSTALLED) != 0) {
            showIt = false;
        } else if (AppUtils.isInstant(appEntry.info)) {
            showIt = false;
        }
        return showIt;
    }

    @VisibleForTesting
    boolean refreshUi() {
        retrieveAppEntry();
        if (mAppEntry == null) {
            return false; // onCreate must have failed, make sure to exit
        }

        if (mPackageInfo == null) {
            return false; // onCreate must have failed, make sure to exit
        }

        mState.ensureIcon(mAppEntry);

        // Update the preference summaries.
        for (Callback callback : mCallbacks) {
            callback.refreshUi();
        }
        if (mAppButtonsPreferenceController.isAvailable()) {
            mAppButtonsPreferenceController.refreshUi();
        }

        if (!mInitialized) {
            // First time init: are we displaying an uninstalled app?
            mInitialized = true;
            mShowUninstalled = (mAppEntry.info.flags & ApplicationInfo.FLAG_INSTALLED) == 0;
        } else {
            // All other times: if the app no longer exists then we want
            // to go away.
            try {
                final ApplicationInfo ainfo = getActivity().getPackageManager().getApplicationInfo(
                        mAppEntry.info.packageName,
                        PackageManager.MATCH_DISABLED_COMPONENTS
                                | PackageManager.MATCH_ANY_USER);
                if (!mShowUninstalled) {
                    // If we did not start out with the app uninstalled, then
                    // it transitioning to the uninstalled state for the current
                    // user means we should go away as well.
                    return (ainfo.flags & ApplicationInfo.FLAG_INSTALLED) != 0;
                }
            } catch (NameNotFoundException e) {
                return false;
            }
        }

        return true;
    }

    private void uninstallPkg(String packageName, boolean allUsers, boolean andDisable) {
        stopListeningToPackageRemove();
        // Create new intent to launch Uninstaller activity
        final Uri packageURI = Uri.parse("package:" + packageName);
        final Intent uninstallIntent = new Intent(Intent.ACTION_UNINSTALL_PACKAGE, packageURI);
        uninstallIntent.putExtra(Intent.EXTRA_UNINSTALL_ALL_USERS, allUsers);
        mMetricsFeatureProvider.action(
                getContext(), SettingsEnums.ACTION_SETTINGS_UNINSTALL_APP);
        startActivityForResult(uninstallIntent, REQUEST_UNINSTALL);
    }

    public static void startAppInfoFragment(Class<?> fragment, int title, Bundle args,
            SettingsPreferenceFragment caller, AppEntry appEntry) {
        // start new fragment to display extended information
        if (args == null) {
            args = new Bundle();
        }
        args.putString(ARG_PACKAGE_NAME, appEntry.info.packageName);
        args.putInt(ARG_PACKAGE_UID, appEntry.info.uid);
        new SubSettingLauncher(caller.getContext())
                .setDestination(fragment.getName())
                .setArguments(args)
                .setTitleRes(title)
                .setResultListener(caller, SUB_INFO_FRAGMENT)
                .setSourceMetricsCategory(caller.getMetricsCategory())
                .launch();
    }

    private void onPackageRemoved() {
        getActivity().finishActivity(SUB_INFO_FRAGMENT);
        getActivity().finishAndRemoveTask();
    }

    @VisibleForTesting
    int getNumberOfUserWithPackageInstalled(String packageName) {
        final List<UserInfo> userInfos = mUserManager.getUsers(true);
        int count = 0;

        for (final UserInfo userInfo : userInfos) {
            try {
                // Use this API to check whether user has this package
                final ApplicationInfo info = mPm.getApplicationInfoAsUser(
                        packageName, PackageManager.GET_META_DATA, userInfo.id);
                if ((info.flags & ApplicationInfo.FLAG_INSTALLED) != 0) {
                    count++;
                }
            } catch (NameNotFoundException e) {
                Log.e(TAG, "Package: " + packageName + " not found for user: " + userInfo.id);
            }
        }

        return count;
    }

    private String getPackageName() {
        if (mPackageName != null) {
            return mPackageName;
        }
        final Bundle args = getArguments();
        mPackageName = (args != null) ? args.getString(ARG_PACKAGE_NAME) : null;
        if (mPackageName == null) {
            final Intent intent = (args == null) ?
                    getActivity().getIntent() : (Intent) args.getParcelable("intent");
            if (intent != null) {
                mPackageName = intent.getData().getSchemeSpecificPart();
            }
        }
        return mPackageName;
    }

    @VisibleForTesting
    void retrieveAppEntry() {
        final Activity activity = getActivity();
        if (activity == null || mFinishing) {
            return;
        }
        if (mState == null) {
            mState = ApplicationsState.getInstance(activity.getApplication());
            mSession = mState.newSession(this, getSettingsLifecycle());
        }
        mUserId = UserHandle.myUserId();
        mAppEntry = mState.getEntry(getPackageName(), UserHandle.myUserId());
        if (mAppEntry != null) {
            // Get application info again to refresh changed properties of application
            try {
                mPackageInfo = activity.getPackageManager().getPackageInfo(
                        mAppEntry.info.packageName,
                        PackageManager.MATCH_DISABLED_COMPONENTS |
                                PackageManager.MATCH_ANY_USER |
                                PackageManager.GET_SIGNATURES |
                                PackageManager.GET_PERMISSIONS);
            } catch (NameNotFoundException e) {
                Log.e(TAG, "Exception when retrieving package:" + mAppEntry.info.packageName, e);
            }
        } else {
            Log.w(TAG, "Missing AppEntry; maybe reinstalling?");
            mPackageInfo = null;
        }
    }

    private void setIntentAndFinish(boolean finish, boolean appChanged) {
        if (localLOGV) Log.i(TAG, "appChanged=" + appChanged);
        final Intent intent = new Intent();
        intent.putExtra(ManageApplications.APP_CHG, appChanged);
        final SettingsActivity sa = (SettingsActivity) getActivity();
        sa.finishPreferencePanel(Activity.RESULT_OK, intent);
        mFinishing = true;
    }
    .....
}

    @Override
    protected int getPreferenceScreenResId() {
        return R.xml.app_info_settings;
    }
    从这里可以看出 布局文件就是 xml中的app_info_settings.xml
```

###    在AppInfoDashboardFragment.java中通过获取屏幕布局xml发现


### @Override     protected int getPreferenceScreenResId() {         return R.xml.app\_info\_settings;     }     从这里可以看出 布局文件就是 xml中的app\_info\_settings.xml


接下来看下app\_info\_settings.xml的相关布局


###   3.2 app\_info\_settings.xml代码分析



```
 <PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:key="installed_app_detail_settings_screen"
    settings:initialExpandedChildrenCount="6">

    <com.android.settingslib.widget.LayoutPreference
        android:key="header_view"
        android:layout="@layout/settings_entity_header"
        android:selectable="false"
        android:order="-10000"
        settings:allowDividerBelow="true"/>

    <com.android.settingslib.widget.LayoutPreference
        android:key="instant_app_buttons"
        android:layout="@layout/instant_app_buttons"
        android:selectable="false"
        android:order="-9999"
        settings:allowDividerAbove="true"
        settings:allowDividerBelow="true"/>

    <com.android.settingslib.widget.ActionButtonsPreference
        android:key="action_buttons"
        android:order="-9998" />

    <Preference
        android:key="notification_settings"
        android:title="@string/notifications_label"
        settings:controller="com.android.settings.applications.appinfo.AppNotificationPreferenceController"
        settings:allowDividerAbove="true"/>

    <com.android.settings.widget.FixedLineSummaryPreference
        android:key="permission_settings"
        android:title="@string/permissions_label"
        android:summary="@string/summary_placeholder"
        settings:summaryLineCount="1"
        settings:controller="com.android.settings.applications.appinfo.AppPermissionPreferenceController" />

    <Preference
        android:key="storage_settings"
        android:title="@string/storage_settings_for_app"
        android:summary="@string/summary_placeholder"
        settings:controller="com.android.settings.applications.appinfo.AppStoragePreferenceController" />

    <com.android.settings.applications.AppDomainsPreference
        android:key="instant_app_launch_supported_domain_urls"
        android:title="@string/app_launch_supported_domain_urls_title"
        android:selectable="true"
        settings:controller="com.android.settings.applications.appinfo.InstantAppDomainsPreferenceController" />

    <Preference
        android:key="data_settings"
        android:title="@string/data_usage_app_summary_title"
        android:summary="@string/summary_placeholder"
        settings:controller="com.android.settings.applications.appinfo.AppDataUsagePreferenceController" />

    <Preference
        android:key="time_spent_in_app"
        android:title="@string/time_spent_in_app_pref_title"
        settings:controller="com.android.settings.applications.appinfo.TimeSpentInAppPreferenceController" />

    <Preference
        android:key="battery"
        android:title="@string/power_usage_summary_title"
        android:summary="@string/summary_placeholder" />

    <Preference
        android:key="preferred_settings"
        android:title="@string/launch_by_default"
        android:summary="@string/summary_placeholder"
        android:selectable="true"
        settings:controller="com.android.settings.applications.appinfo.AppOpenByDefaultPreferenceController" />

    <Preference
        android:key="memory"
        android:title="@string/memory_settings_title"
        android:summary="@string/summary_placeholder"
        android:enabled="false" />

    <!-- Default apps shortcuts -->
    <Preference
        android:key="default_home"
        android:title="@string/home_app"
        android:summary="@string/summary_placeholder" />

    <Preference
        android:key="default_browser"
        android:title="@string/default_browser_title"
        android:summary="@string/summary_placeholder" />

    <Preference
        android:key="default_phone_app"
        android:title="@string/default_phone_title"
        android:summary="@string/default_phone_title" />

    <Preference
        android:key="default_emergency_app"
        android:title="@string/default_emergency_app"
        android:summary="@string/summary_placeholder" />

    <Preference
        android:key="default_sms_app"
        android:title="@string/sms_application_title"
        android:summary="@string/summary_placeholder" />

    <Preference
        android:key="app_usertimes"
        android:title="@string/app_user_time"
        android:summary="@string/summary_placeholder" />

    <!-- Advanced apps settings -->
    <PreferenceCategory
        android:key="advanced_app_info"
        android:title="@string/advanced_apps"
        settings:controller="com.android.settings.applications.appinfo.AdvancedAppInfoPreferenceCategoryController">

        <Preference
            android:key="system_alert_window"
            android:title="@string/draw_overlay"
            android:summary="@string/summary_placeholder"
            settings:controller="com.android.settings.applications.appinfo.DrawOverlayDetailPreferenceController" />

        <Preference
            android:key="write_settings_apps"
            android:title="@string/write_settings"
            android:summary="@string/summary_placeholder"
            settings:controller="com.android.settings.applications.appinfo.WriteSystemSettingsPreferenceController" />

        <Preference
            android:key="picture_in_picture"
            android:title="@string/picture_in_picture_app_detail_title"
            android:summary="@string/summary_placeholder"
            settings:controller="com.android.settings.applications.specialaccess.pictureinpicture.PictureInPictureDetailPreferenceController" />

        <Preference
            android:key="install_other_apps"
            android:title="@string/install_other_apps"
            android:summary="@string/summary_placeholder"
            settings:controller="com.android.settings.applications.appinfo.ExternalSourceDetailPreferenceController" />

    </PreferenceCategory>

    <!-- App installer info -->
    <PreferenceCategory
        android:key="app_installer"
        android:title="@string/app_install_details_group_title"
        settings:controller="com.android.settings.applications.appinfo.AppInstallerPreferenceCategoryController">

        <Preference
            android:key="app_info_store"
            android:title="@string/app_install_details_title"
            settings:controller="com.android.settings.applications.appinfo.AppInstallerInfoPreferenceController" />

    </PreferenceCategory>

    <Preference
        android:key="app_settings_link"
        android:title="@string/app_settings_link"
        settings:controller="com.android.settings.applications.appinfo.AppSettingPreferenceController"
        settings:allowDividerAbove="true" />

    <Preference
        android:key="app_version"
        android:selectable="false"
        android:order="9999"
        settings:controller="com.android.settings.applications.appinfo.AppVersionPreferenceController"
        settings:allowDividerAbove="true"
        settings:enableCopying="true"/>

</PreferenceScreen>

```

###  在 xml 中 增加 最近使用情况的 Preference 控件作为显示使用时长的布局


### 3.3 string.xml的值



```
--- a/packages/apps/Settings/res/values-zh-rCN/strings.xml
+++ b/packages/apps/Settings/res/values-zh-rCN/strings.xml
@@ -21,6 +21,7 @@
     <string name="create" msgid="3578857613172647409">"创建"</string>
     <string name="allow" msgid="3349662621170855910">"允许"</string>
     <string name="deny" msgid="6947806159746484865">"拒绝"</string>
+    <string name="app_user_time">最近使用时间</string>
     <string name="device_info_default" msgid="7847265875578739287">"未知"</string>
     <plurals name="show_dev_countdown" formatted="false" msgid="7201398282729229649">
       <item quantity="other">现在只需再执行 <xliff:g id="STEP_COUNT_1">%1$d</xliff:g> 步操作即可进入开发者模式。</item>
```

### 增加string的相关资源


### 4. 增加功能实现显示使用时长


UsageStatsManager是系统提供专门用于统计app的api  
 UsageStats是在指定时间区间内某个应用使用统计数据的封装类。包含的公开方法及对应的作用如下：


方法 用途  
 getFirstTimeStamp() 获取指定时间区间内应用第一次使用时间戳  
 getLastTimeStamp() 获取指定时间区间内应用最后一次使用时间戳  
 getLastTimeUsed() 获取应用最后一次使用时间戳  
 getPackageName() 获取应用包名  
 getTotalTimeInForeground() 获取应用在前台的时间  
 EventStats  
 EventStats是在指定时间区间内某个类型事件统计数据的封装类。包含的公开方法及对应的作用如下：


方法 用途  
 getCount() 获取在指定时间区间内事件发生的次数  
 getEventType() 获取事件类型  
 getFirstTimeStamp() 获取指定时间区间内这个事件第一次发生的时间戳  
 getLastEventTime() 获取这个事件最后一次发生的时间戳  
 getLastTimeStamp() 获取指定时间区间内这个事件最后一次发生的时间戳  
 getTotalTime() 获取这个事件总共发生的次数



```


4.1 AppInfoDashboardFragment.java增加功能的实现
在onCreatePreferences(Bundle savedInstanceState, String rootKey)中获取控件 然后设置使用时间长的值

@Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        if (!ensurePackageInfoAvailable(getActivity())) {
            return;
        }
        super.onCreatePreferences(savedInstanceState, rootKey);
		PreferenceScreen preferenceScreen = getPreferenceScreen();
        Preference uerstimers_pre = preferenceScreen.findPreference("app_usertimes");
		uerstimers_pre.setSummary(getappusertimes());
    }

   //根据app 获取运行时长
    private String getappusertimes(){
		String usertimes = "";
        UsageStatsManager usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
		try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);  
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            List<UsageStats> stats =usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,
                    calendar.getTimeInMillis(), System.currentTimeMillis());
            for(int i=0;i<stats.size();i++){
                final android.app.usage.UsageStats pkgStats = stats.get(i);
                String package_name=pkgStats.getPackageName();
                long time_begin= pkgStats.getFirstTimeStamp();
                long time_end=pkgStats.getLastTimeStamp();
                long time_used=pkgStats.getLastTimeUsed();
                long time_total=pkgStats.getTotalTimeInForeground();
                if(time_total>0&&package_name.equals(getPackageName())) {
		Log.e("MainActivity","package_name:"+package_name+"--time_begin:"+time_begin+"--time_used:"+time_used+"--time_total:"+time_total);
		return time_total/1000+"s";
	}
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
		return usertimes;
}
  
```



