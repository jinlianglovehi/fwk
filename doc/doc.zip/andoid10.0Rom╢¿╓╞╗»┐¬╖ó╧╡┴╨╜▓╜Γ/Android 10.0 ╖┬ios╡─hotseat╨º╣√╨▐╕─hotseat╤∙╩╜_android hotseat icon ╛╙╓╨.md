






### 1.概述


在10.0的系统产品开发中，在最近项目需求的需要，hotseat效果要仿ios一样不需要全屏的效果 居中显示就行了，所以就要看hotseat的具体布局显示了  
 效果图如下:


![在这里插入图片描述](https://img-blog.csdnimg.cn/138bb6ad4fa24d1d8624193c3707c0a2.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAQW5kcm9pZCBmcmFtZXdvcmvlt6XnqIvluIg=,size_20,color_FFFFFF,t_70,g_se,x_16#pic_center)


### 2.仿ios的hotseat效果修改hotseat样式的核心类



```
packages/apps/Launcher3/res/layout/launcher.xml
/packages/apps/Launcher3/src/com/android/launcher3/Launcher.java

```

### 3.仿ios的hotseat效果修改hotseat样式的核心功能分析和实现


在Launcher3中主页面的布局是在laucher.xml中,所以  
 接下来先看hotseat布局 在laucher.xml中


### 3.1laucher.xml相关源码分析



```
<com.android.launcher3.LauncherRootView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:id="@+id/launcher"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:fitsSystemWindows="true">

    <com.android.launcher3.dragndrop.DragLayer
        android:id="@+id/drag\_layer"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:importantForAccessibility="no">

        <!-- The workspace contains 5 screens of cells -->
        <!-- DO NOT CHANGE THE ID -->
        <com.android.launcher3.Workspace
            android:id="@+id/workspace"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent"
            android:layout_gravity="center"
            android:theme="@style/HomeScreenElementTheme"
            launcher:pageIndicator="@+id/page\_indicator" />

        <include layout="@layout/memoryinfo\_ext" />

        <!-- DO NOT CHANGE THE ID -->
        <include
            android:id="@+id/hotseat"
            layout="@layout/hotseat" />

        <include
            android:id="@+id/overview\_panel"
            layout="@layout/overview\_panel"
            android:visibility="gone" />

        <!-- Keep these behind the workspace so that they are not visible when
         we go into AllApps -->
        <com.sprd.ext.pageindicators.WorkspacePageIndicatorLine
            android:id="@+id/page\_indicator"
            android:layout_width="match\_parent"
            android:layout_height="@dimen/vertical\_drag\_handle\_size"
            android:layout_gravity="bottom"
            android:theme="@style/HomeScreenElementTheme" />

        <include
            android:id="@+id/page\_indicator\_customize"
            layout="@layout/page\_indicator\_customize" />

        <include
            android:id="@+id/drop\_target\_bar"
            layout="@layout/drop\_target\_bar" />

        <include
            android:id="@+id/scrim\_view"
            layout="@layout/scrim\_view" />

        <include
            android:id="@+id/apps\_view"
            layout="@layout/all\_apps"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent" />

    </com.android.launcher3.dragndrop.DragLayer>

</com.android.launcher3.LauncherRootView>

```

通过上述源码的分析可以发现  
 在 launcher.xml中



```
  <include
            android:id="@+id/hotseat"
            layout="@layout/hotseat" />

```

hotseat 布局 就是hotseat.xml 就是所谓的hotseat了  
 接下来看下Hotseat的布局类



```
<com.android.launcher3.Hotseat
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:id="@+id/hotseat"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:theme="@style/HomeScreenElementTheme"
    android:importantForAccessibility="no"
    launcher:containerType="hotseat" />

```

而hotseat布局 也就是 Hotseat.java  
 接下来看Hotseat.java 源码，看下具体功能实现


### 3.2Hotseat.java 源码的相关源码分析



```
public class Hotseat extends CellLayout implements LogContainerProvider, Insettable, Transposable {

    @ViewDebug.ExportedProperty(category = "launcher")
    public boolean mHasVerticalHotseat;
    private final HotseatController mController;

    public Hotseat(Context context) {
        this(context, null);
    }

    public Hotseat(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public Hotseat(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mController = LauncherAppMonitor.getInstance(context).getHotseatController();
		
    }

    public HotseatController getController() {
        return mController;
    }

    /* Get the orientation specific coordinates given an invariant order in the hotseat. */
    public int getCellXFromOrder(int rank) {
        return mHasVerticalHotseat ? 0 : rank;
    }

    public int getCellYFromOrder(int rank) {
        return mHasVerticalHotseat ? (getCountY() - (rank + 1)) : 0;
    }

    public void resetLayout(boolean hasVerticalHotseat) {
        removeAllViewsInLayout();
        mHasVerticalHotseat = hasVerticalHotseat;
        InvariantDeviceProfile idp = mActivity.getDeviceProfile().inv;
        if (hasVerticalHotseat) {
            setGridSize(1, idp.numHotseatIcons);
        } else {
            setGridSize(idp.numHotseatIcons, 1);
        }
       // 添加背景
	setBackgroundResource(R.drawable.shape_corner);
    }

    @Override
    public void fillInLogContainerData(View v, ItemInfo info, Target target, Target targetParent) {
        target.gridX = info.cellX;
        target.gridY = info.cellY;
        targetParent.containerType = LauncherLogProto.ContainerType.HOTSEAT;
    }

    @Override
    public void setInsets(Rect insets) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        DeviceProfile grid = mActivity.getWallpaperDeviceProfile();
        insets = grid.getInsets();

        if (grid.isVerticalBarLayout()) {
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            if (grid.isSeascape()) {
                lp.gravity = Gravity.LEFT;
                lp.width = grid.hotseatBarSizePx + insets.left;
            } else {
                lp.gravity = Gravity.RIGHT;
                lp.width = grid.hotseatBarSizePx + insets.right;
            }
        } else {
            lp.gravity = Gravity.BOTTOM;
            lp.width = 960;
			lp.leftMargin=480;
			lp.bottomMargin = 100;
            lp.height = grid.hotseatBarSizePx;
        }
        Rect padding = grid.getHotseatLayoutPadding();
        setPadding(0, padding.top, 0,0);
        
        setLayoutParams(lp);
        InsettableFrameLayout.dispatchInsets(this, insets);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Don't let if follow through to workspace
        return true;
    }

    @Override
    public RotationMode getRotationMode() {
        return Launcher.getLauncher(getContext()).getRotationMode();
    }
}

```

在Hotseat的源码分析发现，在布局的时候都会调用resetLayout （）方法进行重新布局  
 所以resetLayout 就是负责布局的 当hotseat 增加减少时都会重新布局，接下来看下  
 这个方法



```
public void resetLayout(boolean hasVerticalHotseat) {
        removeAllViewsInLayout();
        mHasVerticalHotseat = hasVerticalHotseat;
        InvariantDeviceProfile idp = mActivity.getDeviceProfile().inv;
        if (hasVerticalHotseat) {
            setGridSize(1, idp.numHotseatIcons);
        } else {
            setGridSize(idp.numHotseatIcons, 1);
        }
       // 添加背景
	setBackgroundResource(R.drawable.shape_corner);
    }

```

所以在 resetLayout(boolean hasVerticalHotseat)给hotseat 添加背景就可以了  
 接下来添加圆角背景的xml，实现如下  
 shape\_corner.xml



```
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <!--背景颜色-->
    <solid android:color="#FFFAFA" />
    <!--角的半径-->
    <corners android:radius="10dp"/>
    <!--边框颜色-->
    <stroke android:width="1dp" android:color="#00000000" />
</shape>

```

通过在setInset() 中修改FrameLayout.LayoutParams的长宽的参数，从而实现  
 对hotseat的宽高的设置，达到设置背景的目的


而setInset() 负责设置绘制布局 的参数  
 具体修改为：



```
 public void setInsets(Rect insets) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
        DeviceProfile grid = mActivity.getWallpaperDeviceProfile();
        insets = grid.getInsets();
        //竖屏布局
        if (grid.isVerticalBarLayout()) {
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            if (grid.isSeascape()) {
                lp.gravity = Gravity.LEFT;
                lp.width = grid.hotseatBarSizePx + insets.left;
            } else {
                lp.gravity = Gravity.RIGHT;
                lp.width = grid.hotseatBarSizePx + insets.right;
            }
        } else {
           // 横屏布局
           // 平板开发项目 固定横屏，所以要在这里设置参数
            lp.gravity = Gravity.BOTTOM;
           // 设置宽高  左边底部的间距
            lp.width = 960;
			lp.leftMargin=480;
			lp.bottomMargin = 100;
            lp.height = grid.hotseatBarSizePx;
        }
        Rect padding = grid.getHotseatLayoutPadding();
        // 设置padding 布局
           setPadding(0, padding.top, 0,0);
        
        setLayoutParams(lp);
        InsettableFrameLayout.dispatchInsets(this, insets);
    }

```

其实只需要修改lp的参数就行了 然后hotseat 会根据长宽等参数 来具体布局每一个hotseat的具体坐标





