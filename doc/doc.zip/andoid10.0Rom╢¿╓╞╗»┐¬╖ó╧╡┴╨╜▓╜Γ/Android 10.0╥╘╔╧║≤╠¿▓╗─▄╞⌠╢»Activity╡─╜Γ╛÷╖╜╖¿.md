






### 1.概述


在android Q以后 google不允许在后台service 广播等等启动Activity 具体请看google文档  
 https://developer.android.google.cn/guide/components/activities/background-starts 有一些做法 也可以通过在后台发送一个通知的方式 然后点击通知的方式来启动Activity 这也是一种方法 但是不是很方便 所以既然做定制化开发 通过修改系统源码的方式 也是可以解决这个问题的


### 2.10.0以上后台不能启动Activity的解决方法的核心类



```
frameworks\base\services\core\java\com\android\server\wm\ActivityStarter.java
frameworks/base/services/core/java/com/android/server/wm/ActivityTaskManagerService.java

```

### 3.10.0以上后台不能启动Activity的解决方法的核心功能分析和实现


在android系统中关于activity的启动都是由AMS负责启动的，10.0以后具体由ATMS来负责这部分功能  
 首选在AMS来负责启动Activity  
 而Ams中在后台启动Activity 会执行moveTaskToFront(）


### 3.1 ActivityTaskManagerService.java相关管理Activity的方法



```
    @Override
    public void moveTaskToFront(IApplicationThread appThread, String callingPackage, int taskId,
            int flags, Bundle bOptions) {
        mActivityTaskManager.moveTaskToFront(appThread, callingPackage, taskId, flags, bOptions);
    }

而在ActivityTaskManagerService.java 中 moveTaskToFront() 如下:

/**
     * TODO: Add mController hook
     */
    @Override
    public void moveTaskToFront(IApplicationThread appThread, String callingPackage, int taskId,
            int flags, Bundle bOptions) {
        mAmInternal.enforceCallingPermission(android.Manifest.permission.REORDER_TASKS, "moveTaskToFront()");

        if (DEBUG_STACK) Slog.d(TAG_STACK, "moveTaskToFront: moving taskId=" + taskId);
        synchronized (mGlobalLock) {
            moveTaskToFrontLocked(appThread, callingPackage, taskId, flags,
                    SafeActivityOptions.fromBundle(bOptions), false /* fromRecents */);
        }
    }

    void moveTaskToFrontLocked(@Nullable IApplicationThread appThread,
            @Nullable String callingPackage, int taskId, int flags, SafeActivityOptions options,
            boolean fromRecents) {

        final int callingPid = Binder.getCallingPid();
        final int callingUid = Binder.getCallingUid();
        if (!isSameApp(callingUid, callingPackage)) {
            String msg = "Permission Denial: moveTaskToFrontLocked() from pid="
                    + Binder.getCallingPid() + " as package " + callingPackage;
            Slog.w(TAG, msg);
            throw new SecurityException(msg);
        }
        if (!checkAppSwitchAllowedLocked(callingPid, callingUid, -1, -1, "Task to front")) {
            SafeActivityOptions.abort(options);
            return;
        }
        final long origId = Binder.clearCallingIdentity();
        WindowProcessController callerApp = null;
        if (appThread != null) {
            callerApp = getProcessController(appThread);
        }
        final ActivityStarter starter = getActivityStartController().obtainStarter(
                null /* intent */, "moveTaskToFront");
        if (starter.shouldAbortBackgroundActivityStart(callingUid, callingPid, callingPackage, -1,
                -1, callerApp, null, false, null)) {
            if (!isBackgroundActivityStartsEnabled()) {
                return;
            }
        }
        try {
            final TaskRecord task = mRootActivityContainer.anyTaskForId(taskId);
            if (task == null) {
                Slog.d(TAG, "Could not find task for id: "+ taskId);
                SafeActivityOptions.abort(options);
                return;
            }
            if (getLockTaskController().isLockTaskModeViolation(task)) {
                Slog.e(TAG, "moveTaskToFront: Attempt to violate Lock Task Mode");
                SafeActivityOptions.abort(options);
                return;
            }
            ActivityOptions realOptions = options != null
                    ? options.getOptions(mStackSupervisor)
                    : null;
            mStackSupervisor.findTaskToMoveToFront(task, flags, realOptions, "moveTaskToFront",
                    false /* forceNonResizable */);

            final ActivityRecord topActivity = task.getTopActivity();
            if (topActivity != null) {

                // We are reshowing a task, use a starting window to hide the initial draw delay
                // so the transition can start earlier.
                topActivity.showStartingWindow(null /* prev */, false /* newTask */,
                        true /* taskSwitch */, fromRecents);
            }
        } finally {
            Binder.restoreCallingIdentity(origId);
        }
    }

```

从上述代码中可以看到ATMS的moveTaskToFront最终调用ActivityStarter.java的相关代码负责  
 从代码中可以看到 starter.shouldAbortBackgroundActivityStart(）是判断是否是后台启动 如果是直接返回


接下来看ActivityStarter 中 shouldAbortBackgroundActivityStart()  
 路径:frameworks\base\services\core\java\com\android\server\wm\ActivityStarter.java


### 3.2接下来看下ActivityStarter.java相关源码



```
boolean shouldAbortBackgroundActivityStart(int callingUid, int callingPid,
            final String callingPackage, int realCallingUid, int realCallingPid,
            WindowProcessController callerApp, PendingIntentRecord originatingPendingIntent,
            boolean allowBackgroundActivityStart, Intent intent) {
        // don't abort for the most important UIDs
 final int callingAppId = UserHandle.getAppId(callingUid);
 if (callingUid == Process.ROOT\_UID || callingAppId == Process.SYSTEM\_UID
 || callingAppId == Process.NFC\_UID) {
 return false;
 }
 // don't abort if the callingUid has a visible window or is a persistent system process
        final int callingUidProcState = mService.getUidState(callingUid);
        final boolean callingUidHasAnyVisibleWindow =
                mService.mWindowManager.mRoot.isAnyNonToastWindowVisibleForUid(callingUid);
        final boolean isCallingUidForeground = callingUidHasAnyVisibleWindow
                || callingUidProcState == ActivityManager.PROCESS_STATE_TOP
                || callingUidProcState == ActivityManager.PROCESS_STATE_BOUND_TOP;
        final boolean isCallingUidPersistentSystemProcess =
                callingUidProcState <= ActivityManager.PROCESS_STATE_PERSISTENT_UI;
        if (callingUidHasAnyVisibleWindow || isCallingUidPersistentSystemProcess) {
            return false;
        }
        // take realCallingUid into consideration
        final int realCallingUidProcState = (callingUid == realCallingUid)
                ? callingUidProcState
                : mService.getUidState(realCallingUid);
        final boolean realCallingUidHasAnyVisibleWindow = (callingUid == realCallingUid)
                ? callingUidHasAnyVisibleWindow
                : mService.mWindowManager.mRoot.isAnyNonToastWindowVisibleForUid(realCallingUid);
        final boolean isRealCallingUidForeground = (callingUid == realCallingUid)
                ? isCallingUidForeground
                : realCallingUidHasAnyVisibleWindow
                        || realCallingUidProcState == ActivityManager.PROCESS_STATE_TOP;
        final int realCallingAppId = UserHandle.getAppId(realCallingUid);
        final boolean isRealCallingUidPersistentSystemProcess = (callingUid == realCallingUid)
                ? isCallingUidPersistentSystemProcess
                : (realCallingAppId == Process.SYSTEM_UID)
                        || realCallingUidProcState <= ActivityManager.PROCESS_STATE_PERSISTENT_UI;
        if (realCallingUid != callingUid) {
            // don't abort if the realCallingUid has a visible window
 if (realCallingUidHasAnyVisibleWindow) {
 return false;
 }
 // if the realCallingUid is a persistent system process, abort if the IntentSender
 // wasn't whitelisted to start an activity
            if (isRealCallingUidPersistentSystemProcess && allowBackgroundActivityStart) {
                return false;
            }
            // don't abort if the realCallingUid is an associated companion app
 if (mService.isAssociatedCompanionApp(UserHandle.getUserId(realCallingUid),
 realCallingUid)) {
 return false;
 }
 }
 // don't abort if the callingUid has START_ACTIVITIES_FROM_BACKGROUND permission
        if (mService.checkPermission(START_ACTIVITIES_FROM_BACKGROUND, callingPid, callingUid)
                == PERMISSION_GRANTED) {
            return false;
        }
        // don't abort if the caller has the same uid as the recents component
 if (mSupervisor.mRecentTasks.isCallerRecents(callingUid)) {
 return false;
 }

 
 // add code start 根据包名来判断是否后台启动 直接返回fasle 即可
 if(callingPackage.equals("com.pne.jnitest")){
 return false;
 }
 // add code end


 // don't abort if the callingUid is the device owner
        if (mService.isDeviceOwner(callingUid)) {
            return false;
        }
        // don't abort if the callingUid has companion device
 final int callingUserId = UserHandle.getUserId(callingUid);
 if (mService.isAssociatedCompanionApp(callingUserId, callingUid)) {
 return false;
 }
 // If we don't have callerApp at this point, no caller was provided to startActivity().
        // That's the case for PendingIntent-based starts, since the creator's process might not be
        // up and alive. If that's the case, we retrieve the WindowProcessController for the send()
 // caller, so that we can make the decision based on its foreground/whitelisted state.
 int callerAppUid = callingUid;
 if (callerApp == null) {
 callerApp = mService.getProcessController(realCallingPid, realCallingUid);
 callerAppUid = realCallingUid;
 }
 // don't abort if the callerApp or other processes of that uid are whitelisted in any way
        if (callerApp != null) {
            // first check the original calling process
            if (callerApp.areBackgroundActivityStartsAllowed()) {
                return false;
            }
            // only if that one wasn't whitelisted, check the other ones
 final ArraySet<WindowProcessController> uidProcesses =
 mService.mProcessMap.getProcesses(callerAppUid);
 if (uidProcesses != null) {
 for (int i = uidProcesses.size() - 1; i >= 0; i--) {
 final WindowProcessController proc = uidProcesses.valueAt(i);
 if (proc != callerApp && proc.areBackgroundActivityStartsAllowed()) {
 return false;
 }
 }
 }
 }
 // don't abort if the callingUid has SYSTEM_ALERT_WINDOW permission
        if (mService.hasSystemAlertWindowPermission(callingUid, callingPid, callingPackage)) {
            Slog.w(TAG, "Background activity start for " + callingPackage
                    + " allowed because SYSTEM\_ALERT\_WINDOW permission is granted.");
            return false;
        }
        // anything that has fallen through would currently be aborted
        Slog.w(TAG, "Background activity start [callingPackage: " + callingPackage
                + "; callingUid: " + callingUid
                + "; isCallingUidForeground: " + isCallingUidForeground
                + "; isCallingUidPersistentSystemProcess: " + isCallingUidPersistentSystemProcess
                + "; realCallingUid: " + realCallingUid
                + "; isRealCallingUidForeground: " + isRealCallingUidForeground
                + "; isRealCallingUidPersistentSystemProcess: "
                + isRealCallingUidPersistentSystemProcess
                + "; originatingPendingIntent: " + originatingPendingIntent
                + "; isBgStartWhitelisted: " + allowBackgroundActivityStart
                + "; intent: " + intent
                + "; callerApp: " + callerApp
                + "]");
        // log aborted activity start to TRON
        if (mService.isActivityStartsLoggingEnabled()) {
            mSupervisor.getActivityMetricsLogger().logAbortedBgActivityStart(intent, callerApp,
                    callingUid, callingPackage, callingUidProcState, callingUidHasAnyVisibleWindow,
                    realCallingUid, realCallingUidProcState, realCallingUidHasAnyVisibleWindow,
                    (originatingPendingIntent != null));
        }
        return true;
    }

```

在上述shouldAbortBackgroundActivityStart(）的相关源码中发现，这里判断是否不让从后台启动，  
 如果有START\_ACTIVITIES\_FROM\_BACKGROUND启动权限是可以启动的，所以根据这个需要添加  
 根据包名判断，返回fasle 就可以了  
 在这里直接 根据包名来判断 是否允许后台启动Activity  
 然后编译发现可以在后台启动Activity了





