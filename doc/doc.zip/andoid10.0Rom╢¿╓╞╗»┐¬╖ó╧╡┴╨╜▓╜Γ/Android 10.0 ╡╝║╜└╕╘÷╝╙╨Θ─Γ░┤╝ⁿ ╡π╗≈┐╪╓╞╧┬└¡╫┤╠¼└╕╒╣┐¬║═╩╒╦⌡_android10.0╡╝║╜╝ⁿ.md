



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.导航栏增加虚拟按键 点击控制下拉状态栏展开和收缩的核心代码](#2.%E5%AF%BC%E8%88%AA%E6%A0%8F%E5%A2%9E%E5%8A%A0%E8%99%9A%E6%8B%9F%E6%8C%89%E9%94%AE%20%E7%82%B9%E5%87%BB%E6%8E%A7%E5%88%B6%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8F%E5%B1%95%E5%BC%80%E5%92%8C%E6%94%B6%E7%BC%A9%E7%9A%84%E6%A0%B8%E5%BF%83%E4%BB%A3%E7%A0%81)


[3.导航栏增加虚拟按键 点击控制下拉状态栏展开和收缩的核心功能分析](#3.%E5%AF%BC%E8%88%AA%E6%A0%8F%E5%A2%9E%E5%8A%A0%E8%99%9A%E6%8B%9F%E6%8C%89%E9%94%AE%20%E7%82%B9%E5%87%BB%E6%8E%A7%E5%88%B6%E4%B8%8B%E6%8B%89%E7%8A%B6%E6%80%81%E6%A0%8F%E5%B1%95%E5%BC%80%E5%92%8C%E6%94%B6%E7%BC%A9%E7%9A%84%E6%A0%B8%E5%BF%83%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)




---


## 1.概述


在10.0定制化开发中，在导航栏增加虚拟按键也是常有的功能，功能开发需求要求增加虚拟按键来实现对下拉状态栏展开和收缩的控制  
 关于导航栏增加虚拟按键在前面的博客已经讲过  
 地址:增加虚拟按键一:https://blog.csdn.net/baidu\_41666295/article/details/117294851  
 增加虚拟按键二:https://blog.csdn.net/baidu\_41666295/article/details/117295327  
 这两篇已经讲述怎么在导航栏增加虚拟按键了 就不在讲述 了  
 下面直接讲述怎么控制状态栏展开收缩


## 2.导航栏增加虚拟按键 点击控制下拉状态栏展开和收缩的核心代码



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
```

## 3.导航栏增加虚拟按键 点击控制下拉状态栏展开和收缩的核心功能分析


主要是看StatusBar.java 的相关代码 控制展开收缩状态栏都是在这里控制



```

路径:frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
public class StatusBar extends SystemUI implements DemoMode,
ActivityStarter, OnUnlockMethodChangedListener,
OnHeadsUpChangedListener, CommandQueue.Callbacks, ZenModeController.Callback,
ColorExtractor.OnColorsChangedListener, ConfigurationListener,
StatusBarStateController.StateListener, ShadeController,
ActivityLaunchAnimator.Callback, AmbientPulseManager.OnAmbientChangedListener,
AppOpsController.Callback {
	@Override
	public void start() {
		mGroupManager = Dependency.get(NotificationGroupManager.class);
		mGroupAlertTransferHelper = Dependency.get(NotificationGroupAlertTransferHelper.class);
		mVisualStabilityManager = Dependency.get(VisualStabilityManager.class);
		mNotificationLogger = Dependency.get(NotificationLogger.class);
		mRemoteInputManager = Dependency.get(NotificationRemoteInputManager.class);
		mNotificationListener =  Dependency.get(NotificationListener.class);
		mNotificationListener.registerAsSystemService();
		mNetworkController = Dependency.get(NetworkController.class);
		mUserSwitcherController = Dependency.get(UserSwitcherController.class);
		mScreenLifecycle = Dependency.get(ScreenLifecycle.class);
		mScreenLifecycle.addObserver(mScreenObserver);
		mWakefulnessLifecycle = Dependency.get(WakefulnessLifecycle.class);
		mWakefulnessLifecycle.addObserver(mWakefulnessObserver);
		mBatteryController = Dependency.get(BatteryController.class);
		mAssistManager = Dependency.get(AssistManager.class);
		mUiModeManager = mContext.getSystemService(UiModeManager.class);
		mLockscreenUserManager = Dependency.get(NotificationLockscreenUserManager.class);
		mGutsManager = Dependency.get(NotificationGutsManager.class);
		mMediaManager = Dependency.get(NotificationMediaManager.class);
		mEntryManager = Dependency.get(NotificationEntryManager.class);
		mNotificationInterruptionStateProvider =
		Dependency.get(NotificationInterruptionStateProvider.class);
		mViewHierarchyManager = Dependency.get(NotificationViewHierarchyManager.class);
		mForegroundServiceController = Dependency.get(ForegroundServiceController.class);
		mAppOpsController = Dependency.get(AppOpsController.class);
		mZenController = Dependency.get(ZenModeController.class);
		mKeyguardViewMediator = getComponent(KeyguardViewMediator.class);
		mColorExtractor = Dependency.get(SysuiColorExtractor.class);
		mDeviceProvisionedController = Dependency.get(DeviceProvisionedController.class);
		mNavigationBarController = Dependency.get(NavigationBarController.class);
		mBubbleController = Dependency.get(BubbleController.class);
		mBubbleController.setExpandListener(mBubbleExpandListener);
		mActivityIntentHelper = new ActivityIntentHelper(mContext);
		KeyguardSliceProvider sliceProvider = KeyguardSliceProvider.getAttachedInstance();
		if (sliceProvider != null) {
			sliceProvider.initDependencies(mMediaManager, mStatusBarStateController);
		} else {
			Log.w(TAG, "Cannot init KeyguardSliceProvider dependencies");
		}
		mColorExtractor.addOnColorsChangedListener(this);
		mStatusBarStateController.addCallback(this,
		SysuiStatusBarStateController.RANK_STATUS_BAR);
		mWindowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
		mDreamManager = IDreamManager.Stub.asInterface(
		ServiceManager.checkService(DreamService.DREAM_SERVICE));
		mDisplay = mWindowManager.getDefaultDisplay();
		mDisplayId = mDisplay.getDisplayId();
		updateDisplaySize();
		mVibrateOnOpening = mContext.getResources().getBoolean(
		R.bool.config_vibrateOnIconAnimation);
		mVibratorHelper = Dependency.get(VibratorHelper.class);
		DateTimeView.setReceiverHandler(Dependency.get(Dependency.TIME_TICK_HANDLER));
		putComponent(StatusBar.class, this);
		// start old BaseStatusBar.start().
		mWindowManagerService = WindowManagerGlobal.getWindowManagerService();
		mDevicePolicyManager = (DevicePolicyManager) mContext.getSystemService(
		Context.DEVICE_POLICY_SERVICE);
		mAccessibilityManager = (AccessibilityManager)
		mContext.getSystemService(Context.ACCESSIBILITY_SERVICE);
		mPowerManager = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
		mKeyguardUpdateMonitor = KeyguardUpdateMonitor.getInstance(mContext);
		mBarService = IStatusBarService.Stub.asInterface(
		ServiceManager.getService(Context.STATUS_BAR_SERVICE));
		mRecents = getComponent(Recents.class);
		mKeyguardManager = (KeyguardManager) mContext.getSystemService(Context.KEYGUARD_SERVICE);
		// Connect in to the status bar manager service
		mCommandQueue = getComponent(CommandQueue.class);
		mCommandQueue.addCallback(this);
		RegisterStatusBarResult result = null;
		try {
			result = mBarService.registerStatusBar(mCommandQueue);
		}
		catch (RemoteException ex) {
			ex.rethrowFromSystemServer();
		}
		createAndAddWindows(result);
		// Make sure we always have the most current wallpaper info.
		IntentFilter wallpaperChangedFilter = new IntentFilter(Intent.ACTION_WALLPAPER_CHANGED);
		mContext.registerReceiverAsUser(mWallpaperChangedReceiver, UserHandle.ALL,
		wallpaperChangedFilter, null 
		/* broadcastPermission */
		, null 
		/* scheduler */
		);
		mWallpaperChangedReceiver.onReceive(mContext, null);
		// Set up the initial notification state. This needs to happen before CommandQueue.disable()
		setUpPresenter();
		setSystemUiVisibility(mDisplayId, result.mSystemUiVisibility,
		result.mFullscreenStackSysUiVisibility, result.mDockedStackSysUiVisibility,
		xffffffff, result.mFullscreenStackBounds, result.mDockedStackBounds,
		result.mNavbarColorManagedByIme);
		// StatusBarManagerService has a back up of IME token and it's restored here.
		setImeWindowStatus(mDisplayId, result.mImeToken, result.mImeWindowVis,
		result.mImeBackDisposition, result.mShowImeSwitcher);
		// Set up the initial icon state
		int numIcons = result.mIcons.size();
		for (int i = 0; i < numIcons; i++) {
			mCommandQueue.setIcon(result.mIcons.keyAt(i), result.mIcons.valueAt(i));
		}
		if (DEBUG) {
			Log.d(TAG, String.format(
			"init: icons=%d disabled=0x%08x lights=0x%08x imeButton=0x%08x",
			numIcons,
			result.mDisabledFlags1,
			result.mSystemUiVisibility,
			result.mImeWindowVis));
		}
		IntentFilter internalFilter = new IntentFilter();
		internalFilter.addAction(BANNER_ACTION_CANCEL);
		internalFilter.addAction(BANNER_ACTION_SETUP);
		mContext.registerReceiver(mBannerActionBroadcastReceiver, internalFilter, PERMISSION_SELF,
		null);
		IWallpaperManager wallpaperManager = IWallpaperManager.Stub.asInterface(
		ServiceManager.getService(Context.WALLPAPER_SERVICE));
		try {
			wallpaperManager.setInAmbientMode(false 
			/* ambientMode */
			, 0L 
			/* duration */
			);
		}
		catch (RemoteException e) {
			// Just pass, nothing critical.
		}
		// end old BaseStatusBar.start().
		// Lastly, call to the icon policy to install/update all the icons.
		mIconPolicy = new PhoneStatusBarPolicy(mContext, mIconController);
		mSignalPolicy = new StatusBarSignalPolicy(mContext, mIconController);
		mUnlockMethodCache = UnlockMethodCache.getInstance(mContext);
		mUnlockMethodCache.addListener(this);
		startKeyguard();
		mKeyguardUpdateMonitor.registerCallback(mUpdateCallback);
		putComponent(DozeHost.class, mDozeServiceHost);
		mScreenPinningRequest = new ScreenPinningRequest(mContext);
		mFalsingManager = FalsingManagerFactory.getInstance(mContext);
		Dependency.get(ActivityStarterDelegate.class).setActivityStarterImpl(this);
		Dependency.get(ConfigurationController.class).addCallback(this);
		// set the initial view visibility
		Dependency.get(InitController.class).addPostInitTask(this::updateAreThereNotifications);
		int disabledFlags1 = result.mDisabledFlags1;
		int disabledFlags2 = result.mDisabledFlags2;
		Dependency.get(InitController.class).addPostInitTask(
		() -> setUpDisableFlags(disabledFlags1, disabledFlags2));
	}
	// ================================================================================
	// Constructing the view
	// ================================================================================
	protected void makeStatusBarView(@Nullable RegisterStatusBarResult result) {
		final Context context = mContext;
		updateDisplaySize();
		// populates mDisplayMetrics
		updateResources();
		updateTheme();
		inflateStatusBarWindow(context);
		mStatusBarWindow.setService(this);
		mStatusBarWindow.setOnTouchListener(getStatusBarWindowTouchListener());
		// TODO: Deal with the ugliness that comes from having some of the statusbar broken out
		// into fragments, but the rest here, it leaves some awkward lifecycle and whatnot.
		mNotificationPanel = mStatusBarWindow.findViewById(R.id.notification_panel);
		mStackScroller = mStatusBarWindow.findViewById(R.id.notification_stack_scroller);
		mZenController.addCallback(this);
		NotificationListContainer notifListContainer = (NotificationListContainer) mStackScroller;
		mNotificationLogger.setUpWithContainer(notifListContainer);
		mNotificationIconAreaController = SystemUIFactory.getInstance()
		createNotificationIconAreaController(context, this, mStatusBarStateController);
		inflateShelf();
		mNotificationIconAreaController.setupShelf(mNotificationShelf);
		Dependency.get(DarkIconDispatcher.class).addDarkReceiver(mNotificationIconAreaController);
		// Allow plugins to reference DarkIconDispatcher and StatusBarStateController
		Dependency.get(PluginDependencyProvider.class)
		allowPluginDependency(DarkIconDispatcher.class);
		Dependency.get(PluginDependencyProvider.class)
		allowPluginDependency(StatusBarStateController.class);
		FragmentHostManager.get(mStatusBarWindow)
		addTagListener(CollapsedStatusBarFragment.TAG, (tag, fragment) -> {
			CollapsedStatusBarFragment statusBarFragment =
			(CollapsedStatusBarFragment) fragment;
			statusBarFragment.initNotificationIconArea(mNotificationIconAreaController);
			PhoneStatusBarView oldStatusBarView = mStatusBarView;
			mStatusBarView = (PhoneStatusBarView) fragment.getView();
			mStatusBarView.setBar(this);
			mStatusBarView.setPanel(mNotificationPanel);
			mStatusBarView.setScrimController(mScrimController);
			// CollapsedStatusBarFragment re-inflated PhoneStatusBarView and both of
			// mStatusBarView.mExpanded and mStatusBarView.mBouncerShowing are false.
			// PhoneStatusBarView's new instance will set to be gone in
			// PanelBar.updateVisibility after calling mStatusBarView.setBouncerShowing
			// that will trigger PanelBar.updateVisibility. If there is a heads up showing,
			// it needs to notify PhoneStatusBarView's new instance to update the correct
			// status by calling mNotificationPanel.notifyBarPanelExpansionChanged().
			if (mHeadsUpManager.hasPinnedHeadsUp()) {
				mNotificationPanel.notifyBarPanelExpansionChanged();
			}
			mStatusBarView.setBouncerShowing(mBouncerShowing);
			if (oldStatusBarView != null) {
				float fraction = oldStatusBarView.getExpansionFraction();
				Boolean expanded = oldStatusBarView.isExpanded();
				mStatusBarView.panelExpansionChanged(fraction, expanded);
			}
			HeadsUpAppearanceController oldController = mHeadsUpAppearanceController;
			if (mHeadsUpAppearanceController != null) {
				// This view is being recreated, let's destroy the old one
				mHeadsUpAppearanceController.destroy();
			}
			mHeadsUpAppearanceController = new HeadsUpAppearanceController(
			mNotificationIconAreaController, mHeadsUpManager, mStatusBarWindow);
			mHeadsUpAppearanceController.readFrom(oldController);
			mStatusBarWindow.setStatusBarView(mStatusBarView);
			updateAreThereNotifications();
			checkBarModes();
		}
		).getFragmentManager()
		beginTransaction()
		replace(R.id.status_bar_container, new CollapsedStatusBarFragment(),
		CollapsedStatusBarFragment.TAG)
		commit();
		mIconController = Dependency.get(StatusBarIconController.class);
		mHeadsUpManager = new HeadsUpManagerPhone(context, mStatusBarWindow, mGroupManager, this,
		mVisualStabilityManager);
		Dependency.get(ConfigurationController.class).addCallback(mHeadsUpManager);
		mHeadsUpManager.addListener(this);
		mHeadsUpManager.addListener(mNotificationPanel);
		mHeadsUpManager.addListener(mGroupManager);
		mHeadsUpManager.addListener(mGroupAlertTransferHelper);
		mHeadsUpManager.addListener(mVisualStabilityManager);
		mAmbientPulseManager.addListener(this);
		mAmbientPulseManager.addListener(mGroupManager);
		mAmbientPulseManager.addListener(mGroupAlertTransferHelper);
		mNotificationPanel.setHeadsUpManager(mHeadsUpManager);
		mGroupManager.setHeadsUpManager(mHeadsUpManager);
		mGroupAlertTransferHelper.setHeadsUpManager(mHeadsUpManager);
		mNotificationLogger.setHeadsUpManager(mHeadsUpManager);
		putComponent(HeadsUpManager.class, mHeadsUpManager);
		createNavigationBar(result);
		if (ENABLE_LOCKSCREEN_WALLPAPER) {
			mLockscreenWallpaper = new LockscreenWallpaper(mContext, this, mHandler);
		}
		mKeyguardIndicationController =
		SystemUIFactory.getInstance().createKeyguardIndicationController(mContext,
		mStatusBarWindow.findViewById(R.id.keyguard_indication_area),
		mStatusBarWindow.findViewById(R.id.lock_icon));
		mNotificationPanel.setKeyguardIndicationController(mKeyguardIndicationController);
		mAmbientIndicationContainer = mStatusBarWindow.findViewById(
		R.id.ambient_indication_container);
		// TODO: Find better place for this callback.
		mBatteryController.addCallback(new BatteryStateChangeCallback() {
			@Override
			public void onPowerSaveChanged(Boolean isPowerSave) {
				mHandler.post(mCheckBarModes);
				if (mDozeServiceHost != null) {
					mDozeServiceHost.firePowerSaveChanged(isPowerSave);
				}
			}
			@Override
			public void onBatteryLevelChanged(int level, Boolean pluggedIn, Boolean charging) {
				// noop
			}
		}
		);
		mAutoHideController = Dependency.get(AutoHideController.class);
		mAutoHideController.setStatusBar(this);
		mLightBarController = Dependency.get(LightBarController.class);
		ScrimView scrimBehind = mStatusBarWindow.findViewById(R.id.scrim_behind);
		ScrimView scrimInFront = mStatusBarWindow.findViewById(R.id.scrim_in_front);
		mScrimController = SystemUIFactory.getInstance().createScrimController(
		scrimBehind, scrimInFront, mLockscreenWallpaper,
		(state, alpha, color) -> mLightBarController.setScrimState(state, alpha, color),
		scrimsVisible -> {
			if (mStatusBarWindowController != null) {
				mStatusBarWindowController.setScrimsVisibility(scrimsVisible);
			}
			if (mStatusBarWindow != null) {
				mStatusBarWindow.onScrimVisibilityChanged(scrimsVisible);
			}
		}
		, DozeParameters.getInstance(mContext),
		mContext.getSystemService(AlarmManager.class));
		mNotificationPanel.initDependencies(this, mGroupManager, mNotificationShelf,
		mHeadsUpManager, mNotificationIconAreaController, mScrimController);
		mDozeScrimController = new DozeScrimController(DozeParameters.getInstance(context));
		BackDropView backdrop = mStatusBarWindow.findViewById(R.id.backdrop);
		mMediaManager.setup(backdrop, backdrop.findViewById(R.id.backdrop_front),
		backdrop.findViewById(R.id.backdrop_back), mScrimController, mLockscreenWallpaper);
		// Other icons
		mVolumeComponent = getComponent(VolumeComponent.class);
		mNotificationPanel.setUserSetupComplete(mUserSetup);
		if (UserManager.get(mContext).isUserSwitcherEnabled()) {
			createUserSwitcher();
		}
		mNotificationPanel.setLaunchAffordanceListener(
		mStatusBarWindow::onShowingLaunchAffordanceChanged);
		// Set up the quick settings tile panel
		View container = mStatusBarWindow.findViewById(R.id.qs_frame);
		if (container != null) {
			FragmentHostManager fragmentHostManager = FragmentHostManager.get(container);
			ExtensionFragmentListener.attachExtensonToFragment(container, QS.TAG, R.id.qs_frame,
			Dependency.get(ExtensionController.class)
			newExtension(QS.class)
			withPlugin(QS.class)
			withDefault(this::createDefaultQSFragment)
			build());
			mBrightnessMirrorController = new BrightnessMirrorController(mStatusBarWindow,
			(visible) -> {
				mBrightnessMirrorVisible = visible;
				updateScrimController();
			}
			);
			fragmentHostManager.addTagListener(QS.TAG, (tag, f) -> {
				QS qs = (QS) f;
				if (qs instanceof QSFragment) {
					mQSPanel = ((QSFragment) qs).getQsPanel();
					mQSPanel.setBrightnessMirror(mBrightnessMirrorController);
				}
			}
			);
		}
		mReportRejectedTouch = mStatusBarWindow.findViewById(R.id.report_rejected_touch);
		if (mReportRejectedTouch != null) {
			updateReportRejectedTouchVisibility();
			mReportRejectedTouch.setOnClickListener(v -> {
				Uri session = mFalsingManager.reportRejectedTouch();
				if (session == null) {
					return;
				}
				StringWriter message = new StringWriter();
				message.write("Build info: ");
				message.write(SystemProperties.get("ro.build.description"));
				message.write("nSerial number: ");
				message.write(SystemProperties.get("ro.serialno"));
				message.write("n");
PrintWriter falsingPw = new PrintWriter(message);
FalsingLog.dump(falsingPw);
falsingPw.flush();
startActivityDismissingKeyguard(Intent.createChooser(new Intent(Intent.ACTION_SEND)
setType("*
				/*")
putExtra(Intent.EXTRA_SUBJECT, "Rejected touch report")
putExtra(Intent.EXTRA_STREAM, session)
putExtra(Intent.EXTRA_TEXT, message.toString()),
"Share rejected touch report")
addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
true /* onlyProvisioned */
				, true 
				/* dismissShade */
				);
			}
			);
		}
		PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
		if (!pm.isScreenOn()) {
			mBroadcastReceiver.onReceive(mContext, new Intent(Intent.ACTION_SCREEN_OFF));
		}
		mGestureWakeLock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK,
		"GestureWakeLock");
		mVibrator = mContext.getSystemService(Vibrator.class);
		int[] pattern = mContext.getResources().getIntArray(
		R.array.config_cameraLaunchGestureVibePattern);
		mCameraLaunchGestureVibePattern = new long[pattern.length];
		for (int i = 0; i < pattern.length; i++) {
			mCameraLaunchGestureVibePattern[i] = pattern[i];
		}
		// receive broadcasts
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
		filter.addAction(Intent.ACTION_SCREEN_OFF);
		filter.addAction(DevicePolicyManager.ACTION_SHOW_DEVICE_MONITORING_DIALOG);
		context.registerReceiverAsUser(mBroadcastReceiver, UserHandle.ALL, filter, null, null);
		IntentFilter demoFilter = new IntentFilter();
		if (DEBUG_MEDIA_FAKE_ARTWORK) {
			demoFilter.addAction(ACTION_FAKE_ARTWORK);
		}
		demoFilter.addAction(ACTION_DEMO);
		context.registerReceiverAsUser(mDemoReceiver, UserHandle.ALL, demoFilter,
		android.Manifest.permission.DUMP, null);
		// listen for USER_SETUP_COMPLETE setting (per-user)
		mDeviceProvisionedController.addCallback(mUserSetupObserver);
		mUserSetupObserver.onUserSetupChanged();
		// disable profiling bars, since they overlap and clutter the output on app windows
		ThreadedRenderer.overrideProperty("disableProfileBars", "true");
		// Private API call to make the shadows look better for Recents
		ThreadedRenderer.overrideProperty("ambientRatio", String.valueOf(1.5f));
	}


void makeExpandedInvisible() {
        if (SPEW) Log.d(TAG, "makeExpandedInvisible: mExpandedVisible=" + mExpandedVisible
                + " mExpandedVisible=" + mExpandedVisible);

        if (!mExpandedVisible || mStatusBarWindow == null) {
            return;
        }

        // Ensure the panel is fully collapsed (just in case; bug 6765842, 7260868)
        mStatusBarView.collapsePanel(/*animate=*/ false, false /* delayed*/,
                1.0f /* speedUpFactor */);

        mNotificationPanel.closeQs();

        mExpandedVisible = false;
        visibilityChanged(false);

        // Shrink the window to the size of the status bar only
        mStatusBarWindowController.setPanelVisible(false);
        mStatusBarWindowController.setForceStatusBarVisible(false);

        // Close any guts that might be visible
        mGutsManager.closeAndSaveGuts(true /* removeLeavebehind */, true /* force */,
                true /* removeControls */, -1 /* x */, -1 /* y */, true /* resetMenu */);

        runPostCollapseRunnables();
        setInteracting(StatusBarManager.WINDOW_STATUS_BAR, false);
        if (!mNotificationActivityStarter.isCollapsingToShowActivityOverLockscreen()) {
            showBouncerIfKeyguard();
        } else if (DEBUG) {
            Log.d(TAG, "Not showing bouncer due to activity showing over lockscreen");
        }
        mCommandQueue.recomputeDisableFlags(
                mDisplayId, mNotificationPanel.hideStatusBarIconsWhenExpanded() /* animate */);

        // Trimming will happen later if Keyguard is showing - doing it here might cause a jank in
        // the bouncer appear animation.
        if (!mStatusBarKeyguardViewManager.isShowing()) {
            WindowManagerGlobal.getInstance().trimMemory(ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN);
        }
    }

    void makeExpandedVisible(boolean force) {
        if (SPEW) Log.d(TAG, "Make expanded visible: expanded visible=" + mExpandedVisible);
        if (!force && (mExpandedVisible || !mCommandQueue.panelsEnabled())) {
            return;
        }

        mExpandedVisible = true;

        // Expand the window to encompass the full screen in anticipation of the drag.
        // This is only possible to do atomically because the status bar is at the top of the screen!
        mStatusBarWindowController.setPanelVisible(true);

        visibilityChanged(true);
        mCommandQueue.recomputeDisableFlags(mDisplayId, !force /* animate */);
        setInteracting(StatusBarManager.WINDOW_STATUS_BAR, true);
    }






```

在启动SystemUI构建状态栏时，最先启动start()来构建各种需要的参数，然后通过makeStatusBarView()来构建导航栏状态栏  
 makeExpandedInvisible()就是收缩下拉状态栏相关操作，makeExpandedVisible展开下拉状态栏的操作


void makeExpandedInvisible()和makeExpandedVisible(boolean force)


这两个方法就是状态栏展开和收缩执行的相关代码  
 所以增加自定义方法 来实现状态栏展开和收缩


具体修改如下：



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBar.java
@@ -1153,10 +1153,16 @@ public class StatusBar extends SystemUI implements DemoMode,
     }
 
+       public void openMenu(){
+                //mExpandedVisible 标识当前是展开或收缩
+                if(!mExpandedVisible){
+                        mStatusBarManager.disable(StatusBarManager.DISABLE_NONE);
+                        mNotificationPanel.expand(true /* animate */);
+                        mMetricsLogger.count(NotificationPanelView.COUNTER_PANEL_OPEN, 1);
+                        mStatusBarManager.disable(StatusBarManager.DISABLE_EXPAND);
+                }else{
+                        mNotificationPanel.collapse(false /* delayed */, 1.0f /* speedUpFactor */);
+                        mNotificationPanel.flingSettings(0,2);
+                }
     }
     protected QS createDefaultQSFragment() {
         return FragmentHostManager.get(mStatusBarWindow).create(QSFragment.class);
```

然后就可以在NavigationBarFragment中通过按键来调用openMenu（）来实现下拉状态栏的展开和收缩



