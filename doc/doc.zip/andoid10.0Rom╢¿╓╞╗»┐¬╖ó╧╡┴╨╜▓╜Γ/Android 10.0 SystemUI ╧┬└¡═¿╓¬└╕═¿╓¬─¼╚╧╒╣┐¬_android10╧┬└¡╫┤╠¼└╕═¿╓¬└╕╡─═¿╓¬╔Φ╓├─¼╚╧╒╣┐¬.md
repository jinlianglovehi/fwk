






### 1.概述


10.0 在对SystemUI下拉通知栏做定制的时候，最后一条通知默认是收缩的 点击按钮 就会展开 原生系统如此，为了更美观 所以要求最后一条通知也默认展开，显得更美观  
 原来样式  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/889c4a7829754c629779222823fcaa3a.png#pic_center)


修改后样式  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/16807c94c2e9421d99be7afb1158bb6d.png#pic_center)


### 2.SystemUI 下拉通知栏通知默认展开的相关代码



```
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/NotificationViewHierarchyManager.java
frameworks\base\packages\SystemUI\res\values\config.xml

```

### 3.SystemUI 下拉通知栏通知默认展开的功能分析


首选这些下拉通知栏的每条通知都是由NotificationViewHierarchyManager来负责管理的，  
 先看下NotificationViewHierarchyManager 通知管理类



```
public class NotificationViewHierarchyManager implements DynamicPrivacyController.Listener {
    private static final String TAG = "NotificationViewHierarchyManager";

    private final Handler mHandler;

    //TODO: change this top <Entry, List<Entry>>?
    private final HashMap<ExpandableNotificationRow, List<ExpandableNotificationRow>>
            mTmpChildOrderMap = new HashMap<>();
@Inject
public NotificationViewHierarchyManager(Context context,
@Named(MAIN_HANDLER_NAME) Handler mainHandler,
NotificationLockscreenUserManager notificationLockscreenUserManager,
NotificationGroupManager groupManager,
VisualStabilityManager visualStabilityManager,
StatusBarStateController statusBarStateController,
NotificationEntryManager notificationEntryManager,
Lazy<ShadeController> shadeController,
BubbleData bubbleData,
DynamicPrivacyController privacyController) {
mHandler = mainHandler;
mLockscreenUserManager = notificationLockscreenUserManager;
mGroupManager = groupManager;
mVisualStabilityManager = visualStabilityManager;
mStatusBarStateController = (SysuiStatusBarStateController) statusBarStateController;
mEntryManager = notificationEntryManager;
mShadeController = shadeController;
Resources res = context.getResources();
mAlwaysExpandNonGroupedNotification =
res.getBoolean(R.bool.config_alwaysExpandNonGroupedNotifications);
mBubbleData = bubbleData;
mDynamicPrivacyController = privacyController;
privacyController.addListener(this);
}

public void updateRowStates() {
Assert.isMainThread();
try {
beginUpdate();
} catch (IllegalStateException e) {
// IllegalStateException do not update statues
return;
}
updateRowStatesInternal();
endUpdate();
}


private void updateRowStatesInternal() {
    Trace.beginSection("NotificationViewHierarchyManager#updateRowStates");
    final int N = mListContainer.getContainerChildCount();

    int visibleNotifications = 0;
    boolean onKeyguard = mStatusBarStateController.getState() == StatusBarState.KEYGUARD;
    int maxNotifications = -1;
    if (onKeyguard) {
        maxNotifications = mPresenter.getMaxNotificationsWhileLocked(true /* recompute */);
    }
    mListContainer.setMaxDisplayedNotifications(maxNotifications);
    Stack<ExpandableNotificationRow> stack = new Stack<>();
    for (int i = N - 1; i >= 0; i--) {
        View child = mListContainer.getContainerChildAt(i);
        if (!(child instanceof ExpandableNotificationRow)) {
            continue;
        }
        stack.push((ExpandableNotificationRow) child);
 }
 while(!stack.isEmpty()) {
        ExpandableNotificationRow row = stack.pop();
        NotificationEntry entry = row.getEntry();
        boolean isChildNotification =
                mGroupManager.isChildInGroupWithSummary(entry.notification);

        row.setOnKeyguard(onKeyguard);

        if (!onKeyguard) {
            // If mAlwaysExpandNonGroupedNotification is false, then only expand the
            // very first notification and if it's not a child of grouped notifications.
 row.setSystemExpanded(mAlwaysExpandNonGroupedNotification
 || (visibleNotifications == 0 && !isChildNotification
 && !row.isLowPriority()));
 }

 entry.getRow().setOnAmbient(mShadeController.get().isDozing());
 int userId = entry.notification.getUserId();
 boolean suppressedSummary = mGroupManager.isSummaryOfSuppressedGroup(
 entry.notification) && !entry.isRowRemoved();
 boolean showOnKeyguard = mLockscreenUserManager.shouldShowOnKeyguard(entry);
 if (!showOnKeyguard) {
 // min priority notifications should show if their summary is showing
 if (mGroupManager.isChildInGroupWithSummary(entry.notification)) {
 NotificationEntry summary = mGroupManager.getLogicalGroupSummary(
 entry.notification);
 if (summary != null && mLockscreenUserManager.shouldShowOnKeyguard(summary)) {
 showOnKeyguard = true;
 }
 }
 }
 if (suppressedSummary
 || mLockscreenUserManager.shouldHideNotifications(userId)
 || (onKeyguard && !showOnKeyguard)) {
 entry.getRow().setVisibility(View.GONE);
 } else {
 boolean wasGone = entry.getRow().getVisibility() == View.GONE;
 if (wasGone) {
 entry.getRow().setVisibility(View.VISIBLE);
 }
 if (!isChildNotification && !entry.getRow().isRemoved()) {
 if (wasGone) {
 // notify the scroller of a child addition
 mListContainer.generateAddAnimation(entry.getRow(),
 !showOnKeyguard /\* fromMoreCard \*/);
 }
 visibleNotifications++;
 }
 }
 if (row.isSummaryWithChildren()) {
 List<ExpandableNotificationRow> notificationChildren =
 row.getNotificationChildren();
 int size = notificationChildren.size();
 for (int i = size - 1; i >= 0; i--) {
 stack.push(notificationChildren.get(i));
 }
 }

 row.showAppOpsIcons(entry.mActiveAppOps);
 row.setLastAudiblyAlertedMs(entry.lastAudiblyAlertedMs);
 }

 Trace.beginSection("NotificationPresenter#onUpdateRowStates");
 mPresenter.onUpdateRowStates();
 Trace.endSection();
 Trace.endSection();
}

if (!onKeyguard) {
 // If mAlwaysExpandNonGroupedNotification is false, then only expand the
 // very first notification and if it's not a child of grouped notifications.
            row.setSystemExpanded(mAlwaysExpandNonGroupedNotification
                    || (visibleNotifications == 0 && !isChildNotification
                    && !row.isLowPriority()));
        }
        entry.getRow().setOnAmbient(mShadeController.get().isDozing());
            int userId = entry.notification.getUserId();
            boolean suppressedSummary = mGroupManager.isSummaryOfSuppressedGroup(
                    entry.notification) && !entry.isRowRemoved();
            boolean showOnKeyguard = mLockscreenUserManager.shouldShowOnKeyguard(entry);
            if (!showOnKeyguard) {
                // min priority notifications should show if their summary is showing
                if (mGroupManager.isChildInGroupWithSummary(entry.notification)) {
                    NotificationEntry summary = mGroupManager.getLogicalGroupSummary(
                            entry.notification);
                    if (summary != null && mLockscreenUserManager.shouldShowOnKeyguard(summary)) {
                        showOnKeyguard = true;
                    }
                }
            }
            if (suppressedSummary
                    || mLockscreenUserManager.shouldHideNotifications(userId)
                    || (onKeyguard && !showOnKeyguard)) {
                entry.getRow().setVisibility(View.GONE);
            } else {
                boolean wasGone = entry.getRow().getVisibility() == View.GONE;
                if (wasGone) {
                    entry.getRow().setVisibility(View.VISIBLE);
                }
                if (!isChildNotification && !entry.getRow().isRemoved()) {
                    if (wasGone) {
                        // notify the scroller of a child addition
                        mListContainer.generateAddAnimation(entry.getRow(),
                                !showOnKeyguard /* fromMoreCard */);
                    }
                    visibleNotifications++;
                }
            }
            if (row.isSummaryWithChildren()) {
                List<ExpandableNotificationRow> notificationChildren =
                        row.getNotificationChildren();
                int size = notificationChildren.size();
                for (int i = size - 1; i >= 0; i--) {
                    stack.push(notificationChildren.get(i));
                }
            }

            row.showAppOpsIcons(entry.mActiveAppOps);
            row.setLastAudiblyAlertedMs(entry.lastAudiblyAlertedMs);
        }

        Trace.beginSection("NotificationPresenter#onUpdateRowStates");
        mPresenter.onUpdateRowStates();
        Trace.endSection();
        Trace.endSection();
    }

```

updateRowStates(）加载所有的通知栏通知  
 在全局变量mAlwaysExpandNonGroupedNotification 记录是否展开通知栏，然后在updateRowStatesInternal()中从mListContainer.getContainerChildCount()判断有多少通知，然后for遍历每条通知，而row.setSystemExpanded判断是否展开，判断每条消息是否展开  
 根据mAlwaysExpandNonGroupedNotification 判断是否展开



```
mAlwaysExpandNonGroupedNotification =
        res.getBoolean(R.bool.config_alwaysExpandNonGroupedNotifications);

```

所以mAlwaysExpandNonGroupedNotification 的值由config\_alwaysExpandNonGroupedNotifications的值为true 就可以了  
 具体修改  
 frameworks\base\packages\SystemUI\res\values\config.xml



```
-<bool name="config\_alwaysExpandNonGroupedNotifications">false</bool>
+<bool name="config\_alwaysExpandNonGroupedNotifications">true</bool>

```

编译后发现通知栏通知默认展开了





