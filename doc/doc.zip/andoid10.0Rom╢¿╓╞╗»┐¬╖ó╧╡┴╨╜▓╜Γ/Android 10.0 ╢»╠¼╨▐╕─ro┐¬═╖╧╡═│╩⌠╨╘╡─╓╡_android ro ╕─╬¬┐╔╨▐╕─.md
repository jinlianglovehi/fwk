



**目录**


[1.概述](#1.%E6%A6%82%E8%BF%B0)


[2.动态修改ro开头系统属性的值的功能分析](#2.%E5%8A%A8%E6%80%81%E4%BF%AE%E6%94%B9ro%E5%BC%80%E5%A4%B4%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E7%9A%84%E5%80%BC%E7%9A%84%E5%8A%9F%E8%83%BD%E5%88%86%E6%9E%90)


[3.动态修改ro开头系统属性的值的功能实现和代码分析](#3.%E5%8A%A8%E6%80%81%E4%BF%AE%E6%94%B9ro%E5%BC%80%E5%A4%B4%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E7%9A%84%E5%80%BC%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0%E5%92%8C%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.1 property\_service.cpp的相关代码分析](#3.1%20property_service.cpp%E7%9A%84%E7%9B%B8%E5%85%B3%E4%BB%A3%E7%A0%81%E5%88%86%E6%9E%90)


[3.2 动态修改ro开头系统属性的值的功能实现](#3.2%20%E5%8A%A8%E6%80%81%E4%BF%AE%E6%94%B9ro%E5%BC%80%E5%A4%B4%E7%B3%BB%E7%BB%9F%E5%B1%9E%E6%80%A7%E7%9A%84%E5%80%BC%E7%9A%84%E5%8A%9F%E8%83%BD%E5%AE%9E%E7%8E%B0)




---



## 1.概述


 在10.0 定制化产品开发时，在10.0的产品中为了产品的安全性，ro开头属性值是不能修改的，由于项目需要变成可以修改它的值，  
 所以这就要从System的开机init.rc中来分析来实现这个功能


## 2.动态修改ro开头系统属性的值的功能分析


 android10.0它是在开机的时候从build.prop中读取的属性值 由property\_service.cpp来负责系统属性的修改,下面从property\_service.cpp来分析相关代码  
 来看如何实现功能


## 3.动态修改ro开头系统属性的值的功能实现和代码分析


#### 3.1 property\_service.cpp的相关代码分析



```
路径: /system/core/init/property_service.cpp
namespace android {
namespace init {

static bool persistent_properties_loaded = false;

static int property_set_fd = -1;

static PropertyInfoAreaFile property_info_area;

uint32_t InitPropertySet(const std::string& name, const std::string& value);

uint32_t (*property_set)(const std::string& name, const std::string& value) = InitPropertySet;

void CreateSerializedPropertyInfo();

struct PropertyAuditData {
const ucred* cr;
const char* name;
};

void property_init() {
mkdir("/dev/__properties__", S_IRWXU | S_IXGRP | S_IXOTH);
CreateSerializedPropertyInfo();
if (__system_property_area_init()) {
LOG(FATAL) << "Failed to initialize property area";
}
if (!property_info_area.LoadDefaultPath()) {
LOG(FATAL) << "Failed to load serialized property info file";
}
}

bool CanReadProperty(const std::string& source_context, const std::string& name) {
const char* target_context = nullptr;
property_info_area->GetPropertyInfo(name.c_str(), &target_context, nullptr);

PropertyAuditData audit_data;

audit_data.name = name.c_str();

ucred cr = {.pid = 0, .uid = 0, .gid = 0};
audit_data.cr = &cr;

return selinux_check_access(source_context.c_str(), target_context, "file", "read",
&audit_data) == 0;
}

static bool CheckMacPerms(const std::string& name, const char* target_context,
const char* source_context, const ucred& cr) {
if (!target_context || !source_context) {
return false;
}

PropertyAuditData audit_data;

audit_data.name = name.c_str();
audit_data.cr = &cr;

bool has_access = (selinux_check_access(source_context, target_context, "property_service",
"set", &audit_data) == 0);

return has_access;
}

static uint32_t PropertySet(const std::string& name, const std::string& value, std::string* error) {
size_t valuelen = value.size();

if (!IsLegalPropertyName(name)) {
*error = "Illegal property name";
return PROP_ERROR_INVALID_NAME;
}

if (valuelen >= PROP_VALUE_MAX && !StartsWith(name, "ro.")) {
*error = "Property value too long";
return PROP_ERROR_INVALID_VALUE;
}

if (mbstowcs(nullptr, value.data(), 0) == static_cast<std::size_t>(-1)) {
*error = "Value is not a UTF8 encoded string";
return PROP_ERROR_INVALID_VALUE;
}

prop_info* pi = (prop_info*) __system_property_find(name.c_str());
if (pi != nullptr) {
// ro.* properties are actually "write-once".
if (StartsWith(name, "ro.")) {
*error = "Read-only property was already set";
return PROP_ERROR_READ_ONLY_PROPERTY;
}

__system_property_update(pi, value.c_str(), valuelen);
} else {
int rc = __system_property_add(name.c_str(), name.size(), value.c_str(), valuelen);
if (rc < 0) {
*error = "__system_property_add failed";
return PROP_ERROR_SET_FAILED;
}
}

// Don't write properties to disk until after we have read all default
// properties to prevent them from being overwritten by default values.
if (persistent_properties_loaded && StartsWith(name, "persist.")) {
WritePersistentProperty(name, value);
}
property_changed(name, value);
return PROP_SUCCESS;
}

typedef int (*PropertyAsyncFunc)(const std::string&, const std::string&);

struct PropertyChildInfo {
pid_t pid;
PropertyAsyncFunc func;
std::string name;
std::string value;
};

static std::queue<PropertyChildInfo> property_children;

static void PropertyChildLaunch() {
auto& info = property_children.front();
pid_t pid = fork();
if (pid < 0) {
LOG(ERROR) << "Failed to fork for property_set_async";
while (!property_children.empty()) {
property_children.pop();
}
return;
}
if (pid != 0) {
info.pid = pid;
} else {
if (info.func(info.name, info.value) != 0) {
LOG(ERROR) << "property_set_async(\"" << info.name << "\", \"" << info.value
<< "\") failed";
}
_exit(0);
}
}

bool PropertyChildReap(pid_t pid) {
if (property_children.empty()) {
return false;
}
auto& info = property_children.front();
if (info.pid != pid) {
return false;
}
std::string error;
if (PropertySet(info.name, info.value, &error) != PROP_SUCCESS) {
LOG(ERROR) << "Failed to set async property " << info.name << " to " << info.value << ": "
<< error;
}
property_children.pop();
if (!property_children.empty()) {
PropertyChildLaunch();
}
return true;
}

static uint32_t PropertySetAsync(const std::string& name, const std::string& value,
PropertyAsyncFunc func, std::string* error) {
if (value.empty()) {
return PropertySet(name, value, error);
}

PropertyChildInfo info;
info.func = func;
info.name = name;
info.value = value;
property_children.push(info);
if (property_children.size() == 1) {
PropertyChildLaunch();
}
return PROP_SUCCESS;
}

static int RestoreconRecursiveAsync(const std::string& name, const std::string& value) {
return selinux_android_restorecon(value.c_str(), SELINUX_ANDROID_RESTORECON_RECURSE);
}

uint32_t InitPropertySet(const std::string& name, const std::string& value) {
if (StartsWith(name, "ctl.")) {
LOG(ERROR) << "InitPropertySet: Do not set ctl. properties from init; call the Service "
"functions directly";
return PROP_ERROR_INVALID_NAME;
}
if (name == "selinux.restorecon_recursive") {
LOG(ERROR) << "InitPropertySet: Do not set selinux.restorecon_recursive from init; use the "
"restorecon builtin directly";
return PROP_ERROR_INVALID_NAME;
}

uint32_t result = 0;
ucred cr = {.pid = 1, .uid = 0, .gid = 0};
std::string error;
result = HandlePropertySet(name, value, kInitContext.c_str(), cr, &error);
if (result != PROP_SUCCESS) {
LOG(ERROR) << "Init cannot set '" << name << "' to '" << value << "': " << error;
}

return result;
}

// This returns one of the enum of PROP_SUCCESS or PROP_ERROR*.
uint32_t HandlePropertySet(const std::string& name, const std::string& value,
const std::string& source_context, const ucred& cr,
SocketConnection* socket, std::string* error) {
if (auto ret = CheckPermissions(name, value, source_context, cr, error); ret != PROP_SUCCESS) {
return ret;
}
if (StartsWith(name, "ctl.")) {
    return SendControlMessage(name.c_str() + 4, value, cr.pid, socket, error);
}

// sys.powerctl is a special property that is used to make the device reboot.  We want to log
// any process that sets this property to be able to accurately blame the cause of a shutdown.
if (name == "sys.powerctl") {
    std::string cmdline_path = StringPrintf("proc/%d/cmdline", cr.pid);
    std::string process_cmdline;
    std::string process_log_string;
    if (ReadFileToString(cmdline_path, &process_cmdline)) {
        // Since cmdline is null deliminated, .c_str() conveniently gives us just the process
        // path.
        process_log_string = StringPrintf(" (%s)", process_cmdline.c_str());
    }
    LOG(INFO) << "Received sys.powerctl='" << value << "' from pid: " << cr.pid
              << process_log_string;
}

// If a process other than init is writing a non-empty value, it means that process is
// requesting that init performs a restorecon operation on the path specified by 'value'.
// We use a thread to do this restorecon operation to prevent holding up init, as it may take
// a long time to complete.
if (name == kRestoreconProperty && cr.pid != 1 && !value.empty()) {
    static AsyncRestorecon async_restorecon;
    async_restorecon.TriggerRestorecon(value);
    return PROP_SUCCESS;
}

return PropertySet(name, value, error);

}
uint32_t InitPropertySet(const std::string& name, const std::string& value) {
uint32_t result = 0;
ucred cr = {.pid = 1, .uid = 0, .gid = 0};
std::string error;
result = HandlePropertySet(name, value, kInitContext.c_str(), cr, nullptr, &error);
if (result != PROP_SUCCESS) {
LOG(ERROR) << "Init cannot set '" << name << "' to '" << value << "': " << error;
}
return result;

}
uint32_t (*property_set)(const std::string& name, const std::string& value) = InitPropertySet;
static uint32_t PropertySet(const std::string& name, const std::string& value, std::string* error) {
size_t valuelen = value.size();
if (!IsLegalPropertyName(name)) {
    *error = "Illegal property name";
    return PROP_ERROR_INVALID_NAME;
}

if (valuelen >= PROP_VALUE_MAX && !StartsWith(name, "ro.")) {
    *error = "Property value too long";
    return PROP_ERROR_INVALID_VALUE;
}

if (mbstowcs(nullptr, value.data(), 0) == static_cast<std::size_t>(-1)) {
    *error = "Value is not a UTF8 encoded string";
    return PROP_ERROR_INVALID_VALUE;
}

prop_info* pi = (prop_info*) __system_property_find(name.c_str());
if (pi != nullptr) {
    // ro.* properties are actually "write-once".
    if (StartsWith(name, "ro.")) {
        *error = "Read-only property was already set";
        return PROP_ERROR_READ_ONLY_PROPERTY;
    }

    __system_property_update(pi, value.c_str(), valuelen);
} else {
    int rc = __system_property_add(name.c_str(), name.size(), value.c_str(), valuelen);
    if (rc < 0) {
        *error = "__system_property_add failed";
        return PROP_ERROR_SET_FAILED;
    }
}

// Don't write properties to disk until after we have read all default
// properties to prevent them from being overwritten by default values.
if (persistent_properties_loaded && StartsWith(name, "persist.")) {
    WritePersistentProperty(name, value);
}
// If init hasn't started its main loop, then it won't be handling property changed messages
// anyway, so there's no need to try to send them.
if (init_socket != -1) {
    SendPropertyChanged(name, value);
}
return PROP_SUCCESS;

}
最终由PropertySet(const std::string& name, const std::string& value, std::string* error) 来负责存储
修改的系统属性值
而 if (StartsWith(name, "ro.")) {
error = "Read-only property was already set";return PROP_ERROR_READ_ONLY_PROPERTY;}/
是判断如果ro.开头 就不能修改 所以注释掉就好
```

#### 3.2 动态修改ro开头系统属性的值的功能实现



```
static uint32_t PropertySet(const std::string& name, const std::string& value, std::string* error) {
size_t valuelen = value.size();
if (!IsLegalPropertyName(name)) {
    *error = "Illegal property name";
    return PROP_ERROR_INVALID_NAME;
}

if (valuelen >= PROP_VALUE_MAX && !StartsWith(name, "ro.")) {
    *error = "Property value too long";
    return PROP_ERROR_INVALID_VALUE;
}

if (mbstowcs(nullptr, value.data(), 0) == static_cast<std::size_t>(-1)) {
    *error = "Value is not a UTF8 encoded string";
    return PROP_ERROR_INVALID_VALUE;
}

prop_info* pi = (prop_info*) __system_property_find(name.c_str());
if (pi != nullptr) {
    // ro.* properties are actually "write-once".
    
  // 判断是不是ro开头的熟悉注释掉这段代码

  /* if (StartsWith(name, "ro.")) {
        *error = "Read-only property was already set";
        return PROP_ERROR_READ_ONLY_PROPERTY;
    }*/


    __system_property_update(pi, value.c_str(), valuelen);
} else {
    int rc = __system_property_add(name.c_str(), name.size(), value.c_str(), valuelen);
    if (rc < 0) {
        *error = "__system_property_add failed";
        return PROP_ERROR_SET_FAILED;
    }
}

// Don't write properties to disk until after we have read all default
// properties to prevent them from being overwritten by default values.
if (persistent_properties_loaded && StartsWith(name, "persist.")) {
    WritePersistentProperty(name, value);
}
// If init hasn't started its main loop, then it won't be handling property changed messages
// anyway, so there's no need to try to send them.
if (init_socket != -1) {
    SendPropertyChanged(name, value);
}
return PROP_SUCCESS;

}
```



