






### 1.概述


在10.0系统Tv设备开发中，USB鼠标通过usb口来控制设备也是常见的问题，可是原生的系统 鼠标右键不是返回键 根据客户需要修改成右键就需要跟代码了，  
 功能分析：  
 InputReader 从 EventHub 读取原始事件数据，并将其处理为输入事件，并将其发送到 InputListener。 InputReader 的某些功能（例如低功耗状态下的早期事件过滤）由单独的策略对象控制。  
 追踪代码到InputReader.cpp文件，位置frameworks/native/services/inputflinger/InputReader.cpp。InputReader主要功能是处理EventHub传过来的事件，然后加工，再分发给各个InputDispatcher


### 2.USB鼠标右键改成返回键的核心类



```
frameworks/native/services/inputflinger/InputReader.cpp

```

### 3.USB鼠标右键改成返回键的核心功能分析和实现


经过上述功能分析发现具体实现类是在InputReader.cpp中所以  
 接下来看InputReader.cpp源码



```
    void InputReader::loopOnce() {
      int32_t oldGeneration;
      int32_t timeoutMillis;
      bool inputDevicesChanged = false;
      std::vector<InputDeviceInfo> inputDevices;
      { // acquire lock
          AutoMutex _l(mLock);
  
          oldGeneration = mGeneration;
          timeoutMillis = -1;
  
          uint32_t changes = mConfigurationChangesToRefresh;
          if (changes) {
              mConfigurationChangesToRefresh = 0;
              timeoutMillis = 0;
              refreshConfigurationLocked(changes);
          } else if (mNextTimeout != LLONG_MAX) {
              nsecs_t now = systemTime(SYSTEM_TIME_MONOTONIC);
              timeoutMillis = toMillisecondTimeoutDelay(now, mNextTimeout);
          }
      } // release lock
  
      size_t count = mEventHub->getEvents(timeoutMillis, mEventBuffer, EVENT_BUFFER_SIZE);
  
      { // acquire lock
          AutoMutex _l(mLock);
          mReaderIsAliveCondition.broadcast();
  
          if (count) {
              processEventsLocked(mEventBuffer, count);
          }
  
          if (mNextTimeout != LLONG_MAX) {
              nsecs_t now = systemTime(SYSTEM_TIME_MONOTONIC);
              if (now >= mNextTimeout) {
  #if DEBUG\_RAW\_EVENTS
                  ALOGD("Timeout expired, latency=%0.3fms", (now - mNextTimeout) * 0.000001f);
  #endif
                  mNextTimeout = LLONG_MAX;
                  timeoutExpiredLocked(now);
              }
          }
  
          if (oldGeneration != mGeneration) {
              inputDevicesChanged = true;
              getInputDevicesLocked(inputDevices);
          }
      } // release lock
  
      // Send out a message that the describes the changed input devices.
      if (inputDevicesChanged) {
          mPolicy->notifyInputDevicesChanged(inputDevices);
      }
  
      // Flush queued events out to the listener.
      // This must happen outside of the lock because the listener could potentially call
      // back into the InputReader's methods, such as getScanCodeState, or become blocked
 // on another thread similarly waiting to acquire the InputReader lock thereby
 // resulting in a deadlock. This situation is actually quite plausible because the
 // listener is actually the input dispatcher, which calls into the window manager,
 // which occasionally calls into the input reader.
 mQueuedListener->flush();
 }
void InputReader::processEventsLocked(const RawEvent\* rawEvents, size\_t count) {
 if(rawEvents->value == 0 || rawEvents->value == 1 || rawEvents->value == -1){ // 0:A and B type key up or A type touch or move end; -1: B type touch or move up
 ALOGD("processEventsLocked: type=%d Count=%zu code=%d value=%d deviceId=%d",
 rawEvents->type, count,rawEvents->code,rawEvents->value,rawEvents->deviceId);
 }
 for (const RawEvent\* rawEvent = rawEvents; count;) {
 int32\_t type = rawEvent->type;
 size\_t batchSize = 1;
 if (type < EventHubInterface::FIRST\_SYNTHETIC\_EVENT) {
 int32\_t deviceId = rawEvent->deviceId;
 while (batchSize < count) {
 if (rawEvent[batchSize].type >= EventHubInterface::FIRST\_SYNTHETIC\_EVENT
 || rawEvent[batchSize].deviceId != deviceId) {
 break;
 }
 batchSize += 1;
 }
#if DEBUG\_RAW\_EVENTS
 ALOGD\_READER("BatchSize: %zu Count: %zu", batchSize, count);
#endif
 processEventsForDeviceLocked(deviceId, rawEvent, batchSize);
 } else {
 switch (rawEvent->type) {
 case EventHubInterface::DEVICE\_ADDED:
 addDeviceLocked(rawEvent->when, rawEvent->deviceId);
 break;
 case EventHubInterface::DEVICE\_REMOVED:
 removeDeviceLocked(rawEvent->when, rawEvent->deviceId);
 break;
 case EventHubInterface::FINISHED\_DEVICE\_SCAN:
 handleConfigurationChangedLocked(rawEvent->when);
 break;
 default:
 ALOG\_ASSERT(false); // can't happen
                break;
            }
        }
        count -= batchSize;
        rawEvent += batchSize;
    }
}

```

在上述代码中发现processEventsLocked(const RawEvent\* rawEvents, size\_t count)具体处理输入事件  
 而对于真正处理鼠标事件的就是在这里getButtonState()中处理的，接下来看下getButtonState()的具体处理如下：



```
uint32_t CursorButtonAccumulator::getButtonState() const {
    uint32_t result = 0;
    if (mBtnLeft) {
        result |= AMOTION_EVENT_BUTTON_PRIMARY;
    }
   // 鼠标右键处理
    if (mBtnRight) {
        result |= AMOTION_EVENT_BUTTON_SECONDARY;
    }
    if (mBtnMiddle) {
        result |= AMOTION_EVENT_BUTTON_TERTIARY;
    }
    if (mBtnBack || mBtnSide) {
        result |= AMOTION_EVENT_BUTTON_BACK;
    }
    if (mBtnForward || mBtnExtra) {
        result |= AMOTION_EVENT_BUTTON_FORWARD;
    }
    return result;
}

```

在上述代码中发现getButtonState() 处理鼠标右键事件是在mBtnRight为true 负责right的值  
 所以想修改鼠标右键事件，可以在这里修改，所以可以具体修改为:



```
uint32_t CursorButtonAccumulator::getButtonState() const {
    uint32_t result = 0;
    if (mBtnLeft) {
        result |= AMOTION_EVENT_BUTTON_PRIMARY;
    }
   // 鼠标右键处理
    if (mBtnRight) {
       - result |= AMOTION_EVENT_BUTTON_SECONDARY;
      +  result |= AMOTION_EVENT_BUTTON_BACK;
    }
    if (mBtnMiddle) {
        result |= AMOTION_EVENT_BUTTON_TERTIARY;
    }
    if (mBtnBack || mBtnSide) {
        result |= AMOTION_EVENT_BUTTON_BACK;
    }
    if (mBtnForward || mBtnExtra) {
        result |= AMOTION_EVENT_BUTTON_FORWARD;
    }
    return result;
}

```

不过这样就写死了 如果想通过属性开关来控制的话也可以这样  
 首先在system.prop中添加一个prop属性：persist.sys.right.back=false  
 上层通过设置属性值来控制是否back事件  
 所以可以修改成



```
uint32_t CursorButtonAccumulator::getButtonState() const {
    uint32_t result = 0;
    if (mBtnLeft) {
        result |= AMOTION_EVENT_BUTTON_PRIMARY;
    }
   // 鼠标右键处理
    if (mBtnRight) {
       - result |= AMOTION_EVENT_BUTTON_SECONDARY;
      +  char rightback[PROPERTY_VALUE_MAX]=“”；
       +     __system_property_get("persist.sys.right.back", rightback);
       +     if(strcmp(rightback,"true") == 0){
        +         result |= AMOTION_EVENT_BUTTON_BACK;
        +    }else{
         +        result |= AMOTION_EVENT_BUTTON_SECONDARY;
         +   }
    }
    if (mBtnMiddle) {
        result |= AMOTION_EVENT_BUTTON_TERTIARY;
    }
    if (mBtnBack || mBtnSide) {
        result |= AMOTION_EVENT_BUTTON_BACK;
    }
    if (mBtnForward || mBtnExtra) {
        result |= AMOTION_EVENT_BUTTON_FORWARD;
    }
    return result;
}

```

修改完验证功能，发现实现了同样的功能





