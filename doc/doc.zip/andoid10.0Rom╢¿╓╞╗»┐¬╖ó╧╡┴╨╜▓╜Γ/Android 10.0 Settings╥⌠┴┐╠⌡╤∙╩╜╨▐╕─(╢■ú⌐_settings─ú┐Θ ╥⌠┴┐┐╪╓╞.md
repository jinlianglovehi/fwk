






### 1.概述


在10.0的系统产品开发中，对于系统Settings声音一级菜单中，进入声音会有媒体音量 闹钟音量 通知音量等音量条，系统默认的音量条样式不太美观，所以要根据产品需要修改音量条的布局  
 所以需要自己定制修改


### 2.Settings音量条样式修改(二）的核心类



```
 /packages/apps/Settings/res/xml/sound_settings.xml
 packages/apps/Settings/src/com/android/settings/widget/SeekBarPreference.java
 /packages/apps/Settings/src/com/android/settings/notification/VolumeSeekBarPreference.java

```

### 3.Settings音量条样式修改(二）的核心功能分析和实现


在系统Settings中的声音界面布局中，默认是xml就是sound\_settings.xml  
 布局，所以可以从这里看出关于音量条的相关类布局


### 3.1sound\_settings.xml的相关布局分析


首选看下布局文件 sound\_settings.xml



```
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (C) 2017 The Android Open Source Project

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
-->

<PreferenceScreen
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:settings="http://schemas.android.com/apk/res-auto"
    android:title="@string/sound\_settings"
    android:key="sound\_settings"
    settings:keywords="@string/keywords\_sounds"
    settings:initialExpandedChildrenCount="9">

    <!-- Remote volume -->
    <com.android.settings.notification.RemoteVolumeSeekBarPreference
        android:key="remote\_volume"
        android:icon="@drawable/ic\_volume\_remote"
        android:title="@string/remote\_media\_volume\_option\_title"
        android:order="-185"
        settings:controller="com.android.settings.notification.RemoteVolumePreferenceController"/>

    <!-- Media volume -->
    <com.android.settings.notification.VolumeSeekBarPreference
        android:key="media\_volume"
        android:icon="@drawable/ic\_media\_stream"
        android:title="@string/media\_volume\_option\_title"
        android:order="-180"
        settings:controller="com.android.settings.notification.MediaVolumePreferenceController"/>

    <!-- Media output switcher -->
    <Preference
        android:key="media\_output"
        android:title="@string/media\_output\_title"
        android:dialogTitle="@string/media\_output\_title"
        android:order="-175"
        settings:controller="com.android.settings.sound.MediaOutputPreferenceController"/>

    <!-- Call volume -->
    <com.android.settings.notification.VolumeSeekBarPreference
        android:key="call\_volume"
        android:icon="@drawable/ic\_local\_phone\_24\_lib"
        android:title="@string/call\_volume\_option\_title"
        android:order="-170"
        settings:controller="com.android.settings.notification.CallVolumePreferenceController"/>

    <!-- Hands free profile output switcher -->
    <ListPreference
        android:key="take\_call\_on\_output"
        android:title="@string/take\_call\_on\_title"
        android:dialogTitle="@string/take\_call\_on\_title"
        android:order="-165"
        settings:controller="com.android.settings.sound.HandsFreeProfileOutputPreferenceController"/>

    <!-- Ring volume -->
    <com.android.settings.notification.VolumeSeekBarPreference
        android:key="ring\_volume"
        android:icon="@drawable/ic\_notifications"
        android:title="@string/ring\_volume\_option\_title"
        android:order="-160"
        settings:controller="com.android.settings.notification.RingVolumePreferenceController"/>


    <!-- Alarm volume -->
    <com.android.settings.notification.VolumeSeekBarPreference
        android:key="alarm\_volume"
        android:icon="@\*android:drawable/ic\_audio\_alarm"
        android:title="@string/alarm\_volume\_option\_title"
        android:order="-150"
        settings:controller="com.android.settings.notification.AlarmVolumePreferenceController"/>

    <!-- Notification volume -->
    <com.android.settings.notification.VolumeSeekBarPreference
        android:key="notification\_volume"
        android:icon="@drawable/ic\_notifications"
        android:title="@string/notification\_volume\_option\_title"
        android:order="-140"
        settings:controller="com.android.settings.notification.NotificationVolumePreferenceController"/>

    <!-- Also vibrate for calls -->
    <SwitchPreference
        android:key="vibrate\_when\_ringing"
        android:title="@string/vibrate\_when\_ringing\_title"
        settings:controller="com.android.settings.notification.VibrateWhenRingPreferenceController"
        android:order="-130"/>

    <!-- Interruptions -->
    <com.android.settingslib.RestrictedPreference
        android:key="zen\_mode"
        android:title="@string/zen\_mode\_settings\_title"
        android:fragment="com.android.settings.notification.ZenModeSettings"
        android:order="-120"
        settings:useAdminDisabledSummary="true"
        settings:keywords="@string/keywords\_sounds\_and\_notifications\_interruptions"
        settings:allowDividerAbove="true"
        settings:controller="com.android.settings.notification.ZenModePreferenceController"/>

    <Preference
        android:key="gesture\_prevent\_ringing\_sound"
        android:title="@string/gesture\_prevent\_ringing\_sound\_title"
        android:order="-110"
        android:fragment="com.android.settings.gestures.PreventRingingGestureSettings"
        settings:controller="com.android.settings.gestures.PreventRingingParentPreferenceController"/>

    <!-- Phone ringtone -->
    <com.android.settings.DefaultRingtonePreference
        android:key="ringtone"
        android:title="@string/ringtone\_title"
        android:dialogTitle="@string/ringtone\_title"
        android:summary="@string/summary\_placeholder"
        android:ringtoneType="ringtone"
        android:order="-100"
        settings:keywords="@string/sound\_settings"/>

    <!-- Default notification ringtone -->
    <com.android.settings.DefaultRingtonePreference
        android:key="notification\_ringtone"
        android:title="@string/notification\_ringtone\_title"
        android:dialogTitle="@string/notification\_ringtone\_title"
        android:summary="@string/summary\_placeholder"
        android:ringtoneType="notification"
        android:order="-90"/>

    <!-- Default alarm ringtone -->
    <com.android.settings.DefaultRingtonePreference
        android:key="alarm\_ringtone"
        android:title="@string/alarm\_ringtone\_title"
        android:dialogTitle="@string/alarm\_ringtone\_title"
        android:summary="@string/summary\_placeholder"
        android:persistent="false"
        android:ringtoneType="alarm"
        android:order="-80"/>

    <!-- Other sounds -->
    <PreferenceCategory
          android:key="other\_sounds\_and\_vibrations\_category"
          android:title="@string/other\_sound\_category\_preference\_title"
          android:order="-50">

        <!-- Dial pad tones -->
        <SwitchPreference
          android:key="dial\_pad\_tones"
          android:title="@string/dial\_pad\_tones\_title"/>

        <!-- Screen locking sounds -->
        <SwitchPreference
          android:key="screen\_locking\_sounds"
          android:title="@string/screen\_locking\_sounds\_title"/>

        <!-- Charging sounds -->
        <!--SwitchPreference
          android:key="charging\_sounds"
          android:title="@string/charging\_sounds\_title"/-->

        <!-- Docking sounds -->
        <SwitchPreference
          android:key="docking\_sounds"
          android:title="@string/docking\_sounds\_title"/>

        <!-- Touch sounds -->
        <SwitchPreference
          android:key="touch\_sounds"
          android:title="@string/touch\_sounds\_title"/>

        <!-- Vibrate on touch -->
        <SwitchPreference
          android:key="vibrate\_on\_touch"
          android:title="@string/vibrate\_on\_touch\_title"
          android:summary="@string/vibrate\_on\_touch\_summary"
          settings:keywords="@string/keywords\_vibrate\_on\_touch"/>

        <!-- Dock speaker plays -->
        <DropDownPreference
          android:key="dock\_audio\_media"
          android:title="@string/dock\_audio\_media\_title"
          android:summary="%s"/>

        <!-- Boot sounds -->
        <SwitchPreference
          android:key="boot\_sounds"
          android:title="@string/boot\_sounds\_title"/>

        <!-- Emergency tone -->
        <DropDownPreference
          android:key="emergency\_tone"
          android:title="@string/emergency\_tone\_title"
          android:summary="%s"/>
    </PreferenceCategory>

    <com.android.settings.widget.WorkOnlyCategory
        android:key="sound\_work\_settings\_section"
        android:title="@string/sound\_work\_settings"
        android:order="100">

                <!-- Use the same sounds of the work profile -->
                <SwitchPreference
                    android:key="work\_use\_personal\_sounds"
                    android:title="@string/work\_use\_personal\_sounds\_title"
                    android:summary="@string/work\_use\_personal\_sounds\_summary"
                    android:disableDependentsState="true"/>

                <!-- Work phone ringtone -->
                <com.android.settings.DefaultRingtonePreference
                    android:key="work\_ringtone"
                    android:title="@string/work\_ringtone\_title"
                    android:dialogTitle="@string/work\_alarm\_ringtone\_title"
                    android:ringtoneType="ringtone"
                    android:dependency="work\_use\_personal\_sounds"/>

                <!-- Default work notification ringtone -->
                <com.android.settings.DefaultRingtonePreference
                    android:key="work\_notification\_ringtone"
                    android:title="@string/work\_notification\_ringtone\_title"
                    android:dialogTitle="@string/work\_alarm\_ringtone\_title"
                    android:ringtoneType="notification"
                    android:dependency="work\_use\_personal\_sounds"/>

                <!-- Default work alarm ringtone -->
                <com.android.settings.DefaultRingtonePreference
                    android:key="work\_alarm\_ringtone"
                    android:title="@string/work\_alarm\_ringtone\_title"
                    android:dialogTitle="@string/work\_alarm\_ringtone\_title"
                    android:persistent="false"
                    android:ringtoneType="alarm"
                    android:dependency="work\_use\_personal\_sounds"/>

    </com.android.settings.widget.WorkOnlyCategory>
</PreferenceScreen>

```

从上述的sound\_settings.xml的布局中，可以看出闹钟 媒体 通知等音量条都是  
 从布局文件可以看出 com.android.settings.notification.VolumeSeekBarPreference 就是音量条布局  
 所以要看下VolumeSeekBarPreference的相关源码分析


### 3.2VolumeSeekBarPreference相关音量条功能分析


从上面的分析可以看出音量条的布局就是VolumeSeekBarPreference接下来  
 看下关于音量进度条的相关代码



```
public class VolumeSeekBarPreference extends SeekBarPreference {
    private static final String TAG = "VolumeSeekBarPreference";

    protected SeekBar mSeekBar;
    private int mStream;
    private SeekBarVolumizer mVolumizer;
    private Callback mCallback;
    private ImageView mIconView;
    private TextView mSuppressionTextView;
    private String mSuppressionText;
    private boolean mMuted;
    private boolean mZenMuted;
    private int mIconResId;
    private int mMuteIconResId;
    private boolean mStopped;
    @VisibleForTesting
    AudioManager mAudioManager;

    public VolumeSeekBarPreference(Context context, AttributeSet attrs, int defStyleAttr,
            int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setLayoutResource(R.layout.preference_volume_slider);
        mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    }
......
}

```

从VolumeSeekBarPreference的代码看出它 也是继承于SeekBarPreference的  
 所以可以在SeekBarPreference查看相关的源码，然后分析功能实现定制音量条布局  
 接下来看下SeekBarPreference相关源码布局  
 路径：packages/apps/Settings/src/com/android/settings/widget/SeekBarPreference.java


### 3.3SeekBarPreference 相关音量条布局



```
public class SeekBarPreference extends RestrictedPreference
        implements OnSeekBarChangeListener, View.OnKeyListener {

    private int mProgress;
    private int mMax;
    private int mMin;
    private boolean mTrackingTouch;

    private boolean mContinuousUpdates;
    private int mDefaultProgress = -1;
    private Context mContext;
    private SeekBar mSeekBar;
    private boolean mShouldBlink;
    private int mAccessibilityRangeInfoType = AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_INT;
    private CharSequence mSeekBarContentDescription;

    public SeekBarPreference(
            Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);

        TypedArray a = context.obtainStyledAttributes(
                attrs, com.android.internal.R.styleable.ProgressBar, defStyleAttr, defStyleRes);
        setMax(a.getInt(com.android.internal.R.styleable.ProgressBar_max, mMax));
        setMin(a.getInt(com.android.internal.R.styleable.ProgressBar_min, mMin));
        a.recycle();
        mContext=context;
        a = context.obtainStyledAttributes(attrs,
                com.android.internal.R.styleable.SeekBarPreference, defStyleAttr, defStyleRes);
        final int layoutResId = a.getResourceId(
                com.android.internal.R.styleable.SeekBarPreference_layout,
                com.android.internal.R.layout.preference_widget_seekbar);
        a.recycle();

        a = context.obtainStyledAttributes(
                attrs, com.android.internal.R.styleable.Preference, defStyleAttr, defStyleRes);
        final boolean isSelectable = a.getBoolean(
                com.android.settings.R.styleable.Preference_android_selectable, false);
        setSelectable(isSelectable);
        a.recycle();

        setLayoutResource(layoutResId);
    }

    public SeekBarPreference(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public SeekBarPreference(Context context, AttributeSet attrs) {
        this(context, attrs, TypedArrayUtils.getAttr(context,
                        androidx.preference.R.attr.seekBarPreferenceStyle,
                        com.android.internal.R.attr.seekBarPreferenceStyle));
    }

    public SeekBarPreference(Context context) {
        this(context, null);
    }

    public void setShouldBlink(boolean shouldBlink) {
        mShouldBlink = shouldBlink;
        notifyChanged();
    }

    @Override
    public boolean isSelectable() {
        if(isDisabledByAdmin()) {
            return true;
        } else {
            return super.isSelectable();
        }
    }

    @Override
    public void onBindViewHolder(PreferenceViewHolder view) {
        super.onBindViewHolder(view);
        view.itemView.setOnKeyListener(this);
        mSeekBar = (SeekBar) view.findViewById(
                com.android.internal.R.id.seekbar);
	+    Drawable progressdrawable = mContext.getResources().getDrawable(com.android.settings.R.drawable.brightness_progress_drawable);
	+    Drawable thumbdrawable = mContext.getResources().getDrawable(com.android.settings.R.drawable.icon_jindu);
        +    mSeekBar.setProgressDrawable(progressdrawable);
        +    mSeekBar.setThumb(thumbdrawable);		
        mSeekBar.setOnSeekBarChangeListener(this);
        mSeekBar.setMax(mMax);
        mSeekBar.setMin(mMin);
        mSeekBar.setProgress(mProgress);
        mSeekBar.setEnabled(isEnabled());
        final CharSequence title = getTitle();
        if (!TextUtils.isEmpty(mSeekBarContentDescription)) {
            mSeekBar.setContentDescription(mSeekBarContentDescription);
        } else if (!TextUtils.isEmpty(title)) {
            mSeekBar.setContentDescription(title);
        }
        if (mSeekBar instanceof DefaultIndicatorSeekBar) {
            ((DefaultIndicatorSeekBar) mSeekBar).setDefaultProgress(mDefaultProgress);
 }
 if (mShouldBlink) {
 View v = view.itemView;
 v.post(() -> {
 if (v.getBackground() != null) {
 final int centerX = v.getWidth() / 2;
 final int centerY = v.getHeight() / 2;
 v.getBackground().setHotspot(centerX, centerY);
 }
 v.setPressed(true);
 v.setPressed(false);
 mShouldBlink = false;
 });
 }
 mSeekBar.setAccessibilityDelegate(new View.AccessibilityDelegate() {
 @Override
 public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo info) {
 super.onInitializeAccessibilityNodeInfo(view, info);
 // Update the range info with the correct type
 AccessibilityNodeInfo.RangeInfo rangeInfo = info.getRangeInfo();
 if (rangeInfo != null) {
 info.setRangeInfo(AccessibilityNodeInfo.RangeInfo.obtain(
 mAccessibilityRangeInfoType, rangeInfo.getMin(),
 rangeInfo.getMax(), rangeInfo.getCurrent()));
                }
            }
        });
    }

```

在SeekBarPreference 中关于音量条布局类中，发现布局的相关方法onBindViewHolder 里面就是绑定SeekBar的一些参数而也可以在这里设置样式就好了.从而改成自己需要的样式从而来满足功能  
 所以需要增加亮度条布局背景如下


brightness\_progress\_drawable.xml



```
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@android:id/background"
          android:gravity="center\_vertical|fill\_horizontal">
        <shape android:shape="rectangle">
            <size android:height="3dp" />
            <solid android:color="#eeeeee" />
            <corners android:radius="3dp" />
        </shape>
    </item>
    <item android:id="@android:id/progress"
          android:gravity="center\_vertical|fill\_horizontal">
        <scale android:scaleWidth="100%">
            <shape android:shape="rectangle">
                <size android:height="3dp" />
                <solid android:color="#0091ff" />
                <corners android:radius="3dp" />
            </shape>
        </scale>
    </item>
</layer-list>

```

icon\_jindu 为 thumb的图片


编译Settings.apk 然后替换发现样式已经变了





