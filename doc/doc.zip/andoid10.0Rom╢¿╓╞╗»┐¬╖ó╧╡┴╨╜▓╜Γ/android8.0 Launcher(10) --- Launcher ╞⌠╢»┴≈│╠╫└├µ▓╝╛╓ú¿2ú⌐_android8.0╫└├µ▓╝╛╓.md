






本篇讲解Launcher启动流程第四步setupViews方法中的第二部分 setupOverviewPanel();这个方法。


对于setupOverviewPanel（）方法主要操作就是对overViewPanel布局里面的空间进行事件的绑定。对于OverViewPanel的布局整体在res里面以xml文件的形式存在。


什么是OverViewPanel那？  
 在Launcher使用时，长按桌面空白处，此时workspace缩小，hotseat消失，在下方出现三个选项，wallpapers，widget，setting，这个提供特殊选项的栏就叫做overviewpanel


setupOverviewPanel()  
 我们来看下 setupOverviewPanel()方法的源码。通关观察，我们发现整个方法思路很清晰，首先获取overview\_panel的View，然后依次创建wallpaper，widget，settings这3个buttom。给button设置点击事件。



```
private void setupOverviewPanel() {
    mOverviewPanel = (ViewGroup) findViewById(R.id.overview_panel);

  1.  // Bind wallpaper button actions
    View wallpaperButton = findViewById(R.id.wallpaper_button);
    new OverviewButtonClickListener(ControlType.WALLPAPER_BUTTON) {
        @Override
        public void handleViewClick(View view) {
            onClickWallpaperPicker(view);
        }
    }.attachTo(wallpaperButton);

    2.// Bind widget button actions
    mWidgetsButton = findViewById(R.id.widget_button);
    new OverviewButtonClickListener(ControlType.WIDGETS_BUTTON) {
        @Override
        public void handleViewClick(View view) {
            onClickAddWidgetButton(view);
        }
    }.attachTo(mWidgetsButton);

   3. // Bind settings actions
    View settingsButton = findViewById(R.id.settings_button);
    boolean hasSettings = hasSettings();
    if (hasSettings) {
        new OverviewButtonClickListener(ControlType.SETTINGS_BUTTON) {
            @Override
            public void handleViewClick(View view) {
                onClickSettingsButton(view);
            }
        }.attachTo(settingsButton);
    } else {
        settingsButton.setVisibility(View.GONE);
    }

    mOverviewPanel.setAlpha(0f);
}

```

第一步创建wallpaperButton  
 通过findViewById找到控件wallpaper\_button，创建Listener，并绑定到view上。new OverviewButtonClickListener().attachTo(wallpaperButton).  
 在attachTo方法中会给View设置长按点击事件和点击事件



```
 public void attachTo(View v) {
        v.setOnClickListener(this);
        v.setOnLongClickListener(this);
    }
那么点击事件的具体实现是在OverviewButtonClickListener这个类中，那么就来看一下这两个方法

  @Override
    public void onClick(View view) {
        if (shouldPerformClick(view)) {
            handleViewClick(view, Action.Touch.TAP);
        }
    }

    @Override
    public boolean onLongClick(View view) {
        if (shouldPerformClick(view)) {
            handleViewClick(view, Action.Touch.LONGPRESS);
        }
        return true;
    }

```

两个方法里面都调用了handleViewClick方法，而我们创建的OverviewButtonClickListener则是重写了handleViewClick方法。  
 public void handleViewClick(View view) {  
 onClickWallpaperPicker(view);  
 }  
 于是，这里创建对象并attach，就是当我们点击这个按钮时，要触发重写的方法。在wallpaperButton里面，我们写的是onClickWallpaperPicker(view)。  
 我们来看一下onClickWallpaperPicker(view)方法源码，只粘贴最关键代码



```
public void onClickWallpaperPicker(View v) {
        Intent intent = new Intent(Intent.ACTION_SET_WALLPAPER)
                .putExtra(Utilities.EXTRA_WALLPAPER_OFFSET, offset);
            startActivityForResult(intent, REQUEST_PICK_WALLPAPE
                    hasTargetPackage ? getActivityLaunchOptions(v) : null);
     
    }

```

主要操作是通过Intent跳转到设置壁纸功能的应用。


第二步创建mWidgetsButton  
 整个步骤和第一步基本一样，只有handelViewClick中重写的内容不一样，这里会调用 onClickAddWidgetButton(view);方法。



```
 public void onClickAddWidgetButton(View view) {
            showWidgetsView(true /* animated */, true /* resetPageToZero */);
    }

void showWidgetsView(boolean animated, boolean resetPageToZero) {
    showAppsOrWidgets(State.WIDGETS, animated, false);
}

private boolean showAppsOrWidgets(State toState, boolean animated, boolean focusSearchBar) {
    if (toState == State.APPS) {
        mStateTransitionAnimation.startAnimationToAllApps(animated, focusSearchBar);
    } else {
        mStateTransitionAnimation.startAnimationToWidgets(animated);
    }
    return true;
}

```

从代码可以看到，是一个递进调用，过程中对state进行设置，最终调用了mStateTransitionAnimation这个对象的方法。  
 mStateTransitionAnimation是在Launcher流程第三步创建的第三个对象，负责不同模式间的切换，在onClickAddWidgetButton中完成的是从overview模式到widget模式的切换。


第三步创建settingsButton  
 最后是settingsButton



```
 public void onClickSettingsButton(View v) {
        if (LOGD) Log.d(TAG, "onClickSettingsButton");
        Intent intent = new Intent(getApplicationContext(), HomescreenSettingsActivity.class);
        intent.setSourceBounds(getViewBounds(v));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent, getActivityLaunchOptions(v));
        showWorkspace(true);
    }

```

通过intent跳转到设置页面。


这样overviewpanel的三个选项就都完成了。其中wallpapers和settings是启动新的activity ， widget是Launcher之间的模式变化





