






### 1.概述


在10.0的产品开发中，对于产品需求要求对蓝牙模块进行管控，控制蓝牙模块的启用和停用，  
 所以需要了解蓝牙模块的流程，然后进行管控


### 2.启用和停用蓝牙模块(蓝牙模块功能开关控制)的核心类



```
/frameworks/base/services/core/java/com/android/server/BluetoothManagerService.java
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/BluetoothControllerImpl.java
packages/apps/Settings/src/com/android/settings/bluetooth/BluetoothEnabler.java
packages/apps/Settings/src/com/android/set
tings/connecteddevice/BluetoothDashboardFragment.java
frameworks/base/packages/SettingsLib/src/com/android/settingslib/bluetooth/LocalBluetoothAdapter.java
frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tiles/BluetoothTile.java

```

### 3.启用和停用蓝牙模块(蓝牙模块功能开关控制)的核心功能分析和实现


### 3.1BluetoothManagerService.java 中对启动蓝牙的模块进行控制


路径:/frameworks/base/services/core/java/com/android/server/BluetoothManagerService.java



```
public boolean enable(String packageName) throws RemoteException {
        final int callingUid = Binder.getCallingUid();
        final boolean callerSystem = UserHandle.getAppId(callingUid) == Process.SYSTEM_UID;

        if (isBluetoothDisallowed()) {
            if (DBG) {
                Slog.d(TAG, "enable(): not enabling - bluetooth disallowed");
            }
            return false;
        }
+               //add code start
+               if(SystemProperties.get("persist.sys.disableBT", "false").equals("true")){
+                       return false;
+               }
+               //add code end

        if (!callerSystem) {
            // Check if packageName belongs to callingUid
            checkPackage(callingUid, packageName);

            if (!checkIfCallerIsForegroundUser()) {
                Slog.w(TAG, "enable(): not allowed for non-active and non system user");
                return false;
            }

            mContext.enforceCallingOrSelfPermission(BLUETOOTH_ADMIN_PERM,
                    "Need BLUETOOTH ADMIN permission");

            if (!isEnabled() && mWirelessConsentRequired && startConsentUiIfNeeded(packageName,
                    callingUid, BluetoothAdapter.ACTION_REQUEST_ENABLE)) {
                return false;
            }
        }

        if (DBG) {
            Slog.d(TAG, "enable(" + packageName + "): mBluetooth =" + mBluetooth + " mBinding = "
                    + mBinding + " mState = " + BluetoothAdapter.nameForState(mState));
        }

        synchronized (mReceiver) {
            mQuietEnableExternal = false;
            mEnableExternal = true;
            // waive WRITE_SECURE_SETTINGS permission check
            sendEnableMsg(false,
                    BluetoothProtoEnums.ENABLE_DISABLE_REASON_APPLICATION_REQUEST, packageName);
        }
        if (DBG) {
            Slog.d(TAG, "enable returning");
        }
        return true;
    }

```

在BluetoothManagerService.java的enable(String packageName)中控制蓝牙的开启功能，通过系统属性persist.sys.disableBT来判断是否需要开启蓝牙


### 3.2 SystemUI中关于下拉状态栏中的蓝牙模块的控制


首先是在BluetoothControllerImpl 中控制蓝牙模块开启



```
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/BluetoothControllerImpl.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/policy/BluetoothControllerImpl.java
@@ -17,7 +17,7 @@
 package com.android.systemui.statusbar.policy;
 
 import static com.android.systemui.Dependency.BG_LOOPER_NAME;
-
+import android.os.SystemProperties;
 import android.annotation.Nullable;
 import android.app.ActivityManager;
 import android.bluetooth.BluetoothAdapter;
@@ -185,7 +185,10 @@ public class BluetoothControllerImpl implements BluetoothController, BluetoothCa
 
     @Override
     public boolean isBluetoothSupported() {
-        return mLocalBluetoothManager != null;
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               boolean support=!"true".equals(flag);
+        return support;
     }

```

在BluetoothControllerImpl 中的isBluetoothSupported()中的判断是否支持蓝牙模块，这里也需要根据  
 系统属性persist.sys.disableBT来进行判断是否需要支持蓝牙模块


在下拉状态栏中的蓝牙快捷模块是否开启蓝牙模块的判断



```
diff --git a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tiles/BluetoothTile.java b/frameworks/base/packages/SystemUI/src/com/android/s
ystemui/qs/tiles/BluetoothTile.java
old mode 100644
new mode 100755
index c5aab32b2f..0f55286614
--- a/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tiles/BluetoothTile.java
+++ b/frameworks/base/packages/SystemUI/src/com/android/systemui/qs/tiles/BluetoothTile.java
@@ -47,7 +47,7 @@ import com.android.systemui.qs.QSDetailItems.Item;
 import com.android.systemui.qs.QSHost;
 import com.android.systemui.qs.tileimpl.QSTileImpl;
 import com.android.systemui.statusbar.policy.BluetoothController;
-
+import android.os.SystemProperties;
 import java.util.ArrayList;
 import java.util.Collection;
 import java.util.List;
@@ -93,6 +93,11 @@ public class BluetoothTile extends QSTileImpl<BooleanState> {
 
     @Override
     protected void handleClick() {
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               if("true".equals(flag)){
+                       return ;
+               }
         // Secondary clicks are header clicks, just toggle.
         final boolean isEnabled = mState.value;
         // Immediately enter transient enabling state when turning bluetooth on.
@@ -102,11 +107,21 @@ public class BluetoothTile extends QSTileImpl<BooleanState> {
 
     @Override
     public Intent getLongClickIntent() {
         return new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
     }
 
     @Override
     protected void handleSecondaryClick() {
         if (!mController.canConfigBluetooth()) {
             mActivityStarter.postStartActivityDismissingKeyguard(
                     new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), 0);

```

在BluetoothTile.java中的handleClick()判断是否在点击蓝牙模块的时候，根据系统属性persist.sys.disableBT中判断是否支持蓝牙


### 3.3Settings 关于蓝牙的模块控制


在BluetoothEnabler.java 中Settings中蓝牙开关页面是否可以打开蓝牙按钮判断



```
@Override
--- a/packages/apps/Settings/src/com/android/settings/bluetooth/BluetoothEnabler.java
+++ b/packages/apps/Settings/src/com/android/settings/bluetooth/BluetoothEnabler.java
@@ -24,9 +24,9 @@ import android.content.IntentFilter;
import android.os.UserManager;
import android.provider.Settings;
import android.widget.Toast;
-
+import android.util.Log;
import androidx.annotation.VisibleForTesting;
-
+import android.os.SystemProperties;
import com.android.settings.R;
import com.android.settings.widget.SwitchWidgetController;
import com.android.settingslib.RestrictedLockUtils.EnforcedAdmin;
@@ -85,6 +85,12 @@ public final class BluetoothEnabler implements SwitchWidgetController.OnSwitchCh
        }
        mIntentFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        mRestrictionUtils = restrictionUtils;
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               if("true".equals(flag)){
+                       mSwitchController.setEnabled(false);
+               } 
    }

    public void setupSwitchController() {
@@ -99,7 +105,13 @@ public final class BluetoothEnabler implements SwitchWidgetController.OnSwitchCh
        if (mContext != context) {
            mContext = context;
        }
-
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               Log.d("dong","BluetoothDashboardFragment:"+flag);
+               if("true".equals(flag)){
+                       mSwitchController.setEnabled(false);
+                       return;
+               } 
        final boolean restricted = maybeEnforceRestrictions();

        if (mBluetoothAdapter == null) {
@@ -166,6 +178,12 @@ public final class BluetoothEnabler implements SwitchWidgetController.OnSwitchCh

    @Override
    public boolean onSwitchToggled(boolean isChecked) {
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               if("true".equals(flag)){
+                       return false;
+               } 
        if (maybeEnforceRestrictions()) {
            triggerParentPreferenceCallback(isChecked);
            return true;

```

在BluetoothEnabler.java中关于蓝牙switch控件中，根据是否开启蓝牙的开关来根据系统属性persist.sys.disableBT来开启蓝牙模块来达到控制蓝牙模块的功能


接下来在BluetoothDashboardFragment.java来看关于蓝牙模块的管理



```
--- a/packages/apps/Settings/src/com/android/settings/connecteddevice/BluetoothDashboardFragment.java
+++ b/packages/apps/Settings/src/com/android/settings/connecteddevice/BluetoothDashboardFragment.java
@@ -35,7 +35,8 @@ import com.android.settings.widget.SwitchBarController;
import com.android.settingslib.core.lifecycle.Lifecycle;
import com.android.settingslib.search.SearchIndexable;
import com.android.settingslib.widget.FooterPreference;
-
+import android.os.SystemProperties;
+import android.util.Log;
import java.util.ArrayList;
import java.util.List;

@@ -112,6 +113,12 @@ public class BluetoothDashboardFragment extends DashboardFragment {
                lifecycle.addObserver(mSlaveController);
            }
        }
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               if("true".equals(flag)){
+                       mSwitchBar.setEnabled(false);
+               } 
    }

```

在系统设置的BluetoothDashboardFragment.java页面中对于开启蓝牙模块的控制  
 通过系统属性的persist.sys.disableBT的判断是否开启蓝牙功能



```
    /**
     * For Search.
--- a/frameworks/base/packages/SettingsLib/src/com/android/settingslib/bluetooth/LocalBluetoothAdapter.java
+++ b/frameworks/base/packages/SettingsLib/src/com/android/settingslib/bluetooth/LocalBluetoothAdapter.java
@@ -26,7 +26,7 @@ import android.util.Log;

import java.util.List;
import java.util.Set;
-
+import android.os.SystemProperties;
/**
 * LocalBluetoothAdapter provides an interface between the Settings app
 * and the functionality of the local {@link BluetoothAdapter}, specifically
@@ -87,6 +87,11 @@ public class LocalBluetoothAdapter {
    }

    public boolean enable() {
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               if("true".equals(flag)){
+                       return false;
+               }               
        return mAdapter.enable();
    }

@@ -226,6 +231,11 @@ public class LocalBluetoothAdapter {
    }

    public boolean setBluetoothEnabled(boolean enabled) {
+               String flag = SystemProperties.get("persist.sys.disableBT", "false");
+               if("true".equals(flag)){
+                       return false;
+               }               
        boolean success = enabled
                ? mAdapter.enable()
                : mAdapter.disable();

```

在系统设置的LocalBluetoothAdapter .java页面中对于开启蓝牙模块的控制通过系统属性persist.sys.disableBT判断是否在setBluetoothEnabled和enable() 中开启蓝牙模块





