






在更换系统壁纸后 感觉launcher3的WorkSpace 背景有点重影的感觉 那就得研究代码了


接下来下看launcher.xml



```
<com.android.launcher3.LauncherRootView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:launcher="http://schemas.android.com/apk/res-auto"
    android:id="@+id/launcher"
    android:layout_width="match\_parent"
    android:layout_height="match\_parent"
    android:fitsSystemWindows="true">

    <com.android.launcher3.dragndrop.DragLayer
        android:id="@+id/drag\_layer"
        android:layout_width="match\_parent"
        android:layout_height="match\_parent"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:importantForAccessibility="no">

        <!-- The workspace contains 5 screens of cells -->
        <!-- DO NOT CHANGE THE ID -->
        <com.android.launcher3.Workspace
            android:id="@+id/workspace"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent"
            android:layout_gravity="center"
            android:theme="@style/HomeScreenElementTheme"
            launcher:pageIndicator="@+id/page\_indicator" />

        <include layout="@layout/memoryinfo\_ext" />

        <!-- DO NOT CHANGE THE ID -->
        <include
            android:id="@+id/hotseat"
            layout="@layout/hotseat" />

        <include
            android:id="@+id/overview\_panel"
            layout="@layout/overview\_panel"
            android:visibility="gone" />

        <!-- Keep these behind the workspace so that they are not visible when
         we go into AllApps -->
        <com.sprd.ext.pageindicators.WorkspacePageIndicatorLine
            android:id="@+id/page\_indicator"
            android:layout_width="match\_parent"
            android:layout_height="@dimen/vertical\_drag\_handle\_size"
            android:layout_gravity="bottom"
            android:theme="@style/HomeScreenElementTheme" />

        <include
            android:id="@+id/page\_indicator\_customize"
            layout="@layout/page\_indicator\_customize" />

        <include
            android:id="@+id/drop\_target\_bar"
            layout="@layout/drop\_target\_bar" />

        <include
            android:id="@+id/scrim\_view"
            layout="@layout/scrim\_view" />

        <include
            android:id="@+id/apps\_view"
            layout="@layout/all\_apps"
            android:layout_width="match\_parent"
            android:layout_height="match\_parent" />

    </com.android.launcher3.dragndrop.DragLayer>

</com.android.launcher3.LauncherRootView>

```

从这里可以看出 最外层是DragLayer 来负责绘制的


接下来看 DragLayer.java的代码



```
public class DragLayer extends BaseDragLayer<Launcher> {

    public static final int ALPHA_INDEX_OVERLAY = 0;
    public static final int ALPHA_INDEX_LAUNCHER_LOAD = 1;
    public static final int ALPHA_INDEX_TRANSITIONS = 2;
    private static final int ALPHA_CHANNEL_COUNT = 3;

    public static final int ANIMATION_END_DISAPPEAR = 0;
    public static final int ANIMATION_END_REMAIN_VISIBLE = 2;

    @Thunk DragController mDragController;

    // Variables relating to animation of views after drop
    private ValueAnimator mDropAnim = null;
    private final TimeInterpolator mCubicEaseOutInterpolator = Interpolators.DEACCEL_1_5;
    @Thunk DragView mDropView = null;
    @Thunk int mAnchorViewInitialScrollX = 0;
    @Thunk View mAnchorView = null;

    private boolean mHoverPointClosesFolder = false;

    private int mTopViewIndex;
    private int mChildCountOnLastUpdate = -1;

    // Related to adjacent page hints
    private final ViewGroupFocusHelper mFocusIndicatorHelper;
    private final WorkspaceAndHotseatScrim mScrim;

    /**
     * Used to create a new DragLayer from XML.
     *
     * @param context The application's context.
 \* @param attrs The attributes set containing the Workspace's customization values.
     */
    public DragLayer(Context context, AttributeSet attrs) {
        super(context, attrs, ALPHA_CHANNEL_COUNT);

        // Disable multitouch across the workspace/all apps/customize tray
        setMotionEventSplittingEnabled(false);
        setChildrenDrawingOrderEnabled(true);

        mFocusIndicatorHelper = new ViewGroupFocusHelper(this);
        mScrim = new WorkspaceAndHotseatScrim(this);
    }

    public void setup(DragController dragController, Workspace workspace) {
        mDragController = dragController;
        mScrim.setWorkspace(workspace);
        recreateControllers();
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        // Draw the background below children.
        mScrim.draw(canvas);
        mFocusIndicatorHelper.draw(canvas);
        super.dispatchDraw(canvas);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mScrim.setSize(w, h);
    }

    @Override
    public void setInsets(Rect insets) {
        super.setInsets(insets);
        mScrim.onInsetsChanged(insets);
    }
}

```

而从源码中看 dispatchDraw(）和 setInsets（）  
 都调用了 WorkspaceAndHotseatScrim 的draw（）和 onInsetsChanged（）方法


接下来我们看下WorkspaceAndHotseatScrim的源码  
 路径:packages\apps\Launcher3\src\com\android\launcher3\graphics\WorkspaceAndHotseatScrim.java



```
public void draw(Canvas canvas) {
        // Draw the background below children.
        if (mScrimAlpha > 0) {
            // Update the scroll position first to ensure scrim cutout is in the right place.
            mWorkspace.computeScrollWithoutInvalidation();
            CellLayout currCellLayout = mWorkspace.getCurrentDragOverlappingLayout();
            canvas.save();
            if (currCellLayout != null && currCellLayout != mLauncher.getHotseat()) {
                // Cut a hole in the darkening scrim on the page that should be highlighted, if any.
                mLauncher.getDragLayer()
                        .getDescendantRectRelativeToSelf(currCellLayout, mHighlightRect);
                canvas.clipRect(mHighlightRect, Region.Op.DIFFERENCE);
            }

            canvas.drawColor(setColorAlphaBound(mFullScrimColor, mScrimAlpha));
            canvas.restore();
        }

        if (!mHideSysUiScrim) {
            if (mSysUiProgress <= 0) {
                mAnimateScrimOnNextDraw = false;
                return;
            }

            if (mAnimateScrimOnNextDraw) {
                mSysUiAnimMultiplier = 0;
                reapplySysUiAlphaNoInvalidate();

                ObjectAnimator anim = ObjectAnimator.ofFloat(this, SYSUI_ANIM_MULTIPLIER, 1);
                anim.setAutoCancel(true);
                anim.setDuration(600);
                anim.setStartDelay(mLauncher.getWindow().getTransitionBackgroundFadeDuration());
                anim.start();
                mAnimateScrimOnNextDraw = false;
            }

            if (mDrawTopScrim) {
                mTopScrim.draw(canvas);
            }
            if (mDrawBottomScrim) {
                canvas.drawBitmap(mBottomMask, null, mFinalMaskRect, mBottomMaskPaint);
            }
        }
    }

    public void onInsetsChanged(Rect insets) {
        mDrawTopScrim = mTopScrim != null && insets.top > 0;
        mDrawBottomScrim = mBottomMask != null &&
                !mLauncher.getDeviceProfile().isVerticalBarLayout();
    }

```

从draw()方法中可以看出



```
if (mDrawTopScrim) {
            mTopScrim.draw(canvas);
        }
        if (mDrawBottomScrim) {
            canvas.drawBitmap(mBottomMask, null, mFinalMaskRect, mBottomMaskPaint);
        }

```

mTopScrim来绘制画布 会导致重影  
 所以把mDrawTopScrim 和 mDrawBottomScrim 设置为false;


修改如下:



```
public void draw(Canvas canvas) {
        // Draw the background below children.
       + mDrawTopScrim = false;
       + mDrawBottomScrim = false;
        if (mScrimAlpha > 0) {
            // Update the scroll position first to ensure scrim cutout is in the right place.
            mWorkspace.computeScrollWithoutInvalidation();
            CellLayout currCellLayout = mWorkspace.getCurrentDragOverlappingLayout();
            canvas.save();
            if (currCellLayout != null && currCellLayout != mLauncher.getHotseat()) {
                // Cut a hole in the darkening scrim on the page that should be highlighted, if any.
                mLauncher.getDragLayer()
                        .getDescendantRectRelativeToSelf(currCellLayout, mHighlightRect);
                canvas.clipRect(mHighlightRect, Region.Op.DIFFERENCE);
            }

            canvas.drawColor(setColorAlphaBound(mFullScrimColor, mScrimAlpha));
            canvas.restore();
        }

        if (!mHideSysUiScrim) {
            if (mSysUiProgress <= 0) {
                mAnimateScrimOnNextDraw = false;
                return;
            }

            if (mAnimateScrimOnNextDraw) {
                mSysUiAnimMultiplier = 0;
                reapplySysUiAlphaNoInvalidate();

                ObjectAnimator anim = ObjectAnimator.ofFloat(this, SYSUI_ANIM_MULTIPLIER, 1);
                anim.setAutoCancel(true);
                anim.setDuration(600);
                anim.setStartDelay(mLauncher.getWindow().getTransitionBackgroundFadeDuration());
                anim.start();
                mAnimateScrimOnNextDraw = false;
            }

            if (mDrawTopScrim) {
                mTopScrim.draw(canvas);
            }
            if (mDrawBottomScrim) {
                canvas.drawBitmap(mBottomMask, null, mFinalMaskRect, mBottomMaskPaint);
            }
        }
    }

```

编译Launcher3 然后替换Launcher3.apk 然后验证





