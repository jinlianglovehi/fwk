






### 1.概述


在android 9.0 10.0中当安装低版本(TARGET\_SDK小于23 以下的app）时，会弹出应用版本过低提示框，其实也是有些麻烦的 如下图:  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/img_convert/dbf52a1e7f8cf6d19b01a8d50af31c30.png#pic_center)


### 2.安装低版本app 弹出应用版本过低警告窗的核心类



```
frameworks/base/services/core/java/com/android/server/wm/AppWarnings.java

```

### 3.安装低版本app 弹出应用版本过低警告窗的核心功能分析和实现


在安装低版本的app时，可以在弹窗提示页面的时候，利用adb shell命令查看当前置顶页面是哪个，  
 然后查看相关代码，  
 跟踪代码 原来是AMS 在启动app时会对 app版本做检测，如果过低就会弹出版本过低提示  
 具体流程如下:



```
@@ -287,7 +287,7 @@ class AppWarnings {
      /**
   * Manages warning dialogs shown during application lifecycle.
   */
  class AppWarnings {
      public AppWarnings(ActivityTaskManagerService atm, Context uiContext, Handler handler,
              Handler uiHandler, File systemDir) {
          mAtm = atm;
          mUiContext = uiContext;
          mHandler = new ConfigHandler(handler.getLooper());
          mUiHandler = new UiHandler(uiHandler.getLooper());
          mConfigFile = new AtomicFile(new File(systemDir, CONFIG_FILE_NAME), "warnings-config");
  
          readConfigFromFileAmsThread();
      }
     /**
     * Called when an activity is being started.
     *
     * @param r record for the activity being started
     */

    public void onStartActivity(ActivityRecord r) {
        showUnsupportedCompileSdkDialogIfNeeded(r);
        showUnsupportedDisplaySizeDialogIfNeeded(r);
       showDeprecatedTargetDialogIfNeeded(r)；
    }

```

在上述的AppWarnings构造方法中，启动configHandler和UiHandler的相关参数，用readConfigFromFileAmsThread()读取config的参数，而在 onStartActivity(ActivityRecord r)启动Activity,检测app的版本等信息



```
 /** 
     * Shows the "deprecated target sdk" warning, if necessary.
     *
     * @param r activity record for which the warning may be displayed
     */
    public void showDeprecatedTargetDialogIfNeeded(ActivityRecord r) {
        //MIN_SUPPORTED_TARGET_SDK_INT =23；
        if (r.appInfo.targetSdkVersion < Build.VERSION.MIN_SUPPORTED_TARGET_SDK_INT) {
            mUiHandler.showDeprecatedTargetDialog(r);
        }
    }

```

在这里showDeprecatedTargetDialogIfNeeded判断app的sdk版本



```
/**
     * Handles messages on the system process UI thread.
     */
    private final class UiHandler extends Handler {
        private static final int MSG_SHOW_UNSUPPORTED_DISPLAY_SIZE_DIALOG = 1;
        private static final int MSG_HIDE_UNSUPPORTED_DISPLAY_SIZE_DIALOG = 2;
        private static final int MSG_SHOW_UNSUPPORTED_COMPILE_SDK_DIALOG = 3;
        private static final int MSG_HIDE_DIALOGS_FOR_PACKAGE = 4;
        private static final int MSG_SHOW_DEPRECATED_TARGET_SDK_DIALOG = 5;

        public UiHandler(Looper looper) {
            super(looper, null, true);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SHOW_UNSUPPORTED_DISPLAY_SIZE_DIALOG: {
                    final ActivityRecord ar = (ActivityRecord) msg.obj;
                    showUnsupportedDisplaySizeDialogUiThread(ar);
                } break;
                case MSG_HIDE_UNSUPPORTED_DISPLAY_SIZE_DIALOG: {
                    hideUnsupportedDisplaySizeDialogUiThread();
                } break;
                case MSG_SHOW_UNSUPPORTED_COMPILE_SDK_DIALOG: {
                    final ActivityRecord ar = (ActivityRecord) msg.obj;
                    showUnsupportedCompileSdkDialogUiThread(ar);
                } break;
                case MSG_HIDE_DIALOGS_FOR_PACKAGE: {
                    final String name = (String) msg.obj;
                    hideDialogsForPackageUiThread(name);
                } break;
                case MSG_SHOW_DEPRECATED_TARGET_SDK_DIALOG: {
                    final ActivityRecord ar = (ActivityRecord) msg.obj;
                    showDeprecatedTargetSdkDialogUiThread(ar);
                } break;
            }
        }

```

UiHandler 中接收各种hanlder信息然后调用各自的方法



```
        public void showUnsupportedDisplaySizeDialog(ActivityRecord r) {
            removeMessages(MSG_SHOW_UNSUPPORTED_DISPLAY_SIZE_DIALOG);
            obtainMessage(MSG_SHOW_UNSUPPORTED_DISPLAY_SIZE_DIALOG, r).sendToTarget();
        }

        public void hideUnsupportedDisplaySizeDialog() {
            removeMessages(MSG_HIDE_UNSUPPORTED_DISPLAY_SIZE_DIALOG);
            sendEmptyMessage(MSG_HIDE_UNSUPPORTED_DISPLAY_SIZE_DIALOG);
        }

        public void showUnsupportedCompileSdkDialog(ActivityRecord r) {
            removeMessages(MSG_SHOW_UNSUPPORTED_COMPILE_SDK_DIALOG);
            obtainMessage(MSG_SHOW_UNSUPPORTED_COMPILE_SDK_DIALOG, r).sendToTarget();
        }

        public void showDeprecatedTargetDialog(ActivityRecord r) {
            removeMessages(MSG_SHOW_DEPRECATED_TARGET_SDK_DIALOG);
            obtainMessage(MSG_SHOW_DEPRECATED_TARGET_SDK_DIALOG, r).sendToTarget();
        }

        public void hideDialogsForPackage(String name) {
            obtainMessage(MSG_HIDE_DIALOGS_FOR_PACKAGE, name).sendToTarget();
        }
    }

    /**  
     * Shows the "deprecated target sdk version" warning for the given application.
     * <p>
     * <strong>Note:</strong> Must be called on the UI thread.
     *
     * @param ar record for the activity that triggered the warning
     */
    @UiThread
    private void showDeprecatedTargetSdkDialogUiThread(ActivityRecord ar) {
        if (mDeprecatedTargetSdkVersionDialog != null) {
            mDeprecatedTargetSdkVersionDialog.dismiss();
            mDeprecatedTargetSdkVersionDialog = null;
        }
        if (ar != null && !hasPackageFlag(
                ar.packageName, FLAG_HIDE_DEPRECATED_SDK)) {
            mDeprecatedTargetSdkVersionDialog = new DeprecatedTargetSdkVersionDialog(
                    AppWarnings.this, mUiContext, ar.info.applicationInfo);
            mDeprecatedTargetSdkVersionDialog.show();
        }
    }

```

在上述的AppWarnings.java中在启动activity时调用onStartActivity(ActivityRecord r)进行检测app，然后又调用showDeprecatedTargetDialogIfNeeded(ActivityRecord r) 检测app的版本，如果版本过低最后调用showDeprecatedTargetSdkDialogUiThread(ActivityRecord ar)来弹窗提示当前版本过低


解决方案：



```
--- a/frameworks/base/services/core/java/com/android/server/wm/AppWarnings.java
+++ b/frameworks/base/services/core/java/com/android/server/wm/AppWarnings.java
@@ -287,7 +287,7 @@ class AppWarnings {


     /**
     * Called when an activity is being started.
     *
     * @param r record for the activity being started
     */
    public void onStartActivity(ActivityRecord r) {
        showUnsupportedCompileSdkDialogIfNeeded(r);
        showUnsupportedDisplaySizeDialogIfNeeded(r);

      
- showDeprecatedTargetDialogIfNeeded(r);
 +        
 //showDeprecatedTargetDialogIfNeeded(r);

    }

```

所以说在AppWarnings.java启动Activity时开始检测的时候去掉检测app版本的showDeprecatedTargetDialogIfNeeded®方法调用就可以了





