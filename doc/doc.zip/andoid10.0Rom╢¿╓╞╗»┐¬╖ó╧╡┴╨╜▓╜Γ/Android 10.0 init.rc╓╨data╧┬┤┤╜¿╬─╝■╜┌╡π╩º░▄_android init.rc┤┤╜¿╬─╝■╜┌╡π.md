






在定制化开发中，由于系统给的文件节点不能满足需要，所以就要自己添加文件夹和节点，而系统启动过程中，大多数节点都是在init.rc中创建的  
 所以就在这里添加节点就可以了  
 接下来看下 system/core/init/init.cpp源码



```
static void LoadBootScripts(ActionManager& action_manager, ServiceList& service_list) {
    Parser parser = CreateParser(action_manager, service_list);

    std::string bootscript = GetProperty("ro.boot.init\_rc", "");
    if (bootscript.empty()) {
	std::string bootmode = GetProperty("ro.bootmode", "");
	if (bootmode == "charger") {
		parser.ParseConfig("/vendor/etc/init/charge.rc");
	} else {
        	parser.ParseConfig("/init.rc");
        	if (!parser.ParseConfig("/system/etc/init")) {
            		late_import_paths.emplace_back("/system/etc/init");
        	}
        	if (!parser.ParseConfig("/product/etc/init")) {
            		late_import_paths.emplace_back("/product/etc/init");
        	}
        	if (!parser.ParseConfig("/product\_services/etc/init")) {
            		late_import_paths.emplace_back("/product\_services/etc/init");
        	}
        	if (!parser.ParseConfig("/odm/etc/init")) {
            		late_import_paths.emplace_back("/odm/etc/init");
        	}
        	if (!parser.ParseConfig("/vendor/etc/init")) {
            		late_import_paths.emplace_back("/vendor/etc/init");
        	}
	}
    } else {
        parser.ParseConfig(bootscript);
    }
}

```

在开机的时候 会解析init.rc 来创建节点和文件夹


所以在init.rc中



```
on early-boot
mkdir /data/custom 0755 root root

```

在10.0之前的都正常使用 但是在10.0就不行了  
 于是查阅相关资料，发现action=post-fs-data 才开始创建data下的文件夹和节点  
 修改成以下的命令，就对了。



```
on post-fs-data
mkdir /data/custom 0755 root root

```

具体原因，是因为google在这方面做了以下修改。  
 https://source.android.com/security/encryption/



```
vold then mounts the decrypted real /data partition and then prepares the new partition.
It sets the property vold.post_fs_data_done to 0 and then sets vold.decrypt to trigger_post_fs_data.
This causes init.rc to run its post-fs-data commands.
They will create any necessary directories or links and then set vold.post_fs_data_done to 1.

```

所以想在/data/目录下创建文件夹的话，要在on post-fs-data的时候进行。  
 下面是init.rc执行的顺序。



```
on early-init
on init
on early-fs
on fs
on post-fs
on post-fs-data
on early-boot
on boot

```

复制内容到文件夹内，增加如下内容：



```
copy /system/etc/xxx/xxx.txt /data/xxx/xxx.txt  

```




