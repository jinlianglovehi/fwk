






### 1.概述


在10.0的系统产品开发中，在一些产品中，有些产品中，需要导航栏左边显示，这就需要修改导航栏的显示方向，然后就可以靠左边显示，实现导航栏左边显示的功能


### 2.NavigationBarView 导航栏 左边显示的修改的核心类



```
frameworks/base/services/core/java/com/android/server/wm/DisplayPolicy.java
packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java

```

### 3.NavigationBarView 导航栏 左边显示的修改的核心功能分析和实现


### 3.1 DisplayPolicy 导航栏显示方向的控制


在系统中关于对系统导航栏方向的控制，也是在DisplayPolicy.java中处理的，接下来看下DisplayPolicy.java的相关导航栏的源码



```
     private boolean layoutNavigationBar(DisplayFrames displayFrames, int uiMode, boolean navVisible,
              boolean navTranslucent, boolean navAllowedHidden,
              boolean statusBarForcesShowingNavigation) {
          if (mNavigationBar == null) {
              return false;
          }
  
          final Rect navigationFrame = sTmpNavFrame;
          boolean transientNavBarShowing = mNavigationBarController.isTransientShowing();
          // Force the navigation bar to its appropriate place and size. We need to do this directly,
          // instead of relying on it to bubble up from the nav bar, because this needs to change
          // atomically with screen rotations.
          final int rotation = displayFrames.mRotation;
          final int displayHeight = displayFrames.mDisplayHeight;
          final int displayWidth = displayFrames.mDisplayWidth;
          final Rect dockFrame = displayFrames.mDock;
          mNavigationBarPosition = navigationBarPosition(displayWidth, displayHeight, rotation);
  
          final Rect cutoutSafeUnrestricted = sTmpRect;
          cutoutSafeUnrestricted.set(displayFrames.mUnrestricted);
          cutoutSafeUnrestricted.intersectUnchecked(displayFrames.mDisplayCutoutSafe);
  
          if (mNavigationBarPosition == NAV_BAR_BOTTOM) {
              // It's a system nav bar or a portrait screen; nav bar goes on bottom.
              final int top = cutoutSafeUnrestricted.bottom
                      - getNavigationBarHeight(rotation, uiMode);
              final int topNavBar = cutoutSafeUnrestricted.bottom
                      - getNavigationBarFrameHeight(rotation, uiMode);
              navigationFrame.set(0, topNavBar, displayWidth, displayFrames.mUnrestricted.bottom);
              displayFrames.mStable.bottom = displayFrames.mStableFullscreen.bottom = top;
              if (transientNavBarShowing) {
                  mNavigationBarController.setBarShowingLw(true);
              } else if (navVisible) {
                  mNavigationBarController.setBarShowingLw(true);
                  dockFrame.bottom = displayFrames.mRestricted.bottom =
                          displayFrames.mRestrictedOverscan.bottom = top;
              } else {
                  // We currently want to hide the navigation UI - unless we expanded the status bar.
                  mNavigationBarController.setBarShowingLw(statusBarForcesShowingNavigation);
              }
              if (navVisible && !navTranslucent && !navAllowedHidden
                      && !mNavigationBar.isAnimatingLw()
                      && !mNavigationBarController.wasRecentlyTranslucent()) {
                  // If the opaque nav bar is currently requested to be visible and not in the process
                  // of animating on or off, then we can tell the app that it is covered by it.
                  displayFrames.mSystem.bottom = top;
              }
          } else if (mNavigationBarPosition == NAV_BAR_RIGHT) {
              // Landscape screen; nav bar goes to the right.
              final int left = cutoutSafeUnrestricted.right
                      - getNavigationBarWidth(rotation, uiMode);
              navigationFrame.set(left, 0, displayFrames.mUnrestricted.right, displayHeight);
              displayFrames.mStable.right = displayFrames.mStableFullscreen.right = left;
              if (transientNavBarShowing) {
                  mNavigationBarController.setBarShowingLw(true);
              } else if (navVisible) {
                  mNavigationBarController.setBarShowingLw(true);
                  dockFrame.right = displayFrames.mRestricted.right =
                          displayFrames.mRestrictedOverscan.right = left;
              } else {
                  // We currently want to hide the navigation UI - unless we expanded the status bar.
                  mNavigationBarController.setBarShowingLw(statusBarForcesShowingNavigation);
              }
              if (navVisible && !navTranslucent && !navAllowedHidden
                      && !mNavigationBar.isAnimatingLw()
                      && !mNavigationBarController.wasRecentlyTranslucent()) {
                  // If the nav bar is currently requested to be visible, and not in the process of
                  // animating on or off, then we can tell the app that it is covered by it.
                  displayFrames.mSystem.right = left;
              }
          } 
....
          mNavigationBarController.setContentFrame(mNavigationBar.getContentFrameLw());
  
          if (DEBUG_LAYOUT) Slog.i(TAG, "mNavigationBar frame: " + navigationFrame);
          return mNavigationBarController.checkHiddenLw();
      }

```

DisplayPolicy中的layoutNavigationBar（）关于导航栏的布局中，在mNavigationBarPosition = navigationBarPosition(displayWidth, displayHeight, rotation);这个关于导航栏布局最终是调用的是navigationBarPosition(displayWidth, displayHeight, rotation)来确定导航栏方向的，接下来看下这个方法的相关源码如下:



```
  @NavigationBarPosition
      int navigationBarPosition(int displayWidth, int displayHeight, int displayRotation) {
          if (navigationBarCanMove() && displayWidth > displayHeight) {
              if (displayRotation == Surface.ROTATION_270) {
                  return NAV_BAR_LEFT;
              } else if (displayRotation == Surface.ROTATION_90) {
                  return NAV_BAR_RIGHT;
              }
          }
          return NAV_BAR_BOTTOM;
      }

```

在从上文的DisplayPolicy.java的layoutNavigationBar（）中在布局导航栏的时候，调用来navigationBarPosition(）在此方法中，布局导航栏的位置，所以可以在这里根据屏幕的方向设置导航栏的旋转方向  
 所以具体修改为:



```
--- a/services/core/java/com/android/server/wm/DisplayPolicy.java
+++ b/services/core/java/com/android/server/wm/DisplayPolicy.java
@@ -3015,7 +3015,7 @@ public class DisplayPolicy {
     @NavigationBarPosition
     int navigationBarPosition(int displayWidth, int displayHeight, int displayRotation) {
         if (navigationBarCanMove() && displayWidth > displayHeight) {
-            if (displayRotation == Surface.ROTATION_270) {
+            if (displayRotation == Surface.ROTATION_270 || displayRotation == Surface.ROTATION_0) {
                 return NAV_BAR_LEFT;
             } else if (displayRotation == Surface.ROTATION_90) {
                 return NAV_BAR_RIGHT;

```

在navigationBarPosition方法中，增加Surface.ROTATION\_0方向时导航栏左边显示的设置，这样就可以让导航栏在左边显示，完成功能


### 3.2 NavigationBarView 使用竖屏布局的UI



```
diff --git a/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java b/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java
old mode 100644
new mode 100755
index 421a58f..16e9c9f
--- a/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java
+++ b/packages/SystemUI/src/com/android/systemui/statusbar/phone/NavigationBarView.java
@@ -266,7 +266,7 @@ public class NavigationBarView extends FrameLayout implements
     public NavigationBarView(Context context, AttributeSet attrs) {
 
-        mIsVertical = false;
+        mIsVertical = true;
         mLongClickableAccessibilityButton = false;
         mNavBarMode = Dependency.get(NavigationModeController.class).addListener(this);

```

在NavigationBarView构造方法中，对于是否用竖屏到导航栏布局，默认为false，所以想要使用竖屏布局就得修改为true就可以了





