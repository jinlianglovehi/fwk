



## 1.概述


在10.0的系统产品开发rom定制中，在Launcher3的开发中，在Launcher3的folder文件夹中， 在进入文件夹由于背景是白色的，不是很美观，所以要求去掉白色背景，要求背景换成透明的  
 所以需要从folder文件夹流程中，找到相关的背景设置的地方，去掉相关背景的功能就可以了


## 2.Launcher3 folder文件夹去掉背景功能实现的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\folder\FolderAnimationManager.java
```

## 3.Launcher3 folder文件夹去掉背景功能实现的核心功能分析和实现


在系统启动完毕后，在启动Launcher3的时候，在Launcher3进入文件夹后，主要由FolderAnimationManager.java来负责管理背景这块，所以需要在FolderAnimationManager.java中看是如何  
 对背景进行管理绘制的，然后去掉背景相关的代码  
 文件夹缩率图背景和展开文件夹背景根据系统值或者主题设置成纯色的，不美观，根据  
 需要可修改被壁纸默认的背景，比较美观大方，修改点如下：  
 FolderAnimationManager.java 类的getAnimator方法中屏蔽背景的设置，变量  
 mFolderBackground设置背景，接下来看下FolderAnimationManager.java的  
 相关源码



```
   public class FolderAnimationManager {
     
        private static final int FOLDER_NAME_ALPHA_DURATION = 32;
     
        private Folder mFolder;
        private FolderPagedView mContent;
        private GradientDrawable mFolderBackground;
     
        private FolderIcon mFolderIcon;
        private PreviewBackground mPreviewBackground;
     
        private Context mContext;
        private Launcher mLauncher;
     
        private final boolean mIsOpening;
     
        private final int mDuration;
        private final int mDelay;
     
        private final TimeInterpolator mFolderInterpolator;
        private final TimeInterpolator mLargeFolderPreviewItemOpenInterpolator;
        private final TimeInterpolator mLargeFolderPreviewItemCloseInterpolator;
     
        private final PreviewItemDrawingParams mTmpParams = new PreviewItemDrawingParams(0, 0, 0, 0);
        private final FolderGridOrganizer mPreviewVerifier;
     
        public FolderAnimationManager(Folder folder, boolean isOpening) {
            mFolder = folder;
            mContent = folder.mContent;
            //mFolderBackground = (GradientDrawable) mFolder.getBackground();
     
            mFolderIcon = folder.mFolderIcon;
            mPreviewBackground = mFolderIcon.mBackground;
     
            mContext = folder.getContext();
            mLauncher = folder.mLauncher;
            mPreviewVerifier = new FolderGridOrganizer(mLauncher.getDeviceProfile().inv);
     
            mIsOpening = isOpening;
     
            Resources res = mContent.getResources();
            mDuration = res.getInteger(R.integer.config_materialFolderExpandDuration);
            mDelay = res.getInteger(R.integer.config_folderDelay);
     
            mFolderInterpolator = AnimationUtils.loadInterpolator(mContext,
                    R.interpolator.folder_interpolator);
            mLargeFolderPreviewItemOpenInterpolator = AnimationUtils.loadInterpolator(mContext,
                    R.interpolator.large_folder_preview_item_open_interpolator);
            mLargeFolderPreviewItemCloseInterpolator = AnimationUtils.loadInterpolator(mContext,
                    R.interpolator.large_folder_preview_item_close_interpolator);
        }
```

在上述的代码中可以看到，在FolderAnimationManager.java中，可以看到变量 private GradientDrawable mFolderBackground;就是背景图片，而在FolderAnimationManager(Folder folder, boolean isOpening)构造方法中，通过该//mFolderBackground = (GradientDrawable) mFolder.getBackground();进行背景变量赋值，  
 所以可以在构造方法中，注释掉这行代码



```
       public AnimatorSet getAnimator() {
            final DragLayer.LayoutParams lp = (DragLayer.LayoutParams) mFolder.getLayoutParams();
            mFolderIcon.getPreviewItemManager().recomputePreviewDrawingParams();
            ClippedFolderIconLayoutRule rule = mFolderIcon.getLayoutRule();
            final List<BubbleTextView> itemsInPreview = getPreviewIconsOnPage(0);
     
            // Match position of the FolderIcon
            final Rect folderIconPos = new Rect();
            float scaleRelativeToDragLayer = mLauncher.getDragLayer()
                    .getDescendantRectRelativeToSelf(mFolderIcon, folderIconPos);
            int scaledRadius = mPreviewBackground.getScaledRadius();
            float initialSize = (scaledRadius * 2) * scaleRelativeToDragLayer;
     
            // Match size/scale of icons in the preview
            float previewScale = rule.scaleForItem(itemsInPreview.size());
            float previewSize = rule.getIconSize() * previewScale;
            float initialScale = previewSize / itemsInPreview.get(0).getIconSize()
                    * scaleRelativeToDragLayer;
            final float finalScale = 1f;
            float scale = mIsOpening ? initialScale : finalScale;
            mFolder.setPivotX(0);
            mFolder.setPivotY(0);
     
            // Scale the contents of the folder.
            mFolder.mContent.setScaleX(scale);
            mFolder.mContent.setScaleY(scale);
            mFolder.mContent.setPivotX(0);
            mFolder.mContent.setPivotY(0);
            mFolder.mFooter.setScaleX(scale);
            mFolder.mFooter.setScaleY(scale);
            mFolder.mFooter.setPivotX(0);
            mFolder.mFooter.setPivotY(0);
     
            // We want to create a small X offset for the preview items, so that they follow their
            // expected path to their final locations. ie. an icon should not move right, if it's final
            // location is to its left. This value is arbitrarily defined.
            int previewItemOffsetX = (int) (previewSize / 2);
            if (Utilities.isRtl(mContext.getResources())) {
                previewItemOffsetX = (int) (lp.width * initialScale - initialSize - previewItemOffsetX);
            }
            final int paddingOffsetX = (int) (mContent.getPaddingLeft() * initialScale);
            final int paddingOffsetY = (int) (mContent.getPaddingTop() * initialScale);
            int initialX = folderIconPos.left + mFolder.getPaddingLeft()
                    + mPreviewBackground.getOffsetX() - paddingOffsetX - previewItemOffsetX;
            int initialY = folderIconPos.top + mFolder.getPaddingTop()
                    + mPreviewBackground.getOffsetY() - paddingOffsetY;
            final float xDistance = initialX - lp.x;
            final float yDistance = initialY - lp.y;
            // Set up the Folder background.
            final int finalColor = ColorUtils.setAlphaComponent(
                    Themes.getAttrColor(mContext, R.attr.folderFillColor), 255);
            final int initialColor = setColorAlphaBound(
                    finalColor, mPreviewBackground.getBackgroundAlpha());
            //mFolderBackground.mutate();
            //mFolderBackground.setColor(mIsOpening ? initialColor : finalColor);
```

在上述的代码中，可以看到在FolderAnimationManager.java中在getAnimator() 中的代码中，在


//mFolderBackground.mutate();


//mFolderBackground.setColor(mIsOpening ? initialColor : finalColor);


中就是对文件夹背景的设置颜色的核心代码，由于背景变量注释掉了所以这里也需要注释掉



```
            // Set up the reveal animation that clips the Folder.
            int totalOffsetX = paddingOffsetX + previewItemOffsetX;
            Rect startRect = new Rect(totalOffsetX,
                    paddingOffsetY,
                    Math.round((totalOffsetX + initialSize)),
                    Math.round((paddingOffsetY + initialSize)));
            Rect endRect = new Rect(0, 0, lp.width, lp.height);
            float finalRadius = ResourceUtils.pxFromDp(2, mContext.getResources().getDisplayMetrics());
     
            // Create the animators.
            AnimatorSet a = new AnimatorSet();
     
            // Initialize the Folder items' text.
            PropertyResetListener colorResetListener =
                    new PropertyResetListener<>(TEXT_ALPHA_PROPERTY, 1f);
            for (BubbleTextView icon : mFolder.getItemsOnPage(mFolder.mContent.getCurrentPage())) {
                if (mIsOpening) {
                    icon.setTextVisibility(false);
                }
                ObjectAnimator anim = icon.createTextAlphaAnimator(mIsOpening);
                anim.addListener(colorResetListener);
                play(a, anim);
            }
            play(a, getAnimator(mFolder, View.TRANSLATION_X, xDistance, 0f));
            play(a, getAnimator(mFolder, View.TRANSLATION_Y, yDistance, 0f));
            play(a, getAnimator(mFolder.mContent, SCALE_PROPERTY, initialScale, finalScale));
            play(a, getAnimator(mFolder.mFooter, SCALE_PROPERTY, initialScale, finalScale));
            //play(a, getAnimator(mFolderBackground, "color", initialColor, finalColor));
            play(a, mFolderIcon.mFolderName.createTextAlphaAnimator(!mIsOpening));
            play(a, getShape().createRevealAnimator(
                    mFolder, startRect, endRect, finalRadius, !mIsOpening));
            // Fade in the folder name, as the text can overlap the icons when grid size is small.
            mFolder.mFolderName.setAlpha(mIsOpening ? 0f : 1f);
            play(a, getAnimator(mFolder.mFolderName, View.ALPHA, 0, 1),
                    mIsOpening ? FOLDER_NAME_ALPHA_DURATION : 0,
                    mIsOpening ? mDuration - FOLDER_NAME_ALPHA_DURATION : FOLDER_NAME_ALPHA_DURATION);
            // Translate the footer so that it tracks the bottom of the content.
            float normalHeight = mFolder.getContentAreaHeight();
            float scaledHeight = normalHeight * initialScale;
            float diff = normalHeight - scaledHeight;
            play(a, getAnimator(mFolder.mFooter, View.TRANSLATION_Y, -diff, 0f));
            // Animate the elevation midway so that the shadow is not noticeable in the background.
            int midDuration = mDuration / 2;
            Animator z = getAnimator(mFolder, View.TRANSLATION_Z, -mFolder.getElevation(), 0);
            play(a, z, mIsOpening ? midDuration : 0, midDuration);
            // Store clip variables

....
            return a;
        }
```

在上述的代码中，可以看到在FolderAnimationManager.java中在getAnimator() 中的代码中，在  
 //play(a, getAnimator(mFolderBackground, "color", initialColor, finalColor));  
 中就是对mFolderBackground背景进行初始化颜色的，背景颜色已经被注释掉了，所以这里  
 也会需要注释掉。通过对上述的几处的重点修改,就可以实现在Launcher3中的默认文件夹布局的  
 默认背景的修改，



