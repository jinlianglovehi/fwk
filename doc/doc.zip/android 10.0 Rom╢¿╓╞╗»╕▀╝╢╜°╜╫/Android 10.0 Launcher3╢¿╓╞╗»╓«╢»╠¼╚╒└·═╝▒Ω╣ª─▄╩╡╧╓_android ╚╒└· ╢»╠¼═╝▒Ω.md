



## 1.概述


 在10.0的系统产品rom开发中，在Launcher3中的相关定制化功能中，对于一些产品要求需要动态日历图标功能，在日期改变的时候，日历图标也需要跟着改变  
 所以需要自定义日历图标，监听日历改变的广播，收到日期改变的广播后，刷新日历图标，接下来就来分析关于动态日历图标更新这个功能的实现


![](https://img-blog.csdnimg.cn/a1f5fd1bd1734c46a91a5100a40550f2.png)


## 2.Launcher3定制化之动态日历图标功能实现的核心类



```
packages\apps\Launcher3\src\com\android\launcher3\BubbleTextView.java
```

## 3.Launcher3定制化之动态日历图标功能实现的核心功能分析和实现


在系统app开发中，对于自定义view的开发中，在自定义控件类中，可继承View，同样也可以继承Drawable,来实现一个图标绘制背景功能，就可以直接作为  
 某个图标的背景了，而  
 Drawable在我们平时的开发中，基本都会用到，而且对于大家来说也是很实用的。那么什么是Drawable呢？能够在canvas上绘制的一个玩意，而且相比于View，  
 并不需要去考虑measure、layout，仅仅只要去考虑如何draw（canavs）自定义Drawable，是通过继承drawable子类，重写draw(Canvas canvas)方法，  
 实现稍复杂的drawable来实现功能的


## 3.1 自定义添加动态日历Drawable类


Drawable 是一个可以调用 Canvas 来进行绘制的上层工具。调用 Drawable.draw(Canvas) 可以把 Drawable 设置的绘制内容绘制到 Canvas  
 中。Drawable 内部存储的是绘制规则，这个规则可以是一个具体的 Bitmap，也可以是 一个纯粹的颜色，甚至可以是一个抽象的、灵活的描述。Drawable 可以不含有具体 的像素信息，只要它含有的信息足以在 draw(Canvas) 方法被调用时进行绘制就 够了。  
 由于 Drawable 存储的只是绘制规则，因此在它的 draw() 方法被调用前，需要先  
 调用 Drawable.setBounds() 来为它设置绘制边界  
 接下来就通过自定义Drawable控件，来继承Drawable,重点实现  
 drawable()方法来绘制图标，通过上述的分析，接下来就可以自定义一个类  
 CustomCalendarDrawable.java类，主要是实现onDraw()方法，在这里实现  
 绘制动态日历图标的功能，具体实现如下



```
      package com.android.launcher3;
     
    import android.content.BroadcastReceiver;
    import android.content.Context;
    import android.content.Intent;
    import android.content.IntentFilter;
    import android.graphics.Bitmap;
    import android.graphics.BitmapFactory;
    import android.graphics.Canvas;
    import android.graphics.Color;
    import android.graphics.ColorFilter;
    import android.graphics.Paint;
    import android.graphics.PixelFormat;
    import android.graphics.Rect;
    import android.graphics.RectF;
    import android.graphics.Typeface;
    import android.graphics.drawable.Drawable;
    import androidx.annotation.NonNull;
    import androidx.annotation.Nullable;
    import com.android.launcher3.R;
    import java.util.Calendar;
     
    public class CustomCalendarDrawable extends Drawable {
        private Context mContext;
        public CustomCalendarDrawable(Context context){
            this.mContext = context;
            mContext.registerReceiver(mCalendarBroadCast,new IntentFilter(Intent.ACTION_DATE_CHANGED));
        }
        BroadcastReceiver mCalendarBroadCast = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if(action.equals(Intent.ACTION_DATE_CHANGED)){
                    invalidateSelf();
                }
            }
        };
        private Bitmap getBitmap(Context context, int res) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_4444;
            return BitmapFactory.decodeResource(context.getResources(), res, options);
        }

```

  
 在上述的代码中，在自定义的CustomCalendarDrawable中，首选在CustomCalendarDrawable(Context context)的构造方法中  
 注册监听日期改变的广播，然后刷新Drawable，在draw(@NonNull Canvas canvas)绘制日历图标，



```
        @Override
        public void draw(@NonNull Canvas canvas) {
            Bitmap calendarIcon = getBitmap(mContext, R.drawable.corner_white);
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            canvas.drawBitmap(calendarIcon, 0, 0, paint);
            String dayString = String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
            int dayOfWeek = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
            String weekStrings[] = {"星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
            String weekString = weekStrings[dayOfWeek-1];
            float mDensity = mContext.getResources().getDisplayMetrics().density;
            Paint _debugInfoPaint = new Paint(Paint.ANTI_ALIAS_FLAG); //设置无锯齿 也可以使用setAntiAlias(true)
            _debugInfoPaint.setColor(Color.parseColor("#FE2746"));//设置画笔颜色
            _debugInfoPaint.setStrokeWidth(1.5f);//设置线宽
            _debugInfoPaint.setStyle(Paint.Style.FILL);//设置样式：FILL表示颜色填充整个；STROKE表示空心
            canvas.drawRoundRect(new RectF(0, 0, 112, 35), 15, 15, _debugInfoPaint);
            canvas.drawRect(new Rect(0,20,112,35),_debugInfoPaint);
            int icon_width = calendarIcon.getWidth();
            int icon_height = calendarIcon.getHeight();
            Paint mWeekPaint = new Paint();
            mWeekPaint.setTypeface(Typeface.DEFAULT_BOLD);
            mWeekPaint.setTextSize((int) 14F * mDensity);
            mWeekPaint.setColor(Color.WHITE);
            mWeekPaint.setAntiAlias(true);
            Rect rect_week = new Rect();
            mWeekPaint.getTextBounds(weekString, 0, weekString.length(), rect_week);
            int week_width = rect_week.right - rect_week.left;
            int week_height = rect_week.bottom - rect_week.top;
            canvas.drawText(weekString, (icon_width - week_width) / 2 - rect_week.left, week_height+5, mWeekPaint);
            Paint mDatePaint = new Paint();
            mDatePaint.setTypeface(Typeface.DEFAULT_BOLD);
            mDatePaint.setTextSize((int) 35F * mDensity);
            mDatePaint.setColor(Color.BLACK);
            mDatePaint.setAntiAlias(true);
            Rect rect = new Rect();
            mDatePaint.getTextBounds(dayString, 0, dayString.length(), rect);
            int day_width = rect.right - rect.left;
            int day_height = rect.bottom - rect.top;
            canvas.drawText(dayString, (icon_width - day_width) / 2 - rect.left,(icon_height - day_height+35) / 2 - rect.top , mDatePaint);
        }
     
        @Override
        public int getOpacity() {
            return PixelFormat.UNKNOWN;
        }
     
        @Override
        public void unscheduleSelf(@NonNull Runnable what) {
            super.unscheduleSelf(what);
            mContext.unregisterReceiver(mCalendarBroadCast);
        }
    }

```

通过上述代码的分析，发现在自定义的CustomCalendarDrawable中，主要是draw(@NonNull Canvas canvas) 中通过canvas.drawBitmap  
 首选绘制一张背景，然后在绘制当前的星期几，最后绘制当前日期，计算宽高以后，在通过canvas.drawText 根据坐标还有字体的大小来做绘制文字  
 从而来实现功能，来绘制一张可以动态改变的Drawable,接下来看下如何替换掉系统自带的日历图标，  
 这样就可以在Launcher3的桌面中看到一个动态的日历图标了，


## 3.2 BubbleTextView.java中替换掉日历原有的图标



```
    public void applyFromWorkspaceItem(WorkspaceItemInfo info, boolean promiseStateChanged) {
            applyIconAndLabel(info);
            setTag(info);
            if (promiseStateChanged || (info.hasPromiseIconUi())) {
                applyPromiseState(promiseStateChanged);
            }
     
            applyDotState(info, false /* animate */);
        }
     
        public void applyFromApplicationInfo(AppInfo info) {
            applyIconAndLabel(info);
     
            // We don't need to check the info since it's not a WorkspaceItemInfo
            super.setTag(info);
     
            // Verify high res immediately
            verifyHighRes();
     
            if (info instanceof PromiseAppInfo) {
                PromiseAppInfo promiseAppInfo = (PromiseAppInfo) info;
                applyProgressLevel(promiseAppInfo.level);
            }
            applyDotState(info, false /* animate */);
        }
     
        public void applyFromPackageItemInfo(PackageItemInfo info) {
            applyIconAndLabel(info);
            // We don't need to check the info since it's not a WorkspaceItemInfo
            super.setTag(info);
     
            // Verify high res immediately
            verifyHighRes();
        }
     
        private void applyIconAndLabel(ItemInfoWithIcon info) {
            String pkgname = "";
            if (info.getIntent() != null && info.getIntent().getComponent() != null) {
                pkgname = info.getIntent().getComponent().getPackageName();
            }
            //android.util.Log.e("Launcher3","pkgname:"+pkgname);
     
    //add core start
            FastBitmapDrawable iconDrawable = null;
            if( if(pkgname.equals("com.android.calendar")){
    	CustomCalendarDrawable calendarDrawable = new CustomCalendarDrawable(getContext());
    	if(calendarDrawable!=null)setIcon(calendarDrawable);
            }else{
                iconDrawable = newIcon(getContext(), info);
            }
    //add core end
     
     
            //FastBitmapDrawable iconDrawable = newIcon(getContext(), info);
            mDotParams.color = IconPalette.getMutedColor(info.bitmap.color, 0.54f);
     
            if(iconDrawable!=null)setIcon(iconDrawable);
            setText(info.title);
            if (info.contentDescription != null) {
                setContentDescription(info.isDisabled()
                        ? getContext().getString(R.string.disabled_app_label, info.contentDescription)
                        : info.contentDescription);
            }
        }
```

在上述的代码中可以看到，在BubbleTextView.java的相关代码中，在applyFromWorkspaceItem(WorkspaceItemInfo info, boolean promiseStateChanged)  
 和applyFromApplicationInfo(AppInfo info) ,applyFromPackageItemInfo(PackageItemInfo info),applyIconAndLabel(ItemInfoWithIcon info)  
 这几个方法都是添加各种不同类型图标的，而最后的app图标都是在applyIconAndLabel(ItemInfoWithIcon info)中添加的  
 所以在这个可以根据包名来替换掉原来的系统日历图标，调用CustomCalendarDrawable 然后setIcon(calendarDrawable);  
 就替换了动态日历的图标，从而实现了功能



