



## 1.前言


  
  在10.0的系统开发中，在对于第三方app全屏显示的功能需求开发中，需要默认app全屏显示，针对这一个要求，就需要在系统启动app  
 的过程中，在绘制app阶段就设置全屏属性，接下来就实现这个功能  
 效果图如下:


![](https://img-blog.csdnimg.cn/4d6b7cf032474f2cb9d56533f7b63394.png)


## 2.framework层实现app默认全屏显示的核心类



```
frameworks\base\core\java\android\app\ActivityThread.java
```

## 3.framework层实现app默认全屏显示的核心功能分析和实现


在Android系统启动的过程中，系统中第一个启动起来的进程就是zygote进程，然后由zygote负责启动SystemServer，然后就是启动  
 ActivityManagerService、WindowManagerService等系统核心服务引导服务以及其他服务等待，而这些服务承担着整个Android系统与客户端交互的重担。  
 zygote除了启动系统服务与进程外，普通的用户进程也由zygote进程fork而来，当一个应用进程启动起来后，  
 就会加载用户在AndroidManifest.xml中配置的默认加载带有Launcher属性的Activity，此时加载的入口是ActivityThread，  
 是整个应用程序的入口。接下来就来看下


ActivityThread在Android中代表Android的主线程，但是并不是一个Thread类。ActivityThread类是Android 进程的初始类，  
 它的main函数是这个App进程的入口。  
 当创建完新进程之后，main函数被加载，然后执行一个loop的循环使当前线程进入消息循环。


首先，我们看一下Activity的启动逻辑过程：Applicationthread的ScheduleActivity通过一个叫H的Handler  
 发送了一个启动Activity信息。handleLaunchActivity接收了这个消息，然后做处理，处理的逻辑是让PreformLaunchActivity处理，并最终执行Activity的启动。



```
    /**
     * Extended implementation of activity launch. Used when server requests a launch or relaunch.
     */
    @Override
    public Activity handleLaunchActivity(ActivityClientRecord r,
            PendingTransactionActions pendingActions, Intent customIntent) {
        // If we are getting ready to gc after going to the background, well
        // we are back active so skip it.
        unscheduleGcIdler();
        mSomeActivitiesChanged = true;
 
        if (r.profilerInfo != null) {
            mProfiler.setProfiler(r.profilerInfo);
            mProfiler.startProfiling();
        }
 
        // Make sure we are running with the most recent config.
        handleConfigurationChanged(null, null);
 
        if (localLOGV) Slog.v(
            TAG, "Handling launch of " + r);
 
        // Initialize before creating the activity
        if (!ThreadedRenderer.sRendererDisabled
                && (r.activityInfo.flags & ActivityInfo.FLAG_HARDWARE_ACCELERATED) != 0) {
            HardwareRenderer.preload();
        }
        WindowManagerGlobal.initialize();
 
        // Hint the GraphicsEnvironment that an activity is launching on the process.
        GraphicsEnvironment.hintActivityLaunch();
    //1.创建并且加载Activity，调用其onCreate函数。
        final Activity a = performLaunchActivity(r, customIntent);
 
        if (a != null) {
            r.createdConfig = new Configuration(mConfiguration);
            reportSizeConfigurations(r);
            if (!r.activity.mFinished && pendingActions != null) {
                pendingActions.setOldState(r.state);
                pendingActions.setRestoreInstanceState(true);
                pendingActions.setCallOnPostCreate(true);
            }
        } else {
            // If there was an error, for any reason, tell the activity manager to stop us.
            try {
                ActivityTaskManager.getService()
                        .finishActivity(r.token, Activity.RESULT_CANCELED, null,
                                Activity.DONT_FINISH_TASK_WITH_ACTIVITY);
            } catch (RemoteException ex) {
                throw ex.rethrowFromSystemServer();
            }
        }
 
        return a;
    }
```

在上述的ActivityThread.java的方法中，在ActivityThread.java在接收到需要启动Acitivivity的时候，会在ActivityThread的内部类H的handlMessage函数会处理该消息，然后会调用ActivityThread的  
 handleLaunchActivity(ActivityClientRecord r, Intent customIntent, String reason)函数，  
 在这个函数中会创建将要启动的Activity，并且调用其生命周期函数onCreate、onResume。



```
    @Override
    public void handleResumeActivity(IBinder token, boolean finalStateRequest, boolean isForward,
            String reason) {
        // If we are getting ready to gc after going to the background, well
        // we are back active so skip it.
        unscheduleGcIdler();
        mSomeActivitiesChanged = true;

        // TODO Push resumeArgs into the activity for consideration
        final ActivityClientRecord r = performResumeActivity(token, finalStateRequest, reason);
        if (r == null) {
            // We didn't actually resume the activity, so skipping any follow-up actions.
            return;
        }
        if (mActivitiesToBeDestroyed.containsKey(token)) {
            // Although the activity is resumed, it is going to be destroyed. So the following
            // UI operations are unnecessary and also prevents exception because its token may
            // be gone that window manager cannot recognize it. All necessary cleanup actions
            // performed below will be done while handling destruction.
            return;
        }

        final Activity a = r.activity;

        if (localLOGV) {
            Slog.v(TAG, "Resume " + r + " started activity: " + a.mStartedActivity
                    + ", hideForNow: " + r.hideForNow + ", finished: " + a.mFinished);
        }

        final int forwardBit = isForward
                ? WindowManager.LayoutParams.SOFT_INPUT_IS_FORWARD_NAVIGATION : 0;

        // If the window hasn't yet been added to the window manager,
        // and this guy didn't finish itself or start another activity,
        // then go ahead and add the window.
        boolean willBeVisible = !a.mStartedActivity;
        if (!willBeVisible) {
            try {
                willBeVisible = ActivityTaskManager.getService().willActivityBeVisible(
                        a.getActivityToken());
            } catch (RemoteException e) {
                throw e.rethrowFromSystemServer();
            }
        }
        if (r.window == null && !a.mFinished && willBeVisible) {
            r.window = r.activity.getWindow();
            View decor = r.window.getDecorView();
            decor.setVisibility(View.INVISIBLE);

//add core start
            //r.window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
            //       | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            r.window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            //r.window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            //r.window.setStatusBarColor(android.graphics.Color.TRANSPARENT);
            //r.window.setNavigationBarColor(android.graphics.Color.TRANSPARENT);

//add core end

            ViewManager wm = a.getWindowManager();
            WindowManager.LayoutParams l = r.window.getAttributes();
            a.mDecor = decor;
            l.type = WindowManager.LayoutParams.TYPE_BASE_APPLICATION;
            l.softInputMode |= forwardBit;
            if (r.mPreserveWindow) {
                // UNISOC: Bug711794, ensure that the decor view is attached to window.
                // if the remain decor view is not attached to window, we should make sure
                // that it will been attached in the following workflow.
                if(DecorView.isAddedToWindow(decor)) a.mWindowAdded = true;
                r.mPreserveWindow = false;
                // Normally the ViewRoot sets up callbacks with the Activity
                // in addView->ViewRootImpl#setView. If we are instead reusing
                // the decor view we have to notify the view root that the
                // callbacks may have changed.
                ViewRootImpl impl = decor.getViewRootImpl();
                if (impl != null) {
                    impl.notifyChildRebuilt();
                }
            }
       // Get rid of anything left hanging around.
        cleanUpPendingRemoveWindows(r, false /* force */);

....

    }
}
```

在上述的ActivityThread.java的相关源码中，在  
 handleReumeActivity函数又调用了performResumeActivty函数来回调Activity的onResume函数，并且DecorView  
 添加到WindowManager中，最后将Activity的DecorView设置为可见，并且通知ActivityManagerService渲染视图  
 ，因此，在onResume函数之后，Activity就显示在屏幕上了。  
 ActivityThread的main函数被调用之后，依次执行Activity的onCreate、onStart、onResume函数，用户通常在  
 Activity的子类中覆写onCreate方法，并且在其中调用setContentView方法来设置布局。从上文可以知道，  
 在onResume之后，Activity的布局内容就显示到窗口上了。  
 通过在 if (r.window == null && !a.mFinished && willBeVisible) 这里判断是初步构建activity的window窗口时，  
 来设置全屏模式来实现app里的页面全屏功能的实现




