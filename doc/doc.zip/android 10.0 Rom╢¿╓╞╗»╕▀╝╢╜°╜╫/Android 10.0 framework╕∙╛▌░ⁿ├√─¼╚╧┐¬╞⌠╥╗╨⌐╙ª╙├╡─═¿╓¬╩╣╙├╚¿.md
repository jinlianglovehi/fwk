



## 1.前言


在10.0的系统rom定制化开发中，在一些产品开发中，需要对某些app的通知权限授权，运行收到系统通知的功能，所以就需要  
 了解系统通知的管理权限功能，接下来看下相关的功能分析来实现具体的功能



## 2.framework根据包名默认开启一些应用的通知使用权的核心类



```
frameworks/base/services/core/java/com/android/server/notification/NotificationManagerService.java
frameworks/base/core/res/res/values/config.xml
```

## 3.framework根据包名默认开启一些应用的通知使用权的核心功能分析和实现


NotificationManager是一个Android系统服务，用于管理和运行所有通知。  
 NotificationManager因为是系统服务，所以不能被实例化，为了把Notification传给它，可以用getSystemService()方法获取一个NotificationManager的引用。  
 在需要通知用户时再调用notify()方法将Notification对象传给它。  
 NotificationManager是状态栏通知的管理类,负责发通知、清楚通知等。 NotificationManager 是一个系统Service,必须通过getSystemService()方法来获取  
 NotificationManagerService 是在系统启动时在SystemService.startOtherServicess的时候通过  
 mSystemServiceManager.startService(NotificationManagerService.class)方式启动的，  
 并且加入到了系统服务的列表当中，在Android系统中可以通过  
 ServiceManager.getService("notification")拿到这个服务，后面统称为NMS。


## 3.1 NotificationManagerService.java关于通知授权的相关管理分析


在实现framework根据包名默认开启一些应用的通知使用权的核心功能中，通过上述的分析得知，  
 NotificationManagerService是在系统中主要管理系统通知的服务，负责通知的发送等核心功能  
 接下来具体看下相关功能



```
    private final BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equals(Intent.ACTION_SCREEN_ON)) {
                // Keep track of screen on/off state, but do not turn off the notification light
                // until user passes through the lock screen or views the notification.
                mScreenOn = true;
                updateNotificationPulse();
            } else if (action.equals(Intent.ACTION_SCREEN_OFF)) {
                mScreenOn = false;
                updateNotificationPulse();
            } else if (action.equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) {
                mInCall = TelephonyManager.EXTRA_STATE_OFFHOOK
                        .equals(intent.getStringExtra(TelephonyManager.EXTRA_STATE));
                updateNotificationPulse();
            } else if (action.equals(Intent.ACTION_USER_STOPPED)) {
                int userHandle = intent.getIntExtra(Intent.EXTRA_USER_HANDLE, -1);
                if (userHandle >= 0) {
                    cancelAllNotificationsInt(MY_UID, MY_PID, null, null, 0, 0, true, userHandle,
                            REASON_USER_STOPPED, null);
                }
            } else if (action.equals(Intent.ACTION_MANAGED_PROFILE_UNAVAILABLE)) {
                int userHandle = intent.getIntExtra(Intent.EXTRA_USER_HANDLE, -1);
                if (userHandle >= 0) {
                    cancelAllNotificationsInt(MY_UID, MY_PID, null, null, 0, 0, true, userHandle,
                            REASON_PROFILE_TURNED_OFF, null);
                }
            } else if (action.equals(Intent.ACTION_USER_PRESENT)) {
                // turn off LED when user passes through lock screen
                mNotificationLight.turnOff();
            } else if (action.equals(Intent.ACTION_USER_SWITCHED)) {
                final int userId = intent.getIntExtra(Intent.EXTRA_USER_HANDLE, USER_NULL);
                mUserProfiles.updateCache(context);
                if (!mUserProfiles.isManagedProfile(userId)) {
                    // reload per-user settings
                    mSettingsObserver.update(null);
                    // Refresh managed services
                    mConditionProviders.onUserSwitched(userId);
                    mListeners.onUserSwitched(userId);
                    mZenModeHelper.onUserSwitched(userId);
                    mPreferencesHelper.onUserSwitched(userId);
                }
                // assistant is the only thing that cares about managed profiles specifically
                mAssistants.onUserSwitched(userId);
            } else if (action.equals(Intent.ACTION_USER_ADDED)) {
                final int userId = intent.getIntExtra(Intent.EXTRA_USER_HANDLE, USER_NULL);
                if (userId != USER_NULL) {
                    mUserProfiles.updateCache(context);
                    if (!mUserProfiles.isManagedProfile(userId)) {
                        readDefaultApprovedServices(userId);
                    }
                }
            }
...
}

    @VisibleForTesting
    protected void loadPolicyFile() {
        if (DBG) Slog.d(TAG, "loadPolicyFile");
        synchronized (mPolicyFile) {
            InputStream infile = null;
            try {
                infile = mPolicyFile.openRead();
                readPolicyXml(infile, false /*forRestore*/, UserHandle.USER_ALL);
            } catch (FileNotFoundException e) {
                // No data yet
                // Load default managed services approvals
                readDefaultApprovedServices(USER_SYSTEM);
            } catch (IOException e) {
                Log.wtf(TAG, "Unable to read notification policy", e);
            } catch (NumberFormatException e) {
                Log.wtf(TAG, "Unable to parse notification policy", e);
            } catch (XmlPullParserException e) {
                Log.wtf(TAG, "Unable to parse notification policy", e);
            } finally {
                IoUtils.closeQuietly(infile);
            }
        }
    }
```

在实现framework根据包名默认开启一些应用的通知使用权的核心功能中，通过上述的分析得知，  
 NotificationManagerService的相关源码中分析得知，在多用户模式收到添加用户的时候，和  
  loadPolicyFile()加载默认数据的时候，都会调用readDefaultApprovedServices(USER\_SYSTEM);  
 来授予默认一些app的通知管理权限，接下来看怎么授予通知权限的，



```
    protected void readDefaultApprovedServices(int userId) {
        String defaultListenerAccess = getContext().getResources().getString(
                com.android.internal.R.string.config_defaultListenerAccessPackages);
        if (defaultListenerAccess != null) {
            for (String whitelisted :
                    defaultListenerAccess.split(ManagedServices.ENABLED_SERVICES_SEPARATOR)) {
                // Gather all notification listener components for candidate pkgs.
                Set<ComponentName> approvedListeners =
                        mListeners.queryPackageForServices(whitelisted,
                                MATCH_DIRECT_BOOT_AWARE
                                        | MATCH_DIRECT_BOOT_UNAWARE, userId);
                for (ComponentName cn : approvedListeners) {
                    try {
                        getBinderService().setNotificationListenerAccessGrantedForUser(cn,
                                    userId, true);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        String defaultDndAccess = getContext().getResources().getString(
                com.android.internal.R.string.config_defaultDndAccessPackages);
        if (defaultDndAccess != null) {
            for (String whitelisted :
                    defaultDndAccess.split(ManagedServices.ENABLED_SERVICES_SEPARATOR)) {
                try {
                    getBinderService().setNotificationPolicyAccessGranted(whitelisted, true);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }

        setDefaultAssistantForUser(userId);
    }
```

在实现framework根据包名默认开启一些应用的通知使用权的核心功能中，通过上述的分析得知，  
 NotificationManagerService的相关源码中分析得知，在readDefaultApprovedServices(int userId）  
 方法中，会根据com.android.internal.R.string.config\_defaultDndAccessPackages和  
  com.android.internal.R.string.config\_defaultListenerAccessPackages中的包名来授予通知权限  
 这两个value值中两个包名之间用:分开解析的时候来作为分隔符  
 接下来看下frameworks/base/core/res/res/values/config.xml中的值



```
    <!-- Colon separated list of package names that should be granted DND access -->
    <string name="config_defaultDndAccessPackages" translatable="false">com.android.camera2</string>
    <!-- Colon separated list of package names that should be granted Notification Listener access -->
 -   <string name="config_defaultListenerAccessPackages" translatable="false"></string>
+   <string name="config_defaultListenerAccessPackages" translatable="false">com.simon.harmonichackernews:com.android.splitscreen</string>
```

在实现framework根据包名默认开启一些应用的通知使用权的核心功能中，通过上述的分析得知，  
 NotificationManagerService的相关源码中分析得知，在config.xml中  
 config\_defaultListenerAccessPackages中添加需要默认授权通知权限的app，包名之间用  
 :分割开就可以了，这样就实现了相关的功能



