



## 1.前言


在10.0的系统rom产品定制化开发中，在对Launcher3的folder文件夹功能定制中，要求folder文件夹跨行显示，就是 2x2布局显示，默认的都是占1格的，现在要求占4格显示，系统默认是不支持显示4格的，所以接下来需要分析相关的 功能，然后来实现这个功能


![](https://img-blog.csdnimg.cn/direct/8c44b386067a42278bf43aa0bf4c4985.png)


## 2.Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心类



```
packages\apps\Launcher3\res\xml\default_workspace_5x5.xml
packages\apps\Launcher3\src\com\android\launcher3\AutoInstallsLayout.java
packages\apps\Launcher3\src\com\android\launcher3\model\LoaderTask.java
```

## 3.Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能分析和实现


在launcher3中初始化数据的时候，初始化创建launcher.db数据库，数据库里创建了两张表，分别是favorites，workspace 在数据库表中，\_id:用于标识区分各个应用图标，是表favorites的主键，当添加数据时通过generateNewId使\_id值增加。 title:在WorkSpace(HotSeat中一般会隐藏掉)中展示的应用快捷图标的标题。 intent:当点击桌面图标时的负责启动应用的intent，它通过Intent.toUri()转换为String存储，在使用时通过Intent.parseUri()转换为intent。 container:指的是当前数据所在的容器类型，在Launcher中有两种container类型：1.CONTAINER\_DESKTOP(-100)， 2.CONTAINER\_HOTSEAT(-101)。 screen:用于标识当前数据所在的页。当container为-100时，则screen的值表现为我们桌面的页数的值，当container为-101即当前快捷图标处于HotSeat时，则指快捷图标所在的第X个位置。 cellX:当前快捷图标所在页(CellLayout)的X位置，即快捷图标在当前页横向的第X个位置。 cellY:当前快捷图标所在页(CellLayout)的Y位置，即快捷图标在当前页纵向的第Y个位置。 spanX:当前快捷图标的在所在页(CellLayout)的横向范围信息，如果当前图标为application、shortcut、folder则为1，表示图标横向上占据一个cell的位置范围。如果当前图标为Widget，则横向占据范围可能为多个cell。 spanY:当前快捷图标的在所在页(CellLayout)的纵向范围信息，如果当前图标为application、shortcut、folder则为1，表示图标纵向上占据一个cell的位置范围。如果当前图标为Widget，则纵向占据范围可能为多个cell。 而在加载数据的时候，在AutoInstallsLayout.java负责解析xml的属性，然后添加到db数据库里面，而在 LoaderTask.java:加载各个模块Task的显示类,如workspace工作区icon、all工作 区icon初始化工作


## 3.1 default\_workspace\_5x5.xml中添加folder文件夹数据


在Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能中，在通过上述的分析得知， 在Launcher3中，关于具体是加载哪个workspace的xml，需要分析device\_profiles.xml的屏幕的匹配来看具体是 哪个xml文件，在这里以default\_workspace\_5x5.xml为例来添加folder的功能



```
   <resolve
        launcher:container="-101"
        launcher:screen="1"
        launcher:x="1"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_GALLERY;end" />
        <favorite launcher:uri="#Intent;type=images/*;end" />
    </resolve>
   <folder
        launcher:screen="1"
        launcher:title="folder"
        launcher:spanX="2"
        launcher:spanY="2"
        launcher:x="0"
        launcher:y="0">
        <favorite
           launcher:packageName="com.android.soundrecorder"
           launcher:className="com.android.soundrecorder.SoundRecorder" />
        <favorite
           launcher:packageName="com.android.documentsui" 
           launcher:className="com.android.documentsui.LauncherActivity" />
        <favorite
           launcher:packageName="com.mediatek.camera" 
           launcher:className="com.mediatek.camera.CameraLauncher" />
        <favorite
           launcher:packageName="com.android.gallery3d" 
           launcher:className="com.android.gallery3d.app.GalleryActivity" />
        <favorite
           launcher:packageName="com.android.settings" 
           launcher:className="com.android.settings.Settings" />
    </folder>
```

在Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能中，在通过上述的分析得知， 在default\_workspace\_5x5.xml中的相关源码中，添加folder的这段代码，然后添加表示所占行列的参数 launcher:spanX="2" launcher:spanY="2"来看具体实现怎么在解析的时候来把这个参数添加到db数据库里面 接下来看下在AutoInstallsLayout.java解析folder的相关源码分析


## 3.2 AutoInstallsLayout.java解析folder的相关源码分析


在Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能中，在通过上述的分析得知， AutoInstallsLayout.java中负责解析不同类型的图标类型然后添加对应的属性到数据库中，接下来分析下 相关的解析xml数据的相关类型



```
  protected ArrayMap<String, TagParser> getLayoutElementsMap() {
        ArrayMap<String, TagParser> parsers = new ArrayMap<>();
        parsers.put(TAG_APP_ICON, new AppShortcutParser());
        parsers.put(TAG_AUTO_INSTALL, new AutoInstallParser());
        parsers.put(TAG_FOLDER, new FolderParser());
        parsers.put(TAG_APPWIDGET, new PendingWidgetParser());
        parsers.put(TAG_SEARCH_WIDGET, new SearchWidgetParser());
        parsers.put(TAG_SHORTCUT, new ShortcutParser(mSourceRes));
        return parsers;
    }
    protected class FolderParser implements TagParser {
        private final ArrayMap<String, TagParser> mFolderElements;

        public FolderParser() {
            this(getFolderElementsMap());
        }

        public FolderParser(ArrayMap<String, TagParser> elements) {
            mFolderElements = elements;
        }

        @Override
        public int parseAndAdd(XmlPullParser parser)
                throws XmlPullParserException, IOException {
            final String title;
            final int titleResId = getAttributeResourceValue(parser, ATTR_TITLE, 0);
            if (titleResId != 0) {
                title = mSourceRes.getString(titleResId);
            } else {
                String titleText = getAttributeValue(parser, ATTR_TITLE_TEXT);
                title = TextUtils.isEmpty(titleText) ? "" : titleText;
            }

            mValues.put(Favorites.TITLE, "");
            mValues.put(Favorites.ITEM_TYPE, Favorites.ITEM_TYPE_FOLDER);
-            mValues.put(Favorites.SPANX, 1);
-            mValues.put(Favorites.SPANY, 1);
+            mValues.put(Favorites.SPANX, getAttributeValue(parser, ATTR_SPAN_X));
+            mValues.put(Favorites.SPANY, getAttributeValue(parser, ATTR_SPAN_Y));
            mValues.put(Favorites._ID, mCallback.generateNewItemId());
            int folderId = mCallback.insertAndCheck(mDb, mValues);
            if (folderId < 0) {
                if (LOGD) Log.e(TAG, "Unable to add folder");
                return -1;
            }

            final ContentValues myValues = new ContentValues(mValues);
            IntArray folderItems = new IntArray();

            int type;
            int folderDepth = parser.getDepth();
            int rank = 0;
            while ((type = parser.next()) != XmlPullParser.END_TAG ||
                    parser.getDepth() > folderDepth) {
                if (type != XmlPullParser.START_TAG) {
                    continue;
                }
                mValues.clear();
                mValues.put(Favorites.CONTAINER, folderId);
                mValues.put(Favorites.RANK, rank);

                TagParser tagParser = mFolderElements.get(parser.getName());
                if (tagParser != null) {
                    final int id = tagParser.parseAndAdd(parser);
                    if (id >= 0) {
                        folderItems.add(id);
                        rank++;
                    }
                } else {
                    throw new RuntimeException("Invalid folder item " + parser.getName());
                }
            }

            int addedId = folderId;

.....
            return addedId;
        }
    }
```

在Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能中，在通过上述的分析得知，  
 AutoInstallsLayout.java中的相关源码中分析得知，在getLayoutElementsMap()会根据在解析default\_workspace\_5x5.xml中  
 的源码中，来看属于哪种类型的item类型，所以会看到解析folder的时候，会调用FolderParser 来进行相关的  
 解析功能，而在  mValues.put(Favorites.SPANX, 1);和mValues.put(Favorites.SPANY, 1);的时候，会发现  
 folder文件夹的所占行数列数呗写为1的，所以改成从xml中解析相关的数据，修改成上述的代码就可以了，  
 接下来看下加载Folder的时候，看下如何改成所占的行列数


## 3.3 LoaderTask.java的相关解析folder数据的分析


在Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能中，在通过上述的分析得知，  
 LoaderTask.java核心加载各个模块Task的显示类,如workspace工作区icon、all工作 区icon初始化工作，接下来看下是如何加载Folder的相关数据的



```
  private void loadWorkspace(List<ShortcutInfo> allDeepShortcuts) {
        loadWorkspace(allDeepShortcuts, LauncherSettings.Favorites.CONTENT_URI);
    }
    protected void loadWorkspace(List<ShortcutInfo> allDeepShortcuts, Uri contentUri) {
.....

        LauncherSettings.Settings.call(contentResolver,
                LauncherSettings.Settings.METHOD_LOAD_DEFAULT_FAVORITES);

        synchronized (mBgDataModel) {
            mBgDataModel.clear();

            final HashMap<PackageUserKey, SessionInfo> installingPkgs =
                    mSessionHelper.getActiveSessions();
            installingPkgs.forEach(mApp.getIconCache()::updateSessionCache);

            final PackageUserKey tempPackageKey = new PackageUserKey(null, null);
            mFirstScreenBroadcast = new FirstScreenBroadcast(installingPkgs);

            Map<ShortcutKey, ShortcutInfo> shortcutKeyToPinnedShortcuts = new HashMap<>();
            final LoaderCursor c = new LoaderCursor(
                    contentResolver.query(contentUri, null, null, null, null), contentUri, mApp,
                    mUserManagerState);

            Map<ComponentKey, AppWidgetProviderInfo> widgetProvidersMap = null;
.....
                        case LauncherSettings.Favorites.ITEM_TYPE_FOLDER:
                            FolderInfo folderInfo = mBgDataModel.findOrMakeFolder(c.id);
                            c.applyCommonProperties(folderInfo);

                            // Do not trim the folder label, as is was set by the user.
                            folderInfo.title = c.getString(c.titleIndex);
-                            folderInfo.spanX = 1;
-                            folderInfo.spanY = 1;
+                            folderInfo.spanX = c.getInt(spanXIndex);
+                            folderInfo.spanY = c.getInt(spanYIndex);
                            folderInfo.options = c.getInt(optionsIndex);

                            // no special handling required for restored folders
                            c.markRestored();

                            c.checkAndAddItem(folderInfo, mBgDataModel);
                            break;
```

在Launcher3定制folder文件夹2x2布局之一xml文件配置和解析相关属性的核心功能中，在通过上述的分析得知，  
 在LoaderTask.java中的相关源码中分析得知，在run方法中，来加载worksapce数据的时候，会调用  
            loadWorkspace(allShortcuts);来负责加载数据，然后在 loadWorkspace(List<ShortcutInfo> allDeepShortcuts, Uri contentUri)  
 来负责从db数据库加载具体数据，然后在对数据类型具体分析，在case LauncherSettings.Favorites.ITEM\_TYPE\_FOLDER  
 中就表示是加载folder的数据类型，然后在folderInfo.spanX = 1;和 folderInfo.spanY = 1;设置folder所占行列为  
 1.所以需要改成db数据库中读取行列数，具体实现就是修改为folderInfo.spanX = c.getInt(spanXIndex);  
 和folderInfo.spanY = c.getInt(spanYIndex);来实现功能



