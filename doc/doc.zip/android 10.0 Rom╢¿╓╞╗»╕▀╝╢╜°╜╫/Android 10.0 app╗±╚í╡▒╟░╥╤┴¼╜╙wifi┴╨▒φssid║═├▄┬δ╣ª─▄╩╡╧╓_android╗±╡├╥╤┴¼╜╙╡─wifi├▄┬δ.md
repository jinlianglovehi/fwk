



## 1.前言


在10.0的系统定制化开发中，在一些关于wifi的定制中，有产品需求app中要求获取当前连接wifi和密码功能，在系统原生wifi中  
 是禁止获取wifi连接的密码的，所以就需要对wifi模块进行一部分的修改，来满足app中获取wifi的ssid和密码功能，接下来就来  
 实现这个功能 如图:


![](https://img-blog.csdnimg.cn/direct/f41ea56c7a854b6ea11596868c38c7a3.png)  
 首选看下在app中获取wifi连接的相关信息的代码



```
   WifiConfiguration wifiConfiguration = null;
        WifiManager wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
    try {
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        String ssid1 = wifiInfo.getSSID();
        Log.e("EditActivity","ssid111111:"+ssid);
        List<WifiConfiguration> configuredNetworks = wifiManager.getConfiguredNetworks();
        Log.e("EditActivity","ssid111111:"+ssid+"--configuredNetworks:"+configuredNetworks);
        for (WifiConfiguration config : configuredNetworks) {
            String ssid2 = config.SSID;
            String psd = config.preSharedKey;

            Log.e("EditActivity","psd:"+psd+"--ssid2:"+ssid2);
            /*if (config.SSID.equals(ssid1)){
                wifiConfiguration = config;
                String psd = config.preSharedKey;
                Log.e("EditActivity","psd:"+psd+"--ssid1:"+ssid);
                break;
            }*/
        }
    }catch (Exception e){
        e.printStackTrace();
    }
```

在上述的app这段代码中，发现在联网情况下通过wifiInfo.getSSID();可以获取到wifi的ssid,而在  
 List<WifiConfiguration> configuredNetworks = wifiManager.getConfiguredNetworks();这段获取当前wifi列表的  
 由于受到系统权限的限制所以就获取不到当前已连接wifi的WifiConfiguration的信息列表，接下来就看在系统中如何  
 修改相关源码来实现获取已连接的wifi列表功能


## 2.app获取当前已连接wifi列表ssid和密码功能实现的核心类



```
frameworks/base/services/core/java/com/android/server/policy/PhoneWindowManager.java
frameworks/opt/net/wifi/service/java/com/android/server/wifi/WifiServiceImpl.java
frameworks/base/wifi/java/android/net/wifi/WifiManager.java

```

3.app获取当前已连接wifi列表ssid和密码功能实现的核心功能分析和实现


WifiManager这个类, 是 Android 暴露给开发者使用的一个系统服务管理类, 其中包含对WiFi的响应的操作函数; 其隐藏掉的系统服务类为IWifiService,  
 为Android私有的, 其具体实现, 未暴露给用户; 只需要使用WifiManager进行函数操作完成UI, 监听对应的广播消息, 就可完成功能了. 换言之, WifiManager会调用service简介地和framework层,  
  驱动层进行函数调用, 然后驱动层会回调至上层, 以广播的形式实现通知; 这是目前WiFi的简单介绍


 WifiServiceImpl为IWifiManager.Stub的实现类,因此WifiServiceImpl是WifiManager大部分方法调用的JAVA层实现  
 WifiService类，继承自SystemService，这个类主要负责初始化WifiServiceImpl，将WifiServiceImpl以WIFI\_SERVICE注册到ServiceManager中，Wifi的主要功能通过binder来调用WifiServiceImpl实现


## 3.1 WifiManager.java中关于获取wifi列表的相关功能分析


在实现app获取当前已连接wifi列表ssid和密码功能实现的核心功能中，在通过上述分析得知，在  
 WifiManager这个类, 是 Android 暴露给开发者使用的一个系统服务管理类, 其中包含对WiFi的响应的操作函数，接下来  
 看下这个类的相关核心方法分析来实现相关功能



```
  @Deprecated
    @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE})
    public List<WifiConfiguration> getConfiguredNetworks() {
        try {
            ParceledListSlice<WifiConfiguration> parceledList =
-                    mService.getConfiguredNetworks(mContext.getOpPackageName(),
+                    mService.getPrivilegedConfiguredNetworks(mContext.getOpPackageName(),
                            mContext.getAttributionTag());
            if (parceledList == null) {
                return Collections.emptyList();
            }
            return parceledList.getList();
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }

    /** @hide */
    @SystemApi
    @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE, READ_WIFI_CREDENTIAL})
    public List<WifiConfiguration> getPrivilegedConfiguredNetworks() {
        try {
            ParceledListSlice<WifiConfiguration> parceledList =
                    mService.getPrivilegedConfiguredNetworks(mContext.getOpPackageName(),
                            mContext.getAttributionTag());
            if (parceledList == null) {
                return Collections.emptyList();
            }
            return parceledList.getList();
        } catch (RemoteException e) {
            throw e.rethrowFromSystemServer();
        }
    }
```

在实现app获取当前已连接wifi列表ssid和密码功能实现的核心功能中，在通过上述分析得知，在  
 WifiManager.java中的上述源码分析得知，在上述的源码中，可以看出在getConfiguredNetworks()  
 和getPrivilegedConfiguredNetworks()中这两个方法中，都可以通过WifiManager来获取当前已连接的  
 wifi列表，但是它们两个方法的区别就是在通过getConfiguredNetworks()获取的List<WifiConfiguration>  
 的wifi列表中，通过WifiConfiguration的preSharedKey方法获取的wifi密码就是一个\*号看不到密码所以加密的  
 密码，而通过getPrivilegedConfiguredNetworks()获取的List<WifiConfiguration>  
 的wifi列表中，通过WifiConfiguration的preSharedKey方法获取的wifi密码就是明文密码，所以就可以通过  
 获取wifi列表，然后遍历wifi列表通过WifiConfiguration的preSharedKey方法获取密码  
 所以在上述的getConfiguredNetworks()中通过mService.getPrivilegedConfiguredNetworks来获取wifi列表功能


## 3.2 WifiServiceImpl.java中关于获取wifi密码的修改


在实现app获取当前已连接wifi列表ssid和密码功能实现的核心功能中，在通过上述分析得知，在  
 WifiServiceImpl.java中，WifiServiceImpl是WifiManager大部分方法调用的JAVA层实现类，所以说  
 在wifimanager.java中的接口都是在WifiServiceImpl中实现的，接下来分析下具体的方法实现



```
    /**
     * see {@link android.net.wifi.WifiManager#getPrivilegedConfiguredNetworks()}
     *
     * @param packageName String name of the calling package
     * @param featureId The feature in the package
     * @return the list of configured networks with real preSharedKey
     */
    @Override
    public ParceledListSlice<WifiConfiguration> getPrivilegedConfiguredNetworks(
            String packageName, String featureId) {
-        enforceReadCredentialPermission();
+        //enforceReadCredentialPermission();
        enforceAccessPermission();
        int callingUid = Binder.getCallingUid();
        long ident = Binder.clearCallingIdentity();
        try {
            mWifiPermissionsUtil.enforceCanAccessScanResults(packageName, featureId, callingUid,
                    null);
        } catch (SecurityException e) {
            Log.e(TAG, "Permission violation - getPrivilegedConfiguredNetworks not allowed for"
                    + " uid=" + callingUid + ", packageName=" + packageName + ", reason=" + e);
            return null;
        } finally {
            Binder.restoreCallingIdentity(ident);
        }
        if (mVerboseLoggingEnabled) {
            mLog.info("getPrivilegedConfiguredNetworks uid=%").c(callingUid).flush();
        }
        List<WifiConfiguration> configs = mWifiThreadRunner.call(
                () -> mWifiConfigManager.getConfiguredNetworksWithPasswords(),
                Collections.emptyList());
        return new ParceledListSlice<>(configs);
    }
    private void enforceReadCredentialPermission() {
        mContext.enforceCallingOrSelfPermission(android.Manifest.permission.READ_WIFI_CREDENTIAL,
                                                "WifiService");
    }
```

在实现app获取当前已连接wifi列表ssid和密码功能实现的核心功能中，在通过上述分析得知，在  
 WifiServiceImpl.java中的上述源码中分析得知，在getPrivilegedConfiguredNetworks中获取  
 wifi列表的功能中，在enforceAccessPermission();中判断app中获取wifi关于定位的普通权限，而在enforceReadCredentialPermission()  
 中就是判断app是否有READ\_WIFI\_CREDENTIAL权限，这个权限app中是无法申请的，属于系统权限，所以让  
 app能正常使用就需要注释掉这个权限的判断，


## 3.3 PhoneWindowManager.java中关于获取已连接wifi列表的功能验证


在实现app获取当前已连接wifi列表ssid和密码功能实现的核心功能中，在通过上述分析得知，在PhoneWindowManager.java  
 中主要是来负责实现验证获取当前已经连接过的wifi列表的功能实现，接下来来具体实现



```
  @Override
    public void systemReady() {
        // In normal flow, systemReady is called before other system services are ready.
        // So it is better not to bind keyguard here.
        mKeyguardDelegate.onSystemReady();

        mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
        if (mVrManagerInternal != null) {
            mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
        }
......
                //add code start
        IntentFilter intentFilter = new IntentFilter("");
        intentFilter.addAction("com.android.getwifipsd");
        mContext.registerReceiver(mWallpaperChangedReceiver, intentFilter);
// add core end
        mAutofillManagerInternal = LocalServices.getService(AutofillManagerInternal.class);
    }
       //add code start
    BroadcastReceiver mWallpaperChangedReceiver  = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
                       String action = intent.getAction();
                       Log.e("EditActivity","action:"+action);
                       if(action.equals("com.android.getwifipsd")){
                        final long ident = Binder.clearCallingIdentity();
              try {
                               WifiManager wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
                               WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String ssid1 = wifiInfo.getSSID();
                List<WifiConfiguration> configuredNetworks = wifiManager.getConfiguredNetworks();
                               Log.e("EditActivity","ssid111111:"+ssid1+"--configuredNetworks:"+configuredNetworks);
                               for (WifiConfiguration config : configuredNetworks) {
                                       String ssid2 = config.SSID;
                                       String psd = config.preSharedKey;
                    Log.e("EditActivity","psd:"+psd+"--ssid2:"+ssid2);
                  /*if (config.SSID.equals(ssid1)){
                    String psd = config.preSharedKey;
                    Log.e("EditActivity","psd:"+psd+"--ssid1:"+ssid1);
                    break;
                  }*/
                }
                         } finally {
                Binder.restoreCallingIdentity(ident);
              }
                       }
        }
    };
// add core end
```

在实现app获取当前已连接wifi列表ssid和密码功能实现的核心功能中，在通过上述分析得知，在PhoneWindowManager.java  
 中通过在systemReady()中注册监听com.android.getwifipsd的测试获取wifi密码的广播，然后在接收到测试广播以后，就可以  
 通过wifiManager.getConfiguredNetworks()的接口来获取当前wifi连接的列表，然后遍历列表通过config.SSID和 config.preSharedKey  
 来获取wifi的ssid和密码实现功能，这样同时也可以在app中获取wifi的密码功能



