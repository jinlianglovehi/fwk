



## 1.前言


  
  在10.0的系统产品定制化开发中，在camera2的一些图形图像中有些是不正常的功能，比如在拍照和预览画面和手机屏幕不一致，  
 或者在保存拍照图片的时候发现图片翻转保存了等问题，所以就需要分析下相关的问题来解决实现功能


## 2.camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现的核心类



```
packages\apps\Camera2\src\com\android\camera\one\v2\SimpleOneCameraFactory.java
packages\apps\Camera2\src\com\android\camera\one\v2\OneCameraImpl.java
packages\apps\Camera2\src\com\android\camera\one\v2\OneCameraZslImpl.java
packages\apps\Camera2\src\com\android\camera\TextureViewHelper.java
packages\apps\Camera2\src\com\android\camera\Storage.java
```

## 3.camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现的核心功能分析和实现


在camera2中的源码中，在进行拍照的过程中，在SimpleOneCameraFactory创建了一个rootTemplate,他是一个RequestTemplate类,并传入了一个CameraDeviceRequestBuilderFactory。  
 来构建拍照的camera实体类OneCameraImpl.java和OneCameraZslImpl.java来进行拍照功能  
 在camera2中关于预览画面主要就是由TextureViewHelper.java来进行负责的，在它的构造方法中，实例化出了  
 关于预览画面的相关参数进行预览的相关功能实现  
 在camera2中的源码中，Storage.java主要负责拍照保存图片功能，在这个类中，updateImage（）这个静态  
 方法主要就是来保存拍照图片的功能，接下来就来实现这些功能


## 3.1 关于拍照方向旋转90度的功能实现


在camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现中，通过上述的相关camera2的源码分析得知，  
 在SimpleOneCameraFactory.java，OneCameraImpl.java和OneCameraZslImpl.java中主要就是进行拍照功能的  
 实现，接下来就来看下拍照方向修改的相关功能实现  
 SimpleOneCameraFactory.java中关于拍照方向的旋转功能实现



```
 CameraStarter cameraStarter = new CameraStarter() {
            @Override
            public CameraStarter.CameraControls startCamera(Lifetime cameraLifetime,
                    CameraCaptureSessionProxy cameraCaptureSession,
                    Surface previewSurface,
                    Observable<Float> zoomState,
                    Updatable<TotalCaptureResultProxy> metadataCallback,
                    Updatable<Boolean> readyState) {
                // Create the FrameServer from the CaptureSession.
                FrameServerFactory frameServerComponent = new FrameServerFactory(
                        new Lifetime(cameraLifetime), cameraCaptureSession, new HandlerFactory());

                CameraCommandExecutor cameraCommandExecutor = new CameraCommandExecutor(
                        Loggers.tagFactory(),
                        new Provider<ExecutorService>() {
                            @Override
                            public ExecutorService get() {
                                // Use a dynamically-expanding thread pool to
                                // allow any number of commands to execute
                                // simultaneously.
                                return Executors.newCachedThreadPool();
                            }
                        });

                // Create the shared image reader.
                SharedImageReaderFactory sharedImageReaderFactory =
                        new SharedImageReaderFactory(new Lifetime(cameraLifetime), imageReader,
                                new HandlerFactory());
                Updatable<Long> globalTimestampCallback =
                        sharedImageReaderFactory.provideGlobalTimestampQueue();
                ManagedImageReader managedImageReader =
                        sharedImageReaderFactory.provideSharedImageReader();
....

                FrameServer ephemeralFrameServer =
                      frameServerComponent.provideEphemeralFrameServer();

                // Create basic functionality (zoom, AE, AF).
                BasicCameraFactory basicCameraFactory = new BasicCameraFactory(new Lifetime
                        (cameraLifetime),
                        characteristics,
                        ephemeralFrameServer,
                        rootBuilder,
                        cameraCommandExecutor,
                        new BasicPreviewCommandFactory(ephemeralFrameServer),
                        flashSetting,
                        exposureSetting,
                        zoomState,
                        hdrSceneSetting,
                        CameraDevice.TEMPLATE_PREVIEW);

                // Register the dynamic updater via orientation supplier
                rootBuilder.setParam(CaptureRequest.JPEG_ORIENTATION,
            -            mImageRotationCalculator.getSupplier());
            +          90);
OneCameraImpl.java中关于拍照方向的旋转功能实现

    public void takePictureNow(PhotoCaptureParameters params, CaptureSession session) {
        long dt = SystemClock.uptimeMillis() - mTakePictureStartMillis;
        Log.v(TAG, "Taking shot with extra AF delay of " + dt + " ms.");
        try {
            // JPEG capture.
            CaptureRequest.Builder builder = mDevice
                    .createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            builder.setTag(RequestTag.CAPTURE);
            addBaselineCaptureKeysToRequest(builder);

            // Enable lens-shading correction for even better DNGs.
            if (sCaptureImageFormat == ImageFormat.RAW_SENSOR) {
                builder.set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE,
                        CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE_ON);
            } else if (sCaptureImageFormat == ImageFormat.JPEG) {
                builder.set(CaptureRequest.JPEG_QUALITY, JPEG_QUALITY);
                builder.set(CaptureRequest.JPEG_ORIENTATION,
                 -       CameraUtil.getJpegRotation(params.orientation, mCharacteristics));
                 +       90);
            }

            builder.addTarget(mPreviewSurface);
            builder.addTarget(mCaptureImageReader.getSurface());
            CaptureRequest request = builder.build();
OneCameraZslImpl.java中关于拍照方向的旋转功能实现
  private boolean sendSingleRequest(OneCamera.PhotoCaptureParameters params) {
        Log.v(TAG, "sendSingleRequest()");
        try {
            CaptureRequest.Builder builder;
            builder = mDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);

            builder.addTarget(mPreviewSurface);

            // Always add this surface for single image capture requests.
            builder.addTarget(mCaptureImageReader.getSurface());

            builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);

            Flash flashMode = Flash.OFF;
            addFlashToCaptureRequestBuilder(builder, flashMode);
            addRegionsToCaptureRequestBuilder(builder);

            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
            builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE);

            // Tag this as a special request which should be saved.
            builder.setTag(RequestTag.EXPLICIT_CAPTURE);

            if (sCaptureImageFormat == ImageFormat.JPEG) {
                builder.set(CaptureRequest.JPEG_QUALITY, (byte) (JPEG_QUALITY));
                builder.set(CaptureRequest.JPEG_ORIENTATION,
      -                  CameraUtil.getJpegRotation(params.orientation, mCharacteristics));
    +                  90);
            }

            mCaptureSession.capture(builder.build(), mCaptureManager, mCameraHandler);
            return true;
        } catch (CameraAccessException e) {
            Log.v(TAG, "Could not execute single still capture request.", e);
            return false;
        }
    }
```

在camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现中，通过上述的相关camera2的源码分析得知，  
 在SimpleOneCameraFactory.java，OneCameraImpl.java和OneCameraZslImpl.java中在关于拍照方向的  
 rootBuilder.setParam(CaptureRequest.JPEG\_ORIENTATION, 90);都做了90度旋转，所以这样拍照方向就  
 可以看出来是正常的方向了


## 3.2 TextureViewHelper.java关于预览方向的旋转90度功能实现


在camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现中，通过上述的相关camera2的源码分析得知，  
 在TextureViewHelper.java中主要负责预览方向的管理，所以就需要在构造方法中旋转预览方向就可以了



```
   public TextureViewHelper(TextureView preview, CaptureLayoutHelper helper,
            CameraProvider cameraProvider, AppController appController) {
        mPreview = preview;
        mCameraProvider = cameraProvider;
        mPreview.addOnLayoutChangeListener(this);
        mPreview.setSurfaceTextureListener(this);
        mCaptureLayoutHelper = helper;
        mAppController = appController;
+ mPreview.setRotation(90);
        mCameraModeId = appController.getAndroidContext().getResources()
                .getInteger(R.integer.camera_mode_photo);
        mCaptureIntentModeId = appController.getAndroidContext().getResources()
                .getInteger(R.integer.camera_mode_capture_intent);
    }
```

在camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现中，通过上述的相关camera2的源码分析得知，  
 在TextureViewHelper.java中在构造方法中，添加 mPreview.setRotation(90);就实现了预览画面旋转90度功能，


## 3.3 Storage.java关于拍照存储照片镜像功能实现


在camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现中，通过上述的相关camera2的源码分析得知，  
 在Storage.java主要负责存储照片功能，所以就 分析下相关存储照片源码



```
   public static Uri updateImage(Uri imageUri, ContentResolver resolver, String title, long date,
           Location location, int orientation, ExifInterface exif,
           byte[] jpeg, int width, int height, String mimeType) throws IOException {

+        Bitmap bitmap = CameraUtil.makeBitmap(jpeg, width * height);
+        Matrix matrix = new Matrix();
+        matrix .postScale(-1, 1);  // 镜像水平翻转
+        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
+        ByteArrayOutputStream byteout = new ByteArrayOutputStream();
+        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteout);
+        byte[] jpegData = byteout.toByteArray();

        String path = generateFilepath(title, mimeType);
     -   writeFile(path, jpeg, exif);
     +   writeFile(path, jpegData , exif);
     -   return updateImage(imageUri, resolver, title, date, location, orientation, jpeg.length, path,
     +   return updateImage(imageUri, resolver, title, date, location, orientation,  jpegData.length, path,
                width, height, mimeType);
    }

    /** Updates the image values in MediaStore. */
    private static Uri updateImage(Uri imageUri, ContentResolver resolver, String title,
            long date, Location location, int orientation, int jpegLength,
            String path, int width, int height, String mimeType) {

        ContentValues values =
                getContentValuesForData(title, date, location, orientation, jpegLength, path,
                        width, height, mimeType);


        Uri resultUri = imageUri;
        if (Storage.isSessionUri(imageUri)) {
            // If this is a session uri, then we need to add the image
            resultUri = addImageToMediaStore(resolver, title, date, location, orientation,
                    jpegLength, path, width, height, mimeType);
            sSessionsToContentUris.put(imageUri, resultUri);
            sContentUrisToSessions.put(resultUri, imageUri);
        } else {
            // Update the MediaStore
            resolver.update(imageUri, values, null, null);
        }
        return resultUri;
    }

```

在camera2关于拍照预览方向旋转90度和拍照图片镜像功能实现中，通过上述的相关camera2的源码分析得知，  
 在上述的Storage.java中的相关源码中分析得知，在updateImage(Uri imageUri, ContentResolver resolver...)  
 的方法中就是具体保存拍照照片的功能的，所以就可以在这个方法中，来通过添加图像镜像功能来实现保存  
 照片的功能，在上述方法中调用matrix .postScale(-1, 1);  // 镜像水平翻转来实现拍照图片的镜像功能




