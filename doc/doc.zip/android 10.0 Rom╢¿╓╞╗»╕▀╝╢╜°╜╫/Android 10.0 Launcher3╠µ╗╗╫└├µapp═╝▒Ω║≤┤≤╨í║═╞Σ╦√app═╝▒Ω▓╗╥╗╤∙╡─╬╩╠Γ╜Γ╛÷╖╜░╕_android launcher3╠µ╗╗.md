



## 1.前言


在10.0的系统ROM产品定制化开发中，在关于launcher3的产品定制化开发中，在有些时候需要对一些第三方的app图标做 替换或者是做一些动态图标的替换，发现在替换以后图标大小和其他app的图标大小不一样，所以就需要看是具体哪里 对app的图标做了缩放功能，接下来就需要去掉这些app图标的缩放功能来实现具体的功能


![](https://img-blog.csdnimg.cn/direct/cbb05e7aee60480cbddf198b9acc7b09.png)


## 2.Launcher3替换桌面app图标后大小和其他app图标不一样的问题解决方案的核心类



```
packages\apps\Launcher3\iconloaderlib\src\com\android\launcher3\icons\BaseIconFactory.java
packages\apps\Launcher3\src\com\android\launcher3\FastBitmapDrawable.java
```

## 3.Launcher3替换桌面app图标后大小和其他app图标不一样的问题解决方案的核心功能分析和实现


Launcher顾名思义,就是桌面的意思,也是android系统启动后第一个启动的应用程序， Launcher 是用户与设备交互的核心界面之一,它负责显示应用程序列表、提供快捷方式、管理小部件等功能， 在Launcher3中作为系统的桌面，相关定制功能也是很多的，在本篇功能实现中，BaseIconFactory.java：Launcher图标的工厂类，控制图标UI展示（图标白边控制） 在这个类中，为Launcher3来构造不同类型的app图标，包括缩放等功能，所以具体就需要分析下相关的构造app图标的 相关方法


## 3.1 BaseIconFactory.java的构造图标的相关源码分析


在实现Launcher3替换桌面app图标后大小和其他app图标不一样的问题解决方案的核心功能中，在通过上述的分析得知， 在BaseIconFactory.java的方法中，有关于具体实现对app图标的缩放功能，这样就可能会导致替换的app图标的大小 和其他app图标的大小不一样的功能，所以接下来需要具体分析下相关功能实现



```
 public BitmapInfo createIconBitmap(Bitmap icon) {
        if (mIconBitmapSize != icon.getWidth() || mIconBitmapSize != icon.getHeight()) {
            icon = createIconBitmap(new BitmapDrawable(mContext.getResources(), icon), 1f);
        }

        return BitmapInfo.of(icon, extractColor(icon));
    }

    public BitmapInfo createBadgedIconBitmap(Drawable icon, UserHandle user,
            boolean shrinkNonAdaptiveIcons) {
        return createBadgedIconBitmap(icon, user, shrinkNonAdaptiveIcons, false, null);
    }

    public BitmapInfo createBadgedIconBitmap(Drawable icon, UserHandle user,
            int iconAppTargetSdk) {
        return createBadgedIconBitmap(icon, user, iconAppTargetSdk, false);
    }

    public BitmapInfo createBadgedIconBitmap(Drawable icon, UserHandle user,
            int iconAppTargetSdk, boolean isInstantApp) {
        return createBadgedIconBitmap(icon, user, iconAppTargetSdk, isInstantApp, null);
    }

    public BitmapInfo createBadgedIconBitmap(Drawable icon, UserHandle user,
            int iconAppTargetSdk, boolean isInstantApp, float[] scale) {
        boolean shrinkNonAdaptiveIcons = ATLEAST_P ||
                (ATLEAST_OREO && iconAppTargetSdk >= Build.VERSION_CODES.O);
        return createBadgedIconBitmap(icon, user, shrinkNonAdaptiveIcons, isInstantApp, scale);
    }

    public Bitmap createScaledBitmapWithoutShadow(Drawable icon, int iconAppTargetSdk) {
        boolean shrinkNonAdaptiveIcons = ATLEAST_P ||
                (ATLEAST_OREO && iconAppTargetSdk >= Build.VERSION_CODES.O);
        return  createScaledBitmapWithoutShadow(icon, shrinkNonAdaptiveIcons);
    }

    /**
     * Creates bitmap using the source drawable and various parameters.
     * The bitmap is visually normalized with other icons and has enough spacing to add shadow.
     *
     * @param icon                      source of the icon
     * @param user                      info can be used for a badge
     * @param shrinkNonAdaptiveIcons    {@code true} if non adaptive icons should be treated
     * @param isInstantApp              info can be used for a badge
     * @param scale                     returns the scale result from normalization
     * @return a bitmap suitable for disaplaying as an icon at various system UIs.
     */
    public BitmapInfo createBadgedIconBitmap(@NonNull Drawable icon, UserHandle user,
            boolean shrinkNonAdaptiveIcons, boolean isInstantApp, float[] scale) {
        if (scale == null) {
            scale = new float[1];
        }
        icon = normalizeAndWrapToAdaptiveIcon(icon, shrinkNonAdaptiveIcons, null, scale);
        Bitmap bitmap = createIconBitmap(icon, scale[0]);
        if (ATLEAST_OREO && icon instanceof AdaptiveIconDrawable) {
            mCanvas.setBitmap(bitmap);
            getShadowGenerator().recreateIcon(Bitmap.createBitmap(bitmap), mCanvas);
            mCanvas.setBitmap(null);
        }

        if (isInstantApp) {
            badgeWithDrawable(bitmap, mContext.getDrawable(R.drawable.ic_instant_app_badge));
        }
        if (user != null) {
            BitmapDrawable drawable = new FixedSizeBitmapDrawable(bitmap);
            Drawable badged = mPm.getUserBadgedIcon(drawable, user);
            if (badged instanceof BitmapDrawable) {
                bitmap = ((BitmapDrawable) badged).getBitmap();
            } else {
                bitmap = createIconBitmap(badged, 1f);
            }
        }
        int color = extractColor(bitmap);
        return icon instanceof BitmapInfo.Extender
                ? ((BitmapInfo.Extender) icon).getExtendedInfo(bitmap, color, this)
                : BitmapInfo.of(bitmap, color);
    }

    public Bitmap createScaledBitmapWithoutShadow(Drawable icon, boolean shrinkNonAdaptiveIcons) {
        RectF iconBounds = new RectF();
        float[] scale = new float[1];
        icon = normalizeAndWrapToAdaptiveIcon(icon, shrinkNonAdaptiveIcons, iconBounds, scale);
        return createIconBitmap(icon,
                Math.min(scale[0], ShadowGenerator.getScaleForBounds(iconBounds)));
    }
```

在实现Launcher3替换桌面app图标后大小和其他app图标不一样的问题解决方案的核心功能中，在通过上述的分析得知， 在BaseIconFactory.java的方法中，在上述的关于构造app图标的方法中，有各种构造createBadgedIconBitmap的 方法，主要的方法就是在createBadgedIconBitmap(@NonNull Drawable icon, UserHandle user, boolean shrinkNonAdaptiveIcons, boolean isInstantApp, float[] scale)方法中，看具体是否需要缩放 就是float[] scale这个参数决定的，而在这个方法中，normalizeAndWrapToAdaptiveIcon(icon, shrinkNonAdaptiveIcons, null, scale); 是来判断缩放比例的，所以具体需要分析下normalizeAndWrapToAdaptiveIcon(icon, shrinkNonAdaptiveIcons, null, scale);的 相关方法



```
    private Drawable normalizeAndWrapToAdaptiveIcon(@NonNull Drawable icon,
            boolean shrinkNonAdaptiveIcons, RectF outIconBounds, float[] outScale) {
        if (icon == null) {
            return null;
        }
        float scale = 1f;

        if (shrinkNonAdaptiveIcons && ATLEAST_OREO) {
            if (mWrapperIcon == null) {
                mWrapperIcon = mContext.getDrawable(R.drawable.adaptive_icon_drawable_wrapper)
                        .mutate();
            }
            AdaptiveIconDrawable dr = (AdaptiveIconDrawable) mWrapperIcon;
            dr.setBounds(0, 0, 1, 1);
            boolean[] outShape = new boolean[1];
// modify code start
            //scale = getNormalizer().getScale(icon, outIconBounds, dr.getIconMask(), outShape);
// modify code end
            if (!(icon instanceof AdaptiveIconDrawable) && !outShape[0]) {
                FixedScaleDrawable fsd = ((FixedScaleDrawable) dr.getForeground());
                fsd.setDrawable(icon);
                fsd.setScale(scale);
                icon = dr;
// modify code start
                //scale = getNormalizer().getScale(icon, outIconBounds, null, null);
// modify code end
                ((ColorDrawable) dr.getBackground()).setColor(mWrapperBackgroundColor);
            }
        } else {
            scale = getNormalizer().getScale(icon, outIconBounds, null, null);
        }

        outScale[0] = scale;
        return icon;
    }
```

Launcher3替换桌面app图标后大小和其他app图标不一样的问题解决方案的核心功能中，在通过上述的分析得知， 在BaseIconFactory.java的方法中，通过上述的 normalizeAndWrapToAdaptiveIcon(@NonNull Drawable icon, boolean shrinkNonAdaptiveIcons, RectF outIconBounds, float[] outScale)的方法分析得知， 在if (shrinkNonAdaptiveIcons && ATLEAST\_OREO) 这个方法中，通过scale = getNormalizer().getScale(icon, outIconBounds, dr.getIconMask(), outShape); 和scale = getNormalizer().getScale(icon, outIconBounds, null, null);这两处来实现判断当前的app图标 是否需要缩放，然后返回这个值，这样就实现了app的图标缩放，会导致替换的app图标和原来的图标大小不同 所以就需要注释掉这部分代码就可以实现替换的app图标大小和其他app大小图标一样的效果



