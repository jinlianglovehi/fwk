



## 1.概述


  
  在10.0的系统产品开发中，对于app调用系统api来打开摄像头拍照的功能也是常有的功能，而拍照一般是默认打开后置摄像头拍照的，由于  
 客户的产品特殊要求，需要打开前置摄像头拍照功能，所以需要了解拍照功能的流程，然后修改默认前置摄像头打开拍照功能就可以了


app调用拍照功能如下：



```
private void photograph(String outputimagepath){
try//判断图片是否存在，存在则删除在创建，不存在则直接创建

{

if (!outputimagepath.getParentFile().exists()) {

outputimagepath.getParentFile().mkdirs();

}

if (outputimagepath.exists()) {

outputimagepath.delete();

}

outputimagepath.createNewFile();
Uri imagUri = null;
if (Build.VERSION.SDK_INT >= 24) {

imageUri = FileProvider.getUriForFile(this,

"com.wj.phone.fileprovider", outputimagepath);

} else {

imageUri = Uri.fromFile(outputimagepath);

}

//使用隐示的Intent，系统会找到与它对应的活动，即调用摄像头，并把它存储

Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");

intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

startActivityForResult(intent, TAKE_PHOTO);

//调用会返回结果的开启方式，返回成功的话，则把它显示出来

} catch (IOException e) {
e.printStackTrace();
}
}
```

## 2.Camera2 拍照功能默认选前摄像头的核心类



```
packages/apps/Camera2/src/com/android/camera/CaptureModule.java
packages/apps/Camera2/src/com/android/camera/CaptureActivity.java
packages/apps/Camera2/AndroidManifest.xml
```

## 3.Camera2 拍照功能默认选前摄像头的核心功能分析和实现


  
    通过上述app调用拍照api来调用系统摄像头api来拍照，然后照片回传到app处理，  
 主要是通过调用android.media.action.IMAGE\_CAPTURE然后在Camera2中，所以需要看哪里处理android.media.action.IMAGE\_CAPTURE  
 这个action,然后找相关代码分析


##   3.1 Camera2/AndroidManifest.xml相关action的处理



```
     <?xml version="1.0" encoding="utf-8"?>

 <manifest
   xmlns:android="http://schemas.android.com/apk/res/android"
   package="com.android.camera2">

   <uses-sdk
       android:minSdkVersion="19"
       android:targetSdkVersion="28" />
    <activity
            android:name="com.android.camera.CaptureActivity"
            android:label="@string/app_name"
            android:theme="@style/Theme.Camera"
            android:configChanges="orientation|screenSize|keyboardHidden"
             android:windowSoftInputMode="stateAlwaysHidden|adjustPan"
             android:visibleToInstantApps="true">
             <intent-filter>
                 <action android:name="android.media.action.IMAGE_CAPTURE" />
                 <category android:name="android.intent.category.DEFAULT" />
             </intent-filter>
         </activity>
 
         <!-- Video camera and capture use the Camcorder label and icon. -->
         <activity-alias
             android:name="com.android.camera.VideoCamera"
             android:label="@string/video_camera_label"
             android:targetActivity="com.android.camera.CaptureActivity">
             <intent-filter>
                 <action android:name="android.media.action.VIDEO_CAMERA" />
                 <category android:name="android.intent.category.DEFAULT" />
             </intent-filter>
             <intent-filter>
                 <action android:name="android.media.action.VIDEO_CAPTURE" />
                 <category android:name="android.intent.category.DEFAULT" />
             </intent-filter>
         </activity-alias>
```

通过Camera2的Androidmanifest.xml中可以发现在CaptureActivity中，处理了android.media.action.IMAGE\_CAPTURE  
 这个action事件，所以在CaptureActivity是主要处理拍照事件的，接下来分析下CaptureActivity的相关代码


## 3.2 CaptureActivity的相关代码



```
package com.android.camera;
  
  // Use a different activity for capture intents, so it can have a different
  // task affinity from others. This makes sure the regular camera activity is not
  // reused for IMAGE_CAPTURE or VIDEO_CAPTURE intents from other activities.
  public class CaptureActivity extends CameraActivity {
  }
```

在CaptureActivity的相关代码中可以看出并没有具体实现，每个平台具体实现不同，但是最后  
 通过分析得知，具体实现是在CaptureModule.java 这个类主要处理关于拍照的相关功能，  
 所以接下来分析下CaptureModule.java的相关代码，看具体的摄像头调用


## 3.3 CaptureModule.java的相关代码的拍照功能分析



```
      /**
   * New Capture module that is made to support photo and video capture on top of
   * the OneCamera API, to transparently support GCam.
   * <p>
   * This has been a re-write with pieces taken and improved from GCamModule and
   * PhotoModule, which are to be retired eventually.
   * <p>
   */
  public class CaptureModule extends CameraModule implements
          ModuleController,
          CountDownView.OnCountDownStatusListener,
          OneCamera.PictureCallback,
          OneCamera.FocusStateListener,
          OneCamera.ReadyStateChangedListener,
          RemoteCameraModule {
  
     private void reopenCamera() {
          if (mPaused) {
              return;
          }
          AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable() {
              @Override
              public void run() {
                  closeCamera();
                  if(!mAppController.isPaused()) {
                      openCameraAndStartPreview();
                  }
              }
          });
      }

     /**
       * Open camera and start the preview.
       */
      private void openCameraAndStartPreview() {
          Profile guard = mProfiler.create("CaptureModule.openCameraAndStartPreview()").start();
          try {
              // TODO Given the current design, we cannot guarantee that one of
              // CaptureReadyCallback.onSetupFailed or onReadyForCapture will
              // be called (see below), so it's possible that
              // mCameraOpenCloseLock.release() is never called under extremely
              // rare cases. If we leak the lock, this timeout ensures that we at
              // least crash so we don't deadlock the app.
              if (!mCameraOpenCloseLock.tryAcquire(CAMERA_OPEN_CLOSE_TIMEOUT_MILLIS,
                      TimeUnit.MILLISECONDS)) {
                  throw new RuntimeException("Time out waiting to acquire camera-open lock.");
              }
          } catch (InterruptedException e) {
              throw new RuntimeException("Interrupted while waiting to acquire camera-open lock.", e);
          }
  
          guard.mark("Acquired mCameraOpenCloseLock");
  
          if (mOneCameraOpener == null) {
              Log.e(TAG, "no available OneCameraManager, showing error dialog");
              mCameraOpenCloseLock.release();
              mAppController.getFatalErrorHandler().onGenericCameraAccessFailure();
              guard.stop("No OneCameraManager");
              return;
          }
          if (mCamera != null) {
              // If the camera is already open, do nothing.
              Log.d(TAG, "Camera already open, not re-opening.");
              mCameraOpenCloseLock.release();
              guard.stop("Camera is already open");
              return;
          }
  
          // Derive objects necessary for camera creation.
          MainThread mainThread = MainThread.create();
          ImageRotationCalculator imageRotationCalculator = ImageRotationCalculatorImpl
                  .from(mAppController.getOrientationManager(), mCameraCharacteristics);
  
          // Only enable GCam on the back camera
          boolean useHdr = mHdrPlusEnabled && mCameraFacing == Facing.BACK;
  
          CameraId cameraId = mOneCameraManager.findFirstCameraFacing(mCameraFacing);
          final String settingScope = SettingsManager.getCameraSettingScope(cameraId.getValue());
  
          OneCameraCaptureSetting captureSetting;
          // Read the preferred picture size from the setting.
          try {
              mPictureSize = mAppController.getResolutionSetting().getPictureSize(
                      cameraId, mCameraFacing);
              captureSetting = OneCameraCaptureSetting.create(mPictureSize, mSettingsManager,
                      getHardwareSpec(), settingScope, useHdr);
          } catch (OneCameraAccessException ex) {
              mAppController.getFatalErrorHandler().onGenericCameraAccessFailure();
              return;
          }
  
          mOneCameraOpener.open(cameraId, captureSetting, mCameraHandler, mainThread,
                imageRotationCalculator, mBurstController, mSoundPlayer,
                new OpenCallback() {
                    @Override
                    public void onFailure() {
                        Log.e(TAG, "Could not open camera.");
                        // Sometimes the failure happens due to the controller
                        // being in paused state but mCamera is already
                        // initialized.  In these cases we just need to close the
                        // camera device without showing the error dialog.
                        // Application will properly reopen the camera on the next
                        // resume operation (b/21025113).
                        boolean isControllerPaused = mAppController.isPaused();
                        if (mCamera != null) {
                            mCamera.close();
                        }
                        mCamera = null;
                        mCameraOpenCloseLock.release();
                        if (!isControllerPaused) {
                            mAppController.getFatalErrorHandler().onCameraOpenFailure();
                        }
                    }
  
                    @Override
                    public void onCameraClosed() {
                        mCamera = null;
                        mCameraOpenCloseLock.release();
                    }
  
                    @Override
                    public void onCameraOpened(@Nonnull final OneCamera camera) {
                        Log.d(TAG, "onCameraOpened: " + camera);
                        mCamera = camera;
  
                        // A race condition exists where the camera may be in the process
                        // of opening (blocked), but the activity gets destroyed. If the
                        // preview is initialized or callbacks are invoked on a destroyed
                        // activity, bad things can happen.
                        if (mAppController.isPaused()) {
                            onFailure();
                            return;
                        }
  
                        // When camera is opened, the zoom is implicitly reset to 1.0f
                        mZoomValue = 1.0f;
  
                        updatePreviewBufferDimension();
  
                        // If the surface texture is not destroyed, it may have
                        // the last frame lingering. We need to hold off setting
                        // transform until preview is started.
                        updatePreviewBufferSize();
                        mState = ModuleState.WATCH_FOR_NEXT_FRAME_AFTER_PREVIEW_STARTED;
                        Log.d(TAG, "starting preview ...");
  
                        // TODO: make mFocusController final and remove null
                        // check.
                        if (mFocusController != null) {
                            camera.setFocusDistanceListener(mFocusController);
                        }
  
                        mMainThread.execute(new Runnable() {
                            @Override
                            public void run() {
                                mAppController.getCameraAppUI().onChangeCamera();
                                mAppController.getButtonManager().enableCameraButton();
                            }
                        });
  
                        // TODO: Consider rolling these two calls into one.
                        camera.startPreview(new Surface(getPreviewSurfaceTexture()),
                              new CaptureReadyCallback() {
                                  @Override
                                  public void onSetupFailed() {
                                      // We must release this lock here,
                                      // before posting to the main handler
                                      // since we may be blocked in pause(),
                                      // getting ready to close the camera.
                                      mCameraOpenCloseLock.release();
                                      Log.e(TAG, "Could not set up preview.");
                                      mMainThread.execute(new Runnable() {
                                          @Override
                                          public void run() {
                                              if (mCamera == null) {
                                                  Log.d(TAG, "Camera closed, aborting.");
                                                  return;
                                              }
                                              mCamera.close();
                                              mCamera = null;
                                              // TODO: Show an error message
                                              // and exit.
                                          }
                                      });
                                  }
  
                                  @Override
                                  public void onReadyForCapture() {
                                      // We must release this lock here,
                                      // before posting to the main handler
                                      // since we may be blocked in pause(),
                                      // getting ready to close the camera.
                                      mCameraOpenCloseLock.release();
                                      mMainThread.execute(new Runnable() {
                                          @Override
                                          public void run() {
                                              Log.d(TAG, "Ready for capture.");
                                              if (mCamera == null) {
                                                  Log.d(TAG, "Camera closed, aborting.");
                                                  return;
                                              }
                                              onPreviewStarted();
                                              // May be overridden by
                                              // subsequent call to
                                              // onReadyStateChanged().
                                              onReadyStateChanged(true);
                                              mCamera.setReadyStateChangedListener(
                                                    CaptureModule.this);
                                              // Enable zooming after preview
                                              // has started.
                                              mUI.initializeZoom(mCamera.getMaxZoom());
                                              mCamera.setFocusStateListener(CaptureModule.this);
                                          }
                                      });
                                  }
                              });
                    }
                }, mAppController.getFatalErrorHandler());
          guard.stop("mOneCameraOpener.open()");
      }

   private Facing getFacingFromCameraId(int cameraId) {
          return mAppController.getCameraProvider().getCharacteristics(cameraId)
                  .isFacingFront() ? Facing.FRONT : Facing.BACK;
      }
```

 从CaptureModule上述的代码中，可以看出在构造方法中，初始化拍照的相关api等,而在openCameraAndStartPreview()  
 中负责打开摄像头实现拍照的功能，而在openCameraAndStartPreview() 中可以看出在mOneCameraManager.findFirstCameraFacing(mCameraFacing)  
 来负责调用哪个摄像头，而它的值由mCameraFacing决定，而它由getFacingFromCameraId(int cameraId)中来判断调用哪个摄像头  
 所以具体看getFacingFromCameraId(int cameraId)的值，接下来具体修改为:



```
  private Facing getFacingFromCameraId(int cameraId) {
          return /*mAppController.getCameraProvider().getCharacteristics(cameraId)
                  .isFacingFront() ? */Facing.FRONT /*: Facing.BACK*/;
      }
```

就这样来决定调用前置摄像头来实现功能




