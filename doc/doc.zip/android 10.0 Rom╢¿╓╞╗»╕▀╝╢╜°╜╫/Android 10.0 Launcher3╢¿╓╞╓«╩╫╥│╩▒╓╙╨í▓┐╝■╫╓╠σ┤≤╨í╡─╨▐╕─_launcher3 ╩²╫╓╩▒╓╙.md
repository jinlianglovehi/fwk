



## 1.前言


在10.0的产品开发中，在一些Launcher3的定制化开发中，在对于一些小屏幕的产品开发中，在首页添加时钟小部件会显得字体有点小，  
 所以为了整体布局美观就需要改动小部件的布局日期字体的大小来实现整体的布局美观效果，接下来来具体实现相关的功能  
 具体效果图:


![](https://img-blog.csdnimg.cn/11e8252faf99455e844e1edcb87758f1.png)


## 2.Launcher3定制之首页时钟小部件字体大小的修改的核心类



```
packages\apps\Launcher3\res\xml\default_workspace_4x4.xml
packages\apps\DeskClock\src\com\android\alarmclock\DigitalAppWidgetProvider.java
```

## 3.Launcher3定制之首页时钟小部件字体大小的修改的核心功能分析和实现


App Widget的原理。App Widget是在桌⾯上的⼀块显⽰信息的东西，通过单击App Widget跳转到程序⼊⼝类。  
 ⽽系统⾃带的程序，典型的App Widget是music，这个Android内置的⾳乐播放⼩程序。这个是典型的  
 App Widget+app应⽤。就是⼀个程序既可以通过App Widget启动，也可以通过App启动。App Widget  
 就是⼀个AppWidgetProvider+⼀个UI界⾯显⽰(预先绑定了好多Intent)，界⾯上的信息可以通过程序控制⽽改变，  
 单击Widget上的控件只能激发发送⼀个Intent，  
 或发出⼀个Service的启动通知。⽽AppWidgetProvider可以拦截这个Intent，⽽进⾏相应的处理(⽐如显⽰新的信息)。  
 App Widget启动  
 长按空⽩的桌⾯主屏幕会弹出“添加到主屏幕”，然后选择“窗⼝⼩部件”选项进⼊“选择窗⼝⼩部件”，最后选择  
 想要的⼩部件就会添加到桌⾯主屏幕，当点击刚才添加的桌⾯控件就会进⼊到程序主⼊⼝  
 在Launcher3中的首页App Widget小部件一般是通过加载default\_workspace\_4x4.xml等相关的布局文件信息，保存到数据  
 库里面，然后通过加载App Widget信息来显示这些小部件的，接下来看下default\_workspace\_4x4.xml的相关布局控件的  
 加载方法


## 3.1 default\_workspace\_4x4.xml等相关控件源码分析



```
<favorites xmlns:launcher="http://schemas.android.com/apk/res-auto/com.android.launcher3">

    <appwidget
       launcher:packageName="com.android.deskclock"
       launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"
       launcher:screen="0"
       launcher:x="1"
       launcher:y="1"
       launcher:spanX="2"
       launcher:spanY="2"
    />
    <!-- Hotseat (We use the screen as the position of the item in the hotseat) -->
    <!-- Dialer, Messaging, Browser, Camera -->
    <resolve
        launcher:container="-101"
        launcher:screen="0"
        launcher:x="0"
        launcher:y="0" >
         <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_MAPS;end" />
         <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_MUSIC;end" />
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="1"
        launcher:x="1"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_GALLERY;end" />
        <favorite launcher:uri="#Intent;type=images/*;end" />
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="3"
        launcher:x="3"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.settings.SETTINGS;category=android.intent.category.DEFAULT;end"/>
    </resolve>

    <resolve
        launcher:container="-101"
        launcher:screen="2"
        launcher:x="2"
        launcher:y="0" >
        <favorite launcher:uri="#Intent;action=android.media.action.STILL_IMAGE_CAMERA;end" />
        <favorite launcher:uri="#Intent;action=android.intent.action.CAMERA_BUTTON;end" />
    </resolve>

    <!-- Bottom row -->
    <resolve
        launcher:screen="0"
        launcher:x="0"
        launcher:y="-1" >
        <favorite launcher:uri="#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_EMAIL;end" />
        <favorite launcher:uri="mailto:" />
    </resolve>
...
</favorites>
```

在上述的default\_workspace\_4x4.xml的相关布局控件的源码分析得知，在这里通过在Launcher3中的LoaderTask.java等相关  
 读取数据加载类信息，在初步加载桌面显示的相关控件显示信息的时候，会通过控件标签appwidget resolve favorite等相关  
 标签来添加相关的控件信息到数据库，然后每次重启的时候重新从数据库中读取信息然后绑定到桌面workspace显示相关的  
 控件，在这个default\_workspace\_4x4.xml的布局文件中，<appwidget  
        launcher:packageName="com.android.deskclock"  
        launcher:className="com.android.alarmclock.DigitalAppWidgetProvider"这个就是关于桌面时钟的控件，它指向的  
 是引用com.android.deskclock时钟app里面的小部件显示在桌面布局的，所以具体的时钟部件构造信息需要到  
 com.android.alarmclock.DigitalAppWidgetProvider来分析相关的信息显示，接下来分析下DigitalAppWidgetProvider.java  
 的相关信息


## 3.2 DigitalAppWidgetProvider的相关信息分析


通过看源码发现DigitalAppWidgetProvider是继承于AppWidgetProvider，而AppWidgetProvider是一个Android组件，  
 用于创建和管理开发者的小部件（widget）的，在这个类中relayoutWidget来具体负责对小部件的布局的排版  
 所以需要具体分析这个方法



```
      private static RemoteViews relayoutWidget(Context context, AppWidgetManager wm, int widgetId,
              Bundle options, boolean portrait) {
          // Create a remote view for the digital clock.
          final String packageName = context.getPackageName();
          final RemoteViews rv = new RemoteViews(packageName, R.layout.digital_widget);
  
          // Tapping on the widget opens the app (if not on the lock screen).
          if (Utils.isWidgetClickable(wm, widgetId)) {
              final Intent openApp = new Intent(context, DeskClock.class);
              final PendingIntent pi = PendingIntent.getActivity(context, 0, openApp, 0);
              rv.setOnClickPendingIntent(R.id.digital_widget, pi);
          }
  
          // Configure child views of the remote view.
          final CharSequence dateFormat = getDateFormat(context);
          rv.setCharSequence(R.id.date, "setFormat12Hour", dateFormat);
          rv.setCharSequence(R.id.date, "setFormat24Hour", dateFormat);
  
          final String nextAlarmTime = Utils.getNextAlarm(context);
          if (TextUtils.isEmpty(nextAlarmTime)) {
              rv.setViewVisibility(R.id.nextAlarm, GONE);
              rv.setViewVisibility(R.id.nextAlarmIcon, GONE);
          } else  {
              rv.setTextViewText(R.id.nextAlarm, nextAlarmTime);
              rv.setViewVisibility(R.id.nextAlarm, VISIBLE);
              rv.setViewVisibility(R.id.nextAlarmIcon, VISIBLE);
          }
  
          if (options == null) {
              options = wm.getAppWidgetOptions(widgetId);
          }
  
          // Fetch the widget size selected by the user.
          final Resources resources = context.getResources();
          final float density = resources.getDisplayMetrics().density;
          final int minWidthPx = (int) (density * options.getInt(OPTION_APPWIDGET_MIN_WIDTH));
          final int minHeightPx = (int) (density * options.getInt(OPTION_APPWIDGET_MIN_HEIGHT));
          final int maxWidthPx = (int) (density * options.getInt(OPTION_APPWIDGET_MAX_WIDTH));
          final int maxHeightPx = (int) (density * options.getInt(OPTION_APPWIDGET_MAX_HEIGHT));
          final int targetWidthPx = portrait ? minWidthPx : maxWidthPx;
          final int targetHeightPx = portrait ? maxHeightPx : minHeightPx;
          final int largestClockFontSizePx =
                  resources.getDimensionPixelSize(R.dimen.widget_max_clock_font_size);
  
          // Create a size template that describes the widget bounds.
          final Sizes template = new Sizes(targetWidthPx, targetHeightPx, largestClockFontSizePx);
  
          // Compute optimal font sizes and icon sizes to fit within the widget bounds.
          final Sizes sizes = optimizeSizes(context, template, nextAlarmTime);
          if (LOGGER.isVerboseLoggable()) {
              LOGGER.v(sizes.toString());
          }
  
          // Apply the computed sizes to the remote views.
          rv.setImageViewBitmap(R.id.nextAlarmIcon, sizes.mIconBitmap);
 -         rv.setTextViewTextSize(R.id.date, COMPLEX_UNIT_PX, sizes.mFontSizePx);
  +        rv.setTextViewTextSize(R.id.date, COMPLEX_UNIT_PX, sizes.mFontSizePx*2);
          rv.setTextViewTextSize(R.id.nextAlarm, COMPLEX_UNIT_PX, sizes.mFontSizePx);
 -         rv.setTextViewTextSize(R.id.clock, COMPLEX_UNIT_PX, sizes.mClockFontSizePx);
+          rv.setTextViewTextSize(R.id.clock, COMPLEX_UNIT_PX, sizes.mClockFontSizePx*1.3);
  
          final int smallestWorldCityListSizePx =
                  resources.getDimensionPixelSize(R.dimen.widget_min_world_city_list_size);
          if (sizes.getListHeight() <= smallestWorldCityListSizePx) {
              // Insufficient space; hide the world city list.
              rv.setViewVisibility(R.id.world_city_list, GONE);
          } else {
              // Set an adapter on the world city list. That adapter connects to a Service via intent.
              final Intent intent = new Intent(context, DigitalAppWidgetCityService.class);
              intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
              intent.setData(Uri.parse(intent.toUri(Intent.URI_INTENT_SCHEME)));
              rv.setRemoteAdapter(R.id.world_city_list, intent);
              rv.setViewVisibility(R.id.world_city_list, VISIBLE);
  
              // Tapping on the widget opens the city selection activity (if not on the lock screen).
              if (Utils.isWidgetClickable(wm, widgetId)) {
                  final Intent selectCity = new Intent(context, CitySelectionActivity.class);
                  final PendingIntent pi = PendingIntent.getActivity(context, 0, selectCity, 0);
                  rv.setPendingIntentTemplate(R.id.world_city_list, pi);
              }
          }
  
          return rv;
      }
  
```

在上述的DigitalAppWidgetProvider.java的相关源码中分析得知，在这里通过relayoutWidget(Context context, AppWidgetManager wm, int widgetId,  
               Bundle options, boolean portrait)来构造Launcher3桌面时钟小部件的相关布局的，所以可以从上述的  
 rv.setTextViewTextSize(R.id.date, COMPLEX\_UNIT\_PX, sizes.mFontSizePx);分析得知这里就是构造时钟部件的日期的字体大小的相关  
 代码，所以可以修改为自己需要的字体大小，同样的          rv.setTextViewTextSize(R.id.clock, COMPLEX\_UNIT\_PX, sizes.mClockFontSizePx);  
 就是桌面时钟小部件 时间的字体大小可以根据需要修改成相关的大小，这样就实现了功能需求



