



## 1. 前言


在10.0的定制开发中，在系统中，对于后台运行的app过多的时候，会比较耗内存，导致系统运行有可能会卡顿，所以在系统优化的  
 过程中，会限制后台app进程运行的数量，来保证系统流畅不影响体验，所以需要分析下系统中关于限制app进程的相关源码来实现  
 功能


![](https://img-blog.csdnimg.cn/9a22ff0041334f8e8f8255acdbb79e53.png)


## 2.framework层设置后台运行app进程最大数功能实现的核心类



```
packages\apps\Settings\src\com\android\settings\development\BackgroundProcessLimitPreferenceController.java
packages\apps\Settings\res\xml\development_settings.xml
frameworks\base\services\core\java\com\android\server\policy\PhoneWindowManager.java
```

## 3.framework层设置后台运行app进程最大数功能实现的核心功能分析和实现


Android O开始对应用在后台运行时可以执行的操作施加了限制，称为后台执行限制（Background Execution Limits），这可以大大减少应用的内存使用和耗电量，提高用户体验。后台执行限制分为两个部分：  
 后台服务限制（Background Service Limitations）、广播限制（BroadcastLimitations）


当app在后台运行的服务在几分钟内会被stop掉（模拟器测试在1分钟左右后被kill掉）。在这段时间内，应用仍可以创建和使用服务


后台服务限制:后台应用程序无法创建随意长时间运行的服务。在后台运行的服务将在不到一分钟的时间内被停止。  
 然而,如果应用程序正在与用户进行交互,则可以运行服务,并且服务可以持续到与用户的交互结束


在系统Setting中的开发者模式中，偶然会看到关于选择后台限制app数量的选择弹框，所以可以从这里出发，分析源码  
 看怎么实现这个功能，接下来分析下源码


## 3.1 development\_settings.xml中关于后台限制app的空间分析



```
    <PreferenceCategory
        android:key="debug_applications_category"
        android:title="@string/debug_applications_category"
        android:order="1000">

        <SwitchPreference
            android:key="immediately_destroy_activities"
            android:title="@string/immediately_destroy_activities"
            android:summary="@string/immediately_destroy_activities_summary" />

        <ListPreference
            android:key="app_process_limit"
            android:title="@string/app_process_limit_title"
            android:entries="@array/app_process_limit_entries"
            android:entryValues="@array/app_process_limit_values" />

        <Preference
            android:key="background_check"
            android:fragment="com.android.settings.applications.appops.BackgroundCheckSummary"
            android:title="@string/background_check_pref" />

        <SwitchPreference
            android:key="show_first_crash_dialog"
            android:title="@string/show_first_crash_dialog"
            android:summary="@string/show_first_crash_dialog_summary" />

        <SwitchPreference
            android:key="show_all_anrs"
            android:title="@string/show_all_anrs"
            android:summary="@string/show_all_anrs_summary" />

        <SwitchPreference
            android:key="show_notification_channel_warnings"
            android:title="@string/show_notification_channel_warnings"
            android:summary="@string/show_notification_channel_warnings_summary" />

        <SwitchPreference
            android:key="asst_capability_prioritizer"
            android:title="@string/asst_capability_prioritizer_title"
            settings:controller="com.android.settings.notification.AssistantCapabilityPreferenceController" />

        <Preference
            android:key="inactive_apps"
            android:title="@string/inactive_apps_title"
            android:fragment="com.android.settings.fuelgauge.InactiveApps" />

        <SwitchPreference
            android:key="force_allow_on_external"
            android:title="@string/force_allow_on_external"
            android:summary="@string/force_allow_on_external_summary" />

        <SwitchPreference
            android:key="force_resizable_activities"
            android:title="@string/force_resizable_activities"
            android:summary="@string/force_resizable_activities_summary" />

        <SwitchPreference
            android:key="enable_freeform_support"
            android:title="@string/enable_freeform_support"
            android:summary="@string/enable_freeform_support_summary" />

        <SwitchPreference
            android:key="force_desktop_mode_on_external_displays"
            android:title="@string/force_desktop_mode"
            android:summary="@string/force_desktop_mode_summary" />

        <Preference
            android:key="reset_shortcut_manager_throttling"
            android:title="@string/reset_shortcut_manager_throttling" />

        <SwitchPreference
            android:key="sms_access_restriction_enabled"
            android:title="@string/sms_access_restriction_enabled"
            android:summary="@string/sms_access_restriction_enabled_summary" />

        <SwitchPreference
            android:key="notification_bubbles"
            android:title="@string/notification_bubbles_title"
            android:summary="@string/notification_bubbles_developer_setting_summary"/>

    </PreferenceCategory>
```

在上述的development\_settings.xml中的相关源码中，通过搜索相关的关键词发现在app\_process\_limit这个ListPreference  
 就是后台限制app的list列表选项功能，所以可以说在点击这个控件的时候，就会弹出选择框来选择哪个限制app后台运行的  
 数量，而它的处理具体功能是在BackgroundProcessLimitPreferenceController.java中处理的，所以接下来分析下  
 BackgroundProcessLimitPreferenceController.java的相关源码


## 3.2 BackgroundProcessLimitPreferenceController.java的相关源码分析



```
public class BackgroundProcessLimitPreferenceController extends
        DeveloperOptionsPreferenceController implements Preference.OnPreferenceChangeListener,
        PreferenceControllerMixin {

    public boolean onPreferenceChange(Preference preference, Object newValue) {
        writeAppProcessLimitOptions(newValue);
        updateAppProcessLimitOptions();
        return true;
    }

    @Override
    public void updateState(Preference preference) {
        updateAppProcessLimitOptions();
    }

    @Override
    protected void onDeveloperOptionsSwitchDisabled() {
        super.onDeveloperOptionsSwitchDisabled();
        writeAppProcessLimitOptions(null);
    }

    private void updateAppProcessLimitOptions() {
        try {
            final int limit = getActivityManagerService().getProcessLimit();
            int index = 0; // default
            for (int i = 0; i < mListValues.length; i++) {
                int val = Integer.parseInt(mListValues[i]);
                if (val >= limit) {
                    index = i;
                    break;
                }
            }
            final ListPreference listPreference = (ListPreference) mPreference;
            listPreference.setValue(mListValues[index]);
            listPreference.setSummary(mListSummaries[index]);
        } catch (RemoteException e) {
            // intentional no-op
        }
    }

    private void writeAppProcessLimitOptions(Object newValue) {
        try {
            final int limit = newValue != null ? Integer.parseInt(newValue.toString()) : -1;
            getActivityManagerService().setProcessLimit(limit);
            updateAppProcessLimitOptions();
        } catch (RemoteException e) {
            // intentional no-op
        }
    }

```

在BackgroundProcessLimitPreferenceController.java中的上述源码中，通过分析得知，在  
 onPreferenceChange(Preference preference, Object newValue)中通过监听ListPreference  
 这个控件的改变，然后根据选择项的值，来调用writeAppProcessLimitOptions(newValue);来  
 设置后台app运行限制的数量，在writeAppProcessLimitOptions(newValue);中具体调用  
 getActivityManagerService().setProcessLimit(limit);通过这里可以看出，关于限制app后台运行数量  
 的功能其实是在ActivityManagerService中的setProcessLimit(limit)的方法，所以可以通过  
 调用这个方法来实现功能


## 3.3 PhoneWindowManager.java中设置默认后台限制app数量功能



```
   /** {@inheritDoc} */
    @Override
    public void systemReady() {
        // In normal flow, systemReady is called before other system services are ready.
        // So it is better not to bind keyguard here.
        mKeyguardDelegate.onSystemReady();

        Settings.System.putInt(mContext.getContentResolver(),
                Settings.System.TIGO_CMAS_STATUS, 0);

        mVrManagerInternal = LocalServices.getService(VrManagerInternal.class);
        if (mVrManagerInternal != null) {
            mVrManagerInternal.addPersistentVrModeStateListener(mPersistentVrModeListener);
        }

......
// add core start
        try {
            ActivityManager.getService().setProcessLimit(2);
        } catch (Exception e) {
            e.printStackTrace();
        }
// add core end

```

在上述的PhoneWindowManager.java中相关源码中，在系统核心服务启动完毕后，在systemReady()中  
 这时候添加ActivityManager.getService().setProcessLimit(2); 来表示设置限制app启动后台的数量  
 就是2个，超过2个系统就会自动杀掉以前的进程保此后台的app数量最多为2个，所以就需要  
 保证后台app的数量不超过2个，就实现了后台app数量的限制



