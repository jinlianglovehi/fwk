




## 1.1概述


 在10.0的rom定制化开发中，由于Launcher3有一些功能需要定制，这样的需求也好多的，现在功能需求要求桌面固定在Launcher3的app列表页，不让左右移动，就是禁止左右移动的功能实现，所以需要禁止滑动分析页面滑动部分的功能，然后禁用


## 2.1Launcher3桌面禁止左右滑动的核心代码



```
  packages\apps\Launcher3\src\com\android\launcher3\PagedView.java
  packages\apps\Launcher3\src\com\android\launcher3\allapps\AllAppsPagedView.java
  packages/apps/Launcher3/src/com/android/launcher3/allapps/AllAppsContainerView.java
```

## 3.Launcher3桌面禁止左右滑动的功能分析以及功能实现


##  3.1 AllAppsPagedView.java关于app列表页app绑定功能分析



```
    public class AllAppsPagedView extends PagedView<PersonalWorkSlidingTabStrip> {

  final static float START_DAMPING_TOUCH_SLOP_ANGLE = (float) Math.PI / 6;
  final static float MAX_SWIPE_ANGLE = (float) Math.PI / 3;
  final static float TOUCH_SLOP_DAMPING_FACTOR = 4;

  public AllAppsPagedView(Context context) {
        this(context, null);
    }

    public AllAppsPagedView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AllAppsPagedView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected String getCurrentPageDescription() {
        // Not necessary, tab-bar already has two tabs with their own descriptions.
        return "";
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        mPageIndicator.setScroll(l, mMaxScrollX);
    }

    @Override
    protected void determineScrollingStart(MotionEvent ev) {
        float absDeltaX = Math.abs(ev.getX() - getDownMotionX());
        float absDeltaY = Math.abs(ev.getY() - getDownMotionY());

        if (Float.compare(absDeltaX, 0f) == 0) return;

        float slope = absDeltaY / absDeltaX;
        float theta = (float) Math.atan(slope);

        if (absDeltaX > mTouchSlop || absDeltaY > mTouchSlop) {
            cancelCurrentPageLongPress();
        }

        if (theta > MAX_SWIPE_ANGLE) {
            return;
        } else if (theta > START_DAMPING_TOUCH_SLOP_ANGLE) {
            theta -= START_DAMPING_TOUCH_SLOP_ANGLE;
            float extraRatio = (float)
                    Math.sqrt((theta / (MAX_SWIPE_ANGLE - START_DAMPING_TOUCH_SLOP_ANGLE)));
            super.determineScrollingStart(ev, 1 + TOUCH_SLOP_DAMPING_FACTOR * extraRatio);
        } else {
            super.determineScrollingStart(ev);
        }
    }

    @Override
    public boolean hasOverlappingRendering() {
        return false;
    }
}
```

app列表页的AllAppsPagedView是PagedView的子类 关于左右滑动的事件处理不在这里，都是在PagedView中


实现的,AllAppsPagedView在AllAppsContainerView为apps布局


## 3.2 AllAppsContainerView中关于布局的相关代码



```
        // 绑定apps列表布局
         private void rebindAdapters(boolean showTabs, boolean force) {
        if (showTabs == mUsingTabs && !force) {
            return;
        }
        replaceRVContainer(showTabs);
        mUsingTabs = showTabs;

        mAllAppsStore.unregisterIconContainer(mAH[AdapterHolder.MAIN].recyclerView);
        mAllAppsStore.unregisterIconContainer(mAH[AdapterHolder.WORK].recyclerView);

        if (mUsingTabs) {
            mAH[AdapterHolder.MAIN].setup(mViewPager.getChildAt(0), mPersonalMatcher);
            mAH[AdapterHolder.WORK].setup(mViewPager.getChildAt(1), mWorkMatcher);
            onTabChanged(mViewPager.getNextPage());
        } else {
            mAH[AdapterHolder.MAIN].setup(findViewById(R.id.apps_list_view), null);
            mAH[AdapterHolder.WORK].recyclerView = null;
        }
        setupHeader();

        mAllAppsStore.registerIconContainer(mAH[AdapterHolder.MAIN].recyclerView);
        mAllAppsStore.registerIconContainer(mAH[AdapterHolder.WORK].recyclerView);
    }
// 为布局也选xml布局文件
    private void replaceRVContainer(boolean showTabs) {
        for (int i = 0; i < mAH.length; i++) {
            if (mAH[i].recyclerView != null) {
                mAH[i].recyclerView.setLayoutManager(null);
            }
        }
        View oldView = getRecyclerViewContainer();
        int index = indexOfChild(oldView);
        removeView(oldView);
       //根据showTabs的值来判断需要哪个布局
        int layout = showTabs ? R.layout.all_apps_tabs : R.layout.all_apps_rv_layout;
        View newView = LayoutInflater.from(getContext()).inflate(layout, this, false);
        addView(newView, index);
        if (showTabs) {
            mViewPager = (AllAppsPagedView) newView;
            mViewPager.initParentViews(this);
            mViewPager.getPageIndicator().setContainerView(this);
        } else {
            mViewPager = null;
        }
    }
```

在AllAppsContainerView.java中的上述源码中，在rebindAdapters(boolean showTabs, boolean force)方法中主要是绑定app的列表，而在replaceRVContainer(boolean showTabs) 中的主要功能


就是选择合适的xml文件


## 3.3 PagedView.java的相关左右滑动的相关布局



```
   /**
 * An abstraction of the original Workspace which supports browsing through a
 * sequential list of "pages"
 */
public abstract class PagedView<T extends View & PageIndicator> extends ViewGroup {
    private static final String TAG = "PagedView";
    private static final boolean DEBUG = false;

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        // Skip touch handling if there are no pages to swipe
        if (getChildCount() <= 0 || shouldDisableGestures(ev)) return false;

        acquireVelocityTrackerAndAddMovement(ev);

        final int action = ev.getAction();

        switch (action & MotionEvent.ACTION_MASK) {
        case MotionEvent.ACTION_DOWN:
            /*
             * If being flinged and user touches, stop the fling. isFinished
             * will be false if being flinged.
             */
            if (!mScroller.isFinished()) {
                abortScrollerAnimation(false);
            }

            // Remember where the motion event started
            mDownMotionX = mLastMotionX = ev.getX();
            mDownMotionY = ev.getY();
            mLastMotionXRemainder = 0;
            mTotalMotionX = 0;
            mActivePointerId = ev.getPointerId(0);

            if (mIsBeingDragged) {
                onScrollInteractionBegin();
                pageBeginTransition();
            }
            break;

        case MotionEvent.ACTION_MOVE:
            if (mIsBeingDragged) {
                // Scroll to follow the motion event
                final int pointerIndex = ev.findPointerIndex(mActivePointerId);

                if (pointerIndex == -1) return true;

                final float x = ev.getX(pointerIndex);
                final float deltaX = mLastMotionX + mLastMotionXRemainder - x;

                mTotalMotionX += Math.abs(deltaX);

                // Only scroll and update mLastMotionX if we have moved some discrete amount.  We
                // keep the remainder because we are actually testing if we've moved from the last
                // scrolled position (which is discrete).
                if (Math.abs(deltaX) >= 1.0f) {
                    scrollBy((int) deltaX, 0);
                    mLastMotionX = x;
                    mLastMotionXRemainder = deltaX - (int) deltaX;
                } else {
                    awakenScrollBars();
                }
            } else {
                determineScrollingStart(ev);
            }
            break;

        case MotionEvent.ACTION_UP:
            if (mIsBeingDragged) {
                final int activePointerId = mActivePointerId;
                final int pointerIndex = ev.findPointerIndex(activePointerId);
                final float x = ev.getX(pointerIndex);
                final VelocityTracker velocityTracker = mVelocityTracker;
                velocityTracker.computeCurrentVelocity(1000, mMaximumVelocity);
                int velocityX = (int) velocityTracker.getXVelocity(mActivePointerId);
                final int deltaX = (int) (x - mDownMotionX);
                final int pageWidth = getPageAt(mCurrentPage).getMeasuredWidth();
                boolean isSignificantMove = Math.abs(deltaX) > pageWidth *
                        SIGNIFICANT_MOVE_THRESHOLD;

                mTotalMotionX += Math.abs(mLastMotionX + mLastMotionXRemainder - x);
                boolean isFling = mTotalMotionX > mTouchSlop && shouldFlingForVelocity(velocityX);
                boolean isDeltaXLeft = mIsRtl ? deltaX > 0 : deltaX < 0;
                boolean isVelocityXLeft = mIsRtl ? velocityX > 0 : velocityX < 0;

                if (!mFreeScroll) {// 处理左右滑动
                    // In the case that the page is moved far to one direction and then is flung
                    // in the opposite direction, we use a threshold to determine whether we should
                    // just return to the starting page, or if we should skip one further.
                    boolean returnToOriginalPage = false;
                    //根据滑动距离判断是否滑动到下一页
             if (Math.abs(deltaX) > pageWidth * RETURN_TO_ORIGINAL_PAGE_THRESHOLD &&
                            Math.signum(velocityX) != Math.signum(deltaX) && isFling) {
                        returnToOriginalPage = true;
                    }

                    int finalPage;
                    // We give flings precedence over large moves, which is why we short-circuit our
                    // test for a large move if a fling has been registered. That is, a large
                    // move to the left and fling to the right will register as a fling to the right.
// 根据当前页处理滑动到下一页 由snapToPageWithVelocity（）处理滑动到下一页
                    if (((isSignificantMove && !isDeltaXLeft && !isFling) ||
                            (isFling && !isVelocityXLeft))
                            && mCurrentPage > getMinPageIndex()) {
                        finalPage = returnToOriginalPage ? mCurrentPage : mCurrentPage - 1;
                        snapToPageWithVelocity(finalPage, velocityX);
                    } else if (((isSignificantMove && isDeltaXLeft && !isFling) ||
                            (isFling && isVelocityXLeft)) &&
                            mCurrentPage < getMaxPageIndex()) {
                        finalPage = returnToOriginalPage ? mCurrentPage : mCurrentPage + 1;
                        snapToPageWithVelocity(finalPage, velocityX);
                    } else {
                        snapToDestination();
                    }
                } else {
                    if (!mScroller.isFinished()) {
                        abortScrollerAnimation(true);
                    }

                    int initialScrollX = getScrollX();

                    if (((initialScrollX >= mMaxScrollX) && (isVelocityXLeft || !isFling)) ||
                            ((initialScrollX <= mMinScrollX) && (!isVelocityXLeft || !isFling))) {
                        mScroller.springBack(getScrollX(), mMinScrollX, mMaxScrollX);
                        mNextPage = getPageNearestToCenterOfScreen();
                    } else {
                        mScroller.setInterpolator(mDefaultInterpolator);
                  //滑动范围
                        mScroller.fling(initialScrollX, -velocityX,
                                mMinScrollX, mMaxScrollX,
                                Math.round(getWidth() * 0.5f * OVERSCROLL_DAMP_FACTOR));

                        int finalX = mScroller.getFinalPos();
                          //获取下一页
                        mNextPage = getPageNearestToCenterOfScreen(finalX);

                        int firstPageScroll = getScrollForPage(!mIsRtl ? 0 : getPageCount() - 1);
                        int lastPageScroll = getScrollForPage(!mIsRtl ? getPageCount() - 1 : 0);
                        if (finalX > mMinScrollX && finalX < mMaxScrollX) {
                            // If scrolling ends in the half of the added space that is closer to
                            // the end, settle to the end. Otherwise snap to the nearest page.
                            // If flinging past one of the ends, don't change the velocity as it
                            // will get stopped at the end anyway.
                            int pageSnappedX = finalX < (firstPageScroll + mMinScrollX) / 2
                                    ? mMinScrollX
                                    : finalX > (lastPageScroll + mMaxScrollX) / 2
                                            ? mMaxScrollX
                                            : getScrollForPage(mNextPage);

                            mScroller.setFinalPos(pageSnappedX);
                            // Ensure the scroll/snap doesn't happen too fast;
                            int extraScrollDuration = OVERSCROLL_PAGE_SNAP_ANIMATION_DURATION
                                    - mScroller.getDuration();
                            if (extraScrollDuration > 0) {
                                mScroller.extendDuration(extraScrollDuration);
                            }
                        }
                    }
                    invalidate();
                }
                onScrollInteractionEnd();
            }

            // End any intermediate reordering states
            resetTouchState();
            break;

        case MotionEvent.ACTION_CANCEL:
            if (mIsBeingDragged) {
                snapToDestination();
                onScrollInteractionEnd();
            }
            resetTouchState();
            break;

        case MotionEvent.ACTION_POINTER_UP:
            onSecondaryPointerUp(ev);
            releaseVelocityTracker();
            break;
        }

        return true;
    }
```

在上述的PagedView.java的相关方法中，onTouchEvent(MotionEvent ev)事件为处理滑动事件，


而在case MotionEvent.ACTION\_UP是处理


滑动事件停止后处理相关事件，


mScroller.fling(initialScrollX, -velocityX,


 mMinScrollX, mMaxScrollX,


 Math.round(getWidth() \* 0.5f \* OVERSCROLL\_DAMP\_FACTOR));


处理滑动距离，而在mNextPage = getPageNearestToCenterOfScreen(finalX);中处理下一页的


相关功能


具体修改为:



```
@Override
    public boolean onTouchEvent(MotionEvent ev) {
        // Skip touch handling if there are no pages to swipe
        if (getChildCount() <= 0 || shouldDisableGestures(ev)) return false;

        acquireVelocityTrackerAndAddMovement(ev);

        final int action = ev.getAction();

        switch (action & MotionEvent.ACTION_MASK) {
        case MotionEvent.ACTION_DOWN:
            /*
             * If being flinged and user touches, stop the fling. isFinished
             * will be false if being flinged.
             */
            if (!mScroller.isFinished()) {
                abortScrollerAnimation(false);
            }

            // Remember where the motion event started
            mDownMotionX = mLastMotionX = ev.getX();
            mDownMotionY = ev.getY();
            mLastMotionXRemainder = 0;
            mTotalMotionX = 0;
            mActivePointerId = ev.getPointerId(0);

            if (mIsBeingDragged) {
                onScrollInteractionBegin();
                pageBeginTransition();
            }
            break;

        case MotionEvent.ACTION_MOVE:
            if (mIsBeingDragged) {
                // Scroll to follow the motion event
                final int pointerIndex = ev.findPointerIndex(mActivePointerId);

                if (pointerIndex == -1) return true;

                final float x = ev.getX(pointerIndex);
                final float deltaX = mLastMotionX + mLastMotionXRemainder - x;

                mTotalMotionX += Math.abs(deltaX);

                // Only scroll and update mLastMotionX if we have moved some discrete amount.  We
                // keep the remainder because we are actually testing if we've moved from the last
                // scrolled position (which is discrete).
                if (Math.abs(deltaX) >= 1.0f) {
                    scrollBy((int) deltaX, 0);
                    mLastMotionX = x;
                    mLastMotionXRemainder = deltaX - (int) deltaX;
                } else {
                    awakenScrollBars();
                }
            } else {
                determineScrollingStart(ev);
            }
            break;

        case MotionEvent.ACTION_UP:
            if (mIsBeingDragged) {
                final int activePointerId = mActivePointerId;
                final int pointerIndex = ev.findPointerIndex(activePointerId);
                final float x = ev.getX(pointerIndex);
                final VelocityTracker velocityTracker = mVelocityTracker;
                velocityTracker.computeCurrentVelocity(1000, mMaximumVelocity);
                int velocityX = (int) velocityTracker.getXVelocity(mActivePointerId);
                final int deltaX = (int) (x - mDownMotionX);
                final int pageWidth = getPageAt(mCurrentPage).getMeasuredWidth();
                boolean isSignificantMove = Math.abs(deltaX) > pageWidth *
                        SIGNIFICANT_MOVE_THRESHOLD;

                mTotalMotionX += Math.abs(mLastMotionX + mLastMotionXRemainder - x);
                boolean isFling = mTotalMotionX > mTouchSlop && shouldFlingForVelocity(velocityX);
                boolean isDeltaXLeft = mIsRtl ? deltaX > 0 : deltaX < 0;
                boolean isVelocityXLeft = mIsRtl ? velocityX > 0 : velocityX < 0;

                if (!mFreeScroll) {// 处理左右滑动
                    // In the case that the page is moved far to one direction and then is flung
                    // in the opposite direction, we use a threshold to determine whether we should
                    // just return to the starting page, or if we should skip one further.
                    boolean returnToOriginalPage = false;
                    //根据滑动距离判断是否滑动到下一页
             if (Math.abs(deltaX) > pageWidth * RETURN_TO_ORIGINAL_PAGE_THRESHOLD &&
                            Math.signum(velocityX) != Math.signum(deltaX) && isFling) {
                        //returnToOriginalPage = true;
                    }

// add core start  处理滑动事件 滑动到当前页面
                    if(FeatureFlags.ALL_APPS_TABS_ENABLED){
                        Log.e(TAG, "into MotionEvent.ACTION_UP ==>>"+action);
                        //returnToOriginalPage = true;
                        snapToPageWithVelocity(mCurrentPage, velocityX);
                    }
//add core end
                    int finalPage;
                    // We give flings precedence over large moves, which is why we short-circuit our
                    // test for a large move if a fling has been registered. That is, a large
                    // move to the left and fling to the right will register as a fling to the right.
// 根据当前页处理滑动到下一页 由snapToPageWithVelocity（）处理滑动到下一页 注释掉这部分代码
                    /*if (((isSignificantMove && !isDeltaXLeft && !isFling) ||
                            (isFling && !isVelocityXLeft))
                            && mCurrentPage > getMinPageIndex()) {
                        finalPage = returnToOriginalPage ? mCurrentPage : mCurrentPage - 1;
                        snapToPageWithVelocity(finalPage, velocityX);
                    } else if (((isSignificantMove && isDeltaXLeft && !isFling) ||
                            (isFling && isVelocityXLeft)) &&
                            mCurrentPage < getMaxPageIndex()) {
                        finalPage = returnToOriginalPage ? mCurrentPage : mCurrentPage + 1;
                        snapToPageWithVelocity(finalPage, velocityX);
                    } else {
                        snapToDestination();
                    }*/
                } else {
                    if (!mScroller.isFinished()) {
                        abortScrollerAnimation(true);
                    }
...
```




