



## 1.前言


 在10.0的系统定制化开发中，在app中多窗口模式中，分屏模式也是其中的一种模式，可以通过app内部设置分屏的属性，然后实现  
 app启动的时候分屏功能，在无源码的app中就没办法更改。就需要在安装的时候修改这个属性，接下来实现这个功能


## 2.framework中禁止某个无源码app使用分屏功能的核心类



```
frameworks\base\core\java\android\content\pm\PackageParser.java
```

## 3.framework中禁止某个无源码app使用分屏功能的核心功能分析和实现


PMS（PackageManagerService）是Android提供的包管理系统服务，它用来管理所有的包信息，包括应用安装、  
 卸载、更新以及解析AndroidManifest.xml。通过解析每个安装应用的AndroidManifest.xml，将xml中的数据  
 全部都保存起来，后续提供给AMS所需要的数据，它是具有保存应用数据的缓存


PackageParser为Activity、Service、Provider、Permission等构件在其内部以内部类的方式 创建了对应的类，然后封装成属性的对象  
 PackageParser是使用的XMLPullParser工具来对XML进行解析的,然后分别通过android.content.pm下各种xxxInfo类来进行封装  
  apk包中的AndroidManifest.xml文件包含了package的各种描述信息. 分析和获取这些信息的工作是由PackageParser完成的


## 3.1 PackageParser.java的相关源码分析


在framework中禁止某个无源码app使用分屏功能的实现中，在上述分析得知pms的核心功能，安装卸载解析app的相关信息，这些  
 主要就是由PackageParser.java来完成app的AndroidManifest.xml文件中的相关属性的解析功能，所以接下来主要分析下  
 PackageParser.java中的相关源码



```
     public Package parseMonolithicPackage(File apkFile, int flags) throws PackageParserException {
            final PackageLite lite = parseMonolithicPackageLite(apkFile, flags);
            if (mOnlyCoreApps) {
                if (!lite.coreApp) {
                    throw new PackageParserException(INSTALL_PARSE_FAILED_MANIFEST_MALFORMED,
                            "Not a coreApp: " + apkFile);
                }
            }
     
            final SplitAssetLoader assetLoader = new DefaultSplitAssetLoader(lite, flags);
            try {
                final Package pkg = parseBaseApk(apkFile, assetLoader.getBaseAssetManager(), flags);
                pkg.setCodePath(apkFile.getCanonicalPath());
                pkg.setUse32bitAbi(lite.use32bitAbi);
                return pkg;
            } catch (IOException e) {
                throw new PackageParserException(INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION,
                        "Failed to get path: " + apkFile, e);
            } finally {
                IoUtils.closeQuietly(assetLoader);
            }
        }
```

在framework中禁止某个无源码app使用分屏功能的实现中，  
 在PackageManager解析安装app的时候会首选调用parseMonolithicPackage(File apkFile, int flags)进行解析安装app，而在parseMonolithicPackage(File apkFile, int flags)中会调用parseBaseApk(apkFile, assetLoader.getBaseAssetManager(), flags)  
 解析app的，核心的解析Androidmanifest.xml的功能就是由parseBaseApk(apkFile, assetLoader.getBaseAssetManager(), flags)实现的，接下来看下源码



```
       @UnsupportedAppUsage(maxTargetSdk = Build.VERSION_CODES.P, trackingBug = 115609023)
        private Package parseBaseApk(String apkPath, Resources res, XmlResourceParser parser, int flags,
                String[] outError) throws XmlPullParserException, IOException {
            final String splitName;
            final String pkgName;
     
            try {
                Pair<String, String> packageSplit = parsePackageSplitNames(parser, parser);
                pkgName = packageSplit.first;
                splitName = packageSplit.second;
     
                if (!TextUtils.isEmpty(splitName)) {
                    outError[0] = "Expected base APK, but found split " + splitName;
                    mParseError = PackageManager.INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME;
                    return null;
                }
            } catch (PackageParserException e) {
                mParseError = PackageManager.INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME;
                return null;
            }
     
            if (mCallback != null) {
                String[] overlayPaths = mCallback.getOverlayPaths(pkgName, apkPath);
                if (overlayPaths != null && overlayPaths.length > 0) {
                    for (String overlayPath : overlayPaths) {
                        res.getAssets().addOverlayPath(overlayPath);
                    }
                }
            }
     
            final Package pkg = new Package(pkgName);
     
            TypedArray sa = res.obtainAttributes(parser,
                    com.android.internal.R.styleable.AndroidManifest);
     
            pkg.mVersionCode = sa.getInteger(
                    com.android.internal.R.styleable.AndroidManifest_versionCode, 0);
            pkg.mVersionCodeMajor = sa.getInteger(
                    com.android.internal.R.styleable.AndroidManifest_versionCodeMajor, 0);
            pkg.applicationInfo.setVersionCode(pkg.getLongVersionCode());
            pkg.baseRevisionCode = sa.getInteger(
                    com.android.internal.R.styleable.AndroidManifest_revisionCode, 0);
            pkg.mVersionName = sa.getNonConfigurationString(
                    com.android.internal.R.styleable.AndroidManifest_versionName, 0);
            if (pkg.mVersionName != null) {
                pkg.mVersionName = pkg.mVersionName.intern();
            }
     
            pkg.coreApp = parser.getAttributeBooleanValue(null, "coreApp", false);
     
            pkg.mCompileSdkVersion = sa.getInteger(
                    com.android.internal.R.styleable.AndroidManifest_compileSdkVersion, 0);
            pkg.applicationInfo.compileSdkVersion = pkg.mCompileSdkVersion;
            pkg.mCompileSdkVersionCodename = sa.getNonConfigurationString(
                    com.android.internal.R.styleable.AndroidManifest_compileSdkVersionCodename, 0);
            if (pkg.mCompileSdkVersionCodename != null) {
                pkg.mCompileSdkVersionCodename = pkg.mCompileSdkVersionCodename.intern();
            }
            pkg.applicationInfo.compileSdkVersionCodename = pkg.mCompileSdkVersionCodename;
     
            sa.recycle();
     
            return parseBaseApkCommon(pkg, null, res, parser, flags, outError);
        }
```

在framework中禁止某个无源码app使用分屏功能的实现中，在上述的PackageParser.java的相关源码中，  
 在parseBaseApk中最终调用的是parseBaseApkCommon(pkg, null, res, parser, flags, outError)  
 来继续解析app的xml内容，接下来分析下parseBaseApkCommon(pkg, null, res, parser, flags, outError)中的  
 相关源码



```
    private Package parseBaseApkCommon(Package pkg, Set<String> acceptedTags, Resources res,
                XmlResourceParser parser, int flags, String[] outError) throws XmlPullParserException,
                IOException {
            mParseInstrumentationArgs = null;
     
            int type;
            boolean foundApp = false;
     
            TypedArray sa = res.obtainAttributes(parser,
                    com.android.internal.R.styleable.AndroidManifest);
     
            String str = sa.getNonConfigurationString(
                    com.android.internal.R.styleable.AndroidManifest_sharedUserId, 0);
            if (str != null && str.length() > 0) {
                String nameError = validateName(str, true, true);
                if (nameError != null && !"android".equals(pkg.packageName)) {
                    outError[0] = "<manifest> specifies bad sharedUserId name \""
                        + str + "\": " + nameError;
                    mParseError = PackageManager.INSTALL_PARSE_FAILED_BAD_SHARED_USER_ID;
                    return null;
                }
                pkg.mSharedUserId = str.intern();
                pkg.mSharedUserLabel = sa.getResourceId(
                        com.android.internal.R.styleable.AndroidManifest_sharedUserLabel, 0);
            }
     
            pkg.installLocation = sa.getInteger(
                    com.android.internal.R.styleable.AndroidManifest_installLocation,
                    PARSE_DEFAULT_INSTALL_LOCATION);
            pkg.applicationInfo.installLocation = pkg.installLocation;
     
            final int targetSandboxVersion = sa.getInteger(
                    com.android.internal.R.styleable.AndroidManifest_targetSandboxVersion,
                    PARSE_DEFAULT_TARGET_SANDBOX);
            pkg.applicationInfo.targetSandboxVersion = targetSandboxVersion;
     
  
    ...
    }
```

在framework中禁止某个无源码app使用分屏功能的实现中，在上述的PackageParser.java的相关源码中，  
 在parseBaseApkCommon中继续解析xml文件 当tag为TAG\_APPLICATION即application的时候调用parseBaseApplication(pkg, res, parser, flags, outError)解析application的相关内容  
 所以继续追踪parseBaseApplication(pkg, res, parser, flags, outError)的相关源码，而这里又调用parseActivity(Package owner, Resources res,  
             XmlResourceParser parser, int flags, String[] outError, CachedComponentArgs cachedArgs,  
             boolean receiver, boolean hardwareAccelerated)来负责解析相关属性值，对于是否分屏的相关属性，  
 主要就是在setActivityResizeMode(ActivityInfo aInfo, TypedArray sa, Package owner)中继续处理的，接下来  
 分析下setActivityResizeMode(ActivityInfo aInfo, TypedArray sa, Package owner)的相关源码



```
   private void setActivityResizeMode(ActivityInfo aInfo, TypedArray sa, Package owner) {
        final boolean appExplicitDefault = (owner.applicationInfo.privateFlags
                & (PRIVATE_FLAG_ACTIVITIES_RESIZE_MODE_RESIZEABLE
                | PRIVATE_FLAG_ACTIVITIES_RESIZE_MODE_UNRESIZEABLE)) != 0;
// core start modify
-        if (sa.hasValue(R.styleable.AndroidManifestActivity_resizeableActivity)
-                || appExplicitDefault) {
+        if (!owner.packageName.equals("包名")&&(sa.hasValue(R.styleable.AndroidManifestActivity_resizeableActivity)
+                || appExplicitDefault)) {
// core end modify
            // Activity or app explicitly set if it is resizeable or not;
            final boolean appResizeable = (owner.applicationInfo.privateFlags
                    & PRIVATE_FLAG_ACTIVITIES_RESIZE_MODE_RESIZEABLE) != 0;
            if (sa.getBoolean(R.styleable.AndroidManifestActivity_resizeableActivity,
                    appResizeable)) {
                aInfo.resizeMode = RESIZE_MODE_RESIZEABLE;
            } else {
                aInfo.resizeMode = RESIZE_MODE_UNRESIZEABLE;
            }
            return;
        }

        if ((owner.applicationInfo.privateFlags
                & PRIVATE_FLAG_ACTIVITIES_RESIZE_MODE_RESIZEABLE_VIA_SDK_VERSION) != 0) {
            // The activity or app didn't explicitly set the resizing option, however we want to
            // make it resize due to the sdk version it is targeting.
            aInfo.resizeMode = RESIZE_MODE_RESIZEABLE_VIA_SDK_VERSION;
            return;
        }

        // resize preference isn't set and target sdk version doesn't support resizing apps by
        // default. For the app to be resizeable if it isn't fixed orientation or immersive.
        if (aInfo.isFixedOrientationPortrait()) {
            aInfo.resizeMode = RESIZE_MODE_FORCE_RESIZABLE_PORTRAIT_ONLY;
        } else if (aInfo.isFixedOrientationLandscape()) {
            aInfo.resizeMode = RESIZE_MODE_FORCE_RESIZABLE_LANDSCAPE_ONLY;
        } else if (aInfo.isFixedOrientation()) {
            aInfo.resizeMode = RESIZE_MODE_FORCE_RESIZABLE_PRESERVE_ORIENTATION;
        } else {
            aInfo.resizeMode = RESIZE_MODE_FORCE_RESIZEABLE;
        }
```

在framework中禁止某个无源码app使用分屏功能的实现中，在上述的PackageParser.java的相关源码中，  
 通过在setActivityResizeMode(ActivityInfo aInfo, TypedArray sa, Package owner) 方法中，关于解析  
 是否设置分屏模式的判断中，添加!owner.packageName.equals("包名")  
 这个判断，就额可以禁止某个app设置分屏模式了，然后就实现了功能



