



## 1.前言


  
  在10.0的系统rom产品开发定制中，在对一些产品开发中的配置需求方面，在产品后续订单中，产品提出要提高硬件配置，但是硬件方面已经定板，项目时间比较仓促，所以  
 来不及对硬件重新定制，就需要软件方面在ram运行内存的容量大小方面作假，修改ram真实的大小容量，所以就需要在kenel驱动部分或者ams中来修改这部分的值最好了，  
 接下来分析下计算ram容量的  
 相关代码，然后做出修改


获取ram容量大小和剩余使用内存的方法如下:  
 //运行内存



```
public  void getTotalRam(){
   //获取运行内存的信息
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);  
        MemoryInfo info = new MemoryInfo();  
        manager.getMemoryInfo(info);  
        StringBuilder sb = new StringBuilder();
        LogUtil.d("可用RAM:"+info.availMem/1024/1024 + "MB");
        LogUtil.d("总RAM:"+info.totalMem/1024/1024 + "MB");
}
```

## 2.kenel和frameworks中修改ram运行内存的两种方法的核心类



```
frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
frameworks/base/services/core/java/com/android/server/am/ProcessList.java
frameworks/base/core/jni/android_util_Process.cpp
kernel/kernel4.14/mm/page_alloc.c
```

## 3.kenel和frameworks中修改ram运行内存的两种方法的核心功能分析和实现 3.1 frameworks中关于获取ram内存容量的相关方法分析


 在AMS中获取ram的信息的方法，在通过上述代码中，可以看出就是在getMemoryInfo(info);中来获取  
 ram的容量大小信息的，具体代码如下:  
     @Override  
     public void getMemoryInfo(ActivityManager.MemoryInfo outInfo) {  
         mProcessList.getMemoryInfo(outInfo);  
     }


从上述的AMS的getMemoryInfo(ActivityManager.MemoryInfo outInfo)中的源码中，可以看出  
 具体获取ram容量大小的信息，就是在具体的ram容量的信息，是在ProcessList.getMemoryInfo(outInfo);中的  
 代码中



```
   void getMemoryInfo(ActivityManager.MemoryInfo outInfo) {
        final long homeAppMem = getMemLevel(HOME_APP_ADJ);
        final long cachedAppMem = getMemLevel(CACHED_APP_MIN_ADJ);
        outInfo.availMem = getFreeMemory();
        outInfo.totalMem = getTotalMemory();
        outInfo.threshold = homeAppMem;
        outInfo.lowMemory = outInfo.availMem < (homeAppMem + ((cachedAppMem-homeAppMem)/2));
        outInfo.hiddenAppThreshold = cachedAppMem;
        outInfo.secondaryServerThreshold = getMemLevel(SERVICE_ADJ);
        outInfo.visibleAppThreshold = getMemLevel(VISIBLE_APP_ADJ);
        outInfo.foregroundAppThreshold = getMemLevel(FOREGROUND_APP_ADJ);
    }

    ProcessRecord findAppProcessLocked(IBinder app, String reason) {
        final int NP = mProcessNames.getMap().size();
        for (int ip = 0; ip < NP; ip++) {
            SparseArray<ProcessRecord> apps = mProcessNames.getMap().valueAt(ip);
            final int NA = apps.size();
            for (int ia = 0; ia < NA; ia++) {
                ProcessRecord p = apps.valueAt(ia);
                if (p.thread != null && p.thread.asBinder() == app) {
                    return p;
                }
            }
        }

        Slog.w(TAG, "Can't find mystery application for " + reason
                + " from pid=" + Binder.getCallingPid()
                + " uid=" + Binder.getCallingUid() + ": " + app);
        return null;
    }

    private void checkSlow(long startTime, String where) {
        long now = SystemClock.uptimeMillis();
        if ((now - startTime) > 50) {
            // If we are taking more than 50ms, log about it.
            Slog.w(TAG, "Slow operation: " + (now - startTime) + "ms so far, now at " + where);
        }
    }
```

在上述的ProcessList.java的上述相关源码中，可以看出，在  
         outInfo.availMem = getFreeMemory();  
         outInfo.totalMem = getTotalMemory();  
 这段代码中，getFreeMemory();就是当前ram剩余的内存容量，而  
 getTotalMemory();就是系统ram运行内存的容量大小，而这两个方法是  
 native（）方法，具体实现是在android\_util\_Process.cpp中实现的，  
 接下来分析下android\_util\_Process.cpp中的相关方法



```
static jlong android_os_Process_getFreeMemory(JNIEnv* env, jobject clazz)
  {
      static const std::vector<std::string> memFreeTags = {
          ::android::meminfo::SysMemInfo::kMemFree,
          ::android::meminfo::SysMemInfo::kMemCached,
      };
      std::vector<uint64_t> mem(memFreeTags.size());
      ::android::meminfo::SysMemInfo smi;
  
      if (!smi.ReadMemInfo(memFreeTags, &mem)) {
          jniThrowRuntimeException(env, "SysMemInfo read failed to get Free Memory");
          return -1L;
      }
  
      jlong sum = 0;
      std::for_each(mem.begin(), mem.end(), [&](uint64_t val) { sum += val; });
  -    return sum * 1024;
  +    return sum * 1024*2;
  }
  
  static jlong android_os_Process_getTotalMemory(JNIEnv* env, jobject clazz)
  {
      struct sysinfo si;
      if (sysinfo(&si) == -1) {
          ALOGE("sysinfo failed: %s", strerror(errno));
          return -1;
      }
 -    return si.totalram;
 +     return si.totalram*2;
  }
```

在android\_util\_Process.cpp中的上述源码中，可以看出在android\_os\_Process\_getFreeMemory(JNIEnv\* env, jobject clazz)中  
 就是获取系统中ram运行内存当前剩余内存容量的大小，最终返回sum \* 1024， 而在android\_os\_Process\_getTotalMemory(JNIEnv\* env, jobject clazz)中  
 就是获取系统中ram运行内存内存容量的大小，最终返回的就是si.totalram;，所以就可以修改返回值就好了 来修改ram的容量和ram剩余容量的大小


## 3.2 kenel中修改ram容量大小的相关方法分析


  
 page\_alloc.c中关于ram运行内存容量大小的相关方法分析



```
long si_mem_available(void)
{
	long available;
	unsigned long pagecache;
	unsigned long wmark_low = 0;
	unsigned long pages[NR_LRU_LISTS];
	struct zone *zone;
	int lru;

	for (lru = LRU_BASE; lru < NR_LRU_LISTS; lru++)
		pages[lru] = global_node_page_state(NR_LRU_BASE + lru);

	for_each_zone(zone)
		wmark_low += zone->watermark[WMARK_LOW];

	/*
	 * Estimate the amount of memory available for userspace allocations,
	 * without causing swapping.
	 */
	available = global_zone_page_state(NR_FREE_PAGES) - totalreserve_pages;

	/*
	 * Not all the page cache can be freed, otherwise the system will
	 * start swapping. Assume at least half of the page cache, or the
	 * low watermark worth of cache, needs to stay.
	 */
	pagecache = pages[LRU_ACTIVE_FILE] + pages[LRU_INACTIVE_FILE];
	pagecache -= min(pagecache / 2, wmark_low);
	available += pagecache;

	/*
	 * Part of the reclaimable slab consists of items that are in use,
	 * and cannot be freed. Cap this estimate at the low watermark.
	 */
	available += global_node_page_state(NR_SLAB_RECLAIMABLE) -
		     min(global_node_page_state(NR_SLAB_RECLAIMABLE) / 2,
			 wmark_low);

	/*
	 * Part of the kernel memory, which can be released under memory
	 * pressure.
	 */
	available += global_node_page_state(NR_INDIRECTLY_RECLAIMABLE_BYTES) >>
		PAGE_SHIFT;

	if (available < 0)
		available = 0;
	return available;
}
EXPORT_SYMBOL_GPL(si_mem_available);

void si_meminfo(struct sysinfo *val)
{
-	val->totalram = totalram_pages;
+	val->totalram = totalram_pages*2;
	val->sharedram = global_node_page_state(NR_SHMEM);
-	val->freeram = global_zone_page_state(NR_FREE_PAGES);
+	val->freeram = global_zone_page_state(NR_FREE_PAGES)*2;
	val->bufferram = nr_blockdev_pages();
	val->totalhigh = totalhigh_pages;
	val->freehigh = nr_free_highpages();
	val->mem_unit = PAGE_SIZE;
}
```

在page\_alloc.c中的上述源码中，可以看出在si\_mem\_available(void)获取系统ram中的剩余可用内存大小容量  
 在核心方法si\_meminfo(struct sysinfo \*val)主要就是计算当前系统ram运行内存容量大小的方法，所以具体就可以修改  
 val->totalram = totalram\_pages;和val->freeram = global\_zone\_page\_state(NR\_FREE\_PAGES);  
 这两个值就可以了 这样就可以做到修改ram运行内存容量的大小的功能



